# Saiki Motion Effect SDK

An effect is a **folder** with two files. No Kotlin and no rebuild of the app code is needed to make one.

```
my_effect/
  effect.json   what the effect is called, its sliders and colors, how it looks in the browser
  effect.glsl   the shader code
  preview.jpg   (optional) your own picture for the browser card
```

There are two places an effect folder can live:

| Where | How you edit it | When it loads |
|---|---|---|
| **Inside the app** (Effects > Custom > Open Effect Editor) | the built-in code editor | when you press Run |
| **Inside the APK source**: `app/src/main/assets/sdk/<any folders>/my_effect/` | any text editor, then rebuild with GitHub Actions | every app start |

If both places contain the same `id`, the in-app one wins. Folders whose name starts with `_` are ignored (the `_template` folder is a starting point).
Folders can be nested to organize packs, for example `assets/sdk/my_pack/glows/soft_glow/`.

## effect.json

```json
{
  "id": "my_glow",
  "name": "My Glow",
  "description": "One line that explains the effect.",
  "category": "Light and glow",
  "params": [
    { "name": "amount", "label": "Amount", "min": 0, "max": 1, "def": 0.5, "dec": 2 },
    { "name": "mode",   "label": "Mode", "options": ["Soft", "Hard"], "def": 0 },
    { "name": "offset", "label": "Offset", "infinite": true, "span": 2, "def": 0 }
  ],
  "colors": [
    { "name": "tint", "label": "Tint", "def": "#FFFF8A1F" }
  ],
  "inputs": ["Map layer"],
  "shader": "effect.glsl",
  "preview": { "image": "mountain", "time": 0.7, "animation": "swipe" }
}
```

| Field | Notes |
|---|---|
| `id` | Unique. Letters, digits and `_`, starts with a letter. Saved projects refer to it, so do not change it later. |
| `name`, `description` | Shown in the browser. Both are required. |
| `category` | One of: Light and glow, Color, Stylize, Distort, Blur, Generate, Glitch and motion, Keying, Transform and time, Custom. Anything else is shown under Custom. |
| `params` | Each becomes a slider and a `float` with the same name in GLSL. `name` must be a valid GLSL identifier and must not clash with a GLSL function (`mix`, `step`, `length`...). Use `options` for a dropdown: the value is 0, 1, 2... in order. Use `"infinite": true` for a slider with no limits (`span` is how much one screen width covers). `dec` is the number of decimals shown. |
| `colors` | Each becomes a color picker and a `vec4` (premultiplied is NOT applied: `.rgb` is the plain color, `.a` its opacity). `def` is `#RRGGBB` or `#AARRGGBB`. |
| `inputs` | Up to 2 names. The user picks another layer for each, readable with `in0(uv)` and `in1(uv)`. `uHas0` and `uHas1` are 1.0 when a layer was chosen. |
| `shader` | File name of the code. Defaults to `effect.glsl`. |
| `preview` | How the card looks in the Effects browser, see below. |

### Browser animation (`preview`)

| Key | Values |
|---|---|
| `image` | `portrait`, `mountain`, `woman`, `greenscreen`, `ramen`, `apple`, or a file name in the effect folder such as `preview.jpg` (jpg or png) |
| `time` | the moment of the effect shown in the thumbnail, in seconds. Pick one where the effect is clearly visible. |
| `animation` | `swipe` a divider slides over the picture, `fade` cross-fades before to after, `cut` jumps between before and after, `wipe` a vertical reveal |

## effect.glsl

Define one function. It runs for every pixel.

```glsl
vec4 effect(vec2 uv) {
  vec4 c = src(uv);
  return vec4(c.rgb * amount, c.a);
}
```

* `uv` goes 0..1 across the layer. (0,0) is the bottom-left.
* Pixels are **premultiplied alpha**. Use `unpremul(c)` to get the plain color and multiply by `c.a` again before returning.
* Return a `vec4`. The result replaces the layer's pixel.

Available to your code:

| Name | What it is |
|---|---|
| `uTime` | seconds since the layer started |
| `uRes` | size of the layer in pixels (`vec2`) |
| `src(uv)` | the layer's pixel, outside 0..1 gives edge pixels |
| `srcW(uv, m)` | like `src` with edge handling: `m` = 0 transparent outside, 1 repeat, 2 mirror |
| `in0(uv)`, `in1(uv)` | pixels of the layers chosen in `inputs` |
| `luma(rgb)` | brightness |
| `hash11(x)`, `hash21(v)` | random number 0..1 from a float / vec2 |
| `vnoise(v)`, `fbm(v)` | smooth noise, layered noise |
| `rot(v, radians)` | rotates a vec2 |
| `hsv2rgb(hsv)` | color conversion |
| `unpremul(c)` | plain color from a premultiplied pixel |
| your params | `float` named as in `params` |
| your colors | `vec4` named as in `colors` |

Tips
* Dividing the screen into a square grid: multiply `uv.x` by `uRes.x / uRes.y`.
* Loops need constant bounds: `for (int i = 0; i < 16; i++)`.
* Effects that draw outside the layer (glows, streaks) are clipped to the layer, unless built in.

## Using the in-app editor

Effects > **Custom** > **Open Effect Editor**.

* Left: your files. Use the icons for **new effect**, **new file**, **new folder**, **rename**, **delete**. Long-press an item for the same menu. The **Bundled** group at the bottom is read-only: long-press an effect there and choose **Duplicate to my effects** to start from it.
* Top: **Run** saves everything, reloads the effects and renders the browser preview below the editor. Compiler errors appear under Problems with the line number of *your* file. Tap an error to jump to the line.
* The key bar above the keyboard has Tab, brackets and common symbols. Undo and redo are in the top bar.

## Putting an effect in the APK

1. In the project, create `app/src/main/assets/sdk/my_pack/my_effect/`.
2. Add `effect.json` and `effect.glsl` (copy `_template`).
3. Commit and let GitHub Actions build. The effect is in the Effects browser after install.

To move an effect you made in the app into the APK: open one of its files in the editor, tap the three-dot menu and choose **Export effect as zip**. The zip is saved in Downloads/SaikiMotion and contains the effect folder. Unzip it into `app/src/main/assets/sdk/my_pack/`, commit, and rebuild.

To use your own picture in the browser card: three-dot menu > **Pick preview image**. The picture is stored in the effect folder as `preview.jpg` or `preview.png` and `preview.image` in `effect.json` is set for you.

## Troubleshooting

* **The effect is missing from the browser.** `effect.json` is invalid or the `id` is already used. In the editor the folder is shown in red and Run lists the reason. Common causes: a missing `name` or `description`, a parameter name with a space, an `id` that starts with a digit.
* **"Line 12: ..." errors.** Line numbers are relative to your `effect.glsl`. Tap the error to jump there.
* **The picture goes transparent or black.** The result must be premultiplied: `vec4(rgb * alpha, alpha)`.
* **A slider does nothing.** The parameter is not used in the code, or its name differs by capital letters.
