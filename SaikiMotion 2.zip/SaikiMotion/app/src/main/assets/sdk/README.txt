Effects in this folder are bundled into the APK. Each effect is a folder with effect.json and effect.glsl.
Add a folder here, rebuild, and the effect appears in the Effects browser. See SDK.md in the project root.
