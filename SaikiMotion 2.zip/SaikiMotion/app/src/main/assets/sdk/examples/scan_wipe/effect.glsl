// Position of the pixel along the sweep direction.
vec4 effect(vec2 uv) {
  float a = radians(angle);
  vec2 dir = vec2(cos(a), sin(a));
  float along = dot(uv - 0.5, dir) + 0.5;        // 0..1 across the picture
  float pos = fract(uTime * speed) * 1.4 - 0.2;  // line position, runs a little past the edges
  float d = along - pos;
  float inLine = 1.0 - smoothstep(0.0, width, abs(d));
  // Pixels close to the line are pushed sideways by a random amount.
  float row = floor(uv.y * 40.0);
  float jitter = (hash11(row + floor(uTime * 12.0)) - 0.5) * shift * inLine;
  vec4 c = srcW(uv + vec2(jitter, 0.0), 2.0);
  vec3 glow = lineColor.rgb * inLine * lineColor.a;
  return vec4(c.rgb + glow * c.a, c.a);
}
