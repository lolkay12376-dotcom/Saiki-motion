// Pulses a tint color over the layer.
vec4 effect(vec2 uv) {
  vec4 c = src(uv);
  float s = 0.5 + 0.5 * sin(uTime * speed * 6.2831853);
  if (shape > 0.5 && shape < 1.5) s = s * s * s;      // Sharp
  if (shape > 1.5) s = 1.0;                            // Steady
  vec3 base = c.a > 0.0001 ? c.rgb / c.a : vec3(0.0);  // un-premultiply
  vec3 mixed = mix(base, base * tint.rgb * 1.6, amount * s * tint.a);
  return vec4(mixed * c.a, c.a);                       // premultiply again
}
