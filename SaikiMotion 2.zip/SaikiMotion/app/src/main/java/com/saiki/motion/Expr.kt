package com.saiki.motion

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

private typealias F = (Float, Float) -> Float

/** Tiny expression language for properties. Variables: t (time), v (keyframed value). */
class Expr private constructor(private val fn: F) {
    fun eval(v: Float, t: Float): Float = try {
        val r = fn(v, t)
        if (r.isNaN() || r.isInfinite()) v else r
    } catch (e: Exception) { v }

    companion object {
        fun parse(src: String): Expr? = try { val p = P(src); val f = p.expr(); p.end(); Expr(f) } catch (e: Exception) { null }

        private fun fn(b: F): F = b
        private fun h(i: Int): Float { var x = i * 374761393; x = (x xor (x ushr 13)) * 1274126177; x = x xor (x ushr 16); return (x and 0xFFFFFF) / 16777216f }
        private fun noise(x: Float): Float { val i = floor(x); val f = x - i; val u = f * f * (3f - 2f * f); val a = h(i.toInt()); val b = h(i.toInt() + 1); return a + (b - a) * u }

        private class P(val s: String) {
            var i = 0
            fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
            fun end() { ws(); if (i != s.length) throw IllegalArgumentException("trailing") }
            fun peek(): Char { ws(); return if (i < s.length) s[i] else '\u0000' }

            fun expr(): F {
                val a = addExpr()
                val c = peek()
                if (c == '<' || c == '>' || c == '=' || c == '!') {
                    var op = s[i++].toString()
                    if (i < s.length && s[i] == '=') { op += "="; i++ }
                    val b = addExpr()
                    return when (op) {
                        "<" -> fn { v, t -> if (a(v, t) < b(v, t)) 1f else 0f }
                        ">" -> fn { v, t -> if (a(v, t) > b(v, t)) 1f else 0f }
                        "<=" -> fn { v, t -> if (a(v, t) <= b(v, t)) 1f else 0f }
                        ">=" -> fn { v, t -> if (a(v, t) >= b(v, t)) 1f else 0f }
                        "==", "=" -> fn { v, t -> if (a(v, t) == b(v, t)) 1f else 0f }
                        "!=" -> fn { v, t -> if (a(v, t) != b(v, t)) 1f else 0f }
                        else -> throw IllegalArgumentException(op)
                    }
                }
                return a
            }
            fun addExpr(): F {
                var l = term()
                while (peek() == '+' || peek() == '-') {
                    val op = s[i++]; val r = term(); val a = l
                    l = if (op == '+') fn { v, t -> a(v, t) + r(v, t) } else fn { v, t -> a(v, t) - r(v, t) }
                }
                return l
            }
            fun term(): F {
                var l = unary()
                while (peek() == '*' || peek() == '/' || peek() == '%') {
                    val op = s[i++]; val r = unary(); val a = l
                    l = when (op) { '*' -> fn { v, t -> a(v, t) * r(v, t) }; '/' -> fn { v, t -> a(v, t) / r(v, t) }; else -> fn { v, t -> a(v, t) % r(v, t) } }
                }
                return l
            }
            fun unary(): F {
                if (peek() == '-') { i++; val a = unary(); return fn { v, t -> -a(v, t) } }
                if (peek() == '+') { i++; return unary() }
                val base = atom()
                if (peek() == '^') { i++; val e = unary(); return fn { v, t -> base(v, t).pow(e(v, t)) } }
                return base
            }
            fun atom(): F {
                val c = peek()
                if (c == '(') { i++; val e = expr(); if (peek() != ')') throw IllegalArgumentException(); i++; return e }
                if (c.isDigit() || c == '.') {
                    val st = i
                    while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                    val n = s.substring(st, i).toFloat()
                    return fn { _, _ -> n }
                }
                if (c.isLetter() || c == '_') {
                    val st = i
                    while (i < s.length && (s[i].isLetterOrDigit() || s[i] == '_')) i++
                    val name = s.substring(st, i).lowercase()
                    if (name == "marker" && i < s.length && s[i] == '.') {
                        i++
                        val st2 = i
                        while (i < s.length && s[i].isLetter()) i++
                        if (s.substring(st2, i).lowercase() != "key") throw IllegalArgumentException("marker")
                        if (peek() != '(') throw IllegalArgumentException()
                        i++
                        val q = peek()
                        if (q != '"' && q != '\'') throw IllegalArgumentException("string")
                        i++
                        val st3 = i
                        while (i < s.length && s[i] != q) i++
                        if (i >= s.length) throw IllegalArgumentException("string")
                        val nm = s.substring(st3, i)
                        i++
                        if (peek() != ')') throw IllegalArgumentException()
                        i++
                        return fn { _, _ -> Editor.scene.markerTime(nm) ?: 0f }
                    }
                    if (peek() == '(') {
                        i++
                        val args = ArrayList<F>()
                        if (peek() != ')') { args.add(expr()); while (peek() == ',') { i++; args.add(expr()) } }
                        if (peek() != ')') throw IllegalArgumentException()
                        i++
                        return call(name, args)
                    }
                    return when (name) {
                        "t", "time" -> fn { _, t -> t }
                        "v", "value" -> fn { v, _ -> v }
                        "pi" -> fn { _, _ -> PI.toFloat() }
                        else -> throw IllegalArgumentException(name)
                    }
                }
                throw IllegalArgumentException("unexpected")
            }
            fun call(n: String, a: List<F>): F {
                fun need(k: Int) { if (a.size != k) throw IllegalArgumentException("args") }
                return when (n) {
                    "sin" -> { need(1); fn { v, t -> sin(a[0](v, t)) } }
                    "cos" -> { need(1); fn { v, t -> cos(a[0](v, t)) } }
                    "tan" -> { need(1); fn { v, t -> tan(a[0](v, t)) } }
                    "abs" -> { need(1); fn { v, t -> abs(a[0](v, t)) } }
                    "sqrt" -> { need(1); fn { v, t -> sqrt(a[0](v, t)) } }
                    "floor" -> { need(1); fn { v, t -> floor(a[0](v, t)) } }
                    "round" -> { need(1); fn { v, t -> a[0](v, t).roundToInt().toFloat() } }
                    "noise" -> { need(1); fn { v, t -> noise(a[0](v, t)) * 2f - 1f } }
                    "if" -> { need(3); fn { v, t -> if (a[0](v, t) != 0f) a[1](v, t) else a[2](v, t) } }
                    "step" -> { need(2); fn { v, t -> if (a[1](v, t) >= a[0](v, t)) 1f else 0f } }
                    "pow" -> { need(2); fn { v, t -> a[0](v, t).pow(a[1](v, t)) } }
                    "min" -> { need(2); fn { v, t -> min(a[0](v, t), a[1](v, t)) } }
                    "max" -> { need(2); fn { v, t -> max(a[0](v, t), a[1](v, t)) } }
                    "wiggle" -> { need(2); fn { v, t -> a[1](v, t) * (noise(t * a[0](v, t)) * 2f - 1f) } }
                    "clamp" -> { need(3); fn { v, t -> a[0](v, t).coerceIn(a[1](v, t), a[2](v, t)) } }
                    "mix" -> { need(3); fn { v, t -> a[0](v, t) + (a[1](v, t) - a[0](v, t)) * a[2](v, t) } }
                    "linear" -> { need(5); fn { v, t ->
                        val x = a[0](v, t); val a0 = a[1](v, t); val b0 = a[2](v, t); val c0 = a[3](v, t); val d0 = a[4](v, t)
                        c0 + (d0 - c0) * ((x - a0) / (b0 - a0)).coerceIn(0f, 1f) } }
                    else -> throw IllegalArgumentException(n)
                }
            }
        }
    }
}
