package com.saiki.motion

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CopyOnWriteArraySet
import kotlin.math.abs

enum class Ease { LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, BOUNCE, CUSTOM, ELASTIC, WAVE, STEPS }

fun bezier(u: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
    if (u <= 0f) return 0f
    if (u >= 1f) return 1f
    var s = u
    val cx = 3f * x1
    val bx = 3f * (x2 - x1) - cx
    val ax = 1f - cx - bx
    for (i in 0 until 8) {
        val x = ((ax * s + bx) * s + cx) * s
        val dx = (3f * ax * s + 2f * bx) * s + cx
        if (abs(dx) < 1e-5f) break
        s = (s - (x - u) / dx).coerceIn(0f, 1f)
    }
    val cy = 3f * y1
    val by = 3f * (y2 - y1) - cy
    val ay = 1f - cy - by
    return ((ay * s + by) * s + cy) * s
}

fun elasticOut(u: Float, cn: Int, amp: Float): Float {
    if (u <= 0f) return 0f
    if (u >= 1f) return 1f
    val c = (2.0 * Math.PI / 3.0) * (cn / 3.0)
    val e = Math.pow(2.0, -10.0 * u) * Math.sin((u * 10.0 - 0.75) * c) + 1.0
    return 1f + (e.toFloat() - 1f) * amp
}

fun bounceOut(u: Float): Float {
    val n = 7.5625f
    val d = 2.75f
    return when {
        u < 1f / d -> n * u * u
        u < 2f / d -> { val x = u - 1.5f / d; n * x * x + 0.75f }
        u < 2.5f / d -> { val x = u - 2.25f / d; n * x * x + 0.9375f }
        else -> { val x = u - 2.625f / d; n * x * x + 0.984375f }
    }
}

class Key(var t: Float, var v: Float, var ease: Ease = Ease.EASE_IN_OUT) {
    var x1 = 0.42f
    var y1 = 0f
    var x2 = 0.58f
    var y2 = 1f

    fun preset(e: Ease) {
        ease = e
        when (e) {
            Ease.LINEAR -> { x1 = 0f; y1 = 0f; x2 = 1f; y2 = 1f }
            Ease.EASE_IN -> { x1 = 0.42f; y1 = 0f; x2 = 1f; y2 = 1f }
            Ease.EASE_OUT -> { x1 = 0f; y1 = 0f; x2 = 0.58f; y2 = 1f }
            Ease.EASE_IN_OUT -> { x1 = 0.42f; y1 = 0f; x2 = 0.58f; y2 = 1f }
            else -> {}
        }
    }

    var amp = 1f
    var cn = 3
    var rev = false

    fun isBezier(): Boolean = ease != Ease.BOUNCE && ease != Ease.ELASTIC && ease != Ease.WAVE && ease != Ease.STEPS

    private fun raw(u: Float): Float = when (ease) {
        Ease.BOUNCE -> bounceOut(u)
        Ease.ELASTIC -> elasticOut(u, cn, amp)
        Ease.WAVE -> if (u <= 0f) 0f else if (u >= 1f) 1f else u + amp * 0.12f * Math.sin(2.0 * Math.PI * cn * u).toFloat()
        Ease.STEPS -> if (u >= 1f) 1f else Math.floor((u * cn).toDouble()).toFloat() / cn
        else -> bezier(u, x1, y1, x2, y2)
    }

    fun curve(u: Float): Float = if (rev) 1f - raw(1f - u) else raw(u)

    fun copyCurveFrom(o: Key) { ease = o.ease; x1 = o.x1; y1 = o.y1; x2 = o.x2; y2 = o.y2; amp = o.amp; cn = o.cn; rev = o.rev }

    fun curveJson(): JSONObject = JSONObject().put("e", ease.name).put("x1", x1.toDouble()).put("y1", y1.toDouble())
        .put("x2", x2.toDouble()).put("y2", y2.toDouble()).put("amp", amp.toDouble()).put("cn", cn).put("rev", rev)

    fun curveFromJson(o: JSONObject) {
        ease = try { Ease.valueOf(o.optString("e", "CUSTOM")) } catch (e: Exception) { Ease.CUSTOM }
        x1 = o.optDouble("x1", x1.toDouble()).toFloat(); y1 = o.optDouble("y1", y1.toDouble()).toFloat()
        x2 = o.optDouble("x2", x2.toDouble()).toFloat(); y2 = o.optDouble("y2", y2.toDouble()).toFloat()
        amp = o.optDouble("amp", 1.0).toFloat(); cn = o.optInt("cn", 3); rev = o.optBoolean("rev", false)
    }

    init { preset(ease) }
}

/** An animatable value: constant `base` or interpolated keyframes with cubic bezier easing. */
class Track(var base: Float) {
    val keys = CopyOnWriteArrayList<Key>()

    var exprSrc = ""
    @Volatile var expr: Expr? = null
    @Volatile var exprOn = false
    fun exprActive() = exprOn && expr != null
    fun copyExprFrom(o: Track) { setExpr(o.exprSrc); exprOn = o.exprOn }

    fun setExpr(s: String): Boolean {
        if (s.isBlank()) { exprSrc = ""; expr = null; return true }
        val e = Expr.parse(s) ?: return false
        exprSrc = s; expr = e
        return true
    }

    fun eval(t: Float): Float {
        val r = evalRaw(t)
        val e = expr
        return if (e != null && exprOn) e.eval(r, t) else r
    }

    private fun evalRaw(t: Float): Float {
        val ks = keys
        val n = ks.size
        if (n == 0) return base
        if (t <= ks[0].t) return ks[0].v
        if (t >= ks[n - 1].t) return ks[n - 1].v
        for (i in 0 until n - 1) {
            val a = ks[i]
            val b = ks[i + 1]
            if (t >= a.t && t <= b.t) {
                val u = (t - a.t) / (b.t - a.t)
                return a.v + (b.v - a.v) * a.curve(u)
            }
        }
        return base
    }

    fun keyAt(t: Float): Key? = keys.firstOrNull { abs(it.t - t) < 0.03f }

    fun set(t: Float, v: Float, autoKey: Boolean) {
        if (!autoKey && keys.isEmpty()) { base = v; return }
        val k = keyAt(t)
        if (k != null) k.v = v else { keys.add(Key(t, v)); keys.sortBy { it.t } }
    }

    fun toggleKey(t: Float) {
        val k = keyAt(t)
        if (k != null) {
            keys.remove(k)
            if (keys.isEmpty()) base = k.v
        } else {
            val v = evalRaw(t)
            keys.add(Key(t, v))
            keys.sortBy { it.t }
        }
    }

    fun toJson(): JSONObject {
        val arr = JSONArray()
        for (k in keys) arr.put(JSONObject().put("t", k.t.toDouble()).put("v", k.v.toDouble()).put("e", k.ease.name)
            .put("x1", k.x1.toDouble()).put("y1", k.y1.toDouble()).put("x2", k.x2.toDouble()).put("y2", k.y2.toDouble()).put("amp", k.amp.toDouble()).put("cn", k.cn).put("rev", k.rev))
        return JSONObject().put("b", base.toDouble()).put("k", arr).put("x", exprSrc).put("xo", exprOn)
    }

    fun load(o: JSONObject) {
        base = o.optDouble("b", base.toDouble()).toFloat()
        setExpr(o.optString("x", ""))
        exprOn = o.optBoolean("xo", exprSrc.isNotBlank())
        keys.clear()
        val a = o.optJSONArray("k") ?: return
        for (i in 0 until a.length()) {
            val j = a.getJSONObject(i)
            val k = Key(j.getDouble("t").toFloat(), j.getDouble("v").toFloat(),
                try { Ease.valueOf(j.optString("e", "EASE_IN_OUT")) } catch (e: Exception) { Ease.EASE_IN_OUT })
            k.x1 = j.optDouble("x1", k.x1.toDouble()).toFloat(); k.y1 = j.optDouble("y1", k.y1.toDouble()).toFloat()
            k.x2 = j.optDouble("x2", k.x2.toDouble()).toFloat(); k.y2 = j.optDouble("y2", k.y2.toDouble()).toFloat()
            k.amp = j.optDouble("amp", 1.0).toFloat(); k.cn = j.optInt("cn", 3); k.rev = j.optBoolean("rev", false)
            keys.add(k)
        }
    }
}

class PropDef(
    val key: String, val label: String, val min: Float, val max: Float, val def: Float,
    val dec: Int = 2, val name: String = key, val options: List<String>? = null,
    val inf: Boolean = false, val span: Float = 0f
)

enum class LayerType { SHAPE, TEXT, IMAGE, VIDEO, CAMERA, NULL, MODEL, PARTICLES, GROUP, ADJUST, AUDIO }
enum class ShapeKind { RECT, ROUND, CIRCLE, TRIANGLE, STAR }

class TextAnim(var type: Int = 0, var mode: Int = 0) {
    var start = 0f
    var dur = 0.6f
    var stagger = 0.06f
    var distance = 0.6f
    var scaleFrom = 0f
    var rotFrom = 0f
    var ease = 1
    var fade = true
    var speed = 1f
    val curve = Key(0f, 0f)

    fun name(): String = TYPES.getOrElse(type) { "Animation" } + (if (mode == 0) " in" else if (mode == 1) " out" else " loop")
    fun sig(): String = "$type,$mode,$start,$dur,$stagger,$distance,$scaleFrom,$rotFrom,$ease,$fade,$speed,${curve.x1},${curve.y1},${curve.x2},${curve.y2}"
    fun copy(): TextAnim {
        val c = TextAnim(type, mode)
        c.start = start; c.dur = dur; c.stagger = stagger; c.distance = distance; c.scaleFrom = scaleFrom
        c.rotFrom = rotFrom; c.ease = ease; c.fade = fade; c.speed = speed
        c.curve.x1 = curve.x1; c.curve.y1 = curve.y1; c.curve.x2 = curve.x2; c.curve.y2 = curve.y2
        return c
    }
    fun toJson(): JSONObject = JSONObject().put("type", type).put("mode", mode).put("start", start.toDouble()).put("dur", dur.toDouble())
        .put("stagger", stagger.toDouble()).put("distance", distance.toDouble()).put("scaleFrom", scaleFrom.toDouble())
        .put("rotFrom", rotFrom.toDouble()).put("ease", ease).put("fade", fade).put("speed", speed.toDouble()).put("cx1", curve.x1.toDouble()).put("cy1", curve.y1.toDouble()).put("cx2", curve.x2.toDouble()).put("cy2", curve.y2.toDouble())

    companion object {
        val TYPES = listOf("Fade", "Slide up", "Slide down", "Slide left", "Slide right", "Pop", "Rotate", "Typewriter", "Wave", "Outline draw", "Shake")
        fun fromJson(o: JSONObject): TextAnim {
            val a = TextAnim(o.optInt("type", 0), o.optInt("mode", 0))
            a.start = o.optDouble("start", 0.0).toFloat(); a.dur = o.optDouble("dur", 0.6).toFloat()
            a.stagger = o.optDouble("stagger", 0.06).toFloat(); a.distance = o.optDouble("distance", 0.6).toFloat()
            a.scaleFrom = o.optDouble("scaleFrom", 0.0).toFloat(); a.rotFrom = o.optDouble("rotFrom", 0.0).toFloat()
            a.ease = o.optInt("ease", 1); a.fade = o.optBoolean("fade", true); a.speed = o.optDouble("speed", 1.0).toFloat()
            a.curve.x1 = o.optDouble("cx1", 0.42).toFloat(); a.curve.y1 = o.optDouble("cy1", 0.0).toFloat(); a.curve.x2 = o.optDouble("cx2", 0.58).toFloat(); a.curve.y2 = o.optDouble("cy2", 1.0).toFloat()
            return a
        }
    }
}

class Layer(val id: Int, var name: String, var type: LayerType) {
    /** Parameter key for a given effect entry; entries with "~n" are extra instances of the same effect. */
    fun pkey(entry: String, pd: PropDef): String = if (entry.contains('~')) entry + "__" + pd.name else pd.key
    fun ckey(entry: String, cp: ColorParam): String = if (entry.contains('~')) entry + "__" + cp.name else cp.key

    var text = "Saiki Motion"
    var color = 0xFF7C4DFF.toInt()
    var color2 = 0xFFFF4081.toInt()
    var shape = ShapeKind.ROUND
    var bold = true
    var italic = false
    var imagePath: String? = null
    var start = 0f
    var end = 5f
    var visible = true
    var is3d = false
    var parentId = -1
    var blend = 0
    var srcDur = 0f
    var srcOffset = 0f
    var mask = 0
    var mblur = false
    var mbRgb = false
    var mbStutter = false
    var font = "sans-serif"
    var fontPath: String? = null
    var strokeW = 0f
    var strokeColor = 0xFF000000.toInt()
    var spacing = 0f
    var borderW = 0f
    var borderColor = 0xFFFFFFFF.toInt()
    var borderPad = 10f
    @Volatile var texComp = 1f
    val anims = CopyOnWriteArrayList<TextAnim>()
    @Volatile var texAspect = 1f
    val props = LinkedHashMap<String, Track>().also { m -> Registry.allProps().forEach { m[it.key] = Track(it.def) } }
    val fx = CopyOnWriteArrayList<String>()
    val fxOff = CopyOnWriteArraySet<String>()
    val inputs = ConcurrentHashMap<String, Int>()

    /** UI-side accessor: creates the track if it did not exist yet (e.g. effect imported later). */
    fun track(key: String): Track = props[key] ?: synchronized(props) {
        props.getOrPut(key) { Track(Registry.propDef(key)?.def ?: 0f) }
    }

    fun p(key: String, t: Float): Float = props[key]?.eval(t) ?: (Registry.propDef(key)?.def ?: 0f)
    fun texKey(lt: Float = 0f): String =
        "$type|$text|$color|$shape|$bold|$italic|$imagePath|$font|$fontPath|${p("strokeW", lt)}|$strokeColor|${p("spacing", lt)}|${p("borderW", lt)}|$borderColor|${p("borderPad", lt)}" +
            (if (type == LayerType.TEXT && anims.isNotEmpty()) "|" + anims.joinToString(";") { it.sig() } + "|" + animStamp(lt) else "")

    /** Text re-renders only while an animation is actually playing. */
    private fun animStamp(lt: Float): String {
        val rel = lt - start
        var lo = Float.MAX_VALUE
        var hi = -1f
        var loop = false
        val n = maxOf(1, text.length)
        for (a in anims) { if (a.mode == 2) loop = true; lo = minOf(lo, a.start); hi = maxOf(hi, a.start + a.stagger * (n - 1) + a.dur) }
        if (!loop && rel < lo) return "pre"
        if (!loop && rel > hi) return "post"
        return (rel * 30f).toInt().toString()
    }
    fun fxOn(id: String): Boolean = fx.contains(id) && !fxOff.contains(id)
    fun isRenderable(): Boolean = type != LayerType.CAMERA && type != LayerType.NULL && type != LayerType.GROUP && type != LayerType.AUDIO

    /** Time used to evaluate this layer's animation (Time Remap). */
    fun localTime(t: Float): Float {
        if (!fxOn("remap")) return t
        val rt = props["remapT"]
        if (rt != null && rt.keys.isNotEmpty()) return start + rt.eval(t)
        val sp = props["remapSpeed"] ?: return t
        if (sp.keys.isEmpty()) return start + (t - start) * sp.base
        var acc = 0f
        var u = start
        while (u < t) {
            val d = minOf(0.05f, t - u)
            acc += sp.eval(u + d * 0.5f) * d
            u += d
        }
        return start + acc
    }

    /** Playback speed at timeline time t (1 when Time Remap is off). */
    fun speedAt(t: Float): Float {
        if (!fxOn("remap")) return 1f
        val rt = props["remapT"]
        if (rt != null && rt.keys.isNotEmpty()) return (rt.eval(t + 0.02f) - rt.eval(t - 0.02f)) / 0.04f
        return props["remapSpeed"]?.eval(t) ?: 1f
    }

    fun editTime(key: String, t: Float): Float = if (key.startsWith("remap")) t else localTime(t)
}

class Scene(var name: String) {
    var duration = 5f
    var bg = 0xFF101018.toInt()
    var fov = 45f
    val layers = CopyOnWriteArrayList<Layer>()
    val markers = CopyOnWriteArrayList<Float>()
    val markerNames = java.util.concurrent.ConcurrentHashMap<Int, String>()
    private fun mk(t: Float) = Math.round(t * 1000f)
    fun markerName(t: Float): String? = markerNames[mk(t)] ?: markers.firstOrNull { Math.abs(it - t) < 0.02f }?.let { markerNames[mk(it)] }
    fun setMarkerName(t: Float, n: String) {
        val m = markers.firstOrNull { Math.abs(it - t) < 0.02f } ?: return
        if (n.isBlank()) markerNames.remove(mk(m)) else markerNames[mk(m)] = n.trim()
    }
    fun markerTime(name: String): Float? {
        for ((k, v) in markerNames) if (v.equals(name, true)) return k / 1000f
        return null
    }
}

class Project {
    var name = "Project 1"
    var w = 1920
    var h = 1080
    var fps = 30
    var nextId = 1
    val scenes = CopyOnWriteArrayList<Scene>()
    init { scenes.add(Scene("Scene 1")) }
}

object Editor {
    @Volatile var project = Project()
    @Volatile var sceneIndex = 0
    @Volatile var time = 0f
    val scene: Scene
        get() = project.scenes[sceneIndex.coerceIn(0, project.scenes.size - 1)]
}

object Store {
    fun toJson(p: Project): JSONObject {
        val o = JSONObject().put("name", p.name).put("w", p.w).put("h", p.h).put("fps", p.fps).put("next", p.nextId)
        val sa = JSONArray()
        for (s in p.scenes) {
            val so = JSONObject().put("name", s.name).put("dur", s.duration.toDouble())
                .put("bg", s.bg).put("fov", s.fov.toDouble())
            val la = JSONArray()
            for (l in s.layers) {
                val lo = JSONObject().put("id", l.id).put("name", l.name).put("type", l.type.name)
                    .put("text", l.text).put("color", l.color).put("color2", l.color2).put("shape", l.shape.name)
                    .put("bold", l.bold).put("italic", l.italic).put("font", l.font).put("fontPath", l.fontPath ?: "").put("strokeW", l.strokeW.toDouble()).put("strokeColor", l.strokeColor).put("spacing", l.spacing.toDouble()).put("borderW", l.borderW.toDouble()).put("borderColor", l.borderColor).put("borderPad", l.borderPad.toDouble())
                    .put("img", l.imagePath ?: "").put("start", l.start.toDouble()).put("end", l.end.toDouble())
                    .put("is3d", l.is3d).put("parent", l.parentId).put("blend", l.blend).put("srcDur", l.srcDur.toDouble()).put("srcOff", l.srcOffset.toDouble()).put("mask", l.mask).put("mblur", l.mblur).put("mbRgb", l.mbRgb).put("mbStutter", l.mbStutter)
                lo.put("anims", JSONArray().also { a -> for (an in l.anims) a.put(an.toJson()) })
                lo.put("fx", JSONArray(l.fx.toList()))
                lo.put("fxoff", JSONArray(l.fxOff.toList()))
                lo.put("vis", l.visible)
                val io = JSONObject()
                for ((k, v) in l.inputs) io.put(k, v)
                lo.put("inputs", io)
                val po = JSONObject()
                for ((k, tr) in l.props) po.put(k, tr.toJson())
                lo.put("props", po)
                la.put(lo)
            }
            so.put("layers", la)
            val ma = JSONArray()
            for (m in s.markers) ma.put(m.toDouble())
            so.put("markers", ma)
            val mn = JSONObject()
            for ((k, v) in s.markerNames) mn.put(k.toString(), v)
            so.put("mnames", mn)
            sa.put(so)
        }
        o.put("scenes", sa)
        return o
    }

    fun fromJson(o: JSONObject): Project {
        val p = Project()
        p.scenes.clear()
        p.name = o.optString("name", "Project")
        p.w = o.optInt("w", 1920); p.h = o.optInt("h", 1080); p.fps = o.optInt("fps", 30)
        p.nextId = o.optInt("next", 1)
        val sa = o.getJSONArray("scenes")
        for (i in 0 until sa.length()) {
            val so = sa.getJSONObject(i)
            val s = Scene(so.optString("name", "Scene"))
            s.duration = so.optDouble("dur", 5.0).toFloat()
            s.bg = so.optInt("bg", s.bg)
            s.fov = so.optDouble("fov", 45.0).toFloat()
            val mk = so.optJSONArray("markers")
            if (mk != null) for (k in 0 until mk.length()) s.markers.add(mk.getDouble(k).toFloat())
            val mnj = so.optJSONObject("mnames")
            if (mnj != null) for (key in mnj.keys()) { val ki = key.toIntOrNull(); if (ki != null) s.markerNames[ki] = mnj.getString(key) }
            val la = so.optJSONArray("layers")
            if (la != null) for (j in 0 until la.length()) {
                val lo = la.getJSONObject(j)
                val type = try { LayerType.valueOf(lo.getString("type")) } catch (e: Exception) { LayerType.SHAPE }
                val l = Layer(lo.getInt("id"), lo.optString("name", "Layer"), type)
                l.text = lo.optString("text", ""); l.color = lo.optInt("color", l.color); l.color2 = lo.optInt("color2", l.color2)
                l.shape = try { ShapeKind.valueOf(lo.optString("shape", "ROUND")) } catch (e: Exception) { ShapeKind.ROUND }
                l.bold = lo.optBoolean("bold", true); l.italic = lo.optBoolean("italic", false); l.font = lo.optString("font", "sans-serif"); val fpth = lo.optString("fontPath", ""); l.fontPath = if (fpth.isEmpty()) null else fpth; l.strokeW = lo.optDouble("strokeW", 0.0).toFloat(); l.strokeColor = lo.optInt("strokeColor", l.strokeColor); l.spacing = lo.optDouble("spacing", 0.0).toFloat(); l.borderW = lo.optDouble("borderW", 0.0).toFloat(); l.borderColor = lo.optInt("borderColor", l.borderColor); l.borderPad = lo.optDouble("borderPad", 10.0).toFloat(); lo.optJSONArray("anims")?.let { aa -> for (q in 0 until aa.length()) l.anims.add(TextAnim.fromJson(aa.getJSONObject(q))) }
                val img = lo.optString("img", "")
                l.imagePath = if (img.isEmpty()) null else img
                l.start = lo.optDouble("start", 0.0).toFloat(); l.end = lo.optDouble("end", 5.0).toFloat()
                l.is3d = lo.optBoolean("is3d", false); l.parentId = lo.optInt("parent", -1)
                l.blend = lo.optInt("blend", 0); l.srcDur = lo.optDouble("srcDur", 0.0).toFloat(); l.srcOffset = lo.optDouble("srcOff", 0.0).toFloat(); l.mask = lo.optInt("mask", 0); l.mblur = lo.optBoolean("mblur", false); l.mbRgb = lo.optBoolean("mbRgb", false); l.mbStutter = lo.optBoolean("mbStutter", false)
                val fa = lo.optJSONArray("fx")
                if (fa != null) for (k in 0 until fa.length()) l.fx.add(fa.getString(k))
                val fo = lo.optJSONArray("fxoff")
                if (fo != null) for (k in 0 until fo.length()) l.fxOff.add(fo.getString(k))
                l.visible = lo.optBoolean("vis", true)
                val io = lo.optJSONObject("inputs")
                if (io != null) for (k in io.keys()) l.inputs[k] = io.getInt(k)
                val po = lo.optJSONObject("props")
                if (po != null) for (k in po.keys()) po.optJSONObject(k)?.let { l.track(k).load(it) }
                s.layers.add(l)
            }
            p.scenes.add(s)
        }
        if (p.scenes.isEmpty()) p.scenes.add(Scene("Scene 1"))
        return p
    }
}
