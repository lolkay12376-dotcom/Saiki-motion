package com.saiki.motion

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Project files: a .saikipjf (JSON), or a zip holding the .saikipjf plus every media file it uses. */
object ProjectIO {
    class MediaInfo(val files: List<File>, val bytes: Long)

    private val KEYS = arrayOf("img", "fontPath")

    private fun eachLayer(root: JSONObject, f: (JSONObject) -> Unit) {
        val sc = root.optJSONArray("scenes") ?: return
        for (i in 0 until sc.length()) {
            val la = sc.getJSONObject(i).optJSONArray("layers") ?: continue
            for (j in 0 until la.length()) f(la.getJSONObject(j))
        }
    }

    fun mediaOf(ctx: Context, id: String): MediaInfo {
        val json = Store.toJson(Projects.load(ctx, id))
        val set = LinkedHashSet<String>()
        eachLayer(json) { l -> for (k in KEYS) { val v = l.optString(k, ""); if (v.isNotEmpty() && File(v).exists()) set.add(v) } }
        val files = set.map { File(it) }
        var bytes = 0L
        for (f in files) bytes += f.length()
        return MediaInfo(files, bytes)
    }

    private fun saveDownload(ctx: Context, name: String, mime: String, input: InputStream): String {
        val v = ContentValues()
        v.put(MediaStore.Downloads.DISPLAY_NAME, name)
        v.put(MediaStore.Downloads.MIME_TYPE, mime)
        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SaikiMotion")
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw IOException("Could not create file")
        ctx.contentResolver.openOutputStream(uri)!!.use { o -> input.use { it.copyTo(o) } }
        return "Downloads/SaikiMotion/$name"
    }

    /** Returns where the file was saved. */
    fun export(ctx: Context, id: String, includeMedia: Boolean): String {
        val p = Projects.load(ctx, id)
        val json = Store.toJson(p)
        val safe = p.name.replace(Regex("[^A-Za-z0-9_ -]"), "_").ifBlank { "project" }
        val media = mediaOf(ctx, id).files
        if (includeMedia && media.isNotEmpty()) {
            val names = HashMap<String, String>()
            val used = HashSet<String>()
            for (f in media) {
                var n = f.name
                var k = 1
                while (!used.add(n)) { n = k.toString() + "_" + f.name; k++ }
                names[f.absolutePath] = "media/$n"
            }
            eachLayer(json) { l -> for (k in KEYS) { val v = l.optString(k, ""); names[v]?.let { r -> l.put(k, r) } } }
            val tmp = File(ctx.cacheDir, "$safe.zip")
            ZipOutputStream(FileOutputStream(tmp)).use { z ->
                z.putNextEntry(ZipEntry("project.saikipjf"))
                z.write(json.toString().toByteArray())
                z.closeEntry()
                for (f in media) {
                    z.putNextEntry(ZipEntry(names[f.absolutePath]!!))
                    f.inputStream().use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
            val loc = saveDownload(ctx, "$safe.zip", "application/zip", tmp.inputStream())
            tmp.delete()
            return loc
        }
        return saveDownload(ctx, "$safe.saikipjf", "application/octet-stream", json.toString().byteInputStream())
    }

    /** Accepts a .saikipjf or a zip. Returns the new project id. */
    fun import(ctx: Context, uri: Uri): String {
        val raw = BufferedInputStream(ctx.contentResolver.openInputStream(uri) ?: throw IOException("Could not open file"))
        raw.mark(4)
        val b0 = raw.read()
        val b1 = raw.read()
        raw.reset()
        var text: String? = null
        val map = HashMap<String, String>()
        if (b0 == 0x50 && b1 == 0x4B) {
            ZipInputStream(raw).use { z ->
                var e = z.nextEntry
                var n = 0
                while (e != null) {
                    val name = e.name
                    if (!e.isDirectory) {
                        if (name.endsWith(".saikipjf")) text = z.readBytes().toString(Charsets.UTF_8)
                        else {
                            n++
                            val f = File(Projects.mediaDir(ctx), System.currentTimeMillis().toString() + "_" + n + "_" + File(name).name)
                            FileOutputStream(f).use { o -> z.copyTo(o) }
                            map[name] = f.absolutePath
                        }
                    }
                    z.closeEntry()
                    e = z.nextEntry
                }
            }
        } else {
            text = raw.readBytes().toString(Charsets.UTF_8)
            raw.close()
        }
        val json = JSONObject(text ?: throw IOException("No project found in this file"))
        eachLayer(json) { l -> for (k in KEYS) { val v = l.optString(k, ""); map[v]?.let { r -> l.put(k, r) } } }
        val p = Store.fromJson(json)
        val id = "p" + System.currentTimeMillis()
        Projects.save(ctx, id, p)
        return id
    }
}
