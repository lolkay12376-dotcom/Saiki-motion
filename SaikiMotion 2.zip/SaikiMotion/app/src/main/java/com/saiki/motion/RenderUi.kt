package com.saiki.motion

import android.app.Activity
import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

/** Render settings dialog and the full-screen render overlay with the looping animation. */
object RenderUi {
    class Settings { var scale = 1f; var mbps = 0; var fps = 0 }

    fun autoMbps(w: Int, h: Int, fps: Int): Int = ((w.toLong() * h * fps / 9L) / 1_000_000L).toInt().coerceIn(2, 100)

    fun settings(a: Activity, p: Project, onStart: (Settings) -> Unit) {
        val s = Settings()
        val d = a.resources.displayMetrics.density
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding((4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt(), (4 * d).toInt())
        val scales = floatArrayOf(1f, 0.75f, 0.5f)
        val rates = intArrayOf(0, 8, 16, 32, 64)
        val fpsList = intArrayOf(0, 24, 30, 60)
        var qi = 0
        var bi = 0
        var fi = 0
        fun line(t: String, color: Int, size: Float, bold: Boolean = false) {
            val tv = TextView(a)
            tv.text = t; tv.setTextColor(color); tv.textSize = size
            if (bold) tv.typeface = Typeface.DEFAULT_BOLD
            tv.setPadding((6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt(), (2 * d).toInt())
            box.addView(tv)
        }
        fun build() {
            box.removeAllViews()
            s.scale = scales[qi]; s.mbps = rates[bi]; s.fps = fpsList[fi]
            val w = (p.w * s.scale / 2f).toInt() * 2
            val h = (p.h * s.scale / 2f).toInt() * 2
            val fps = if (s.fps > 0) s.fps else p.fps
            var dur = 0f
            for (sc in p.scenes) dur += sc.duration
            val mbps = if (s.mbps > 0) s.mbps else autoMbps(w, h, fps)
            line("Output", C.GREEN, 13f, true)
            line("$w x $h  ·  $fps fps  ·  " + String.format("%.1f", dur) + " s", C.TEXT, 16f)
            line("$mbps Mbps  ·  about " + String.format("%.0f", mbps * dur / 8f) + " MB", C.DIM, 13f)
            line("Quality", C.GREEN, 13f, true)
            box.addView(chipRow(a, listOf("Full size", "3/4 size", "1/2 size"), qi) { qi = it; build() })
            line("Bit rate", C.GREEN, 13f, true)
            box.addView(chipRow(a, listOf("Auto", "8 Mbps", "16 Mbps", "32 Mbps", "64 Mbps"), bi) { bi = it; build() })
            line("Frame rate", C.GREEN, 13f, true)
            box.addView(chipRow(a, listOf("Project (" + p.fps + ")", "24", "30", "60"), fi) { fi = it; build() })
        }
        build()
        Dlg(a).setTitle("Render settings").setView(box).setPositiveButton("Render") { _, _ -> onStart(s) }.setNegativeButton("Cancel", null).show()
    }

    fun show(a: Activity, p: Project, s: Settings) {
        val d = a.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val dlg = Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dlg.setCancelable(false)
        val root = FrameLayout(a)
        root.setBackgroundColor(0xFF000000.toInt())
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(dp(32), dp(32), dp(32), dp(32))
        val img = ImageView(a)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        col.addView(img, LinearLayout.LayoutParams(dp(260), dp(260)))
        val title = TextView(a)
        title.text = "Rendering"; title.setTextColor(0xFFFFFFFF.toInt()); title.textSize = 26f; title.typeface = Typeface.DEFAULT_BOLD; title.gravity = Gravity.CENTER
        title.setPadding(0, dp(12), 0, dp(4))
        col.addView(title)
        val status = TextView(a)
        status.text = "Starting..."; status.setTextColor(C.DIM); status.textSize = 15f; status.gravity = Gravity.CENTER
        status.setPadding(0, 0, 0, dp(16))
        col.addView(status)
        val bar = ProgressBarView(a)
        col.addView(bar, LinearLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT))
        val actions = LinearLayout(a)
        actions.orientation = LinearLayout.VERTICAL
        actions.gravity = Gravity.CENTER_HORIZONTAL
        actions.setPadding(0, dp(24), 0, 0)
        col.addView(actions, LinearLayout.LayoutParams(dp(280), ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        dlg.setContentView(root)

        val frames = ArrayList<Bitmap>()
        var i = 0
        while (i < 64) {
            val rid = a.resources.getIdentifier("render_f$i", "drawable", a.packageName)
            if (rid == 0) break
            frames.add(BitmapFactory.decodeResource(a.resources, rid))
            i++
        }
        val handler = Handler(Looper.getMainLooper())
        var fi = 0
        val tick = object : Runnable {
            override fun run() {
                if (frames.isNotEmpty()) { img.setImageBitmap(frames[fi % frames.size]); fi++ }
                handler.postDelayed(this, 140)
            }
        }
        handler.post(tick)

        fun addButton(text: String, fill: Int, tc: Int, click: () -> Unit): PillButton {
            val b = PillButton(a, text, null, fill, tc)
            b.onClick = click
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50))
            lp.setMargins(0, dp(4), 0, dp(4))
            actions.addView(b, lp)
            return b
        }

        var ref: Exporter? = null
        addButton("Cancel", C.CARD2, C.TEXT) { ref?.cancel(); status.text = "Cancelling..." }
        val ex = Exporter(a.applicationContext, p,
            { pct -> a.runOnUiThread { bar.progress = pct / 100f; status.text = "Rendering " + pct + "%  ·  keep the app open" } },
            { path, err ->
                a.runOnUiThread {
                    handler.removeCallbacks(tick)
                    actions.removeAllViews()
                    bar.visibility = View.GONE
                    if (err != null) {
                        if (err == "Cancelled") { dlg.dismiss(); return@runOnUiThread }
                        title.text = "Render failed"; status.text = err
                        addButton("Close", C.GREEN, 0xFF2B1400.toInt()) { dlg.dismiss() }
                    } else {
                        val f = File(path ?: "")
                        title.text = "Render complete"
                        status.text = String.format("%.1f MB", f.length() / 1048576f)
                        var saveBtn: PillButton? = null
                        saveBtn = addButton("Save to Photos", C.GREEN, 0xFF2B1400.toInt()) {
                            status.text = "Saving..."
                            Thread {
                                try {
                                    Exporter.saveToMovies(a, f)
                                    f.delete()
                                    a.runOnUiThread { status.text = "Saved to Photos"; actions.removeView(saveBtn) }
                                } catch (e: Exception) {
                                    a.runOnUiThread { status.text = "Could not save the video" }
                                }
                            }.start()
                        }
                        addButton("Close", C.CARD2, C.TEXT) { dlg.dismiss() }
                    }
                }
            }, s.scale, s.mbps, s.fps, false)
        ref = ex
        dlg.show()
        ex.start()
    }
}
