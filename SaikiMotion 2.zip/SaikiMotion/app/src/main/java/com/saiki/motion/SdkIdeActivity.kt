package com.saiki.motion

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.Spannable
import android.text.TextWatcher
import android.text.method.KeyListener
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Colors the code with a span class of its own so old colors can be cleared without touching anything else. */
private class SyntaxSpan(color: Int) : ForegroundColorSpan(color)

/** A plain EditText that shows line numbers, highlights the current line and never wraps. */
class CodeEditor(ctx: Context) : EditText(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val numP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gutterP = Paint()
    private val sepP = Paint()
    private val curP = Paint()
    private var baseKeys: KeyListener? = null
    private val gutterW = (48f * d).toInt()

    init {
        typeface = Typeface.MONOSPACE
        textSize = 13f
        setTextColor(0xFFE6E6EA.toInt())
        setBackgroundColor(0xFF111114.toInt())
        gravity = Gravity.TOP or Gravity.START
        setHorizontallyScrolling(true)
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI
        isVerticalScrollBarEnabled = true
        setPadding(gutterW + (8f * d).toInt(), (6f * d).toInt(), (24f * d).toInt(), (40f * d).toInt())
        highlightColor = 0x55FF8A1F
        numP.color = 0xFF6B6B76.toInt()
        numP.textSize = 12f * d
        numP.typeface = Typeface.MONOSPACE
        numP.textAlign = Paint.Align.RIGHT
        numP.isAntiAlias = true
        gutterP.color = 0xFF16161A.toInt()
        sepP.color = C.LINE
        curP.color = 0xFF1C1C21.toInt()
        baseKeys = keyListener
    }

    fun setReadOnly(ro: Boolean) {
        if (ro) keyListener = null else if (baseKeys != null) keyListener = baseKeys
    }

    override fun onDraw(c: Canvas) {
        val l = layout
        if (l == null) { super.onDraw(c); return }
        val pt = extendedPaddingTop.toFloat()
        val sel = selectionStart
        if (sel >= 0 && isFocused) {
            val ln = l.getLineForOffset(sel)
            c.drawRect(scrollX.toFloat(), l.getLineTop(ln) + pt, (scrollX + width).toFloat(), l.getLineBottom(ln) + pt, curP)
        }
        super.onDraw(c)
        c.drawRect(scrollX.toFloat(), scrollY.toFloat(), (scrollX + gutterW).toFloat(), (scrollY + height).toFloat(), gutterP)
        c.drawLine((scrollX + gutterW).toFloat(), scrollY.toFloat(), (scrollX + gutterW).toFloat(), (scrollY + height).toFloat(), sepP)
        val first = l.getLineForVertical(scrollY)
        val last = l.getLineForVertical(scrollY + height)
        for (i in first..last) {
            c.drawText((i + 1).toString(), (scrollX + gutterW - 8f * d), l.getLineBaseline(i) + pt, numP)
        }
    }

    /** Character offset of the start of a 1-based line, or -1. */
    fun offsetOfLine(line: Int): Int {
        val t = text.toString()
        if (line < 1) return -1
        var off = 0
        var n = 1
        while (n < line) {
            val nl = t.indexOf('\n', off)
            if (nl < 0) return -1
            off = nl + 1
            n++
        }
        return off
    }
}

class SdkIdeActivity : Activity() {

    private class Node(val name: String, val path: String, val isDir: Boolean)
    private class Problem(val line: Int?, val text: String)

    private class OpenFile(var path: String, val readOnly: Boolean) {
        var text = ""
        var saved = ""
        val undo = ArrayList<String>()
        val redo = ArrayList<String>()
        val dirty: Boolean get() = !readOnly && text != saved
        val name: String get() = path.substringAfterLast('/')
    }

    private val handler = Handler(Looper.getMainLooper())
    private val dens by lazy { resources.displayMetrics.density }
    private fun dp(v: Int) = (v * dens).toInt()
    private val root by lazy { Registry.sdkRoot(this) }

    private val expanded = HashSet<String>()
    private var selectedPath: String? = null
    private val openFiles = ArrayList<OpenFile>()
    private var cur: OpenFile? = null
    private var loading = false
    private var pendingIndent = -1
    private var changed = false
    private var wide = false
    private var previewOpen = true
    private var keyboardUp = false

    private lateinit var treeBox: LinearLayout
    private lateinit var explorerBox: LinearLayout
    private lateinit var tabsRow: LinearLayout
    private lateinit var editor: CodeEditor
    private lateinit var banner: TextView
    private lateinit var titleView: TextView
    private lateinit var previewPane: LinearLayout
    private lateinit var problemsBox: LinearLayout
    private lateinit var card: EffectCard
    private lateinit var drawer: View
    private lateinit var scrim: View
    private lateinit var rootFrame: FrameLayout
    private var pv: PreviewView? = null
    private var problems: List<Problem> = emptyList()

    private val R_PICK_IMAGE = 71

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(C.BG))
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG
        Registry.init(this)
        val newFx = intent.getBooleanExtra("new", false)
        val openPath = intent.getStringExtra("open")
        buildUi()
        if (newFx) {
            val f = Registry.newEffectFolder(this, "My Effect")
            changed = true
            Registry.reloadSdk(this)
            expanded.add(f.absolutePath)
            selectedPath = f.absolutePath
            openFile(File(f, "effect.glsl").absolutePath)
        } else if (openPath != null && isAsset(openPath)) {
            var a = openPath.removePrefix("asset:")
            while (a.isNotEmpty()) { expanded.add("asset:$a"); a = a.substringBeforeLast('/', "") }
            selectedPath = openPath
            openFile("$openPath/effect.glsl")
        } else if (openPath != null) {
            val f = File(openPath)
            if (f.exists()) {
                expanded.add(f.absolutePath)
                selectedPath = f.absolutePath
                openFile(File(f, "effect.glsl").absolutePath)
            }
        } else {
            expanded.add(root.absolutePath)
            rebuildTree()
        }
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        saveAll()
        buildUi()
    }

    override fun onResume() { super.onResume(); pv?.onResume() }

    override fun onPause() {
        super.onPause()
        pv?.onPause()
        saveAll()
        if (changed) { Registry.reloadSdk(this); setResult(RESULT_OK) }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!wide && drawer.visibility == View.VISIBLE) { closeDrawer(); return }
        saveAll()
        if (changed) { Registry.reloadSdk(this); setResult(RESULT_OK) }
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    // ------------------------------------------------------------------ layout

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun lpw(w: Int, h: Int, weight: Float) = LinearLayout.LayoutParams(w, h, weight)

    private fun buildUi() {
        wide = resources.configuration.screenWidthDp >= 720
        rootFrame = FrameLayout(this)
        rootFrame.setBackgroundColor(C.BG)
        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        main.addView(buildTopBar(), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL
        explorerBox = buildExplorer()
        if (wide) body.addView(explorerBox, lp(dp(270), ViewGroup.LayoutParams.MATCH_PARENT))
        body.addView(buildEditorColumn(), lpw(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        main.addView(body, lpw(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        rootFrame.addView(main, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        scrim = View(this)
        scrim.setBackgroundColor(0x99000000.toInt())
        scrim.visibility = View.GONE
        scrim.setOnClickListener { closeDrawer() }
        drawer = explorerBox
        if (!wide) {
            rootFrame.addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val dl = FrameLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.MATCH_PARENT)
            dl.gravity = Gravity.START
            explorerBox.visibility = View.GONE
            rootFrame.addView(explorerBox, dl)
        }
        var view = pv
        if (view == null) { view = PreviewView(this); pv = view }
        (view.parent as? ViewGroup)?.removeView(view)
        rootFrame.addView(view, FrameLayout.LayoutParams(dp(2), dp(2), Gravity.BOTTOM or Gravity.END))
        rootFrame.viewTreeObserver.addOnGlobalLayoutListener {
            val r = android.graphics.Rect()
            rootFrame.getWindowVisibleDisplayFrame(r)
            val up = rootFrame.rootView.height - r.bottom > dp(150)
            if (up != keyboardUp) { keyboardUp = up; applyPreviewVisibility() }
        }
        setContentView(rootFrame)
        rebuildTree()
        rebuildTabs()
        loadCurrentIntoEditor()
        showProblems()
    }

    private fun buildTopBar(): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(C.PANEL)
        bar.setPadding(dp(4), 0, dp(8), 0)
        val back = IconView(this, "back", C.TEXT, 22f)
        back.onClick = { onBackPressed() }
        bar.addView(back, lp(dp(44), dp(48)))
        if (!wide) {
            val fi = IconView(this, "folder", C.TEXT, 22f)
            fi.onClick = { openDrawer() }
            bar.addView(fi, lp(dp(44), dp(48)))
        }
        titleView = TextView(this)
        titleView.setTextColor(C.TEXT)
        titleView.textSize = 14f
        titleView.typeface = Typeface.DEFAULT_BOLD
        titleView.maxLines = 1
        titleView.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        titleView.setPadding(dp(6), 0, dp(6), 0)
        bar.addView(titleView, lpw(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val un = IconView(this, "undo", C.TEXT, 20f)
        un.onClick = { undo() }
        bar.addView(un, lp(dp(40), dp(48)))
        val re = IconView(this, "redo", C.TEXT, 20f)
        re.onClick = { redo() }
        bar.addView(re, lp(dp(40), dp(48)))
        val sv = IconView(this, "save", C.TEXT, 20f)
        sv.onClick = { saveAll(); toast("Saved") }
        bar.addView(sv, lp(dp(40), dp(48)))
        val run = PillButton(this, "Run", "play", C.GREEN, 0xFF2B1400.toInt())
        run.onClick = { run() }
        bar.addView(run, lp(dp(84), dp(38)))
        val more = IconView(this, "more", C.TEXT, 22f)
        more.onClick = { showMenu() }
        bar.addView(more, lp(dp(40), dp(48)))
        return bar
    }

    private fun buildExplorer(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(C.PANEL)
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(4), 0, dp(4), 0)
        val t = TextView(this)
        t.text = "EXPLORER"
        t.setTextColor(C.DIM)
        t.textSize = 11f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(dp(8), 0, 0, 0)
        head.addView(t, lpw(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fun tool(icon: String, tint: Int, click: () -> Unit) {
            val v = IconView(this, icon, tint, 20f)
            v.onClick = click
            head.addView(v, lp(dp(38), dp(44)))
        }
        tool("sparkle", C.GREEN) { newEffect() }
        tool("file_plus", C.TEXT) { newFile() }
        tool("folder_plus", C.TEXT) { newFolder() }
        tool("edit", C.TEXT) { renameSelected() }
        tool("trash", C.RED) { deleteSelected() }
        box.addView(head, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
        val sv = ScrollView(this)
        treeBox = LinearLayout(this)
        treeBox.orientation = LinearLayout.VERTICAL
        sv.addView(treeBox)
        box.addView(sv, lpw(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return box
    }

    private fun buildEditorColumn(): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.setBackgroundColor(C.PANEL)
        tabsRow = LinearLayout(this)
        tabsRow.orientation = LinearLayout.HORIZONTAL
        hs.addView(tabsRow)
        col.addView(hs, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        banner = TextView(this)
        banner.setTextColor(C.AMBER)
        banner.textSize = 12f
        banner.setBackgroundColor(0xFF2A2412.toInt())
        banner.setPadding(dp(12), dp(6), dp(12), dp(6))
        banner.text = "Read-only. Long-press this effect in the explorer and choose Duplicate to my effects to edit a copy."
        banner.visibility = View.GONE
        col.addView(banner, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        editor = CodeEditor(this)
        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) {
                pendingIndent = if (!loading && s != null && count == 1 && before == 0 && st < s.length && s[st] == '\n') st + 1 else -1
            }
            override fun afterTextChanged(e: Editable?) {
                if (e == null || loading) return
                if (pendingIndent >= 0) { val at = pendingIndent; pendingIndent = -1; insertIndent(e, at) }
                val f = cur ?: return
                f.text = e.toString()
                scheduleHighlight()
                scheduleHistory()
                rebuildTabs()
            }
        })
        col.addView(editor, lpw(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        col.addView(buildSymbolBar(), lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        previewPane = buildPreviewPane()
        col.addView(previewPane, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(200)))
        applyPreviewVisibility()
        return col
    }

    private fun buildSymbolBar(): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.setBackgroundColor(C.PANEL)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        hs.addView(row)
        fun key(label: String, text: String, back: Int = 0) {
            val t = TextView(this)
            t.text = label
            t.setTextColor(C.TEXT)
            t.textSize = 14f
            t.typeface = Typeface.MONOSPACE
            t.gravity = Gravity.CENTER
            val bg = GradientDrawable()
            bg.setColor(C.CARD2)
            bg.cornerRadius = dp(8).toFloat()
            t.background = bg
            t.setOnClickListener { insertText(text, back) }
            val l = lp(dp(if (label.length > 3) 58 else 40), dp(32))
            l.setMargins(dp(3), 0, dp(3), 0)
            row.addView(t, l)
        }
        key("Tab", "  ")
        key("{ }", "{  }", 2)
        key("( )", "()", 1)
        key("[ ]", "[]", 1)
        key(";", ";")
        key("=", " = ")
        key(".", ".")
        key(",", ", ")
        key("+", " + ")
        key("-", " - ")
        key("*", " * ")
        key("/", " / ")
        key("<", " < ")
        key(">", " > ")
        key("vec2", "vec2(", 0)
        key("vec3", "vec3(", 0)
        key("vec4", "vec4(", 0)
        key("float", "float ", 0)
        key("uv", "uv")
        key("src", "src(uv)")
        key("uTime", "uTime")
        return hs
    }

    private fun buildPreviewPane(): LinearLayout {
        val pane = LinearLayout(this)
        pane.orientation = LinearLayout.HORIZONTAL
        pane.setBackgroundColor(C.PANEL)
        pane.setPadding(dp(8), dp(8), dp(8), dp(8))
        card = EffectCard(this, "Preview", "Press Run")
        card.thumbHeight = 0.95f
        pane.addView(card, lp(dp(140), ViewGroup.LayoutParams.MATCH_PARENT))
        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        val h = TextView(this)
        h.text = "PROBLEMS"
        h.setTextColor(C.DIM)
        h.textSize = 11f
        h.typeface = Typeface.DEFAULT_BOLD
        h.setPadding(dp(10), 0, 0, dp(4))
        right.addView(h)
        val sv = ScrollView(this)
        problemsBox = LinearLayout(this)
        problemsBox.orientation = LinearLayout.VERTICAL
        sv.addView(problemsBox)
        right.addView(sv, lpw(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        pane.addView(right, lpw(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        return pane
    }

    private fun applyPreviewVisibility() {
        if (!::previewPane.isInitialized) return
        previewPane.visibility = if (previewOpen && !keyboardUp) View.VISIBLE else View.GONE
    }

    private fun toast(s: String) = Snack.show(this, s)

    // ------------------------------------------------------------------ explorer

    private fun isAsset(p: String) = p.startsWith("asset:")

    private fun children(path: String): List<Node> {
        val out: List<Node>
        if (isAsset(path)) {
            val ap = path.removePrefix("asset:")
            val names = try { assets.list(ap) } catch (e: Exception) { null } ?: return emptyList()
            out = names.map { n ->
                val full = "$ap/$n"
                val dir = (try { assets.list(full) } catch (e: Exception) { null })?.isNotEmpty() == true
                Node(n, "asset:$full", dir)
            }
        } else {
            val fs = File(path).listFiles() ?: return emptyList()
            out = fs.map { Node(it.name, it.absolutePath, it.isDirectory) }
        }
        return out.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
    }

    private fun isEffectFolder(path: String): Boolean {
        if (isAsset(path)) return (try { assets.list(path.removePrefix("asset:")) } catch (e: Exception) { null })?.contains("effect.json") == true
        return File(path, "effect.json").exists()
    }

    private fun rebuildTree() {
        if (!::treeBox.isInitialized) return
        treeBox.removeAllViews()
        treeBox.addView(section("MY EFFECTS"))
        val mine = children(root.absolutePath)
        if (mine.isEmpty()) {
            val t = TextView(this)
            t.text = "Nothing here yet. Tap the sparkle icon to make your first effect."
            t.setTextColor(C.DIM)
            t.textSize = 12f
            t.setPadding(dp(14), dp(6), dp(14), dp(10))
            treeBox.addView(t)
        }
        addChildren(root.absolutePath, 0)
        treeBox.addView(section("BUNDLED (READ-ONLY)"))
        addChildren("asset:sdk", 0)
    }

    private fun section(label: String): View {
        val t = TextView(this)
        t.text = label
        t.setTextColor(C.DIM)
        t.textSize = 11f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(dp(12), dp(12), dp(12), dp(4))
        return t
    }

    private fun addChildren(path: String, depth: Int) {
        for (n in children(path)) {
            val eff = n.isDir && isEffectFolder(n.path)
            val isOpen = expanded.contains(n.path)
            val failed = n.isDir && !isAsset(n.path) && Registry.sdkErrors.containsKey(n.name)
            val icon = if (eff) "sparkle" else if (n.isDir) (if (isOpen) "folder_open" else "folder") else "file"
            val tint = if (failed) C.RED else if (eff) C.GREEN else if (n.isDir) C.AMBER else C.DIM
            treeBox.addView(treeRow(depth, icon, tint, n))
            if (n.isDir && isOpen) addChildren(n.path, depth + 1)
        }
    }

    private fun treeRow(depth: Int, icon: String, tint: Int, n: Node): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(8 + depth * 14), 0, dp(8), 0)
        if (n.path == selectedPath) r.setBackgroundColor(0xFF2A2A30.toInt())
        val iv = IconView(this, icon, tint, 18f)
        iv.isClickable = false
        iv.isLongClickable = false
        r.addView(iv, lp(dp(28), dp(38)))
        val t = TextView(this)
        t.text = n.name
        t.setTextColor(C.TEXT)
        t.textSize = 14f
        t.maxLines = 1
        t.ellipsize = android.text.TextUtils.TruncateAt.END
        r.addView(t, lpw(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.setOnClickListener { onNodeTap(n) }
        r.setOnLongClickListener { onNodeLong(n); true }
        return r
    }

    private fun onNodeTap(n: Node) {
        selectedPath = n.path
        if (n.isDir) {
            if (!expanded.remove(n.path)) expanded.add(n.path)
            rebuildTree()
        } else {
            openFile(n.path)
            if (!wide) closeDrawer()
        }
    }

    private fun onNodeLong(n: Node) {
        selectedPath = n.path
        rebuildTree()
        val eff = n.isDir && isEffectFolder(n.path)
        if (isAsset(n.path)) {
            if (eff) Dlg(this).setTitle(n.name).setIconItems(arrayOf("Duplicate to my effects"), arrayOf("dup")) { _, _ -> duplicateEffect(n.path) }.show()
            else toast("Bundled files are read-only")
            return
        }
        val labels = ArrayList<String>()
        val icons = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (n.isDir) {
            labels.add("New effect here"); icons.add("sparkle"); acts.add { newEffect() }
            labels.add("New file here"); icons.add("file_plus"); acts.add { newFile() }
            labels.add("New folder here"); icons.add("folder_plus"); acts.add { newFolder() }
        }
        if (eff) { labels.add("Duplicate"); icons.add("dup"); acts.add { duplicateEffect(n.path) } }
        labels.add("Rename"); icons.add("edit"); acts.add { renameSelected() }
        labels.add("Delete"); icons.add("trash"); acts.add { deleteSelected() }
        Dlg(this).setTitle(n.name).setIconItems(labels.toTypedArray(), icons.toTypedArray()) { _, w -> acts[w]() }.show()
    }

    private fun openDrawer() { scrim.visibility = View.VISIBLE; explorerBox.visibility = View.VISIBLE }
    private fun closeDrawer() { if (!wide) { scrim.visibility = View.GONE; explorerBox.visibility = View.GONE } }

    private fun targetDir(): File {
        val sp = selectedPath
        if (sp != null && !isAsset(sp)) {
            val f = File(sp)
            return if (f.isDirectory) f else (f.parentFile ?: root)
        }
        return root
    }

    private fun prompt(title: String, hint: String, init: String, ok: String, cb: (String) -> Unit) {
        val et = EditText(this)
        et.hint = hint
        et.setText(init)
        et.setSingleLine(true)
        et.setSelection(et.text.length)
        Dlg(this).setTitle(title).setView(et).setPositiveButton(ok) { _, _ -> cb(et.text.toString().trim()) }.setNegativeButton("Cancel", null).show()
    }

    private fun validName(n: String): Boolean = n.isNotEmpty() && !n.contains('/') && !n.contains('\\') && n != "." && n != ".."

    private fun newEffect() {
        val dir = targetDir()
        prompt("New effect", "Effect name", "My Effect", "Create") { name ->
            if (name.isEmpty()) return@prompt
            val f = Registry.newEffectFolder(this, name, dir)
            changed = true
            Registry.reloadSdk(this)
            expanded.add(dir.absolutePath)
            expanded.add(f.absolutePath)
            selectedPath = f.absolutePath
            openFile(File(f, "effect.glsl").absolutePath)
        }
    }

    private fun newFile() {
        val dir = targetDir()
        prompt("New file", "File name, for example notes.txt", "", "Create") { name ->
            if (!validName(name)) { toast("Use a simple file name"); return@prompt }
            val f = File(dir, name)
            if (f.exists()) { toast("That name is taken"); return@prompt }
            try { f.writeText("") } catch (e: Exception) { toast("Could not create the file"); return@prompt }
            changed = true
            expanded.add(dir.absolutePath)
            selectedPath = f.absolutePath
            openFile(f.absolutePath)
        }
    }

    private fun newFolder() {
        val dir = targetDir()
        prompt("New folder", "Folder name", "", "Create") { name ->
            if (!validName(name)) { toast("Use a simple folder name"); return@prompt }
            val f = File(dir, name)
            if (f.exists()) { toast("That name is taken"); return@prompt }
            f.mkdirs()
            changed = true
            expanded.add(dir.absolutePath)
            expanded.add(f.absolutePath)
            selectedPath = f.absolutePath
            rebuildTree()
        }
    }

    private fun renameSelected() {
        val sp = selectedPath
        if (sp == null) { toast("Select a file or folder first"); return }
        if (isAsset(sp)) { toast("Bundled files are read-only"); return }
        val f = File(sp)
        if (f == root) { toast("The root folder cannot be renamed"); return }
        prompt("Rename", "New name", f.name, "Rename") { name ->
            if (!validName(name)) { toast("Use a simple name"); return@prompt }
            val nf = File(f.parentFile, name)
            if (nf.exists() && nf != f) { toast("That name is taken"); return@prompt }
            saveAll()
            if (!f.renameTo(nf)) { toast("Rename failed"); return@prompt }
            val oldP = f.absolutePath
            val newP = nf.absolutePath
            for (o in openFiles) if (o.path == oldP || o.path.startsWith("$oldP/")) o.path = newP + o.path.substring(oldP.length)
            val ex = expanded.map { if (it == oldP || it.startsWith("$oldP/")) newP + it.substring(oldP.length) else it }
            expanded.clear(); expanded.addAll(ex)
            selectedPath = newP
            changed = true
            rebuildTree(); rebuildTabs(); updateTitle()
        }
    }

    private fun deleteSelected() {
        val sp = selectedPath
        if (sp == null) { toast("Select a file or folder first"); return }
        if (isAsset(sp)) { toast("Bundled files are read-only"); return }
        val f = File(sp)
        if (f == root) { toast("The root folder cannot be deleted"); return }
        Dlg(this).setTitle("Delete " + f.name + "?").setMessage(if (f.isDirectory) "The folder and everything inside it will be deleted." else "The file will be deleted.")
            .setPositiveButton("Delete") { _, _ ->
                val p = f.absolutePath
                f.deleteRecursively()
                openFiles.removeAll { it.path == p || it.path.startsWith("$p/") }
                if (cur != null && !openFiles.contains(cur)) cur = openFiles.lastOrNull()
                expanded.remove(p)
                selectedPath = f.parentFile?.absolutePath
                changed = true
                rebuildTree(); rebuildTabs(); loadCurrentIntoEditor()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun duplicateEffect(path: String) {
        try {
            val srcName = path.substringAfterLast('/')
            var dest = File(root, srcName + "_copy")
            var n = 2
            while (dest.exists()) dest = File(root, srcName + "_copy" + n++)
            dest.mkdirs()
            copyTree(path, dest)
            val mf = File(dest, "effect.json")
            if (mf.exists()) {
                val o = JSONObject(mf.readText())
                var id = o.optString("id", dest.name) + "_copy"
                var k = 2
                while (Registry.byId.containsKey(id)) id = o.optString("id", dest.name) + "_copy" + k++
                o.put("id", id)
                o.put("name", o.optString("name", dest.name) + " Copy")
                mf.writeText(o.toString(2))
            }
            changed = true
            Registry.reloadSdk(this)
            expanded.add(root.absolutePath)
            expanded.add(dest.absolutePath)
            selectedPath = dest.absolutePath
            rebuildTree()
            openFile(File(dest, "effect.glsl").absolutePath)
            toast("Copied to My effects")
        } catch (e: Exception) { toast("Copy failed") }
    }

    private fun copyTree(src: String, dest: File) {
        if (isAsset(src)) {
            val ap = src.removePrefix("asset:")
            val names = assets.list(ap) ?: return
            for (n in names) {
                val full = "$ap/$n"
                val sub = assets.list(full)
                if (sub != null && sub.isNotEmpty()) { val d = File(dest, n); d.mkdirs(); copyTree("asset:$full", d) }
                else assets.open(full).use { i -> File(dest, n).outputStream().use { o -> i.copyTo(o) } }
            }
        } else {
            File(src).copyRecursively(dest, true)
        }
    }

    // ------------------------------------------------------------------ files + tabs

    private val textExt = setOf("json", "glsl", "frag", "vert", "fsh", "txt", "md", "xml", "js", "csv", "")

    private fun readFile(path: String): String =
        if (isAsset(path)) assets.open(path.removePrefix("asset:")).bufferedReader().use { it.readText() } else File(path).readText()

    private fun openFile(path: String) {
        val ext = path.substringAfterLast('/').substringAfterLast('.', "").lowercase()
        if (ext !in textExt) { toast("Only text files can be edited here"); rebuildTree(); return }
        var f = openFiles.firstOrNull { it.path == path }
        if (f == null) {
            val text = try { readFile(path) } catch (e: Exception) { toast("Could not open the file"); return }
            f = OpenFile(path, isAsset(path))
            f.text = text
            f.saved = text
            f.undo.add(text)
            openFiles.add(f)
        }
        cur = f
        selectedPath = path
        rebuildTree(); rebuildTabs(); loadCurrentIntoEditor()
    }

    private fun rebuildTabs() {
        if (!::tabsRow.isInitialized) return
        tabsRow.removeAllViews()
        for (f in openFiles) {
            val tab = LinearLayout(this)
            tab.orientation = LinearLayout.HORIZONTAL
            tab.gravity = Gravity.CENTER_VERTICAL
            tab.setPadding(dp(12), 0, dp(4), 0)
            tab.setBackgroundColor(if (f === cur) 0xFF111114.toInt() else C.PANEL)
            val t = TextView(this)
            t.text = f.name + (if (f.dirty) "  *" else "")
            t.setTextColor(if (f === cur) C.TEXT else C.DIM)
            t.textSize = 13f
            tab.addView(t)
            val x = IconView(this, "close", C.DIM, 14f)
            x.onClick = { closeTab(f) }
            tab.addView(x, lp(dp(32), dp(40)))
            tab.setOnClickListener { saveCurrentText(); cur = f; selectedPath = f.path; rebuildTabs(); rebuildTree(); loadCurrentIntoEditor() }
            tabsRow.addView(tab, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
    }

    private fun saveCurrentText() { cur?.let { f -> if (!loading) f.text = editor.text.toString() } }

    private fun closeTab(f: OpenFile) {
        if (f.dirty) writeFile(f)
        val i = openFiles.indexOf(f)
        openFiles.remove(f)
        if (cur === f) cur = openFiles.getOrNull(minOf(i, openFiles.size - 1))
        rebuildTabs(); loadCurrentIntoEditor()
    }

    private fun writeFile(f: OpenFile) {
        if (f.readOnly) return
        try { File(f.path).writeText(f.text); f.saved = f.text; changed = true } catch (e: Exception) { toast("Could not save " + f.name) }
    }

    private fun saveAll() {
        saveCurrentText()
        for (f in openFiles) if (f.dirty) writeFile(f)
        rebuildTabs()
    }

    private fun updateTitle() {
        if (!::titleView.isInitialized) return
        val f = cur
        titleView.text = if (f == null) "Effect Editor" else f.path.removePrefix("asset:").let { p ->
            val parts = p.split('/')
            if (parts.size >= 2) parts[parts.size - 2] + " / " + parts.last() else parts.last()
        }
    }

    private fun loadCurrentIntoEditor() {
        val f = cur
        loading = true
        if (f == null) {
            editor.setText("")
            editor.hint = "Open a file from the explorer, or tap the sparkle icon to create an effect."
            editor.setReadOnly(true)
            banner.visibility = View.GONE
        } else {
            editor.setReadOnly(f.readOnly)
            editor.setText(f.text)
            editor.setSelection(0)
            banner.visibility = if (f.readOnly) View.VISIBLE else View.GONE
        }
        loading = false
        highlight()
        updateTitle()
    }

    // ------------------------------------------------------------------ editing helpers

    private fun insertText(text: String, back: Int) {
        val f = cur ?: return
        if (f.readOnly) return
        val s = editor.selectionStart.coerceAtLeast(0)
        val e = editor.selectionEnd.coerceAtLeast(s)
        editor.text.replace(s, e, text)
        editor.setSelection((s + text.length - back).coerceAtLeast(0))
        editor.requestFocus()
    }

    private fun insertIndent(e: Editable, at: Int) {
        val lineStart = e.lastIndexOf('\n', at - 2) + 1
        val prev = e.subSequence(lineStart, maxOf(lineStart, at - 1)).toString()
        var indent = prev.takeWhile { it == ' ' || it == '\t' }
        if (prev.trimEnd().endsWith("{")) indent += "  "
        if (indent.isEmpty()) return
        loading = true
        e.insert(at, indent)
        loading = false
        editor.setSelection(at + indent.length)
    }

    private val histRun = Runnable {
        val f = cur
        if (f != null && (f.undo.isEmpty() || f.undo[f.undo.size - 1] != f.text)) {
            f.undo.add(f.text)
            if (f.undo.size > 100) f.undo.removeAt(0)
            f.redo.clear()
        }
    }
    private fun scheduleHistory() { handler.removeCallbacks(histRun); handler.postDelayed(histRun, 500) }

    private fun undo() {
        val f = cur ?: return
        if (f.readOnly) return
        handler.removeCallbacks(histRun); histRun.run()
        if (f.undo.size <= 1) return
        f.redo.add(f.undo.removeAt(f.undo.size - 1))
        restore(f, f.undo[f.undo.size - 1])
    }

    private fun redo() {
        val f = cur ?: return
        if (f.readOnly || f.redo.isEmpty()) return
        val t = f.redo.removeAt(f.redo.size - 1)
        f.undo.add(t)
        restore(f, t)
    }

    private fun restore(f: OpenFile, text: String) {
        val pos = editor.selectionStart
        loading = true
        editor.setText(text)
        loading = false
        f.text = text
        editor.setSelection(pos.coerceIn(0, text.length))
        highlight()
        rebuildTabs()
    }

    // ------------------------------------------------------------------ syntax colors

    private val hlRun = Runnable { highlight() }
    private fun scheduleHighlight() { handler.removeCallbacks(hlRun); handler.postDelayed(hlRun, 180) }

    private val rxGlslComment = Regex("//[^\\n]*|/\\*[\\s\\S]*?\\*/")
    private val rxNumber = Regex("\\b\\d+(\\.\\d+)?([eE][+-]?\\d+)?\\b")
    private val rxKeyword = Regex("\\b(float|int|bool|void|vec2|vec3|vec4|mat2|mat3|mat4|if|else|for|while|return|break|continue|discard|const|uniform|varying|in|out|inout|true|false|precision|highp|mediump|lowp|struct)\\b")
    private val rxBuiltin = Regex("\\b(sin|cos|tan|asin|acos|atan|pow|exp|log|sqrt|abs|sign|floor|ceil|fract|mod|min|max|clamp|mix|step|smoothstep|length|distance|dot|cross|normalize|reflect|texture2D|radians|degrees)\\b")
    private val rxSdk = Regex("\\b(effect|src|srcW|in0|in1|luma|hash11|hash21|vnoise|fbm|rot|hsv2rgb|unpremul|uTime|uRes|uHas0|uHas1)\\b")
    private val rxJsonString = Regex("\"(\\\\.|[^\"\\\\])*\"")
    private val rxJsonKey = Regex("\"(\\\\.|[^\"\\\\])*\"(?=\\s*:)")
    private val rxJsonLit = Regex("\\b(true|false|null)\\b")

    private fun paint(e: Editable, rx: Regex, color: Int, s: String) {
        for (m in rx.findAll(s)) e.setSpan(SyntaxSpan(color), m.range.first, m.range.last + 1, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun highlight() {
        if (!::editor.isInitialized) return
        val f = cur ?: return
        val e = editor.text
        for (sp in e.getSpans(0, e.length, SyntaxSpan::class.java)) e.removeSpan(sp)
        if (e.length > 60000) return
        val s = e.toString()
        val ext = f.name.substringAfterLast('.', "").lowercase()
        if (ext == "json") {
            paint(e, rxNumber, 0xFFF5B301.toInt(), s)
            paint(e, rxJsonLit, 0xFFFF79C6.toInt(), s)
            paint(e, rxJsonString, 0xFF9AE59A.toInt(), s)
            paint(e, rxJsonKey, 0xFF7DD3FC.toInt(), s)
        } else if (ext == "glsl" || ext == "frag" || ext == "vert" || ext == "fsh") {
            paint(e, rxNumber, 0xFFF5B301.toInt(), s)
            paint(e, rxKeyword, 0xFFFF79C6.toInt(), s)
            paint(e, rxBuiltin, 0xFF7DD3FC.toInt(), s)
            paint(e, rxSdk, 0xFFFF8A1F.toInt(), s)
            paint(e, rxGlslComment, 0xFF6B8E6B.toInt(), s)
        }
    }

    // ------------------------------------------------------------------ run, preview, problems

    /** Folder of the effect that the current file belongs to (nearest parent holding effect.json). */
    private fun effectFolderOf(path: String): String? {
        if (isAsset(path)) {
            var p = path.removePrefix("asset:").substringBeforeLast('/', "")
            while (p.isNotEmpty()) {
                if (isEffectFolder("asset:$p")) return "asset:$p"
                p = p.substringBeforeLast('/', "")
            }
            return null
        }
        var f: File? = File(path).parentFile
        if (File(path).isDirectory) f = File(path)
        while (f != null && f.absolutePath.startsWith(root.absolutePath)) {
            if (File(f, "effect.json").exists()) return f.absolutePath
            f = f.parentFile
        }
        return null
    }

    private fun effectIdOf(folder: String): String? = try {
        JSONObject(readFile("$folder/effect.json")).optString("id", "").ifBlank { null }
    } catch (e: Exception) { null }

    private fun run() {
        saveAll()
        Registry.reloadSdk(this)
        val f = cur
        val folder = if (f != null) effectFolderOf(f.path) else null
        val id = if (folder != null) effectIdOf(folder) else null
        EffectThumbs.cache.keys.removeAll { it == id || it.startsWith("__orig:custom:") }
        val def = if (id != null) Registry.byId[id] else null
        if (id == null) {
            problems = listOf(Problem(null, if (folder == null) "This file is not inside an effect folder (a folder with effect.json)." else "effect.json has no id."))
            showProblems(); return
        }
        if (def == null) {
            val msg = Registry.sdkErrors[File(folder!!).name] ?: Registry.sdkErrors[folder.removePrefix("asset:")] ?: "The effect could not be loaded."
            problems = listOf(Problem(null, "effect.json: $msg"))
            card.before = null; card.after = null
            showProblems(); return
        }
        card.name = def.name
        card.category = def.category
        card.anim = def.previewAnim
        card.before = null; card.after = null
        problems = emptyList()
        showProblems("Rendering...")
        val view = pv
        if (view == null) { showProblems(); return }
        EffectThumbs.generate(this, view) {
            val d2 = Registry.byId[id]
            card.before = EffectThumbs.cache[EffectThumbs.origKey(id)]
            card.after = EffectThumbs.cache[id]
            card.anim = d2?.previewAnim ?: "swipe"
            card.invalidate()
            val raw = Registry.errors[id]
            problems = if (raw != null && d2 != null) parseErrors(raw, d2) else emptyList()
            showProblems()
        }
        previewOpen = true
        applyPreviewVisibility()
    }

    private fun parseErrors(raw: String, d: EffectDef): List<Problem> {
        val off = Registry.codeLineOffset(d)
        val out = ArrayList<Problem>()
        val rxA = Regex("(\\d+):(\\d+):?\\s*(.*)")
        val rxB = Regex("\\((\\d+)\\)\\s*:\\s*(.*)")
        for (line in raw.lines()) {
            val t = line.trim()
            if (t.isEmpty()) continue
            val a = rxA.find(t)
            val b = rxB.find(t)
            if (a != null) {
                val ln = a.groupValues[2].toInt() - off
                out.add(Problem(if (ln >= 1) ln else null, a.groupValues[3].ifBlank { t }))
            } else if (b != null) {
                val ln = b.groupValues[1].toInt() - off
                out.add(Problem(if (ln >= 1) ln else null, b.groupValues[2]))
            } else out.add(Problem(null, t))
        }
        return out
    }

    private fun showProblems(status: String? = null) {
        if (!::problemsBox.isInitialized) return
        problemsBox.removeAllViews()
        fun line(text: String, color: Int, click: (() -> Unit)?) {
            val t = TextView(this)
            t.text = text
            t.setTextColor(color)
            t.textSize = 12f
            t.typeface = Typeface.MONOSPACE
            t.setPadding(dp(10), dp(4), dp(6), dp(4))
            if (click != null) t.setOnClickListener { click() }
            problemsBox.addView(t)
        }
        if (status != null) { line(status, C.DIM, null); return }
        if (problems.isEmpty()) {
            val sdk = Registry.sdkErrors
            if (sdk.isNotEmpty()) for ((k, v) in sdk) line("$k: $v", C.AMBER, null)
            else line(if (card.after != null) "No problems. Pull the sliders in the Effects panel to test it." else "Press Run to compile and preview.", C.DIM, null)
            return
        }
        for (p in problems) {
            val label = if (p.line != null) "Line " + p.line + ": " + p.text else p.text
            line(label, C.RED, if (p.line != null) ({ gotoLine(p.line) }) else null)
        }
    }

    private fun gotoLine(line: Int) {
        val f = cur ?: return
        val folder = effectFolderOf(f.path) ?: return
        val glsl = if (isAsset(folder)) "$folder/effect.glsl" else File(folder, "effect.glsl").absolutePath
        if (f.path != glsl) openFile(glsl)
        val off = editor.offsetOfLine(line)
        if (off >= 0) {
            editor.requestFocus()
            editor.setSelection(off.coerceAtMost(editor.text.length))
        }
    }

    // ------------------------------------------------------------------ menu, export, preview image

    private fun showMenu() {
        val labels = arrayOf("Pick preview image", "Export effect as zip", "Show SDK reference", if (previewOpen) "Hide preview" else "Show preview", "Open effects in the editor")
        val icons = arrayOf("media", "export", "box", "eye", "sparkle")
        Dlg(this).setTitle("Effect editor").setIconItems(labels, icons) { _, w ->
            when (w) {
                0 -> pickPreviewImage()
                1 -> exportZip()
                2 -> showReference()
                3 -> { previewOpen = !previewOpen; applyPreviewVisibility() }
                4 -> { if (!wide) openDrawer() }
            }
        }.show()
    }

    private fun userEffectFolder(): File? {
        val f = cur ?: return null
        val folder = effectFolderOf(f.path)
        if (folder == null || isAsset(folder)) return null
        return File(folder)
    }

    private fun pickPreviewImage() {
        if (userEffectFolder() == null) { toast("Open a file of one of your own effects first"); return }
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(i, R_PICK_IMAGE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != R_PICK_IMAGE || res != RESULT_OK) return
        val uri = data?.data ?: return
        val dir = userEffectFolder() ?: return
        try {
            val mime = contentResolver.getType(uri) ?: "image/jpeg"
            val name = if (mime.contains("png")) "preview.png" else "preview.jpg"
            File(dir, "preview.jpg").delete(); File(dir, "preview.png").delete()
            contentResolver.openInputStream(uri)!!.use { i -> File(dir, name).outputStream().use { o -> i.copyTo(o) } }
            val mf = File(dir, "effect.json")
            val o = JSONObject(mf.readText())
            val pv2 = o.optJSONObject("preview") ?: JSONObject()
            pv2.put("image", name)
            o.put("preview", pv2)
            mf.writeText(o.toString(2))
            changed = true
            // If effect.json is open, show the new text.
            val oj = openFiles.firstOrNull { it.path == mf.absolutePath }
            if (oj != null) { oj.text = mf.readText(); oj.saved = oj.text; if (cur === oj) loadCurrentIntoEditor() }
            rebuildTree()
            toast("Preview image set. Press Run to see it.")
        } catch (e: Exception) { toast("Could not use that image") }
    }

    private fun exportZip() {
        val dir = userEffectFolder()
        if (dir == null) { toast("Open a file of one of your own effects first"); return }
        saveAll()
        try {
            val v = ContentValues()
            val name = dir.name + ".zip"
            v.put(MediaStore.Downloads.DISPLAY_NAME, name)
            v.put(MediaStore.Downloads.MIME_TYPE, "application/zip")
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SaikiMotion")
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            ZipOutputStream(contentResolver.openOutputStream(uri)!!).use { z ->
                dir.walkTopDown().filter { it.isFile }.forEach { f ->
                    z.putNextEntry(ZipEntry(dir.name + "/" + f.relativeTo(dir).path))
                    f.inputStream().use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
            toast("Saved to Downloads/SaikiMotion/$name")
        } catch (e: Exception) { toast("Export failed") }
    }

    private fun showReference() {
        val t = TextView(this)
        t.text = "vec4 effect(vec2 uv) runs for every pixel. uv is 0..1, (0,0) bottom-left.\n\n" +
            "uTime  seconds since the layer started\nuRes  layer size in pixels (vec2)\n" +
            "src(uv)  the layer's pixel (premultiplied)\nsrcW(uv, m)  m: 0 clear outside, 1 repeat, 2 mirror\n" +
            "in0(uv), in1(uv)  pixels of chosen layers\nuHas0, uHas1  1.0 when a layer is chosen\n" +
            "luma(rgb)  brightness\nhash11(x), hash21(v)  random 0..1\nvnoise(v), fbm(v)  noise\n" +
            "rot(v, radians)  rotate a vec2\nhsv2rgb(c)  color conversion\nunpremul(c)  plain color from a pixel\n\n" +
            "Params in effect.json are floats with the same name. Colors are vec4 (rgb plus a).\n" +
            "Option lists give 0, 1, 2 in order.\n\nReturn premultiplied color: multiply rgb by alpha before returning.\n\n" +
            "Preview animations: swipe, fade, cut, wipe.\nPreview images: portrait, mountain, woman, greenscreen, ramen, apple, or a file in the effect folder.\n\nFull guide: SDK.md in the project."
        t.setTextColor(C.TEXT)
        t.textSize = 12f
        t.typeface = Typeface.MONOSPACE
        t.setPadding(dp(4), dp(4), dp(4), dp(4))
        Dlg(this).setTitle("SDK reference").setView(ScrollView(this).also { it.addView(t) }).setPositiveButton("Close", null).show()
    }
}
