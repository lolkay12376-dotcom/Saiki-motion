package com.saiki.motion

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.media.MediaMetadataRetriever
import java.util.concurrent.ConcurrentHashMap
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.roundToInt

interface TimelineHost {
    fun selectedId(): Int
    fun onSeek(t: Float)
    fun onSelect(id: Int)
    fun onToggleVisible(l: Layer)
    fun beginEdit()
    fun onTimingChanged()
    fun onReorder(l: Layer, listIndex: Int)
    fun onKeyTap(l: Layer, key: String, idx: Int)
    fun isSelected(id: Int): Boolean
}

/**
 * Timeline with a centred playhead. Top row = front-most layer.
 * "^" expands a layer into its keyframe rows (or a group into its content),
 * long-press a layer then drag up or down to reorder it.
 */
class TimelineView(ctx: Context, private val host: TimelineHost) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    var pxPerSec = 80f * d
    private var scrollY = 0f
    private val rulerH = 36f * d
    private val rowH = 34f * d
    private val paramH = 24f * d
    private val leftCol = 74f * d
    private val open = HashSet<Int>()

    private class TRow(val kind: Int, val layer: Layer, val depth: Int, val label: String = "", val key: String = "") {
        var top = 0f
        var h = 0f
    }
    private val trows = ArrayList<TRow>()
    private var totalH = 0f

    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mkName = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10f * resources.displayMetrics.density; typeface = Typeface.DEFAULT_BOLD }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val barLine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val name = Paint(Paint.ANTI_ALIAS_FLAG)
    private val small = Paint(Paint.ANTI_ALIAS_FLAG)
    private val head = Paint(Paint.ANTI_ALIAS_FLAG)
    private val headTxt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val white = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tri = Path()
    private val r = RectF()

    // gesture state
    private var mode = 0 // 0 none, 1 scrub, 2 pending tap, 3 trim start, 4 trim end, 5 move bar, 6 vscroll, 7 reorder
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moved = false
    private var tapLayer: Layer? = null
    private var tapEye: Layer? = null
    private var tapChev: Layer? = null
    private var tapKey: Triple<Layer, String, Int>? = null
    private var dragLayer: Layer? = null
    private var dragY = 0f
    private var dragKey: Key? = null
    private var dragTrack: Track? = null
    private var keyBegun = false
    private var dragGrab = 0f
    private val offCur = HashMap<Int, Float>()
    private val offTgt = HashMap<Int, Float>()
    private val handler = Handler(Looper.getMainLooper())
    private val longPress = Runnable {
        val l = tapLayer ?: return@Runnable
        if (mode == 2 || mode == 5 || mode == 3 || mode == 4) {
            dragLayer = l
            mode = 7
            open.remove(l.id)
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            val row = rowFor(l)
            dragGrab = if (row != null) downY - (rulerH + row.top - scrollY) else rowH / 2f
            dragY = downY
            invalidate()
        }
    }

    private val pinch = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(det: ScaleGestureDetector): Boolean {
            pxPerSec = (pxPerSec * det.scaleFactor).coerceIn(10f * d, 900f * d)
            invalidate()
            return true
        }
    })

    init {
        bgP.color = C.BG
        tick.strokeWidth = 1f * d; tick.color = 0xFF55555E.toInt()
        num.color = C.DIM; num.textSize = 11f * d; num.textAlign = Paint.Align.CENTER
        barLine.style = Paint.Style.STROKE; barLine.strokeWidth = 2f * d; barLine.color = 0xFFFFFFFF.toInt()
        name.color = 0xFFFFFFFF.toInt(); name.textSize = 11f * d; name.typeface = Typeface.DEFAULT_BOLD
        small.color = C.DIM; small.textSize = 11f * d
        head.color = C.GREEN
        headTxt.color = 0xFF2B1400.toInt(); headTxt.textSize = 12f * d; headTxt.typeface = Typeface.DEFAULT_BOLD; headTxt.textAlign = Paint.Align.CENTER
        white.color = 0xFFFFFFFF.toInt()
    }

    fun fitToScene() {
        val usable = width - leftCol - 24f * d
        if (usable > 0) pxPerSec = (usable / Editor.scene.duration).coerceIn(10f * d, 900f * d)
        invalidate()
    }

    private fun cx() = width / 2f
    private fun tx(t: Float) = cx() + (t - Editor.time) * pxPerSec
    private fun xt(x: Float) = Editor.time + (x - cx()) / pxPerSec

    fun timecode(t: Float): String {
        val fps = Editor.project.fps
        val total = (t * fps).roundToInt()
        return String.format("%02d:%02d:%02d", total / fps / 60, (total / fps) % 60, total % fps)
    }

    private val thumbs = ConcurrentHashMap<Int, Bitmap>()
    private val loading = HashSet<Int>()
    private val dst = RectF()

    private fun thumb(l: Layer): Bitmap? {
        if (l.type != LayerType.IMAGE && l.type != LayerType.VIDEO) return null
        thumbs[l.id]?.let { return it }
        val p = l.imagePath ?: return null
        if (loading.add(l.id)) Thread {
            try {
                val b: Bitmap? = if (l.type == LayerType.IMAGE) {
                    val o = BitmapFactory.Options(); o.inJustDecodeBounds = true; BitmapFactory.decodeFile(p, o)
                    var ss = 1
                    while (o.outHeight / ss > 160) ss *= 2
                    val o2 = BitmapFactory.Options(); o2.inSampleSize = ss
                    BitmapFactory.decodeFile(p, o2)
                } else {
                    val mr = MediaMetadataRetriever(); mr.setDataSource(p)
                    val f = mr.getFrameAtTime(0); mr.release()
                    if (f != null) Bitmap.createScaledBitmap(f, maxOf(1, f.width * 80 / f.height), 80, true) else null
                }
                if (b != null) { thumbs[l.id] = b; postInvalidate() }
            } catch (e: Exception) { }
        }.start()
        return null
    }

    /** Opens every layer and group, or closes them all if everything is already open. */
    fun expandAll() {
        val ls = Editor.scene.layers
        if (ls.any { !open.contains(it.id) }) ls.forEach { open.add(it.id) } else open.clear()
        invalidate()
    }

    // ------------------------------------------------------------------ rows

    private fun groupOf(l: Layer, k: String): String {
        if (Defs.transform.any { it.key == k } || Defs.pos3d.any { it.key == k } || Defs.rot3d.any { it.key == k }) return "Transform"
        if (k == "camFov") return "Camera"
        for (id in l.fx) { val e = Registry.get(id); if (e != null && e.props.any { l.pkey(id, it) == k }) return if (id.contains('~')) e.name + " " + id.substringAfter('~') else e.name }
        return "Other"
    }

    private fun build() {
        trows.clear()
        val ls = Editor.scene.layers
        fun emit(l: Layer, depth: Int) {
            trows.add(TRow(0, l, depth))
            if (!open.contains(l.id) || depth > 4) return
            if (l.type == LayerType.GROUP) {
                for (c in ls.reversed()) if (c.parentId == l.id) emit(c, depth + 1)
            } else {
                val groups = LinkedHashMap<String, MutableList<String>>()
                for ((k, tr) in l.props) if (tr.keys.isNotEmpty()) groups.getOrPut(groupOf(l, k)) { ArrayList() }.add(k)
                if (groups.isEmpty()) trows.add(TRow(3, l, depth + 1, "No keyframes yet"))
                for ((g, keys) in groups) {
                    trows.add(TRow(1, l, depth + 1, g))
                    for (k in keys) trows.add(TRow(2, l, depth + 2, Registry.propDef(k)?.label ?: k, k))
                }
            }
        }
        for (l in ls.reversed()) {
            val par = ls.firstOrNull { it.id == l.parentId }
            if (par == null || par.type != LayerType.GROUP) emit(l, 0)
        }
        var y = 0f
        for (row in trows) { row.top = y; row.h = if (row.kind == 0) rowH else paramH; y += row.h }
        totalH = y
    }

    /** Start and end shown for a layer; groups span their children. */
    private fun extent(l: Layer): Pair<Float, Float> {
        if (l.type != LayerType.GROUP) return Pair(l.start, l.end)
        val kids = Editor.scene.layers.filter { it.parentId == l.id }
        if (kids.isEmpty()) return Pair(0f, Editor.scene.duration)
        val ex = kids.map { extent(it) }
        return Pair(ex.minOf { it.first }, ex.maxOf { it.second })
    }

    private fun fitDuration() {
        val mx = Editor.scene.layers.filter { it.type != LayerType.GROUP }.maxOfOrNull { it.end } ?: return
        if (mx > Editor.scene.duration + 0.001f) Editor.scene.duration = minOf(mx, 600f)
    }

    private fun rowFor(l: Layer): TRow? = trows.firstOrNull { it.kind == 0 && it.layer === l }

    private fun rowAt(y: Float): TRow? {
        if (y < rulerH) return null
        for (row in trows) { val t = rulerH + row.top - scrollY; if (y >= t && y < t + row.h) return row }
        return null
    }

    /** True for the top layer of a group that has its mask turned on. */
    private fun isMaskLayer(l: Layer): Boolean {
        val g = Editor.scene.layers.firstOrNull { it.id == l.parentId } ?: return false
        if (g.type != LayerType.GROUP || g.mask == 0) return false
        return Editor.scene.layers.lastOrNull { it.parentId == g.id }?.id == l.id
    }

    private fun siblings(l: Layer): List<TRow> = trows.filter { it.kind == 0 && it.layer.parentId == l.parentId }

    // ------------------------------------------------------------------ drawing

    override fun onDraw(c: Canvas) { try { draw0(c) } catch (e: Exception) { } }

    private fun draw0(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val scene = Editor.scene
        build()
        c.drawRect(0f, 0f, w, h, bgP)

        // ruler
        val steps = floatArrayOf(0.1f, 0.2f, 0.5f, 1f, 2f, 5f, 10f, 30f, 60f)
        var step = 60f
        for (s in steps) if (s * pxPerSec >= 56f * d) { step = s; break }
        var t = floor(xt(0f) / step) * step
        val t1 = xt(w)
        while (t <= t1) {
            if (t >= -0.0001f) {
                val x = tx(t)
                c.drawLine(x, rulerH - 14f * d, x, rulerH, tick)
                c.drawText(if (step >= 1f) String.format("%d", t.roundToInt()) else String.format("%.1f", t), x, rulerH - 18f * d, num)
            }
            for (k in 1 until 5) {
                val mt = t + step * k / 5f
                if (mt >= 0f && step * pxPerSec / 5f > 7f * d) c.drawLine(tx(mt), rulerH - 6f * d, tx(mt), rulerH, tick)
            }
            t += step
        }
        head.strokeWidth = 3f * d
        c.drawLine(maxOf(tx(0f), 0f), 1.5f * d, minOf(tx(scene.duration), w), 1.5f * d, head)
        for (m in scene.markers) {
            val x = tx(m)
            tri.reset(); tri.moveTo(x - 6f * d, rulerH - 12f * d); tri.lineTo(x + 6f * d, rulerH - 12f * d); tri.lineTo(x, rulerH); tri.close()
            bar.color = C.BLUE; c.drawPath(tri, bar)
            c.drawLine(x, rulerH, x, h, tick)
            val mnm = scene.markerName(m)
            if (mnm != null) { mkName.color = C.BLUE; c.drawText(mnm, x + 8f * d, rulerH - 14f * d, mkName) }
        }

        // rows
        advanceOffsets()
        c.save()
        c.clipRect(0f, rulerH, w, h)
        val sel = host.selectedId()
        for (row in trows) {
            if (row.layer === dragLayer && row.kind == 0) continue
            val top = rulerH + row.top - scrollY + (offCur[row.layer.id] ?: 0f).let { if (row.kind == 0) it else 0f }
            if (top > h || top + row.h < rulerH) continue
            drawRow(c, row, top, sel)
        }
        val dl = dragLayer
        if (dl != null) {
            val row = rowFor(dl)
            if (row != null) {
                val top = (dragY - dragGrab).coerceIn(rulerH, h - rowH)
                bar.color = 0x66000000
                c.drawRect(0f, top - 2f * d, w, top + rowH + 2f * d, bar)
                drawRow(c, row, top, sel)
            }
        }
        c.restore()

        // playhead
        val px = cx()
        head.strokeWidth = 2f * d
        c.drawLine(px, 0f, px, h, head)
        val tc = timecode(Editor.time)
        val bw = headTxt.measureText(tc) + 18f * d
        r.set(px - bw / 2f, 4f * d, px + bw / 2f, 24f * d)
        c.drawRoundRect(r, 10f * d, 10f * d, head)
        c.drawText(tc, px, 19f * d, headTxt)
    }

    private fun drawRow(c: Canvas, row: TRow, top: Float, sel: Int) {
        val w = width.toFloat()
        val l = row.layer
        val indent = row.depth * 10f * d
        when (row.kind) {
            0 -> {
                var s0 = l.start
                var e0 = l.end
                if (l.type == LayerType.GROUP) {
                    val kids = Editor.scene.layers.filter { it.parentId == l.id }
                    if (kids.isNotEmpty()) { s0 = kids.minOf { it.start }; e0 = kids.maxOf { it.end } } else { s0 = 0f; e0 = Editor.scene.duration }
                }
                val x0 = tx(s0)
                val x1 = tx(e0)
                r.set(x0, top + 4f * d, x1, top + rowH - 4f * d)
                bar.color = when (l.type) {
                    LayerType.SHAPE -> 0xFF2F6BFF.toInt(); LayerType.TEXT -> 0xFFD9822B.toInt(); LayerType.IMAGE -> 0xFF1FA67A.toInt()
                    LayerType.VIDEO -> 0xFF8B5CF6.toInt(); LayerType.CAMERA -> 0xFF6B7280.toInt(); LayerType.NULL -> 0xFF9CA3AF.toInt()
                    LayerType.MODEL -> 0xFFEC4899.toInt(); LayerType.PARTICLES -> 0xFFCA8A04.toInt(); LayerType.GROUP -> 0xFF4B4B55.toInt(); LayerType.ADJUST -> 0xFF0EA5E9.toInt(); LayerType.AUDIO -> 0xFF64748B.toInt()
                }
                bar.alpha = if (l.visible) 255 else 90
                c.drawRoundRect(r, 7f * d, 7f * d, bar)
                val tb = thumb(l)
                if (tb != null && l.visible) {
                    c.save(); c.clipRect(r)
                    val th = r.height()
                    val tw = th * tb.width / tb.height
                    var x = maxOf(r.left, 0f)
                    val endx = minOf(r.right, width.toFloat())
                    while (x < endx) { dst.set(x, r.top, x + tw, r.bottom); c.drawBitmap(tb, null, dst, null); x += tw }
                    c.restore()
                    bar.color = 0x77000000; c.drawRoundRect(r, 7f * d, 7f * d, bar)
                }
                if (l.type == LayerType.AUDIO) {
                    bar.color = 0xAAFFFFFF.toInt(); bar.strokeWidth = 1.5f * d
                    val origin = tx(l.start)
                    var x = maxOf(r.left, leftCol)
                    val ex = minOf(r.right, width.toFloat())
                    val mid = r.centerY()
                    while (x < ex) {
                        val idx = ((x - origin) / (3f * d)).toInt()
                        val hh = (0.2f + 0.8f * ((((idx.toLong() * 2654435761L) ushr 7) and 255L) / 255f)) * r.height() * 0.45f
                        c.drawLine(x, mid - hh, x, mid + hh, bar)
                        x += 3f * d
                    }
                }
                if (l.fx.isNotEmpty()) { bar.color = 0x33FFFFFF; c.drawRect(r.left + 6f * d, r.bottom - 6f * d, r.right - 6f * d, r.bottom - 3f * d, bar) }
                if (l.type != LayerType.GROUP) {
                    val seen = HashSet<Int>()
                    for ((_, tr) in l.props) for (k in tr.keys) {
                        val kx = tx(k.t)
                        if (kx < x0 || kx > x1 || !seen.add((k.t * 100f).roundToInt())) continue
                        diamond(c, kx, r.centerY(), 4.5f * d, white)
                    }
                }
                c.save()
                c.clipRect(maxOf(r.left + 8f * d, leftCol), r.top, r.right - 8f * d, r.bottom)
                c.drawText(if (l.type == LayerType.GROUP) l.name + (if (l.mask != 0) "  (mask" + (if (l.mask == 2 || l.mask == 4) ", inverted" else "") + ")" else "") else (if (isMaskLayer(l)) "[mask] " else "") + l.name + "  " + String.format("%.1fs", l.end - l.start) + (if (l.fx.isNotEmpty()) "  fx" + l.fx.size else ""), maxOf(r.left, leftCol) + 8f * d + indent, top + rowH / 2f + 4f * d, name)
                c.restore()
                if (l.id == sel && l.type != LayerType.GROUP) {
                    c.drawRoundRect(r, 7f * d, 7f * d, barLine)
                    for (side in 0..1) {
                        val hx = if (side == 0) r.left else r.right
                        val hr = RectF(hx - 9f * d, r.top - 1f * d, hx + 9f * d, r.bottom + 1f * d)
                        c.drawRoundRect(hr, 6f * d, 6f * d, white)
                        val cy = r.centerY()
                        val dir = if (side == 0) -1f else 1f
                        tri.reset(); tri.moveTo(hx + dir * 3f * d, cy - 4f * d); tri.lineTo(hx + dir * 3f * d, cy + 4f * d); tri.lineTo(hx - dir * 2f * d, cy); tri.close()
                        bar.color = 0xFF222222.toInt(); bar.alpha = 255
                        c.drawPath(tri, bar)
                    }
                } else if (host.isSelected(l.id)) c.drawRoundRect(r, 7f * d, 7f * d, barLine)
                // left column
                bar.color = C.BG; bar.alpha = 255
                c.drawRect(0f, top, leftCol, top + rowH, bar)
                val cy = top + rowH / 2f
                Icons.draw(c, if (l.visible) "eye" else "eye_off", leftCol * 0.27f, cy, 19f * d, if (l.visible) C.TEXT else 0xFF666670.toInt())
                Icons.draw(c, "chev_up", leftCol * 0.74f, cy, 19f * d, if (open.contains(l.id)) C.AMBER else 0xFF777782.toInt())
                bar.color = C.BG; bar.alpha = 255
                c.drawRect(w - 30f * d, top, w, top + rowH, bar)
                Icons.draw(c, "handle", w - 16f * d, cy, 16f * d, C.DIM)
            }
            1 -> {
                bar.color = 0xFF14141A.toInt(); c.drawRect(0f, top, w, top + row.h, bar)
                small.typeface = Typeface.DEFAULT_BOLD; small.color = C.GREEN
                c.drawText(row.label, leftCol + 8f * d + indent, top + row.h / 2f + 4f * d, small)
                small.typeface = Typeface.DEFAULT; small.color = C.DIM
            }
            2 -> {
                bar.color = 0xFF101015.toInt(); c.drawRect(0f, top, w, top + row.h, bar)
                val tr = l.props[row.key]
                if (tr != null) for (k in tr.keys) {
                    val on = abs(k.t - Editor.time) < 0.03f
                    diamond(c, tx(k.t), top + row.h / 2f, 5f * d, if (on) head else white)
                }
                bar.color = 0xCC0E0E10.toInt(); c.drawRect(leftCol, top, leftCol + 150f * d, top + row.h, bar)
                c.drawText(row.label, leftCol + 8f * d + indent, top + row.h / 2f + 4f * d, small)
            }
            else -> c.drawText(row.label, leftCol + 8f * d + indent, top + row.h / 2f + 4f * d, small)
        }
    }

    private fun diamond(c: Canvas, x: Float, y: Float, s: Float, p: Paint) {
        tri.reset(); tri.moveTo(x, y - s); tri.lineTo(x + s, y); tri.lineTo(x, y + s); tri.lineTo(x - s, y); tri.close()
        c.drawPath(tri, p)
    }

    /** Drags a keyframe along the timeline; snaps to beat markers and frames. */
    private fun moveKey(x: Float) {
        val k = dragKey ?: return
        val tr = dragTrack ?: return
        val fps = Editor.project.fps.toFloat()
        var t = xt(x)
        val m = Editor.scene.markers.minByOrNull { abs(it - t) }
        t = if (m != null && abs(m - t) < 8f * d / pxPerSec) m else Math.round(t * fps) / fps
        t = t.coerceIn(0f, Editor.scene.duration)
        if (tr.keys.any { it !== k && abs(it.t - t) < 0.5f / fps }) return
        k.t = t
        tr.keys.sortBy { it.t }
        host.onTimingChanged()
        invalidate()
    }

    /** Smoothly slides the rows that the dragged layer passes over. */
    private fun advanceOffsets() {
        val dl = dragLayer
        offTgt.clear()
        if (dl != null) {
            val sib = siblings(dl)
            val src = sib.indexOfFirst { it.layer === dl }
            val tgt = targetIndex(sib)
            for ((i, s) in sib.withIndex()) {
                if (s.layer === dl) continue
                offTgt[s.layer.id] = if (tgt < src && i in tgt until src) rowH else if (tgt > src && i in (src + 1)..tgt) -rowH else 0f
            }
        }
        var busy = false
        val ids = HashSet<Int>(offCur.keys); ids.addAll(offTgt.keys)
        for (id in ids) {
            val cur = offCur[id] ?: 0f
            val tg = offTgt[id] ?: 0f
            val nv = cur + (tg - cur) * 0.32f
            if (abs(tg - nv) < 0.5f) { if (tg == 0f) offCur.remove(id) else offCur[id] = tg } else { offCur[id] = nv; busy = true }
        }
        if (busy || dl != null) postInvalidateOnAnimation()
    }

    private fun targetIndex(sib: List<TRow>): Int {
        val dl = dragLayer ?: return 0
        val center = dragY - dragGrab + rowH / 2f
        var best = sib.indexOfFirst { it.layer === dl }
        var bd = Float.MAX_VALUE
        for ((i, s) in sib.withIndex()) {
            val c = rulerH + s.top - scrollY + rowH / 2f
            val dd = abs(c - center)
            if (dd < bd) { bd = dd; best = i }
        }
        return best
    }

    // ------------------------------------------------------------------ touch

    override fun onTouchEvent(e: MotionEvent): Boolean {
        pinch.onTouchEvent(e)
        if (pinch.isInProgress || e.pointerCount > 1) { handler.removeCallbacks(longPress); if (mode != 7) mode = 0; return true }
        val layers = Editor.scene.layers
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y; moved = false
                tapLayer = null; tapEye = null; tapChev = null; tapKey = null
                parent?.requestDisallowInterceptTouchEvent(true)
                val row = rowAt(e.y)
                mode = 1
                if (row != null && row.kind == 0) {
                    val l = row.layer
                    if (e.x > width - 30f * d) {
                        dragLayer = l; mode = 7; open.remove(l.id)
                        dragGrab = downY - (rulerH + row.top - scrollY); dragY = downY
                        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    }
                    else if (e.x < leftCol * 0.5f) { tapEye = l; mode = 0 }
                    else if (e.x < leftCol) { tapChev = l; mode = 0 }
                    else {
                        val ext = extent(l); val x0 = tx(ext.first); val x1 = tx(ext.second); val hit = 22f * d
                        val isSel = l.id == host.selectedId() && l.type != LayerType.GROUP
                        if (isSel && abs(e.x - x0) < hit) { host.beginEdit(); mode = 3 }
                        else if (isSel && abs(e.x - x1) < hit) { host.beginEdit(); mode = 4 }
                        else if (l.id == host.selectedId() && e.x in x0..x1) { host.beginEdit(); mode = 5 }
                        else mode = 2
                        tapLayer = l
                        handler.postDelayed(longPress, 420)
                    }
                } else if (row != null && row.kind == 2) {
                    val tr = row.layer.props[row.key]
                    var hitIdx = -1
                    if (tr != null) for ((i, k) in tr.keys.withIndex()) if (abs(e.x - tx(k.t)) < 20f * d) hitIdx = i
                    tapLayer = row.layer
                    mode = 2
                    if (hitIdx >= 0 && tr != null) { tapKey = Triple(row.layer, row.key, hitIdx); dragKey = tr.keys[hitIdx]; dragTrack = tr; mode = 8 }
                } else if (e.y > rulerH) { tapLayer = row?.layer; mode = 2 }
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX
                val dy = e.y - lastY
                if (abs(e.x - downX) > 8f * d || abs(e.y - downY) > 8f * d) { moved = true; if (mode != 7) handler.removeCallbacks(longPress) }
                when (mode) {
                    7 -> { dragY = e.y; invalidate() }
                    8 -> if (moved) { if (!keyBegun) { host.beginEdit(); keyBegun = true }; moveKey(e.x) }
                    1, 2 -> {
                        if (mode == 2 && moved && abs(e.y - downY) > abs(e.x - downX) * 1.5f && totalH > height - rulerH - 1f) mode = 6
                        else if (moved) {
                            mode = 1
                            host.onSeek((Editor.time - dx / pxPerSec).coerceIn(0f, Editor.scene.duration))
                        }
                    }
                    6 -> { scrollY = (scrollY - dy).coerceIn(0f, maxOf(0f, totalH + 8f * d - (height - rulerH))); invalidate() }
                    3, 4, 5 -> {
                        val l = layers.firstOrNull { it.id == host.selectedId() }
                        if (l != null && moved) {
                            val fps = Editor.project.fps.toFloat()
                            val dur = Editor.scene.duration
                            when (mode) {
                                3 -> {
                                    val ns = (Math.round(xt(e.x) * fps) / fps).coerceIn(0f, maxOf(0f, l.end - 0.1f))
                                    if (l.type == LayerType.VIDEO || l.type == LayerType.AUDIO) l.srcOffset += ns - l.start
                                    l.start = ns
                                }
                                4 -> {
                                    var ne = (Math.round(xt(e.x) * fps) / fps).coerceAtLeast(l.start + 0.1f)
                                    if ((l.type == LayerType.VIDEO || l.type == LayerType.AUDIO) && l.srcDur > 0f) ne = minOf(ne, l.start + l.srcDur - l.srcOffset)
                                    l.end = maxOf(ne, l.start + 0.1f)
                                    fitDuration()
                                }
                                else -> {
                                    if (l.type == LayerType.GROUP) {
                                        val kids = layers.filter { it.parentId == l.id }
                                        if (kids.isNotEmpty()) {
                                            val lo = -kids.minOf { it.start }
                                            val dt = (dx / pxPerSec).coerceAtLeast(lo)
                                            for (k in kids) { k.start += dt; k.end += dt }
                                            fitDuration()
                                        }
                                    } else {
                                        val len = l.end - l.start
                                        val ns = (l.start + dx / pxPerSec).coerceAtLeast(0f)
                                        l.start = ns; l.end = ns + len
                                        fitDuration()
                                    }
                                }
                            }
                            host.onTimingChanged(); invalidate()
                        }
                    }
                }
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPress)
                parent?.requestDisallowInterceptTouchEvent(false)
                if (mode == 7) {
                    val dl = dragLayer
                    if (dl != null) {
                        val sib = siblings(dl)
                        val ti = targetIndex(sib)
                        val tl = sib.getOrNull(ti)?.layer
                        if (tl != null && tl !== dl) host.onReorder(dl, layers.indexOf(tl))
                    }
                    dragLayer = null
                    offCur.clear(); offTgt.clear()
                    invalidate()
                } else if (!moved) {
                    val eye = tapEye; val chev = tapChev; val key = tapKey; val tl = tapLayer
                    if (eye != null) host.onToggleVisible(eye)
                    else if (chev != null) { if (!open.remove(chev.id)) open.add(chev.id); invalidate() }
                    else if (key != null) host.onKeyTap(key.first, key.second, key.third)
                    else if (tl != null) host.onSelect(tl.id)
                    else if (mode == 2) host.onSelect(-1)
                }
                dragKey = null; dragTrack = null; keyBegun = false
                mode = 0
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPress); parent?.requestDisallowInterceptTouchEvent(false)
                dragLayer = null; offCur.clear(); offTgt.clear(); mode = 0
            }
        }
        return true
    }
}
