package com.saiki.motion

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** First-launch welcome screen with the disclaimer and the update list. */
object Welcome {
    val UPDATES = listOf(
        "Project menu: rename, render, export and import project files (.saikipjf, or a zip with media)",
        "Render settings: quality, bit rate and frame rate, with a live render screen and Save to Photos",
        "Audio now starts instantly and stays in sync while you edit",
        "Welcome screen with the disclaimer and update notes"
    )

    fun show(a: Activity, force: Boolean = false) {
        val sp = a.getSharedPreferences("saiki", Context.MODE_PRIVATE)
        if (!force && sp.getBoolean("hideWelcome", false)) return
        val d = a.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val dlg = Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dlg.setCancelable(false)
        val sv = ScrollView(a)
        sv.setBackgroundColor(0xFF000000.toInt())
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(22), dp(28), dp(22), dp(24))

        fun tv(t: String, color: Int, size: Float, bold: Boolean = false, center: Boolean = false): TextView {
            val x = TextView(a)
            x.text = t; x.setTextColor(color); x.textSize = size
            if (bold) x.typeface = Typeface.DEFAULT_BOLD
            if (center) x.gravity = Gravity.CENTER
            return x
        }

        val img = ImageView(a)
        img.setImageResource(R.drawable.splash_chibi)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        col.addView(img, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)))
        val brand = tv("SAIKI MOTION", C.GREEN, 14f, true, true)
        brand.letterSpacing = 0.3f
        brand.setPadding(0, dp(14), 0, 0)
        col.addView(brand)
        val title = tv("Welcome", 0xFFF2F2F2.toInt(), 32f, true, true)
        title.setPadding(0, dp(4), 0, dp(18))
        col.addView(title)

        val card = LinearLayout(a)
        card.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(C.CARD); bg.cornerRadius = 20f * d; bg.setStroke(dp(1), C.LINE)
        card.background = bg
        card.setPadding(dp(18), dp(16), dp(18), dp(16))
        card.addView(tv("THIS APP IS NOT A MOD OF KEYFLOW.", C.GREEN, 16f, true))
        val body = tv("Saiki Motion is an independent app. We built it with a similar interface and feature set to Keyflow by Angkin, and it is free for all users. We are currently in development and we are excited for the future of Saiki Motion.", C.TEXT, 14f)
        body.setPadding(0, dp(10), 0, dp(14))
        body.setLineSpacing(0f, 1.2f)
        card.addView(body)
        card.addView(tv("Developers", C.DIM, 12f, true))
        val dv = tv("TikTok  @quintsuxf\nTikTok  @naviya903", C.TEXT, 15f)
        dv.setPadding(0, dp(4), 0, 0)
        card.addView(dv)
        col.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val up = tv("What's new", C.GREEN, 13f, true)
        up.setPadding(dp(4), dp(22), 0, dp(6))
        col.addView(up, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        for (u in UPDATES) {
            val line = tv("•  $u", C.TEXT, 14f)
            line.setPadding(dp(4), dp(3), dp(4), dp(3))
            col.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(26), 0, 0)
        val never = PillButton(a, "Don't show again", null, C.CARD2, C.TEXT)
        never.onClick = { sp.edit().putBoolean("hideWelcome", true).apply(); dlg.dismiss() }
        val close = PillButton(a, "Close", null, C.GREEN, 0xFF2B1400.toInt())
        close.onClick = { dlg.dismiss() }
        val l1 = LinearLayout.LayoutParams(0, dp(50), 1f)
        l1.setMargins(0, 0, dp(8), 0)
        row.addView(never, l1)
        row.addView(close, LinearLayout.LayoutParams(0, dp(50), 1f))
        col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        sv.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        dlg.setContentView(sv)
        dlg.show()
    }
}
