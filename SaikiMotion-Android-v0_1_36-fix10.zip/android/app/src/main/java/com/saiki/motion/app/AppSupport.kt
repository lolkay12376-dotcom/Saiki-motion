@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.app

import android.app.Activity
import android.content.Intent
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.saiki.motion.ui.C
import com.saiki.motion.ui.IconView
import com.saiki.motion.ui.PillButton
import com.saiki.motion.ui.TapView
import com.saiki.motion.ui.appKeyWindow
import com.saiki.motion.ui.measureText
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UINavigationController
import com.saiki.motion.uikit.Navigator
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.currentActivity

// App-wave support: pieces the App screens need that live in iOS Core/Util.swift
// (Dlg, Snack) plus small glue (MLText multi-line label, DocPicker, pushScreen).
// core/Util.kt only carries the model-layer pieces of Util.swift.

/** Snack — Sources/Core/Util.swift snackbar replacement (Toast twin, 170pt offset). */
object Snack {
    private var current: UiView? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    fun show(text: String) = showText(text)
    fun show(vc: UIViewController, text: String) = showText(text)

    private fun showText(text: String) {
        handler.post {
            val window = appKeyWindow() ?: return@post
            current?.let { it.removeFromSuperview(); current = null }
            val lbl = object : UiView(window.context) {
                override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    com.saiki.motion.ui.fillRoundRect(c, rect, 16f, 0xF5222228.toInt())
                    com.saiki.motion.ui.drawText(text, rect.midX, rect.midY + 5f, color = C.TEXT, size = 14f,
                        bold = false, align = NSTextAlignment.center)
                }
            }
            val maxW = window.rectWidth() - 48f
            val lines = 1 + text.length / 34
            val w = minOf(maxW, measureText(text, 14f) + 36f)
            val h = 24f + 18f * lines
            lbl.frame = CGRect((window.rectWidth() - w) / 2f, window.rectHeight() - 170f - h, w, h)
            window.addSubview(lbl)
            current = lbl
            lbl.animate().alpha(1f).setDuration(150).start()
            handler.postDelayed({
                lbl.animate().alpha(0f).setDuration(350).withEndAction {
                    lbl.removeFromSuperview()
                    if (current === lbl) current = null
                }.start()
            }, 2400)
        }
    }
}

/** MLText — UILabel(numberOfLines: 0) twin: a StaticLayout-backed multi-line text view. */
class MLText(text: String, val size: Float, color: Int, bold: Boolean = false,
             align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL) : UiView(com.saiki.motion.uikit.appContext!!) {
    private var layout: StaticLayout? = null
    var text: String = text; private set
    val sizeF = size
    val textBold = bold
    private val paint = TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; this.textSize = size; isFakeBoldText = bold
    }
    private val alignm = align
    var spacingMul = 1f

    fun height(): Float = layout?.height?.toFloat() ?: (size * 1.3f)

    fun build(w: Float) {
        layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, w.toInt().coerceAtLeast(1))
            .setAlignment(alignm).setLineSpacing(0f, spacingMul).build()
    }

    /** Builds (if needed) and returns the current layout for direct Canvas drawing. */
    fun layoutPublic(w: Float): StaticLayout {
        if (layout == null) build(w)
        return layout!!
    }

    fun setText(t: String) { text = t; layout = null; setNeedsDisplay() }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        layout?.draw(c.canvas)
    }
}

/** A dialog custom view that sizes itself (Dlg asks for its height at a given width). */
interface DialogSizing {
    fun dialogHeight(w: Float): Float
    fun dialogLayout(w: Float, h: Float)
}

/** Dlg — Sources/Core/Util.swift AlertDialog replacement: dimmed overlay card with a builder chain. */
class Dlg(private val owner: UIViewController) {
    private var title: String? = null
    private var message: String? = null
    private var customView: UiView? = null
    private var items: List<String> = emptyList()
    private var itemIcons: List<String>? = null
    private var onItem: ((Dlg, Int) -> Unit)? = null
    private val buttons = ArrayList<Triple<String, Int, ((Dlg, Int) -> Unit)?>>()
    private var overlay: UiView? = null

    fun setTitle(t: String): Dlg { title = t; return this }
    fun setMessage(m: String): Dlg { message = m; return this }
    fun setView(v: UiView): Dlg { customView = v; return this }
    fun setItems(labels: List<String>, cb: (Dlg, Int) -> Unit): Dlg { items = labels; itemIcons = null; onItem = cb; return this }
    fun setIconItems(labels: List<String>, icons: List<String>, cb: (Dlg, Int) -> Unit): Dlg { items = labels; itemIcons = icons; onItem = cb; return this }
    fun setPositiveButton(t: String, cb: ((Dlg, Int) -> Unit)?): Dlg { buttons.add(Triple(t, 0, cb)); return this }
    fun setNeutralButton(t: String, cb: ((Dlg, Int) -> Unit)?): Dlg { buttons.add(Triple(t, 1, cb)); return this }
    fun setNegativeButton(t: String, cb: ((Dlg, Int) -> Unit)?): Dlg { buttons.add(Triple(t, 2, cb)); return this }
    fun create(): Dlg = this

    companion object {
        private var current: Dlg? = null
        fun dismissCurrent() { current?.dismiss() }
    }

    fun show(): Dlg {
        dismissCurrent()
        val window = appKeyWindow() ?: return this
        current = this
        val ctx = window.context

        val dim = UiView(ctx)
        dim.setBackgroundColor(0x8C000000.toInt())
        dim.onClick = { dismiss() }
        window.addSubview(dim)
        dim.frame = CGRect(0f, 0f, window.rectWidth(), window.rectHeight())   // UiView children own their frame; it was never sized

        val maxW = minOf(window.rectWidth() - 48f, 420f)
        val innerW = maxW - 36f
        var y = 14f
        val rows = ArrayList<Pair<UiView, Float>>()   // view, row height

        title?.let { t ->
            val l = MLText(t, 17f, C.TEXT, bold = true)
            l.build(innerW); rows.add(l to l.height() + 6f); y += l.height() + 6f
        }
        message?.let { m ->
            val l = MLText(m, 13f, C.DIM)
            l.build(innerW); rows.add(l to l.height() + 6f); y += l.height() + 6f
        }
        for ((i, label) in items.withIndex()) {
            val row = object : TapView() {
                override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    com.saiki.motion.ui.drawText(label, if (itemIcons != null) 44f else 14f, rect.midY + 5f,
                        color = C.TEXT, size = 15f, bold = false, align = NSTextAlignment.left)
                }
            }
            if (itemIcons != null) {
                val iv = IconView(itemIcons?.get(i) ?: "file", C.TEXT, 22f)
                iv.isUserInteractionEnabled = false
                row.addView(iv)
                iv.frame = CGRect(10f, 8f, 30f, 30f)
            }
            val idx = i
            row.onClick = {
                val cb = onItem
                dismiss()
                cb?.invoke(this, idx)
            }
            rows.add(row to 46f)
            y += 46f
        }
        customView?.let { v ->
            val vh = (v as? DialogSizing)?.dialogHeight(innerW)
                ?: (if (v.rectHeight() > 0f) v.rectHeight() else 40f)
            rows.add(v to vh + 6f)
            y += vh + 6f
        }
        val btns = buttons.sortedByDescending { it.second }   // negative, neutral, positive
        if (btns.isNotEmpty()) {
            val r = UiView(ctx)
            var bx = 0f
            val bw = (innerW - 8f * (btns.size - 1)) / btns.size
            for ((t, idx, cb) in btns) {
                val b = PillButton(t, null, C.CARD2, if (idx == 0) C.GREEN else C.TEXT)
                b.frame = CGRect(bx, 10f, bw, 40f)
                b.onClick = {
                    dismiss()
                    cb?.invoke(this, idx)
                }
                r.addView(b)
                bx += bw + 8f
            }
            rows.add(r to 50f)
            y += 50f
        }
        val cardH = (y + 12f).coerceAtLeast(60f)
        val maxH = window.rectHeight() * 0.78f
        val h = minOf(cardH, maxH)

        val card = object : UiView(ctx) {
            override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                com.saiki.motion.ui.fillRoundRect(c, rect, 18f, C.PANEL)
            }
        }
        dim.addView(card)
        card.frame = CGRect((window.rectWidth() - maxW) / 2, (window.rectHeight() - h) / 2f, maxW, h)
        var cy = 14f
        for ((v, rh) in rows) {
            card.addView(v)
            v.frame = CGRect(18f, cy, innerW, rh)
            if (v is MLText) v.build(innerW)
            (v as? DialogSizing)?.dialogLayout(innerW, rh)
            cy += rh
        }
        overlay = dim
        return this
    }

    fun dismiss() {
        val ov = overlay ?: return
        (ov.parent as? android.view.ViewGroup)?.removeView(ov)
        overlay = null
        if (current === this) current = null
    }
}

/** DocPicker — UIDocumentPickerViewController twin: ACTION_OPEN_DOCUMENT with a one-shot callback. */
object DocPicker {
    private var callback: ((android.net.Uri) -> Unit)? = null
    const val REQ = 47131
    const val REQ_IMAGES = 47132

    fun pick(then: (android.net.Uri) -> Unit) {
        val act: Activity = currentActivity?.get() ?: return
        callback = then
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        act.startActivityForResult(i, REQ)
    }

    /** The photo-library twin of iOS PHPickerViewController (pictures only, system picker UI). */
    fun pickImages(then: (android.net.Uri) -> Unit) {
        val act: Activity = currentActivity?.get() ?: return
        callback = then
        val i: Intent = if (android.os.Build.VERSION.SDK_INT >= 33) {
            Intent(android.provider.MediaStore.ACTION_PICK_IMAGES)
        } else {
            Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
            }
        }
        act.startActivityForResult(i, REQ_IMAGES)
    }

    /** Route here from Activity.onActivityResult (MainActivity forwards it). */
    fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != REQ && requestCode != REQ_IMAGES) return
        val cb = callback ?: return
        callback = null
        if (resultCode != Activity.RESULT_OK) return
        val u = data?.data ?: return
        cb(u)
    }
}

/** The app's navigation controller (Main.swift's window root; MainActivity hosts Navigator.stack). */
object AppNav {
    val nav: UINavigationController by lazy { UINavigationController(null) }
}

/** pushViewController that works with or without a wired navigationController (Navigator renders it). */
fun UIViewController.pushScreen(vc: UIViewController, animated: Boolean = true) {
    val nav = navigationController
    if (nav != null) nav.pushViewController(vc, animated)
    else AppNav.nav.pushViewController(vc, animated)
}

/** popViewController when nested, dismiss when presented (the gallery's pick flow). */
fun UIViewController.popOrDismiss(animated: Boolean = true) {
    if (navigationController != null) navigationController?.popViewController(animated) else dismiss(animated)
}
