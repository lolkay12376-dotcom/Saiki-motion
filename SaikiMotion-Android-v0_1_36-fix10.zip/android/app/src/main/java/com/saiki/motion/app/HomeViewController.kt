@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.app

import android.content.Intent
import android.graphics.BitmapFactory
import com.saiki.motion.core.AppInfo
import com.saiki.motion.core.CrashLog
import com.saiki.motion.core.EffectCrashLog
import com.saiki.motion.core.Folders
import com.saiki.motion.core.FrameCache
import com.saiki.motion.core.L10n
import com.saiki.motion.core.Prefs
import com.saiki.motion.core.PreRender
import com.saiki.motion.core.Project
import com.saiki.motion.core.ProjectArchive
import com.saiki.motion.core.ProjectFolder
import com.saiki.motion.core.Projects
import com.saiki.motion.core.StoreNotification
import com.saiki.motion.ui.DrawingGalleryViewController
import com.saiki.motion.ui.C
import com.saiki.motion.ui.ChibiView
import com.saiki.motion.ui.HelpDocs
import com.saiki.motion.ui.Icons
import com.saiki.motion.ui.PillButton
import com.saiki.motion.ui.SwitchRow
import com.saiki.motion.ui.TapView
import com.saiki.motion.ui.appKeyWindow
import com.saiki.motion.ui.boldFont
import com.saiki.motion.ui.drawText
import com.saiki.motion.ui.fillRoundRect
import com.saiki.motion.ui.measureText
import com.saiki.motion.ui.sysFont
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment as TA
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UILongPressGestureRecognizer
import com.saiki.motion.uikit.UITapGestureRecognizer
import com.saiki.motion.uikit.UISwitch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.capScrollOf
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.uikit.currentActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Port of Sources/App/HomeViewController.swift — the home screen: five-tab bar,
// "My Playground" projects tab with folders, Tools/Community/Extras tabs.
// NOTE(app root): iOS Main.swift sets the window root to HomeViewController; on Android
// MainActivity stays the entry for now — the EditorViewController wave wires
// Navigator.setRoot(HomeViewController()) there (see the comment in MainActivity.kt).

private typealias PAD = Int

class HomeViewController : UIViewController() {

    enum class Tab(val label: String, val icon: String) {
        account("Account", "account"),
        projects("Projects", "film"),
        tools("Tools", "tools"),
        community("Community", "people"),
        extras("Extras", "grid_plus");
    }

    // chrome
    private val barButtons = ArrayList<HomeTabButton>()
    private val content = UiView(com.saiki.motion.uikit.appContext!!)
    private var current: UiView? = null
    private var tabChild: UIViewController? = null
    private var selectedTab: Tab = Tab.projects
    private var didFirstAppear = false

    // projects tab state
    private var projects: List<Project> = emptyList()
    private var countLabel: UILabel? = null
    private var headerLabel: UILabel? = null
    private var openFolder: String? = null
    private var folderList: UiView? = null
    private var wrapView: UiView? = null

    private val pad: CGFloat = 16f

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        CrashLog.note("home")
        buildUi()
        show(Tab.projects)
        StoreNotification.observe(StoreNotification.Name.projectsChanged) { refresh() }
        StoreNotification.observe(StoreNotification.Name.languageChanged) { languageChanged() }
    }

    override fun viewWillAppear(animated: Boolean) {
        super.viewWillAppear(animated)
        refresh()      // pick up a fresh thumbnail after returning from the editor
    }

    override fun viewDidAppear(animated: Boolean) {
        super.viewDidAppear(animated)
        if (didFirstAppear) return
        didFirstAppear = true
        maybeShowWelcome()
    }

    // MARK: - buildUi

    private lateinit var tabBar: UiView

    private fun buildUi() {
        val bar = UiView(com.saiki.motion.uikit.appContext!!)
        bar.setBackgroundColor(C.BG)
        view.addView(bar)
        tabBar = bar
        for (tab in Tab.entries) {
            val b = HomeTabButton()
            b.icon = tab.icon
            b.setLabel(kerned(L10n.tr(tab.label), 9f, semibold = true, kern = 1.0f))
            b.on = tab == Tab.projects
            b.tapped = { show(tab) }
            bar.addView(b)
            barButtons.add(b)
        }
        view.addView(content)
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        val w = view.rectWidth(); val h = view.rectHeight()
        if (!this::tabBar.isInitialized) return
        val bar = tabBar
        val barH = 58f
        bar.frame = CGRect(0f, h - barH - view.safeAreaInsets.bottom, w, barH)
        val bw = w / Tab.entries.size
        for ((i, b) in barButtons.withIndex()) b.frame = CGRect(bw * i, 0f, bw, barH)
        content.frame = CGRect(0f, 0f, w, h - barH - view.safeAreaInsets.bottom)
        current?.let {
            it.frame = CGRect(0f, 0f, content.rectWidth(), content.rectHeight())
            (it as? Relayout)?.relayout()
            it.postLayout?.invoke(content.rectWidth())
            it.postLayout2?.invoke(content.rectWidth())
        }
    }

    interface Relayout { fun relayout() }

    // MARK: - tab switching

    private fun show(tab: Tab) {
        selectedTab = tab
        for ((i, b) in barButtons.withIndex()) b.on = i == tab.ordinal
        tabChild?.let { ch -> ch.view.removeFromSuperview() }
        tabChild = null
        current?.removeFromSuperview()
        val v = when (tab) {
            Tab.projects -> buildProjects()
            Tab.account -> buildAccount()
            Tab.tools -> buildTools()
            Tab.community -> buildCommunity()
            Tab.extras -> buildExtras()
        }
        content.addView(v)
        v.frame = CGRect(0f, 0f, content.rectWidth(), content.rectHeight())
        current = v
        (v as? Relayout)?.relayout()
    }

    private fun languageChanged() {
        for ((i, b) in barButtons.withIndex()) {
            val tab = Tab.entries.getOrNull(i) ?: continue
            b.setLabel(kerned(L10n.tr(tab.label), 9f, semibold = true, kern = 1.0f))
        }
        show(selectedTab)
    }

    // MARK: - Projects tab ("My Playground")

    private inner class ProjectsTab : UiView(com.saiki.motion.uikit.appContext!!), Relayout {
        val scroll = capScrollOf(context)
        val stack = UiView(context)
        val importBtn = HomeBigButton()
        val newBtn = HomeBigButton()
        val wordmark = UILabel()
        val header = UILabel()
        var pendingDivider: UiView? = null

        init {
            setBackgroundColor(C.BG)
            wordmark.attributedText = kerned("SAIKI MOTION", 12f, bold = true, kern = 2.2f)
            wordmark.textColor = argbToUIColor(C.GREEN)
            wordmark.font = boldFont(12f)
            val metalLP = UILongPressGestureRecognizer { g -> if (g.state == com.saiki.motion.uikit.UIGestureRecognizerState.began) metalDebugPressed() }
            metalLP.minimumPressDuration = 2.0
            wordmark.addGestureRecognizer(metalLP)
            wordmark.isUserInteractionEnabled = true
            addView(wordmark)
            header.text = "My Playground"
            header.font = com.saiki.motion.uikit.UIFont.boldSystemFont(27f)
            header.textColor = argbToUIColor(C.TEXT)
            addView(header)
            headerLabel = header
            val count = UILabel()
            count.font = sysFont(12f)
            count.textColor = argbToUIColor(C.DIM)
            count.textAlignment = TA.right
            addView(count)
            countLabel = count
            addView(scroll)
            scroll.addView(stack)
            importBtn.attributedTitle = kerned("IMPORT PROJECT FILE", 13f, bold = true)
            importBtn.bg = 0xFF14351F.toInt()      // dark green (green-editor theme)
            importBtn.fg = C.GREEN
            importBtn.icon = "import"
            importBtn.tapped = { pickProjectFile() }
            addView(importBtn)
            newBtn.attributedTitle = kerned(L10n.tr("New project"), 15f, bold = true)
            newBtn.bg = C.GREEN
            newBtn.fg = C.ONDARK
            newBtn.icon = "plus"
            newBtn.tapped = { showNewDialog() }
            addView(newBtn)
            val divider = UiView(context)
            divider.setBackgroundColor(C.LINE)
            addView(divider)
            pendingDivider = divider
        }

        override fun relayout() {
            val w = rectWidth(); val h = rectHeight()
            val top = 16f + viewSafeTop
            wordmark.frame = CGRect(pad, top, w / 2, 16f)
            header.frame = CGRect(pad, top + 18f, w / 2, 32f)
            countLabel?.frame = CGRect(w / 2, top + 26f, w / 2 - pad, 16f)
            val newBtnBottom = h - 12f
            newBtn.frame = CGRect(pad, newBtnBottom - 46f, w - 2 * pad, 46f)
            importBtn.frame = CGRect(pad, newBtn.frame.minY - 10f - 46f, w - 2 * pad, 46f)
            pendingDivider?.frame = CGRect(0f, h - 0.5f, w, 0.5f)
            scroll.frame = CGRect(0f, header.frame.maxY + 10f, w, importBtn.frame.minY - 12f - (header.frame.maxY + 10f))
            stack.frame = CGRect(pad, 4f, w - 2 * pad, 0f)
            refresh()
        }
    }

    private val viewSafeTop: Float get() = 0f   // fullscreen theme: no system bar inset

    private fun buildProjects(): UiView {
        val v = ProjectsTab()
        wrapView = v
        folderList = v.stack
        return v
    }

    /** Total bytes used by the store (projects + media + user SDK effects). Metadata only. */
    private fun storeBytes(): Long {
        var total = 0L
        val en = Projects.root.walkTopDown()
        for (f in en) total += f.length()
        return total
    }

    private fun setScrollContent(v: UiView, w: Float, h: Float) {
        val sc = v.parent as? com.saiki.motion.uikit.UIScrollView ?: return
        sc.contentSize = com.saiki.motion.uikit.CGSize(w, h)
        v.frame = CGRect(0f, 0f, w, h)
    }

    /** Rebuilds the project card list + stats (the original's refresh()). */
    private fun refresh() {
        projects = Projects.list()
        val mb = storeBytes() / 1048576.0
        val stats = "${projects.count()} ${L10n.tr("projects")} · " +
            String.format(Locale.US, "%.1f", mb) + " MB ${L10n.tr("on device")}"
        val stack = folderList ?: return
        val count = countLabel
        stack.subviews.forEach { it.removeFromSuperview() }

        if (projects.isEmpty()) {
            count?.text = null
            var y = 24f
            val chibi = ChibiView(0)
            chibi.frame = CGRect(0f, y, stack.rectWidth().coerceAtLeast(1f), 230f)
            stack.addView(chibi); y += 230f
            val lines = listOf(
                Triple("Hmm... nothing here yet.", 14f, C.GREEN),
                Triple(L10n.tr("No projects yet. Tap NEW PROJECT to start."), 13f, C.DIM),
                Triple(stats, 12f, C.DIM))
            for ((t, sz, col) in lines) {
                val l = MLText(t, sz, col, bold = (col == C.GREEN))
                l.build(stack.rectWidth().coerceAtLeast(1f))
                l.frame = CGRect(0f, y, stack.rectWidth().coerceAtLeast(1f), l.height())
                stack.addView(l); y += l.height() + 4f
            }
            val sw = stack.rectWidth().coerceAtLeast(1f)
            setScrollContent(stack, sw, y)
            return
        }

        count?.text = stats
        if (openFolder != null && Folders.all.none { it.id == openFolder }) openFolder = null
        headerLabel?.text = openFolder?.let { Folders.name(it) } ?: "My Playground"
        var y = 4f
        val w = stack.rectWidth().coerceAtLeast(1f)
        if (openFolder != null) {
            val back = PillButton("All projects", "chev_left", C.CARD2, C.TEXT)
            back.onClick = { openFolder = null; refresh() }
            back.frame = CGRect(0f, y, w, 40f); stack.addView(back); y += 50f
            val inside = projects.withIndex().filter { Folders.folderOf(it.value.id) == openFolder }
            if (inside.isEmpty()) {
                val l = MLText("This folder is empty. Use Move to folder on a project.", 13f, C.DIM)
                l.build(w); l.frame = CGRect(0f, y, w, l.height()); stack.addView(l); y += l.height() + 6f
            }
            for ((i, p) in inside) { val r = projectRow(i, p); r.frame = CGRect(0f, y, w, rowH(r)); stack.addView(r); y += rowH(r) + 10f }
        } else {
            val newF = PillButton("New folder", "folder_plus", C.CARD2, C.TEXT)
            newF.onClick = { showNewFolder() }
            newF.frame = CGRect(0f, y, w, 40f); stack.addView(newF); y += 50f
            for (f in Folders.all) { val r = folderRow(f); r.frame = CGRect(0f, y, w, rowH(r)); stack.addView(r); y += rowH(r) + 10f }
            for ((i, p) in projects.withIndex()) {
                if (Folders.folderOf(p.id) == null) {
                    val r = projectRow(i, p); r.frame = CGRect(0f, y, w, rowH(r)); stack.addView(r); y += rowH(r) + 10f
                }
            }
        }
            setScrollContent(stack, w, y + 16f)
    }

    private fun rowH(v: UiView): Float = if (v.rectHeight() > 0f) v.rectHeight() else 76f

    // MARK: - folders

    private fun folderRow(f: ProjectFolder): UiView {
        val card = TapView()
        card.setBackgroundColor(C.CARD)
        val name = UILabel()
        name.text = f.name
        name.font = com.saiki.motion.uikit.UIFont.semiboldSystemFont(16f)
        name.textColor = argbToUIColor(C.TEXT)
        card.addView(name)
        val n = Folders.count(f.id)
        val meta = UILabel()
        meta.text = "$n project" + (if (n == 1) "" else "s")
        meta.font = sysFont(12f)
        meta.textColor = argbToUIColor(C.DIM)
        card.addView(meta)
        val dots = ToolIconDots()
        dots.onClick = { showFolderMenu(f) }
        card.addView(dots)
        card.drawBlock = { c ->
            val cg = UIGraphics.getCurrentContext()!!
            Icons.draw(cg, "folder", 14f + 17f, 76f / 2, 34f, C.GREEN)
        }
        dots.frame = CGRect(0f, 0f, 40f, 40f)
        name.frame = CGRect(60f, 14f, 0f, 20f)
        meta.frame = CGRect(60f, 37f, 0f, 16f)
        card.onClick = { openFolder = f.id; refresh() }
        // layout in relayout via drawBlock? keep it simple: size once measured
        card.postLayout = { w ->
            name.frame = CGRect(60f, 14f, w - 60f - 48f, 20f)
            meta.frame = CGRect(60f, 37f, w - 60f - 48f, 16f)
            dots.frame = CGRect(w - 44f, (76f - 40f) / 2, 40f, 40f)
            name.setNeedsDisplay(); meta.setNeedsDisplay()
        }
        return card
    }

    private fun showFolderMenu(f: ProjectFolder) {
        Dlg(this).setIconItems(listOf("Rename folder", "Delete folder"), listOf("edit", "trash")) { _, which ->
            if (which == 0) {
                val field = makeField(f.name)
                Dlg(this).setTitle("Rename folder").setView(field)
                    .setPositiveButton("OK") { _, _ ->
                        val nm = field.text.trim()
                        if (nm.isNotEmpty()) Folders.rename(f.id, nm)
                        refresh()
                    }.setNegativeButton("Cancel", null).show()
            } else {
                Dlg(this).setTitle("Delete folder?")
                    .setMessage("\"${f.name}\" is removed. Its projects are kept and move back to the main list.")
                    .setPositiveButton("Delete") { _, _ -> Folders.delete(f.id); refresh() }
                    .setNegativeButton("Cancel", null).show()
            }
        }.show()
    }

    private fun showNewFolder(project: Project? = null) {
        val field = makeField("New folder")
        Dlg(this).setTitle("New folder").setView(field)
            .setPositiveButton("Create") { _, _ ->
                val nm = field.text.trim()
                if (nm.isEmpty()) return@setPositiveButton
                val f = Folders.create(nm)
                if (project != null) Folders.move(project.id, f.id)
                refresh()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showMoveDialog(p: Project) {
        val fs = Folders.all
        val labels = fs.map { it.name }.toMutableList()
        val icons = MutableList(fs.size) { "folder" }
        labels.add("New folder…"); icons.add("folder_plus")
        if (Folders.folderOf(p.id) != null) { labels.add("Remove from folder"); icons.add("close") }
        Dlg(this).setTitle("Move to folder").setIconItems(labels, icons) { _, which ->
            if (which < fs.count()) { Folders.move(p.id, fs[which].id); refresh() }
            else if (which == fs.count()) showNewFolder(p)
            else { Folders.move(p.id, null); refresh() }
        }.show()
    }

    /** One project card. Tap opens the editor; the dots open Rename/Duplicate/Delete/Export. */
    private fun projectRow(index: Int, info: Project): UiView {
        val card = TapView()
        card.setBackgroundColor(C.CARD)
        val dots = ToolIconDots()
        dots.onClick = { showDotsMenu(info) }
        card.addView(dots)
        card.tag = 200 + index
        // thumb: jpg from the store, else the film icon
        val thumbBmp = try { BitmapFactory.decodeFile(Projects.thumbFile(info.id).path) } catch (_: Exception) { null }
        val bmp = thumbBmp
        card.drawBlock = { c ->
            val cg = UIGraphics.getCurrentContext()!!
            // thumbnail 96x56 rounded 8
            c.save()
            val clip = com.saiki.motion.uikit.UIBezierPath(CGRect(10f, 10f, 96f, 56f), cornerRadius = 8f)
            cg.addPath(clip.cgPath); cg.clipPath()
            if (bmp != null) {
                val s = maxOf(96f / bmp.width, 56f / bmp.height)
                c.drawBitmap(bmp, null, android.graphics.RectF(10f + (96f - bmp.width * s) / 2, 10f + (56f - bmp.height * s) / 2,
                    10f + (96f + bmp.width * s) / 2, 10f + (56f + bmp.height * s) / 2),
                    android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
            } else {
                Icons.draw(cg, "film", 10f + 48f, 10f + 28f, 26f, C.DIM)
            }
            c.restore()
        }
        card.onClick = {
            // iOS rowTapped: the 3-dot corner opens the dots menu, not the project
            val p0 = card.lastTouchLocation
            if (!(p0.x > card.frame.width - 48f && p0.y < 52f)) open(info)
        }
        val long = UILongPressGestureRecognizer { g -> if (g.state == com.saiki.motion.uikit.UIGestureRecognizerState.began) showMenu(info) }
        long.minimumPressDuration = 0.35
        card.addGestureRecognizer(long)
        card.postLayout = { w ->
            dots.frame = CGRect(w - 44f, 4f, 40f, 40f)
            val name = card.subviews.firstOrNull { it is UILabel && (it as UILabel).text == info.name } as? UILabel
            name?.frame = CGRect(118f, 14f, w - 118f - 92f, 20f)
            val meta = card.subviews.firstOrNull { it is UILabel && (it as UILabel).text == Projects.resLabel(info) } as? UILabel
            meta?.frame = CGRect(118f, 37f, w - 118f - 92f, 16f)
            val date = card.subviews.firstOrNull { it is UILabel && (it as UILabel).font.size == 11f } as? UILabel
            date?.frame = CGRect(w - 92f - 70f, 14f, 70f, 14f)
        }
        // labels (kept as subviews for the postLayout pass above)
        val name = UILabel(); name.text = info.name
        name.font = com.saiki.motion.uikit.UIFont.semiboldSystemFont(16f); name.textColor = argbToUIColor(C.TEXT)
        card.addView(name)
        val meta = UILabel(); meta.text = Projects.resLabel(info)
        meta.font = sysFont(12f); meta.textColor = argbToUIColor(C.DIM)
        card.addView(meta)
        val date = UILabel(); date.text = relativeDate(info.updatedAt)
        date.font = sysFont(11f); date.textColor = argbToUIColor(C.DIM)
        card.addView(date)
        return card
    }

    private fun open(project: Project) {
        CrashLog.note("open_project")
        pushScreen(EditorViewController(projectId = project.id), animated = true)
    }

    private fun metalDebugPressed() {
        // iOS: MetalDebug.present(from:) — the Metal debug panel is intentionally not ported (CONVENTIONS rule 10).
    }

    // MARK: - dialogs

    private fun showNewDialog() {
        var res = 1        // 0: 720p, 1: 1080p, 2: 1440p
        val aspectChips = com.saiki.motion.ui.AspectChips(com.saiki.motion.uikit.appContext!!, 0)   // presets + Custom
        var fps = 1        // 0: 24, 1: 30, 2: 60
        val fpsOptions = listOf(24, 30, 60)

        val defaultName = "Project ${projects.count() + 1}"
        val field = makeField(defaultName)

        fun dims(): Pair<Int, Int> = com.saiki.motion.ui.AspectPresets.dims(base = listOf(720, 1080, 1440)[res], ratio = aspectChips.ratio)

        val col = NewProjectSheet(field, aspectChips, { res = it }, { fps = it }, { listOf("720p", "1080p", "1440p") }, { listOf("24 fps", "30 fps", "60 fps") }, { fps })

        Dlg(this)
            .setTitle(L10n.tr("New Project"))
            .setView(col)
            .setPositiveButton(L10n.tr("Create")) { _, _ ->
                var name = field.text.trim()
                if (name.isEmpty()) name = defaultName
                val (w, h) = dims()
                val project = Project(name = name, w = w, h = h, fps = fpsOptions[fps])
                Projects.save(project)
                refresh()
                open(project)
            }
            .setNegativeButton(L10n.tr("Cancel"), null)
            .show()
    }

    /** Long-press menu on a project card. */
    private fun showMenu(p: Project) {
        Dlg(this)
            .setIconItems(listOf(L10n.tr("Rename project"), L10n.tr("Duplicate"),
                L10n.tr("Delete project?"), L10n.tr("Export project file"), "Overwrite from file", "Move to folder"),
                listOf("edit", "dup", "trash", "export", "export", "folder")) { _, which ->
                when (which) {
                    0 -> showRename(p)
                    1 -> { Projects.duplicate(p.id); refresh() }
                    2 -> confirmDelete(p)
                    3 -> showExportDialog(p)
                    4 -> { overwriteTarget = p; pickProjectFile() }
                    5 -> showMoveDialog(p)
                }
            }
            .show()
    }

    private fun showRename(p: Project) {
        val field = makeField(p.name)
        Dlg(this)
            .setTitle(L10n.tr("Rename project"))
            .setView(field)
            .setPositiveButton(L10n.tr("OK")) { _, _ ->
                val name = field.text.trim()
                if (name.isNotEmpty()) Projects.rename(p.id, name)
                refresh()
            }
            .setNegativeButton(L10n.tr("Cancel"), null)
            .show()
    }

    private fun confirmDelete(p: Project) {
        Dlg(this)
            .setTitle(L10n.tr("Delete project?"))
            .setMessage("\"${p.name}\"")
            .setPositiveButton(L10n.tr("Delete")) { _, _ ->
                Projects.delete(p.id)
                refresh()
            }
            .setNegativeButton(L10n.tr("Cancel"), null)
            .show()
    }

    /** The card's 3-dot menu: same six items as the long-press menu. */
    private fun showDotsMenu(p: Project) = showMenu(p)

    /** Export sheet: plain project file, or a self-contained .saikiproject with "Include media" on. */
    private fun showExportDialog(p: Project) {
        val withMedia = booleanArrayOf(false)
        val row = object : TapView() {
            var on = false
            override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                drawText("Include media", 14f, 20f, color = C.TEXT, size = 15f, bold = true, align = TA.left)
                val sub = MLText("Off: project file (.json) only.\nOn: one .saikiproject with all media inside.", 12f, C.DIM)
                sub.build(rect.width - 62f); sub.frame = CGRect(0f, 24f, rect.width - 62f, sub.height()); sub.draw(rect)
                // switch
                val sw = 50f; val sh = 28f; val x1 = rect.width - 14f; val x0 = x1 - sw; val y0 = rect.midY - sh / 2
                fillRoundRect(c, CGRect(x0, y0, sw, sh), sh / 2, if (on) C.GREEN else 0xFF3A3A44.toInt())
                com.saiki.motion.ui.fillCircle(c, if (on) x1 - sh / 2 else x0 + sh / 2, y0 + sh / 2, sh / 2 - 3f, 0xFFFFFFFF.toInt())
            }
        }
        row.onClick = { row.on = !row.on; withMedia[0] = row.on; row.setNeedsDisplay() }

        Dlg(this)
            .setTitle(L10n.tr("Export project file"))
            .setMessage("\"${p.name}\"")
            .setView(row)
            .setPositiveButton("Export") { _, _ ->
                if (!withMedia[0]) {
                    showExport(p)
                    return@setPositiveButton
                }
                toast("Packing project…")
                Thread {
                    val url = ProjectArchive.export(p.id)
                    com.saiki.motion.uikit.UIGraphics.getCurrentContext()   // no-op touch
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        if (url != null) shareFile(url) else toast("Export failed")
                    }
                }.start()
            }
            .setNegativeButton(L10n.tr("Cancel"), null)
            .show()
    }

    /** Shares the plain project JSON (named after the project, not its id). */
    private fun showExport(info: Project) {
        val safe = info.name.replace(Regex("[/\\\\:*?\"<>|]"), "_")
        val act = currentActivity?.get() ?: return
        val cacheDir = File(act.cacheDir, "share").apply { mkdirs() }
        val tmp = File(cacheDir, (if (safe.isEmpty()) "project" else safe) + ".json")
        try { tmp.delete() } catch (_: Exception) {}
        try { Projects.exportFile(info.id).copyTo(tmp, overwrite = true) } catch (_: Exception) {}
        shareFile(tmp)
    }

    private fun shareFile(url: File) {
        val act = currentActivity?.get() ?: return
        val share = Intent(Intent.ACTION_SEND)
        share.type = when (url.extension.lowercase()) {
            "json" -> "application/json"
            "saikiproject" -> "application/octet-stream"
            else -> "application/octet-stream"
        }
        share.putExtra(Intent.EXTRA_STREAM, android.net.Uri.parse("file://" + url.absolutePath))
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        act.startActivity(Intent.createChooser(share, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** The name input used by New / Rename (the original's makeField). */
    private fun makeField(initial: String): com.saiki.motion.uikit.UITextField {
        val f = com.saiki.motion.uikit.UITextField()
        f.text = initial
        f.placeholder = L10n.tr("New Project")
        f.font = sysFont(15f)
        f.textColor = argbToUIColor(C.TEXT)
        f.backing.setBackgroundColor(C.CARD2)
        f.backing.setPadding(12, 0, 12, 0)
        f.backing.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, 15f)
        f.frame = CGRect(0f, 0f, 0f, 40f)
        return f
    }

    // MARK: - import

    private var overwriteTarget: Project? = null

    private fun pickProjectFile() {
        DocPicker.pick { url ->
            val target = overwriteTarget
            if (target != null) {
                overwriteTarget = null
                confirmOverwrite(target, url)
                return@pick
            }
            if (Projects.importFile(url) != null) {
                refresh()
                toast(L10n.tr("Import") + " · " + Projects.lastImportNote)
            } else {
                toast("Not a SaikiMotion project file")
            }
        }
    }

    // MARK: - What's New

    private fun maybeShowWelcome() {
        if (Prefs.getBool("hideWelcome", false)) return
        val w = WelcomeViewController()
        present(w, animated = true)
    }

    // MARK: - other tabs

    private fun cardView(): Pair<UiView, UiView> {
        // scrollable: long tabs (Extras) used to run past the screen and over the tab bar
        val wrap = capScrollOf(com.saiki.motion.uikit.appContext!!)
        wrap.showsVerticalScrollIndicator = false
        val stack = UiView(wrap.context)
        wrap.addView(stack)
        wrap.postLayout = { w -> stack.frame = CGRect(pad, 18f, w - 2 * pad, stack.rectHeight()) }
        return wrap to stack
    }

    private fun tabHeader(text: String): MLText {
        val l = MLText(kernedString(text, 24f, bold = true), 24f, C.TEXT, bold = true)
        return l
    }

    private fun infoCard(title: String, lines: List<String>): MLText {
        // one text block: green kerned title + body lines (matching the iOS card visually)
        val sb = StringBuilder()
        sb.append(title.uppercase())
        for (ln in lines) sb.append("\n").append(ln)
        return MLText(sb.toString(), 13f, C.DIM)
    }

    private fun buildAccount(): UiView {
        val (wrap, stack) = cardView()
        stack.addView(tabHeader(L10n.tr("Account")))
        stack.addView(infoCard("SaikiMotion", listOf(
            "${L10n.tr("Version")}: ${AppInfo.displayVersion}",
            AppInfo.bundleId,
            L10n.tr("Offline notice"))))
        wrap.postLayout2 = { w ->
            layoutInfoStack(stack, w - 2 * pad)
        }
        return wrap
    }

    private fun layoutInfoStack(stack: UiView, w: Float) {
        var y = 0f
        for (v in stack.subviews) {
            when (v) {
                is MLText -> { v.build(w); v.frame = CGRect(0f, y, w, v.height()); y += v.height() + 12f }
                is TapView -> { v.frame = CGRect(0f, y, w, v.rectHeight().coerceAtLeast(40f)); y += v.rectHeight() + 12f }
                else -> { v.frame = CGRect(0f, y, w, 40f); y += 52f }
            }
        }
        setScrollContent(stack, w, y)
    }

    // MARK: - Tools tab

    private fun buildTools(): UiView {
        val (wrap, stack) = cardView()
        stack.addView(tabHeader(L10n.tr("Tools")))
        stack.addView(toolCard(
            "Anime Decomposition",
            "Split an anime character into head, eyes, eyelids, hair strands, body parts, clothes and line art, right on your phone. " +
                "Layers come auto-grouped. Export as PSD, as an image, or straight into a new project.",
            "anime") { pushScreen(AnimeDecomposeViewController(), animated = true) })
        stack.addView(toolCard(
            "Drawing Editor",
            "Paint, smudge and erase on layers with folders, just like a drawing app. Hold the canvas to pick a color. " +
                "Anime Decomposition can send its layers here, and any drawing can be sent into a video project.",
            "edit") { pushScreen(DrawingGalleryViewController(), animated = true) })
        wrap.postLayout2 = { w ->
            var y = 0f
            for (v in stack.subviews) {
                if (v is MLText) { v.build(w); v.frame = CGRect(0f, y, w, v.height()); y += v.height() + 12f }
                else if (v is ToolCardView) { v.frame = CGRect(0f, y, w, v.cardHeight(w)); v.layoutCard(w); y += v.cardHeight(w) + 12f }
            }
            setScrollContent(stack, w, y)
        }
        return wrap
    }

    /** One tappable tool entry: orange icon badge, title, description underneath. */
    private fun toolCard(title: String, desc: String, icon: String, open: () -> Unit): UiView {
        val card = ToolCardView()
        card.onClick = open
        card.setBackgroundColor(C.CARD)
        card.badgeIcon = icon
        card.titleText = title
        card.descText = desc
        return card
    }

    private fun buildCommunity(): UiView {
        val wrap = UiView(com.saiki.motion.uikit.appContext!!)
        val header = tabHeader(L10n.tr("Community"))
        wrap.addView(header)
        // the bundled SDK example effects (the real defs, read-only)
        val gallery = EffectsGalleryViewController(EffectsGalleryViewController.Mode.browse)
        gallery.loadViewIfNeeded()
        gallery.view.frame = CGRect(0f, 0f, 10f, 10f)
        wrap.addView(gallery.view)
        tabChild = gallery
        wrap.postLayout = { w ->
            header.build(w - pad); header.frame = CGRect(pad, 14f, w - pad, header.height())
            gallery.view.frame = CGRect(0f, header.frame.maxY + 8f, w, wrap.rectHeight() - header.frame.maxY - 8f)
            gallery.viewDidLayoutSubviews()
        }
        return wrap
    }

    private fun buildExtras(): UiView {
        val (wrap, stack) = cardView()
        val header = tabHeader(L10n.tr("Extras"))
        val crashInfo = infoCard(L10n.tr("Crash reports"), listOf(
            "${CrashLog.reportCount()} ${L10n.tr("in the Crash folder of this app")}",
            "${EffectCrashLog.count()} effects with crash/freeze logs"))
        val crashBtn = textButton("Open crash logs", C.GREEN)
        crashBtn.onClick = {
            pushScreen(com.saiki.motion.ui.CrashBrowserViewController(null), animated = true)
        }
        val cacheCard = CacheCard()
        val helpCard = HelpCard()
        val langCard = LangCard()
        stack.addView(header); stack.addView(crashInfo); stack.addView(crashBtn)
        stack.addView(cacheCard); stack.addView(helpCard); stack.addView(langCard)
        val cap = { t: String -> MLText(kernedString(t, 11f, semibold = true, kern = 1.4f), 11f, C.DIM, bold = true) }
        wrap.postLayout2 = { w ->
            val iw = w - 2 * pad
            var y = 0f
            fun add(v: UiView, h: Float) { v.frame = CGRect(0f, y, iw, h); y += h + 6f }
            header.build(iw); add(header, header.height())
            // Help section
            add(cap("Help"), 14f)
            add(helpCard, helpCard.height(iw)); helpCard.layoutCard(iw)
            y += 16f
            // Rendering
            add(cap("Rendering"), 14f)
            add(cacheCard, cacheCard.height(iw)); cacheCard.layoutCard(iw)
            y += 16f
            // Language
            add(cap("Language"), 14f)
            add(langCard, langCard.height(iw)); langCard.layoutCard(iw)
            y += 16f
            // Diagnostics
            add(cap("Diagnostics"), 14f)
            crashInfo.build(iw); add(crashInfo, crashInfo.height())
            crashBtn.frame = CGRect(0f, y, iw, 40f); y += 40f + 6f
            setScrollContent(stack, iw, y)
        }
        return wrap
    }

    private fun textButton(t: String, color: Int): TapView {
        val b = object : TapView() {
            override fun draw(rect: CGRect) {
                drawText(t, 14f, rect.midY + 5f, color = color, size = 15f, bold = true, align = TA.left)
            }
        }
        return b
    }

    // MARK: - helpers

    /** Uppercase letter-spaced text — the original's kerned() helper. */
    private fun kerned(s: String, size: CGFloat, bold: Boolean = false, semibold: Boolean = false, kern: CGFloat = 1.6f): com.saiki.motion.uikit.NSAttributedString {
        return com.saiki.motion.uikit.NSAttributedString(s.uppercase(), mapOf(
            "kern" to kern,
            "font" to com.saiki.motion.uikit.UIFont.systemFont(size, if (semibold) 600 else if (bold) 700 else 500),
        ))
    }

    private fun kernedString(s: String, size: CGFloat, bold: Boolean = false, semibold: Boolean = false, kern: CGFloat = 1.6f): String = s.uppercase()

    private fun relativeDate(d: Long): String {
        val diff = (System.currentTimeMillis() - d) / 1000L
        return when {
            diff < 60 -> "now"
            diff < 3600 -> "${diff / 60}m ago"
            diff < 86400 -> "${diff / 3600}h ago"
            diff < 86400 * 7 -> "${diff / 86400}d ago"
            else -> SimpleDateFormat("MM/dd/yy", Locale.US).format(Date(d))
        }
    }

    fun toast(text: String) {
        val window = appKeyWindow() ?: return
        val l = MLText("  $text  ", 13f, C.TEXT)
        val w = window.rectWidth()
        l.build((w - 48f).coerceAtLeast(40f))
        val lw = minOf(l.height() + 28f, w - 48f)
        val lbl = object : UiView(window.context) {
            override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                fillRoundRect(c, rect, 14f, 0xB8000000.toInt())
                drawText(text, rect.midX, rect.midY + 5f, color = C.TEXT, size = 13f, bold = false, align = TA.center)
            }
        }
        lbl.frame = CGRect((w - lw) / 2, window.rectHeight() - view.safeAreaInsets.bottom - 90f - 34f, lw, 34f)
        window.addSubview(lbl)
        lbl.animate().alpha(0f).setDuration(250).setStartDelay(1800).withEndAction { lbl.removeFromSuperview() }.start()
    }

    // MARK: - overwrite a project from a file

    private fun confirmOverwrite(p: Project, url: android.net.Uri) {
        val isArc = ProjectArchive.isArchive(url)
        var withMedia = true
        var content: UiView? = null
        if (isArc) {
            val row = object : TapView() {
                var on = true
                override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    drawText("Include media", 14f, 20f, color = C.TEXT, size = 15f, bold = true, align = TA.left)
                    val sub = MLText("On: take the media inside the file.\nOff: keep this project's current media.", 12f, C.DIM)
                    sub.build(rect.width - 62f); sub.draw(CGRect(0f, 24f, 0f, 0f))
                    val sw = 50f; val sh = 28f; val x1 = rect.width - 14f; val x0 = x1 - sw; val y0 = rect.midY - sh / 2
                    fillRoundRect(c, CGRect(x0, y0, sw, sh), sh / 2, if (on) C.GREEN else 0xFF3A3A44.toInt())
                    com.saiki.motion.ui.fillCircle(c, if (on) x1 - sh / 2 else x0 + sh / 2, y0 + sh / 2, sh / 2 - 3f, 0xFFFFFFFF.toInt())
                }
            }
            row.onClick = { row.on = !row.on; withMedia = row.on; row.setNeedsDisplay() }
            content = row
        }
        val d = Dlg(this)
            .setTitle("Overwrite project?")
            .setMessage("\"${p.name}\" will be replaced by the contents of \"${url.lastPathSegment?.substringAfterLast('/') ?: ""}\". This can't be undone.")
        if (content != null) d.setView(content)
        d.setPositiveButton("Overwrite") { _, _ ->
            if (Projects.overwrite(p.id, url, withMedia) != null) {
                refresh()
                toast("Overwritten · " + Projects.lastImportNote)
            } else {
                toast("Couldn't overwrite: not a SaikiMotion project file")
            }
        }
            .setNegativeButton(L10n.tr("Cancel"), null)
            .show()
    }
}

// MARK: - small views for the Tools tab + project cards

/** A tappable card (the Tools tab entries). */
class ToolCardView : TapView() {
    var badgeIcon = ""
    var titleText = ""
    var descText = ""
    var tagText = "OPEN TOOL  ›"

    fun cardHeight(w: Float): Float {
        val desc = MLText(descText, 13f, C.DIM)
        desc.build(w - 44f - 14f - 14f)
        return 16f + 21f + 6f + desc.height + 6f + 14f + 16f
    }

    fun layoutCard(w: Float) { setNeedsDisplay() }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        com.saiki.motion.ui.fillRoundRect(c, rect, 14f, C.CARD)
        // badge
        com.saiki.motion.ui.fillRoundRect(c, CGRect(14f, 16f, 44f, 44f), 12f, C.GREEN)
        Icons.draw(c, badgeIcon, 14f + 22f, 16f + 22f, 24f, C.ONDARK)
        val colX = 14f + 44f + 14f
        val colW = rect.width - colX - 14f
        drawText(titleText, colX, 16f + 15f, color = C.TEXT, size = 17f, bold = true, align = TA.left)
        val desc = MLText(descText, 13f, C.DIM)
        desc.build(colW)
        c.canvas.save(); c.canvas.translate(colX, 16f + 21f + 6f)
        val lay = desc.layoutPublic(colW); lay.draw(c.canvas); c.canvas.restore()
        // OPEN TOOL tag
        val tagPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = C.GREEN; textSize = 11f; isFakeBoldText = true; letterSpacing = 1.4f / 11f }
        c.canvas.drawText(tagText, colX, rect.height - 16f - 4f, tagPaint)
    }
}

/** Orange rounded badge with a vector icon. */
class ToolBadgeView : UiView(com.saiki.motion.uikit.appContext!!) {
    var icon = ""
    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        com.saiki.motion.ui.fillRoundRect(c, rect, 12f, C.GREEN)
        Icons.draw(c, icon, rect.midX, rect.midY, 24f, C.ONDARK)
    }
}

/** The 3-dot button in the corner of a project card. */
class ToolIconDots : TapView() {
    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        Icons.draw(c, "more", boundsRect.midX, boundsRect.midY, 22f, if (isHighlighted) C.GREEN else C.DIM)
    }
}

// MARK: - Extras cards (render cache, help, language)

/** Render cache card: size, clear, live/pre-render switches. */
private class CacheCard : UiView(com.saiki.motion.uikit.appContext!!) {
    private val clearBtn = object : TapView() {
        override fun draw(rect: CGRect) {
            drawText("Clear cache", 0f, rect.midY + 5f, color = C.RED, size = 14f, bold = true, align = TA.left)
        }
    }
    private var sizeText = "Calculating…"
    private val liveSw = SwitchRow()
    private val preSw = SwitchRow()

    init {
        setBackgroundColor(C.CARD)
        liveSw.label = "Live render cache (render ahead in the editor)"
        liveSw.on = FrameCache.enabled
        liveSw.onToggle = { FrameCache.enabled = it }
        preSw.label = "Pre-render groups (bake groups to frames)"
        preSw.on = PreRender.enabled
        preSw.onToggle = { PreRender.enabled = it }
        addView(liveSw); addView(preSw); addView(clearBtn)
        Thread {
            val t = FrameCache.sizeText()
            android.os.Handler(android.os.Looper.getMainLooper()).post { sizeText = "Using $t — projects are not affected"; setNeedsDisplay() }
        }.start()
        clearBtn.onClick = {
            sizeText = "Clearing…"; setNeedsDisplay()
            Thread {
                FrameCache.clearAll()
                val t = FrameCache.sizeText()
                android.os.Handler(android.os.Looper.getMainLooper()).post { sizeText = "Using $t — projects are not affected"; setNeedsDisplay() }
            }.start()
        }
    }

    fun height(w: Float): Float = 14f + 19f + 6f + 16f + 6f + 44f + 44f + 6f + 20f + 8f

    fun layoutCard(w: Float) {
        liveSw.frame = CGRect(0f, 14f + 19f + 6f + 16f + 6f, w, 44f)
        preSw.frame = CGRect(0f, liveSw.frame.maxY, w, 44f)
        clearBtn.frame = CGRect(0f, preSw.frame.maxY + 6f, w, 20f)
        setNeedsDisplay()
    }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        drawText("Render cache", 14f, 14f + 12f, color = C.TEXT, size = 15f, bold = true, align = TA.left)
        drawText(sizeText, 14f, 14f + 19f + 6f + 12f, color = C.DIM, size = 13f, bold = false, align = TA.left)
    }
}

/** Help & documentation card: one row per HelpDocs topic. */
private class HelpCard : UiView(com.saiki.motion.uikit.appContext!!) {
    private val rows = ArrayList<Pair<String, TapView>>()

    init {
        setBackgroundColor(C.CARD)
        for ((name, secs) in HelpDocs.topics) {
            val b = object : TapView() {
                override fun draw(rect: CGRect) {
                    drawText(name, 0f, rect.midY + 5f, color = C.GREEN, size = 15f, bold = false, align = TA.left)
                }
            }
            val nm = name
            b.onClick = { HelpDocs.show(nm, secs) }
            rows.add(nm to b)
            addView(b)
        }
    }

    fun height(w: Float): Float = 14f + 19f + rows.size * 40f + 8f

    fun layoutCard(w: Float) {
        var y = 14f + 19f + 6f
        for ((_, b) in rows) { b.frame = CGRect(0f, y, w, 40f); y += 40f }
    }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        drawText("Help & documentation", 14f, 14f + 12f, color = C.TEXT, size = 15f, bold = true, align = TA.left)
    }
}

/** Language picker card (L10n.languages, current one marked with a bullet). */
private class LangCard : UiView(com.saiki.motion.uikit.appContext!!) {
    private val rows = ArrayList<TapView>()

    init {
        setBackgroundColor(C.CARD)
        rebuild()
    }

    private fun rebuild() {
        rows.forEach { it.removeFromSuperview() }
        rows.clear()
        for (lang in L10n.languages) {
            val on = lang.first == L10n.current
            val label = (if (on) "• " else "   ") + lang.second
            val b = object : TapView() {
                override fun draw(rect: CGRect) {
                    drawText(label, 0f, rect.midY + 5f, color = if (on) C.GREEN else C.DIM, size = 14f, bold = false, align = TA.left)
                }
            }
            val code = lang.first
            b.onClick = {
                L10n.current = code
                StoreNotification.post(StoreNotification.Name.languageChanged)
            }
            rows.add(b)
            addView(b)
        }
    }

    fun height(w: Float): Float = 8f + rows.size * 34f + 8f

    fun layoutCard(w: Float) {
        var y = 8f
        for (b in rows) { b.frame = CGRect(0f, y, w, 34f); y += 34f }
    }
}

// MARK: - New Project sheet

/** The creation sheet column: name field, Resolution pills, Aspect chips, Frame rate pills, summary. */
private class NewProjectSheet(
    val field: com.saiki.motion.uikit.UITextField,
    val aspectChips: com.saiki.motion.ui.AspectChips,
    val onRes: (Int) -> Unit,
    val onFps: (Int) -> Unit,
    val resOptions: () -> List<String>,
    val fpsOptions: () -> List<String>,
    val fpsIndex: () -> Int,
) : UiView(com.saiki.motion.uikit.appContext!!), DialogSizing {

    private var resSel = 1
    private val summary = UILabel()

    override fun dialogHeight(w: Float): Float {
        var h = 16f + 13f   // "PROJECT NAME" section
        h += 40f + 12f      // field
        h += 16f + 34f + 12f   // Resolution
        h += 16f + 130f + 12f  // Aspect chips (2 rows + custom)
        h += 16f + 34f + 12f   // Frame rate
        h += 20f
        return h
    }

    override fun dialogLayout(w: Float, h: Float) {
        var y = 0f
        field.frame = CGRect(0f, y, w, 40f); y += 40f + 12f + 16f
        fun pillRow(options: List<String>, sel: Int, cb: (Int) -> Unit): UiView {
            val row = UiView(context)
            val pw = (w - 8f * (options.size - 1)) / options.size
            for ((i, opt) in options.withIndex()) {
                val p = SegPill()
                p.title = opt
                p.on = i == sel
                p.tapped = {
                    for (q in row.subviews.filterIsInstance<SegPill>()) q.on = (q === p)
                    cb(i)
                    updateSummary()
                }
                p.frame = CGRect((pw + 8f) * i, 0f, pw, 34f)
                row.addView(p)
            }
            return row
        }
        val resRow = pillRow(resOptions(), resSel) { resSel = it; onRes(it) }
        resRow.frame = CGRect(0f, y, w, 34f); y += 34f + 12f + 16f
        addView(resRow)
        aspectChips.frame = CGRect(0f, y, w, 130f); y += 130f + 12f + 16f
        addView(aspectChips)
        aspectChips.onChange = { updateSummary() }
        val fpsRow = pillRow(fpsOptions(), fpsIndex()) { onFps(it) }
        fpsRow.frame = CGRect(0f, y, w, 34f); y += 34f + 12f
        addView(fpsRow)
        summary.frame = CGRect(0f, y, w, 18f)
        addView(summary)
        updateSummary()
    }

    private fun updateSummary() {
        val (w, h) = com.saiki.motion.ui.AspectPresets.dims(base = listOf(720, 1080, 1440)[resSel], ratio = aspectChips.ratio)
        summary.text = "$w x $h · ${fpsOptions()[fpsIndex()]} fps"
    }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        fun section(key: String, y: Float) {
            val k = com.saiki.motion.uikit.NSAttributedString(L10n.tr(key).uppercase(), mapOf(
                "kern" to 1.2f, "font" to com.saiki.motion.uikit.UIFont.semiboldSystemFont(11f)))
            drawText(k.string(), 0f, y, color = C.DIM, size = 11f, bold = true, align = TA.left)
        }
        var y = 13f
        section("Project name", y); y += 16f + 40f + 12f
        section("Resolution", y); y += 16f + 34f + 12f
        section("Aspect ratio", y); y += 16f + 130f + 12f
        section("Frame rate", y)
        summary.text?.let { drawText(it, rect.midX, rect.height - 4f, color = C.TEXT, size = 13f, bold = false, align = TA.center) }
    }
}
