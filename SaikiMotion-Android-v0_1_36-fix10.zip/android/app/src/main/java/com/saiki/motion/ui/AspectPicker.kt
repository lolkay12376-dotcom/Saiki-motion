@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.UIPinchGestureRecognizer
import com.saiki.motion.uikit.UIPanGestureRecognizer
import com.saiki.motion.uikit.UITapGestureRecognizer
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGestureRecognizer
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

// Port of Sources/UI/AspectLayout.swift — letterboxing container.
// Frames its subviews to the largest rect with the canvas aspect that fits the bounds.
// Includes the viewport zoom/pan (two fingers; moves the comp view, never the 3D space).
class AspectLayout(context: android.content.Context) : UiView(context) {

    /** width / height of the canvas (e.g. 1080/1920 = 0.5625). */
    var ratio: CGFloat = 9f / 16f
        set(v) { if (v != field) { field = v; requestLayout() } }

    init {
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        clipsToBounds = true
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        if (rectWidth() <= 1f || rectHeight() <= 1f || ratio <= 0f) return
        var w = rectWidth()
        var h = w / ratio
        if (h > rectHeight()) {
            h = rectHeight()
            w = h * ratio
        }
        val f = CGRect((rectWidth() - w) / 2, (rectHeight() - h) / 2, w, h)
        for (v in subviews) {
            v.setTransformIdentity()          // frame is only valid on an untransformed view
            v.frame = f
            v.transform = viewTransform
            (v as? OverlayView)?.syncExt()
        }
    }

    /** UIKit hitTest twin for the puppet overlay: while its ext helper is on, the overlay owns the whole
     *  visible area (pins can be tapped / dragged outside the comp rect). Android dispatches by bounds only. */
    public override fun onInterceptTouchEvent(ev: android.view.MotionEvent): Boolean {
        val ov = subviews.firstOrNull { it is OverlayView } as? OverlayView ?: return false
        if (ov.wantsExtTouch(CGPoint(ev.x - ov.frame.x, ev.y - ov.frame.y))) return true
        return false
    }

    // MARK: - viewport zoom / pan (two fingers; moves the comp view, never the 3D space)

    var zoomLocked = false      // pinch / two-finger drag ignored (2D comp view only)
    var moveLocked = false
    var zoom: CGFloat = 1f
        private set
    var pan = CGPoint(0f, 0f)
        private set
    private val resetBtn = object : TapView() {
        public override fun draw(rect: CGRect) {
            val c = com.saiki.motion.uikit.UIGraphics.getCurrentContext() ?: return
            fillRoundRect(c, rect, 14f, C.GREEN)
            drawText("$zoomPct%  ↺ Reset", rect.midX, rect.midY + 4.5f, color = 0xFF0D0D0F.toInt(), size = 12f, bold = true,
                     align = com.saiki.motion.uikit.NSTextAlignment.center)
        }
    }
    private val zoomPct: Int get() = round(zoom * 100).toInt()
    private val viewTransform: android.graphics.Matrix
        get() = android.graphics.Matrix().apply { postTranslate(pan.x, pan.y); postScale(zoom, zoom) }

    /** Two-finger pinch + drag on the comp view, a two-finger double-tap and a reset chip to go back. */
    fun enableViewportGestures(chipHost: UiView) {
        val pinch = UIPinchGestureRecognizer { g -> onPinch(g) }
        val drag = UIPanGestureRecognizer { g -> onDrag(g) }
        drag.minimumNumberOfTouches = 2; drag.maximumNumberOfTouches = 2
        val dbl = UITapGestureRecognizer { resetViewport() }
        dbl.numberOfTouchesRequired = 2; dbl.numberOfTapsRequired = 2
        for (g in listOf(pinch, drag, dbl)) { addGestureRecognizer(g) }

        resetBtn.isHidden = true
        resetBtn.onClick = { resetViewport() }
        chipHost.addSubview(resetBtn)
        resetBtn.translatesAutoresizingMaskIntoConstraints = false
        val lp = (resetBtn.layoutParams as? android.view.ViewGroup.MarginLayoutParams)
            ?: android.view.ViewGroup.MarginLayoutParams(
                android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 28)
        lp.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        lp.height = 28
        lp.topMargin = 6
        lp.marginStart = -8
        resetBtn.layoutParams = lp
    }

    private fun centre(g: UIGestureRecognizer): CGPoint {
        val p = g.location(this)
        return CGPoint(p.x - rectWidth() / 2, p.y - rectHeight() / 2)
    }

    private fun onPinch(g: UIPinchGestureRecognizer) {
        if (zoomLocked) { g.scale = 1f; return }
        if (g.state != com.saiki.motion.uikit.UIGestureRecognizerState.changed && g.state != com.saiki.motion.uikit.UIGestureRecognizerState.began) return
        val nz = min(16f, max(1f, zoom * g.scale))
        val k = nz / zoom
        val f = centre(g)                          // keep the point between the fingers fixed
        pan = CGPoint(f.x - k * (f.x - pan.x), f.y - k * (f.y - pan.y))
        zoom = nz; g.scale = 1f
        applyViewport()
    }

    private fun onDrag(g: UIPanGestureRecognizer) {
        if (moveLocked) { g.setTranslationZero(); return }
        if (g.state != com.saiki.motion.uikit.UIGestureRecognizerState.changed && g.state != com.saiki.motion.uikit.UIGestureRecognizerState.began) return
        val t = g.translation(this); g.setTranslationZero()
        pan = CGPoint(pan.x + t.x, pan.y + t.y)
        applyViewport()
    }

    fun resetViewport() {
        zoom = 1f; pan = CGPoint(0f, 0f)
        com.saiki.motion.uikit.UIViewAnimator.animate(0.2f) { applyViewport() }
    }

    private fun applyViewport() {
        // never let the comp slide fully out of view
        val mx = rectWidth() * zoom / 2; val my = rectHeight() * zoom / 2
        pan = CGPoint(min(mx, max(-mx, pan.x)), min(my, max(-my, pan.y)))
        for (v in subviews) v.transform = viewTransform
        val on = zoom > 1.01f || hypot(pan.x.toDouble(), pan.y.toDouble()) > 1.0
        resetBtn.isHidden = !on
        resetBtn.setNeedsDisplay()
    }
}

// Port of Sources/UI/AspectPicker.swift — aspect-ratio presets + the picker used by New Project.
// `base` everywhere is the SHORT side in pixels (720 / 1080 / 1440): 16:9 @1080 = 1920x1080.
object AspectPresets {
    val names = listOf("16:9", "9:16", "1:1", "4:3", "3:4", "4:5", "3:2", "2:3", "21:9")
    val ratios = doubleArrayOf(16.0 / 9, 9.0 / 16, 1.0, 4.0 / 3, 3.0 / 4, 4.0 / 5, 3.0 / 2, 2.0 / 3, 21.0 / 9)

    /** Longest edge is capped (GPU texture limits): ratio stays inside 1:4 … 4:1. */
    fun clampRatio(r: Double): Double = min(max(if (r.isFinite()) r else 1.0, 0.25), 4.0)

    /** Even pixel size for a ratio (W/H) with `base` pixels on the short side. */
    fun dims(base: Int, ratio: Double): Pair<Int, Int> {
        val r = clampRatio(ratio)
        fun even(v: Double): Int = max(2, round(v / 2).toInt() * 2)
        return if (r >= 1.0) Pair(even(base * r), even(base.toDouble()))
               else Pair(even(base.toDouble()), even(base / r))
    }

    /** Preset index that matches a canvas (within 1%), null → Custom. */
    fun match(w: Int, h: Int): Int? {
        val r = w.toDouble() / max(h, 1)
        return ratios.indexOfFirst { abs(it - r) / it < 0.01 }.takeIf { it >= 0 }
    }

    /** Parses "W" and "H" text fields (commas allowed) into a ratio. */
    fun parse(w: String?, h: String?): Double {
        fun num(s: String?): Double = (s ?: "").replace(",", ".").trim().toDoubleOrNull() ?: 1.0
        return clampRatio(num(w) / max(num(h), 0.0001))
    }

    /** Short side in pixels of an existing canvas, as a resolution index 0/1/2. */
    fun resIndex(w: Int, h: Int): Int {
        val s = min(w, h)
        return if (s >= 1300) 2 else (if (s >= 900) 1 else 0)
    }
}

/** SegPill: small selectable pill (AspectChips row member). */
class SegPill : TapView() {
    var title: String = ""
        set(v) { field = v; setNeedsDisplay() }
    var on = false
        set(v) { field = v; setNeedsDisplay() }
    var tapped: (() -> Unit)? = null

    init {
        onClick = { tapped?.invoke() }
    }

    public override fun draw(rect: CGRect) {
        val c = com.saiki.motion.uikit.UIGraphics.getCurrentContext() ?: return
        fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 8f, if (on) C.GREEN else C.CARD2)
        drawText(title, rect.midX, rect.midY + 5f, color = if (on) C.ONDARK else C.TEXT, size = 14f, bold = true,
                 align = com.saiki.motion.uikit.NSTextAlignment.center)
    }
}

/** Grid of aspect pills (+ Custom with two number fields). Lays itself out; call select() to drive it. */
class AspectChips(context: android.content.Context, selected: Int) : UiView(context) {
    private val pills = ArrayList<SegPill>()
    val wField = com.saiki.motion.uikit.UITextField(context)
    val hField = com.saiki.motion.uikit.UITextField(context)
    private var customShown = false
    var index = 0
        private set
    var onChange: (() -> Unit)? = null

    val ratio: Double
        get() = if (index < AspectPresets.ratios.size) AspectPresets.ratios[index]
                else AspectPresets.parse(wField.text, hField.text)

    init {
        index = selected
        val all = AspectPresets.names + "Custom"
        var row: ArrayList<SegPill>? = null
        val rows = ArrayList<ArrayList<SegPill>>()
        for ((i, nm) in all.withIndex()) {
            if (i % 4 == 0) { row = ArrayList(); rows.add(row) }
            val p = SegPill()
            p.title = nm
            p.on = i == selected
            p.tapped = { select(i) }
            pills.add(p)
            row?.add(p)
        }
        addSubview(object : UiView(context) {
            override fun layoutSubviews() { layoutPills(rows) }
            public override fun draw(rect: CGRect) {
                val c = com.saiki.motion.uikit.UIGraphics.getCurrentContext() ?: return
                var y = 4f
                for (r in rows) {
                    var x = 0f
                    val w = rectWidth() / 4
                    for ((j, p) in r.withIndex()) {
                        p.frame = CGRect(x + 4f, y, w - 8f, 34f)
                        x += w
                    }
                    if (r.size < 4 && r.isNotEmpty()) r[0].frame = r[0].frame   // placeholder fillers keep widths equal
                    y += 42f
                }
                if (customShown) {
                    val cw = (rectWidth() - 8f * 3 - 20f) / 2
                    wField.frame = CGRect(8f, y + 4f, cw, 38f)
                    hField.frame = CGRect(8f * 2 + cw + 20f, y + 4f, cw, 38f)
                    drawText(":", 8f + cw + 10f, y + 29f, color = C.DIM, size = 18f, bold = true,
                             align = com.saiki.motion.uikit.NSTextAlignment.center)
                    y += 46f
                }
            }
        }.also { container ->
            container.setBackgroundColor(android.graphics.Color.TRANSPARENT)
            for (p in pills) container.addSubview(p)
            container.addSubview(wField); container.addSubview(hField)
        })
        for ((f, v) in listOf(Pair(wField, "21"), Pair(hField, "9"))) {
            f.text = v
            f.numeric = true
            f.setBackgroundColor(C.CARD2)
            f.onEdit = { onChange?.invoke() }
        }
        customShown = selected >= AspectPresets.names.size
    }

    private fun layoutPills(rows: List<List<SegPill>>) {
        // handled by the container's draw (frame-based layout in one pass)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        subviews.firstOrNull()?.let { it.frame = CGRect(0f, 0f, rectWidth(), rectHeight()) }
    }

    /** Pre-fills the Custom fields (e.g. from the current canvas) and selects Custom. */
    fun setCustom(w: Int, h: Int) {
        var x = w; var y = h
        while (y != 0) { val t = x % y; x = y; y = t }
        val g = max(x, 1)
        wField.text = "${w / g}"; hField.text = "${h / g}"
        select(AspectPresets.names.size)
    }

    fun select(i: Int) {
        index = i
        for ((k, p) in pills.withIndex()) p.on = k == i
        customShown = i >= AspectPresets.names.size
        onChange?.invoke()
        setNeedsDisplay()
    }
}
