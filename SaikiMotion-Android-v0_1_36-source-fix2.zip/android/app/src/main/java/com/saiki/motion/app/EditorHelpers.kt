@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorHelpers.swift — field binding, string helpers,
// the pretty JSON writer, and the EBox/EVStack/EHStack panel layout primitives
// (the UIKit Auto-Layout stand-in used by every editor panel).

package com.saiki.motion.app

import android.graphics.Paint
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.saiki.motion.core.JSONWriter
import com.saiki.motion.core.toPretty
import com.saiki.motion.ui.C
import com.saiki.motion.ui.Dev
import com.saiki.motion.ui.RulerSlider
import com.saiki.motion.ui.TapView
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.ui.boldFont
import com.saiki.motion.ui.fillRoundRect
import com.saiki.motion.ui.sysFont
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UITextField
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.drawText
import com.saiki.motion.uikit.measureText
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

// ================================================================ layout primitives (UIKit Auto-Layout stand-in)

/** Padded wrapper with an optional explicit child size (iOS wrap()/pad() boxes + Auto-Layout constraints). */
class EBox(val child: UiView, val childW: CGFloat, val childH: CGFloat,
           val padL: CGFloat, val padT: CGFloat, val padR: CGFloat, val padB: CGFloat) : UiView(appContext!!) {
    /** EHStack: >0 → shares the leftover width (iOS UIStackView spacer / content-hugging). */
    var grow = 0f
    /** Dynamic height for width (multi-line labels). */
    var dyn: ((CGFloat) -> CGFloat)? = null

    fun boxW(): CGFloat = childW + padL + padR
    fun boxH(w: CGFloat): CGFloat = (if (childH > 0) childH else (dyn?.invoke(w) ?: 0f)) + padT + padB

    override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth() - padL - padR
        val h = if (childH > 0) childH else rectHeight() - padT - padB
        child.frame = CGRect(padL, padT, w, h)
    }
}

/** Vertical stack (iOS UIStackView axis .vertical): children framed top-to-bottom by EBox heights. */
class EVStack : UiView(appContext!!) {
    private val kids = ArrayList<UiView>()
    val arranged: List<UiView> get() = kids
    var totalH: CGFloat = 0f
        private set

    fun add(v: UiView) { kids.add(v); addSubview(v); relayout() }
    fun clear() { for (k in kids) k.removeFromSuperview(); kids.clear(); relayout() }

    fun relayout() { layoutStack() }

    override fun layoutSubviews() { super.layoutSubviews(); layoutStack() }

    private fun layoutStack() {
        val w = rectWidth()
        var y = 0f
        for (c in kids) {
            val h = (c as? EBox)?.boxH(w) ?: c.frame.height
            c.frame = CGRect(0f, y, w, max(h, 1f))
            y += h
        }
        totalH = y
    }
}

/** Horizontal stack (iOS UIStackView axis .horizontal): EBox widths left-to-right, grow boxes share the rest. */
class EHStack : UiView(appContext!!) {
    private val kids = ArrayList<UiView>()
    val arranged: List<UiView> get() = kids
    var spacing: CGFloat = 0f

    fun add(v: UiView) { kids.add(v); addSubview(v); relayout() }
    fun clear() { for (k in kids) k.removeFromSuperview(); kids.clear(); relayout() }

    fun relayout() { layoutStack() }

    override fun layoutSubviews() { super.layoutSubviews(); layoutStack() }

    private fun layoutStack() {
        val h = rectHeight()
        var fixed = 0f
        var growTotal = 0f
        for (c in kids) {
            val b = c as? EBox
            if (b != null && b.childW <= 0 && b.grow > 0) growTotal += b.grow else fixed += (b?.boxW() ?: c.rectWidth().coerceAtLeast(if (c.frame.width > 0) 44f else 44f))
        }
        var x = 0f
        var i = 0
        for (c in kids) {
            if (i > 0) x += spacing
            val b = c as? EBox
            val w: CGFloat = if (b != null && b.childW <= 0 && b.grow > 0) {
                if (growTotal > 0) max(0f, rectWidth() - fixed - spacing * (kids.size - 1)) * (b.grow / growTotal) else 0f
            } else {
                (b?.boxW() ?: max(c.rectWidth(), 44f))
            }
            c.frame = CGRect(x, 0f, w, h)
            x += w
            i++
        }
    }
}

/** Multi-line wrapping label (iOS UILabel numberOfLines = 0 inside the panels). */
class PLabel : UiView(appContext!!) {
    var text: String = ""
        set(v) { field = v; layout_ = null; setNeedsDisplay() }
    var color: Int = C.DIM
        set(v) { field = v; setNeedsDisplay() }
    var size: CGFloat = 13f
        set(v) { field = v; layout_ = null; setNeedsDisplay() }
    var bold = false
        set(v) { field = v; layout_ = null; setNeedsDisplay() }
    var singleLine = false
        set(v) { field = v; layout_ = null; setNeedsDisplay() }

    private var layout_: StaticLayout? = null

    fun height(w: CGFloat): CGFloat {
        if (text.isEmpty()) return size * 1.2f
        build(w)
        return (layout_?.height ?: 0).toFloat() + 2f
    }

    private fun build(w: CGFloat) {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = color; textSize = size; isFakeBoldText = bold }
        val ww = max(8f, w).toInt()
        val old = layout_
        if (old != null && old.width == ww && old.paint.textSize == size && old.paint.isFakeBoldText == bold) return
        layout_ = StaticLayout.Builder.obtain(text, 0, text.length, p, ww)
            .setAlignment(if (singleLine) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.12f).build()
    }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        if (text.isEmpty()) return
        build(rectWidth())
        c.canvas.save()
        c.canvas.translate(0f, 1f)
        layout_?.draw(c.canvas)
        c.canvas.restore()
    }
}

/** Touch-scrollable vertical container hosting an EVStack (iOS UIScrollView + panelList). */
class PanelScroll : UiView(appContext!!) {
    val content = EVStack()
    private var lastY = 0f
    private var downY = 0f
    private var scrolling = false

    init { addSubview(content); clipsToBounds = true }

    override fun layoutSubviews() {
        super.layoutSubviews()
        content.frame = CGRect(0f, 0f, rectWidth(), max(content.totalH, rectHeight()))
        scrollTo(panelScrollX(), min(panelScrollY(), max(0f, content.totalH - rectHeight()).toInt()))
    }

    private fun panelScrollX(): Int = 0
    private fun panelScrollY(): Int = -content.translationY.toInt()

    public override fun onInterceptTouchEvent(ev: android.view.MotionEvent): Boolean {
        when (ev.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { downY = ev.y; scrolling = false }
            android.view.MotionEvent.ACTION_MOVE -> {
                if (!scrolling && kotlin.math.abs(ev.y - downY) > 12) scrolling = true
            }
        }
        return scrolling
    }

    public override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { lastY = e.y; downY = e.y; scrolling = true }
            android.view.MotionEvent.ACTION_MOVE -> {
                val dy = e.y - lastY; lastY = e.y
                val maxY = max(0f, content.totalH - rectHeight())
                val ny = (content.translationY + dy).coerceIn(-maxY, 0f)
                content.translationY = ny
            }
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> scrolling = false
        }
        return true
    }
}

// ================================================================ EditorViewController helpers (extension-style)

/** Plain icon button factory (iOS EditorViewController.icon). */
fun EditorViewController.icon(name: String, tint: Int = C.TEXT, click: () -> Unit = {}): com.saiki.motion.ui.IconView {
    val v = com.saiki.motion.ui.IconView(name, tint)
    v.onClick = click
    return v
}

fun EditorViewController.hRow(): EHStack = EHStack()
fun EditorViewController.vStack(): EVStack = EVStack()

fun EditorViewController.spacer(): EBox {
    val b = EBox(UiView(appContext!!), 0f, 0f, 0f, 0f, 0f, 0f)
    b.grow = 1f
    return b
}

/** Wraps a view so it grows to fill the stack width (title column, icon strip). */
fun growBox(v: UiView, weight: Float = 1f): EBox {
    val b = EBox(v, 0f, 0f, 0f, 0f, 0f, 0f)
    b.grow = weight
    return b
}

fun EditorViewController.addIcon(parent: EHStack, v: com.saiki.motion.ui.IconView, w: CGFloat = 44f, h: CGFloat = 48f) {
    parent.add(EBox(v, w, h, 0f, 0f, 0f, 0f))
}

/** iOS pill() — rounded text button. */
fun EditorViewController.pill(text: String, icon: String? = null, fill: Int = C.CARD2, tc: Int = C.TEXT,
                              click: () -> Unit = {}): com.saiki.motion.ui.PillButton {
    val b = com.saiki.motion.ui.PillButton(text, icon, fill, tc)
    b.onClick = click
    return b
}

/** iOS put(parent, v, hDp, mT, mB): adds with top/bottom margins; h>0 → fixed height. */
fun EditorViewController.put(parent: UiView, v: UiView, h: CGFloat = 0f, mT: CGFloat = 3f, mB: CGFloat = 3f): UiView {
    val fixed = if (h > 0f) (if (v is RulerSlider) h * Dev.k else h) else 0f
    val box = EBox(v, 0f, fixed, 0f, mT, 0f, mB)
    (parent as? EVStack)?.add(box) ?: parent.addSubview(box)
    return v
}

/** Wraps a view in padding (Android view.setPadding / layout margins). */
fun EditorViewController.pad(v: UiView, t: CGFloat, l: CGFloat, b: CGFloat, r: CGFloat): EBox =
    EBox(v, 0f, 0f, l, t, r, b)

/** Wraps a view with explicit size + margins (Android LayoutParams with setMargins). */
fun EditorViewController.wrap(v: UiView, w: CGFloat, h: CGFloat, l: CGFloat, t: CGFloat, r: CGFloat, b: CGFloat): EBox =
    EBox(v, w, h, l, t, r, b)

/** Wrapper that pins the child to the edges but fixes the wrapper width (the 52pt side rail). */
fun EditorViewController.fixedWidth(v: UiView, w: CGFloat): EBox = EBox(v, w, 0f, 0f, 0f, 0f, 0f)

/** iOS text(parent, ...) — a wrapping dim label row. */
fun EditorViewController.text(parent: UiView, t: String, color: Int = C.DIM,
                              size: CGFloat = 13f, bold: Boolean = false): PLabel {
    val tv = PLabel()
    tv.text = t; tv.color = color; tv.size = size; tv.bold = bold
    val box = EBox(tv, 0f, 0f, 6f, 6f, 6f, 4f)
    box.dyn = { w -> tv.height(w - 12f) }
    (parent as? EVStack)?.add(box) ?: parent.addSubview(box)
    return tv
}

// ================================================================ private string/number helpers (iOS EditorHelpers.swift)

/** Attaches an editing-changed handler to a UITextField (iOS bind + EditWatcher). */
fun EditorViewController.bind(field: UITextField, handler: (String) -> Unit) {
    field.onTextChanged = handler
}

fun EditorViewController.makeField(text: String): UITextField {
    val f = UITextField()
    f.text = text
    f.textColor = argbToUIColor(C.TEXT)
    f.font = sysFont(16f)
    f.backing.setBackgroundResource(0)
    f.backing.setBackgroundColor(C.CARD2)
    f.backing.setPadding(24, 12, 24, 12)
    f.backing.setTextColor(C.TEXT)
    f.backing.textSize = 16f
    f.autocorrectionType = 0
    f.returnKeyType = com.saiki.motion.uikit.UIReturnKeyType.done
    f.onReturn = { f.backing.clearFocus() }
    return f
}

fun EditorViewController.monoFont(size: CGFloat): UIFont = UIFont.monospacedFont(size)

/** Monospaced digits for the timecode readout (top bar) so it never jiggles. */
fun EditorViewController.monoTimeFontS(size: CGFloat): UIFont = UIFont.monospacedDigitSystemFont(size)

/** Kotlin Float.toInt(): truncate toward zero, NaN → 0, saturate at Int32 bounds. */
fun EditorViewController.ktInt(v: Float): Int {
    if (v.isNaN()) return 0
    if (v >= 2147483520f) return Int.MAX_VALUE
    if (v <= -2147483520f) return Int.MIN_VALUE
    return v.toInt()
}

fun EditorViewController.cap(s: String): String =
    if (s.isEmpty()) s else s.substring(0, 1).uppercase() + s.substring(1)

/** Kotlin String.substringAfter — returns the whole string when the separator is missing. */
fun EditorViewController.afterFirst(s: String, sep: Char): String {
    val i = s.indexOf(sep)
    return if (i >= 0) s.substring(i + 1) else s
}

fun EditorViewController.afterLast(s: String, sep: Char): String {
    val i = s.lastIndexOf(sep)
    return if (i >= 0) s.substring(i + 1) else s
}

fun EditorViewController.beforeLast(s: String, sep: Char): String {
    val i = s.lastIndexOf(sep)
    return if (i >= 0) s.substring(0, i) else s
}

/** name.replace(Regex("[^A-Za-z0-9]"), "_") */
fun EditorViewController.alnum(s: String): String =
    s.map { c -> if (c.code < 128 && (c.isLetter() || c.isDigit())) c else '_' }.joinToString("")

/** org.json toString(indent) equivalent used for exported effect/preset files. */
fun EditorViewController.prettyJson(v: Any, indent: Int = 0): String = when (v) {
    is org.json.JSONObject -> v.toPretty(indent)
    is org.json.JSONArray -> v.toPretty(indent)
    is String -> "\"" + JSONWriter.escape(v) + "\""
    is Boolean -> if (v) "true" else "false"
    is Long -> v.toString()
    is Int -> v.toString()
    is Double -> JSONWriter.numberToString(v)
    is Float -> JSONWriter.numberToString(v.toDouble())
    else -> "null"
}
