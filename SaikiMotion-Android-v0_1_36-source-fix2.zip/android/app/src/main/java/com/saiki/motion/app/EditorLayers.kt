@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorLayers.swift — layer management: add/clone/copy/paste/group/split/trim/menus.

package com.saiki.motion.app

import com.saiki.motion.core.Defs
import com.saiki.motion.core.Ease
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Key
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.Lights
import com.saiki.motion.core.PreRender
import com.saiki.motion.core.Registry
import com.saiki.motion.core.ShapeKind
import com.saiki.motion.core.Track
import com.saiki.motion.ui.C
import com.saiki.motion.ui.chipRow
import com.saiki.motion.ui.shapeGrid

fun EditorViewController.addLayer(type: LayerType): Layer {
    pushUndo()
    val p = Editor.project
    val s = Editor.scene
    val id = p.nextId
    p.nextId += 1
    val nm: String = when (type) {
        LayerType.SHAPE -> "Shape"
        LayerType.TEXT -> "Text"
        LayerType.IMAGE -> "Image"
        LayerType.VIDEO -> "Video"
        LayerType.CAMERA -> "Camera"
        LayerType.NULL -> "Null"
        LayerType.MODEL -> "Model"
        LayerType.PARTICLES -> "Particles"
        LayerType.GROUP -> "Group"
        LayerType.ADJUST -> "Adjustment"
        LayerType.AUDIO -> "Audio"
        LayerType.FLARE -> "Optical Flare"
    }
    val l = Layer(id, "$nm $id", type)
    l.end = s.duration
    if (type == LayerType.TEXT) { l.color = 0xFFFFFFFF.toInt(); if (l.text.isEmpty()) l.text = "Saiki Text" }
    if (type == LayerType.MODEL || type == LayerType.CAMERA) l.is3d = true
    s.layers.add(l)
    if (type == LayerType.NULL) toast("Turn on the 3D cube (top bar) so this Null can drive other layers")
    if (type == LayerType.CAMERA) toast("The camera affects layers below it that have the 3D cube on")
    onSelect(id)
    return l
}

fun EditorViewController.addLight(type: Int = 0, color: Int = 0xFFFFF2D8.toInt()): Layer {
    val l = addLayer(LayerType.NULL)
    l.name = "${Lights.types[type]} Light ${l.id}"
    l.is3d = true
    l.xset("isLight", 1f); l.xset("lightInt", 8f); l.xset("lightInf", 1f); l.xset("lightRad", 0.5f); l.xset("lightType", type.toFloat()); l.xset("lightTemp", 6500f)
    l.xset("lightPitch", if (type == 1) -50f else -60f); l.xset("lightCone", 40f)
    l.xset("atmAmt", 0.3f); l.xset("atmCol", 0x6688FF.toFloat())
    l.vdbTint = color
    l.track("y").set(Editor.time, 1f, false)
    render(); refreshPanel()
    return l
}

/** "Particles": an invisible solid carrying the Particular effect (3D, camera-aware, occluded by 3D layers). */
fun EditorViewController.addParticles() {
    val l = addLayer(LayerType.SHAPE)
    l.name = "Particles ${l.id}"
    l.shape = ShapeKind.RECT
    l.is3d = true
    val ar = Editor.project.w.toFloat() / Editor.project.h.toFloat()
    l.track("scale").base = kotlin.math.min(kotlin.math.max(2 * ar, 2f) / 0.8f / 0.84f * 1.02f, 8f)
    l.fx.add("particular")
    l.track("ptShowSrc").base = 0f
    expanded.add("${l.id}:particular")
    fxTab = 0
    panel = P_FX
    showBottom(); refreshPanel()
    openParticularDesigner(l)
}

fun EditorViewController.addStrands() {
    val l = addLayer(LayerType.SHAPE)
    l.name = "Organic Strands ${l.id}"
    l.shape = ShapeKind.CIRCLE
    l.is3d = true
    l.fx.add("bccstrands")
    l.track("stShowSrc").base = 0f
    expanded.add("${l.id}:bccstrands")
    fxTab = 0
    panel = P_FX
    showBottom(); refreshPanel()
}

fun EditorViewController.cloneLayer(l: Layer, suffix: String): Layer {
    val c = Layer(Editor.project.nextId, l.name + suffix, l.type)
    Editor.project.nextId += 1
    c.text = l.text; c.color = l.color; c.color2 = l.color2; c.shape = l.shape; c.imagePath = l.imagePath
    c.bold = l.bold; c.italic = l.italic; c.font = l.font; c.fontPath = l.fontPath
    c.strokeW = l.strokeW; c.strokeColor = l.strokeColor; c.spacing = l.spacing
    c.borderW = l.borderW; c.borderColor = l.borderColor; c.borderPad = l.borderPad
    for (an in l.anims) c.anims.add(an.copy())
    c.start = l.start; c.end = l.end; c.is3d = l.is3d; c.parentId = l.parentId
    c.lockRot = l.lockRot; c.lockScale = l.lockScale; c.lockMove = l.lockMove
    c.blend = l.blend; c.srcDur = l.srcDur; c.visible = l.visible; c.srcOffset = l.srcOffset
    c.vpath = l.vpath; c.mask = l.mask; c.mblur = l.mblur; c.clipIds = l.clipIds.toMutableList(); c.clipInv = l.clipInv
    c.tgraph = l.tgraph; c.m3Env = l.m3Env; c.m3Metal = l.m3Metal; c.m3Ao = l.m3Ao; c.occlude = l.occlude; c.m3View = l.m3View; c.vdbDens = l.vdbDens; c.vdbBright = l.vdbBright; c.rtOn = l.rtOn; c.rtInt = l.rtInt; c.rtRad = l.rtRad; c.vdbEnv = l.vdbEnv; c.vdbEnvPath = l.vdbEnvPath; c.vdbSurround = l.vdbSurround; c.vdbTint = l.vdbTint; c.x3s = l.x3s; c.pbrMaps = LinkedHashMap(l.pbrMaps)
    c.fx.addAll(l.fx)
    c.fxOff.addAll(l.fxOff)
    for ((k, v) in l.inputs) c.inputs[k] = v
    for ((k, tr) in l.props) {
        val n = c.track(k)
        n.base = tr.base
        n.copyExprFrom(tr)
        for (key in tr.keys) {
            val nk = Key(key.t, key.v, key.ease)
            nk.x1 = key.x1; nk.y1 = key.y1; nk.x2 = key.x2; nk.y2 = key.y2
            n.keys.add(nk)
        }
    }
    return c
}

fun EditorViewController.targets(): List<Layer> {
    val m = Editor.scene.layers.filter { multi.contains(it.id) }
    if (m.isNotEmpty()) return m
    val s = selected()
    if (s != null) return listOf(s)
    return emptyList()
}

/// Clones layers together with everything inside any group among them, keeping the inner
/// parent links on the NEW ids. Layers whose parent is not part of the set go to `dest`
/// (null = keep their own parent). This is what lets a layer copied out of a group land
/// outside it, and a copied group bring its contents.
fun EditorViewController.cloneSet(src: List<Layer>, suffix: String, dest: Int?): List<Layer> {
    val all = ArrayList<Layer>()
    fun add(l: Layer) { if (all.none { it === l }) all.add(l) }
    for (l in src) {
        add(l)
        if (l.type == LayerType.GROUP) for (d in PreRender.descendants(l, Editor.scene)) add(d)
    }
    val map = HashMap<Int, Layer>()
    val out = ArrayList<Layer>()
    for (l in all) {
        val c = cloneLayer(l, if (src.any { it === l }) suffix else "")
        map[l.id] = c; out.add(c)
    }
    for ((l, c) in all.zip(out)) {
        val p = map[l.parentId]
        if (p != null) c.parentId = p.id
        else if (dest != null) c.parentId = dest
    }
    return out
}

/// Where a paste lands: beside the selected layer (same group), or the top level if nothing is selected.
fun EditorViewController.pasteParent(): Int {
    val s = selected()
    if (s != null) return s.parentId
    return -1
}

fun EditorViewController.duplicateSelected() {
    val t = targets()
    if (t.isEmpty()) { toast("Select a layer first"); return }
    pushUndo()
    val made = cloneSet(t, " copy", null)
    for (c in made) Editor.scene.layers.add(c)
    val last = made.lastOrNull()?.id ?: -1
    multi.clear()
    multiMode = false
    onSelect(last)
}

fun EditorViewController.copySelected() {
    val t = targets()
    if (t.isEmpty()) { toast("Select a layer first"); return }
    clipboard.clear()
    clipboard.addAll(cloneSet(t, "", null))      // contents of copied groups travel with them
    toast("Copied ${t.count()}${if (t.count() == 1) " layer" else " layers"}")
}

fun EditorViewController.pasteLayers() {
    if (clipboard.isEmpty()) { toast("Nothing copied yet"); return }
    pushUndo()
    val dest = pasteParent()
    // clipboard holds clones whose own parent links are still valid among themselves
    val ids = clipboard.map { it.id }.toSet()
    val map = HashMap<Int, Layer>()
    val made = ArrayList<Layer>()
    for (c in clipboard) {
        val n = cloneLayer(c, "")
        map[c.id] = n; made.add(n)
    }
    for ((c, n) in clipboard.zip(made)) {
        val p = map[c.parentId]
        if (ids.contains(c.parentId) && p != null) n.parentId = p.id else n.parentId = dest
    }
    for (n in made) Editor.scene.layers.add(n)
    val top = clipboard.zip(made).filter { !ids.contains(it.first.parentId) }.lastOrNull()?.second ?: made.lastOrNull()
    multi.clear()
    multiMode = false
    onSelect(top?.id ?: -1)
}

fun EditorViewController.selectAll() {
    multi.clear()
    for (l in Editor.scene.layers) multi.add(l.id)
    if (multi.isEmpty()) { toast("No layers yet"); return }
    selId = multi.lastOrNull() ?: -1
    multiMode = true   // keep the selection alive so Group / Copy / Delete see every layer
    refreshTitle(); refreshToolbar(); render()
    toast("All layers selected")
}

fun EditorViewController.groupSelected(asMask: Boolean = false) {
    var t = targets()
    if (t.isEmpty()) { toast("Select layers first"); return }
    // a layer whose parent is also selected travels inside that parent
    val ids = t.map { it.id }.toSet()
    t = t.filter { !ids.contains(it.parentId) }
    if (t.map { it.parentId }.toSet().size > 1) { toast("Select layers that share the same parent group"); return }
    val wasSingle = t.count() == 1 && multi.count() <= 1
    pushUndo()
    val top = t.mapNotNull { l -> Editor.scene.layers.indexOfFirst { it === l } }.maxOrNull() ?: 0
    val g = addLayer(LayerType.GROUP)
    val ls = Editor.scene.layers
    ls.removeAll { it === g }
    ls.add(kotlin.math.min(top + 1, ls.size), g)
    Editor.scene.layers = ls
    g.parentId = t.firstOrNull()?.parentId ?: -1
    for (l in t) l.parentId = g.id
    if (asMask) {
        // Mask Group: the top layer becomes the alpha matte for everything below it in the group
        g.mask = 1
        g.name = "Mask Group"
        if (t.count() < 2) toast("Mask Group needs 2+ layers: the top one is the matte for the rest")
    }
    var total = t.count()
    for (r in t) total += PreRender.descendants(r, Editor.scene).count()   // layers parented to them travel inside too
    multi.clear()
    multiMode = false
    onSelect(g.id)
    toast(if (wasSingle) "Grouped 1 layer. To group several, use Layers menu > Select Multiple Layers (or Select All) first"
          else "Grouped $total layers")
}

fun EditorViewController.addSolid() {
    val l = addLayer(LayerType.SHAPE)
    l.shape = ShapeKind.RECT
    l.name = "Solid ${l.id}"
    l.color = 0xFF2A2A33.toInt()
    val ar = Editor.project.w.toFloat() / Editor.project.h.toFloat()
    l.track("scale").base = kotlin.math.min(kotlin.math.max(2 * ar, 2f) / 0.8f / 0.84f * 1.02f, 8f)
    refreshPanel(); render()
}

fun EditorViewController.deleteLayer() {
    val t = targets()
    if (t.isEmpty()) return
    pushUndo()
    // deleting a group deletes everything inside it (no orphaned contents left behind)
    val doomed = mutableListOf<Layer>()
    for (l in t) {
        doomed.add(l)
        if (l.type == LayerType.GROUP) doomed.addAll(PreRender.descendants(l, Editor.scene))
    }
    for (l in doomed) {
        Editor.scene.layers.removeAll { it === l }
    }
    val gone = doomed.map { it.id }.toSet()
    for (o in Editor.scene.layers) if (gone.contains(o.parentId)) o.parentId = -1
    multi.clear()
    multiMode = false
    onSelect(-1)
}

fun EditorViewController.splitLayer(l: Layer, t: Float): Layer? {
    if (t <= l.start + 0.04f || t >= l.end - 0.04f) return null
    if (l.type == LayerType.GROUP) return splitGroup(l, t)
    val c = cloneLayer(l, "")
    c.name = l.name
    c.start = t
    if (l.type == LayerType.VIDEO || l.type == LayerType.AUDIO) c.srcOffset = l.srcOffset + (t - l.start)
    l.end = t
    val ls = Editor.scene.layers
    val i = ls.indexOfFirst { it === l }
    if (i >= 0) ls.add(i + 1, c)
    Editor.scene.layers = ls
    return c
}

/** Cuts a group in two at `t`: children are split too, and the right-hand halves move into the new second group. */
fun EditorViewController.splitGroup(g: Layer, t: Float): Layer? {
    val g2 = cloneLayer(g, "")
    g2.name = g.name
    g2.start = t
    g.end = t
    val ls = Editor.scene.layers
    val i = ls.indexOfFirst { it === g }
    if (i >= 0) ls.add(i + 1, g2)
    Editor.scene.layers = ls
    val kids = Editor.scene.layers.filter { it.parentId == g.id }
    for (c in kids) {
        if (c.end <= t + 0.04f) continue
        if (c.start >= t - 0.04f) { c.parentId = g2.id; continue }
        val c2 = splitLayer(c, t)
        if (c2 != null) c2.parentId = g2.id
    }
    return g2
}

/** Splits the selected layers (or every layer under the playhead) at the playhead. */
fun EditorViewController.splitAtPlayhead(all: Boolean) {
    val t = Editor.time
    val list = if (all) Editor.scene.layers else targets()
    if (list.isEmpty()) { toast("Select a layer first"); return }
    pushUndo()
    var last: Layer? = null
    var n = 0
    for (l in list) {
        val c = splitLayer(l, t)
        if (c != null) { last = c; n += 1 }
    }
    if (last == null) { toast("Move the playhead inside the layer to split it"); return }
    multi.clear()
    multiMode = false
    toast(if (n == 1) "Layer split" else "Split $n layers")
    onSelect(last!!.id)
}

/** Moves the start or end of the selected layers to the playhead. */
fun EditorViewController.trimTo(start: Boolean) {
    val list = targets()
    if (list.isEmpty()) { toast("Select a layer first"); return }
    val t = Editor.time
    pushUndo()
    var n = 0
    for (l in list) {
        if (l.type == LayerType.GROUP) continue
        if (start && t > l.start + 0.04f && t < l.end) {
            if (l.type == LayerType.VIDEO || l.type == LayerType.AUDIO) l.srcOffset += t - l.start
            l.start = t; n += 1
        } else if (!start && t < l.end - 0.04f && t > l.start) {
            l.end = t; n += 1
        }
    }
    if (n == 0) toast("Move the playhead inside the layer first") else render()
}

fun EditorViewController.moveLayer(dir: Int) {
    val l = selected() ?: return
    pushUndo()
    val ls = Editor.scene.layers
    val i = ls.indexOfFirst { it === l }
    if (i < 0) return
    val j = i + dir
    if (j < 0 || j >= ls.count()) return
    ls.removeAt(i)
    ls.add(j, l)
    render()
}

fun EditorViewController.toggle3d() {
    val l = selected() ?: run { toast("Select a layer first"); return }
    if (l.type == LayerType.MODEL || l.type == LayerType.CAMERA) { toast("This layer is always 3D"); return }
    pushUndo()
    l.is3d = !l.is3d
    refreshTitle(); refreshPanel(); render()
    toast(if (l.is3d) "3D on" else "3D off")
}

/** Rename the selected layer (name shows in the timeline and the Cubism layer tree). */
fun EditorViewController.renameLayer(l: Layer) {
    val a = com.saiki.motion.uikit.UIAlertController()
    a.title = "Rename layer"
    a.addTextField { it.text = l.name }
    a.addAction(com.saiki.motion.uikit.UIAlertAction("Cancel", com.saiki.motion.uikit.UIAlertActionStyle.cancel, null))
    a.addAction(com.saiki.motion.uikit.UIAlertAction("Rename", com.saiki.motion.uikit.UIAlertActionStyle.default) {
        val n = (a.textFields.firstOrNull()?.text ?: "").trim()
        if (n.isNotEmpty() && n != l.name) {
            pushUndo(); l.name = n
            refreshTitle(); onEdited()
        }
    })
    a.showOver(this)
}

fun EditorViewController.showLayersMenu() {
    // LayersSheet (UI/LayersSheet.swift) belongs to the UI wave; the same items ride a Dlg — PORT NOTE.
    val hasSel = selected() != null
    val items = mutableListOf(
        "Select All Layers", if (multiMode) "Stop Selecting Multiple" else "Select Multiple Layers", "Group Layers",
        "Show All Keyframes", "Split at Playhead", "Split All Layers at Playhead", "Rename Layer",
        "Mask Group", if (overlay.guides) "Hide Grid" else "Show Grid", "Move Layer Up", "Move Layer Down",
        "Set Parent…", "Add Layer…", "Copy", "Paste", "Properties", "Duplicate", "Preset", "Delete Layer")
    Dlg(this).setTitle("Layers").setItems(items) { _, w ->
        when (w) {
            0 -> selectAll()
            1 -> {
                multiMode = !multiMode
                if (!multiMode) multi.clear()
                render()
                toast(if (multiMode) "Tap layers to select them" else "Multi select off")
            }
            2 -> groupSelected()
            3 -> timeline.expandAll()
            4 -> splitAtPlayhead(false)
            5 -> splitAtPlayhead(true)
            6 -> selected()?.let { renameLayer(it) }
            7 -> groupSelected(true)
            8 -> { overlay.guides = !overlay.guides; overlay.setNeedsDisplay() }
            9 -> moveLayer(1)
            10 -> moveLayer(-1)
            11 -> selected()?.let { showParentPopup(it, parentIcon) }
            12 -> showAddLayerMenu()
            13 -> copySelected()
            14 -> pasteLayers()
            15 -> showPropertiesMenu()
            16 -> duplicateSelected()
            17 -> openPanel(P_FX)
            18 -> deleteLayer()
        }
    }.setNegativeButton("Close", null).show()
}

/** Copy the selected layer's animated properties, or paste them onto the selected layer(s). */
fun EditorViewController.showPropertiesMenu() {
    Dlg(this).setTitle("Properties").setIconItems(listOf("Copy Properties", "Paste Properties"), listOf("dup", "import")) { _, w ->
        if (w == 0) {
            val l = selected() ?: return@setIconItems
            propsClip = cloneLayer(l, ""); toast("Properties copied")
        } else {
            val src = propsClip ?: run { toast("Copy properties first"); return@setIconItems }
            val targets = if (multiMode && multi.isNotEmpty()) multi.mapNotNull { id -> Editor.scene.layers.firstOrNull { it.id == id } }
                          else listOfNotNull(selected())
            if (targets.isEmpty()) { toast("Select a layer first"); return@setIconItems }
            pushUndo()
            for (t in targets) t.props = cloneLayer(src, "").props
            onEdited(); render(); toast("Properties pasted")
        }
    }.setNegativeButton("Close", null).show()
}

/** The two-square icon next to the title: add / copy / paste / group / keyframes / duplicate / parent. */
fun EditorViewController.showQuickLayerMenu() {
    val labels = listOf("Add Layer", "Copy Layer", "Paste Layer", "Group Layers",
                        "Show All Keyframes", "Duplicate Layer", "Rename Layer", "Set Parent…")
    val icons = listOf("plus", "dup", "import", "layers", "graph", "dup", "edit", "link")
    Dlg(this).setTitle("Layer").setIconItems(labels, icons) { _, w ->
        when (w) {
            0 -> showAddLayerMenu()
            1 -> copySelected()
            2 -> pasteLayers()
            3 -> groupSelected()
            4 -> timeline.expandAll()
            5 -> duplicateSelected()
            6 -> selected()?.let { renameLayer(it) }
            else -> selected()?.let { showParentPopup(it, parentIcon) }
        }
    }.setNegativeButton("Close", null).show()
}

fun EditorViewController.showAddLayerMenu() {
    val labels = listOf("Media", "Solid", "Adjustment", "Null", "Shape", "Camera", "Particles", "Group", "Vector Pen", "Organic Strands")
    val icons = listOf("media", "solid", "adjust", "nullobj", "shape", "camera", "particles", "layers", "edit", "particles")
    Dlg(this).setTitle("Add Layer").setIconItems(labels, icons) { _, w ->
        when (w) {
            0 -> openPanel(P_MEDIA)
            1 -> addSolid()
            2 -> addLayer(LayerType.ADJUST)
            3 -> addLayer(LayerType.NULL)
            4 -> openPanel(P_SHAPES)
            5 -> addLayer(LayerType.CAMERA)
            6 -> addParticles()
            8 -> openPenEditor()
            9 -> addStrands()
            else -> addLayer(LayerType.GROUP)
        }
    }.setNegativeButton("Close", null).show()
}
