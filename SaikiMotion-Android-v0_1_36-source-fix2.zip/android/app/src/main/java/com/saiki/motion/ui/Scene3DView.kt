@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName", "PropertyName")

// Port of Sources/UI/Scene3DView.swift — the "Scene 3D" screen opened from the cube button beside the preview.
//
// A 3D viewport that mirrors every 3D thing in the main editor (model layers, 3D-cube layers, camera
// layers) at the editor's current time. iOS renders through SceneKit; Android has no SceneKit, so this
// port keeps the same scene graph (S3Node = SCNNode twin) and draws it on the 2D canvas with a
// software painter's-algorithm rasteriser (depth-sorted line / point / triangle batches). Volumes go
// through the same Vulkan volumeOverlay the main viewport uses, composited over the software pass.
// Modes (left toolbar):
//   Still  — look around only (orbit / pan / zoom). Nothing can be selected or edited.
//   Move   — tap selects; drag the selected layer (gizmo arrows constrain to an axis).
//   Scale  — tap selects; drag up / down on it to scale.
// "+" menu: Import Model, Add to scene, View toggles, Pose.
// Bottom panel: Timeline (tracks + keyframes) / Properties (Layer / Global / Bones) / Scatter.
// Edits write the same x / y / z / scale tracks the main editor uses (auto-key aware, undoable).
// Camera: 1 finger orbits (on empty space in edit modes), 2 fingers pan, pinch dollies, 3 fingers dolly fast.

package com.saiki.motion.ui

import com.saiki.motion.core.Editor
import com.saiki.motion.core.FrameCache
import com.saiki.motion.core.GlbModel
import com.saiki.motion.core.GlobalEnv
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.Lights
import com.saiki.motion.core.M4
import com.saiki.motion.core.MetalCam
import com.saiki.motion.core.MetalModelRenderer
import com.saiki.motion.core.ParticularSim
import com.saiki.motion.core.Prefs
import com.saiki.motion.core.Quat
import com.saiki.motion.core.R3D
import com.saiki.motion.core.SceneRenderer
import com.saiki.motion.core.Scatter
import com.saiki.motion.core.Skeleton3D
import com.saiki.motion.core.TGraph
import com.saiki.motion.core.V3
import com.saiki.motion.core.V4
import com.saiki.motion.core.VdbVolume
import com.saiki.motion.core.Xf
import com.saiki.motion.app.R_GLB
import com.saiki.motion.app.deleteLayer
import com.saiki.motion.app.PanelScroll
import com.saiki.motion.app.pickFile
import com.saiki.motion.app.refreshPanel
import com.saiki.motion.app.showColorPicker
import com.saiki.motion.app.show3DImport
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIGraphicsImageRenderer
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.uikit.fillRoundRect
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

// ================================================================ vector helpers

private fun dotS3(a: S3V, b: S3V): Float = a.x * b.x + a.y * b.y + a.z * b.z
private fun crossS3(a: S3V, b: S3V): S3V = S3V(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x)
private fun normalizeS3(v: S3V): S3V { val l = max(v.len(), 1e-8f); return S3V(v.x / l, v.y / l, v.z / l) }
private fun crossV(a: V3, b: V3): V3 = V3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x)
private fun normalizeV(v: V3): V3 { val l = max(sqrt(v.x * v.x + v.y * v.y + v.z * v.z), 1e-8f); return V3(v.x / l, v.y / l, v.z / l) }

// ================================================================ mini SceneKit (SCNNode / SCNGeometry twin)

/** SCNVector3 twin. */
class S3V(var x: Float, var y: Float, var z: Float) {
    constructor() : this(0f, 0f, 0f)
    operator fun plus(o: S3V) = S3V(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: S3V) = S3V(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = S3V(x * s, y * s, z * s)
    fun len(): Float = sqrt(x * x + y * y + z * z)
    companion object { val zero = S3V(0f, 0f, 0f) }
}

/** Geometry kinds the viewport needs (SCNGeometry subclasses). */
enum class S3Kind { lines, points, triangles, plane, box, sphere, cylinder, cone, torus, text }

/** One geometry batch (SCNGeometry + SCNMaterial twin, enough of the API for this view). */
class S3Geom(val kind: S3Kind) {
    var verts: MutableList<S3V> = ArrayList()             // line / point soup (pairs for lines)
    var col: MutableList<Float> = ArrayList()              // per-vertex RGBA (point clouds)
    var tris: List<Scatter.Tri> = emptyList()              // triangle batches (models / planes)
    var img: UIImage? = null                               // plane / model texture
    var argb = 0xFFFFFFFF.toInt()                          // material diffuse colour
    var emission = 0xFF000000.toInt()                      // material emission (selection tint)
    var alpha = 1f                                         // material transparency
    var additive = false                                   // blendMode .add
    var lineFill = false                                   // SCNBox fillMode .lines
    var doubleSided = false
    var writesDepth = true
    var sizeA = 1f; var sizeB = 1f                         // cylinder radius/height, sphere radius, plane w/h...
    var pointSize = 3f
    var label: String? = null                              // SCNText twin
}

/** SCNNode twin: name, transform, opacity, geometry, children. */
class S3Node {
    var name: String? = null
    var geometry: S3Geom? = null
    var position = S3V()
    var eulerAngles = S3V()
    var scale = S3V(1f, 1f, 1f)
    var simdTransform: M4 = M4.identity()
        set(v) { field = v; useMatrix = true; cachedWorld = null }
    var useMatrix = false
        private set
    var opacity = 1f
    var isHidden = false
    var renderingOrder = 0
    val childNodes = ArrayList<S3Node>()
    var parent: S3Node? = null
    private var cachedWorld: M4? = null

    fun addChildNode(n: S3Node) { childNodes.add(n); n.parent = this; cachedWorld = null }
    fun removeFromParentNode() { parent?.childNodes?.remove(this); parent = null }
    fun clone(): S3Node {
        val n = S3Node()
        n.name = name; n.geometry = geometry; n.position = S3V(position.x, position.y, position.z)
        n.eulerAngles = S3V(eulerAngles.x, eulerAngles.y, eulerAngles.z); n.scale = S3V(scale.x, scale.y, scale.z)
        n.simdTransform = simdTransform; n.opacity = opacity; n.isHidden = isHidden; n.renderingOrder = renderingOrder
        for (c in childNodes) n.addChildNode(c.clone())
        return n
    }
    fun childNode(withName: String): S3Node? = childNodes.firstOrNull { it.name == withName }

    val simdWorldPosition: S3V
        get() { val m = worldMatrix(); return S3V(m.m[12], m.m[13], m.m[14]) }
    val simdWorldTransform: M4 get() = worldMatrix()

    fun worldMatrix(): M4 {
        cachedWorld?.let { return it }
        val local = if (useMatrix) simdTransform else compose()
        val p = parent
        val w = if (p != null) p.worldMatrix() * local else local
        cachedWorld = w
        return w
    }

    private fun compose(): M4 {
        val rx = eulerAngles.x; val ry = eulerAngles.y; val rz = eulerAngles.z
        val r = M4.fromQuat(Quat.angleAxis(rz, V3(0f, 0f, 1f)) * Quat.angleAxis(ry, V3(0f, 1f, 0f)) * Quat.angleAxis(rx, V3(1f, 0f, 0f)))
        val s = M4.identity()
        s.setCol(0, V4(scale.x, 0f, 0f, 0f)); s.setCol(1, V4(0f, scale.y, 0f, 0f)); s.setCol(2, V4(0f, 0f, scale.z, 0f))
        val m = r * s
        m.setCol(3, V4(position.x, position.y, position.z, 1f))
        return m
    }
}


// ================================================================ Scene3DView

class Scene3DView(private val host: com.saiki.motion.app.EditorViewController?) : UiView(appContext!!) {

    enum class Mode(val raw: Int) { still(0), move(1), rotate(2), scale(3);
        companion object { fun fromRaw(r: Int): Mode = entries.firstOrNull { it.raw == r } ?: move }
    }

    // MARK: state
    private val scn = S3Node()                      // root
    private val cam = S3Node()
    private val world = S3Node()
    private val gridNode = S3Node()
    private val gizmo = S3Node()
    private val nodes = HashMap<Int, S3Node>()
    private var sig = ""
    private var vdbOverlayOK = false
    private var vdbOvSig = ""
    private var link: com.saiki.motion.uikit.CADisplayLink? = null
    private var camLink: com.saiki.motion.uikit.CADisplayLink? = null
    private var mode = Mode.move
    private var selected = -1
    private var lastHostSel = -2
    private var showGrid = true; private var showGizmo = true; private var showTimeline = true; private var syncScene = true
    private var yaw = 0.6f; private var pitch = 0.35f; private var dist = 6f
    private var target = S3V(0f, 0f, 0f)
    // smoothed camera (what is actually drawn); yaw / pitch / dist / target above are the goals the gestures move
    private var cYaw = 0.6f; private var cPitch = 0.35f; private var cDist = 6f; private var cTarget = S3V(0f, 0f, 0f)
    private var tickN = 0
    private var camMoving = false; private var orbiting = false
    private var velYaw = 0f; private var velPitch = 0f
    private var lastOverlayT = 0.0
    private var drag = false; private var dragAxis = -1
    internal var dragPrev = CGPoint.zero; internal var dragCur = CGPoint.zero
    internal var snapOn = false; internal var rotAcc = 0f
    private val gizmoMats = HashMap<Int, S3Geom>()
    private val gizmoBase = HashMap<Int, Int>()
    private var scLayer = -1
    private var lastTris: List<Scatter.Tri> = emptyList()
    private val surfaceTris = HashMap<Int, List<Scatter.Tri>>()
    private val scInst = HashMap<Int, MutableList<S3Node>>()
    private val vdbMats = HashMap<Int, S3Geom>()
    // pose mode
    internal class SkinPrim(val node: S3Node, val base: FloatArray, val jnt: ShortArray, val wgt: FloatArray)
    internal val skels = HashMap<Int, Skeleton3D>()
    private val skinPrims = HashMap<Int, MutableList<SkinPrim>>()
    private val holders = HashMap<Int, S3Node>()
    private val modelScale = HashMap<Int, Float>()
    private val ovStore = HashMap<Int, String>()
    internal var poseMode = false; internal var showBones = false
    internal var selBone = -1
    private var lastPhysWall = 0.0
    private val boneHosts = HashMap<Int, S3Node>()       // bone overlay lives outside the (faded) model node so it is always visible
    private val modeSeg = FlatSegment(listOf("Object", "Pose"))
    internal var boneClip: FloatArray? = null
    internal var boneFilter = ""
    internal var boneFilterMode = 0
    private val boneStruct = HashMap<Int, String>()
    private val boneNodes = HashMap<Int, MutableList<S3Node>>()

    private val accent = 0xFFFF8C14.toInt()

    // UI
    private val modeBtns = ArrayList<S3Btn>()
    private val chip = UILabel(appContext!!)
    private val plus = PillButton("", "plus", accent, 0xFFFFFFFF.toInt())
    private val tl = UiView(appContext!!)            // bottom panel (timeline or properties)
    private val timeLbl = UILabel(appContext!!)
    private val playBtn = IconView("play", 0xFFFFFFFF.toInt(), 22f)
    private val canvas = TLCanvas()
    private val tlBox = UiView(appContext!!)
    private val propScroll = PanelScroll()
    private val propStack = com.saiki.motion.app.EVStack()
    private val tabSeg = FlatSegment(listOf("Timeline", "Properties", "Scatter"))
    private val scopeSeg = FlatSegment(listOf("Layer", "Global", "Bones"))
    private var header = com.saiki.motion.app.EHStack()
    private var fullscreen = false
    private val known = HashSet<Int>(); private var built = false
    private var propKey = ""
    private var fsBtn: S3Btn? = null
    private var barView: UiView? = null
    private var hdrH = 52f

    /** The SCNView twin: the viewport that draws the 3D scene (software rasterised in draw()). */
    private val sv = object : UiView(appContext!!) {
        public override fun draw(rect: CGRect) { drawScene() }
    }
    /** UIImageView vdbView twin: the volume frame composited over the scene (screen blend). */
    private val vdbView = object : UiView(appContext!!) {
        public override fun draw(rect: CGRect) {
            val c = UIGraphics.getCurrentContext() ?: return
            val b = vdbOverlayBmp ?: return
            val p = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
            c.saveGState()
            c.paint.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN)
            c.canvas.drawBitmap(b.bitmap, null, android.graphics.RectF(0f, 0f, rect.width, rect.height), p)
            c.paint.xfermode = null
            c.restoreGState()
        }
    }
    private var vdbOverlayBmp: UIImage? = null

    private fun svWidth(): CGFloat = sv.rectWidth()
    private fun svHeight(): CGFloat = sv.rectHeight()

    // MARK: entry
    companion object {
        fun present(host: com.saiki.motion.app.EditorViewController) {
            if (host.view.subviews.any { it is Scene3DView }) return
            val v = Scene3DView(host)
            v.frame = CGRect(0f, 0f, host.view.rectWidth(), host.view.rectHeight())
            host.view.addSubview(v)
        }
    }

    init {
        setBackgroundColor(android.graphics.Color.BLACK)
        buildScene()
        buildUI()
        applyCam(snap = true)
        updateModeUI()
        rebuildMenu()
        link = com.saiki.motion.uikit.CADisplayLink(this, "tick")
        link?.preferredFramesPerSecond = 30
        link?.start()
        camLink = com.saiki.motion.uikit.CADisplayLink(this, "camStep")
        camLink?.start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        link?.invalidate(); link = null
        camLink?.invalidate(); camLink = null
    }

    private fun close() { (parent as? android.view.ViewGroup)?.removeView(this) }

    // MARK: layout (no Auto Layout in this layer; same manual scheme as the other screens)

    public override fun layoutSubviews() {
        super.layoutSubviews()
        layoutAll()
    }

    private fun layoutAll() {
        if (rectWidth() <= 1f || rectHeight() <= 1f) return
        val land = rectWidth() > rectHeight()
        val sa = safeAreaInsets
        val x0 = sa.left; val bw = rectWidth() - sa.left - sa.right
        val top = if (fullscreen) 0f else sa.top
        val bottom = rectHeight() - sa.bottom
        header.frame = CGRect(x0 + 14f, top, max(0f, bw - 28f), if (fullscreen) 0f else hdrH)
        header.isHidden = fullscreen
        val y0 = if (fullscreen) 0f else top + hdrH + 4f
        val y1 = bottom - 6f
        val bar = barView
        if (land) {          // landscape: viewport left, tool bar + panel become a column on the right
            val sideW = min(390f, bw * 0.42f)
            val vw = max(0f, bw - sideW - 8f)
            sv.frame = CGRect(x0 + 12f, y0, vw, max(0f, y1 - y0))
            val sx = x0 + 12f + vw + 8f
            val barH = 52f
            bar?.frame = CGRect(sx, y0, sideW, barH)
            tl.frame = CGRect(sx, y0 + barH + 8f, sideW, max(0f, y1 - y0 - barH - 8f))
        } else {
            val vh = (y1 - y0) * 0.5f
            sv.frame = CGRect(x0 + 12f, y0, max(0f, bw - 24f), vh)
            val barH = 52f
            bar?.frame = CGRect(x0 + 12f, y0 + vh + 8f, max(0f, bw - 24f), barH)
            tl.frame = CGRect(x0 + 12f, y0 + vh + 8f + barH + 8f, max(0f, bw - 24f), max(0f, y1 - (y0 + vh + 8f + barH + 8f)))
        }
        layoutBar()
        layoutPanel()
        layoutOverlays()
    }

    private fun layoutBar() {
        val bar = barView ?: return
        chip.frame = CGRect(8f, 13f, 170f, 26f)
        plus.frame = CGRect(max(0f, bar.rectWidth() - 64f), 3f, 64f, 46f)
        tabSeg.frame = CGRect(max(0f, bar.rectWidth() / 2f - 125f), 10f, min(250f, max(0f, bar.rectWidth() - 260f)), 32f)
    }

    private fun layoutPanel() {
        val col = tlBox.subviews.firstOrNull() as? com.saiki.motion.app.EVStack
        if (col != null) {
            val kids = col.arranged
            if (kids.size >= 2) {
                kids[0].frame = CGRect(0f, 0f, tlBox.rectWidth(), 40f)
                kids[1].frame = CGRect(0f, 48f, tlBox.rectWidth(), max(0f, tlBox.rectHeight() - 48f))
            }
        }
        scopeSeg.frame = CGRect(max(0f, tl.rectWidth() / 2f - 135f), 10f, min(270f, max(0f, tl.rectWidth() - 20f)), 32f)
        propScroll.frame = CGRect(0f, 46f, tl.rectWidth(), max(0f, tl.rectHeight() - 46f))
        propStack.frame = CGRect(14f, 0f, max(0f, propScroll.rectWidth() - 28f), max(propStack.totalH, 1f))
    }

    private fun layoutOverlays() {
        // corner buttons (fullscreen/frame/undo/redo/delete) and left toolbar live inside the viewport
        for (v in sv.subviews) {
            if (v !is com.saiki.motion.app.EVStack) continue
            if (v === s3Corner) {
                v.frame = CGRect(max(0f, sv.rectWidth() - 52f), 12f, 44f, 5 * 44f + 4 * 4f)
                var yy = 0f
                for (c in v.arranged) { c.frame = CGRect(0f, yy, 44f, 44f); yy += 48f }
            } else if (v === s3Tools) {
                v.frame = CGRect(8f, 12f, 40f, 6 * 40f + 5 * 4f)
                var yy = 0f
                for (c in v.arranged) { c.frame = CGRect(0f, yy, 40f, 40f); yy += 44f }
            }
        }
        vdbView.frame = sv.boundsRect
    }

    private val s3Corner = com.saiki.motion.app.EVStack()
    private val s3Tools = com.saiki.motion.app.EVStack()

    // MARK: scene
    private class SCNCam { var fieldOfView = 50f; var zNear = 0.05f; var zFar = 300f }
    private val camera = SCNCam()

    private fun buildScene() {
        camera.fieldOfView = 50f; camera.zNear = 0.05f; camera.zFar = 300f
        scn.addChildNode(cam)
        scn.addChildNode(world)
        scn.addChildNode(gridNode)
        scn.addChildNode(gizmo)
        buildGrid()
        buildGizmo()
    }

    private fun buildGrid() {
        gridNode.childNodes.forEach { it.removeFromParentNode() }
        // floor grid + red X / blue Z axes (like the inspiration screenshot)
        val g = ArrayList<S3V>()
        for (i in -10..10) if (i != 0) {
            val f = i.toFloat()
            g.add(S3V(f, 0f, -10f)); g.add(S3V(f, 0f, 10f)); g.add(S3V(-10f, 0f, f)); g.add(S3V(10f, 0f, f))
        }
        gridNode.addChildNode(lines(g, 0xFF474747.toInt()))
        gridNode.addChildNode(lines(listOf(S3V(-10f, 0f, 0f), S3V(10f, 0f, 0f)), 0xFFD94040.toInt()))
        gridNode.addChildNode(lines(listOf(S3V(0f, 0f, -10f), S3V(0f, 0f, 10f)), 0xFF407FF2.toInt()))
    }

    private fun lines(pts: List<S3V>, color: Int): S3Node {
        val geo = S3Geom(S3Kind.lines)
        geo.verts.addAll(pts)
        geo.argb = color
        return S3Node().also { it.geometry = geo }
    }

    private fun buildGizmo() {
        gizmo.childNodes.forEach { it.removeFromParentNode() }
        gizmoMats.clear(); gizmoBase.clear()
        val cols = listOf(0xFFFF4D4D.toInt(), 0xFF4DE666.toInt(), 0xFF4D8CFF.toInt())
        val rots = listOf(S3V(0f, 0f, -(Math.PI.toFloat() / 2f)), S3V(0f, 0f, 0f), S3V(Math.PI.toFloat() / 2f, 0f, 0f))
        fun mat(key: Int, c: Int): S3Geom {
            val m = S3Geom(S3Kind.cylinder)
            m.argb = c; m.writesDepth = false; m.doubleSided = true
            gizmoMats[key] = m; gizmoBase[key] = c
            return m
        }
        /// Invisible, fatter copy of a handle: easy to hit with a finger.
        fun proxy(code: Int, build: () -> S3Geom): S3Node {
            val g = build()
            g.argb = 0; g.alpha = 0f; g.writesDepth = false; g.doubleSided = true
            val n = S3Node(); n.geometry = g; n.name = "ax$code"; n.renderingOrder = 1001
            return n
        }
        for (i in 0 until 3) {
            val axis = S3Node(); axis.eulerAngles = rots[i]
            val m = mat(i, cols[i])
            if (mode == Mode.rotate) {     // one ring per axis
                val ring = S3Node(); val rg = S3Geom(S3Kind.torus)
                rg.argb = m.argb; rg.writesDepth = m.writesDepth; rg.doubleSided = m.doubleSided
                gizmoMats[i] = rg; gizmoBase[i] = cols[i]
                ring.geometry = rg; ring.name = "ax$i"; ring.renderingOrder = 1000
                axis.addChildNode(ring)
                axis.addChildNode(proxy(i) { val t = S3Geom(S3Kind.torus); t.sizeA = 1.3f; t })
                gizmo.addChildNode(axis); continue
            }
            val shaft = S3Node(); val sg = S3Geom(S3Kind.cylinder); sg.argb = m.argb; sg.sizeA = 0.03f; sg.sizeB = 1f
            shaft.geometry = sg; shaft.position = S3V(0f, 0.5f, 0f); shaft.name = "ax$i"; shaft.renderingOrder = 1000
            val tipGeo = S3Geom(if (mode == Mode.scale) S3Kind.box else S3Kind.cone)
            tipGeo.argb = m.argb; tipGeo.sizeA = if (mode == Mode.scale) 0.2f else 0.11f; tipGeo.sizeB = if (mode == Mode.scale) 0.2f else 0.32f
            val tip = S3Node(); tip.geometry = tipGeo; tip.position = S3V(0f, 1.15f, 0f); tip.name = "ax$i"; tip.renderingOrder = 1000
            axis.addChildNode(shaft); axis.addChildNode(tip)
            val fat = proxy(i) { val t = S3Geom(S3Kind.cylinder); t.sizeA = 0.15f; t.sizeB = 1.5f; t }
            fat.position = S3V(0f, 0.75f, 0f)
            axis.addChildNode(fat)
            gizmo.addChildNode(axis)
        }
        if (mode == Mode.move) {           // plane handles: drag in the plane perpendicular to X / Y / Z
            val offs = listOf(S3V(0f, 0.32f, 0.32f), S3V(0.32f, 0f, 0.32f), S3V(0.32f, 0.32f, 0f))
            val eul = listOf(S3V(0f, Math.PI.toFloat() / 2f, 0f), S3V(-(Math.PI.toFloat() / 2f), 0f, 0f), S3V(0f, 0f, 0f))
            for (k in 0 until 3) {
                val code = 3 + k
                val sq = S3Node(); val qg = S3Geom(S3Kind.plane); qg.argb = cols[k]; qg.sizeA = 0.22f; qg.sizeB = 0.22f; qg.alpha = 0.5f; qg.writesDepth = false
                sq.geometry = qg; sq.name = "ax$code"; sq.renderingOrder = 1000
                sq.eulerAngles = eul[k]; sq.position = S3V(offs[k].x, offs[k].y, offs[k].z)
                gizmoMats[code] = qg; gizmoBase[code] = cols[k]
                val fat = proxy(code) { val t = S3Geom(S3Kind.plane); t.sizeA = 0.34f; t.sizeB = 0.34f; t }
                fat.eulerAngles = S3V(eul[k].x, eul[k].y, eul[k].z); fat.position = S3V(offs[k].x, offs[k].y, offs[k].z)
                gizmo.addChildNode(sq); gizmo.addChildNode(fat)
            }
        }
        if (mode == Mode.move || mode == Mode.rotate) {      // centre handle: free move / free rotate
            val c = S3Node(); val cg = S3Geom(S3Kind.sphere); cg.argb = 0xFFFFFFFF.toInt(); cg.sizeA = if (mode == Mode.move) 0.1f else 0.14f; cg.alpha = if (mode == Mode.move) 0.9f else 0.18f; cg.writesDepth = false
            c.geometry = cg; c.name = "ax6"; c.renderingOrder = 1002
            gizmoMats[6] = cg; gizmoBase[6] = 0xFFFFFFFF.toInt()
            gizmo.addChildNode(c)
        }
    }

    /// Dims the handles that are not being dragged (-1 = all normal).
    internal fun highlightGizmo(active: Int) {
        for ((k, m) in gizmoMats) {
            val base = gizmoBase[k] ?: continue
            if (active < 0 || k == active) { m.argb = if (active == k) 0xFFFFFFFF.toInt() else base }
            else m.argb = (base and 0x00FFFFFF) or (0x40 shl 24)
        }
    }

    // MARK: sync with the main editor
    private fun is3dContent(l: Layer): Boolean = l.type == LayerType.MODEL || l.type == LayerType.CAMERA || l.is3d
    private fun layer(id: Int): Layer? = Editor.scene.layers.firstOrNull { it.id == id }

    private fun rebuild() {
        world.childNodes.forEach { it.removeFromParentNode() }
        nodes.clear(); vdbMats.clear(); scInst.clear(); surfaceTris.clear()
        skels.clear(); skinPrims.clear(); holders.clear(); modelScale.clear(); ovStore.clear(); boneStruct.clear(); boneNodes.clear()
        boneHosts.values.forEach { it.removeFromParentNode() }; boneHosts.clear()
        for (l in Editor.scene.layers.filter { is3dContent(it) }) {
            val root = S3Node(); root.name = "L${l.id}"
            when (l.type) {
                LayerType.CAMERA -> root.addChildNode(camShape())
                LayerType.MODEL -> { lastTris = emptyList(); root.addChildNode(if (isVdb(l)) vdbNode(l) else modelNode(l)) }
                LayerType.PARTICLES -> { lastTris = emptyList(); root.addChildNode(particleHolder()) }
                else -> { lastTris = emptyList(); root.addChildNode(if (l.isLight) lightNode(l) else planeNode(l)) }
            }
            world.addChildNode(root)
            nodes[l.id] = root
            if ((l.type == LayerType.MODEL && !isVdb(l)) || (l.type != LayerType.CAMERA && l.type != LayerType.MODEL)) surfaceTris[l.id] = lastTris
        }
        if (selected >= 0 && nodes[selected] == null) selected = -1
        val fresh = nodes.keys.subtract(known)
        known.clear(); known.addAll(nodes.keys)
        if (built && fresh.isNotEmpty()) {              // just imported / added: show it
            val id = fresh.first()
            val l = layer(id)
            if (l != null) nodes[id]?.simdTransform = xform(l, Editor.time)
            if (mode != Mode.still) select(id, notifyHost = false)
            frame(id)
        }
        built = true
        if (mode != Mode.still) tint(nodes[selected], true)
        if (Editor.xray) applyXray()
    }

    // Particle layers: a live point cloud + small emitter marker (never a grey plane)
    private fun particleHolder(): S3Node {
        val h = S3Node(); h.name = "pts"
        val m = S3Geom(S3Kind.sphere); m.argb = 0xFFFF8A1F.toInt(); m.sizeA = 0.04f; m.writesDepth = false
        h.addChildNode(S3Node().also { it.geometry = m })
        return h
    }

    private fun updateParticles(t: Float) {
        for (l in Editor.scene.layers.filter { it.type == LayerType.PARTICLES }) {
            val root = nodes[l.id] ?: continue
            if (root.isHidden) continue
            val h = root.childNode("pts") ?: continue
            h.childNodes.filter { it.name == "cloud" }.forEach { it.removeFromParentNode() }
            val ps = ParticularSim.field({ l.p(it, t) }, t, 1)
            if (ps.isEmpty()) continue
            val g = S3Geom(S3Kind.points)
            g.pointSize = 4f
            for (q in ps) {
                g.verts.add(S3V(q.x, q.y, q.z))
                val a = max(0f, min(1f, q.alpha * (1 - q.life)))
                g.col.addAll(listOf(q.cr, q.cg, q.cb, a))
            }
            g.argb = 0xFFFFFFFF.toInt(); g.additive = true; g.writesDepth = false
            h.addChildNode(S3Node().also { it.geometry = g; it.name = "cloud" })
        }
    }

    private fun lightNode(l: Layer): S3Node {
        val sp = S3Geom(S3Kind.sphere); sp.argb = 0; sp.alpha = 0f; sp.sizeA = max(l.xf("lightRad", 0.5f), 0.05f); sp.writesDepth = false      // invisible: only there so taps still pick the light
        val n = S3Node(); n.geometry = sp
        val ring = S3Node(); ring.name = "ring"
        val a = ArrayList<S3V>(); val b = ArrayList<S3V>()
        val k = 48
        for (i in 0 until k) {
            val t0 = i.toFloat() / k.toFloat() * 2f * Math.PI.toFloat(); val t1 = (i + 1).toFloat() / k.toFloat() * 2f * Math.PI.toFloat()
            a.add(S3V(cos(t0), 0f, sin(t0))); a.add(S3V(cos(t1), 0f, sin(t1)))     // horizontal circle
            b.add(S3V(cos(t0), sin(t0), 0f)); b.add(S3V(cos(t1), sin(t1), 0f))     // vertical circle
        }
        ring.addChildNode(lines(a, 0xFFFFFFFF.toInt())); ring.addChildNode(lines(b, 0xFFFFFFFF.toInt()))
        n.addChildNode(ring)
        styleLight(n, l)
        return n
    }

    private fun styleLight(n: S3Node, l: Layer) {
        val sp = n.geometry ?: return
        val r = max(l.xf("lightRad", 0.5f), 0.05f)
        if (abs(sp.sizeA - r) > 0.0005f) sp.sizeA = r
        val c = l.vdbTint
        val col = 0xFF000000.toInt() or (((c shr 16) and 255) shl 16) or (((c shr 8) and 255) shl 8) or (c and 255)
        val type = l.xf("lightType", 0f).toInt()
        val sigStr = "$type|${l.xf("lightPitch", -60f)}|${l.xf("lightYaw", 30f)}|${l.xf("lightCone", 45f)}"
        val old = n.childNodes.firstOrNull { it.name?.startsWith("dir|") == true }
        if (old?.name != "dir|" + sigStr) {
            old?.removeFromParentNode()
            if (type != 0) {
                val d = Lights.direction(l)
                val pts = ArrayList<S3V>()
                pts.add(S3V.zero); pts.add(S3V(d[0] * 1.6f, d[1] * 1.6f, d[2] * 1.6f))
                if (type == 2) {      // cone edges
                    val up = if (abs(d[1]) < 0.95f) V3(0f, 1f, 0f) else V3(1f, 0f, 0f)
                    val dv = V3(d[0], d[1], d[2])
                    val aV = normalizeV(crossV(dv, up))
                    val bV = crossV(dv, aV)
                    val ang = max(5f, min(l.xf("lightCone", 45f), 89f)) * Math.PI.toFloat() / 180f
                    for (kk in 0 until 4) {
                        val t = kk.toFloat() * Math.PI.toFloat() / 2f
                        val e = normalizeV(dv * cos(ang) + (aV * cos(t) + bV * sin(t)) * sin(ang))
                        pts.add(S3V.zero); pts.add(S3V(e.x * 1.6f, e.y * 1.6f, e.z * 1.6f))
                    }
                }
                val g = lines(pts, 0xFFFFD94D.toInt())
                g.name = "dir|" + sigStr
                n.addChildNode(g)
            } else {
                val g = S3Node(); g.name = "dir|" + sigStr; n.addChildNode(g)
            }
        }
        val ring = n.childNode("ring")
        if (ring != null) {
            ring.scale = S3V(r, r, r)
            ring.childNodes.forEach { it.geometry?.argb = col }
        }
    }

    private fun camShape(): S3Node {
        val w = 0.35f; val h = 0.2f; val d = -0.5f
        val a = S3V(-w, h, d); val b = S3V(w, h, d); val c = S3V(w, -h, d); val e = S3V(-w, -h, d); val o = S3V.zero
        return lines(listOf(o, a, o, b, o, c, o, e, a, b, b, c, c, e, e, a), 0xFFFF8A1F.toInt())
    }

    private fun planeNode(l: Layer): S3Node {
        val (qw, qh) = Xf.quadSize(l)
        val p = S3Geom(S3Kind.plane)
        p.sizeA = max(qw, 0.05f); p.sizeB = max(qh, 0.05f)
        p.doubleSided = true
        val path = l.imagePath
        if (path != null) {
            val bmp = try { android.graphics.BitmapFactory.decodeFile(path) } catch (_: Exception) { null }
            if (bmp != null) p.img = UIImage(bmp) else p.argb = 0x59CCCCCC.toInt()
        } else p.argb = 0x59CCCCCC.toInt()
        lastTris = Scatter.quad(qw, qh)
        return S3Node().also { it.geometry = p }
    }

    private fun modelNode(l: Layer): S3Node {
        val holder = S3Node()
        val model = l.imagePath?.let { GlbModel.load(GlbModel.validate(path = it)) }
        var builtAny = false
        if (model != null) {
            lastTris = Scatter.tris(model)
            val sk = model.skeleton
            if (sk != null) { skels[l.id] = sk; modelScale[l.id] = model.normalize[0] }
            for (p in model.prims.filter { it.verts.isNotEmpty() && it.mode != GlbModel.GL_TRIANGLES }) {   // point / line prims -> points
                val n2 = p.verts.size / 12
                val g = S3Geom(S3Kind.points)
                g.pointSize = 3f
                for (i2 in 0 until n2) g.verts.add(S3V(p.verts[i2 * 12], p.verts[i2 * 12 + 1], p.verts[i2 * 12 + 2]))
                g.argb = 0xFFFFFFFF.toInt()
                holder.addChildNode(S3Node().also { it.geometry = g }); builtAny = true
            }
            for (p in model.prims.filter { it.verts.isNotEmpty() && it.mode == GlbModel.GL_TRIANGLES }) {
                val vc = p.verts.size / 12
                val idx: IntArray = if (p.cpuIdx.isEmpty()) IntArray(vc) { it } else p.cpuIdx
                val geo = S3Geom(S3Kind.triangles)
                geo.tris = triListFromVerts(p.verts, idx)
                if (p.texBase != 0) {
                    val img = GlbModel.cpuImages[p.texBase]?.img
                    if (img != null) geo.img = UIImage(img)
                }
                val tn = S3Node(); tn.geometry = geo
                holder.addChildNode(tn)
                val m2 = model.skeleton
                if (m2 != null && p.jnt.isNotEmpty() && p.jnt.size == vc * 4) {
                    skinPrims.getOrPut(l.id) { ArrayList() }.add(SkinPrim(tn, p.verts, p.jnt, p.wgt))
                }
                builtAny = true
            }
            // renderer-space normalisation: S(n0) · T(offset)
            val nn = model.normalize
            val tr = M4.identity(); tr.setCol(3, V4(nn[1], nn[2], nn[3], 1f))
            val sc = M4.identity(); sc.setCol(0, V4(nn[0], 0f, 0f, 0f)); sc.setCol(1, V4(0f, nn[0], 0f, 0f)); sc.setCol(2, V4(0f, 0f, nn[0], 0f))
            holder.simdTransform = tr * sc
        }
        if (!builtAny) {   // .vdb / animated / unreadable: a placeholder box so it can still be placed
            val b = S3Geom(S3Kind.box); b.argb = 0x4DB3B3B3.toInt(); b.lineFill = true
            holder.addChildNode(S3Node().also { it.geometry = b })
        }
        holders[l.id] = holder
        return holder
    }

    /** Interleaved verts (pos3, normal3, uv2, color4 — 12 floats) + index -> flat Tri list for the painter. */
    private fun triListFromVerts(verts: FloatArray, idx: IntArray): List<Scatter.Tri> {
        val out = ArrayList<Scatter.Tri>(idx.size / 3)
        var i = 0
        while (i + 2 < idx.size) {
            val a = idx[i] * 12; val b = idx[i + 1] * 12; val c = idx[i + 2] * 12
            if (a + 2 < verts.size && b + 2 < verts.size && c + 2 < verts.size) {
                out.add(Scatter.Tri(V3(verts[a], verts[a + 1], verts[a + 2]), V3(verts[b], verts[b + 1], verts[b + 2]), V3(verts[c], verts[c + 1], verts[c + 2])))
            }
            i += 3
        }
        return out
    }

    private fun isVdb(l: Layer): Boolean = (l.imagePath ?: "").lowercase().endsWith(".vdb")

    /// VDB preview: the density lattice as a point cloud (density threshold + point budget are global settings).
    private fun vdbNode(l: Layer): S3Node {
        val node = S3Node()
        val path = l.imagePath
        val vol = if (path != null) VdbVolume.load(path) else null
        val g = vol?.grids?.firstOrNull()
        if (vol == null || g == null || g.nx <= 0 || g.ny <= 0 || g.nz <= 0) {
            val b = S3Geom(S3Kind.box); b.argb = 0xFFFF8A1F.toInt(); b.lineFill = true
            node.addChildNode(S3Node().also { it.geometry = b }); return node
        }
        var mx = 1e-6f
        for (v in g.data) if (v > mx) mx = v
        val maxPts = (90000 * R3D.g("vpPts", 1f)).toInt()
        val step = max(1.0, ((g.nx * g.ny * g.nz).toDouble() / max(maxPts, 1000).toDouble())).pow(1.0 / 3.0)
        val stepI = max(1, kotlin.math.ceil(step).toInt())
        val th = R3D.g("vpThresh", 0.06f)
        val pos = ArrayList<S3V>(); val col = ArrayList<Float>()
        val b = vol.bounds
        val bx = max(b.first, 0.05f); val by = max(b.second, 0.05f); val bz = max(b.third, 0.05f)
        var z = 0
        while (z < g.nz) { var y = 0
            while (y < g.ny) { var x = 0
                while (x < g.nx) {
                    val d = g.data[x + g.nx * (y + g.ny * z)] / mx
                    if (d > th) {
                        pos.add(S3V((x + 0.5f) / g.nx * 2 * bx - bx, (y + 0.5f) / g.ny * 2 * by - by, (z + 0.5f) / g.nz * 2 * bz - bz))
                        val c = min(1f, sqrt(d)); col.addAll(listOf(c, c, c, c))
                    }
                    x += stepI
                }
                y += stepI
            }
            z += stepI
        }
        if (pos.isEmpty()) return node
        val geo = S3Geom(S3Kind.points)
        geo.verts.addAll(pos); geo.col.addAll(col)
        geo.pointSize = 2f; geo.argb = 0xFFFFFFFF.toInt(); geo.additive = true; geo.writesDepth = false; geo.doubleSided = true
        node.addChildNode(S3Node().also { it.geometry = geo })
        vdbMats[l.id] = geo
        styleVdb(geo, l)
        return node
    }

    private fun styleVdb(m: S3Geom, l: Layer) {
        val c = l.vdbTint
        val br = l.vdbBright * R3D.g("vdbBright", 1f)
        val r = min(1f, ((c shr 16) and 255) / 255f * br); val g2 = min(1f, ((c shr 8) and 255) / 255f * br); val b2 = min(1f, (c and 255) / 255f * br)
        m.argb = 0xFF000000.toInt() or ((r * 255).toInt() shl 16) or ((g2 * 255).toInt() shl 8) or (b2 * 255).toInt()
        m.alpha = min(1f, 0.25f * l.vdbDens * R3D.g("vdbDens", 1f) * l.xf("vdbOpacity", 1f))
    }

    /// Centre the orbit camera on a layer.
    private fun frame(id: Int) {
        val n = nodes[id] ?: return
        target = S3V(n.simdWorldPosition.x, n.simdWorldPosition.y, n.simdWorldPosition.z)
        dist = 3.5f
        applyCam(snap = !built)
    }

    /// Scatter preview: clones of each scattered model, placed exactly like the renderer places them.
    private fun updateScatter(t: Float) {
        for (l in Editor.scene.layers.filter { it.type == LayerType.MODEL && !isVdb(it) }) {
            val root = nodes[l.id] ?: continue
            var mats: List<M4>? = null
            val tid = l.xf("scTarget", -1f).toInt()
            if (syncScene && l.xf("scOn", 0f) > 0.5f) {
                if (tid == -2 || tid == -3) {      // ground / air: same field the renderer builds (no target layer)
                    mats = Scatter.instances(l, l, Scatter.ground(l.xf("scGroundSize", 10f), l.xf("scGroundY", 0f)), M4.identity(), t)
                } else {
                    val tl2 = layer(tid)
                    if (tl2 != null && tl2.id != l.id) {
                        val tn = nodes[tl2.id]
                        val tris = surfaceTris[tl2.id]
                        if (tn != null && tris != null) {
                            val norm = if (tl2.type == LayerType.MODEL) (tn.childNodes.firstOrNull()?.simdWorldTransform ?: M4.identity()) else M4.identity()
                            mats = Scatter.instances(l, tl2, tris, xform(tl2, t) * norm, t)
                        }
                    }
                }
            }
            val pool = scInst[l.id] ?: ArrayList()
            val m = mats
            val holder = root.childNodes.firstOrNull()
            if (m == null || holder == null) {
                pool.forEach { it.removeFromParentNode() }; scInst.remove(l.id); continue
            }
            val visible = syncScene && l.visible && t >= l.start && t <= l.end
            if (l.xf("scKeep", 0f) < 0.5f) root.isHidden = true
            while (pool.size > m.size) pool.removeAt(pool.size - 1).removeFromParentNode()
            while (pool.size < m.size) {
                val n = S3Node(); n.name = "L${l.id}"; n.addChildNode(holder.clone()); world.addChildNode(n); pool.add(n)
                if (mode != Mode.still && l.id == selected) tint(n, true)
            }
            for ((i, n) in pool.withIndex()) { n.simdTransform = m[i]; n.isHidden = !visible || vdbOverlayOK }
            scInst[l.id] = pool
        }
    }

    private fun T(x: Float, y: Float, z: Float): M4 { val m = M4.identity(); m.setCol(3, V4(x, y, z, 1f)); return m }

    /// Same maths as MetalCam.modelMatrix: T(pos) · Rz · Rx · Ry · S(scale).
    private fun xform(l: Layer, t: Float): M4 {
        val lt = l.editTime("x", t)
        val x = l.p("x", lt); val y = l.p("y", lt)
        var z = Xf.worldZ(l, t)
        val rot = M4.fromQuat(Quat.angleAxis(l.p("rotZ", lt) * Math.PI.toFloat() / 180f, V3(0f, 0f, 1f)) *
            Quat.angleAxis(l.p("rotX", lt) * Math.PI.toFloat() / 180f, V3(1f, 0f, 0f)) *
            Quat.angleAxis(l.p("rotY", lt) * Math.PI.toFloat() / 180f, V3(0f, 1f, 0f)))
        if (l.type == LayerType.CAMERA) {
            var fov = l.p("fov", lt); if (!fov.isFinite() || fov < 10f) fov = 55f
            z += 1f / tan(min(fov, 150f) * Math.PI.toFloat() / 360f)
            return T(x, y, z) * rot
        }
        if (l.isLight) return T(x, y, z)
        val sc = l.p("scale", lt)
        val sz = sc * (if (l.type == LayerType.MODEL) l.p("scaleZ", lt) else 1f)
        val m = M4.identity()
        m.setCol(0, V4(sc, 0f, 0f, 0f)); m.setCol(1, V4(0f, sc, 0f, 0f)); m.setCol(2, V4(0f, 0f, sz, 0f))
        return T(x, y, z) * rot * m
    }


    internal fun tick() {
        val h = host ?: return
        val s = Editor.scene.layers.filter { is3dContent(it) }.joinToString(",") { "${it.id}|${it.type}|${it.imagePath ?: ""}" } + "|${R3D.g("vpPts", 1f)}|${R3D.g("vpThresh", 0.06f)}"
        if (s != sig) { sig = s; rebuild() }
        if (h.selId != lastHostSel) {
            lastHostSel = h.selId
            if (mode != Mode.still) select(if (nodes[h.selId] != null) h.selId else -1, notifyHost = false)
        }
        val t = Editor.time
        for (l in Editor.scene.layers) {
            val n = nodes[l.id] ?: continue
            n.isHidden = !syncScene || !l.visible || t < l.start || t > l.end || (vdbOverlayOK && isVdb(l))
            n.opacity = if (vdbOverlayOK && !isVdb(l) && (l.type == LayerType.MODEL || l.type == LayerType.PARTICLES || is3dContent(l)) && l.type != LayerType.CAMERA && !l.isLight) 0.004f else 1f
            n.simdTransform = xform(l, t)
        }
        tickN += 1
        if (camMoving || drag || tickN % 2 == 0) updateVdbOverlay(t)      // every frame while dragging a gizmo, so the picture never trails the handles      // building the change-key is not free: 15 Hz when the camera is still
        updateScatter(t)
        if (!vdbOverlayOK) updateParticles(t)      // the point cloud is only the fallback when the volume overlay can't draw the frame
        updatePose(t)
        gridNode.isHidden = !showGrid || vdbOverlayOK
        updateGizmo()
        tl.isHidden = !showTimeline || fullscreen
        val dur = max(Editor.scene.duration, 0.1f)
        timeLbl.text = String.format(Locale.US, "%.2f / %.1fs", t, dur)
        playBtn.set(name = if (h.playing) "pause" else "play", color = 0xFFFFFFFF.toInt())
        camera.fieldOfView = R3D.g("vpFov", 50f)
        if (!tl.isHidden) {
            if (tabSeg.selectedSegmentIndex == 0) {
                canvas.rows = Editor.scene.layers.filter { is3dContent(it) }
                val sk = skels[selected]
                val sl = layer(selected)
                if (poseMode && sk != null && sl != null) {
                    canvas.poseRows = posedFirst(sk, sl).map { i ->
                        val ts = HashSet<Float>()
                        for (c in listOf("rx", "ry", "rz", "px", "py", "pz")) for (key in sl.track("bn$i" + c).keys) ts.add(kotlin.math.round(key.t * 1000f) / 1000f)
                        Triple(i, sk.bones[i].name, ts.sorted())
                    }
                    canvas.selBone = selBone
                    canvas.onSelectBone = { i -> selectBone(i) }
                } else canvas.poseRows = null
                canvas.selected = selected; canvas.time = t; canvas.dur = dur
                canvas.setNeedsDisplay()
            } else {
                val k = "${tabSeg.selectedSegmentIndex}|${scopeSeg.selectedSegmentIndex}|$selected|$poseMode|$showBones|$selBone|$scLayer|${Editor.scene.layers.count()}|" + Editor.scene.layers.joinToString("") { "${it.id}${it.type}" }
                if (k != propKey) { propKey = k; rebuildProps() }
            }
        }
        for ((id, m) in vdbMats) { val l = layer(id); if (l != null) styleVdb(m, l) }
        for (l in Editor.scene.layers.filter { it.isLight }) { val n = nodes[l.id]?.childNodes?.firstOrNull(); if (n != null) styleLight(n, l) }
        sv.setNeedsDisplay()
    }

    /// VDB through the main renderer (same ray-marcher / settings as the main viewport) with the orbit camera.
    private fun updateVdbOverlay(t: Float) {
        // everything 3D goes through the main renderer (same as the viewport): models, rigs, particles, 3D layers, lights
        val vl = Editor.scene.layers.filter { l ->
            if (!l.visible || t < l.start || t > l.end || l.type == LayerType.CAMERA) return@filter false
            l.type == LayerType.MODEL || l.type == LayerType.PARTICLES || l.is3d || l.isLight
        }
        if (!syncScene || vl.none { !it.isLight } || svWidth() <= 4f) { vdbOverlayBmp = null; vdbOverlayOK = false; return }
        val ar = svWidth() / max(svHeight(), 1f)
        val e = camPos
        val vp = MetalCam.lookAtEye(R3D.g("vpFov", 50f), ar, e.x, e.y, e.z, -cPitch, cYaw, 0f)
        val ovH = 540      // one fixed size: switching sizes re-allocates every render target (memory spikes, blank frames)
        // every other visible 3D layer goes along as an occluder (depth / silhouette only, never drawn twice)
        val occ: List<Layer> = emptyList()
        var key = "H$ovH|v${FrameCache.version}|" + vp.joinToString(",") { String.format(Locale.US, "%.4f", it) } + "|$t|"
        for (l in vl) {
            var s = "${l.id}:${l.vdbDens},${l.vdbBright},${l.vdbTint},${l.vdbEnv},${l.vdbSurround},"
            s += "${l.xf("vdbOpacity", 1f)},${l.xf("vdbContrast", 1f)},${l.xf("vdbShadow", 1f)},${l.xf("vdbSteps", 56f)},"
            s += "${l.p("x", t)},${l.p("y", t)},${l.p("z", t)},${l.p("scale", t)},${l.p("scaleZ", t)},"
            s += "${l.p("rotX", t)},${l.p("rotY", t)},${l.p("rotZ", t)},${l.x3s},${l.rtOn},${l.rtInt},${l.rtRad},${l.imagePath ?: ""};"
            key += s
        }
        key += "|P" + skels.values.joinToString(",") { it.poseSig } + "|${R3D.g("rtAll", 0f)},${R3D.g("rtMul", 1f)},${R3D.g("exposure", 1f)},${R3D.g("light", 1f)},${R3D.g("env", 1f)},${GlobalEnv.path ?: ""},${R3D.g("envRot", 0f)}|grid$showGrid|${R3D.g("vdbDens", 1f)},${R3D.g("vdbBright", 1f)},${R3D.g("vdbQuality", 1f)}|"
        for (l in Editor.scene.layers.filter { it.isLight }) {
            var s = "${l.id},${l.visible},${l.vdbTint},${l.x3s},${l.xf("lightInt", 1f)},${l.xf("lightInf", 1f)},${l.xf("lightType", 0f)},${l.xf("lightPitch", -60f)},${l.xf("lightYaw", 30f)},"
            s += "${l.p("x", t)},${l.p("y", t)},${l.p("z", t)};"
            key += s
        }
        if (key == vdbOvSig) return
        val img = SceneRenderer.shared?.volumeOverlay(occ + vl, vp, t, 2, intArrayOf(max(2, (ovH.toFloat() * ar).toInt()), ovH), true)
        if (img != null) {
            vdbOvSig = key
            vdbOverlayBmp = if (showGrid) gridOverlay(UIImage(img), vp) else UIImage(img)
            vdbOverlayOK = true
        } else if (vdbOverlayBmp == null) vdbOverlayOK = false      // renderer unavailable: point-cloud fallback stays
    }

    /// Draws the ground grid into the same frame (same view-projection) so it can never slide against the volume / models.
    private fun gridOverlay(img: UIImage, vp: FloatArray): UIImage {
        val W = img.size.width; val H = img.size.height
        fun clip(x: Float, z: Float): FloatArray =
            floatArrayOf(vp[0] * x + vp[8] * z + vp[12], vp[1] * x + vp[9] * z + vp[13], vp[2] * x + vp[10] * z + vp[14], vp[3] * x + vp[11] * z + vp[15])
        return UIGraphicsImageRenderer(W.toInt(), H.toInt()).image { ctx ->
            val p = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
            ctx.canvas.drawBitmap(img.bitmap, 0f, 0f, p)
            fun line(a: Pair<Float, Float>, b: Pair<Float, Float>, col: Int, lw: CGFloat) {
                var pt = clip(a.first, a.second); var q = clip(b.first, b.second)
                val nearW = 0.05f
                if (pt[3] < nearW && q[3] < nearW) return@line
                if (pt[3] < nearW) { val t = (nearW - pt[3]) / (q[3] - pt[3]); pt = floatArrayOf(pt[0] + (q[0] - pt[0]) * t, pt[1] + (q[1] - pt[1]) * t, pt[2], nearW) }
                if (q[3] < nearW) { val t = (nearW - q[3]) / (pt[3] - q[3]); q = floatArrayOf(q[0] + (pt[0] - q[0]) * t, q[1] + (pt[1] - q[1]) * t, q[2], nearW) }
                fun ppt(v: FloatArray): CGPoint = CGPoint(v[0] / v[3] * 0.5f + 0.5f, 1f - (v[1] / v[3] * 0.5f + 0.5f))
                ctx.setStrokeColor(col); ctx.setLineWidth(lw)
                ctx.move(CGPoint(ppt(pt).x * W, ppt(pt).y * H)); ctx.addLine(CGPoint(ppt(q).x * W, ppt(q).y * H)); ctx.strokePath()
            }
            val g = 0xFF474747.toInt()
            for (i in -10..10) if (i != 0) {
                line(Pair(i.toFloat(), -10f), Pair(i.toFloat(), 10f), g, 1f); line(Pair(-10f, i.toFloat()), Pair(10f, i.toFloat()), g, 1f)
            }
            line(Pair(-10f, 0f), Pair(10f, 0f), 0xFFD94040.toInt(), 1.5f)
            line(Pair(0f, -10f), Pair(0f, 10f), 0xFF407FF2.toInt(), 1.5f)
        }
    }

    private fun updateGizmo() {
        val scattered = !(scInst[selected]?.isEmpty() ?: true)      // original is hidden while its copies show
        if (mode == Mode.still || !showGizmo) { gizmo.isHidden = true; return }
        val n = nodes[selected]
        if (n == null || (n.isHidden && !scattered)) { gizmo.isHidden = true; return }
        if (poseMode && skels[selected] != null && holders[selected] != null) {      // pose mode: the gizmo sits on the selected bone
            val sk = skels[selected]!!
            if (selBone < 0 || selBone >= sk.bones.size) { gizmo.isHidden = true; return }
            val w = sk.world(); val par = sk.bones[selBone].parent
            val frame = (if (par >= 0 && par < w.size) w[par] else M4.identity()) * sk.bones[selBone].restLocal
            val bp = w[selBone].col(3)
            val h = holders[selected]!!
            val sp = h.worldMatrix() * V4(bp.x, bp.y, bp.z, 1f)
            gizmo.isHidden = false
            gizmo.simdTransform = h.worldMatrix() * frame       // axes follow the bone
            gizmoAnchor = S3V(sp.x, sp.y, sp.z)
            gizmoSimScale = max((gizmoAnchor - camPos).len() * R3D.g("vpGizmo", 0.14f), 0.05f)
            return
        }
        gizmo.isHidden = false
        gizmo.simdTransform = M4.identity()
        val wp = n.simdWorldPosition
        gizmoAnchor = S3V(wp.x, wp.y, wp.z)
        gizmoSimScale = max((wp - camPos).len() * R3D.g("vpGizmo", 0.14f), 0.05f)
    }

    private var gizmoAnchor = S3V(0f, 0f, 0f)
    private var gizmoSimScale = 0.14f

    // MARK: selection
    private fun tint(n: S3Node?, on: Boolean) {
        if (n == null) return
        fun walk(c: S3Node) {
            c.geometry?.emission = if (on) 0xFF00387F.toInt() else 0xFF000000.toInt()
            for (k in c.childNodes) walk(k)
        }
        walk(n)
    }

    private fun select(id: Int, notifyHost: Boolean = true) {
        tint(nodes[selected], false)
        selected = id
        if (mode != Mode.still) tint(nodes[id], true)
        if (notifyHost && id >= 0) { lastHostSel = id; host?.onSelect(id) }
    }

    /** (layer id, gizmo axis) at the screen point — gizmo handle circles first, then projected node anchors. */
    private fun pick(p: CGPoint): Pair<Int, Int>? {
        var axis = -1
        var lid: Int? = null
        var bestAxisD = 30f
        var bestLidD = Float.MAX_VALUE
        if (selected >= 0 && nodes[selected] != null && !gizmo.isHidden) {
            val gx = gizmo.simdWorldTransform
            val anchors = ArrayList<Pair<Int, V4>>()       // axis code, world anchor
            for (i in 0 until 3) {
                val dir = when (i) { 0 -> V4(1f, 0f, 0f, 0f); 1 -> V4(0f, 1f, 0f, 0f); else -> V4(0f, 0f, 1f, 0f) }
                anchors.add(Pair(i, gx * (dir * (1.15f * gizmoSimScale))))
            }
            if (mode == Mode.move) {
                val offs = listOf(V4(0f, 0.32f, 0.32f, 1f), V4(0.32f, 0f, 0.32f, 1f), V4(0.32f, 0.32f, 0f, 1f))
                for (k in offs.indices) anchors.add(Pair(3 + k, gx * (offs[k] * gizmoSimScale)))
            }
            if (mode == Mode.move || mode == Mode.rotate) anchors.add(Pair(6, gx * V4(0f, 0f, 0f, 1f)))
            for ((code, w) in anchors) {
                val sp = project(w) ?: continue
                val d = hypot((sp.x - p.x).toDouble(), (sp.y - p.y).toDouble()).toFloat()
                val hitR = if (code == 6) 26f else 30f
                if (d < hitR && d < bestAxisD) { bestAxisD = d; axis = code }
            }
        }
        for ((id, n) in nodes) {
            if (n.isHidden) continue
            val wp = n.simdWorldPosition
            val sp = project(V4(wp.x, wp.y, wp.z, 1f)) ?: continue
            val d = hypot((sp.x - p.x).toDouble(), (sp.y - p.y).toDouble()).toFloat()
            if (d < 48f && d < bestLidD) { bestLidD = d; lid = id }
        }
        if (axis >= 0 && selected >= 0) return Pair(selected, axis)
        if (lid != null) return Pair(lid, -1)
        return null
    }

    // MARK: camera + gestures
    /// Gestures only move the goal; camStep eases the drawn camera toward it every frame.
    private fun applyCam(snap: Boolean = false) {
        if (snap) { cYaw = yaw; cPitch = pitch; cDist = dist; cTarget = S3V(target.x, target.y, target.z); velYaw = 0f; velPitch = 0f; placeCam(); updateVdbOverlay(Editor.time) }
    }

    private var camPos = S3V(0f, 0f, 6f)

    private fun placeCam() {
        val cp = cos(cPitch); val sp = sin(cPitch)
        camPos.x = cTarget.x + cDist * cp * sin(cYaw)
        camPos.y = cTarget.y + cDist * sp
        camPos.z = cTarget.z + cDist * cp * cos(cYaw)
    }

    internal fun camStep() {
        val dt = min(max(1f / 120f, 1f / 60f), 1f / 20f)
        if (!orbiting && abs(velYaw) + abs(velPitch) > 0.02f) {        // inertia after a flick
            yaw += velYaw * dt; pitch = max(-1.5f, min(1.5f, pitch + velPitch * dt))
            val d = exp(-dt * 4.5f); velYaw *= d; velPitch *= d
        }
        val k = 1f - exp(-dt * 22f)
        val dy = yaw - cYaw; val dp = pitch - cPitch; val dd = dist - cDist
        val dt3 = S3V(target.x - cTarget.x, target.y - cTarget.y, target.z - cTarget.z)
        val moving = abs(dy) > 5e-4f || abs(dp) > 5e-4f || abs(dd) > 2e-3f || dt3.len() > 2e-3f
        if (moving) {
            cYaw += dy * k; cPitch += dp * k; cDist += dd * k
            cTarget = S3V(cTarget.x + dt3.x * k, cTarget.y + dt3.y * k, cTarget.z + dt3.z * k)
            camMoving = true
            placeCam()
            val now = System.nanoTime() / 1e9
            if (now - lastOverlayT >= 1.0 / 24) { lastOverlayT = now; updateVdbOverlay(Editor.time) }
        } else if (camMoving) {
            cYaw = yaw; cPitch = pitch; cDist = dist
            cTarget = S3V(target.x, target.y, target.z)
            camMoving = false
            placeCam(); updateVdbOverlay(Editor.time)      // settled: one full-quality picture
        }
    }

    // raw multi-touch like ParticularViewport: 1 finger orbit / drag, 2 fingers pan or pinch, 3 fingers dolly fast
    private val ptrs = HashMap<Int, Pair<Float, Float>>()
    private var lastOne: Pair<Float, Float>? = null
    private var pinchBase = 0f
    private var pinchDist0 = 0f
    private var downT = 0L
    private var downPt = Pair(0f, 0f)
    private var moved = false
    private var lastPanMid: Pair<Float, Float>? = null
    private var lastTapTime = 0L

    public override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN, android.view.MotionEvent.ACTION_POINTER_DOWN -> {
                ptrs[e.getPointerId(e.actionIndex)] = Pair(e.getX(e.actionIndex), e.getY(e.actionIndex))
                if (ptrs.size == 1) {
                    lastOne = ptrs.values.first()
                    downT = android.os.SystemClock.uptimeMillis()
                    downPt = lastOne!!
                    moved = false
                    // gizmo / selected-object drag starts when the finger lands on a handle
                    if (mode != Mode.still) {
                        val p = ptrs.values.first()
                        val h = pick(CGPoint(p.first, p.second))
                        if (h != null && (h.second >= 0 || (!poseMode && h.first == selected))) {
                            dragAxis = h.second; drag = true      // only gizmo handles / the selected object move; anything else orbits
                            dragPrev = CGPoint(p.first, p.second); dragCur = dragPrev; rotAcc = 0f
                            highlightGizmo(dragAxis)
                            host?.pushUndo()
                        }
                    }
                }
                if (ptrs.size == 2) {
                    drag = false
                    val ps = ptrs.values.toList()
                    pinchDist0 = max(1f, hypot((ps[0].first - ps[1].first).toDouble(), (ps[0].second - ps[1].second).toDouble()).toFloat())
                    pinchBase = dist
                    lastPanMid = null
                }
            }
            android.view.MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount >= 3) {       // 3 fingers: drag up / down to dolly fast
                    if (ptrs.isNotEmpty()) {
                        val y0 = ptrs.values.first().second
                        dist = max(0.1f, min(3000f, dist * exp(-(e.y - y0) * 0.01f)))
                    }
                    setNeedsDisplay()
                    return true
                }
                for (i in 0 until e.pointerCount) ptrs[e.getPointerId(i)] = Pair(e.getX(i), e.getY(i))
                if (ptrs.size == 1) {
                    val p = ptrs.values.first(); val l = lastOne ?: p
                    val d = Pair(p.first - l.first, p.second - l.second)
                    if (hypot((p.first - downPt.first).toDouble(), (p.second - downPt.second).toDouble()) > 8f) moved = true
                    if (drag) {
                        dragCur = CGPoint(p.first, p.second)
                        applyDrag(CGPoint(d.first, d.second))
                        dragPrev = dragCur
                        showReadout()
                    } else {
                        val k = 0.0075f + 0.002f * min(dist, 20f) / 20f
                        yaw -= d.first * k
                        pitch = max(-1.55f, min(1.55f, pitch + d.second * k))
                        orbiting = true
                    }
                    lastOne = p; sv.setNeedsDisplay()
                } else if (ptrs.size == 2) {
                    val ps = ptrs.values.toList()
                    val dNow = max(1f, hypot((ps[0].first - ps[1].first).toDouble(), (ps[0].second - ps[1].second).toDouble()).toFloat())
                    val mid = Pair((ps[0].first + ps[1].first) / 2f, (ps[0].second + ps[1].second) / 2f)
                    val prev = lastPanMid ?: mid
                    if (pinchDist0 > 0f && abs(dNow - pinchDist0) / pinchDist0 > 0.12f) {
                        // it became a pinch: dolly
                        dist = max(0.1f, min(3000f, pinchBase * pinchDist0 / max(dNow, 0.01f)))
                    } else {
                        // two-finger pan: move the camera target in the view plane
                        val k = 2f * dist * tan(camera.fieldOfView * Math.PI.toFloat() / 360f) / max(svHeight(), 1f)
                        val f = normalizeS3(S3V(cTarget.x - camPos.x, cTarget.y - camPos.y, cTarget.z - camPos.z))
                        val right = normalizeS3(crossS3(f, S3V(0f, 1f, 0f)))
                        val up = crossS3(right, f)
                        val dx = mid.first - prev.first; val dy = mid.second - prev.second
                        target.x += (-right.x * dx + up.x * dy) * k
                        target.y += (-right.y * dx + up.y * dy) * k
                        target.z += (-right.z * dx + up.z * dy) * k
                    }
                    lastPanMid = mid
                    sv.setNeedsDisplay()
                }
            }
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_POINTER_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                ptrs.remove(e.getPointerId(e.actionIndex))
                if (ptrs.isEmpty()) {
                    orbiting = false
                    lastPanMid = null
                    if (drag) { drag = false; highlightGizmo(-1); updateModeUI(); host?.render(); host?.refreshPanel() }
                    else if (e.actionMasked == android.view.MotionEvent.ACTION_UP && !moved && android.os.SystemClock.uptimeMillis() - downT < 350) {
                        val now = android.os.SystemClock.uptimeMillis()
                        val dbl = now - lastTapTime < 320
                        lastTapTime = now
                        tappedAt(CGPoint(e.getX(e.actionIndex), e.getY(e.actionIndex)), dbl)
                    }
                }
                if (ptrs.size == 1) lastOne = ptrs.values.first()
                if (ptrs.size < 2) { pinchDist0 = 0f; lastPanMid = null }
            }
        }
        return true
    }

    private fun tappedAt(p: CGPoint, doubleTap: Boolean) {
        if (mode == Mode.still) return
        if (poseMode || showBones) {
            val b = pickBone(p)
            if (b != null) {      // bones are tappable whenever they are drawn
                if (b.first != selected) select(b.first)
                if (!poseMode) setPose(true)
                selectBone(b.second); return
            }
        }
        val h = pick(p)
        if (h != null) { select(h.first); if (doubleTap) frame(h.first) } else { select(-1); host?.onSelect(-1) }
    }

    private fun applyDrag(d: CGPoint) {
        val l = layer(selected) ?: return
        val n = nodes[selected] ?: return
        if (poseMode && skels[selected] != null) { applyBoneDrag(d); return }
        val t = Editor.time; val ak = host?.autoKeyOn ?: false
        if (mode == Mode.scale) {
            val f = 1f - d.y * 0.006f
            l.track("scale").set(t, max(0.01f, l.p("scale", t) * f), ak)
            return
        }
        if (mode == Mode.rotate) {
            // ring picked: rotate about that axis by the angle swept around the gizmo; centre / empty drag: free yaw + pitch
            fun add(k: String, v: Float) { l.track(k).set(t, l.p(k, t) + v, ak) }
            val c = n.simdWorldPosition
            when (dragAxis) {
                0 -> snapped(ringAngle(V3(1f, 0f, 0f), V3(c.x, c.y, c.z))) { add("rotX", it) }
                1 -> snapped(ringAngle(V3(0f, 1f, 0f), V3(c.x, c.y, c.z))) { add("rotY", it) }
                2 -> snapped(ringAngle(V3(0f, 0f, 1f), V3(c.x, c.y, c.z))) { add("rotZ", it) }
                else -> { add("rotY", d.x * 0.5f); add("rotX", d.y * 0.5f) }
            }
            return
        }
        val pos = n.simdWorldPosition
        var dw = S3V(0f, 0f, 0f)
        if (dragAxis in 0..2) {
            val dir = when (dragAxis) { 0 -> S3V(1f, 0f, 0f); 1 -> S3V(0f, 1f, 0f); else -> S3V(0f, 0f, 1f) }
            val a = projectV(pos) ?: return
            val b = projectV(pos + dir) ?: return
            val sx = b.x - a.x; val sy = b.y - a.y
            val den = sx * sx + sy * sy
            if (den > 1e-4f) dw = dir * ((d.x * sx + d.y * sy) / den)
        } else if (dragAxis in 3..5) {
            val nrm = when (dragAxis - 3) { 0 -> S3V(1f, 0f, 0f); 1 -> S3V(0f, 1f, 0f); else -> S3V(0f, 0f, 1f) }
            dw = planeDelta(pos, nrm) ?: S3V.zero
        } else {
            val dd = (pos - camPos).len()
            val k = 2f * dd * tan(camera.fieldOfView * Math.PI.toFloat() / 360f) / max(svHeight(), 1f)
            val f = normalizeS3(S3V(cTarget.x - camPos.x, cTarget.y - camPos.y, cTarget.z - camPos.z))
            val right = normalizeS3(crossS3(f, S3V(0f, 1f, 0f)))
            val up = crossS3(right, f)
            dw = right * (d.x * k) - up * (d.y * k)
        }
        l.track("x").set(t, l.p("x", t) + dw.x, ak)
        l.track("y").set(t, l.p("y", t) + dw.y, ak)
        l.track("z").set(t, l.p("z", t) + dw.z, ak)
    }

    // MARK: projection (SCNView projectPoint / unprojectPoint twin)

    private var cachedVP: FloatArray? = null

    /** View-projection of the orbit camera (same convention as MetalCam.lookAtEye: rx = -pitch, ry = yaw). */
    private fun vpMatrix(): FloatArray {
        cachedVP?.let { return it }
        val ar = svWidth() / max(svHeight(), 1f)
        val vp = MetalCam.lookAtEye(camera.fieldOfView, ar, camPos.x, camPos.y, camPos.z, -cPitch, cYaw, 0f)
        cachedVP = vp
        return vp
    }

    private fun project(w: V4): CGPoint? {
        val vp = vpMatrix()
        val cx = vp[0] * w.x + vp[4] * w.y + vp[8] * w.z + vp[12]
        val cy = vp[1] * w.x + vp[5] * w.y + vp[9] * w.z + vp[13]
        val cw = vp[3] * w.x + vp[7] * w.y + vp[11] * w.z + vp[15]
        if (cw <= 0.01f) return null
        return CGPoint((cx / cw * 0.5f + 0.5f) * svWidth(), (1f - (cy / cw * 0.5f + 0.5f)) * svHeight())
    }

    private fun projectV(p: S3V): CGPoint? = project(V4(p.x, p.y, p.z, 1f))

    /** World ray through a screen point (SCNView unprojectPoint twin). */
    private fun unprojectRay(px: CGFloat, py: CGFloat): Pair<S3V, S3V>? {
        val vp = vpMatrix()
        val inv = invertVP(vp) ?: return null
        fun tf(x: Float, y: Float, z: Float, w: Float): V4 =
            V4(inv[0] * x + inv[4] * y + inv[8] * z + inv[12] * w,
                inv[1] * x + inv[5] * y + inv[9] * z + inv[13] * w,
                inv[2] * x + inv[6] * y + inv[10] * z + inv[14] * w,
                inv[3] * x + inv[7] * y + inv[11] * z + inv[15] * w)
        val nx = (px / max(svWidth(), 1f)) * 2f - 1f
        val ny = 1f - (py / max(svHeight(), 1f)) * 2f
        val a = tf(nx, ny, -1f, 1f); val b = tf(nx, ny, 1f, 1f)
        val av = S3V(a.x / a.w, a.y / a.w, a.z / a.w)
        val bv = S3V(b.x / b.w, b.y / b.w, b.z / b.w)
        val d = bv - av
        if (d.len() < 1e-8f) return null
        return Pair(S3V(camPos.x, camPos.y, camPos.z), d)
    }

    private var vpInverseCache: Pair<FloatArray, FloatArray>? = null

    private fun invertVP(vp: FloatArray): FloatArray? {
        vpInverseCache?.let { if (it.first.contentEquals(vp)) return it.second }
        val inv = try { M4(vp.copyOf()).inverse() } catch (_: Exception) { null } ?: return null
        val out = inv.m.copyOf()
        vpInverseCache = Pair(vp.copyOf(), out)
        return out
    }

    /** World movement of the touch point on the plane through `origin` with normal `n` since the last touch. */
    internal fun planeDelta(origin: S3V, n: S3V): S3V? {
        fun hit(p: CGPoint): S3V? {
            val ray = unprojectRay(p.x, p.y) ?: return null
            val o = ray.first; val rn = normalizeS3(ray.second)
            val dn = dotS3(rn, n)
            if (abs(dn) < 0.05f) return null
            val dist = dotS3(origin - o, n) / dn
            return o + rn * dist
        }
        val p0 = hit(dragPrev) ?: return null
        val p1 = hit(dragCur) ?: return null
        return p1 - p0
    }

    /// Degrees swept around `center` (on screen) since the last touch, signed for a right-handed rotation about `axis`.
    internal fun ringAngle(axis: V3, center: V3): Float {
        val c = projectV(S3V(center.x, center.y, center.z)) ?: return 0f
        val a0 = atan2(dragPrev.y - c.y, dragPrev.x - c.x)
        val a1 = atan2(dragCur.y - c.y, dragCur.x - c.x)
        var da = a1 - a0
        if (da > Math.PI.toFloat()) da -= 2f * Math.PI.toFloat()
        if (da < -Math.PI.toFloat()) da += 2f * Math.PI.toFloat()
        val toCam = normalizeS3(S3V(camPos.x - center.x, camPos.y - center.y, camPos.z - center.z))
        val facing = if (dotS3(S3V(axis.x, axis.y, axis.z), toCam) >= 0f) 1f else -1f      // screen y points down: counter-clockwise = decreasing angle
        return -da * facing * 180f / Math.PI.toFloat()
    }

    /// Snaps rotation to 5 degree steps when Snap is on.
    internal fun snapped(v: Float, f: (Float) -> Unit) {
        if (!snapOn) { f(v); return }
        rotAcc += v
        val n = kotlin.math.round(rotAcc / 5f).toInt()
        if (n != 0) { f(n * 5f); rotAcc -= n * 5f }
    }

    /// Shows the values being edited in the top chip while a handle is dragged.
    internal fun showReadout() {
        val l = layer(selected) ?: return
        val t = Editor.time
        fun v3(k: List<String>, f: String): String = listOf("X" to k[0], "Y" to k[1], "Z" to k[2]).joinToString("   ") { (n, key) -> "$n " + String.format(Locale.US, f, l.p(key, t)) }
        if (poseMode && skels[selected] != null && selBone >= 0) {
            val i = selBone
            if (mode == Mode.rotate) chip.text = "Rotate  " + v3(listOf("bn${i}rx", "bn${i}ry", "bn${i}rz"), "%.1f") + (if (snapOn) "  (snap)" else "")
            else if (mode == Mode.move) chip.text = "Move  " + v3(listOf("bn${i}px", "bn${i}py", "bn${i}pz"), "%.3f")
        } else if (mode == Mode.rotate) chip.text = "Rotate  " + v3(listOf("rotX", "rotY", "rotZ"), "%.1f") + (if (snapOn) "  (snap)" else "")
        else if (mode == Mode.move) chip.text = "Move  " + v3(listOf("x", "y", "z"), "%.2f")
        else if (mode == Mode.scale) chip.text = "Scale  " + String.format(Locale.US, "%.2f", l.p("scale", t))
        chip.setNeedsDisplay()
    }


    // ============================================================ software rasteriser (SCNView.draw twin)

    /** Renders the scene graph into `sv`'s canvas: opaque depth-sorted batches, then additive / no-depth passes. */
    private fun drawScene() {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = sv.rectWidth(); val h = sv.rectHeight()
        if (w <= 1f || h <= 1f) return
        cachedVP = null      // the camera may have moved since the last frame
        c.setFillColor(android.graphics.Color.BLACK)
        c.fill(CGRect(0f, 0f, w, h))
        // opaque batches first, translucent / no-depth (gizmo, bones, points) after (renderingOrder breaks ties)
        val items = ArrayList<Pair<Int, () -> Unit>>()
        fun walk(n: S3Node, parentVisible: Boolean, parentOpacity: Float) {
            val vis = parentVisible && !n.isHidden
            val op = parentOpacity * n.opacity
            if (vis) {
                val g = n.geometry
                if (g != null && g.alpha > 0.003f) {
                    val m = n.worldMatrix()
                    val solid = g.writesDepth && !g.additive && g.alpha >= 0.999f
                    items.add(Pair(if (solid) n.renderingOrder else n.renderingOrder + 5000) { drawGeom(c, g, m, w, h, op) })
                }
            }
            for (ch in n.childNodes) walk(ch, vis, op)
        }
        walk(scn, true, 1f)
        items.sortBy { it.first }
        for ((_, d) in items) d()
        vdbView.setNeedsDisplay()
    }

    /** One geometry batch under one node matrix. */
    private fun drawGeom(c: com.saiki.motion.uikit.CGContext, g: S3Geom, m: M4, w: CGFloat, h: CGFloat, nodeOpacity: Float) {
        fun xf(v: S3V): V4 = m * V4(v.x, v.y, v.z, 1f)
        fun screen(p4: V4): CGPoint? {
            val vp = vpMatrix()
            val cw = vp[3] * p4.x + vp[7] * p4.y + vp[11] * p4.z + vp[15]
            if (cw <= 0.01f) return null
            val cx = vp[0] * p4.x + vp[4] * p4.y + vp[8] * p4.z + vp[12]
            val cy = vp[1] * p4.x + vp[5] * p4.y + vp[9] * p4.z + vp[13]
            return CGPoint((cx / cw * 0.5f + 0.5f) * w, (1f - (cy / cw * 0.5f + 0.5f)) * h)
        }
        val a = ((g.argb ushr 24) and 0xFF) / 255f * g.alpha * nodeOpacity
        if (a <= 0.004f) return
        val col = if (g.emission != 0xFF000000.toInt()) (g.emission and 0x00FFFFFF) or (g.argb and 0xFF000000.toInt()) else g.argb
        c.setAlpha(min(1f, a))
        when (g.kind) {
            S3Kind.lines -> {
                c.setStrokeColor(col); c.setLineWidth(1.2f)
                var i = 0
                while (i + 1 < g.verts.size) {
                    val p = screen(xf(g.verts[i])); val q = screen(xf(g.verts[i + 1]))
                    if (p != null && q != null) { c.move(p); c.addLine(q); c.strokePath() }
                    i += 2
                }
            }
            S3Kind.points -> {
                val p = android.graphics.Paint(c.paint)
                val hasCol = g.col.isNotEmpty()
                for ((i, v) in g.verts.withIndex()) {
                    val s = screen(xf(v)) ?: continue
                    if (hasCol && i * 4 + 3 < g.col.size) {
                        val r = (min(1f, g.col[i * 4]) * 255).toInt(); val gg = (min(1f, g.col[i * 4 + 1]) * 255).toInt(); val b = (min(1f, g.col[i * 4 + 2]) * 255).toInt()
                        val al = (min(1f, g.col[i * 4 + 3]) * a * 255).toInt()
                        p.color = (al shl 24) or (r shl 16) or (gg shl 8) or b
                    } else p.color = col
                    c.canvas.drawCircle(s.x, s.y, g.pointSize, p)
                }
            }
            S3Kind.triangles -> {
                val p = android.graphics.Paint(c.paint)
                p.color = col
                for (tri in g.tris) {
                    val pa = screen(xf(S3V(tri.a.x, tri.a.y, tri.a.z))) ?: continue
                    val pb = screen(xf(S3V(tri.b.x, tri.b.y, tri.b.z))) ?: continue
                    val pc = screen(xf(S3V(tri.c.x, tri.c.y, tri.c.z))) ?: continue
                    val path = android.graphics.Path()
                    path.moveTo(pa.x, pa.y); path.lineTo(pb.x, pb.y); path.lineTo(pc.x, pc.y); path.close()
                    val nrm = normalizeV(crossV(tri.b - tri.a, tri.c - tri.a))
                    val shade = 0.55f + 0.45f * max(0f, nrm.y)
                    p.color = (0xFF shl 24) or (((col ushr 16 and 0xFF) * shade).toInt() shl 16) or (((col ushr 8 and 0xFF) * shade).toInt() shl 8) or ((col and 0xFF) * shade).toInt()
                    c.canvas.drawPath(path, p)
                }
            }
            S3Kind.plane -> {
                val hw = g.sizeA / 2f; val hh = g.sizeB / 2f
                val corners = listOf(S3V(-hw, -hh, 0f), S3V(hw, -hh, 0f), S3V(hw, hh, 0f), S3V(-hw, hh, 0f)).map { xf(it) }
                val pts = corners.map { screen(it) }
                if (pts.all { it != null }) {
                    val path = android.graphics.Path()
                    path.moveTo(pts[0]!!.x, pts[0]!!.y)
                    for (i in 1 until 4) path.lineTo(pts[i]!!.x, pts[i]!!.y)
                    path.close()
                    val p = android.graphics.Paint(c.paint)
                    val img = g.img
                    if (img != null) {
                        p.alpha = 255
                        c.canvas.drawBitmap(img.bitmap, null, android.graphics.RectF(pts.minOf { it!!.x }, pts.minOf { it!!.y }, pts.maxOf { it!!.x }, pts.maxOf { it!!.y }), p)
                    } else {
                        p.color = col
                        c.canvas.drawPath(path, p)
                    }
                }
            }
            S3Kind.box -> {
                val s2 = g.sizeA / 2f
                val cs = listOf(
                    S3V(-s2, -s2, -s2), S3V(s2, -s2, -s2), S3V(s2, s2, -s2), S3V(-s2, s2, -s2),
                    S3V(-s2, -s2, s2), S3V(s2, -s2, s2), S3V(s2, s2, s2), S3V(-s2, s2, s2))
                if (g.lineFill) {
                    val edges = listOf(0 to 1, 1 to 2, 2 to 3, 3 to 0, 4 to 5, 5 to 6, 6 to 7, 7 to 4, 0 to 4, 1 to 5, 2 to 6, 3 to 7)
                    c.setStrokeColor(col); c.setLineWidth(1.2f)
                    for ((i, j) in edges) {
                        val p = screen(xf(cs[i])) ?: continue
                        val q = screen(xf(cs[j])) ?: continue
                        c.move(p); c.addLine(q); c.strokePath()
                    }
                } else {
                    val quads = listOf(listOf(0, 1, 2, 3), listOf(4, 5, 6, 7), listOf(0, 1, 5, 4), listOf(2, 3, 7, 6), listOf(1, 2, 6, 5), listOf(0, 3, 7, 4))
                    val p = android.graphics.Paint(c.paint); p.color = col
                    for (q in quads) {
                        val pts = q.map { screen(xf(cs[it])) }
                        if (pts.any { it == null }) continue
                        val path = android.graphics.Path()
                        path.moveTo(pts[0]!!.x, pts[0]!!.y)
                        for (i in 1 until 4) path.lineTo(pts[i]!!.x, pts[i]!!.y)
                        path.close()
                        c.canvas.drawPath(path, p)
                    }
                }
            }
            S3Kind.sphere -> {
                val wp = m * V4(0f, 0f, 0f, 1f)
                val sp = screen(wp) ?: return
                // radius in px: project a point one radius towards screen-right
                val rp2 = screen(m * V4(g.sizeA, 0f, 0f, 1f))
                val rx = if (rp2 != null) hypot((rp2.x - sp.x).toDouble(), (rp2.y - sp.y).toDouble()).toFloat() else g.sizeA * 10f
                c.setFillColor(col)
                c.fillEllipse(CGRect(sp.x - rx, sp.y - rx, rx * 2f, rx * 2f))
            }
            S3Kind.cylinder, S3Kind.cone -> {
                // shaft along local +Y from 0..height (gizmo handles)
                val r = g.sizeA; val hh = g.sizeB
                val pa = screen(m * V4(0f, 0f, 0f, 1f)) ?: return
                val pb = screen(m * V4(0f, hh, 0f, 1f)) ?: return
                val side2 = screen(m * V4(r, 0f, 0f, 1f))
                val rx = if (side2 != null) hypot((side2.x - pa.x).toDouble(), (side2.y - pa.y).toDouble()).toFloat() else r * 10f
                val p = android.graphics.Paint(c.paint); p.color = col
                if (g.kind == S3Kind.cylinder) {
                    c.fillEllipse(CGRect(pa.x - rx, pa.y - rx, rx * 2f, rx * 2f))
                    c.fillEllipse(CGRect(pb.x - rx, pb.y - rx, rx * 2f, rx * 2f))
                    val path = android.graphics.Path()
                    path.moveTo(pa.x - rx, pa.y); path.lineTo(pa.x + rx, pa.y); path.lineTo(pb.x + rx, pb.y); path.lineTo(pb.x - rx, pb.y); path.close()
                    c.canvas.drawPath(path, p)
                } else {
                    val path = android.graphics.Path()
                    path.moveTo(pa.x - rx, pa.y); path.lineTo(pa.x + rx, pa.y); path.lineTo(pb.x, pb.y); path.close()
                    c.canvas.drawPath(path, p)
                }
            }
            S3Kind.torus -> {
                // ring in the local XY plane (rotate gizmo)
                c.setStrokeColor(col); c.setLineWidth(3f)
                var first = true
                for (i in 0..48) {
                    val t2 = i / 48f * 2f * Math.PI.toFloat()
                    val s = screen(m * V4(cos(t2) * g.sizeA, sin(t2) * g.sizeA, 0f, 1f)) ?: continue
                    if (first) { c.move(s); first = false } else c.addLine(s)
                }
                c.strokePath()
            }
            S3Kind.text -> {
                val sp = screen(m * V4(0f, 0f, 0f, 1f)) ?: return
                drawText(g.label ?: "", sp.x, sp.y, color = col, size = 12f, bold = true, align = NSTextAlignment.center)
            }
        }
        c.setAlpha(1f)
    }

    // MARK: UI
    private fun sym(name: String, size: CGFloat = 20f): UIImage? = Icons.sf(name)

    /** UIButton(type: .custom) twin for the toolbars. */
    internal class S3Btn(val icon: String, var tint: Int = 0xFFFFFFFF.toInt()) : TapView() {
        var onClickAction: (() -> Unit)? = null
        var bgOn = false; var bgCol = 0
        init { onClick = { onClickAction?.invoke() } }
        fun highlight(on: Boolean, col: Int) { bgOn = on; bgCol = col; setNeedsDisplay() }
        public override fun draw(rect: CGRect) {
            val c = UIGraphics.getCurrentContext() ?: return
            if (bgOn) fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 12f, bgCol)
            Icons.draw(c, Icons.ownName(icon), rect.width / 2, rect.midY, min(rect.width, 20f), tint)
        }
    }

    private fun buildUI() {
        // header: back, cube, title, Object/Pose segment, close
        val back = S3Btn("chevron.left"); back.onClickAction = { close() }
        val cube = IconView("cube", 0xFFFFFFFF.toInt(), 22f)
        val title = UILabel(appContext!!)
        title.text = "Scene 3D"; title.textColor = argbToUIColor(0xFFFFFFFF.toInt()); title.font = boldFont(22f)
        val x = S3Btn("xmark"); x.onClickAction = { close() }
        modeSeg.selectedSegmentIndex = if (poseMode) 1 else 0
        modeSeg.onValueChanged = { setPose(modeSeg.selectedSegmentIndex == 1) }
        header.add(com.saiki.motion.app.EBox(back, 40f, 40f, 0f, 0f, 0f, 0f))
        header.add(com.saiki.motion.app.EBox(cube, 30f, 30f, 0f, 0f, 0f, 0f))
        header.add(com.saiki.motion.app.EBox(title, 130f, 34f, 0f, 0f, 0f, 0f))
        header.add(com.saiki.motion.app.EBox(UiView(appContext!!), 0f, 0f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        header.add(com.saiki.motion.app.EBox(modeSeg, 150f, 32f, 0f, 0f, 0f, 0f))
        header.add(com.saiki.motion.app.EBox(x, 40f, 40f, 0f, 0f, 0f, 0f))
        header.spacing = 12f
        addSubview(header)

        // viewport
        sv.addSubview(vdbView)
        addSubview(sv)

        // bottom bar: mode chip (left) + plus menu (right)
        chip.textColor = argbToUIColor(0xFFFFFFFF.toInt()); chip.font = sysFont(17f)
        val bar = UiView(appContext!!); barView = bar
        plus.onClick = { plusTap() }
        bar.addSubview(chip); bar.addSubview(plus)
        tabSeg.selectedSegmentIndex = 0
        tabSeg.onValueChanged = { tabChanged() }
        bar.addSubview(tabSeg)
        chip.isHidden = true
        addSubview(bar)

        // bottom panel: timeline or properties
        playBtn.onClick = { playTap() }
        val prev = S3Btn("backward.end.fill"); prev.onClickAction = { prevKey() }
        val next = S3Btn("forward.end.fill"); next.onClickAction = { nextKey() }
        val key = S3Btn("diamond", accent); key.onClickAction = { keyTap() }
        val del = S3Btn("diamond.fill", 0xFFFF3B30.toInt()); del.onClickAction = { delKey() }
        timeLbl.textColor = argbToUIColor(0xFFAAAAAA.toInt())
        timeLbl.font = UIFont.monospacedDigitSystemFont(13f, 500)
        val row = com.saiki.motion.app.EHStack()
        row.spacing = 18f
        for ((v, ww) in listOf(playBtn to 40f, prev to 40f, next to 40f)) row.add(com.saiki.motion.app.EBox(v, ww, 40f, 0f, 0f, 0f, 0f))
        row.add(com.saiki.motion.app.EBox(UiView(appContext!!), 0f, 0f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        row.add(com.saiki.motion.app.EBox(timeLbl, 160f, 20f, 0f, 0f, 0f, 0f))
        row.add(com.saiki.motion.app.EBox(key, 40f, 40f, 0f, 0f, 0f, 0f))
        row.add(com.saiki.motion.app.EBox(del, 40f, 40f, 0f, 0f, 0f, 0f))
        canvas.onSeek = { t -> host?.onSeek(t) }
        canvas.onSelect = { id -> select(id) }
        canvas.setBackgroundColor(0x0DFFFFFF.toInt())
        val col = com.saiki.motion.app.EVStack()
        col.add(row); col.add(canvas)
        tlBox.addSubview(col)
        scopeSeg.selectedSegmentIndex = 0
        scopeSeg.onValueChanged = { propKey = "" }
        propScroll.content.add(propStack)
        propScroll.isHidden = true
        scopeSeg.isHidden = true
        tl.addSubview(tlBox); tl.addSubview(scopeSeg); tl.addSubview(propScroll)
        tl.setBackgroundColor(0xFF141414.toInt())
        addSubview(tl)

        // viewport corner buttons: fullscreen + frame selected + undo / redo / delete
        val fs = S3Btn("arrow.up.left.and.arrow.down.right"); fs.onClickAction = { toggleFull() }
        val fr = S3Btn("scope"); fr.onClickAction = { frameSel() }
        val un = S3Btn("arrow.uturn.backward"); un.onClickAction = { undoTap() }
        val re = S3Btn("arrow.uturn.forward"); re.onClickAction = { redoTap() }
        val tr = S3Btn("trash", 0xFFFF3B30.toInt()); tr.onClickAction = { deleteTap() }
        for (b in listOf(fs, fr, un, re, tr)) s3Corner.add(com.saiki.motion.app.EBox(b, 44f, 44f, 0f, 0f, 0f, 0f))
        s3Corner.setBackgroundColor(0xE6191919.toInt())
        sv.addSubview(s3Corner)
        fsBtn = fs

        // left mode toolbar over the viewport
        val icons = listOf("hand.raised", "arrow.up.and.down.and.arrow.left.and.right", "rotate.3d", "arrow.up.left.and.arrow.down.right", "figure.stand", "xray")
        s3Tools.setBackgroundColor(0xE6191919.toInt())
        for ((i, ic) in icons.withIndex()) {
            val b = S3Btn(ic)
            b.onClickAction = { modeTap(i) }
            s3Tools.add(com.saiki.motion.app.EBox(b, 40f, 40f, 0f, 0f, 0f, 0f))
            modeBtns.add(b)
        }
        sv.addSubview(s3Tools)          // inside the viewport so it can never spill over the tab bar
        layoutAll()
    }

    private fun updateModeUI() {
        for ((i, b) in modeBtns.withIndex()) {
            b.highlight((if (i < 4) i == mode.raw else (if (i == 4) poseMode else Editor.xray)), accent)
        }
        chip.text = when (mode) { Mode.still -> "Still  ·  view only"; Mode.move -> "Edit Viewport  ·  Move"; Mode.rotate -> "Edit Viewport  ·  Rotate"; Mode.scale -> "Edit Viewport  ·  Scale" }
        if (poseMode) chip.text = poseChipText()
        if (mode == Mode.still) { tint(nodes[selected], false); gizmo.isHidden = true }
        else tint(nodes[selected], true)
        buildGizmo()
    }

    private fun modeTap(i: Int) {
        if (i == 4) { setPose(!poseMode); return }
        if (i == 5) { toggleXray(); return }
        mode = Mode.fromRaw(i); updateModeUI()
    }

    internal fun setPose(on: Boolean) {
        poseMode = on
        if (modeSeg.selectedSegmentIndex != (if (on) 1 else 0)) modeSeg.selectedSegmentIndex = if (on) 1 else 0
        if (on) { tabSeg.selectedSegmentIndex = 0; showTimeline = true; if (mode == Mode.still || mode == Mode.scale) mode = Mode.move }
        canvas.setNeedsDisplay()
        markBones(); propKey = ""; updateModeUI(); rebuildMenu()
    }

    /// The + menu is a custom popover (PlusMenu.swift); nothing to rebuild, items are read fresh on every open / toggle.
    private fun rebuildMenu() {}

    private fun plusTap() {
        val m = subviews.compactMapS3<PlusMenuView>().firstOrNull()
        if (m != null) { m.dismiss(); return }
        PlusMenuView(accent).present(this, plus) { plusItems() }
    }

    private inline fun <reified T> List<UiView>.compactMapS3(): List<T> = filterIsInstance<T>()

    private fun plusItems(): List<PlusItem> {
        fun panel(f: (com.saiki.motion.app.EditorViewController, UiView) -> Unit): () -> Unit {
            return { host?.let { h -> f(h, this@Scene3DView) } }
        }
        return listOf(
            PlusItem("Import", "import", children = listOf(
                PlusItem("3D Model", "cube") { host?.pickFile(com.saiki.motion.app.R_GLB) },
                PlusItem("MikuMikuDance", "person") { host?.pickFile(com.saiki.motion.app.R_GLB) },
                PlusItem("VRM", "person") { host?.pickFile(com.saiki.motion.app.R_GLB) })),
            PlusItem("Add to scene", "plus", children = listOf(
                PlusItem("Simulations", "sim") { panel { h, v -> SimulationsPanel.present(h, v) }() },
                PlusItem("Extras", "layers") { panel { h, v -> ExtrasPanel.present(h, v) }() },
                PlusItem("Terrain", "terrain") { panel { h, v -> TerrainPanel.present(h, v) }() },
                PlusItem("Environment", "env") { panel { h, v -> EnvPanel.present(h, v) }() },
                PlusItem("Lighting", "light") { panel { h, v -> LightPanel.present(h, v) }() })),
            PlusItem("View", "eye", children = listOf(
                PlusItem("3D Scene", "cube", checked = syncScene) { syncScene = !syncScene },
                PlusItem("Grid", "grid", checked = showGrid) { showGrid = !showGrid },
                PlusItem("Timeline", "timeline", checked = showTimeline) { showTimeline = !showTimeline },
                PlusItem("Gizmo", "gizmo", checked = showGizmo) { showGizmo = !showGizmo },
                PlusItem("X-Ray", "xray", checked = Editor.xray) { toggleXray() })),
            PlusItem("Pose", "pose", children = listOf(
                PlusItem("Pose Mode", "pose", checked = poseMode) { setPose(!poseMode) },
                PlusItem("Show Bones", "bone", checked = showBones) { showBones = !showBones; markBones(); propKey = "" },
                PlusItem("Snap rotation (5 deg)", "grid", checked = snapOn) { snapOn = !snapOn; rotAcc = 0f })))
    }

    // MARK: x-ray (3D editor viewport + main editor preview; never exported)
    private val xrayOrig = HashMap<S3Geom, FloatArray>()

    internal fun toggleXray() { Editor.xray = !Editor.xray; applyXray(); updateModeUI(); host?.render() }

    /// Makes every model in the viewport see-through (no depth write) or puts the materials back.
    internal fun applyXray() {
        val on = Editor.xray
        for ((id, root) in nodes) {
            if (layer(id)?.type != LayerType.MODEL) continue
            fun walk(n: S3Node) {
                val g = n.geometry
                if (g != null) {
                    if (on) {
                        if (!xrayOrig.containsKey(g)) xrayOrig[g] = floatArrayOf(g.alpha, if (g.writesDepth) 1f else 0f, g.argb.toFloat())
                        g.alpha = 0.38f; g.writesDepth = false; g.argb = 0x66FFFFFF.toInt()
                    } else {
                        val o = xrayOrig[g]
                        if (o != null) { g.alpha = o[0]; g.writesDepth = o[1] != 0f; g.argb = o[2].toInt() }
                    }
                }
                for (c in n.childNodes) walk(c)
            }
            walk(root)
        }
        if (!on) xrayOrig.clear()
    }

    // MARK: timeline actions (drive the main editor's playhead)
    private fun playTap() { host?.togglePlay() }

    private fun keyTimes(l: Layer): List<Float> {
        val ts = HashSet<Float>()
        for (k in listOf("x", "y", "z", "scale", "rotX", "rotY", "rotZ", "fov")) for (key in l.track(k).keys) ts.add(kotlin.math.round(key.t * 1000f) / 1000f)
        return ts.sorted()
    }

    private fun prevKey() {
        val t = Editor.time
        val l = layer(selected)
        val ks = poseBoneTimes(l) ?: (l?.let { keyTimes(it) })
        val k = ks?.lastOrNull { it < t - 0.01f }
        if (k != null) host?.onSeek(k) else host?.onSeek(max(0f, t - 1f / 30f))
    }
    private fun nextKey() {
        val t = Editor.time
        val l = layer(selected)
        val ks = poseBoneTimes(l) ?: (l?.let { keyTimes(it) })
        val k = ks?.firstOrNull { it > t + 0.01f }
        if (k != null) host?.onSeek(k) else host?.onSeek(min(Editor.scene.duration, t + 1f / 30f))
    }

    /// Diamond: key the selected layer's position + scale + rotation at the playhead.
    private fun keyTap() {
        if (mode == Mode.still) return
        val l = layer(selected) ?: return
        host?.pushUndo()
        val t = Editor.time
        val sk = skels[l.id]
        if (poseMode && sk != null && selBone >= 0 && selBone < sk.bones.size) {      // pose mode: key the selected bone
            for (c in listOf("rx", "ry", "rz", "px", "py", "pz")) l.track("bn$selBone" + c).set(t, l.p("bn$selBone" + c, t), true)
            host?.render(); host?.refreshPanel(); return
        }
        val ks = if (l.type == LayerType.CAMERA) listOf("x", "y", "z", "rotX", "rotY", "rotZ", "fov")
            else listOf("x", "y", "z", "scale", "rotX", "rotY", "rotZ") + (if (l.type == LayerType.MODEL) listOf("scaleZ") else emptyList())
        for (k in ks) l.track(k).set(t, l.p(k, t), true)
        host?.render(); host?.refreshPanel()
    }

    private fun poseBoneTimes(l: Layer?): List<Float>? {
        if (l == null || !poseMode) return null
        val sk = skels[l.id] ?: return null
        if (selBone < 0 || selBone >= sk.bones.size) return null
        val ts = HashSet<Float>()
        for (c in listOf("rx", "ry", "rz", "px", "py", "pz")) for (key in l.track("bn$selBone" + c).keys) ts.add(kotlin.math.round(key.t * 1000f) / 1000f)
        return ts.sorted()
    }

    private fun delKey() {
        val l = layer(selected) ?: return
        host?.pushUndo()
        val t = Editor.time
        val sk = skels[l.id]
        if (poseMode && sk != null && selBone >= 0 && selBone < sk.bones.size) {
            for (c in listOf("rx", "ry", "rz", "px", "py", "pz")) l.track("bn$selBone" + c).keys.removeAll { abs(it.t - t) < 0.03f }
            sk.resetPhysics(); host?.render(); host?.refreshPanel(); return
        }
        for (k in listOf("x", "y", "z", "scale", "rotX", "rotY", "rotZ", "fov")) l.track(k).keys.removeAll { abs(it.t - t) < 0.03f }
        host?.render(); host?.refreshPanel()
    }

    // MARK: fullscreen / panel
    private fun toggleFull() {
        fullscreen = !fullscreen
        header.isHidden = fullscreen; hdrH = if (fullscreen) 0f else 52f
        fsBtn?.highlight(fullscreen, accent)
        layoutAll()
    }

    private fun frameSel() { frame(if (selected >= 0) selected else (nodes.keys.firstOrNull() ?: -1)) }

    private fun tabChanged() {
        val i = tabSeg.selectedSegmentIndex
        val p = i != 0
        tlBox.isHidden = p; propScroll.isHidden = !p; scopeSeg.isHidden = i != 1
        propKey = ""
        layoutAll()
    }

    private fun undoTap() { host?.doUndo() }
    private fun redoTap() { host?.doRedo() }
    private fun deleteTap() {
        val h = host ?: return
        if (selected < 0 || layer(selected) == null) return
        h.selId = selected
        h.deleteLayer()
        select(-1, notifyHost = false); selBone = -1; propKey = ""
    }


    // MARK: - Properties panel (Layer / Global)

    private fun rebuildProps() {
        propStack.clear()
        if (tabSeg.selectedSegmentIndex == 2) { scatterProps(); relayoutProps(); return }
        if (scopeSeg.selectedSegmentIndex == 1) { globalProps(); relayoutProps(); return }
        if (scopeSeg.selectedSegmentIndex == 2) { bonesProps(); relayoutProps(); return }
        val l = layer(selected)
        if (l == null) { add(note("Select a 3D layer (tap it in Move / Scale mode, or in the timeline).")); relayoutProps(); return }
        val t = Editor.time
        val vdb = isVdbLayer(l)
        add(head("${l.name}  ·  ${if (vdb) "VDB volume" else l.type.name.lowercase().replaceFirstChar { it.uppercase() }}"))
        add(sw("Visible", l.visible) { v -> host?.pushUndo(); l.visible = v; host?.render() })
        if (l.type == LayerType.MODEL) {
            add(btnRow("Scatter in air (one tap)") {
                host?.pushUndo(); l.xset("scList", 1f); l.xset("scTarget", -3f); l.xset("scOn", 1f)
                if (l.xf("scCount", 0f) == 0f) l.xset("scCount", 30f)
                host?.render(); propKey = ""; rebuildProps()
            })
            val listed = l.xf("scList", 0f) > 0.5f
            add(btnRow(if (listed) "Remove from scatter list" else "Add to scatter list") {
                host?.pushUndo(); l.xset("scList", if (listed) 0f else 1f)
                if (!listed) scLayer = -1
                propKey = ""; rebuildProps()
            })
        }

        if (l.isLight) lightProps(l)
        if (l.tgraph.isNotEmpty()) {
            val g = TGraph.from(json = l.tgraph)
            if (g != null) {
                add(head("Terrain"))
                add(btnRow("Edit node") {
                    host?.let { TerrainNodeEditor.present(it, this@Scene3DView, g, l, null) }
                })
            }
        }
        add(head("Transform"))
        val ak = { host?.autoKeyOn ?: false }
        fun tr(n: String, k: String, lo: Float, hi: Float) {
            add(sl(n, lo, hi, l.p(k, t)) { l.track(k).set(Editor.time, it, ak()) })
        }
        // signed log slider: Z is effectively unbounded (±100000)
        val z = l.p("z", t)
        val zv = (if (z < 0) -1f else 1f) * log10(1 + abs(z) * 10)
        add(sl("Position Z (unbounded)", -6f, 6f, zv) { l.track("z").set(Editor.time, (if (it < 0) -1f else 1f) * (10f.pow(abs(it)) - 1f) / 10f, ak()) })
        if (l.type != LayerType.CAMERA && !l.isLight) {
            // log slider: 0.01 ... 100000 (the on-screen drag and the main editor are unbounded too)
            fun logRow(n: String, k: String) {
                val cur = max(abs(l.p(k, t)), 0.01f)
                add(sl(n, 0f, 7f, log10(cur / 0.01f), "%.2f") { l.track(k).set(Editor.time, 0.01f * 10f.pow(it), ak()) })
            }
            logRow("Scale (log, 0.01 – 100000)", "scale")
            if (l.type == LayerType.MODEL) logRow("Scale Z / depth (log)", "scaleZ")
        }
        tr("Position X", "x", -4f, 4f); tr("Position Y", "y", -4f, 4f)
        tr("Rotate X", "rotX", -180f, 180f); tr("Rotate Y", "rotY", -180f, 180f); tr("Rotate Z", "rotZ", -180f, 180f)
        if (l.type == LayerType.CAMERA) tr("Field of view", "fov", 10f, 150f)

        add(head("Timing"))
        val dur = max(Editor.scene.duration, 1f)
        add(sl("Start (s)", 0f, dur, l.start) { l.start = min(it, l.end - 0.05f) })
        add(sl("End (s)", 0f, dur, l.end) { l.end = max(it, l.start + 0.05f) })

        if (l.type == LayerType.MODEL && !vdb) {
            add(head("Material & light"))
            add(seg("View", listOf("Final", "Base", "Rough", "Metal", "Occl", "Emis"), l.m3View) { i -> host?.pushUndo(); l.m3View = i; host?.render() })
            add(sw("Environment light", l.m3Env) { v -> host?.pushUndo(); l.m3Env = v; host?.render() })
            add(sw("Metallic reflectivity", l.m3Metal) { v -> host?.pushUndo(); l.m3Metal = v; host?.render() })
            add(sw("Ambient occlusion texture", l.m3Ao) { v -> host?.pushUndo(); l.m3Ao = v; host?.render() })
            add(sw("Occluded by other models", l.occlude) { v -> host?.pushUndo(); l.occlude = v; host?.render() })
            add(sl("Light intensity", 0f, 3f, l.xf("light", 1f)) { l.xset("light", it) })
            add(sl("Environment intensity", 0f, 3f, l.xf("env", 1f)) { l.xset("env", it) })
            add(sl("Exposure", 0.2f, 3f, l.xf("exposure", 1f)) { l.xset("exposure", it) })
        }
        if (vdb) {
            add(head("VDB volume"))
            add(sl("Density", 0f, 5f, l.vdbDens) { l.vdbDens = it })
            add(sl("Brightness", 0f, 5f, l.vdbBright) { l.vdbBright = it })
            add(sl("Opacity", 0f, 1f, l.xf("vdbOpacity", 1f)) { l.xset("vdbOpacity", it) })
            add(sl("Contrast", 0.2f, 3f, l.xf("vdbContrast", 1f)) { l.xset("vdbContrast", it) })
            add(sl("Self-shadow", 0f, 2f, l.xf("vdbShadow", 1f)) { l.xset("vdbShadow", it) })
            add(sl("Quality (ray steps)", 16f, 160f, l.xf("vdbSteps", 56f), "%.0f") { l.xset("vdbSteps", it) })
            add(colorRow("Tint", l.vdbTint) { l.vdbTint = it })
            add(sw("Environment lighting", l.vdbEnv) { v -> host?.pushUndo(); l.vdbEnv = v; host?.render() })
            add(sw("Light from surrounding scene", l.vdbSurround) { v -> host?.pushUndo(); l.vdbSurround = v; host?.render() })
            val p = l.vdbEnvPath
            if (p != null && p.isNotEmpty()) {
                add(btnRow("Remove environment image (${p.substringAfterLast('/')})") { l.vdbEnvPath = null; host?.render(); propKey = "" })
            }
        }
        if ((l.type == LayerType.MODEL || l.type == LayerType.CAMERA || l.is3d) && !l.isLight) {
            add(head("Ray tracing"))
            add(sw("Ray tracing", l.rtOn) { v -> host?.pushUndo(); l.rtOn = v; host?.render(); propKey = "" })
            if (l.rtOn) rtRows(l)
        }
        relayoutProps()
    }

    private fun relayoutProps() {
        var y = 0f
        val w = max(0f, propScroll.rectWidth() - 28f)
        for (c in propStack.arranged) {
            val hh = when (c) {
                is com.saiki.motion.app.EBox -> c.boxH(w)
                is FlatSlider -> 72f
                is FlatSegment -> 32f
                is FlatSwitch -> 32f
                is FlatButton -> 44f
                is BoneRow -> 34f
                else -> if (c.rectHeight() > 0f) c.rectHeight() else 30f
            }
            c.frame = CGRect(0f, y, w, hh)
            y += hh + 10f
        }
        propStack.totalH
        propStack.setNeedsDisplay()
    }

    private fun lightProps(l: Layer) {
        val type = l.xf("lightType", 0f).toInt()
        add(head("Light"))
        add(seg("Type", Lights.types, type) { i ->
            host?.pushUndo(); l.xset("lightType", i.toFloat()); host?.render(); propKey = ""; rebuildProps()
        })
        add(note(when (type) { 1 -> "Sun: parallel light from one direction, position does not matter."; 2 -> "Spot: a cone of light from the ball, aimed with Pitch / Yaw."; else -> "Point: light in every direction from the ball." }))
        add(colorRow("Light color", l.vdbTint) { l.vdbTint = it })
        val ncol = max(1, min(l.xf("lightCols", 1f).toInt(), 3))
        add(seg("Number of colours", listOf("1", "2", "3"), ncol - 1) { i ->
            host?.pushUndo(); l.xset("lightCols", (i + 1).toFloat()); host?.render(); propKey = ""; rebuildProps()
        })
        if (ncol >= 2) {
            add(colorRow("Colour 2", 0xFF000000.toInt() or (l.xf("lightC2", 4033535f).toInt() and 0xFFFFFF)) { l.xset("lightC2", (it and 0xFFFFFF).toFloat()) })
            if (ncol >= 3) add(colorRow("Colour 3", 0xFF000000.toInt() or (l.xf("lightC3", 16731040f).toInt() and 0xFFFFFF)) { l.xset("lightC3", (it and 0xFFFFFF).toFloat()) })
            add(seg("Colours blend by", listOf("Cone / distance", "Around", "Height"), l.xf("lightGradMode", 0f).toInt()) { i ->
                host?.pushUndo(); l.xset("lightGradMode", i.toFloat()); host?.render()
            })
            add(sl("Blend span (distance / height)", 0.2f, 30f, l.xf("lightGradSpan", 4f), "%.1f") { l.xset("lightGradSpan", it) })
        }
        add(sl("Temperature (K): warm to cool", 1500f, 12000f, l.xf("lightTemp", 6500f), "%.0f") { l.xset("lightTemp", it) })
        add(sw("Infinite reach", Lights.infinite(l)) { v -> host?.pushUndo(); l.xset("lightInf", if (v) 1f else 0f); host?.render(); propKey = ""; rebuildProps() })
        add(sl("Intensity (up to 10000)", 0f, 10000f, l.xf("lightInt", 1f), "%.0f") { l.xset("lightInt", it) })
        if (type != 1 && !Lights.infinite(l)) {
            add(sl("Range (0 = unlimited)", 0f, 30f, l.xf("lightRange", 0f), "%.1f") { l.xset("lightRange", it) })
            add(sl("Ball size", 0.05f, 4f, l.xf("lightRad", 0.5f)) { l.xset("lightRad", it) })
        }
        if (type != 0) {
            add(sl("Pitch (down to up)", -90f, 90f, l.xf("lightPitch", -60f), "%.0f") { l.xset("lightPitch", it) })
            add(sl("Yaw (turn)", -180f, 180f, l.xf("lightYaw", 30f), "%.0f") { l.xset("lightYaw", it) })
        }
        if (type == 2) {
            add(sl("Cone angle", 5f, 89f, l.xf("lightCone", 45f), "%.0f") { l.xset("lightCone", it) })
            add(sl("Edge softness", 0f, 1f, l.xf("lightSoft", 0.3f)) { l.xset("lightSoft", it) })
        }
        add(head("Surface response"))
        add(sl("Diffuse strength", 0f, 2f, l.xf("lightDiff", 1f)) { l.xset("lightDiff", it) })
        add(sl("Specular strength (highlights)", 0f, 4f, l.xf("lightSpec", 1f)) { l.xset("lightSpec", it) })
        add(head("Volumes (VDB / clouds)"))
        add(colorRow("Atmosphere color", 0xFF000000.toInt() or (l.xf("atmCol", 0x6688FF.toFloat()).toInt() and 0xFFFFFF)) { l.xset("atmCol", (it and 0xFFFFFF).toFloat()) })
        add(sl("Atmosphere amount", 0f, 2f, l.xf("atmAmt", 0.3f)) { l.xset("atmAmt", it) })
        add(note("Up to 8 lights light models and PBR materials. Volumes use point lights only."))
    }

    private fun rtRows(l: Layer) {
        add(sl("Intensity (master)", 0f, 1f, l.rtInt) { l.rtInt = it })
        add(sl("Shadow strength", 0f, 1f, l.xf("rtShadow", 1f)) { l.xset("rtShadow", it) })
        add(sl("Ambient occlusion strength", 0f, 1f, l.xf("rtAo", 1f)) { l.xset("rtAo", it) })
        add(sl("Occlusion radius", 0.05f, 2f, l.rtRad) { l.rtRad = it })
        add(sl("Sun shadow softness", 0f, 0.3f, l.xf("rtSoft", 0.04f), "%.3f") { l.xset("rtSoft", it) })
        add(sl("Shadow quality (rays per pixel)", 1f, 16f, l.xf("rtSamples", 8f), "%.0f") { l.xset("rtSamples", it) })
        add(sl("Light shadow softness (x ball size)", 0f, 3f, l.xf("lightShadowSoft", 1f)) { l.xset("lightShadowSoft", it) })
        add(note("Ray tracing also casts shadows from every scene light (point, spot, sun). Soft edges come from the sun softness and each light's ball size."))
        rtStatusRow()
    }

    private fun rtStatusRow() {
        val st = MetalModelRenderer.rtStatus
        add(note(if (st.isEmpty()) "Ray tracing ready (traced shadows + ambient occlusion on models, via Metal)." else st, if (st.isEmpty()) 0xFF9E9E9E.toInt() else 0xFFFF3B30.toInt()))
    }

    private fun globalProps() {
        add(head("Viewport"))
        add(sw("Grid", showGrid) { v -> showGrid = v })
        add(sw("Gizmo", showGizmo) { v -> showGizmo = v })
        add(sw("Show 3D scene", syncScene) { v -> syncScene = v })
        add(sl("Viewport field of view", 20f, 90f, R3D.g("vpFov", 50f), "%.0f") { R3D.set("vpFov", it) })
        add(sl("Gizmo size", 0.05f, 0.3f, R3D.g("vpGizmo", 0.14f)) { R3D.set("vpGizmo", it) })
        add(sl("Background", 0f, 0.4f, R3D.g("vpBg", 0f)) { v -> R3D.set("vpBg", v) })
        add(sl("VDB preview density cut", 0.01f, 0.5f, R3D.g("vpThresh", 0.06f)) { R3D.set("vpThresh", it) })
        add(sl("VDB preview point budget", 0.2f, 3f, R3D.g("vpPts", 1f)) { R3D.set("vpPts", it) })

        add(head("Rendering (all layers)"))
        add(sl("Exposure", 0.2f, 3f, R3D.g("exposure", 1f)) { R3D.set("exposure", it) })
        add(sl("Light intensity", 0f, 3f, R3D.g("light", 1f)) { R3D.set("light", it) })
        add(sl("Environment intensity", 0f, 3f, R3D.g("env", 1f)) { R3D.set("env", it) })
        add(sw("Ray trace every model", R3D.g("rtAll", 0f) > 0.5f) { v -> R3D.set("rtAll", if (v) 1f else 0f); host?.render() })
        add(sl("Ray tracing intensity (global)", 0f, 1f, R3D.g("rtMul", 1f)) { R3D.set("rtMul", it) })
        rtStatusRow()

        add(head("VDB (all volumes)"))
        add(sl("Density ×", 0f, 3f, R3D.g("vdbDens", 1f)) { R3D.set("vdbDens", it) })
        add(sl("Brightness ×", 0f, 3f, R3D.g("vdbBright", 1f)) { R3D.set("vdbBright", it) })
        add(sl("Quality ×", 0.4f, 2.5f, R3D.g("vdbQuality", 1f)) { R3D.set("vdbQuality", it) })
        add(btnRow("Reset global settings") {
            for (k in listOf("vpFov", "vpGizmo", "vpBg", "vpThresh", "vpPts", "exposure", "light", "env", "rtAll", "rtMul", "vdbDens", "vdbBright", "vdbQuality")) Prefs.removeObject("r3d." + k)
            propKey = ""; host?.render()
        })
    }

    internal fun isVdbLayer(l: Layer): Boolean = (l.imagePath ?: "").lowercase().endsWith(".vdb")

    // ---- row builders
    private fun add(v: UiView) { propStack.add(v) }

    private fun head(t: String): UiView {
        val l = UILabel(appContext!!)
        l.text = t.uppercase(); l.font = boldFont(12f); l.textColor = argbToUIColor(accent)
        return l
    }
    private fun note(t: String, c: Int = 0xFF9E9E9E.toInt()): UiView {
        val l = com.saiki.motion.app.PLabel()
        l.text = t; l.color = c; l.size = 12f
        return l
    }
    private fun sw(t: String, on: Boolean, f: (Boolean) -> Unit): UiView {
        val box = com.saiki.motion.app.EHStack()
        val l = UILabel(appContext!!)
        l.text = t; l.textColor = argbToUIColor(0xFFFFFFFF.toInt()); l.font = sysFont(15f)
        box.add(com.saiki.motion.app.EBox(l, 0f, 32f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        val s = FlatSwitch(on)
        s.onValueChanged = { f(s.isOn) }
        box.add(com.saiki.motion.app.EBox(s, 46f, 32f, 0f, 0f, 0f, 0f))
        return box
    }
    private fun sl(t: String, lo: Float, hi: Float, v: Float, fmt: String = "%.2f", f: (Float) -> Unit): UiView =
        FlatSlider(t, lo, hi, v, step = (hi - lo) / 100f, fmt = fmt, def = min(max(0f, lo), hi),
            onBegin = { host?.pushUndo() }, onChange = f,
            onEnd = { host?.render(); host?.refreshPanel() })

    private fun seg(t: String, items: List<String>, sel: Int, f: (Int) -> Unit): UiView {
        val box = com.saiki.motion.app.EVStack()
        if (t.isNotEmpty()) {
            val l = UILabel(appContext!!)
            l.text = t; l.textColor = argbToUIColor(0xFFFFFFFF.toInt()); l.font = sysFont(15f)
            box.add(com.saiki.motion.app.EBox(l, 0f, 24f, 0f, 0f, 0f, 0f))
        }
        val s = FlatSegment(items, sel)
        s.onValueChanged = { f(s.selectedSegmentIndex) }
        box.add(com.saiki.motion.app.EBox(s, 0f, 32f, 0f, 0f, 0f, 0f))
        return box
    }
    private fun colorRow(t: String, argb: Int, f: (Int) -> Unit): UiView {
        val box = com.saiki.motion.app.EHStack()
        val l = UILabel(appContext!!)
        l.text = t; l.textColor = argbToUIColor(0xFFFFFFFF.toInt()); l.font = sysFont(15f)
        box.add(com.saiki.motion.app.EBox(l, 0f, 32f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        val w = UiView(appContext!!)
        w.setBackgroundColor(argb)
        w.frame = CGRect(0f, 0f, 44f, 30f)
        box.add(com.saiki.motion.app.EBox(w, 44f, 32f, 0f, 0f, 0f, 0f))
        // tap the swatch: the editor's color picker (UIColorWell twin)
        val tap = object : TapView() { public override fun draw(rect: CGRect) {} }
        tap.frame = CGRect(0f, 0f, 44f, 30f)
        tap.onClick = {
            host?.showColorPicker(argb) { col ->
                w.setBackgroundColor(col)
                host?.pushUndo()
                f(col); host?.render()
            }
        }
        w.addSubview(tap)
        return box
    }
    private fun btnRow(t: String, f: () -> Unit): UiView {
        val b = FlatButton(t); b.onTap = f; return b
    }

    // MARK: - Scatter tab

    private fun scatterProps() {
        val objs = Editor.scene.layers.filter { it.type == LayerType.MODEL && it.xf("scList", 0f) > 0.5f }
        val l = layer(scLayer)
        if (l == null || objs.none { it === l }) {
            scLayer = -1
            add(shead("Scatter list"))
            if (objs.isEmpty()) {
                add(sbtn("Open full-screen Scatter editor") { if (host != null) com.saiki.motion.ui.ScatterEditor.present(host, host.view, select = -1) })
                add(snote("No scatter objects yet. Select a 3D model, open Properties and tap \"Add to scatter list\"."))
            } else {
                add(sbtn("Open full-screen Scatter editor") { if (host != null) com.saiki.motion.ui.ScatterEditor.present(host, host.view, select = -1) })
                add(snote("Tap an object to open its scatter panel."))
                for (o in objs) {
                    add(sbtn(o.name + (if (o.xf("scOn", 0f) > 0.5f) "  ·  on" else "")) { scLayer = o.id; propKey = ""; rebuildProps() })
                }
            }
            return
        }
        add(sbtn("Open full-screen Scatter editor") { if (host != null) com.saiki.motion.ui.ScatterEditor.present(host, host.view, select = -1) })
        add(sbtn("‹ Scatter list") { scLayer = -1; propKey = ""; rebuildProps() })
        add(shead("Scatter · ${l.name}"))
        add(snote("Copies this model over the surface of a target (a model, or a media layer with the 3D cube on). Pick the target, then tune it. It renders in the final video too."))
        add(sbtn("Remove from scatter list") {
            host?.pushUndo(); l.xset("scList", 0f); l.xset("scOn", 0f); host?.render()
            scLayer = -1; propKey = ""; rebuildProps()
        })
        val tgts = Editor.scene.layers.filter { is3dContent(it) && it.id != l.id && !isVdbLayer(it) }
        val tv = l.xf("scTarget", -1f).toInt()
        val cur = layer(tv)
        val curName = when (tv) { -2 -> "Ground plane"; -3 -> "Air (random volume)"; else -> (cur?.name ?: "None") }
        add(picker("Target surface", curName, listOf(Pair("Ground plane", -2), Pair("Air (random volume)", -3)) + tgts.map { Pair(it.name, it.id) }) { id ->
            host?.pushUndo(); l.xset("scTarget", id.toFloat()); l.xset("scOn", 1f); host?.render(); propKey = ""
        })
        val s2 = layer(selected)
        if (s2 != null && s2.id != l.id) {
            add(sbtn("Use selected layer (${s2.name}) as target") {
                host?.pushUndo(); l.xset("scTarget", s2.id.toFloat()); l.xset("scOn", 1f); host?.render(); propKey = ""
            })
        }
        if (tv == -2 || tv == -3) {
            if (tv == -3) add(ssl("Air height", 0.5f, 30f, l.xf("scAirH", 4f), "%.1f") { l.xset("scAirH", it) })
            add(ssl("Ground size", 1f, 60f, l.xf("scGroundSize", 10f), "%.0f") { l.xset("scGroundSize", it) })
            add(ssl(if (tv == -3) "Air centre height" else "Ground height", -5f, 5f, l.xf("scGroundY", 0f), "%.2f") { l.xset("scGroundY", it) })
        }
        add(ssw("Scatter on", l.xf("scOn", 0f) > 0.5f) { v -> host?.pushUndo(); l.xset("scOn", if (v) 1f else 0f); host?.render() })
        add(ssw("Keep the original model too", l.xf("scKeep", 0f) > 0.5f) { v -> l.xset("scKeep", if (v) 1f else 0f); host?.render() })
        fun f(n: String, k: String, lo: Float, hi: Float, d: Float, fmt: String = "%.2f") {
            add(ssl(n, lo, hi, l.xf(k, d), fmt) { l.xset(k, it) })
        }
        add(shead("Amount"))
        f("Count", "scCount", 1f, 1500f, 60f, "%.0f"); f("Seed", "scSeed", 1f, 999f, 1f, "%.0f"); f("Jitter", "scJitter", 0f, 1f, 0f)
        add(sbtn("Re-roll seed") { host?.pushUndo(); l.xset("scSeed", (1..999).random().toFloat()); host?.render(); propKey = "" })
        add(shead("Group"))
        add(sseg(listOf("None", "1", "2", "3", "4"), l.xf("scGroup", 0f).toInt()) { i -> l.xset("scGroup", i.toFloat()); host?.render(); propKey = "" })
        if (l.xf("scGroup", 0f) > 0.5f) {
            f("Share in group", "scWeight", 0f, 5f, 1f)
            add(snote("Models in the same group and target share one set of points (count, seed, slope and filters come from the lowest-id model). Each point goes to one model by its share; scale, rotation and lift stay per model."))
        }
        add(shead("Distribution"))
        add(sseg(listOf("Random", "Even spacing"), l.xf("scMode", 0f).toInt()) { i -> l.xset("scMode", i.toFloat()) })
        f("Minimum distance (even)", "scMinDist", 0.01f, 2f, 0.2f)
        add(shead("Scale"))
        f("Scale", "scScale", 0.05f, 3f, 1f); f("Random scale", "scScaleRnd", 0f, 1f, 0.3f); f("Squash / stretch", "scSquash", 0f, 1f, 0f)
        add(shead("Rotation"))
        add(ssw("Follow smooth ground normals", l.xf("scSmooth", 1f) > 0.5f) { v -> l.xset("scSmooth", if (v) 1f else 0f) })
        f("Align to surface", "scAlign", 0f, 1f, 1f); f("Sit on surface", "scSit", 0f, 1f, 1f); f("Random yaw", "scYaw", 0f, 360f, 360f, "%.0f"); f("Random tilt", "scTilt", 0f, 90f, 0f, "%.0f")
        f("Offset X", "scRotX", -180f, 180f, 0f, "%.0f"); f("Offset Y", "scRotY", -180f, 180f, 0f, "%.0f"); f("Offset Z", "scRotZ", -180f, 180f, 0f, "%.0f")
        add(shead("Placement"))
        f("Lift along normal", "scLift", -1f, 1f, 0f); f("Random lift", "scLiftRnd", 0f, 1f, 0f)
        add(ssw("Flip surface normals", l.xf("scFlip", 0f) > 0.5f) { v -> l.xset("scFlip", if (v) 1f else 0f) })
        add(shead("Filters"))
        f("Min slope (0 = flat up)", "scSlopeMin", 0f, 180f, 0f, "%.0f"); f("Max slope", "scSlopeMax", 0f, 180f, 180f, "%.0f")
        f("Min height", "scHMin", -10f, 10f, -10f); f("Max height", "scHMax", -10f, 10f, 10f)
        add(shead("Noise mask (clumps)"))
        f("Noise scale", "scNoiseScale", 0.2f, 20f, 3f); f("Noise threshold", "scNoiseThr", 0f, 1f, 0f)
        add(shead("Animation"))
        f("Grow-in duration (s)", "scGrow", 0f, 5f, 0f); f("Grow stagger", "scStagger", 0f, 1f, 0.5f)
        f("Sway angle", "scSway", 0f, 30f, 0f, "%.1f"); f("Sway speed", "scSwaySpeed", 0f, 4f, 1f)
        add(sbtn("Reset scatter settings") {
            host?.pushUndo()
            l.x3s = l.x3s.split(";").filter { !it.startsWith("sc") || it.startsWith("scList") }.joinToString(";")
            host?.render(); propKey = ""
        })
    }

    private fun shead(t: String): UiView {
        val l = UILabel(appContext!!)
        l.text = t.uppercase(); l.font = boldFont(12f); l.textColor = argbToUIColor(accent)
        return l
    }
    private fun snote(t: String, c: Int = 0xFF9E9E9E.toInt()): UiView {
        val l = com.saiki.motion.app.PLabel()
        l.text = t; l.color = c; l.size = 12f
        return l
    }
    private fun sbtn(t: String, f: () -> Unit): UiView {
        val b = FlatButton(t); b.onTap = f; return b
    }
    private fun picker(title: String, cur: String, opts: List<Pair<String, Int>>, f: (Int) -> Unit): UiView {
        val b = FlatButton("$title:  $cur  v", fill = (accent and 0x00FFFFFF) or (0x59 shl 24), height = 42f)
        b.setMenu(opts.map { o -> Pair(o.first) { f(o.second) } })
        return b
    }
    private fun ssw(t: String, on: Boolean, f: (Boolean) -> Unit): UiView = sw(t, on, f)
    private fun sseg(items: List<String>, sel: Int, f: (Int) -> Unit): UiView {
        val s = FlatSegment(items, sel)
        s.onValueChanged = { f(s.selectedSegmentIndex) }
        return s
    }
    private fun ssl(t: String, lo: Float, hi: Float, v: Float, fmt: String, f: (Float) -> Unit): UiView =
        FlatSlider(t, lo, hi, v, step = (hi - lo) / 100f, fmt = fmt, def = min(max(0f, lo), hi),
            onBegin = { host?.pushUndo() }, onChange = f, onEnd = { host?.render() })

    // MARK: - Pose mode (bones, skinning, bone drag, Bones tab)

    internal fun markBones() { ovSigReset() }
    private fun ovSigReset() { for (k in skels.keys.toIntArray()) setOv(k, "") }

    /** Reads bone tracks ("bn<i>rx/ry/rz/px/py/pz"), poses the skeleton, runs physics, re-skins the mesh and redraws the bone overlay when anything changed. */
    internal fun updatePose(t: Float) {
        val now = System.nanoTime() / 1e9
        val wall = if (lastPhysWall > 0.0) min(now - lastPhysWall, 0.1).toFloat() else 0f
        lastPhysWall = now
        for ((id, sk) in skels) {
            val l = layer(id) ?: continue
            val holder = holders[id] ?: continue
            sk.physicsOn = (sk.phys?.active ?: false) && l.p("bnphoff", t) < 0.5f
            val changed = sk.loadPose(l, t)
            val ph = sk.phys
            if (ph != null) {
                ph.worldXf = holder.worldMatrix()
                ph.groundY = if (R3D.g("physGround", 1f) > 0.5f) 0f else null
                val st = R3D.g("physWind", 0f) * 3f
                if (st > 0f) {
                    val a = R3D.g("physWindDir", 0f) * Math.PI.toFloat() / 180f
                    val gt = (now % 1000.0).toFloat()
                    val gust = 1f + R3D.g("physGust", 0.3f) * sin(gt * 2.3f) * sin(gt * 0.7f + 1f)
                    ph.windWorld = V3(cos(a), 0f, sin(a)) * (st * gust)
                } else ph.windWorld = V3.ZERO
                if (changed) ph.disturb = true
            }
            val moved = sk.stepPhysics(t, wall)
            val bh = boneHosts[id]
            if (bh != null) { bh.simdTransform = holder.worldMatrix(); bh.isHidden = nodes[id]?.isHidden ?: false }
            if (changed || moved) reskin(id, sk.skinMatrices())
            val vis = showBones || poseMode
            val ov = "${sk.poseSig}|${if (vis) sk.simTick else 0}|$showBones|$poseMode|$selBone"
            if (ov != getOv(id)) { setOv(id, ov); refreshBones(id, sk, holder) }
        }
    }

    private fun getOv(id: Int): String = ovStore[id] ?: ""
    private fun setOv(id: Int, v: String) { ovStore[id] = v }

    internal fun poseChipText(): String {
        val sk = skels[selected] ?: return "Pose  ·  select a model with bones"
        var t = "Pose  ·  " + (if (mode == Mode.rotate) "Rotate bone" else (if (mode == Mode.move) "Move bone" else "pick Move or Rotate"))
        if (selBone >= 0 && selBone < sk.bones.size) t += "  ·  " + sk.bones[selBone].name
        return t
    }

    /** Timeline rows in pose mode: bones that have keys first, then the rest of the hierarchy. */
    internal fun posedFirst(sk: Skeleton3D, l: Layer): List<Int> {
        val keyed = sk.bones.indices.filter { i -> listOf("rx", "ry", "rz", "px", "py", "pz").any { l.track("bn$i" + it).keys.isNotEmpty() } }
        val rest = sk.bones.indices.filter { it !in keyed }
        return keyed + rest
    }

    internal fun selectBone(i: Int) {
        selBone = i; markBones(); propKey = ""
        if (poseMode) chip.text = poseChipText()
    }

    private fun reskin(id: Int, mats: List<M4>) {
        for (sp in skinPrims[id] ?: emptyList()) {
            val old = sp.node.geometry ?: continue
            val v = Skeleton3D.skinVerts(base = sp.base, jnt = sp.jnt, wgt = sp.wgt, mats = mats)
            val g = S3Geom(S3Kind.triangles)
            g.tris = triListFromVerts(v, IntArray(v.size / 12) { it })
            g.img = old.img; g.argb = old.argb; g.emission = old.emission
            sp.node.geometry = g
        }
    }

    private fun boneMat(c: Int): S3Geom {
        val m = S3Geom(S3Kind.sphere)
        m.argb = c
        m.writesDepth = false      // bones are always drawn on top of the mesh
        return m
    }

    private fun linePoints(sk: Skeleton3D, w: List<M4>): S3Geom? {
        val pts = ArrayList<S3V>()
        for ((i, b) in sk.bones.withIndex()) {
            if (b.parent >= 0 && b.parent < w.size && b.parent != i) {
                val p = w[i].col(3); val q = w[b.parent].col(3)
                pts.add(S3V(q.x, q.y, q.z)); pts.add(S3V(p.x, p.y, p.z))
            }
        }
        if (pts.isEmpty()) return null
        val geo = S3Geom(S3Kind.lines)
        geo.verts.addAll(pts)
        geo.argb = 0xBFFFFFFF.toInt()
        geo.writesDepth = false
        return geo
    }

    private fun updateBonePositions(root: S3Node, sk: Skeleton3D, id: Int) {
        val w = sk.world()
        val ns = boneNodes[id] ?: emptyList()
        for (i in 0 until min(ns.size, w.size)) { val p = w[i].col(3); ns[i].position = S3V(p.x, p.y, p.z) }
        val ln = root.childNode("lines")
        if (ln != null) {
            val g = linePoints(sk, w)
            if (g != null) ln.geometry = g
        }
        val lb = root.childNode("lbl")
        if (lb != null && selBone >= 0 && selBone < w.size) {
            val p = w[selBone].col(3); val r = 0.016f / max(modelScale[id] ?: 1f, 1e-4f)
            lb.position = S3V(p.x, p.y + r * 2.6f, p.z)
        }
    }

    private fun refreshBones(id: Int, sk: Skeleton3D, holder: S3Node) {
        val existing = boneHosts[id]
        if (!showBones && !poseMode) { existing?.removeFromParentNode(); boneHosts.remove(id); boneStruct.remove(id); return }
        val key = "$selBone|${sk.bones.size}"
        if (existing != null && boneStruct[id] == key) { updateBonePositions(existing, sk, id); return }
        existing?.removeFromParentNode()
        boneStruct[id] = key
        val root = S3Node(); root.name = "bones"
        val w = sk.world()
        val rr = 0.016f / max(modelScale[id] ?: 1f, 1e-4f)
        fun ball(c: Int, k: Float = 1f): S3Geom {
            val g = S3Geom(S3Kind.sphere); g.sizeA = rr * k
            g.argb = c; g.writesDepth = false
            return g
        }
        val cyan = ball(0xFF33D9FF.toInt())
        val sel = ball(0xFFFF8C14.toInt(), 1.6f)
        val phys = ball(0xFFFF4DE6.toInt())
        val ns = ArrayList<S3Node>()
        for ((i, b) in sk.bones.withIndex()) {
            val p = w[i].col(3)
            val node = S3Node()
            node.geometry = if (i == selBone) sel else (if (b.physics) phys else cyan)
            node.name = "bone$i"; node.position = S3V(p.x, p.y, p.z); node.renderingOrder = 901
            root.addChildNode(node); ns.add(node)
        }
        boneNodes[id] = ns
        val ln = S3Node()
        ln.geometry = linePoints(sk, w) ?: S3Geom(S3Kind.lines).also { it.writesDepth = false }
        ln.name = "lines"; ln.renderingOrder = 900
        root.addChildNode(ln)
        if (selBone >= 0 && selBone < sk.bones.size) {          // name of the selected bone, facing the camera
            val g = S3Geom(S3Kind.text)
            g.label = sk.bones[selBone].name
            g.argb = 0xFFFFE659.toInt(); g.writesDepth = false
            val lb = S3Node(); lb.geometry = g; lb.name = "lbl"
            val sc = 0.06f / max(modelScale[id] ?: 1f, 1e-4f)
            lb.scale = S3V(sc, sc, sc); lb.renderingOrder = 902
            val p = w[selBone].col(3)
            lb.position = S3V(p.x, p.y + rr * 2.6f, p.z)
            root.addChildNode(lb)
        }
        root.simdTransform = holder.worldMatrix()
        scn.addChildNode(root); boneHosts[id] = root
    }

    /// Nearest bone joint to the tap in screen space (within 32 pt); the selected model wins ties.
    internal fun pickBone(p: CGPoint): Pair<Int, Int>? {
        var best: Triple<Int, Int, Float>? = null
        for ((id, sk) in skels) {
            val host3 = boneHosts[id] ?: continue
            if (host3.isHidden) continue
            val w = sk.world()
            for (i in 0 until w.size) {
                val c = w[i].col(3)
                val cw = host3.worldMatrix() * V4(c.x, c.y, c.z, 1f)
                val sp = project(cw) ?: continue
                var d = hypot((sp.x - p.x).toDouble(), (sp.y - p.y).toDouble()).toFloat()
                if (id == selected) d -= 4f
                if (d < 32f && d < (best?.third ?: Float.MAX_VALUE)) best = Triple(id, i, d)
            }
        }
        return best?.let { Pair(it.first, it.second) }
    }

    internal fun applyBoneDrag(d: CGPoint) {
        val l = layer(selected) ?: return
        val sk = skels[selected] ?: return
        if (selBone < 0 || selBone >= sk.bones.size) return
        val holder = holders[selected] ?: return
        val t = Editor.time; val ak = host?.autoKeyOn ?: false; val i = selBone
        fun add(k: String, v: Float) { l.track(k).set(t, l.p(k, t) + v, ak) }
        val w = sk.world()
        val bp = w[i].col(3)
        val hw = holder.worldMatrix()
        val sp4 = hw * V4(bp.x, bp.y, bp.z, 1f)
        val pos = S3V(sp4.x, sp4.y, sp4.z)
        val par = sk.bones[i].parent
        val fr = (if (par >= 0 && par < w.size) w[par] else M4.identity()) * sk.bones[i].restLocal
        /// The bone's own axis k in world space (what the gizmo shows).
        fun axisW(k: Int): S3V? {
            val cc = fr.col(k)
            val v = hw * V4(cc.x, cc.y, cc.z, 0f)
            val l2 = v.x * v.x + v.y * v.y + v.z * v.z
            return if (l2 > 1e-9f) S3V(v.x / sqrt(l2), v.y / sqrt(l2), v.z / sqrt(l2)) else null
        }
        if (mode == Mode.rotate) {
            val keys = listOf("bn${i}rx", "bn${i}ry", "bn${i}rz")
            val ax = if (dragAxis in 0..2) axisW(dragAxis) else null
            if (ax != null) {
                snapped(ringAngle(V3(ax.x, ax.y, ax.z), V3(pos.x, pos.y, pos.z))) { add(keys[dragAxis], it) }
            } else { add("bn${i}ry", d.x * 0.5f); add("bn${i}rx", d.y * 0.5f) }
            return
        }
        if (mode != Mode.move) return
        var dw = S3V(0f, 0f, 0f)
        if (dragAxis in 0..2) {
            val dir = axisW(dragAxis) ?: return
            val a = projectV(pos) ?: return
            val b = projectV(pos + dir) ?: return
            val sx = b.x - a.x; val sy = b.y - a.y
            val den = sx * sx + sy * sy
            if (den <= 1e-4f) return
            dw = dir * ((d.x * sx + d.y * sy) / den)
        } else if (dragAxis in 3..5) {
            val nrm = axisW(dragAxis - 3) ?: return
            dw = planeDelta(pos, nrm) ?: S3V.zero
        } else {
            val nrm = normalizeS3(S3V(camPos.x - pos.x, camPos.y - pos.y, camPos.z - pos.z))
            dw = planeDelta(pos, nrm) ?: S3V.zero
        }
        val mv4 = hw * V4(dw.x, dw.y, dw.z, 0f)
        val inv = fr.inverse()
        val o = inv * V4(mv4.x, mv4.y, mv4.z, 0f)
        add("bn${i}px", o.x); add("bn${i}py", o.y); add("bn${i}pz", o.z)
    }

    /// Bones in hierarchy order with their depth.
    private fun boneTree(sk: Skeleton3D): List<Pair<Int, Int>> {
        val n = sk.bones.size
        val kids = Array(n) { ArrayList<Int>() }; val roots = ArrayList<Int>()
        for ((i, b) in sk.bones.withIndex()) {
            if (b.parent >= 0 && b.parent < n && b.parent != i) kids[b.parent].add(i) else roots.add(i)
        }
        val out = ArrayList<Pair<Int, Int>>(); val seen = HashSet<Int>()
        val stack = ArrayList<Pair<Int, Int>>()
        for (r in roots.reversed()) stack.add(Pair(r, 0))
        while (stack.isNotEmpty()) {
            val (i, d) = stack.removeAt(stack.size - 1)
            if (seen.contains(i)) continue
            seen.add(i); out.add(Pair(i, d))
            for (c in kids[i].reversed()) stack.add(Pair(c, d + 1))
        }
        return out
    }

    /// Name of the opposite-side bone (Left/Right, _L/_R, .L/.R, L_/R_), null when it has none.
    private fun mirrorName(n: String): String? {
        for ((a, b) in listOf("Left" to "Right", "left" to "right", "LEFT" to "RIGHT")) {
            if (n.contains(a)) return n.replace(a, b)
            if (n.contains(b)) return n.replace(b, a)
        }
        for ((a, b) in listOf("_L" to "_R", ".L" to ".R", "_l" to "_r", ".l" to ".r", "Left" to "Right")) {
            if (n.endsWith(a)) return n.dropLast(a.length) + b
            if (n.endsWith(b)) return n.dropLast(b.length) + a
        }
        for ((a, b) in listOf("L_" to "R_", "l_" to "r_")) {
            if (n.startsWith(a)) return b + n.drop(a.length)
            if (n.startsWith(b)) return a + n.drop(b.length)
        }
        if (n.contains("\u5DE6")) return n.replace("\u5DE6", "\u53F3}")
        if (n.contains("\u53F3")) return n.replace("\u53F3", "\u5DE6")
        return null
    }

    internal fun bonesProps() {
        val l = layer(selected)
        if (l == null) { add(note("Select a rigged model first.")); return }
        add(head("Bones  ·  ${l.name}"))
        add(sw("Show bones", showBones) { v -> showBones = v; markBones(); propKey = "" })
        val sk = skels[l.id]
        if (sk == null) { add(note("This model has no bones. Rigged GLB / glTF, VRM, PMX and static FBX models are supported.")); return }
        add(sw("Pose mode", poseMode) { v -> setPose(v) })
        val ph = sk.phys
        if (ph != null && ph.active) {
            val nPhys = sk.bones.count { it.physics }
            add(sw("Physics  ($nPhys bones)", l.p("bnphoff", Editor.time) < 0.5f) { v ->
                host?.pushUndo(); l.track("bnphoff").set(Editor.time, if (v) 0f else 1f, false); sk.resetPhysics(); markBones()
            })
        } else {
            add(note("No spring bones or rigid bodies in this model, so there is no physics."))
        }
        add(head("Physics environment"))
        add(sw("Floor collision", R3D.g("physGround", 1f) > 0.5f) { v -> R3D.set("physGround", if (v) 1f else 0f) })
        add(sl("Wind", 0f, 10f, R3D.g("physWind", 0f)) { v -> R3D.set("physWind", v) })
        add(sl("Wind direction", 0f, 360f, R3D.g("physWindDir", 0f), "%.0f") { v -> R3D.set("physWindDir", v) })
        add(sl("Gust", 0f, 1f, R3D.g("physGust", 0.3f)) { v -> R3D.set("physGust", v) })
        add(note("Moving, rotating or scaling the model, editing a pose, or wind all drive the physics. When nothing moves it stays still."))
        val t = Editor.time
        val chn = listOf("rx", "ry", "rz", "px", "py", "pz")
        fun vals(i: Int): FloatArray = FloatArray(6) { c -> l.p("bn$i" + chn[c], t) }
        fun setVals(i: Int, v: FloatArray, key: Boolean) { for (c in 0 until 6) l.track("bn$i" + chn[c]).set(t, v[c], key) }
        fun changed() { propKey = ""; host?.render() }
        fun mk(title: String, fill: Int = Flat.card, f: () -> Unit): FlatButton {
            val b = FlatButton(title, fill = fill); b.onTap = f; return b
        }
        val posed = l.props.keys.mapNotNull { Skeleton3D.boneKey(it)?.first }.toHashSet()

        val r1 = com.saiki.motion.app.EHStack()
        r1.spacing = 8f
        r1.add(com.saiki.motion.app.EBox(mk("Reset pose", (Flat.danger and 0x00FFFFFF) or (0x8C shl 24)) {
            host?.pushUndo(); sk.clearTracks(l); sk.resetPhysics(); markBones(); propKey = ""; host?.render()
        }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        r1.add(com.saiki.motion.app.EBox(mk("Key pose") {
            host?.pushUndo()
            for (i in posed) if (i < sk.bones.size) setVals(i, vals(i), true)
            changed()
        }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        add(r1)

        if (!poseMode) { add(note("Turn on Pose mode (figure button in the side bar) to pick and move bones.")); return }

        add(seg("", listOf("Rotate", "Move"), if (mode == Mode.move) 1 else 0) { i ->
            mode = if (i == 1) Mode.move else Mode.rotate; updateModeUI(); propKey = ""
        })

        val tree = boneTree(sk)
        if (selBone >= 0 && selBone < sk.bones.size) {
            val i = selBone
            add(head("Bone: ${sk.bones[i].name}"))
            // navigation
            val pos = tree.indexOfFirst { it.first == i }.coerceAtLeast(0)
            fun go(t2: String, target: Int?): UiView {
                val b = FlatButton(t2, height = 34f)
                if (target != null) b.onTap = { selectBone(target) } else b.alpha = 0.35f
                return b
            }
            val par = if (sk.bones[i].parent >= 0 && sk.bones[i].parent < sk.bones.size) sk.bones[i].parent else null
            val child = if (pos + 1 < tree.size && tree[pos + 1].second > tree[pos].second) tree[pos + 1].first else null
            val prev = if (pos > 0) tree[pos - 1].first else null
            val next = if (pos + 1 < tree.size) tree[pos + 1].first else null
            val nav = com.saiki.motion.app.EHStack()
            nav.spacing = 6f
            for ((t2, tg) in listOf("Parent" to par, "Child" to child, "Prev" to prev, "Next" to next)) {
                nav.add(com.saiki.motion.app.EBox(go(t2, tg), 0f, 34f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
            }
            add(nav)

            val rng = 0.5f / max(modelScale[l.id] ?: 1f, 1e-4f)
            fun row(n: String, k: String, lo: Float, hi: Float, step: Float, fmt: String) {
                add(FlatSlider(n, lo, hi, l.p(k, t), step = step, fmt = fmt, def = 0f,
                    onBegin = { host?.pushUndo() },
                    onChange = { v -> l.track(k).set(Editor.time, v, host?.autoKeyOn ?: false) },
                    onEnd = { host?.render() }))
            }
            row("Rotate X", "bn${i}rx", -180f, 180f, 1f, "%.1f"); row("Rotate Y", "bn${i}ry", -180f, 180f, 1f, "%.1f"); row("Rotate Z", "bn${i}rz", -180f, 180f, 1f, "%.1f")
            row("Move X", "bn${i}px", -rng, rng, rng / 100f, "%.3f"); row("Move Y", "bn${i}py", -rng, rng, rng / 100f, "%.3f"); row("Move Z", "bn${i}pz", -rng, rng, rng / 100f, "%.3f")

            val a1 = com.saiki.motion.app.EHStack()
            a1.spacing = 8f
            a1.add(com.saiki.motion.app.EBox(mk("Reset bone") { host?.pushUndo(); setVals(i, FloatArray(6), host?.autoKeyOn ?: false); changed() }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
            a1.add(com.saiki.motion.app.EBox(mk("Key bone", (accent and 0x00FFFFFF) or (0x73 shl 24)) { host?.pushUndo(); setVals(i, vals(i), true); changed() }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
            add(a1)
            val paste = mk("Paste") {
                val c = boneClip ?: return@mk
                host?.pushUndo(); setVals(i, c, host?.autoKeyOn ?: false); changed()
            }
            paste.alpha = if (boneClip == null) 0.35f else 1f
            val a2 = com.saiki.motion.app.EHStack()
            a2.spacing = 8f
            a2.add(com.saiki.motion.app.EBox(mk("Copy") { boneClip = vals(i); propKey = "" }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
            a2.add(com.saiki.motion.app.EBox(paste, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
            add(a2)
            val mn = mirrorName(sk.bones[i].name)
            val mi = if (mn != null) sk.bones.indexOfFirst { it.name == mn } else -1
            if (mn != null && mi >= 0 && mi != i) {
                add(btnRow("Mirror to  $mn") {
                    val v = vals(i)
                    host?.pushUndo(); setVals(mi, floatArrayOf(v[0], -v[1], -v[2], -v[3], v[4], v[5]), host?.autoKeyOn ?: false); changed()
                })
            }
        } else {
            add(note("Tap a bone in the 3D view or in the list to select it."))
        }

        // searchable bone tree
        add(head("All bones (${sk.bones.size})"))
        val field = FlatField()
        field.text = boneFilter
        add(field)
        add(seg("", listOf("All", "Posed", "Physics"), boneFilterMode) { i -> boneFilterMode = i; propKey = "" })
        val box = com.saiki.motion.app.EVStack()
        add(box)
        fun fill() {
            box.clear()
            val q = boneFilter.lowercase()
            var shown = 0; var total = 0
            for ((i, d) in tree) {
                val b = sk.bones[i]
                if (q.isNotEmpty() && !b.name.lowercase().contains(q)) continue
                if (boneFilterMode == 1 && !posed.contains(i)) continue
                if (boneFilterMode == 2 && !b.physics) continue
                total += 1
                if (shown >= 300) continue
                shown += 1
                val r = BoneRow(b.name, depth = (if (q.isEmpty() && boneFilterMode == 0) d else 0), selected = i == selBone, physics = b.physics, posed = posed.contains(i))
                r.onTap = { selectBone(i) }
                box.add(r)
            }
            if (total > shown) box.add(note("${total - shown} more. Use the search to narrow the list."))
            if (total == 0) box.add(note("No bones match."))
            relayoutProps()
        }
        fill()
        field.onTextChanged = { boneFilter = it; fill() }
        field.onReturn = { field.backing.clearFocus() }
    }
}

// MARK: - Timeline canvas (ruler, one row per 3D layer, keyframe diamonds, playhead)

class TLCanvas : UiView(appContext!!) {
    var rows: List<Layer> = emptyList()
    var selected = -1
    var time: Float = 0f
    var dur: Float = 5f
    var onSeek: ((Float) -> Unit)? = null
    var onSelect: ((Int) -> Unit)? = null
    var poseRows: List<Triple<Int, String, List<Float>>>? = null      // pose mode: one row per bone (index, name, key times)
    var selBone = -1
    var onSelectBone: ((Int) -> Unit)? = null
    private val rowCount: Int get() = poseRows?.count() ?: rows.size
    private var pps: CGFloat = 70f           // pixels per second
    private var offX: CGFloat = 0f; private var offY: CGFloat = 0f
    private var scrub = false
    private val rowH: CGFloat = 32f; private val top: CGFloat = 26f
    private val orange = 0xFFFF8C14.toInt()

    fun layoutIfNeeded2() { setNeedsDisplay() }

    private fun tx(t: Float): CGFloat = t * pps - offX + 8f
    private fun tt(x: CGFloat): Float = max(0f, min(dur, (x + offX - 8f) / pps))

    public override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { scrub = e.y < top; lastY = e.y; downPt = Pair(e.x, e.y); if (scrub) onSeek?.invoke(tt(e.x)) }
            android.view.MotionEvent.ACTION_MOVE -> {
                if (scrub) onSeek?.invoke(tt(e.x))
                else {
                    val dx = e.x - downPt.first; val dy = e.y - downPt.second
                    downPt = Pair(e.x, e.y)
                    offX = max(0f, min(offX - dx, max(0f, dur * pps - rectWidth() + 40f)))
                    offY = max(0f, min(offY - dy, max(0f, rowCount * rowH - (rectHeight() - top))))
                    setNeedsDisplay()
                }
            }
            android.view.MotionEvent.ACTION_UP -> {
                if (!scrub && hypot((e.x - downPt.first).toDouble(), (e.y - downPt.second).toDouble()) < 6f) {
                    // tap: seek on the ruler, select on a row
                    if (e.y < top) { onSeek?.invoke(tt(e.x)); return true }
                    val i = ((e.y - top + offY) / rowH).toInt()
                    val pr = poseRows
                    if (pr != null) { if (i >= 0 && i < pr.size) onSelectBone?.invoke(pr[i].first); return true }
                    if (i >= 0 && i < rows.size) onSelect?.invoke(rows[i].id) else onSelect?.invoke(-1)
                }
                scrub = false
            }
        }
        return true
    }

    private var downPt = Pair(0f, 0f)
    private var lastY = 0f

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        // rows
        c.saveGState(); c.clip(to = CGRect(0f, top, rect.width, max(0f, rect.height - top)))
        if (rows.isEmpty() && poseRows == null) drawText("No 3D layers yet. Use + > Import Model", 12f, top + 12f, color = 0xFF9E9E9E.toInt(), size = 10f, align = NSTextAlignment.left)
        val pr = poseRows
        if (pr != null) {
            for ((n, r) in pr.withIndex()) {
                val y = top + n * rowH - offY
                if (y + rowH < top || y > rect.height) continue
                val sel = r.first == selBone
                if (sel) { c.setFillColor((orange and 0x00FFFFFF) or (0x2E shl 24)); c.fill(CGRect(0f, y, rect.width, rowH)) }
                else if (n % 2 == 0) { c.setFillColor(0x08FFFFFF); c.fill(CGRect(0f, y, rect.width, rowH)) }
                drawText(r.second, 8f, y + 9f, color = if (sel) 0xFFFFFFFF.toInt() else 0xFF9E9E9E.toInt(), size = if (sel) 11f else 10f, align = NSTextAlignment.left)
                c.setFillColor(if (sel) orange else 0xFFFFFFFF.toInt())
                for (t in r.third) {
                    val x = tx(t); val my = y + rowH / 2f
                    diamond(c, x, my)
                }
            }
        }
        if (pr == null) {
            for ((i, l) in rows.withIndex()) {
                val y = top + i * rowH - offY
                if (y + rowH < top || y > rect.height) continue
                if (i % 2 == 0) { c.setFillColor(0x08FFFFFF); c.fill(CGRect(0f, y, rect.width, rowH)) }
                val x0 = tx(l.start); val x1 = tx(l.end)
                val bar = CGRect(x0, y + 4f, max(6f, x1 - x0), rowH - 8f)
                c.setFillColor(if (l.id == selected) orange else (orange and 0x00FFFFFF) or (0x59 shl 24))
                fillRoundRect(c, bar, 6f, if (l.id == selected) orange else (orange and 0x00FFFFFF) or (0x59 shl 24))
                drawText(l.name, max(bar.minX, 0f) + 6f, y + 9f, color = 0xFFFFFFFF.toInt(), size = 11f, align = NSTextAlignment.left)
                val ts = HashSet<Float>()
                for (k in listOf("x", "y", "z", "scale", "rotX", "rotY", "rotZ", "fov")) for (key in l.track(k).keys) ts.add(kotlin.math.round(key.t * 1000f) / 1000f)
                c.setFillColor(0xFFFFFFFF.toInt())
                for (t in ts) diamond(c, tx(t), y + rowH / 2f)
            }
        }
        c.restoreGState()
        // ruler
        c.setFillColor(0xFF1C1C1C.toInt()); c.fill(CGRect(0f, 0f, rect.width, top))
        val stepT: Float = if (pps > 140f) 0.5f else (if (pps > 40f) 1f else 5f)
        var t = 0f
        while (t <= dur + 0.001f) {
            val x = tx(t)
            if (x > -30f && x < rect.width + 30f) {
                c.setFillColor(0xFF808080.toInt()); c.fill(CGRect(x, top - 8f, 1f, 8f))
                drawText(String.format(Locale.US, if (stepT < 1f) "%.1f" else "%.0f", t), x + 3f, 14f, color = 0xFF9E9E9E.toInt(), size = 10f, align = NSTextAlignment.left)
            }
            t += stepT
        }
        // end-of-timeline marker
        c.setFillColor(0x80000000.toInt()); c.fill(CGRect(tx(dur), top, max(0f, rect.width - tx(dur)), rect.height))
        // playhead
        val px = tx(time)
        c.setFillColor(orange); c.fill(CGRect(px - 1f, 0f, 2f, rect.height))
        fillRoundRect(c, CGRect(px - 9f, 2f, 18f, 16f), 5f, orange)
    }

    private fun diamond(c: com.saiki.motion.uikit.CGContext, x: CGFloat, my: CGFloat) {
        val p = android.graphics.Path()
        p.moveTo(x, my - 6f); p.lineTo(x + 5f, my); p.lineTo(x, my + 6f); p.lineTo(x - 5f, my); p.close()
        c.canvas.drawPath(p, c.paint)
    }
}

