@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName", "NAME_SHADOWING")

package com.saiki.motion.uikit

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.max

// ============================================================
// UIKit shim part 2: controls, stack/scroll containers,
// view controllers, navigation, alerts, tables/collections.
// ============================================================

// MARK: - UIControl / events

open class UIControl(context: Context) : UiView(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))

    var onBegin: (() -> Unit)? = null
    open fun sendEvent(name: String) {}
}

// MARK: - UILabel

open class UILabel(context: Context) : UiView(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))

    var text: String? = null
        set(v) { field = v; setNeedsDisplay() }
    var font: UIFont = UIFont.systemFont(17f)
        set(v) { field = v; setNeedsDisplay() }
    var textColor: UIColor = UIColor.black
    var textAlignment: NSTextAlignment = NSTextAlignment.left
    var numberOfLines: Int = 1
    var lineBreakMode: NSLineBreakMode = NSLineBreakMode.byTruncatingTail
    var adjustsFontSizeToFitWidth = false
    var minimumScaleFactor: CGFloat = 0f
    var attributedText: NSAttributedString? = null
    /** Letter spacing in points (NSAttributedString .kern twin — the kerned() wordmarks). */
    var kern: CGFloat = 0f
    // UIKit: UILabel.isUserInteractionEnabled defaults to false, so taps fall through to the button behind it
    // (UiView.onTouchEvent returns true, which made labels swallow every tap on buttons).
    override fun onTouchEvent(e: android.view.MotionEvent): Boolean = false

    override fun draw(rect: CGRect) {
        val t = attributedText?.string() ?: text ?: return
        val c = UIGraphics.getCurrentContext() ?: return
        val f = (attributedText?.attrs?.get("font") as? UIFont) ?: font
        val col = (attributedText?.attrs?.get("color") as? UIColor) ?: textColor
        val k = (attributedText?.attrs?.get("kern") as? CGFloat) ?: kern
        if (k == 0f) {
            drawText(t, frame.width / 2, frame.height / 2 + f.size * 0.35f, color = col.toInt(), size = f.size, bold = f.bold, align = textAlignment)
            return
        }
        val p = f.toPaint(); p.color = col.toInt()
        if (f.size > 0f) p.letterSpacing = k / f.size
        val w = p.measureText(t)
        var px = frame.width / 2
        if (textAlignment == NSTextAlignment.left || textAlignment == NSTextAlignment.natural) px = 0f
        else if (textAlignment == NSTextAlignment.right) px = frame.width - w
        c.canvas.drawText(t, px, frame.height / 2 + f.size * 0.35f, p)
    }
}

enum class NSTextAlignment { left, center, right, natural, justified }
enum class NSLineBreakMode { byWordWrapping, byCharWrapping, byClipping, byTruncatingHead, byTruncatingMiddle, byTruncatingTail }

// MARK: - text drawing (Theme.swift drawText port target)

private val textPaintCache = HashMap<Pair<CGFloat, Boolean>, Paint>()

fun measureText(s: String, size: CGFloat, bold: Boolean = false): CGFloat {
    if (s.isEmpty()) return 0f
    val p = textPaintCache.getOrPut(Pair(size, bold)) {
        Paint(Paint.ANTI_ALIAS_FLAG).apply { this.textSize = size; typeface = if (bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT }
    }
    return p.measureText(s)
}

/** Theme.swift drawText: (x, y) = baseline, returns width. align mirrors Paint.Align. */
fun drawText(s: String, x: CGFloat, y: CGFloat, color: Int, size: CGFloat, bold: Boolean = false, align: NSTextAlignment = NSTextAlignment.left): CGFloat {
    if (s.isEmpty()) return 0f
    val c = UIGraphics.getCurrentContext() ?: return 0f
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; this.color = color; typeface = if (bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT }
    val w = paint.measureText(s)
    var px = x
    if (align == NSTextAlignment.center) px -= w / 2 else if (align == NSTextAlignment.right) px -= w
    val fm = paint.fontMetrics
    c.canvas.drawText(s, px, y, paint)
    return w
}

// MARK: - UIButton

open class UIButton(context: Context) : UIControl(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))

    var title: String? = null
    var titleColor: UIColor = UIColor.black
    var font: UIFont = UIFont.systemFont(15f)
    var image: UIImage? = null
    var tintColor: UIColor = UIColor(0xFF007AFF.toInt())
    var onTouchUpInside: (() -> Unit)? = null

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        super.touchesEnded(touches, event)
        if (touches.first()?.location(this)?.let { boundsRect.contains(it) } == true) onTouchUpInside?.invoke()
    }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = frame.width; val h = frame.height
        if (image != null) {
            image?.let { img -> c.canvas.drawBitmap(img.bitmap, null, android.graphics.RectF(0f, 0f, w, h), Paint(Paint.FILTER_BITMAP_FLAG)) }
        } else {
            title?.let {
                drawText(it, w / 2, h / 2 + font.size / 3, color = titleColor.toInt(), size = font.size, bold = false, align = NSTextAlignment.center)
            }
        }
    }
}

class UIBarButtonItem(val title: String?, style: Int = 0, action: (() -> Unit)? = null) {
    var tintColor: UIColor? = null
    var image: UIImage? = null
    var target: Any? = null
    var actionSelector: String? = null
    var isEnabled = true
    companion object {
        fun initWithTitle(t: String?, style: Int, target: Any?, action: String?): UIBarButtonItem {
            val b = UIBarButtonItem(t, style, null)
            b.target = target; b.actionSelector = action
            return b
        }
    }
}

// MARK: - UITextField

open class UITextField(context: Context) : UiView(context), TextWatcher {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))

    private val editText: EditText = EditText(context).apply {
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        setPadding(0, 0, 0, 0)
        addTextChangedListener(this@UITextField)
    }
    var placeholder: String?
        get() = editText.hint?.toString()
        set(v) { editText.hint = v }
    var text: String
        get() = editText.text?.toString() ?: ""
        set(v) { editText.setText(v) }
    var font: UIFont = UIFont.systemFont(15f)
    var textColor: UIColor = UIColor.black
    var keyboardType: UIKeyboardType = UIKeyboardType.default
    var returnKeyType: UIReturnKeyType = UIReturnKeyType.default
    var isSecureTextEntry = false
    var autocorrectionType: Int = 1
    var delegate: Any? = null
    var onTextChanged: ((String) -> Unit)? = null
    var onReturn: (() -> Unit)? = null

    val backing: EditText get() = editText

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = MeasureSpec.getSize(heightSpec)
        backing.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(if (h > 0) h else ViewGroup.LayoutParams.WRAP_CONTENT, MeasureSpec.EXACTLY))
        setMeasuredDimension(w, if (h > 0) h else backing.measuredHeight)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        backing.layout(0, 0, r - l, b - t)
    }

    init {
        editText.imeOptions = EditorInfo.IME_ACTION_DONE
        editText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_NEXT || actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEARCH) { onReturn?.invoke(); true } else false
        }
    }

    override fun afterTextChanged(s: Editable?) { onTextChanged?.invoke(s?.toString() ?: ""); onEdit?.invoke() }
    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

    /** RulerSlider-style helpers (UIKit bridge contract). */
    var numeric: Boolean
        get() = false
        set(v) { editText.inputType = if (v) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL else InputType.TYPE_CLASS_TEXT }
    var onEdit: (() -> Unit)? = null
}

enum class UIKeyboardType { default, asciiCapable, numbersAndPunctuation, URL, numberPad, phonePad, namePhonePad, emailAddress, decimalPad, twitter, webSearch, asciiCapableNumberPad }
enum class UIReturnKeyType { default, go, google, join, next, route, search, send, yahoo, done, emergencyCall }

// MARK: - UISlider / UISwitch

open class UISlider(context: Context) : UIControl(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))
    var minValue: CGFloat = 0f
    var maxValue: CGFloat = 1f
    var value: CGFloat = 0f
    var onValueChanged: ((CGFloat) -> Unit)? = null
    var isContinuous = true
    private var dragging = false

    override fun touchesBegan(touches: Set<UITouch>, event: UIEvent?) {
        super.touchesBegan(touches, event)
        dragging = true
        touches.first()?.let { setv(it.location(this).x) }
    }
    override fun touchesMoved(touches: Set<UITouch>, event: UIEvent?) {
        touches.first()?.let { setv(it.location(this).x) }
    }
    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        super.touchesEnded(touches, event)
        dragging = false
    }
    private fun setv(x: CGFloat) {
        val v = minValue + (x / frame.width).coerceIn(0f, 1f) * (maxValue - minValue)
        if (v != value) { value = v; onValueChanged?.invoke(v); setNeedsDisplay() }
    }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val h = frame.height
        fillRoundRect(c, CGRect(0f, h / 2 - 2, frame.width, 4f), 2f, 0xFF3A3A44.toInt())
        val f = ((value - minValue) / (maxValue - minValue)).coerceIn(0f, 1f)
        fillCircle(c, f * frame.width, h / 2, 10f, 0xFFFFFFFF.toInt())
    }
}

open class UISwitch(context: Context) : UIControl(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))
    var isOn = false
    var onValueChanged: ((Boolean) -> Unit)? = null

    init { onClick = { isOn = !isOn; onValueChanged?.invoke(isOn); setNeedsDisplay() } }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val h = frame.height
        fillRoundRect(c, CGRect(0f, 0f, frame.width, h), h / 2, if (isOn) 0xFFFF8A1F.toInt() else 0xFF3A3A44.toInt())
        fillCircle(c, if (isOn) frame.width - h / 2 else h / 2, h / 2, h / 2 - 3f, 0xFFFFFFFF.toInt())
    }
}

// MARK: - UIStackView

open class UIStackView(context: Context) : UiView(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))
    constructor(arrangedSubviews: List<UiView>) : this() { arrangedSubviews.forEach { addArrangedSubview(it) } }

    var axis: NSLayoutConstraintConstraintAxis = NSLayoutConstraintConstraintAxis.horizontal
    var spacing: CGFloat = 0f
    var alignment: UIStackViewAlignment = UIStackViewAlignment.fill
    var distribution: UIStackViewDistribution = UIStackViewDistribution.fill

    fun addArrangedSubview(v: UiView) {
        if (parent == null) attachToHost()
        hostLayout?.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        arranged.add(v)
        layoutStack()
    }
    fun removeArrangedSubview(v: UiView) { arranged.remove(v); (v.parent as? ViewGroup)?.removeView(v); layoutStack() }

    val arrangedSubviews: List<UiView> get() = arranged
    private val arranged = ArrayList<UiView>()

    val backing: LinearLayout? get() = hostLayout

    private fun attachToHost() {
        // A UIStackView without a parent yet: layout happens on attach.
    }
    private var hostLayout: LinearLayout? = null

    fun setCustomSpacing(s: CGFloat, v: UiView) { customSpacings[v] = s; layoutStack() }
    private val customSpacings = HashMap<UiView, CGFloat>()

    fun layoutStack() {
        // Real LinearLayout-style pass over arranged subviews.
        var x = 0; var y = 0
        for (c in arranged) {
            val w = c.measuredWidth; val h = c.measuredHeight
            if (axis == NSLayoutConstraintConstraintAxis.horizontal) { c.layout(x, 0, x + w, h); x += w + spacing.toInt() }
            else { c.layout(0, y, w, y + h); y += h + spacing.toInt() }
        }
    }
    fun measureStack(widthSpec: Int, heightSpec: Int) {
        var mw = 0; var mh = 0
        for (c in arranged) {
            c.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
            if (axis == NSLayoutConstraintConstraintAxis.horizontal) { mw += c.measuredWidth + spacing.toInt().toInt(); mh = maxOf(mh, c.measuredHeight) }
            else { mw = maxOf(mw, c.measuredWidth); mh += c.measuredHeight + spacing.toInt().toInt() }
        }
        setMeasuredDimension(resolveSize(mw, widthSpec), resolveSize(mh, heightSpec))
    }
}

enum class NSLayoutConstraintConstraintAxis { horizontal, vertical }
enum class UIStackViewAlignment { fill, leading, top, firstBaseline, center, trailing, bottom, lastBaseline }
enum class UIStackViewDistribution { fill, fillEqually, fillProportionally, equalSpacing, equalCentering }

// MARK: - UIScrollView

open class UIScrollView(context: Context) : UiView(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))

    var contentSize: CGSize = CGSize(0f, 0f)
    var contentOffset: CGPoint
        get() = CGPoint(scrollX.toFloat(), scrollY.toFloat())
        set(v) { scrollTo(v.x.toInt(), v.y.toInt()) }
    var showsVerticalScrollIndicator = true
    var showsHorizontalScrollIndicator = true
    var contentInset: UIEdgeInsets = UIEdgeInsets.zero
    var isScrollEnabled = true
    var alwaysBounceVertical = false
    open var delegate: Any? = null
    var minimumZoomScale: CGFloat = 1f
    var maximumZoomScale: CGFloat = 1f
    var zoomScale: CGFloat = 1f

    val contentLayoutGuide: UILayoutGuide get() = UILayoutGuide()
    val frameLayoutGuide: UILayoutGuide get() = UILayoutGuide()

    fun setContentOffset(o: CGPoint, animated: Boolean) { scrollTo(o.x.toInt(), o.y.toInt()) }
    // --- touch scrolling (UIScrollView pan + deceleration) ---
    private val slop = android.view.ViewConfiguration.get(context).scaledTouchSlop
    private val flinger = android.widget.OverScroller(context)
    private var vt: android.view.VelocityTracker? = null
    private var dragging = false
    private var sx0 = 0f; private var sy0 = 0f; private var lx = 0f; private var ly = 0f
    private fun maxScrollX(): Int = max(0, kotlin.math.ceil(contentSize.width + contentInset.left + contentInset.right).toInt() - width)
    private fun maxScrollY(): Int = max(0, kotlin.math.ceil(contentSize.height + contentInset.top + contentInset.bottom).toInt() - height)
    private fun beginDragIfNeeded(e: MotionEvent): Boolean {
        val ddx = e.x - sx0; val ddy = e.y - sy0
        val v = kotlin.math.abs(ddy) > slop && maxScrollY() > 0 && kotlin.math.abs(ddy) >= kotlin.math.abs(ddx)
        val h = kotlin.math.abs(ddx) > slop && maxScrollX() > 0 && kotlin.math.abs(ddx) > kotlin.math.abs(ddy)
        if (v || h) { dragging = true; lx = e.x; ly = e.y; parent?.requestDisallowInterceptTouchEvent(true); return true }
        return false
    }
    private fun track(e: MotionEvent) { if (vt == null) vt = android.view.VelocityTracker.obtain(); vt!!.addMovement(e) }
    private fun endTrack(fling: Boolean) {
        val t = vt
        if (t != null) {
            if (fling && dragging) {
                t.computeCurrentVelocity(1000)
                flinger.fling(scrollX, scrollY, (-t.xVelocity).toInt(), (-t.yVelocity).toInt(), 0, maxScrollX(), 0, maxScrollY())
                postInvalidateOnAnimation()
            }
            t.recycle(); vt = null
        }
        dragging = false
    }
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (!isScrollEnabled) return false
        track(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx0 = e.x; sy0 = e.y; lx = e.x; ly = e.y; dragging = false; flinger.forceFinished(true) }
            MotionEvent.ACTION_MOVE -> if (!dragging) beginDragIfNeeded(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endTrack(false)
        }
        return dragging
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!isScrollEnabled || (maxScrollX() == 0 && maxScrollY() == 0)) return super.onTouchEvent(e)
        track(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx0 = e.x; sy0 = e.y; lx = e.x; ly = e.y; dragging = false; flinger.forceFinished(true) }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) beginDragIfNeeded(e)
                if (dragging) {
                    val nx = (scrollX + (lx - e.x).toInt()).coerceIn(0, maxScrollX())
                    val ny = (scrollY + (ly - e.y).toInt()).coerceIn(0, maxScrollY())
                    lx = e.x; ly = e.y
                    scrollTo(nx, ny)
                }
            }
            MotionEvent.ACTION_UP -> { val was = dragging; endTrack(true); if (was) return true }
            MotionEvent.ACTION_CANCEL -> { endTrack(false); return true }
        }
        return if (dragging) true else super.onTouchEvent(e)
    }
    override fun computeScroll() {
        if (flinger.computeScrollOffset()) { scrollTo(flinger.currX, flinger.currY); postInvalidateOnAnimation() }
    }
    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScroll(l, t, oldl, oldt)
    }

    fun measureScroll(widthSpec: Int, heightSpec: Int) {
        var mw = 0; var mh = 0
        for (c in subviews) {
            c.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
            mw = maxOf(mw, c.measuredWidth); mh = maxOf(mh, c.measuredHeight)
        }
        setMeasuredDimension(resolveSize(maxOf(mw, contentSize.width.toInt()), widthSpec), resolveSize(maxOf(mh, contentSize.height.toInt()), heightSpec))
    }
    fun layoutScroll() {
        var x = 0; var y = 0
        for (c in subviews) { c.layout(x, y, x + c.measuredWidth, y + c.measuredHeight); if (c.frame.maxX > x) x = 0; y = 0 }
    }
}

// MARK: - fill/stroke helpers (Theme.swift CGContext globals)

fun fillRoundRect(c: CGContext, r: CGRect, radius: CGFloat, color: Int) {
    c.setFillColor(color)
    val p = CGPath.roundedRect(r, radius, radius)
    c.addPath(p); c.fillPath()
}

fun strokeRoundRect(c: CGContext, r: CGRect, radius: CGFloat, width: CGFloat, color: Int) {
    c.setStrokeColor(color); c.setLineWidth(width)
    val p = CGPath.roundedRect(r, radius, radius)
    c.addPath(p); c.strokePath()
}

fun strokeLine(c: CGContext, x0: CGFloat, y0: CGFloat, x1: CGFloat, y1: CGFloat, width: CGFloat, color: Int) {
    c.setStrokeColor(color); c.setLineWidth(width)
    val p = CGPath(); p.move(CGPoint(x0, y0)); p.addLine(CGPoint(x1, y1))
    c.addPath(p.path); c.strokePath()
}

fun fillCircle(c: CGContext, x: CGFloat, y: CGFloat, r: CGFloat, color: Int) {
    c.setFillColor(color)
    c.fillEllipse(CGRect(x - r, y - r, 2 * r, 2 * r))
}

fun strokeCircle(c: CGContext, x: CGFloat, y: CGFloat, r: CGFloat, width: CGFloat, color: Int) {
    c.setStrokeColor(color); c.setLineWidth(width)
    c.strokeEllipse(CGRect(x - r, y - r, 2 * r, 2 * r))
}

fun fillRect(c: CGContext, r: CGRect, color: Int) { c.setFillColor(color); c.fill(r) }

// MARK: - NSAttributedString

class NSAttributedString(val str: String, val attrs: Map<String, Any>? = null) {
    fun string(): String = str
    fun enumerate(f: (String, NSRange, Any?, Any?) -> Unit) { f(str, NSRange(0, str.length), attrs, null) }
    val length: Int get() = str.length
    fun size(): CGSize { val f = attrs?.get("font") as? UIFont ?: UIFont.systemFont(17f); val p = f.toPaint(); return CGSize(p.measureText(str), f.size) }
    fun draw(at: CGPoint) {
        val c = UIGraphics.getCurrentContext() ?: return
        val f = attrs?.get("font") as? UIFont ?: UIFont.systemFont(17f)
        val p = f.toPaint(); p.color = (attrs?.get("color") as? UIColor)?.toInt() ?: 0xFF000000.toInt()
        c.canvas.drawText(str, at.x, at.y + f.size, p)
    }
}

class NSRange(val loc: Int, val len: Int)

// MARK: - UIViewController + navigation

/** Default VC root view: forwards its layout passes to the controller (UIKit's viewWillLayoutSubviews/viewDidLayoutSubviews). */
class VcView(ctx: Context, private val vc: UIViewController) : UiView(ctx) {
    private var lw = -1
    private var lh = -1
    // Android-only: iOS lays out in points. Root VC views are measured in points (px / density) and scaled up by density,
    // so every screen fills the device and touches map back through the view transform.
    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val pw = MeasureSpec.getSize(widthSpec); val ph = MeasureSpec.getSize(heightSpec)
        val d = resources.displayMetrics.density
        if (parent is UiView || pw <= 0 || ph <= 0 || d <= 0f) { super.onMeasure(widthSpec, heightSpec); return }
        pivotX = 0f; pivotY = 0f; scaleX = d; scaleY = d
        setMeasuredDimension((pw / d).toInt(), (ph / d).toInt())
    }
    override fun layoutSubviews() {
        super.layoutSubviews()
        val w = width; val h = height
        if (w <= 0 || h <= 0 || (w == lw && h == lh)) return
        lw = w; lh = h
        vc.viewWillLayoutSubviews(); vc.viewDidLayoutSubviews()
    }
}

open class UIViewController {
    open val view: UiView = VcView(appContext ?: throw IllegalStateException("appContext not set"), this)
    private var loadedOnce = false
    fun loadViewIfNeeded() { if (!loadedOnce) { loadedOnce = true; viewDidLoad() } }
    var title: String? = null
    var navigationItem: UINavigationItem? = null
    var navigationController: UINavigationController? = null
    var presentingViewController: UIViewController? = null
    var presentedViewController: UIViewController? = null
    val isViewLoaded: Boolean get() = view.isAttachedToWindow
    open fun viewDidLoad() {}
    open fun viewWillAppear(animated: Boolean) {}
    open fun viewDidAppear(animated: Boolean) {}
    open fun viewWillDisappear(animated: Boolean) {}
    open fun viewDidDisappear(animated: Boolean) {}
    open fun viewWillLayoutSubviews() {}
    open fun viewDidLayoutSubviews() {}
    open fun loadView() {}
    fun present(vc: UIViewController, animated: Boolean = true, completion: (() -> Unit)? = null) {
        Navigator.present(this, vc, animated, completion)
    }
    fun dismiss(animated: Boolean = true, completion: (() -> Unit)? = null) {
        Navigator.dismiss(this, animated, completion)
    }
}

/** UIKit navigation item: bar button holders (UIKit2 carries no bar; presenters read these). */
class UINavigationItem {
    var leftBarButtonItem: UIBarButtonItem? = null
    var rightBarButtonItem: UIBarButtonItem? = null
    var title: String? = null
}

class UINavigationController(root: UIViewController? = null) : UIViewController() {
    val viewControllers = ArrayList<UIViewController>()
    var delegate: Any? = null
    val navigationBarHidden = false
    init { root?.let { viewControllers.add(it); it.navigationController = this } }
    fun pushViewController(vc: UIViewController, animated: Boolean) { viewControllers.add(vc); vc.navigationController = this; Navigator.push(this, vc, animated) }
    fun popViewController(animated: Boolean): UIViewController? {
        if (viewControllers.size <= 1) return null
        val top = viewControllers.removeAt(viewControllers.size - 1)
        Navigator.pop(this, animated)
        return top
    }
    val topViewController: UIViewController? get() = viewControllers.lastOrNull()
}

/** Presents/pushes onto the current Android activity's root container. */
object Navigator {
    val stack = ArrayList<UIViewController>()
    var nav: UINavigationController? = null

    /** The FrameLayout that holds the Vulkan SurfaceView + the current root VC view (set by host()). */
    var hostRoot: FrameLayout? = null

    fun host(activity: Activity): FrameLayout {
        val root = FrameLayout(activity)
        activity.setContentView(root)
        hostRoot = root
        return root
    }

    fun setRoot(root: UIViewController) {
        stack.clear()
        stack.add(root)
        root.loadViewIfNeeded()
        renderRoot()
    }


    fun present(from: UIViewController, vc: UIViewController, animated: Boolean, completion: (() -> Unit)?) {
        from.presentedViewController = vc
        vc.presentingViewController = from
        vc.loadViewIfNeeded()
        // full-screen presentation over the host
        (currentActivity?.get()?.let { act ->
            val root = act.findViewById<FrameLayout>(android.R.id.content) ?: return
            vc.view.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                vc.viewWillAppear(animated)
            root.addView(vc.view)
            vc.viewDidAppear(animated)
            completion?.invoke()
        })
    }

    fun dismiss(vc: UIViewController, animated: Boolean, completion: (() -> Unit)?) {
        (vc.view.parent as? ViewGroup)?.removeView(vc.view)
        vc.presentingViewController?.presentedViewController = null
        completion?.invoke()
    }

    fun push(nav: UINavigationController, vc: UIViewController, animated: Boolean) {
        // the nav stack is the render stack: the pushed VC becomes the visible root
        if (stack.none { it === vc }) stack.add(vc)
        vc.loadViewIfNeeded()
        renderRoot()
    }

    fun pop(nav: UINavigationController, animated: Boolean) {
        if (stack.size > 1) stack.removeAt(stack.size - 1)
        renderRoot()
    }

    fun renderRoot() {
        val top = stack.lastOrNull() ?: return
        top.loadViewIfNeeded()
        // Swap the visible root inside the host, keeping the Vulkan SurfaceView (the editor preview renders into it).
        val root = hostRoot ?: currentActivity?.get()?.findViewById<FrameLayout>(android.R.id.content) ?: return
        val prev = shown
        if (prev != null && prev !== top) prev.viewWillDisappear(false)
        top.viewWillAppear(false)
        for (i in root.childCount - 1 downTo 0) if (root.getChildAt(i) is UiView) root.removeViewAt(i)
        top.view.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(top.view)
        if (prev != null && prev !== top) prev.viewDidDisappear(false)
        shown = top
        top.view.post { if (shown === top) top.viewDidAppear(false) }     // after the first layout pass (UIKit order)
    }
    private var shown: UIViewController? = null
}

// MARK: - UIAlertController

class UIAlertAction(val title: String?, val style: UIAlertActionStyle, val handler: (() -> Unit)?) {
    companion object {
        fun initWithTitle(t: String?, style: UIAlertActionStyle, handler: (() -> Unit)?): UIAlertAction = UIAlertAction(t, style, handler)
    }
}

enum class UIAlertActionStyle { `default`, cancel, destructive }

class UIAlertController() {
    var title: String? = null
    var message: String? = null
    var textFields = ArrayList<UITextField>()
    val actions = ArrayList<UIAlertAction>()
    var preferredAction: UIAlertAction? = null

    /** Convenience ctor used by RulerSlider.promptValue. */
    constructor(act: Activity, title: String, message: String?) : this() {
        this.title = title
        this.message = message
    }

    companion object {
        fun alertControllerWithTitle(t: String?, message: String?, style: Int): UIAlertController {
            val a = UIAlertController(); a.title = t; a.message = message; return a
        }
    }

    fun addAction(a: UIAlertAction) { actions.add(a) }
    fun addAction(title: String, handler: (() -> Unit)?) { actions.add(UIAlertAction(title, UIAlertActionStyle.default, handler)) }
    fun addTextField(config: (UITextField) -> Unit) { val f = UITextField(); config(f); textFields.add(f) }

    fun present() { showOver(com.saiki.motion.uikit.UIViewController()) }

    fun showOver(vc: UIViewController, animated: Boolean = true) {
        val act = currentActivity?.get() ?: return
        val dlg = AlertDialog.Builder(act)
        if (title != null) dlg.setTitle(title)
        if (message != null) dlg.setMessage(message)
        // add text field views
        textFields.forEach { dlg.setView(it.backing) }
        for (a in actions) dlg.setPositiveButton(a.title) { _, _ -> a.handler?.invoke() }
        if (actions.isEmpty()) dlg.setPositiveButton("OK", null)
        dlg.show()
    }
}

// MARK: - UITableView / UICollectionView (minimal contract used by panels)

open class UITableViewCell(context: Context) : UiView(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))
    /** iOS UITableViewCell.contentView (cells add their custom subviews to it). */
    val contentView: UiView = UiView(context).also { addSubview(it) }
    private var textLabelField: UILabel? = null
    var textLabel: UILabel?
        get() {
            if (textLabelField == null) { textLabelField = UILabel(); addSubview(textLabelField!!) }
            return textLabelField
        }
        set(v) { textLabelField = v }
    var detailTextLabel: UILabel? = null
    var imageView: UiImageView? = null
    var accessoryType: Int = 0
    var selectionStyle: Int = 0
    var contentPaddingLeft: CGFloat = 16f

    override fun layoutSubviews() {
        contentView.frame = CGRect(0f, 0f, rectWidth(), rectHeight())
        textLabel?.let { l ->
            l.frame = CGRect(contentPaddingLeft, 0f, kotlin.math.max(frame.width - contentPaddingLeft * 2, 0f), frame.height)
        }
    }
}

/** UITableView data source (iOS selector parts as distinct method names: same JVM shape otherwise). */
interface UITableViewDataSource {
    fun numberOfRows(t: UITableView, section: Int): Int
    fun cellForRow(t: UITableView, row: Int): UITableViewCell
}

/** UITableView delegate (selection). */
interface UITableViewDelegate {
    fun didSelectRow(t: UITableView, row: Int) {}
}

open class UITableView(context: Context) : UIScrollView(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))
override var delegate: Any? = null
    var dataSource: Any? = null
    var rowHeight: CGFloat = 44f
    var separatorStyle: Int = 0
    var isEditing = false
    var allowsSelection = true
    /** iOS backgroundView: shown when there are no rows (empty-state hint labels), hidden once rows exist. */
    var backgroundView: UiView? = null
        set(v) {
            field?.removeFromSuperview()
            field = v
            if (v != null) { addSubview(v); v.frame = CGRect(0f, 0f, frame.width, frame.height) }
            rebuildCells()
        }
    private val cellCache = ArrayList<UITableViewCell>()

    fun reloadData() { rebuildCells() }
    fun registerClass(c: Any?, id: String) {}

    /** Rebuilds the cell stack from the data source (called from reloadData and layoutSubviews). */
    private fun rebuildCells() {
        for (c in cellCache) c.removeFromSuperview()
        cellCache.clear()
        val ds = dataSource as? UITableViewDataSource ?: return
        val n = ds.numberOfRows(this, 0)
        // iOS: backgroundView is visible only while the table is empty (cells are removed above, so
        // when n == 0 there is nothing it could sit behind; when n > 0 it is hidden and covers nothing).
        backgroundView?.let { bg ->
            bg.isHidden = n > 0
            bg.frame = CGRect(0f, 0f, frame.width, frame.height)
        }
        var y = 0f
        for (row in 0 until n) {
            val c = ds.cellForRow(this, row)
            cellCache.add(c)
            addSubview(c)
            val h = if (c.frame.height > 0f) c.frame.height else rowHeight
            c.frame = CGRect(0f, y, frame.width, h)
            if (allowsSelection) {
                val r = row
                c.onClick = {
                    (delegate as? UITableViewDelegate)?.didSelectRow(this, r)
                    (dataSource as? UITableViewDelegate)?.didSelectRow(this, r)
                }
            }
            y += h
        }
        contentSize = CGSize(frame.width, y)
    }

    /** iOS deselectRow(animated:) — visual only in this layer (no selection highlight kept). */
    fun deselectRow(row: Int, animated: Boolean = true) {}

    override fun layoutSubviews() {
        super.layoutSubviews()
        if (cellCache.isNotEmpty() && cellCache[0].frame.width != frame.width) rebuildCells()
    }
}

/** UITableViewController: owns a UITableView, is its data source + delegate (UIKit contract). */
open class UITableViewController : UIViewController(), UITableViewDataSource, UITableViewDelegate {
    val tableView: UITableView = UITableView()
    init { tableView.dataSource = this; tableView.delegate = this }
    override fun viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(tableView)
        tableView.frame = view.boundsRect
    }
    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = view.boundsRect
        tableView.reloadData()
    }
    override fun numberOfRows(t: UITableView, section: Int): Int = 0
    override fun cellForRow(t: UITableView, row: Int): UITableViewCell = UITableViewCell()
    override fun didSelectRow(t: UITableView, row: Int) {}
}

/** UICollectionView data source (iOS selector parts as distinct method names). */
interface UICollectionViewDataSource {
    fun numberOfItems(cv: UICollectionView): Int
    fun cellForItem(cv: UICollectionView, index: Int): UICollectionViewCell
}

/** UICollectionView delegate (selection). */
interface UICollectionViewDelegate {
    fun didSelectItem(cv: UICollectionView, index: Int) {}
}

/** A collection cell: contentView fills the cell (UIKit contract). */
open class UICollectionViewCell(context: Context) : UiView(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))
    val contentView: UiView = UiView(context).also { addSubview(it) }
    override fun layoutSubviews() { contentView.frame = CGRect(0f, 0f, rectWidth(), rectHeight()) }
}

open class UICollectionView(context: Context) : UIScrollView(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))
    override var delegate: Any? = null
    var dataSource: Any? = null
    var allowsSelection = true
    /** UICollectionViewFlowLayout settings (the gallery's 116x168 cards). */
    var itemSize: CGSize = CGSize(116f, 168f)
    var sectionInset: UIEdgeInsets = UIEdgeInsets(12f, 12f, 12f, 12f)
    var minimumInteritemSpacing: CGFloat = 10f
    var minimumLineSpacing: CGFloat = 14f

    private val cellCache = ArrayList<UICollectionViewCell>()

    fun reloadData() { rebuildCells() }
    fun registerClass(c: Any?, id: String) {}
    fun dequeueReusableCell(id: String, index: Int): UICollectionViewCell = UICollectionViewCell(context)

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w != ow) rebuildCells()
    }

    private fun rebuildCells() {
        val ds = dataSource as? UICollectionViewDataSource ?: run { for (c in cellCache) c.removeFromSuperview(); cellCache.clear(); return }
        for (c in cellCache) c.removeFromSuperview()
        cellCache.clear()
        val w = rectWidth()
        if (w <= 0f) return
        val n = ds.numberOfItems(this)
        val cols = maxOf(((w - sectionInset.left - sectionInset.right + minimumInteritemSpacing) / (itemSize.width + minimumInteritemSpacing)).toInt(), 1)
        val cw = (w - sectionInset.left - sectionInset.right - minimumInteritemSpacing * (cols - 1)) / cols
        var y = sectionInset.top
        var i = 0
        while (i < n) {
            var x = sectionInset.left
            for (c in 0 until cols) {
                if (i >= n) break
                val cell = ds.cellForItem(this, i)
                cellCache.add(cell)
                addSubview(cell)
                cell.frame = CGRect(x, y, cw, itemSize.height)
                if (allowsSelection) {
                    val idx = i
                    cell.onClick = { (delegate as? UICollectionViewDelegate)?.didSelectItem(this, idx) }
                }
                x += cw + minimumInteritemSpacing
                i++
            }
            y += itemSize.height + minimumLineSpacing
        }
        contentSize = CGSize(w, y + sectionInset.bottom - minimumLineSpacing)
    }
}

// MARK: - UIImageView

open class UiImageView(context: Context) : UiView(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))
    var image: UIImage? = null
        set(v) { field = v; setNeedsDisplay() }
    var contentMode: UIViewContentMode = UIViewContentMode.scaleToFill

    override fun draw(rect: CGRect) {
        val img = image ?: return
        val c = UIGraphics.getCurrentContext() ?: return
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        when (contentMode) {
            UIViewContentMode.scaleAspectFit -> {
                val s = kotlin.math.min(frame.width / img.size.width, frame.height / img.size.height)
                val dw = img.size.width * s; val dh = img.size.height * s
                c.canvas.drawBitmap(img.bitmap, null, android.graphics.RectF((frame.width - dw) / 2, (frame.height - dh) / 2, (frame.width + dw) / 2, (frame.height + dh) / 2), p)
            }
            UIViewContentMode.scaleAspectFill -> {
                val s = kotlin.math.max(frame.width / img.size.width, frame.height / img.size.height)
                val dw = img.size.width * s; val dh = img.size.height * s
                c.canvas.drawBitmap(img.bitmap, null, android.graphics.RectF((frame.width - dw) / 2, (frame.height - dh) / 2, (frame.width + dw) / 2, (frame.height + dh) / 2), p)
            }
            else -> c.canvas.drawBitmap(img.bitmap, null, android.graphics.RectF(0f, 0f, frame.width, frame.height), p)
        }
    }
}

enum class UIViewContentMode { scaleToFill, scaleAspectFit, scaleAspectFill, redraw, center, top, bottom, left, right, topLeft, topRight, bottomLeft, bottomRight }

// MARK: - UITextView (multi-line editing; SdkIde's code editor)

open class UITextView(context: Context) : UiView(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))

    val backing: EditText = EditText(context).apply {
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        gravity = android.view.Gravity.TOP or android.view.Gravity.START
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        isSingleLine = false
        setPadding(0, 0, 0, 0)
        setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, 13f)
        typeface = android.graphics.Typeface.MONOSPACE
        setTextColor(0xFF000000.toInt())
    }

    var text: String
        get() = backing.text?.toString() ?: ""
        set(v) { backing.setText(v) }

    var isEditable: Boolean
        get() = backing.isEnabled
        set(v) { backing.isEnabled = v; backing.isFocusable = v; backing.isFocusableInTouchMode = v }

    /** UITextViewDelegate.textViewDidChange twin. */
    var onDidChange: (() -> Unit)? = null

    var font: UIFont? = null
        set(v) { field = v; v?.let { backing.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, it.size); backing.typeface = it.toPaint().typeface } }

    var textContainerInset: UIEdgeInsets = UIEdgeInsets.zero
        set(v) { field = v; backing.setPadding(v.left.toInt(), v.top.toInt(), v.right.toInt(), v.bottom.toInt()) }

    var selectedRange: NSRange
        get() = NSRange(backing.selectionStart, (backing.selectionEnd - backing.selectionStart).coerceAtLeast(0))
        set(r) { backing.setSelection(r.loc.coerceIn(0, text.length)) }

    init {
        backing.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { onDidChange?.invoke() }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        })
        addView(backing, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec); val h = MeasureSpec.getSize(heightSpec)
        backing.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
        setMeasuredDimension(w, h)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        backing.layout(0, 0, r - l, b - t)
    }

    /** ForegroundColorSpan twin of NSAttributedString .foregroundColor. */
    fun spanColor(range: NSRange, color: Int) {
        val s = backing.text as? Editable ?: return
        val st = range.loc.coerceIn(0, s.length); val en = (range.loc + range.len).coerceIn(st, s.length)
        s.setSpan(android.text.style.ForegroundColorSpan(color), st, en, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun clearSpans() {
        val s = backing.text as? Editable ?: return
        for (sp in s.getSpans(0, s.length, Any::class.java)) s.removeSpan(sp)
    }
}

// MARK: - misc UIKit globals

fun disallowParentScrollInterception(v: UiView, disallow: Boolean) {
    var p = v.parent
    while (p is ViewGroup) {
        if (p is ScrollView || p is android.widget.HorizontalScrollView) p.requestDisallowInterceptTouchEvent(disallow)
        p = p.parent
    }
}

class UIImpactFeedbackGenerator(style: Int = 0) {
    fun impactOccurred() {
        // Android haptics via view.performHapticFeedback at call sites; kept as no-op object for parity
    }
    fun prepare() {}
}

class UINotificationFeedbackGenerator {
    fun notificationOccurred(type: Int) {}
}

class UISelectionFeedbackGenerator {
    fun selectionChanged() {}
}

// MARK: - Theme-facing style helpers (Theme.swift globals)

fun fillStyleRoundRect(c: CGContext, r: CGRect, radius: CGFloat, color: Int) {
    c.setFillColor(color)
    val p = CGPath.roundedRect(r, radius, radius)
    c.addPath(p); c.fillPath()
}
fun strokeStyleRoundRect(c: CGContext, r: CGRect, radius: CGFloat, width: CGFloat, color: Int) {
    c.setStrokeColor(color); c.setLineWidth(width)
    val p = CGPath.roundedRect(r, radius, radius)
    c.addPath(p); c.strokePath()
}
fun strokeStyleLine(c: CGContext, x0: CGFloat, y0: CGFloat, x1: CGFloat, y1: CGFloat, width: CGFloat, color: Int) {
    c.setStrokeColor(color); c.setLineWidth(width)
    val p = CGPath(); p.move(CGPoint(x0, y0)); p.addLine(CGPoint(x1, y1))
    c.addPath(p.path); c.strokePath()
}
fun fillStyleCircle(c: CGContext, x: CGFloat, y: CGFloat, r: CGFloat, color: Int) {
    c.setFillColor(color)
    c.fillEllipse(CGRect(x - r, y - r, 2 * r, 2 * r))
}

fun strokeStyleCircle(c: CGContext, x: CGFloat, y: CGFloat, r: CGFloat, width: CGFloat, color: Int) {
    c.setStrokeColor(color); c.setLineWidth(width)
    c.strokeEllipse(CGRect(x - r, y - r, 2 * r, 2 * r))
}

// MARK: - UIColorWell (iOS 14 color well; opens a color dialog on tap)

/**
 * Small rounded swatch control. Tapping opens a color dialog that reuses the app's ColorPickerView
 * (ui/ColorPickerView.kt — the ColorPicker.swift square + hue/opacity bars) inside a Dlg-style card.
 * `onValueChanged` fires when a color is chosen; `title` captions the dialog; `supportsAlpha`
 * locks the alpha bar at 1 (callers that store _a separately).
 */
class UIColorWell(context: Context) : UIControl(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))

    var selectedColor: UIColor = UIColor.white
        set(v) { field = v; setNeedsDisplay() }
    var supportsAlpha = true
    var title: String? = null
    var onValueChanged: (() -> Unit)? = null

    init { onClick = { openPicker() } }

    private fun openPicker() {
        val win = (currentActivity?.get()?.window?.decorView as? UiView) ?: return
        val dim = UiView(win.context)
        val card = UiView(win.context)
        dim.setBackgroundColor(0x8C000000.toInt())
        dim.frame = CGRect(0f, 0f, win.rectWidth(), win.rectHeight())
        win.addSubview(dim)
        dim.onClick = { dim.removeFromSuperview(); card.removeFromSuperview() }

        card.setBackgroundColor(0xFF1C1C20.toInt())
        card.frame = CGRect(0f, 0f, 300f, 400f)
        dim.addSubview(card)

        val label = UILabel(win.context)
        label.text = title ?: ""
        label.font = UIFont.boldSystemFont(15f)
        label.textColor = UIColor.white
        label.textAlignment = NSTextAlignment.center
        label.frame = CGRect(0f, 12f, 300f, 22f)
        card.addSubview(label)

        // ColorPickerView pieces: the square + bars (alpha row hidden when !supportsAlpha)
        val cp = com.saiki.motion.ui.ColorPickerView()
        cp.setColor(selectedColor.toInt())
        cp.frame = CGRect(24f, 44f, 252f, if (supportsAlpha) 328f else 296f)
        card.addSubview(cp)
        val done = UIButton(win.context)
        done.title = "Done"
        done.titleColor = UIColor.white
        done.font = UIFont.boldSystemFont(15f)
        done.frame = CGRect(24f, if (supportsAlpha) 380f else 348f, 252f, 34f)
        card.addSubview(done)
        done.onTouchUpInside = {
            selectedColor = argbToUIColor(cp.color())
            dim.removeFromSuperview(); card.removeFromSuperview()
            onValueChanged?.invoke()
        }
        cp.onChange = { c -> if (!supportsAlpha) cp.setColor((c or 0xFF000000.toInt())) }
        // center the card
        card.frame = CGRect((win.rectWidth() - 300f) / 2, (win.rectHeight() - 400f) / 2, 300f, 400f)
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        c.setStrokeColor(0x66FFFFFF.toInt()); c.setLineWidth(1f)
        fillRoundRect(c, rect.insetBy(1f, 1f), 5f, selectedColor.toInt())
        strokeRoundRect(c, rect.insetBy(0.5f, 0.5f), 5f, 1f, 0x66FFFFFF.toInt())
    }
}

// MARK: - UISegmentedControl (thin twin over FlatSegment-style drawing)

/** iOS UISegmentedControl subset: items + selectedSegmentIndex + onValueChanged. */
open class UISegmentedControl(val items: List<String>) : UIControl(appContext ?: throw IllegalStateException("appContext not set")) {
    var selectedSegmentIndex = 0
        set(v) { field = v; setNeedsDisplay() }
    var selectedSegmentTintColor: Int? = null
    var onValueChanged: (() -> Unit)? = null

    init { setNeedsDisplay() }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        if (items.isEmpty()) return
        val w = rectWidth() / items.count().toFloat()
        val i = kotlin.math.min(kotlin.math.max((t.location(this).x / w).toInt(), 0), items.count() - 1)
        if (i != selectedSegmentIndex) { selectedSegmentIndex = i; onValueChanged?.invoke() }
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 9f, 0xFF2B2B2B.toInt())
        if (items.isEmpty()) return
        val w = rect.width / items.count().toFloat()
        for ((i, t) in items.withIndex()) {
            val r = CGRect(w * i, 0f, w, rect.height)
            if (i == selectedSegmentIndex) fillRoundRect(c, r.insetBy(2f, 2f), 7f, selectedSegmentTintColor ?: 0xFFFF8C14.toInt())
            val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            p.textSize = if (items.count() > 4) 10f else 13f
            p.typeface = if (i == selectedSegmentIndex) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
            p.color = if (i == selectedSegmentIndex) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            val tw = p.measureText(t)
            c.canvas.drawText(t, r.midX - tw / 2f, r.midY - (p.ascent() + p.descent()) / 2f, p)
        }
    }
}

// MARK: - UISearchBar (minimal: field + magnifier tint)

/** iOS UISearchBar subset: placeholder + onTextChanged (search field on a card background). */
open class UISearchBar(context: Context) : UIControl(context) {
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))

    var placeholder: String = ""
        set(v) { field = v; backing.hint = v }
    var onTextChanged: ((String) -> Unit)? = null
    val backing = EditText(context).apply {
        setBackgroundColor(0xFF2E2E2E.toInt())
        setPadding(28, 12, 12, 12)
        setTextColor(android.graphics.Color.WHITE)
        hint = placeholder
        addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: Editable?) { onTextChanged?.invoke(s?.toString() ?: "") }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        })
    }

    init {
        addView(backing, android.view.ViewGroup.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT))
    }

    var text: String
        get() = backing.text?.toString() ?: ""
        set(v) { backing.setText(v) }

    fun resignFirstResponder() { backing.clearFocus() }
}

/** UITableViewCell thumb image (the iOS imageView) with a proper left offset. */
fun UITableViewCell.setThumb(bmp: android.graphics.Bitmap) {
    val iv = object : UiView(context) {
        public override fun draw(rect: CGRect) {
            val c = UIGraphics.getCurrentContext() ?: return
            c.canvas.drawBitmap(bmp, null,
                android.graphics.RectF(0f, 0f, rect.height, rect.height),
                android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
        }
    }
    iv.frame = CGRect(8f, 8f, frame.height - 16f, frame.height - 16f)
    contentView.addSubview(iv)
    contentPaddingLeft = frame.height
    setNeedsDisplay()
}
