package com.saiki.motion

import android.app.Activity
import android.os.Bundle
import android.view.Choreographer
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.FrameLayout
import com.saiki.motion.app.HomeViewController
import com.saiki.motion.core.AudioLibrary
import com.saiki.motion.core.CrashLog
import com.saiki.motion.core.FreezeWatchdog
import com.saiki.motion.core.Paths
import com.saiki.motion.render.NativeRenderer
import com.saiki.motion.uikit.Navigator
import com.saiki.motion.uikit.appContext

/**
 * Main.swift twin: hosts the UIKit layer (Navigator root = the app's UI tree) over the Vulkan
 * core's SurfaceView. The surface stays alive underneath; the editor's PreviewView renders into
 * it (GLKView parity), so surfaceCreated only inits the renderer, never replaces the content view.
 */
class MainActivity : Activity(), SurfaceHolder.Callback, Choreographer.FrameCallback {
    private var running = false
    private var uiBooted = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        appContext = this   // UIKit shim needs it for view construction
        Paths.init(this); Paths.ensure()
        CrashLog.install(); FreezeWatchdog.start(); AudioLibrary.dir  // Main.swift parity
        val sv = SurfaceView(this); sv.holder.addCallback(this)
        val host = Navigator.host(this)      // FrameLayout root
        host.addView(sv, FrameLayout.LayoutParams(-1, -1))
        Navigator.setRoot(HomeViewController())
        uiBooted = true
    }

    override fun surfaceCreated(h: SurfaceHolder) {
        if (uiBooted) {
            running = NativeRenderer.init(h.surface, assets)
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) { NativeRenderer.resize(w, hh) }
    override fun surfaceDestroyed(h: SurfaceHolder) { running = false; NativeRenderer.destroy() }
    override fun doFrame(ns: Long) {
        if (!running) return
        NativeRenderer.frame(ns / 1e9f)
        Choreographer.getInstance().postFrameCallback(this)
    }
}
