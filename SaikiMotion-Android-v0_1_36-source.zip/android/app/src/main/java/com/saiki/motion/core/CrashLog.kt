package com.saiki.motion.core

import java.io.File

// Port of Sources/Support/CrashLog.swift — crash logger (NDK sigaction replaces the C module CCrashLog;
// see cpp/jni_crash.cpp). Install once, as early as possible in process lifetime.
object CrashLog {
    /** Create <Documents>/Crash and install handlers. Safe to call twice. */
    fun install() {
        val dir = crashDir()
        dir.mkdirs()
        installNative(dir.absolutePath)
        EffectCrashLog.recover()
    }

    /** Record what the app is doing — shows up in the crash report ring. Cheap; call at transitions. */
    fun note(tag: String) = noteNative(tag)

    /** Directory shown in the Files app (user-visible crash folder). */
    fun crashDir(): File = File(Paths.root, "Crash")

    /** Count of reports — Extras tab shows this. */
    fun reportCount(): Int = crashDir().listFiles()?.count { it.extension == "log" } ?: 0

    /** Native crash handlers (signal + java uncaught-exception thread hook). */
    @JvmStatic external fun installNative(dir: String)
    @JvmStatic external fun noteNative(tag: String)
}
