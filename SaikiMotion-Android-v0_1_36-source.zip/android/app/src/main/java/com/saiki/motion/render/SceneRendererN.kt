package com.saiki.motion.render

// Native bridge for the scene renderer (Slice 8): targets, quad/composite passes, glow chain, frame presentation.
// All handles are jlong pointers into vk_core-owned objects (Target* / Tex*), exactly like NativeModel.
object SceneRendererN {
    // ---- lifecycle ----
    @JvmStatic external fun begin(): Boolean                    // start recording the frame's command buffer
    @JvmStatic external fun finish()                            // submit what has been encoded so far
    @JvmStatic external fun present(sceneTarget: Long): Boolean // blit the scene target to the swapchain + present
    @JvmStatic external fun ready(): Boolean                    // device + swapchain ready

    // ---- targets & textures ----
    @JvmStatic external fun targetCreate(w: Int, h: Int, half: Boolean): Long
    @JvmStatic external fun targetTex(target: Long): Long       // non-owning Tex* of the target's colour image
    @JvmStatic external fun targetW(target: Long): Int
    @JvmStatic external fun targetH(target: Long): Int
    @JvmStatic external fun targetFree(target: Long)
    @JvmStatic external fun swapTargets(a: Long, b: Long)       // exchange the images/framebuffers of two same-size targets
    @JvmStatic external fun texCreate(w: Int, h: Int, rgba: ByteArray): Long
    @JvmStatic external fun texCreateCapped(w: Int, h: Int, bmp: android.graphics.Bitmap, maxSide: Int): Long
    @JvmStatic external fun texFree(tex: Long)
    @JvmStatic external fun readTarget(target: Long): android.graphics.Bitmap?

    // ---- passes ----
    @JvmStatic external fun clear(target: Long, r: Float, g: Float, b: Float, a: Float)
    @JvmStatic external fun blit(srcTex: Long, toTarget: Long): Boolean
    @JvmStatic external fun composite(target: Long, scratch: Long, srcTex: Long, maskTex: Long,
                                      alpha: Float, mode: Int, maskMode: Int, rgbShift: Float): Boolean
    /** quad pass (quad.frag / shape.frag with fs.vert|mesh.vert|warp.vert). u = QuadU floats (see jni_scene.cpp). */
    @JvmStatic external fun quadPass(frag: String, vert: String, blend: Boolean, into: Long, clear: Boolean,
                                     u: FloatArray, tex: Long, pos: FloatArray?, uv: FloatArray?, count: Int): Boolean
    @JvmStatic external fun pipelineReady(frag: String): Boolean

    // ---- Deep Glow (MetalGlow) ----
    @JvmStatic external fun encodeGlowPass(frag: String, into: Long, tex0: Long, tex1: Long, ubo: FloatArray): Boolean
    @JvmStatic external fun encodeGlowFinal(out: Long, srcTex: Long, glowTex: Long, ubo: FloatArray): Boolean

    // ---- particles / flares ----
    /** particle pass: PtU b0 (44 floats), pts SSBO b1 (12 floats/vertex), grad[16] b2, atlas b0 + bump b1 (fragment stage). */
    @JvmStatic external fun particlePass(into: Long, u: FloatArray, pts: FloatArray, grad: FloatArray, atlas: Long, bump: Long): Boolean
    /** flare pass: dep b0 (depth view), FlareArr b1 (112 vec4), FlareLens b2 (256 vec4), FlareU b8 (24 floats). */
    @JvmStatic external fun flarePass(into: Long, u: FloatArray, arr: FloatArray, lens: FloatArray, depthTex: Long): Boolean
    /** 1x1 D32 dummy depth texture (flare occlusion placeholder). */
    @JvmStatic external fun depthCreate1(): Long
    /** one effect pass src -> out through the async fx runtime (EffectThumbs generation). */
    @JvmStatic external fun fxPass(key: String, src: Long, out: Long, time: Float): Boolean
    /** RGBA16F equirect texture with full mipmap chain (GlobalEnv HDRI). rgba16 = little-endian half floats. */
    @JvmStatic external fun envTexCreate(w: Int, h: Int, rgba16: ByteArray): Long
    /** mipmap level count of a texture created with envTexCreate. */
    @JvmStatic external fun texMipLevels(tex: Long): Int

    /** android Bitmap -> top-row-first RGBA bytes. */
    @JvmStatic fun bitmapRgba(bmp: android.graphics.Bitmap): ByteArray {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val out = ByteArray(w * h * 4)
        for (i in 0 until w * h) {
            val c = px[i]
            out[i * 4] = (c shr 16).toByte(); out[i * 4 + 1] = (c shr 8).toByte()
            out[i * 4 + 2] = c.toByte(); out[i * 4 + 3] = (c ushr 24).toByte()
        }
        return out
    }
}
