#!/bin/bash
# Compile shared/shaders/glsl -> android assets: assets_src/shaders/<name>.spv (vulkan1.2 target).
set -e
W=/home/z/my-project/work
G=$W/tools/sdk/ndk/26.1.10909125/shader-tools/linux-x86_64/glslc
OUT=$W/android/app/src/main/assets/shaders
mkdir -p "$OUT"
n=0
for f in $W/android/shared/shaders/glsl/*.vert $W/android/shared/shaders/glsl/*.frag; do
  b=$(basename "$f"); stage="${b##*.}"
  $G --target-env=vulkan1.2 -fshader-stage=$stage "$f" -o "$OUT/${b%.*}.spv"
  n=$((n+1))
done
echo "compiled $n shaders -> $OUT"
