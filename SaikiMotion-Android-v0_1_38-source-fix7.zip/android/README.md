# SaikiMotion Android — v0.1.36 (final audit round)

iOS app SaikiMotion v0.1.36 → Android (Kotlin + Vulkan + JNI), ported from Swift/Metal source.
Status: feature-complete port of the v0.1.36 iOS source; `TODO(parity)` = 0, 12 justified
`PARITY-NOTE`s (grep them for iOS file:line refs). Not yet verified on a real device —
see `../docs/DEVICE_TEST.md` for the 23-section device test plan.

## Build

```bash
cd android
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64      # JDK 17+ works
export ANDROID_HOME=/path/to/sdk                         # SDK 34 + NDK 26.1.10909125
./gradlew assembleDebug                                  # dev build
./gradlew assembleRelease                                # optimized deliverable (R8 + -Os)
```

In the original sandbox the toolchain is vendored under `../tools/`
(`gradle-8.7/`, `sdk/` — gitignored, 4.1 GB) and the build was launched with
`GRADLE_USER_HOME=../tools/gradle-home ../tools/gradle-8.7/bin/gradle --no-daemon assembleRelease`.

- Native `libsaiki.so` links Vulkan + NDK shaderc (runtime GLSL→SPIR-V for effects) + c-blosc/abc2glb decoders;
  release links with `-Os -ffunction-sections -fdata-sections -Wl,--gc-sections -s` (stripped)
- 21+ SPIR-V shaders precompiled into `app/src/main/assets/shaders` by `scripts/build_shaders.sh`
  (`model_rt.frag` needs `GL_EXT_ray_query` → `#version 460`)
- Manifest declares READ_MEDIA_IMAGES/VIDEO (+READ_EXTERNAL_STORAGE ≤32) for the album browser
- Release uses R8 (`app/proguard-rules.pro`: JNI classes kept — `external fun` binds by name; ONNX API kept)
  and stays **debug-signed** (no release key in the sandbox)

## Layout

- `app/` — the Android project (`app/src/main/java/com/saiki/motion/{core,render,ui,uikit,app}` + `cpp/` + `assets/`)
- `shared/` — one source of truth: GLSL+MSL shaders, `resources/catalog/builtins.json`
  (175 effects, byte-exact with iOS), sdk plugins/examples, img presets (byte-for-byte with iOS)
- `../docs/` — PARITY.md, HANDOFF.md, DEVICE_TEST.md, SHARED_CODE.md, PORT_CHECKLIST.md
- `tools/` — parity/build tooling (dump_catalog.sh, gen_model_rt.py, parity_table.py, shader_sync_check.py);
  the SDK/NDK/Gradle install lives outside the project (`../tools/`, gitignored)

## Verification status

- `assembleDebug` + `assembleRelease` green; release APK **33.3 MB** (debug 38.9), dex 11 → 3.1 MB (R8),
  `libsaiki.so` stripped; debug-signed; contains all final-round strings (album browser, scatter editor)
- Effects catalog parity 175 = 175 (`tools/dump_catalog.sh`)
- Shader GLSL↔MSL parity enforced by `tools/shader_sync_check.py`
- Everything render/ML related is unverified on device (no emulator in the sandbox):
  Vulkan passes, ONNX inference (AnimeSeg/DepthAnything), MediaCodec video decode —
  `../docs/DEVICE_TEST.md` lists exactly what to compare against iOS, per feature.
