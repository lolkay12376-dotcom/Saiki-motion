plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.saiki.motion"
    compileSdk = 34
    ndkVersion = "26.1.10909125"
    defaultConfig {
        applicationId = "com.saiki.motion.app"      // same id as iOS bundle
        minSdk = 29; targetSdk = 34
        versionCode = 88; versionName = "0.1.36"   // keep == iOS Info.plist / zip version
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild { cmake { cppFlags += "-std=c++17"; arguments += "-DANDROID_STL=c++_shared" } }
    }
    buildFeatures { shaders = false }   // precompiled: scripts/build_shaders.sh -> src/main/assets/shaders (vulkan1.2)
    lint { checkReleaseBuilds = false } // R8 + lint in one 4GB-box daemon OOMs; lint runs in CI/dev instead
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
    buildTypes {
        release {
            isMinifyEnabled = true            // R8: shrinks + optimizes dex (~11MB -> ~4MB)
            isShrinkResources = false         // resources come from the uikit layer, no res/ tree worth shrinking
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("debug")   // final deliverable stays debug-signed (no release key in sandbox)
            ndk { debugSymbolLevel = "NONE" } // no symbol zip
        }
    }
    sourceSets["main"].apply {
        // ONE source of truth for shaders: ../shared/shaders/glsl (AGP compiles with glslc -> assets/shaders/<name>.spv)
        // shaders precompiled into src/main/assets/shaders by ../../scripts/build_shaders.sh (vulkan1.2 target)
        // iOS SDK plugins/effects/images are shared byte-for-byte
        assets.srcDirs("../shared/resources")
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17"; freeCompilerArgs += listOf("-opt-in=kotlin.ExperimentalStdlibApi", "-XXLanguage:+BreakContinueInInlineLambdas") }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    // ONNX Runtime (anime-seg isnetis + Depth Anything V2 onnx builds — real on-device inference)
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.17.0")
}
