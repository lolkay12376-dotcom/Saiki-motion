# SaikiMotion R8 rules (release minify).
# The app has NO reflection, but its UIKit shim constructs view controllers dynamically in
# many places (Navigator stacks, present(), per-panel factories), so ALL app classes are kept:
# R8's static reachability under-approximates this (it stripped MediaBrowserViewController in
# the first minified build — album browser silently dead in release). The size win comes from
# shrinking AndroidX/ONNX deps, which stay minimized.
-keep class com.saiki.motion.** { *; }
-keep class com.saiki.motion.**$* { *; }

# JNI (external fun binds by exact Java_com_saiki_motion_<Class>_<method> at load time).
-keepclasseswithmembernames class com.saiki.motion.** { native <methods>; }

# ONNX Runtime java API (OrtEnvironment etc.) is reflective about its providers.
-keep class ai.onnxruntime.** { *; }

# Kotlin metadata + coroutines: harmless, avoids runtime warnings from stripped metadata.
-dontwarn kotlinx.coroutines.**
-keepattributes SourceFile,LineNumberTable        # readable crash logs from the field
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
