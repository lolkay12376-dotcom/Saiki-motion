cmake_minimum_required(VERSION 3.22)
project(saiki C CXX)

# Recovered decoders, reused UNCHANGED from iOS (c-blosc 1.21.5 for VDB, abc2glb for Alembic). Same flags as project.yml.
file(GLOB BLOSC_SRC native/blosc/*.c)
add_library(cnative STATIC native/bridge.c ${BLOSC_SRC})   # abc2glb.c is #included by bridge.c (single TU)
target_include_directories(cnative PUBLIC native native/include native/blosc)
target_compile_definitions(cnative PRIVATE HAVE_STDINT_H=1 HAVE_STRING_H=1 HAVE_STDIO_H=1 HAVE_STDLIB_H=1 HAVE_INTTYPES_H=1 HAVE_LZ4=1 NDEBUG=1)
target_compile_options(cnative PRIVATE -w)

# NDK shaderc (runtime GLSL -> SPIR-V for effects). NDK r26 ships shaderc SOURCES only (no prebuilt
# .a): work/scripts/build_shaderc.sh ndk-builds them into the libs/ layout below.
set(SHADERC_DIR ${ANDROID_NDK}/sources/third_party/shaderc)
set(SHADERC_LIBS ${SHADERC_DIR}/libs/${ANDROID_STL}/${ANDROID_ABI})
foreach(_sc shaderc shaderc_util SPIRV-Tools SPIRV-Tools-opt glslang SPIRV HLSL OGLCompiler OSDependent SPVRemapper)
    add_library(sc_${_sc} STATIC IMPORTED)
    set_target_properties(sc_${_sc} PROPERTIES IMPORTED_LOCATION ${SHADERC_LIBS}/lib${_sc}.a)
    list(APPEND SHADERC_LINK sc_${_sc})
endforeach()

add_library(saiki SHARED vk_core.cpp fx_runtime.cpp jni_bridge.cpp jni_model.cpp jni_scene.cpp jni_crash.cpp)
target_include_directories(saiki PRIVATE ${SHADERC_DIR}/libshaderc/include ${SHADERC_DIR}/third_party/spirv-tools/include ${SHADERC_DIR}/third_party/spirv-tools/external/spirv-headers/include)
target_compile_definitions(saiki PRIVATE VK_USE_PLATFORM_ANDROID_KHR=1)
# Size/perf: -Os + dead-code strip in release; the shaderc static archives carry the whole
# glslang front-end, which the linker can now garbage-collect (-ffunction-sections + --gc-sections).
target_compile_options(saiki PRIVATE
    $<$<CONFIG:Release>:-Os> $<$<CONFIG:Debug>:-O0>
    -ffunction-sections -fdata-sections)
target_link_options(saiki PRIVATE
    $<$<CONFIG:Release>:-s>              # strip in release
    $<$<CONFIG:Release>:-Wl,--gc-sections>
    $<$<CONFIG:Debug>:-Wl,--no-gc-sections> $<$<CONFIG:Debug>:-Wl,--export-dynamic>)
# link order: shaderc (top) -> shaderc_util -> glslang -> SPIRV-Tools; jnigraphics for AndroidBitmap_*
target_link_libraries(saiki cnative ${SHADERC_LINK} jnigraphics vulkan android log)
