// fx_runtime.cpp — Android twin of Sources/Render/MetalEffects.swift (apply / applyChain / async compile cache).
// Effects keep GLSL as their source (Kotlin FxGlsl.vulkanSource == MetalEffects.translate output); here it is compiled at runtime with
// NDK shaderc on a background thread (never on the render thread) and, until ready, the effect is a passthrough (apply() returns false).
// PARITY-NOTE (MetalEffects.swift:96 compileQ): iOS compiles through its own GCD queue; Android uses an NDK std::thread + atomic-ready flag.
// EffectCrashLog (MetalEffects.swift:121-165) lives in Kotlin (core/EffectCrashLog.kt), used by EffectThumbs/FreezeWatchdog.
#include "vk_core.h"
#include <shaderc/shaderc.hpp>
#include <android/log.h>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <atomic>
#include <algorithm>
#include <vector>
#include <memory>
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "saiki-fx", __VA_ARGS__)

namespace saiki {
namespace {
struct Entry { int state = 0; std::string error; std::string name; std::vector<uint32_t> spv; };   // state: 0 pending, 1 ready, 2 failed (== Entry.pending/lib/error)
std::mutex mu;
std::map<std::string, std::shared_ptr<Entry>> cache;
std::atomic<int> readyCount{0};
int translatedCount = 0;
}
bool fxSpv(const std::string& name, std::vector<uint32_t>& out) {       // vk_core.cpp loadSpv hook: "shaders/fx/<key>.spv"
    const std::string pre = "shaders/fx/", suf = ".spv";
    if (name.size() < pre.size() + suf.size() || name.compare(0, pre.size(), pre) != 0) return false;
    std::string key = name.substr(pre.size(), name.size() - pre.size() - suf.size());
    std::lock_guard<std::mutex> l(mu); auto it = cache.find(key);
    if (it == cache.end() || it->second->state != 1) return false;
    out = it->second->spv; return true;
}
bool fxPrepare(const std::string& key, const std::string& glsl, const std::string& name) {
    std::shared_ptr<Entry> e;
    { std::lock_guard<std::mutex> l(mu); if (cache.count(key)) return true; e = std::make_shared<Entry>(); e->name = name; cache[key] = e; }
    std::thread([e, glsl, key]() {          // == MetalEffects.compileQ (never compile on the render/main thread)
        shaderc::Compiler comp; shaderc::CompileOptions o;
        o.SetTargetEnvironment(shaderc_target_env_vulkan, shaderc_env_version_vulkan_1_1); o.SetOptimizationLevel(shaderc_optimization_level_performance);
        auto r = comp.CompileGlslToSpv(glsl, shaderc_fragment_shader, key.c_str(), o);
        std::lock_guard<std::mutex> l(mu);
        if (r.GetCompilationStatus() == shaderc_compilation_status_success) { e->spv.assign(r.cbegin(), r.cend()); e->state = 1; translatedCount++; }
        else { e->error = r.GetErrorMessage().substr(0, 400); e->state = 2; LOG("effect %s failed: %s", e->name.c_str(), e->error.c_str()); }
        readyCount++;
    }).detach();
    return true;
}
int fxStatus(const std::string& key) { std::lock_guard<std::mutex> l(mu); auto it = cache.find(key); return it == cache.end() ? -1 : it->second->state; }
std::string fxError(const std::string& key) { std::lock_guard<std::mutex> l(mu); auto it = cache.find(key); return it == cache.end() ? "" : it->second->error; }
int fxReadyCount() { return readyCount.load(); }

// == MetalEffects.apply: one pass src -> out. Returns false (writes nothing) when the shader is not ready / failed.
// rect = {lc.x, lc.y, lx.x, lx.y, ly.x, ly.y} or nullptr.
bool fxApply(VkCommandBuffer cb, const FxStep& step, VkImageView src, Target& out, float time, const float* rect) {
    if (fxStatus(step.key) != 1) return false;
    const Layout* L = layoutForShader("fx/");
    VkPipeline pso = pipelineForFile("fs.vert", ("fx/" + step.key).c_str(), out.fmt); if (!pso) return false;
    FxCommon c;
    c.res[0] = (float)out.width; c.res[1] = (float)out.height; c.time = time;
    c.has0 = step.in0 ? 1.f : 0.f; c.has1 = step.in1 ? 1.f : 0.f;
    float ar = (float)out.width / (float)std::max(out.height, 1);
    if (rect) { c.lc[0] = rect[0]; c.lc[1] = rect[1]; c.lx[0] = rect[2]; c.lx[1] = rect[3]; c.ly[0] = rect[4]; c.ly[1] = rect[5]; }
    else { c.lx[0] = ar * 2; c.lx[1] = 0; c.ly[0] = 0; c.ly[1] = 2; }
    // props buffer: props as consecutive floats, each colour (r,g,b,a) on a 16-byte boundary (Kotlin FxGlsl.propBuffer).
    // Reused thread-local scratch: runs per step per frame; the old per-call vector copy was pure churn
    // (the data is memcpy'd into the frame arena immediately, nothing retains it past this call).
    static thread_local std::vector<float> flat;
    flat = step.props; while (flat.size() % 4) flat.push_back(0.f);
    for (auto v : step.colors) flat.push_back(v);                      // colors already flattened 4 floats each
    if (flat.empty()) flat = {0.f, 0.f, 0.f, 0.f};
    Bind b[5]; b[0].binding = 0; b[0].view = src; b[1].binding = 1; b[1].view = step.in0; b[2].binding = 2; b[2].view = step.in1;
    b[3].binding = 3; b[3].data = &c; b[3].size = sizeof(FxCommon); b[4].binding = 4; b[4].data = flat.data(); b[4].size = (uint32_t)(flat.size() * 4);
    return encodeFx(cb, out, pso, L, false, b, 5);
}
// == MetalEffects.applyChain: ping-pong; an effect that cannot run is skipped (passthrough, never a blank frame). Returns the target holding the result.
Target& fxApplyChain(VkCommandBuffer cb, const std::vector<FxStep>& steps, Target& a, Target& b, float time, const float* rect) {
    Target* read = &a; Target* write = &b;
    for (auto& s : steps) if (fxApply(cb, s, read->tex.view, *write, time, rect)) std::swap(read, write);
    return *read;
}
}
