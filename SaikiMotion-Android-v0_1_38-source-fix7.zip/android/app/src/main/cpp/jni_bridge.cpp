#include <jni.h>
#include <android/native_window_jni.h>
#include <android/asset_manager_jni.h>
#include "vk_core.h"
#include <string>

static ANativeWindow* gWin = nullptr;
#include "blosc.h"
extern "C" int saiki_abc_to_glb(const char* src_path, char* out_glb_path, unsigned long out_cap);   // native/bridge.c (iOS decoder, unchanged)

extern "C" {
// VdbVolume.parse: blosc_decompress(src, dst, destSize) from the unchanged c-blosc 1.21.5 (result ignored like iOS; dst stays zero-filled on failure).
JNIEXPORT jbyteArray JNICALL Java_com_saiki_motion_core_NativeBlosc_decompress(JNIEnv* e, jobject, jbyteArray src, jint destSize) {
    if (destSize < 0) destSize = 0;
    jbyteArray out = e->NewByteArray(destSize);
    if (!out) return nullptr;
    jsize sl = e->GetArrayLength(src);
    jbyte* sp = e->GetByteArrayElements(src, nullptr);
    jbyte* dp = e->GetByteArrayElements(out, nullptr);
    if (sp && dp && sl > 0) blosc_decompress(sp, dp, (size_t)destSize);
    if (sp) e->ReleaseByteArrayElements(src, sp, JNI_ABORT);
    if (dp) e->ReleaseByteArrayElements(out, dp, 0);
    return out;
}

// GlbModel.transcodeAbc: returns the new .glb path or null (same 1100-byte buffer as iOS).
JNIEXPORT jstring JNICALL Java_com_saiki_motion_core_NativeAbc_abcToGlb(JNIEnv* e, jobject, jstring src) {
    const char* c = e->GetStringUTFChars(src, nullptr);
    if (!c) return nullptr;
    char out[1100] = {0};
    int ok = saiki_abc_to_glb(c, out, 1100);
    e->ReleaseStringUTFChars(src, c);
    return ok == 1 ? e->NewStringUTF(out) : nullptr;
}
JNIEXPORT jboolean JNICALL Java_com_saiki_motion_render_NativeRenderer_init(JNIEnv* e, jobject, jobject surface, jobject assets) {
    gWin = ANativeWindow_fromSurface(e, surface);
    return saiki::vkInit(gWin, AAssetManager_fromJava(e, assets)) ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT void JNICALL Java_com_saiki_motion_render_NativeRenderer_resize(JNIEnv*, jobject, jint w, jint h) { saiki::vkResize(w, h); }
JNIEXPORT void JNICALL Java_com_saiki_motion_render_NativeRenderer_frame(JNIEnv*, jobject, jfloat t) { saiki::vkFrame(t); }
JNIEXPORT void JNICALL Java_com_saiki_motion_render_NativeRenderer_destroy(JNIEnv*, jobject) {
    saiki::vkDestroy(); if (gWin) { ANativeWindow_release(gWin); gWin = nullptr; }
}

JNIEXPORT jboolean JNICALL Java_com_saiki_motion_render_NativeRenderer_fxPrepare(JNIEnv* e, jobject, jstring key, jstring src, jstring name) {
    auto s = [&](jstring j) { const char* c = e->GetStringUTFChars(j, nullptr); std::string r = c; e->ReleaseStringUTFChars(j, c); return r; };
    return saiki::fxPrepare(s(key), s(src), s(name)) ? JNI_TRUE : JNI_FALSE;
}
JNIEXPORT jint JNICALL Java_com_saiki_motion_render_NativeRenderer_fxStatus(JNIEnv* e, jobject, jstring key) {
    const char* c = e->GetStringUTFChars(key, nullptr); int r = saiki::fxStatus(c); e->ReleaseStringUTFChars(key, c); return r;
}
JNIEXPORT jstring JNICALL Java_com_saiki_motion_render_NativeRenderer_fxError(JNIEnv* e, jobject, jstring key) {
    const char* c = e->GetStringUTFChars(key, nullptr); std::string r = saiki::fxError(c); e->ReleaseStringUTFChars(key, c); return e->NewStringUTF(r.c_str());
}
JNIEXPORT jint JNICALL Java_com_saiki_motion_render_NativeRenderer_fxReadyCount(JNIEnv*, jobject) { return saiki::fxReadyCount(); }
}
