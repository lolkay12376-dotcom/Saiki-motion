// jni_crash.cpp — Android twin of Sources/CCrashLog (the C module behind CrashLog.swift).
// Same contract: install once, as early as possible; all signal-context work in C (async-signal-safe
// write() only, no heap, no locks); a small ring buffer of `note` tags lands in the report.
#include <jni.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <cstdio>
#include <sys/stat.h>
#include <android/log.h>
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "saiki-crash", __VA_ARGS__)

namespace {
char gDir[512] = {0};
char gRing[8192] = {0};
volatile size_t gRingLen = 0;
volatile sig_atomic_t gInHandler = 0;

void ringAppend(const char* s, size_t n) {
    if (gRingLen + n + 1 >= sizeof(gRing)) return;
    memcpy(gRing + gRingLen, s, n);
    gRingLen += n;
    gRing[gRingLen++] = '\n';
}

void writeReport(const char* kind, int sig) {
    if (gInHandler) _exit(1);
    gInHandler = 1;
    char path[600];
    time_t t = time(nullptr);
    struct tm tmv;
    localtime_r(&t, &tmv);
    char stamp[32];
    strftime(stamp, sizeof(stamp), "%Y-%m-%d_%H-%M-%S", &tmv);
    snprintf(path, sizeof(path), "%s/%s_%s.log", gDir, stamp, kind);
    int fd = open(path, O_CREAT | O_WRONLY | O_TRUNC, 0644);
    if (fd >= 0) {
        char head[256];
        int hn = snprintf(head, sizeof(head), "CRASH %s (signal %d)\n==============================\n", kind, sig);
        write(fd, head, hn);
        write(fd, "\nWhat the app was doing (latest last):\n", 39);
        write(fd, gRing, gRingLen);
        write(fd, "\n", 1);
        close(fd);
    }
}

void handler(int sig, siginfo_t* info, void* ctx) {
    (void)info; (void)ctx;
    writeReport("signal", sig);
    // restore default and re-raise so the system still gets its tombstone
    struct sigaction d{};
    d.sa_handler = SIG_DFL;
    sigaction(sig, &d, nullptr);
    raise(sig);
}

void installHandler(int sig) {
    struct sigaction sa{};
    sa.sa_sigaction = handler;
    sa.sa_flags = SA_SIGINFO | SA_RESETHAND;
    sigemptyset(&sa.sa_mask);
    sigaction(sig, &sa, nullptr);
}
}

extern "C" {
JNIEXPORT void JNICALL Java_com_saiki_motion_core_CrashLog_installNative(JNIEnv* e, jobject, jstring jdir) {
    if (jdir) {
        const char* d = e->GetStringUTFChars(jdir, nullptr);
        strncpy(gDir, d, sizeof(gDir) - 1);
        e->ReleaseStringUTFChars(jdir, d);
    } else {
        gDir[0] = 0;
    }
    mkdir(gDir, 0755);
    installHandler(SIGSEGV);
    installHandler(SIGBUS);
    installHandler(SIGFPE);
    installHandler(SIGILL);
    installHandler(SIGABRT);
    LOG("installed, dir=%s", gDir);
}

JNIEXPORT void JNICALL Java_com_saiki_motion_core_CrashLog_noteNative(JNIEnv* e, jobject, jstring jtag) {
    const char* t = e->GetStringUTFChars(jtag, nullptr);
    ringAppend(t, strlen(t));
    e->ReleaseStringUTFChars(jtag, t);
}
}
