// JNI surface for MetalModelRenderer (core/NativeModel.kt). Slice 7m. Unbuilt/unverified.
// Handles are raw native pointers (jlong): Buf*, Tex*, DepthTex*, Target*; pipelines are the VkPipeline value.
// Records into saiki::currentCmd() (vkFrame / runSync); falls back to runSync when nothing is recording.
// 7o-b: RT (acc b36 / RtU b37): accelBuild/accelFree/rtSupported + modelPass(accel, rtu).
#include <jni.h>
#include <vector>
#include <cstring>
#include <android/log.h>
#include "vk_core.h"
using namespace saiki;

#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "saiki-model", __VA_ARGS__)

static DepthTex* gDummyDepth = nullptr;

static const jint UBO_FLOATS = 46 * 4;   // ModelU: 46 vec4 (model.vert / model.frag binding 32)
static const jint LB_FLOATS = 64 * 4;    // LBuf: 8 lights x 8 float4 (binding 33)

extern "C" {
#define NM(n) Java_com_saiki_motion_core_NativeModel_##n

JNIEXPORT jlong JNICALL NM(bufFloat)(JNIEnv* e, jobject, jfloatArray a) {
    jsize n = e->GetArrayLength(a); jfloat* p = e->GetFloatArrayElements(a, nullptr);
    Buf* b = new Buf(); bool ok = makeBufferData(p, (VkDeviceSize)n * 4, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, *b);
    e->ReleaseFloatArrayElements(a, p, JNI_ABORT);
    if (!ok) { delete b; return 0; } return (jlong)b;
}
// index buffer from Int indices; is16 -> uint16 (iOS: idx32 = !indexIs16)
JNIEXPORT jlong JNICALL NM(bufIdx)(JNIEnv* e, jobject, jintArray a, jboolean is16) {
    jsize n = e->GetArrayLength(a); jint* p = e->GetIntArrayElements(a, nullptr);
    std::vector<uint16_t> s; if (is16) { s.resize(n); for (jsize i = 0; i < n; i++) s[i] = (uint16_t)p[i]; }
    Buf* b = new Buf(); bool ok = makeBufferData(is16 ? (const void*)s.data() : (const void*)p, (VkDeviceSize)n * (is16 ? 2 : 4), VK_BUFFER_USAGE_INDEX_BUFFER_BIT, *b);
    e->ReleaseIntArrayElements(a, p, JNI_ABORT);
    if (!ok) { delete b; return 0; } return (jlong)b;
}
JNIEXPORT void JNICALL NM(bufFree)(JNIEnv*, jobject, jlong h) { if (!h) return; Buf* b = (Buf*)h; destroyBuf(*b); delete b; }

JNIEXPORT jlong JNICALL NM(texCreate)(JNIEnv* e, jobject, jint w, jint h, jbyteArray rgba) {
    jbyte* p = e->GetByteArrayElements(rgba, nullptr);
    Tex* t = new Tex(); bool ok = uploadTextureMips(w, h, (const uint8_t*)p, *t);
    e->ReleaseByteArrayElements(rgba, p, JNI_ABORT);
    if (!ok) { delete t; return 0; } return (jlong)t;
}
JNIEXPORT void JNICALL NM(texFree)(JNIEnv*, jobject, jlong h) { if (!h) return; Tex* t = (Tex*)h; destroyTex(*t); delete t; }

// plain RGBA8 texture without mips (== MetalPasses.makeTexture; volume atlas / dummy)
JNIEXPORT jlong JNICALL NM(texCreatePlain)(JNIEnv* e, jobject, jint w, jint h, jbyteArray rgba) {
    jbyte* p = e->GetByteArrayElements(rgba, nullptr);
    Tex* t = new Tex(); bool ok = uploadTexture(w, h, (const uint8_t*)p, *t);
    e->ReleaseByteArrayElements(rgba, p, JNI_ABORT);
    if (!ok) { delete t; return 0; } return (jlong)t;
}

// depth target of the model renderer: returns prev when it already has this size, else recreates (caller sets depthDirty on change)
JNIEXPORT jlong JNICALL NM(depthEnsure)(JNIEnv*, jobject, jlong prev, jint w, jint h) {
    DepthTex* d = (DepthTex*)prev;
    if (d && d->w == w && d->h == h) return prev;
    if (d) { destroyDepth(*d); delete d; }
    d = new DepthTex(); if (!makeDepth(*d, w, h)) { delete d; return 0; } return (jlong)d;
}
JNIEXPORT void JNICALL NM(depthFree)(JNIEnv*, jobject, jlong h) { if (!h) return; DepthTex* d = (DepthTex*)h; destroyDepth(*d); delete d; }

JNIEXPORT jlong JNICALL NM(targetCreate)(JNIEnv*, jobject, jint w, jint h, jboolean half) {
    Target* t = new Target(); if (!makeTarget(*t, w, h, half)) { delete t; return 0; } return (jlong)t;
}
// non-owning Tex* of a Target's colour image (sceneTex / source inputs); never pass it to texFree
JNIEXPORT jlong JNICALL NM(targetTex)(JNIEnv*, jobject, jlong h) { return h ? (jlong)&((Target*)h)->tex : 0; }
JNIEXPORT void JNICALL NM(targetFree)(JNIEnv*, jobject, jlong h) { if (!h) return; Target* t = (Target*)h; destroyTarget(*t); delete t; }

// MetalModelRenderer.pso(blend:format:rt:depthOnly:) + dsWrite/dsNoWrite (depthWrite) for the target's format
JNIEXPORT jlong JNICALL NM(pso)(JNIEnv* e, jobject, jstring frag, jlong target, jboolean blend, jboolean depthOnly, jboolean depthWrite, jboolean points, jboolean rtLayout) {
    Target* t = (Target*)target; if (!t) return 0;
    const char* f = e->GetStringUTFChars(frag, nullptr);
    VkPipeline p = modelPipeline(f, t->fmt, blend, depthOnly, depthWrite, points, "model.vert", false, rtLayout || strncmp(f, "model_rt", 8) == 0);   // RT frag implies the RT set layout
    e->ReleaseStringUTFChars(frag, f); return (jlong)p;
}

// == MTLDevice.supportsRaytracing (+ the ray-query extensions actually enabled on this device)
JNIEXPORT jboolean JNICALL NM(rtSupported)(JNIEnv*, jobject) { return rtEnabled() ? JNI_TRUE : JNI_FALSE; }
// == MetalModelRenderer.buildAccel: one AS over n primitives. vb/ib = Buf*, meta[2i] = idx32, meta[2i+1] = triangle count. Returns Accel* (0 = failed / no RT).
JNIEXPORT jlong JNICALL NM(accelBuild)(JNIEnv* e, jobject, jlongArray jvb, jlongArray jib, jintArray jmeta, jint n) {
    if (n <= 0 || !rtEnabled()) return 0;
    jlong* vb = e->GetLongArrayElements(jvb, nullptr); jlong* ib = e->GetLongArrayElements(jib, nullptr); jint* meta = e->GetIntArrayElements(jmeta, nullptr);
    std::vector<const Buf*> v((size_t)n), x((size_t)n); std::vector<int> i32((size_t)n), tr((size_t)n);
    for (int i = 0; i < n; i++) { v[i] = (const Buf*)vb[i]; x[i] = (const Buf*)ib[i]; i32[i] = meta[i * 2]; tr[i] = meta[i * 2 + 1]; }
    Accel* a = nullptr;
    auto body = [&](VkCommandBuffer c) { a = buildAccel(c, v.data(), x.data(), i32.data(), tr.data(), n); };
    if (VkCommandBuffer c = currentCmd()) body(c); else runSync(body);
    e->ReleaseLongArrayElements(jvb, vb, JNI_ABORT); e->ReleaseLongArrayElements(jib, ib, JNI_ABORT); e->ReleaseIntArrayElements(jmeta, meta, JNI_ABORT);
    return (jlong)a;
}
JNIEXPORT void JNICALL NM(accelFree)(JNIEnv*, jobject, jlong h) { if (h) retireAccel((Accel*)h); }

// One model pass. Per draw i (n draws, instances already expanded by the caller):
//   pso[i], vb[i], ib[i], meta[3i]=idx32, meta[3i+1]=indexCount, meta[3i+2]=collider depth bias (MetalModel.swift:1401), ubo[i*184..] = ModelU, tex[4i..4i+3] = base/mr/emissive/occlusion (Tex*), clamp[4i..] (per-material sampler), own[i] = embedded normal map (Tex* or 0)
// accel = Accel* or 0; rtu = RtU (20 floats: rtp vec4 + rinv mat4) bound at b37 with the AS at b36 for every draw (RT set layout) when accel != 0.
// shared (Tex*): sh[0]=sceneTex, sh[1]=env, sh[2..15]=splat x14, sh[16..20]=pbr normal/rough/metal/height/opacity; depthSrc = DepthTex* or 0 (dummy depth); lights = 256 floats.
JNIEXPORT jboolean JNICALL NM(modelPass)(JNIEnv* e, jobject, jlong target, jlong depth, jboolean clearDepth, jint n,
        jlongArray jpso, jlongArray jvb, jlongArray jib, jintArray jmeta, jfloatArray jubo, jlongArray jtex, jbooleanArray jclamp, jlongArray jown,
        jlongArray jsh, jlong depthSrc, jfloatArray jlights, jfloatArray junder, jlong accel, jfloatArray jrtu) {
    Target* t = (Target*)target; DepthTex* d = (DepthTex*)depth; if (!t || !d) return JNI_FALSE;
    if (!gDummyDepth) { gDummyDepth = new DepthTex(); if (!makeDepth(*gDummyDepth, 1, 1)) { delete gDummyDepth; gDummyDepth = nullptr; return JNI_FALSE; } }
    Accel* ac = (Accel*)accel; if (ac && !rtEnabled()) ac = nullptr;
    const Layout* L = layoutForShader(ac ? "model_rt" : "model.vert"); if (!L) return JNI_FALSE;
    static std::vector<float> rtKeep; if (ac) { jfloat* r = e->GetFloatArrayElements(jrtu, nullptr); rtKeep.assign(r, r + 20); e->ReleaseFloatArrayElements(jrtu, r, JNI_ABORT); }
    jlong* pso = e->GetLongArrayElements(jpso, nullptr); jlong* vb = e->GetLongArrayElements(jvb, nullptr); jlong* ib = e->GetLongArrayElements(jib, nullptr);
    jint* meta = e->GetIntArrayElements(jmeta, nullptr); jfloat* ubo = e->GetFloatArrayElements(jubo, nullptr); jlong* tex = e->GetLongArrayElements(jtex, nullptr);
    jboolean* cl = e->GetBooleanArrayElements(jclamp, nullptr); jlong* own = e->GetLongArrayElements(jown, nullptr);
    jlong* sh = e->GetLongArrayElements(jsh, nullptr); jfloat* lights = e->GetFloatArrayElements(jlights, nullptr);
    auto view = [](jlong h) { return h ? ((Tex*)h)->view : dummyView(); };
    VkSampler smC = sampler(Samp::Aniso4MipClamp), smR = sampler(Samp::Aniso4MipRepeat);   // MetalModel.swift:1098-1106: linear + mip linear + aniso4, clamp/repeat per material
    // Per-frame scratch: one flat Bind arena, per-draw offset (no vector-of-vectors churn).
    // 48 binds/draw is the observed max (4 mat + depth + scene/env + 14 splat + 5 pbr + height + UBOs + RT);
    // the guard below fails the pass loudly instead of overflowing if a future layout grows.
    constexpr int kMaxBindsPerDraw = 56;
    std::vector<Bind> arena((size_t)n * kMaxBindsPerDraw);
    std::vector<ModelDraw> draws((size_t)n);
    for (int i = 0; i < n; i++) {
        Bind* B = arena.data() + (size_t)i * kMaxBindsPerDraw; int nb = 0;
        auto img = [&](uint32_t b, uint32_t idx, VkImageView v, VkSampler s = VK_NULL_HANDLE, VkImageLayout lay = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL) {
            if (nb >= kMaxBindsPerDraw) { LOG("modelPass: bind overflow at b=%u", b); return; }   // guard BEFORE the write
            Bind x; x.binding = b; x.index = idx; x.view = v; x.sampler = s; x.layout = lay; B[nb++] = x;
        };
        for (int k = 0; k < 4; k++) img(k, 0, view(tex[i * 4 + k]), cl[i * 4 + k] ? smC : smR);
        img(4, 0, depthSrc ? ((DepthTex*)depthSrc)->tex.view : gDummyDepth->tex.view, VK_NULL_HANDLE, VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL);
        img(5, 0, view(sh[0])); img(6, 0, view(sh[1]));
        for (int k = 0; k < 4; k++) { img(7, k, view(sh[2 + k])); img(11, k, view(sh[6 + k])); img(15, k, view(sh[10 + k])); }
        img(19, 0, view(sh[14])); img(20, 0, view(sh[15]));
        for (int k = 0; k < 5; k++) img(21 + k, 0, (k == 0 && own[i]) ? view(own[i]) : view(sh[16 + k]));
        img(26, 0, view(sh[19]));   // vertex-stage height map (same image as tPH2)
        Bind u; u.binding = 32; u.data = ubo + (size_t)i * UBO_FLOATS; u.size = UBO_FLOATS * 4; if (nb < kMaxBindsPerDraw) B[nb++] = u;
        Bind lb; lb.binding = 33; lb.data = lights; lb.size = LB_FLOATS * 4; if (nb < kMaxBindsPerDraw) B[nb++] = lb;
        Bind v; v.binding = 34; v.buffer = ((Buf*)vb[i])->buf; v.size = (uint32_t)((Buf*)vb[i])->size; if (nb < kMaxBindsPerDraw) B[nb++] = v;
        if (ac) { Bind a; a.binding = 36; a.accel = ac->as; if (nb < kMaxBindsPerDraw) B[nb++] = a; Bind r; r.binding = 37; r.data = rtKeep.data(); r.size = 80; if (nb < kMaxBindsPerDraw) B[nb++] = r; }
        ModelDraw& m = draws[i]; m.pso = (VkPipeline)pso[i]; m.layout = L; m.nBinds = nb;
        m.ib = ib[i] ? ((Buf*)ib[i])->buf : VK_NULL_HANDLE; m.idx32 = meta[i * 3] != 0; m.indexCount = (uint32_t)meta[i * 3 + 1]; m.instances = 1;
        m.bias = meta[i * 3 + 2] != 0;   // collider depth-only draw: depth bias 4/4/0 (MetalModel.swift:1401)
    }
    for (int i = 0; i < n; i++) draws[i].binds = arena.data() + (size_t)i * kMaxBindsPerDraw;
    // camera below the water surface: full-screen waterUnder pass first (colour LOAD, depth test ALWAYS, no write); under = ModelU (184 floats) + inverse VP (16)
    std::vector<Bind> ub;
    if (junder && e->GetArrayLength(junder) >= UBO_FLOATS + 16) {
        jfloat* un = e->GetFloatArrayElements(junder, nullptr);
        static std::vector<float> keep; keep.assign(un, un + UBO_FLOATS + 16); e->ReleaseFloatArrayElements(junder, un, JNI_ABORT);
        const Layout* UL = layoutForShader("waterUnder.vert");
        VkPipeline up = UL ? modelPipeline("waterUnder.frag", t->fmt, false, false, false, false, "waterUnder.vert", true) : VK_NULL_HANDLE;
        if (up) {
            auto img = [&](uint32_t b, VkImageView v, VkImageLayout lay) { Bind x; x.binding = b; x.view = v; x.layout = lay; ub.push_back(x); };
            img(4, depthSrc ? ((DepthTex*)depthSrc)->tex.view : gDummyDepth->tex.view, VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL);
            img(5, view(sh[0]), VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL);
            Bind u; u.binding = 32; u.data = keep.data(); u.size = UBO_FLOATS * 4; ub.push_back(u);
            Bind iv; iv.binding = 39; iv.data = keep.data() + UBO_FLOATS; iv.size = 64; ub.push_back(iv);
            ModelDraw m; m.pso = up; m.layout = UL; m.binds = ub.data(); m.nBinds = (int)ub.size(); m.vertexCount = 3;
            draws.insert(draws.begin(), m);
        }
    }
    bool ok = false;
    auto body = [&](VkCommandBuffer c) { ok = encodeModelPass(c, *t, *d, clearDepth, draws.data(), (int)draws.size()); };
    if (VkCommandBuffer c = currentCmd()) body(c); else runSync(body);
    e->ReleaseLongArrayElements(jpso, pso, JNI_ABORT); e->ReleaseLongArrayElements(jvb, vb, JNI_ABORT); e->ReleaseLongArrayElements(jib, ib, JNI_ABORT);
    e->ReleaseIntArrayElements(jmeta, meta, JNI_ABORT); e->ReleaseFloatArrayElements(jubo, ubo, JNI_ABORT); e->ReleaseLongArrayElements(jtex, tex, JNI_ABORT);
    e->ReleaseBooleanArrayElements(jclamp, cl, JNI_ABORT); e->ReleaseLongArrayElements(jown, own, JNI_ABORT);
    e->ReleaseLongArrayElements(jsh, sh, JNI_ABORT); e->ReleaseFloatArrayElements(jlights, lights, JNI_ABORT);
    return ok ? JNI_TRUE : JNI_FALSE;
}

// == MetalVolumeRenderer.draw GPU part. ubo = VolU (23 float4 = 92 floats, binding 8). tex = atlas (b0), depth = DepthTex* or 0 -> dummy (b1), env (b2), scene (b3): Tex*.
// sc = {x, y, w, h} scissor (top-left origin) or empty. accumulate: colour LOADed + over blend (pipelineOver + encodeLoad); else cleared (encode).
JNIEXPORT jboolean JNICALL NM(volumePass)(JNIEnv* e, jobject, jlong target, jboolean accumulate, jfloatArray jubo, jlong tex, jlong depth, jlong env, jlong scene, jintArray jsc) {
    Target* t = (Target*)target; if (!t || !tex || !env || !scene) return JNI_FALSE;
    if (!gDummyDepth) { gDummyDepth = new DepthTex(); if (!makeDepth(*gDummyDepth, 1, 1)) { delete gDummyDepth; gDummyDepth = nullptr; return JNI_FALSE; } }
    const Layout* L = layoutForShader("vdb.frag"); VkPipeline p = L ? pipelineForFile("fs.vert", "vdb.frag", t->fmt, accumulate) : VK_NULL_HANDLE; if (!p) return JNI_FALSE;
    jfloat* u = e->GetFloatArrayElements(jubo, nullptr);
    Bind b[5]; b[0].binding = 0; b[0].view = ((Tex*)tex)->view;
    b[1].binding = 1; b[1].view = depth ? ((DepthTex*)depth)->tex.view : gDummyDepth->tex.view; b[1].layout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
    b[2].binding = 2; b[2].view = ((Tex*)env)->view; b[3].binding = 3; b[3].view = ((Tex*)scene)->view;
    b[4].binding = 8; b[4].data = u; b[4].size = 92 * 4;
    VkRect2D sc{}; bool hasSc = jsc && e->GetArrayLength(jsc) >= 4;
    if (hasSc) { jint* s = e->GetIntArrayElements(jsc, nullptr); sc.offset = {s[0], s[1]}; sc.extent = {(uint32_t)s[2], (uint32_t)s[3]}; e->ReleaseIntArrayElements(jsc, s, JNI_ABORT); }
    bool ok = false;
    auto body = [&](VkCommandBuffer c) { ok = encodeFx(c, *t, p, L, accumulate, b, 5, 3, 1, hasSc ? &sc : nullptr); };
    if (VkCommandBuffer c = currentCmd()) body(c); else runSync(body);
    e->ReleaseFloatArrayElements(jubo, u, JNI_ABORT);
    return ok ? JNI_TRUE : JNI_FALSE;
}

// depth snapshot (water): copy src -> dst (same size). Records into the current command buffer, outside any render pass.
JNIEXPORT jboolean JNICALL NM(depthCopy)(JNIEnv*, jobject, jlong src, jlong dst) {
    DepthTex* a = (DepthTex*)src; DepthTex* b = (DepthTex*)dst; if (!a || !b || a->w != b->w || a->h != b->h) return JNI_FALSE;
    auto body = [&](VkCommandBuffer c) { copyDepth(c, *a, *b); };
    if (VkCommandBuffer c = currentCmd()) body(c); else runSync(body);
    return JNI_TRUE;
}

// == MetalModelRenderer.occludePlane GPU part. ubo = PlOccU: inv(16) vp(16) p0(4) n(4) flags(4) = 44 floats.
// 1) planeOcc colour pass src -> dst (cut by nearer model pixels); 2) planeDepth pass writes the plane's own depth into the model depth.
JNIEXPORT jboolean JNICALL NM(planeOcclude)(JNIEnv* e, jobject, jlong src, jlong dst, jlong depth, jboolean clearDepth, jfloatArray jubo) {
    Target* s = (Target*)src; Target* d = (Target*)dst; DepthTex* dp = (DepthTex*)depth;
    if (!s || !d || !dp || s == d || s->width != d->width || s->height != d->height || dp->w != s->width || dp->h != s->height) return JNI_FALSE;
    const Layout* L1 = layoutForShader("planeOcc.frag"); const Layout* L2 = layoutForShader("planeDepth.frag"); if (!L1 || !L2) return JNI_FALSE;
    PipeDesc pd; pd.vert = "waterUnder.vert"; pd.frag = "planeOcc.frag"; pd.layout = L1; pd.fmt = d->fmt;
    VkPipeline p1 = pipelineForDesc(pd); if (!p1) return JNI_FALSE;
    jfloat* u = e->GetFloatArrayElements(jubo, nullptr);
    Bind b1[3]; b1[0].binding = 0; b1[0].view = s->tex.view; b1[1].binding = 4; b1[1].view = dp->tex.view; b1[1].layout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
    b1[2].binding = 32; b1[2].data = u; b1[2].size = 44 * 4;
    Bind b2[2]; b2[0].binding = 0; b2[0].view = d->tex.view; b2[1].binding = 32; b2[1].data = u; b2[1].size = 44 * 4;
    bool ok = false;
    auto body = [&](VkCommandBuffer c) { ok = encodeFx(c, *d, p1, L1, false, b1, 3, 3, 1) && encodePlaneDepth(c, *dp, clearDepth, L2, b2, 2); };
    if (VkCommandBuffer c = currentCmd()) body(c); else runSync(body);
    e->ReleaseFloatArrayElements(jubo, u, JNI_ABORT);
    return ok ? JNI_TRUE : JNI_FALSE;
}
}
