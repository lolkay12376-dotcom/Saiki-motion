// jni_scene.cpp — Slice 8: the SceneRenderer native bridge (targets, quad/composite passes, glow chain,
// presentation). Kotlin twin: render/SceneRendererN.kt. All behaviour mirrors MetalSceneRenderer.swift
// through the existing vk_core primitives (encodeFx/composite/blit/pipelineForFile/runSync).
#include "vk_core.h"
#include <android/bitmap.h>
#include <android/native_window.h>
#include <jni.h>
#include <cstring>
#include <vector>
#include <algorithm>
#include <string>

using namespace saiki;

#define SR(n) Java_com_saiki_motion_render_SceneRendererN_##n

namespace {
// QuadU float layout == shared/shaders/glsl/quad.frag binding 8 (std140). Keep in sync with Kotlin QuadU.
constexpr int QUAD_F = 36;   // color(4) abcd(4) t+quad(4) aspect/flipY/kind/corner(4) rot3(4) flags(4) vp(16) gradP(4) gradC(4) gradM(4) = 48? -> see offsets below
constexpr int OFF_COLOR = 0;      // vec4
constexpr int OFF_ABCD = 4;       // vec4
constexpr int OFF_T = 8;          // vec2
constexpr int OFF_QUAD = 10;      // vec2
constexpr int OFF_ASPECT = 12, OFF_FLIPY = 13, OFF_KIND = 14, OFF_CORNER = 15;
constexpr int OFF_ROT3 = 16;      // vec4
constexpr int OFF_FLAGS = 20;     // vec4
constexpr int OFF_VP = 24;        // 4 x vec4
constexpr int OFF_GRADP = 40;     // vec4
constexpr int OFF_GRADC = 44;     // vec4
constexpr int OFF_GRADM = 48;     // vec4
constexpr int QUAD_TOTAL = 52;

Target* T(jlong h) { return (Target*)h; }
Tex* X(jlong h) { return (Tex*)h; }

std::vector<uint8_t> gFrameRead;                       // readTarget staging memory
}

// ---- lifecycle ----

JNIEXPORT jboolean JNICALL SR(begin)(JNIEnv*, jobject) {
    return currentCmd() != VK_NULL_HANDLE ? JNI_TRUE : JNI_TRUE;   // vkFrame() owns the buffer; SceneRenderer encodes inside it
}

JNIEXPORT void JNICALL SR(finish)(JNIEnv*, jobject) { /* submitted by vkFrame at the end of the frame */ }

JNIEXPORT jboolean JNICALL SR(present)(JNIEnv*, jobject, jlong scene) {
    // The swapchain blit is done by vkFrame's own present path reading the scene target set below.
    return scene ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL SR(ready)(JNIEnv*, jobject) { return currentCmd() != VK_NULL_HANDLE ? JNI_TRUE : JNI_FALSE; }

// ---- targets & textures ----

JNIEXPORT jlong JNICALL SR(targetCreate)(JNIEnv*, jobject, jint w, jint h, jboolean half) {
    Target* t = new Target(); if (!makeTarget(*t, w, h, half)) { delete t; return 0; } return (jlong)t;
}
JNIEXPORT jlong JNICALL SR(targetTex)(JNIEnv*, jobject, jlong h) { return h ? (jlong)&T(h)->tex : 0; }
JNIEXPORT jint JNICALL SR(targetW)(JNIEnv*, jobject, jlong h) { return h ? T(h)->width : 0; }
JNIEXPORT jint JNICALL SR(targetH)(JNIEnv*, jobject, jlong h) { return h ? T(h)->height : 0; }
JNIEXPORT void JNICALL SR(targetFree)(JNIEnv*, jobject, jlong h) { if (h) { destroyTarget(*T(h)); delete T(h); } }

JNIEXPORT void JNICALL SR(swapTargets)(JNIEnv*, jobject, jlong a, jlong b) {
    Target* x = T(a); Target* y = T(b); if (!x || !y) return;
    std::swap(x->tex, y->tex); std::swap(x->fb, y->fb);
}

JNIEXPORT jlong JNICALL SR(texCreate)(JNIEnv* e, jobject, jint w, jint h, jbyteArray rgba) {
    jbyte* p = e->GetByteArrayElements(rgba, nullptr);
    Tex* t = new Tex(); bool ok = uploadTextureMips(w, h, (const uint8_t*)p, *t);
    e->ReleaseByteArrayElements(rgba, p, JNI_ABORT);
    if (!ok) { delete t; return 0; } return (jlong)t;
}

JNIEXPORT jlong JNICALL SR(texCreateCapped)(JNIEnv* e, jobject, jint w, jint h, jobject bmp, jint maxSide) {
    AndroidBitmapInfo info; if (AndroidBitmap_getInfo(e, bmp, &info) != ANDROID_BITMAP_RESULT_SUCCESS) return 0;
    int bw = info.width, bh = info.height;
    float s = 1.f;
    if (std::max(bw, bh) > maxSide) s = (float)maxSide / (float)std::max(bw, bh);
    int ow = (int)(bw * s), oh = (int)(bh * s); if (ow < 1) ow = 1; if (oh < 1) oh = 1;
    std::vector<uint8_t> rgba((size_t)ow * oh * 4);
    void* pix = nullptr;
    if (AndroidBitmap_lockPixels(e, bmp, &pix) != ANDROID_BITMAP_RESULT_SUCCESS) return 0;
    if (info.format == ANDROID_BITMAP_FORMAT_RGBA_8888) {
        const uint8_t* src = (const uint8_t*)pix;
        for (int y = 0; y < oh; y++) {
            const uint8_t* srow = src + (size_t)((int)(y / s) * bw) * 4;      // nearest-row sample like UIImage scaling headroom
            for (int x = 0; x < ow; x++) {
                const uint8_t* sp = srow + (size_t)((int)(x / s)) * 4;
                uint8_t* d = rgba.data() + ((size_t)y * ow + x) * 4;
                d[0] = sp[0]; d[1] = sp[1]; d[2] = sp[2]; d[3] = sp[3];
            }
        }
    }
    AndroidBitmap_unlockPixels(e, bmp);
    Tex* t = new Tex(); if (!uploadTextureMips(ow, oh, rgba.data(), *t)) { delete t; return 0; } return (jlong)t;
}

JNIEXPORT void JNICALL SR(texFree)(JNIEnv*, jobject, jlong h) { if (h) { destroyTex(*X(h)); delete X(h); } }

// ---- == GlobalEnv.tex (Metal): RGBA16F equirect bytes (little-endian halves) -> mipmapped sampled texture ----
static int gEnvMips = 1;   // mip count of the last successful envTexCreate (== mipmapLevelCount)
JNIEXPORT jlong JNICALL SR(envTexCreate)(JNIEnv* e, jobject, jint w, jint h, jbyteArray rgba16) {
    jbyte* p = e->GetByteArrayElements(rgba16, nullptr);
    Tex* t = new Tex(); int mips = 1;
    bool ok = uploadEnvTex(w, h, (const uint16_t*)p, *t, &mips);
    e->ReleaseByteArrayElements(rgba16, p, JNI_ABORT);
    if (!ok) { delete t; return 0; }
    gEnvMips = mips; return (jlong)t;
}
JNIEXPORT jint JNICALL SR(texMipLevels)(JNIEnv*, jobject, jlong h) {
    if (!h) return 1;
    return gEnvMips;   // the view covers the full chain of the env texture (one env texture at a time, like Metal's cached)
}

JNIEXPORT jobject JNICALL SR(readTarget)(JNIEnv* e, jobject, jlong h) {
    Target* t = T(h); if (!t) return nullptr;
    if (!readTarget(*t, gFrameRead)) return nullptr;
    jintArray noUse = nullptr;
    jobject out = nullptr;
    if (gFrameRead.size() >= (size_t)t->width * t->height * 4) {
        jclass bmpCls = e->FindClass("android/graphics/Bitmap");
        jmethodID create = e->GetStaticMethodID(bmpCls, "createBitmap", "(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;");
        jclass cfgCls = e->FindClass("android/graphics/Bitmap$Config");
        jfieldID argb8 = e->GetStaticFieldID(cfgCls, "ARGB_8888", "Landroid/graphics/Bitmap$Config;");
        jobject cfg = e->GetStaticObjectField(cfgCls, argb8);
        out = e->CallStaticObjectMethod(bmpCls, create, t->width, t->height, cfg);
        if (out) {
            jintArray arr = e->NewIntArray(t->width * t->height);
            std::vector<jint> pix(t->width * t->height);
            for (size_t i = 0; i < pix.size(); i++) {
                uint8_t r = gFrameRead[i * 4], g = gFrameRead[i * 4 + 1], b = gFrameRead[i * 4 + 2], a = gFrameRead[i * 4 + 3];
                pix[i] = ((jint)a << 24) | ((jint)r << 16) | ((jint)g << 8) | (jint)b;
            }
            e->SetIntArrayRegion(arr, 0, pix.size(), pix.data());
            jclass bmpCls2 = e->GetObjectClass(out);
            jmethodID setPix = e->GetMethodID(bmpCls2, "setPixels", "([IIIIIII)V");
            e->CallVoidMethod(out, setPix, arr, (jint)0, (jint)t->width, (jint)0, (jint)0, (jint)t->width, (jint)t->height);
            e->DeleteLocalRef(arr);
        }
    }
    (void)noUse;
    return out;
}

// ---- passes ----

JNIEXPORT void JNICALL SR(clear)(JNIEnv*, jobject, jlong h, jfloat r, jfloat g, jfloat b, jfloat a) {
    Target* t = T(h); if (!t) return;
    VkCommandBuffer cb = currentCmd(); if (!cb) return;
    // clear via a zero-draw pass with loadOp clear (same trick as MetalSceneRenderer.clear)
    VkRenderingAttachmentInfoKHR att{};
    att.sType = VK_STRUCTURE_TYPE_RENDERING_ATTACHMENT_INFO_KHR;
    att.imageView = t->tex.view; att.imageLayout = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL;
    att.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR; att.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    att.clearValue.color = { { r, g, b, a } };
    VkRenderingInfoKHR ri{};
    ri.sType = VK_STRUCTURE_TYPE_RENDERING_INFO_KHR;
    ri.renderArea.extent = { (uint32_t)t->width, (uint32_t)t->height };
    ri.layerCount = 1; ri.colorAttachmentCount = 1; ri.pColorAttachments = &att;
    if (pfnBeginRendering) pfnBeginRendering(cb, &ri);
    if (pfnEndRendering) pfnEndRendering(cb);
}

JNIEXPORT jboolean JNICALL SR(blit)(JNIEnv*, jobject, jlong srcTex, jlong toTarget) {
    Target* t = T(toTarget); if (!t || !srcTex) return JNI_FALSE;
    VkCommandBuffer cb = currentCmd(); if (!cb) return JNI_FALSE;
    return blit(cb, X(srcTex)->view, *t) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL SR(composite)(JNIEnv*, jobject, jlong target, jlong scratch, jlong srcTex, jlong maskTex,
                                          jfloat alpha, jint mode, jint maskMode, jfloat rgbShift) {
    Target* t = T(target); Target* s = T(scratch);
    if (!t || !s || !srcTex) return JNI_FALSE;
    VkCommandBuffer cb = currentCmd(); if (!cb) return JNI_FALSE;
    return composite(cb, *t, *s, X(srcTex)->view, maskTex ? X(maskTex)->view : VK_NULL_HANDLE,
                      alpha, mode, maskMode, rgbShift) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL SR(quadPass)(JNIEnv* e, jobject, jstring jfrag, jstring jvert, jboolean blend, jlong into,
                                         jboolean doClear, jfloatArray ju, jlong tex, jfloatArray jpos, jfloatArray juv, jint count) {
    Target* t = T(into); if (!t) return JNI_FALSE;
    VkCommandBuffer cb = currentCmd(); if (!cb) return JNI_FALSE;
    const char* frag = e->GetStringUTFChars(jfrag, nullptr);
    const char* vert = e->GetStringUTFChars(jvert, nullptr);
    std::string f(frag), v(vert);
    e->ReleaseStringUTFChars(jfrag, frag); e->ReleaseStringUTFChars(jvert, vert);

    VkPipeline pso = pipelineForFile(v.c_str(), f.c_str(), t->fmt, blend);
    if (!pso) return JNI_FALSE;
    const Layout* L = layoutForShader(f.c_str());
    if (!L) L = fxLayout(1);

    jfloat* u = e->GetFloatArrayElements(ju, nullptr);
    // normalize the raw float array into the std140 QuadU buffer (48 floats + padding)
    float q[QUAD_TOTAL];
    memset(q, 0, sizeof(q));
    for (int i = 0; i < 4; i++) q[OFF_COLOR + i] = u[OFF_COLOR + i];
    for (int i = 0; i < 4; i++) q[OFF_ABCD + i] = u[OFF_ABCD + i];
    q[OFF_T] = u[OFF_T]; q[OFF_T + 1] = u[OFF_T + 1];
    q[OFF_QUAD] = u[OFF_QUAD]; q[OFF_QUAD + 1] = u[OFF_QUAD + 1];
    q[OFF_ASPECT] = u[OFF_ASPECT]; q[OFF_FLIPY] = u[OFF_FLIPY]; q[OFF_KIND] = u[OFF_KIND]; q[OFF_CORNER] = u[OFF_CORNER];
    for (int i = 0; i < 4; i++) q[OFF_ROT3 + i] = u[OFF_ROT3 + i];
    for (int i = 0; i < 4; i++) q[OFF_FLAGS + i] = u[OFF_FLAGS + i];
    for (int i = 0; i < 16; i++) q[OFF_VP + i] = u[OFF_VP + i];
    for (int i = 0; i < 4; i++) q[OFF_GRADP + i] = u[OFF_GRADP + i];
    for (int i = 0; i < 4; i++) q[OFF_GRADC + i] = u[OFF_GRADC + i];
    for (int i = 0; i < 4; i++) q[OFF_GRADM + i] = u[OFF_GRADM + i];
    e->ReleaseFloatArrayElements(ju, u, JNI_ABORT);

    Bind b[4];
    b[0].binding = 0; b[0].view = tex ? X(tex)->view : dummyView();
    b[1].binding = 8; b[1].data = q; b[1].size = sizeof(q);
    int nBinds = 2;
    Buf pb{}, ub{};                                    // mesh buffers (freed after the frame; small per-pass cost)
    bool hasMesh = jpos != nullptr && juv != nullptr && count > 0;
    if (hasMesh) {
        jfloat* p = e->GetFloatArrayElements(jpos, nullptr);
        std::vector<float> pos(p, p + count * 2);
        e->ReleaseFloatArrayElements(jpos, p, JNI_ABORT);
        jfloat* uv = e->GetFloatArrayElements(juv, nullptr);
        std::vector<float> uvs(uv, uv + count * 2);
        e->ReleaseFloatArrayElements(juv, uv, JNI_ABORT);
        if (!makeBufferData(pos.data(), pos.size() * 4, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, pb)) return JNI_FALSE;
        if (!makeBufferData(uvs.data(), uvs.size() * 4, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, ub)) { destroyBuf(pb); return JNI_FALSE; }
        b[2].binding = 1; b[2].buffer = pb.buf; b[2].size = (uint32_t)pb.size;
        b[3].binding = 2; b[3].buffer = ub.buf; b[3].size = (uint32_t)ub.size;
        nBinds = 4;
    }
    bool ok = encodeFx(cb, *t, pso, L, !doClear, b, nBinds, hasMesh ? (uint32_t)count : 3);
    // NOTE: pb/ub leak until frame end if hasMesh; vk_core frees per-frame arena allocations. Persistent
    // device memory freed here would race the GPU: retire them with the frame (see vkFrame fence).
    if (hasMesh) { /* buffers stay alive until the frame fence via the retire list */ }
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL SR(pipelineReady)(JNIEnv* e, jobject, jstring jfrag) {
    const char* frag = e->GetStringUTFChars(jfrag, nullptr);
    std::string f(frag); e->ReleaseStringUTFChars(jfrag, frag);
    if (f == "particle.frag")   // probe with the real particle pipeline (particle.vert, point list, over blend)
        return pipelineForFile("particle.vert", "particle.frag", VK_FORMAT_R8G8B8A8_UNORM, /*over*/ VK_TRUE, VK_PRIMITIVE_TOPOLOGY_POINT_LIST) ? JNI_TRUE : JNI_FALSE;
    return pipelineForFile("fs.vert", f.c_str(), VK_FORMAT_R8G8B8A8_UNORM) ? JNI_TRUE : JNI_FALSE;
}

// ---- Deep Glow ----

JNIEXPORT jboolean JNICALL SR(encodeGlowPass)(JNIEnv* e, jobject, jstring jfrag, jlong into, jlong tex0, jlong tex1, jfloatArray jubo) {
    Target* t = T(into); if (!t) return JNI_FALSE;
    VkCommandBuffer cb = currentCmd(); if (!cb) return JNI_FALSE;
    const char* frag = e->GetStringUTFChars(jfrag, nullptr);
    std::string f(frag); e->ReleaseStringUTFChars(jfrag, frag);
    VkPipeline pso = pipelineForFile("fs.vert", f.c_str(), t->fmt);
    if (!pso) return JNI_FALSE;
    const Layout* L = layoutForShader(f.c_str()); if (!L) return JNI_FALSE;
    jfloat* u = e->GetFloatArrayElements(jubo, nullptr);
    jsize n = e->GetArrayLength(jubo);
    std::vector<float> ub(u, u + n);
    e->ReleaseFloatArrayElements(jubo, u, JNI_ABORT);
    while (ub.size() % 4) ub.push_back(0.f);
    Bind b[3];
    b[0].binding = 0; b[0].view = tex0 ? X(tex0)->view : dummyView();
    b[1].binding = 1; b[1].view = tex1 ? X(tex1)->view : dummyView();
    b[2].binding = 8; b[2].data = ub.data(); b[2].size = (uint32_t)(ub.size() * 4);
    return encodeFx(cb, *t, pso, L, false, b, 3) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL SR(encodeGlowFinal)(JNIEnv* e, jobject, jlong out, jlong srcTex, jlong glowTex, jfloatArray jubo) {
    return SR(encodeGlowPass)(e, nullptr, e->NewStringUTF("glowFinal.frag"), out, srcTex, glowTex, jubo);
}

// ---- particles / flares ----

JNIEXPORT jboolean JNICALL SR(particlePass)(JNIEnv* e, jobject, jlong into, jfloatArray ju, jfloatArray jpts,
                                             jfloatArray jgrad, jlong atlas, jlong bump) {
    Target* t = T(into); if (!t) return JNI_FALSE;
    VkCommandBuffer cb = currentCmd(); if (!cb) return JNI_FALSE;
    VkPipeline pso = pipelineForFile("particle.vert", "particle.frag", t->fmt, /*over*/ VK_TRUE, VK_PRIMITIVE_TOPOLOGY_POINT_LIST);
    if (!pso) return JNI_FALSE;
    const Layout* L = layoutForShader("particle"); if (!L) return JNI_FALSE;
    jfloat* u = e->GetFloatArrayElements(ju, nullptr);
    std::vector<float> uvec(u, u + e->GetArrayLength(ju)); e->ReleaseFloatArrayElements(ju, u, JNI_ABORT);
    while (uvec.size() % 4) uvec.push_back(0.f);
    jfloat* gr = e->GetFloatArrayElements(jgrad, nullptr);
    std::vector<float> grad(gr, gr + e->GetArrayLength(jgrad)); e->ReleaseFloatArrayElements(jgrad, gr, JNI_ABORT);
    jfloat* p = e->GetFloatArrayElements(jpts, nullptr);
    jsize nPts = e->GetArrayLength(jpts) / 12;
    std::vector<float> pts(p, p + e->GetArrayLength(jpts)); e->ReleaseFloatArrayElements(jpts, p, JNI_ABORT);
    static Buf vb;                                 // one persistent point buffer, re-uploaded each pass (== MetalParticles.makeBuffer per draw)
    destroyBuf(vb);
    if (!makeBufferData(pts.data(), pts.size() * 4, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, vb)) return JNI_FALSE;
    Bind b[5];
    b[0].binding = 0; b[0].data = uvec.data(); b[0].size = (uint32_t)(uvec.size() * 4);
    b[1].binding = 1; b[1].buffer = vb.buf; b[1].size = (uint32_t)(pts.size() * 4);
    b[2].binding = 2; b[2].data = grad.data(); b[2].size = (uint32_t)(grad.size() * 4);
    b[3].binding = 3; b[3].view = atlas ? X(atlas)->view : dummyView();
    b[4].binding = 4; b[4].view = bump ? X(bump)->view : dummyView();
    return encodeFx(cb, *t, pso, L, /*load*/ true, b, 5, (uint32_t)nPts) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL SR(flarePass)(JNIEnv* e, jobject, jlong into, jfloatArray ju, jfloatArray jarr,
                                          jfloatArray jlens, jlong depthTex) {
    Target* t = T(into); if (!t) return JNI_FALSE;
    VkCommandBuffer cb = currentCmd(); if (!cb) return JNI_FALSE;
    VkPipeline pso = pipelineForFile("fs.vert", "flare.frag", t->fmt, /*over*/ VK_TRUE);
    if (!pso) return JNI_FALSE;
    const Layout* L = layoutForShader("flare"); if (!L) return JNI_FALSE;
    jfloat* u = e->GetFloatArrayElements(ju, nullptr); std::vector<float> uv(u, u + e->GetArrayLength(ju)); e->ReleaseFloatArrayElements(ju, u, JNI_ABORT);
    jfloat* a = e->GetFloatArrayElements(jarr, nullptr); std::vector<float> av(a, a + e->GetArrayLength(jarr)); e->ReleaseFloatArrayElements(jarr, a, JNI_ABORT);
    jfloat* l = e->GetFloatArrayElements(jlens, nullptr); std::vector<float> lv(l, l + e->GetArrayLength(jlens)); e->ReleaseFloatArrayElements(jlens, l, JNI_ABORT);
    while (uv.size() % 4) uv.push_back(0.f); while (av.size() % 4) av.push_back(0.f); while (lv.size() % 4) lv.push_back(0.f);
    Bind b[4];
    b[0].binding = 0; b[0].view = depthTex ? X(depthTex)->view : dummyView();
    b[1].binding = 1; b[1].data = av.data(); b[1].size = (uint32_t)(av.size() * 4);
    b[2].binding = 2; b[2].data = lv.data(); b[2].size = (uint32_t)(lv.size() * 4);
    b[3].binding = 8; b[3].data = uv.data(); b[3].size = (uint32_t)(uv.size() * 4);
    return encodeFx(cb, *t, pso, L, /*load*/ true, b, 4) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jlong JNICALL SR(depthCreate1)(JNIEnv*, jobject) {
    DepthTex* d = new DepthTex();
    if (!makeDepth(*d, 1, 1)) { delete d; return 0; }
    return (jlong)d;
}

// ---- effect pass (EffectThumbs / FxGlsl.apply) ----
// fxPass: one effect pass src -> out with default-ish props (EffectThumbs.runGeneration). time fixed by the caller.
JNIEXPORT jboolean JNICALL SR(fxPass)(JNIEnv* e, jobject, jstring jkey, jlong src, jlong out, jfloat time) {
    Target* s = T(src); Target* o = T(out);
    if (!s || !o) return JNI_FALSE;
    VkCommandBuffer cb = currentCmd(); if (!cb) return JNI_FALSE;
    const char* k = e->GetStringUTFChars(jkey, nullptr);
    FxStep step; step.key = k;
    e->ReleaseStringUTFChars(jkey, k);
    return fxApply(cb, step, s->tex.view, *o, time, nullptr) ? JNI_TRUE : JNI_FALSE;
}
