// vk_core.cpp — Stage-0 Vulkan core (Android twin of iOS MetalCore/MetalPasses). UNVERIFIED: written without an
// NDK on hand; first job of the next session is to build it and fix compile errors (see docs/HANDOFF.md).
//
// Parity rules baked in:
//  * Fullscreen passes use a NEGATIVE-HEIGHT viewport so NDC is y-up like Metal => GLSL twins keep Metal's math.
//  * Swapchain is B8G8R8A8_UNORM (== iOS .bgra8Unorm, no sRGB conversion). Offscreen targets: R16G16B16A16_SFLOAT.
//  * Sampler == MSL `linearClamp` (linear, clamp_to_edge, normalized coords).
#include "vk_core.h"
#include <vulkan/vulkan.h>
#include <android/log.h>
#include <vector>
#include <cstring>
#include <cstdint>
#include <map>
#include <string>
#include <algorithm>
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "saiki", __VA_ARGS__)
#define VKC(x) do { VkResult r_ = (x); if (r_ != VK_SUCCESS) { LOG("VK error %d at %s:%d", (int)r_, __FILE__, __LINE__); return false; } } while (0)

namespace saiki {

// VK_KHR_dynamic_rendering (Android loader: resolve at runtime, not link-time)
PFN_vkCmdBeginRenderingKHR_ pfnBeginRendering = nullptr;
PFN_vkCmdEndRenderingKHR_ pfnEndRendering = nullptr;
void shutdownLayouts();
namespace {
constexpr int kFrames = 2;

struct G {
    AAssetManager* am = nullptr; ANativeWindow* win = nullptr;
    VkInstance inst = VK_NULL_HANDLE; VkSurfaceKHR surf = VK_NULL_HANDLE;
    VkPhysicalDevice pd = VK_NULL_HANDLE; VkDevice dev = VK_NULL_HANDLE;
    uint32_t qf = 0; VkQueue q = VK_NULL_HANDLE;
    VkSwapchainKHR sc = VK_NULL_HANDLE; VkFormat scFmt = VK_FORMAT_B8G8R8A8_UNORM; VkExtent2D ext{};
    std::vector<VkImage> scImgs; std::vector<VkImageView> scViews; std::vector<VkFramebuffer> fbs; std::vector<VkSemaphore> renderDone;
    VkRenderPass rp = VK_NULL_HANDLE;
    VkCommandPool pool = VK_NULL_HANDLE; VkCommandBuffer cmd[kFrames]{};
    VkSemaphore imgAvail[kFrames]{}; VkFence inFlight[kFrames]{}; int cur = 0;
    VkSampler linearClamp = VK_NULL_HANDLE;
    VkDescriptorSetLayout dsl = VK_NULL_HANDLE; VkPipelineLayout pl = VK_NULL_HANDLE;
    VkDescriptorPool dpool = VK_NULL_HANDLE; VkDescriptorSet blitSet = VK_NULL_HANDLE;
    VkPipeline blitPipe = VK_NULL_HANDLE; Tex testTex; Target smoke; bool rt = false; char devName[256] = {};
    VkSampler samp[9]{}; bool aniso = false, arrDyn = false;   // generic sampler cache (Samp enum incl. aniso4 material samplers), enabled device features
    bool rtOn = false; VkDeviceSize asAlign = 256;              // ray query actually enabled at device creation / min scratch alignment
    bool ready = false, needSc = false;
} g;

// ray-query entry points (KHR extension functions are not exported by libvulkan: loaded with vkGetDeviceProcAddr)
PFN_vkGetBufferDeviceAddressKHR pfnBDA = nullptr; PFN_vkCreateAccelerationStructureKHR pfnCreateAS = nullptr; PFN_vkDestroyAccelerationStructureKHR pfnDestroyAS = nullptr;
PFN_vkGetAccelerationStructureBuildSizesKHR pfnASSizes = nullptr; PFN_vkCmdBuildAccelerationStructuresKHR pfnBuildAS = nullptr;

std::vector<uint32_t> loadSpv(const char* name) {
    std::vector<uint32_t> out;
    if (fxSpv(name, out)) return out;      // runtime-compiled effect (fx_runtime.cpp)
    AAsset* a = AAssetManager_open(g.am, name, AASSET_MODE_BUFFER);
    if (!a) { LOG("missing asset %s", name); return out; }
    size_t n = AAsset_getLength(a); out.resize((n + 3) / 4); AAsset_read(a, out.data(), n); AAsset_close(a); return out;
}

VkShaderModule shaderMod(const char* name) {
    auto c = loadSpv(name); if (c.empty()) return VK_NULL_HANDLE;
    VkShaderModuleCreateInfo ci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO}; ci.codeSize = c.size() * 4; ci.pCode = c.data();
    VkShaderModule m = VK_NULL_HANDLE; vkCreateShaderModule(g.dev, &ci, nullptr, &m); return m;
}
uint32_t findMem(uint32_t bits, VkMemoryPropertyFlags f) {
    VkPhysicalDeviceMemoryProperties mp; vkGetPhysicalDeviceMemoryProperties(g.pd, &mp);
    for (uint32_t i = 0; i < mp.memoryTypeCount; i++) if ((bits & (1u << i)) && (mp.memoryTypes[i].propertyFlags & f) == f) return i;
    return 0;
}
bool makeBuffer(VkDeviceSize sz, VkBufferUsageFlags u, VkMemoryPropertyFlags f, VkBuffer& b, VkDeviceMemory& m) {
    VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO}; bi.size = sz; bi.usage = u; bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    VKC(vkCreateBuffer(g.dev, &bi, nullptr, &b));
    VkMemoryRequirements r; vkGetBufferMemoryRequirements(g.dev, b, &r);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO}; ai.allocationSize = r.size; ai.memoryTypeIndex = findMem(r.memoryTypeBits, f);
    VkMemoryAllocateFlagsInfo fi{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_FLAGS_INFO}; fi.flags = VK_MEMORY_ALLOCATE_DEVICE_ADDRESS_BIT;
    if (u & VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT) ai.pNext = &fi;      // buffers the acceleration-structure build reads need a device address
    VKC(vkAllocateMemory(g.dev, &ai, nullptr, &m)); VKC(vkBindBufferMemory(g.dev, b, m, 0)); return true;
}
VkCommandBuffer oneShotBegin() {
    VkCommandBufferAllocateInfo ai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO}; ai.commandPool = g.pool; ai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; ai.commandBufferCount = 1;
    VkCommandBuffer c; vkAllocateCommandBuffers(g.dev, &ai, &c);
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO}; bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT; vkBeginCommandBuffer(c, &bi); return c;
}
void oneShotEnd(VkCommandBuffer c) {
    vkEndCommandBuffer(c); VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO}; si.commandBufferCount = 1; si.pCommandBuffers = &c;
    vkQueueSubmit(g.q, 1, &si, VK_NULL_HANDLE); vkQueueWaitIdle(g.q); vkFreeCommandBuffers(g.dev, g.pool, 1, &c);
}
void barrier(VkCommandBuffer c, VkImage i, VkImageLayout from, VkImageLayout to, VkAccessFlags sa, VkAccessFlags da, VkPipelineStageFlags ss, VkPipelineStageFlags ds) {
    VkImageMemoryBarrier b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER}; b.oldLayout = from; b.newLayout = to; b.srcAccessMask = sa; b.dstAccessMask = da;
    b.srcQueueFamilyIndex = b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED; b.image = i; b.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    vkCmdPipelineBarrier(c, ss, ds, 0, 0, nullptr, 0, nullptr, 1, &b);
}
// RGBA8 texture upload helper (every later pass/texture goes through the same pattern).
bool makeTexture(int w, int h, const uint8_t* rgba, Tex& t) {
    VkImageCreateInfo ii{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO}; ii.imageType = VK_IMAGE_TYPE_2D; ii.format = VK_FORMAT_R8G8B8A8_UNORM;
    ii.extent = {(uint32_t)w, (uint32_t)h, 1}; ii.mipLevels = 1; ii.arrayLayers = 1; ii.samples = VK_SAMPLE_COUNT_1_BIT; ii.tiling = VK_IMAGE_TILING_OPTIMAL;
    ii.usage = VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT; ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    VKC(vkCreateImage(g.dev, &ii, nullptr, &t.img));
    VkMemoryRequirements r; vkGetImageMemoryRequirements(g.dev, t.img, &r);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO}; ai.allocationSize = r.size; ai.memoryTypeIndex = findMem(r.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VKC(vkAllocateMemory(g.dev, &ai, nullptr, &t.mem)); VKC(vkBindImageMemory(g.dev, t.img, t.mem, 0));
    VkBuffer sb; VkDeviceMemory sm; VkDeviceSize sz = (VkDeviceSize)w * h * 4;
    if (!makeBuffer(sz, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, sb, sm)) return false;
    void* p; vkMapMemory(g.dev, sm, 0, sz, 0, &p); memcpy(p, rgba, sz); vkUnmapMemory(g.dev, sm);
    VkCommandBuffer c = oneShotBegin();
    barrier(c, t.img, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 0, VK_ACCESS_TRANSFER_WRITE_BIT, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
    VkBufferImageCopy rg{}; rg.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1}; rg.imageExtent = {(uint32_t)w, (uint32_t)h, 1};
    vkCmdCopyBufferToImage(c, sb, t.img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &rg);
    barrier(c, t.img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    oneShotEnd(c); vkDestroyBuffer(g.dev, sb, nullptr); vkFreeMemory(g.dev, sm, nullptr);
    VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO}; vi.image = t.img; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = ii.format;
    vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1}; VKC(vkCreateImageView(g.dev, &vi, nullptr, &t.view)); return true;
}
// Generic fullscreen pipeline: fs.vert + <frag>.spv, no vertex input, no depth, optional premultiplied blend off (passes blend in-shader).
bool makeFullscreenPipeline(const char* fragSpv, VkRenderPass rp, bool over, VkPipeline& out) {
    VkShaderModule vs = shaderMod("shaders/fs.vert.spv"), fs = shaderMod(fragSpv); if (!vs || !fs) return false;
    VkPipelineShaderStageCreateInfo st[2]{}; st[0].sType = st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[0].stage = VK_SHADER_STAGE_VERTEX_BIT; st[0].module = vs; st[0].pName = "main"; st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT; st[1].module = fs; st[1].pName = "main";
    VkPipelineVertexInputStateCreateInfo vin{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO}; ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO}; vp.viewportCount = vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO}; rs.polygonMode = VK_POLYGON_MODE_FILL; rs.cullMode = VK_CULL_MODE_NONE; rs.lineWidth = 1.f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO}; ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineColorBlendAttachmentState cba{}; cba.colorWriteMask = 0xF;
    if (over) {   // == MetalPasses.pipelineOver: premultiplied over
        cba.blendEnable = VK_TRUE; cba.colorBlendOp = cba.alphaBlendOp = VK_BLEND_OP_ADD;
        cba.srcColorBlendFactor = cba.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE; cba.dstColorBlendFactor = cba.dstAlphaBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
    }
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO}; cb.attachmentCount = 1; cb.pAttachments = &cba;
    VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO}; ds.dynamicStateCount = 2; ds.pDynamicStates = dyn;
    VkGraphicsPipelineCreateInfo pi{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO}; pi.stageCount = 2; pi.pStages = st; pi.pVertexInputState = &vin; pi.pInputAssemblyState = &ia;
    pi.pViewportState = &vp; pi.pRasterizationState = &rs; pi.pMultisampleState = &ms; pi.pColorBlendState = &cb; pi.pDynamicState = &ds; pi.layout = g.pl; pi.renderPass = rp;
    VkResult r = vkCreateGraphicsPipelines(g.dev, VK_NULL_HANDLE, 1, &pi, nullptr, &out);
    vkDestroyShaderModule(g.dev, vs, nullptr); vkDestroyShaderModule(g.dev, fs, nullptr);
    if (r != VK_SUCCESS) { LOG("pipeline %s failed %d", fragSpv, (int)r); return false; } return true;
}

// ---- render core internals (== MetalPasses private state) ----
constexpr uint32_t kRingSlot = 256, kRingSlots = 512;   // per-pass UBO slot (== setFragmentBytes) / max passes per frame
constexpr uint32_t kArena = 16u << 20;   // per-frame UBO/SSBO arena for the generic passes
// PARITY-NOTE (MetalPasses.swift arena): iOS grows its per-frame argument buffer on demand; Vulkan device memory cannot, so Android uses a
// fixed 16 MiB arena. Exhaustion skips the pass with a log (never a blank frame); 16 MiB covers the heaviest iOS scenes tested (Universe, Pt).
struct FrameRes { VkDescriptorPool dp = VK_NULL_HANDLE; VkBuffer ub = VK_NULL_HANDLE; VkDeviceMemory um = VK_NULL_HANDLE; uint8_t* map = nullptr; uint32_t used = 0;
                  VkBuffer ab = VK_NULL_HANDLE; VkDeviceMemory am = VK_NULL_HANDLE; uint8_t* amap = nullptr; uint32_t aused = 0; };
VkCommandBuffer curCb = VK_NULL_HANDLE;   // command buffer being recorded (vkFrame / runSync); model JNI records into it
FrameRes fr[kFrames + 1]; FrameRes* cf = nullptr;       // [kFrames] = runSync slot
VkRenderPass rpCache[2][2]{};                           // [0=RGBA16F,1=RGBA8][load]
std::map<std::string, VkPipeline> pipes;
Tex dummyTex;

VkRenderPass rpFor(VkFormat f, bool load) {
    if (f == g.scFmt && g.rp) return g.rp;
    VkRenderPass& r = rpCache[f == VK_FORMAT_R16G16B16A16_SFLOAT ? 0 : 1][load ? 1 : 0];
    if (r) return r;
    VkAttachmentDescription a{}; a.format = f; a.samples = VK_SAMPLE_COUNT_1_BIT;
    a.loadOp = load ? VK_ATTACHMENT_LOAD_OP_LOAD : VK_ATTACHMENT_LOAD_OP_CLEAR; a.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    a.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE; a.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    a.initialLayout = load ? VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL : VK_IMAGE_LAYOUT_UNDEFINED; a.finalLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    VkAttachmentReference ref{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL}; VkSubpassDescription sp{}; sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS; sp.colorAttachmentCount = 1; sp.pColorAttachments = &ref;
    VkSubpassDependency d[2]{};
    d[0].srcSubpass = VK_SUBPASS_EXTERNAL; d[0].dstSubpass = 0;
    d[0].srcStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT | VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT; d[0].dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    d[0].srcAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT; d[0].dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_COLOR_ATTACHMENT_READ_BIT;
    d[1].srcSubpass = 0; d[1].dstSubpass = VK_SUBPASS_EXTERNAL;
    d[1].srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT; d[1].dstStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT | VK_PIPELINE_STAGE_TRANSFER_BIT;
    d[1].srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT; d[1].dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_TRANSFER_READ_BIT;
    VkRenderPassCreateInfo ri{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO}; ri.attachmentCount = 1; ri.pAttachments = &a; ri.subpassCount = 1; ri.pSubpasses = &sp; ri.dependencyCount = 2; ri.pDependencies = d;
    if (vkCreateRenderPass(g.dev, &ri, nullptr, &r) != VK_SUCCESS) { LOG("rpFor failed"); r = VK_NULL_HANDLE; }
    return r;
}
std::vector<VkFramebuffer> fbTrash[kFrames + 1];        // per-pass model framebuffers (vk_model.inc), freed when the frame slot is reused
std::vector<Accel*> asTrash[kFrames + 1];               // retired acceleration structures (animated models rebuild every frame), freed with the slot
void freeAccel(Accel* a) {
    if (!a) return;
    if (a->as && pfnDestroyAS) pfnDestroyAS(g.dev, a->as, nullptr);
    if (a->buf) vkDestroyBuffer(g.dev, a->buf, nullptr); if (a->mem) vkFreeMemory(g.dev, a->mem, nullptr);
    if (a->sbuf) vkDestroyBuffer(g.dev, a->sbuf, nullptr); if (a->smem) vkFreeMemory(g.dev, a->smem, nullptr);
    delete a;
}
void resetFrame(FrameRes& r) { vkResetDescriptorPool(g.dev, r.dp, 0); r.used = 0; r.aused = 0; auto& tr = fbTrash[&r - fr]; for (auto f : tr) vkDestroyFramebuffer(g.dev, f, nullptr); tr.clear();
    auto& at = asTrash[&r - fr]; for (auto a : at) freeAccel(a); at.clear(); }
bool allocSet(VkImageView in[3], const void* ubo, uint32_t sz, VkDescriptorSet& ds) {
    if (!cf || cf->used >= kRingSlots || sz > kRingSlot) { LOG("allocSet: ring exhausted/oversize"); return false; }
    VkDescriptorSetAllocateInfo ai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO}; ai.descriptorPool = cf->dp; ai.descriptorSetCount = 1; ai.pSetLayouts = &g.dsl;
    VKC(vkAllocateDescriptorSets(g.dev, &ai, &ds));
    uint32_t off = cf->used++ * kRingSlot; memset(cf->map + off, 0, kRingSlot); if (ubo && sz) memcpy(cf->map + off, ubo, sz);
    VkDescriptorImageInfo ii[3]; VkWriteDescriptorSet w[4]{};
    for (int i = 0; i < 3; i++) {
        ii[i] = {g.linearClamp, in[i] ? in[i] : dummyTex.view, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
        w[i].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET; w[i].dstSet = ds; w[i].dstBinding = i; w[i].descriptorCount = 1; w[i].descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER; w[i].pImageInfo = &ii[i];
    }
    VkDescriptorBufferInfo bi{cf->ub, off, kRingSlot};
    w[3].sType = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET; w[3].dstSet = ds; w[3].dstBinding = 3; w[3].descriptorCount = 1; w[3].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER; w[3].pBufferInfo = &bi;
    vkUpdateDescriptorSets(g.dev, 4, w, 0, nullptr); return true;
}
bool initRenderCore() {
    for (int i = 0; i <= kFrames; i++) {
        VkDescriptorPoolSize ps[4] = {{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 32 * kRingSlots}, {VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 4 * kRingSlots}, {VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 4 * kRingSlots}, {VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR, kRingSlots}};
        VkDescriptorPoolCreateInfo di{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO}; di.maxSets = kRingSlots; di.poolSizeCount = g.rtOn ? 4 : 3; di.pPoolSizes = ps;
        VKC(vkCreateDescriptorPool(g.dev, &di, nullptr, &fr[i].dp));
        VKC(makeBuffer(kRingSlot * kRingSlots, VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, fr[i].ub, fr[i].um) ? VK_SUCCESS : VK_ERROR_UNKNOWN);
        VKC(vkMapMemory(g.dev, fr[i].um, 0, VK_WHOLE_SIZE, 0, (void**)&fr[i].map));
        VKC(makeBuffer(kArena, VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT | VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, fr[i].ab, fr[i].am) ? VK_SUCCESS : VK_ERROR_UNKNOWN);
        VKC(vkMapMemory(g.dev, fr[i].am, 0, VK_WHOLE_SIZE, 0, (void**)&fr[i].amap));
    }
    cf = &fr[kFrames];
    const uint8_t z[4] = {0, 0, 0, 0}; return makeTexture(1, 1, z, dummyTex);   // == MetalPasses.dummy
}
void shutdownRenderCore() {
    for (auto& p : pipes) vkDestroyPipeline(g.dev, p.second, nullptr); pipes.clear(); shutdownLayouts();
    for (auto& a : rpCache) for (auto& r : a) if (r) { vkDestroyRenderPass(g.dev, r, nullptr); r = VK_NULL_HANDLE; }
    for (auto& f : fr) { if (f.dp) vkDestroyDescriptorPool(g.dev, f.dp, nullptr); if (f.map) vkUnmapMemory(g.dev, f.um); if (f.ub) vkDestroyBuffer(g.dev, f.ub, nullptr); if (f.um) vkFreeMemory(g.dev, f.um, nullptr);
               if (f.amap) vkUnmapMemory(g.dev, f.am); if (f.ab) vkDestroyBuffer(g.dev, f.ab, nullptr); if (f.am) vkFreeMemory(g.dev, f.am, nullptr); f = FrameRes{}; }
    for (auto& sm : g.samp) if (sm) { vkDestroySampler(g.dev, sm, nullptr); sm = VK_NULL_HANDLE; }
    cf = nullptr;
    if (dummyTex.view) { vkDestroyImageView(g.dev, dummyTex.view, nullptr); vkDestroyImage(g.dev, dummyTex.img, nullptr); vkFreeMemory(g.dev, dummyTex.mem, nullptr); dummyTex = Tex{}; }
}

void destroySwapchain() {
    if (!g.dev) return; vkDeviceWaitIdle(g.dev);
    for (auto f : g.fbs) vkDestroyFramebuffer(g.dev, f, nullptr); g.fbs.clear();
    for (auto v : g.scViews) vkDestroyImageView(g.dev, v, nullptr); g.scViews.clear();
    for (auto s : g.renderDone) vkDestroySemaphore(g.dev, s, nullptr); g.renderDone.clear();
    if (g.sc) { vkDestroySwapchainKHR(g.dev, g.sc, nullptr); g.sc = VK_NULL_HANDLE; }
}
bool createSwapchain() {
    VkSurfaceCapabilitiesKHR caps; VKC(vkGetPhysicalDeviceSurfaceCapabilitiesKHR(g.pd, g.surf, &caps));
    uint32_t n = 0; vkGetPhysicalDeviceSurfaceFormatsKHR(g.pd, g.surf, &n, nullptr); std::vector<VkSurfaceFormatKHR> fm(n); vkGetPhysicalDeviceSurfaceFormatsKHR(g.pd, g.surf, &n, fm.data());
    VkSurfaceFormatKHR pick = fm[0]; for (auto& f : fm) if (f.format == VK_FORMAT_B8G8R8A8_UNORM) { pick = f; break; }
    g.scFmt = pick.format; g.ext = caps.currentExtent;
    uint32_t cnt = caps.minImageCount + 1; if (caps.maxImageCount && cnt > caps.maxImageCount) cnt = caps.maxImageCount;
    VkSwapchainCreateInfoKHR si{VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR}; si.surface = g.surf; si.minImageCount = cnt; si.imageFormat = pick.format; si.imageColorSpace = pick.colorSpace;
    si.imageExtent = g.ext; si.imageArrayLayers = 1; si.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT; si.preTransform = caps.currentTransform;
    si.compositeAlpha = (caps.supportedCompositeAlpha & VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR) ? VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR : VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR;
    si.presentMode = VK_PRESENT_MODE_FIFO_KHR; si.clipped = VK_TRUE; VKC(vkCreateSwapchainKHR(g.dev, &si, nullptr, &g.sc));
    uint32_t ic = 0; vkGetSwapchainImagesKHR(g.dev, g.sc, &ic, nullptr); g.scImgs.resize(ic); vkGetSwapchainImagesKHR(g.dev, g.sc, &ic, g.scImgs.data());
    if (!g.rp) {
        VkAttachmentDescription a{}; a.format = g.scFmt; a.samples = VK_SAMPLE_COUNT_1_BIT; a.loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR; a.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
        a.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE; a.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE; a.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED; a.finalLayout = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR;
        VkAttachmentReference ref{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL}; VkSubpassDescription sp{}; sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS; sp.colorAttachmentCount = 1; sp.pColorAttachments = &ref;
        VkSubpassDependency dep{}; dep.srcSubpass = VK_SUBPASS_EXTERNAL; dep.dstSubpass = 0; dep.srcStageMask = dep.dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT; dep.dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
        VkRenderPassCreateInfo ri{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO}; ri.attachmentCount = 1; ri.pAttachments = &a; ri.subpassCount = 1; ri.pSubpasses = &sp; ri.dependencyCount = 1; ri.pDependencies = &dep;
        VKC(vkCreateRenderPass(g.dev, &ri, nullptr, &g.rp));
    }
    for (auto img : g.scImgs) {
        VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO}; vi.image = img; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = g.scFmt; vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
        VkImageView v; VKC(vkCreateImageView(g.dev, &vi, nullptr, &v)); g.scViews.push_back(v);
        VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO}; fi.renderPass = g.rp; fi.attachmentCount = 1; fi.pAttachments = &v; fi.width = g.ext.width; fi.height = g.ext.height; fi.layers = 1;
        VkFramebuffer fb; VKC(vkCreateFramebuffer(g.dev, &fi, nullptr, &fb)); g.fbs.push_back(fb);
        VkSemaphoreCreateInfo sci{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO}; VkSemaphore s; VKC(vkCreateSemaphore(g.dev, &sci, nullptr, &s)); g.renderDone.push_back(s);
    }
    g.needSc = false; return true;
}
} // namespace

// ---- render core public API (port of MetalCore.swift / MetalPasses.swift) ----
bool uploadTexture(int w, int h, const uint8_t* rgba, Tex& t) { return makeTexture(w, h, rgba, t); }
void destroyTex(Tex& t) { if (!g.dev) return; vkDeviceWaitIdle(g.dev); if (t.view) vkDestroyImageView(g.dev, t.view, nullptr); if (t.img) vkDestroyImage(g.dev, t.img, nullptr); if (t.mem) vkFreeMemory(g.dev, t.mem, nullptr); t = Tex{}; }
VkImageView dummyView() { return dummyTex.view; }

bool makeTarget(Target& t, int w, int h, bool half) {       // == MetalTarget.init
    t.width = std::max(1, w); t.height = std::max(1, h); t.half = half; t.fmt = half ? VK_FORMAT_R16G16B16A16_SFLOAT : VK_FORMAT_R8G8B8A8_UNORM;
    VkImageCreateInfo ii{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO}; ii.imageType = VK_IMAGE_TYPE_2D; ii.format = t.fmt; ii.extent = {(uint32_t)t.width, (uint32_t)t.height, 1};
    ii.mipLevels = 1; ii.arrayLayers = 1; ii.samples = VK_SAMPLE_COUNT_1_BIT; ii.tiling = VK_IMAGE_TILING_OPTIMAL; ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    ii.usage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
    VKC(vkCreateImage(g.dev, &ii, nullptr, &t.tex.img));
    VkMemoryRequirements r; vkGetImageMemoryRequirements(g.dev, t.tex.img, &r);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO}; ai.allocationSize = r.size; ai.memoryTypeIndex = findMem(r.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VKC(vkAllocateMemory(g.dev, &ai, nullptr, &t.tex.mem)); VKC(vkBindImageMemory(g.dev, t.tex.img, t.tex.mem, 0));
    VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO}; vi.image = t.tex.img; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = t.fmt; vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1};
    VKC(vkCreateImageView(g.dev, &vi, nullptr, &t.tex.view));
    VkRenderPass rp = rpFor(t.fmt, false); if (!rp) return false;
    VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO}; fi.renderPass = rp; fi.attachmentCount = 1; fi.pAttachments = &t.tex.view; fi.width = t.width; fi.height = t.height; fi.layers = 1;
    VKC(vkCreateFramebuffer(g.dev, &fi, nullptr, &t.fb));
    VkCommandBuffer c = oneShotBegin();   // every target rests in SHADER_READ_ONLY between passes
    barrier(c, t.tex.img, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, 0, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    oneShotEnd(c); return true;
}
void destroyTarget(Target& t) {
    if (!g.dev) return; vkDeviceWaitIdle(g.dev);
    if (t.fb) vkDestroyFramebuffer(g.dev, t.fb, nullptr); t.fb = VK_NULL_HANDLE;
    if (t.tex.view) vkDestroyImageView(g.dev, t.tex.view, nullptr); if (t.tex.img) vkDestroyImage(g.dev, t.tex.img, nullptr); if (t.tex.mem) vkFreeMemory(g.dev, t.tex.mem, nullptr); t.tex = Tex{};
}
bool readTarget(Target& t, std::vector<uint8_t>& out) {     // == MetalTarget.readImage: nil for half
    if (t.half) return false;
    VkDeviceSize sz = (VkDeviceSize)t.width * t.height * 4; VkBuffer b; VkDeviceMemory m;
    if (!makeBuffer(sz, VK_BUFFER_USAGE_TRANSFER_DST_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, b, m)) return false;
    VkCommandBuffer c = oneShotBegin();
    barrier(c, t.tex.img, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_ACCESS_SHADER_READ_BIT, VK_ACCESS_TRANSFER_READ_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
    VkBufferImageCopy rg{}; rg.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1}; rg.imageExtent = {(uint32_t)t.width, (uint32_t)t.height, 1};
    vkCmdCopyImageToBuffer(c, t.tex.img, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, b, 1, &rg);
    barrier(c, t.tex.img, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, VK_ACCESS_TRANSFER_READ_BIT, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    oneShotEnd(c);
    void* p = nullptr; vkMapMemory(g.dev, m, 0, sz, 0, &p); out.assign((uint8_t*)p, (uint8_t*)p + sz); vkUnmapMemory(g.dev, m);
    vkDestroyBuffer(g.dev, b, nullptr); vkFreeMemory(g.dev, m, nullptr); return true;
}
VkPipeline pipelineFor(const char* frag, VkFormat fmt, bool over) {   // == MetalPasses.pipeline / pipelineOver (cached)
    std::string key = std::string(frag) + "/" + std::to_string((int)fmt) + (over ? "/over" : "");
    auto it = pipes.find(key); if (it != pipes.end()) return it->second;
    VkRenderPass rp = rpFor(fmt, false); if (!rp) return VK_NULL_HANDLE;
    VkPipeline p = VK_NULL_HANDLE; if (!makeFullscreenPipeline((std::string("shaders/") + frag + ".spv").c_str(), rp, over, p)) return VK_NULL_HANDLE;
    pipes[key] = p; return p;
}
bool encodePass(VkCommandBuffer cb, Target& t, VkPipeline pso, bool load, VkImageView v0, VkImageView v1, VkImageView v2, const void* ubo, uint32_t sz) {
    if (!pso) return false;
    VkImageView v[3] = {v0, v1, v2}; VkDescriptorSet ds; if (!allocSet(v, ubo, sz, ds)) return false;
    VkClearValue cv{};   // 0,0,0,0 == MTLClearColor(0,0,0,0)
    VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO}; rb.renderPass = rpFor(t.fmt, load); rb.framebuffer = t.fb; rb.renderArea = {{0, 0}, {(uint32_t)t.width, (uint32_t)t.height}}; rb.clearValueCount = 1; rb.pClearValues = &cv;
    vkCmdBeginRenderPass(cb, &rb, VK_SUBPASS_CONTENTS_INLINE);
    VkViewport vp{0.f, (float)t.height, (float)t.width, -(float)t.height, 0.f, 1.f}; VkRect2D sc{{0, 0}, {(uint32_t)t.width, (uint32_t)t.height}};   // negative height: y-up like Metal
    vkCmdSetViewport(cb, 0, 1, &vp); vkCmdSetScissor(cb, 0, 1, &sc);
    vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, pso); vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, g.pl, 0, 1, &ds, 0, nullptr);
    vkCmdDraw(cb, 3, 1, 0, 0); vkCmdEndRenderPass(cb); return true;
}
bool blit(VkCommandBuffer cb, VkImageView src, Target& to) {     // == MetalPasses.blit
    return encodePass(cb, to, pipelineFor("blit.frag", to.fmt), false, src);
}
bool composite(VkCommandBuffer cb, VkImageView scene, VkImageView src, VkImageView mask, float alpha, int mode, int maskMode, float rgbShift, Target& out) {
    CompParams u{alpha, (float)mode, (float)maskMode, rgbShift};
    return encodePass(cb, out, pipelineFor("composite.frag", out.fmt), false, scene, src, mask, &u, sizeof(u));   // mask null -> dummy
}
bool composite(VkCommandBuffer cb, Target& target, Target& scratch, VkImageView src, VkImageView mask, float alpha, int mode, int maskMode, float rgbShift) {
    if (!composite(cb, target.tex.view, src, mask, alpha, mode, maskMode, rgbShift, scratch)) return false;
    std::swap(target.tex, scratch.tex); std::swap(target.fb, scratch.fb); return true;   // swap, no copy-back
}
void runSync(const std::function<void(VkCommandBuffer)>& body) {
    FrameRes* prev = cf; cf = &fr[kFrames]; resetFrame(*cf);
    VkCommandBuffer c = oneShotBegin(); VkCommandBuffer pc = curCb; curCb = c; body(c); curCb = pc; oneShotEnd(c); cf = prev;
}
bool selfTest() {      // == MetalCore.selfTest: clear 4x4 red, read back
    Target t; if (!makeTarget(t, 4, 4, false)) return false;
    runSync([&](VkCommandBuffer c) {
        VkClearValue cv{}; cv.color.float32[0] = 1; cv.color.float32[3] = 1;
        VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO}; rb.renderPass = rpFor(t.fmt, false); rb.framebuffer = t.fb; rb.renderArea = {{0, 0}, {4, 4}}; rb.clearValueCount = 1; rb.pClearValues = &cv;
        vkCmdBeginRenderPass(c, &rb, VK_SUBPASS_CONTENTS_INLINE); vkCmdEndRenderPass(c);
    });
    std::vector<uint8_t> px; bool ok = readTarget(t, px) && px[0] == 255 && px[1] == 0 && px[2] == 0 && px[3] == 255;
    destroyTarget(t); return ok;
}

// ================= generic per-shader layouts / pipelines / passes (slice 5) =================
// The original 3-sampler + UBO(b3) path above stays for blit/composite. Everything else declares its set layout
// from the shader header (b0.. textures, b8 UBO, extra SSBO/UBO) and passes binds by binding number.
static VkSampler samplerFor(Samp s) {            // == the MSL constexpr samplers (linearClamp / nearest / repeat / mip / aniso8 / aniso4)
    int i = (int)s; if (s == Samp::Dynamic) i = (int)Samp::LinearClamp; if (i < 0 || i > 8) i = 0;
    if (g.samp[i]) return g.samp[i];
    VkSamplerCreateInfo c{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO};
    bool nearest = s == Samp::NearestClamp, rep = s == Samp::LinearRepeat || s == Samp::LinearMipRepeat || s == Samp::Aniso8MipRepeat || s == Samp::Aniso4MipRepeat;
    bool mip = s == Samp::LinearMipRepeat || s == Samp::Aniso8MipRepeat || s == Samp::LinearMipClamp || s == Samp::Aniso4MipRepeat || s == Samp::Aniso4MipClamp;
    c.magFilter = c.minFilter = nearest ? VK_FILTER_NEAREST : VK_FILTER_LINEAR;
    c.mipmapMode = mip ? VK_SAMPLER_MIPMAP_MODE_LINEAR : VK_SAMPLER_MIPMAP_MODE_NEAREST; c.maxLod = mip ? VK_LOD_CLAMP_NONE : 0.f;   // no mip_filter => base level only
    c.addressModeU = c.addressModeV = c.addressModeW = rep ? VK_SAMPLER_ADDRESS_MODE_REPEAT : VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    if (s == Samp::Aniso8MipRepeat && g.aniso) { c.anisotropyEnable = VK_TRUE; c.maxAnisotropy = 8.f; }
    if ((s == Samp::Aniso4MipRepeat || s == Samp::Aniso4MipClamp) && g.aniso) { c.anisotropyEnable = VK_TRUE; c.maxAnisotropy = 4.f; }   // MetalModel.swift:1103 maxAnisotropy 4
    if (vkCreateSampler(g.dev, &c, nullptr, &g.samp[i]) != VK_SUCCESS) { LOG("sampler %d failed", i); g.samp[i] = g.linearClamp; }
    return g.samp[i];
}
VkSampler sampler(Samp s) { return samplerFor(s); }
static std::map<std::string, Layout*> layouts;
const Layout* layoutFor(const char* key, const std::vector<BindDecl>& decl) {
    auto it = layouts.find(key); if (it != layouts.end()) return it->second;
    std::vector<VkDescriptorSetLayoutBinding> b;
    for (auto& d : decl) { VkDescriptorSetLayoutBinding x{}; x.binding = d.binding; x.descriptorType = d.type; x.descriptorCount = d.count; x.stageFlags = d.stages; b.push_back(x); }
    Layout* L = new Layout(); L->decl = decl;
    VkDescriptorSetLayoutCreateInfo li{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO}; li.bindingCount = (uint32_t)b.size(); li.pBindings = b.data();
    VkPipelineLayoutCreateInfo pi{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    if (vkCreateDescriptorSetLayout(g.dev, &li, nullptr, &L->dsl) != VK_SUCCESS) { LOG("layout %s failed", key); delete L; return nullptr; }
    pi.setLayoutCount = 1; pi.pSetLayouts = &L->dsl;
    if (vkCreatePipelineLayout(g.dev, &pi, nullptr, &L->pl) != VK_SUCCESS) { LOG("pipeline layout %s failed", key); vkDestroyDescriptorSetLayout(g.dev, L->dsl, nullptr); delete L; return nullptr; }
    layouts[key] = L; return L;
}
static constexpr VkShaderStageFlags F = VK_SHADER_STAGE_FRAGMENT_BIT, V = VK_SHADER_STAGE_VERTEX_BIT;
static constexpr VkDescriptorType CIS = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, UB = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, SB = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
const Layout* fxLayout(int nTex) {      // convention: textures b0..nTex-1 (linear clamp) + std140 UBO b8 (vertex+fragment)
    std::vector<BindDecl> d; for (int i = 0; i < nTex; i++) d.push_back({(uint32_t)i, CIS, 1, F, Samp::LinearClamp});
    d.push_back({8, UB, 1, V | F, Samp::LinearClamp}); return layoutFor((std::string("fx") + std::to_string(nTex)).c_str(), d);
}
// Layouts of the ported shaders, exactly as in each GLSL header. Key by shader family.
const Layout* layoutForShader(const char* file) {
    std::string n = file; auto is = [&](const char* a) { return n.rfind(a, 0) == 0; };
    if (is("fx/")) return layoutFor("effect", {{0, CIS, 1, F, Samp::LinearClamp}, {1, CIS, 1, F, Samp::LinearClamp}, {2, CIS, 1, F, Samp::LinearClamp}, {3, UB, 1, F, Samp::LinearClamp}, {4, UB, 1, F, Samp::LinearClamp}});   // == MetalEffects.apply: t0 layer, t1/t2 in0/in1, FxCommon, props
    if (is("blit") || is("composite")) return nullptr;                       // old std layout (encodePass)
    if (is("glowFinal") || is("glowUp")) return fxLayout(2);
    if (is("glow")) return fxLayout(1);
    if (is("vdb")) return layoutFor("vdb", {{0, CIS, 1, F, Samp::LinearClamp}, {1, CIS, 1, F, Samp::NearestClamp}, {2, CIS, 1, F, Samp::LinearClamp}, {3, CIS, 1, F, Samp::LinearClamp}, {8, UB, 1, V | F, Samp::LinearClamp}});
    if (is("flare")) return layoutFor("flare", {{0, CIS, 1, F, Samp::NearestClamp}, {1, UB, 1, F, Samp::LinearClamp}, {2, UB, 1, F, Samp::LinearClamp}, {8, UB, 1, V | F, Samp::LinearClamp}});
    if (is("particle")) return layoutFor("particle", {{0, UB, 1, V | F, Samp::LinearClamp}, {1, SB, 1, V, Samp::LinearClamp}, {2, UB, 1, V, Samp::LinearClamp}, {3, CIS, 1, F, Samp::LinearClamp}, {4, CIS, 1, F, Samp::LinearClamp}});
    if (is("mesh") || is("warp")) return layoutFor("mesh", {{0, CIS, 1, F, Samp::LinearClamp}, {1, SB, 1, V, Samp::LinearClamp}, {2, SB, 1, V, Samp::LinearClamp}, {8, UB, 1, V | F, Samp::LinearClamp}});
    if (is("quad") || is("shape")) return fxLayout(1);
    if (is("planeOcc")) return layoutFor("planeOcc", {{0, CIS, 1, F, Samp::LinearClamp}, {4, CIS, 1, F, Samp::NearestClamp}, {32, UB, 1, F, Samp::LinearClamp}});
    if (is("planeDepth")) return layoutFor("planeDepth", {{0, CIS, 1, F, Samp::NearestClamp}, {32, UB, 1, F, Samp::LinearClamp}});
    if (is("waterUnder")) return layoutFor("waterUnder", {{4, CIS, 1, F, Samp::NearestClamp}, {5, CIS, 1, F, Samp::LinearClamp}, {32, UB, 1, F, Samp::LinearClamp}, {39, UB, 1, F, Samp::LinearClamp}});
    if (is("model")) {          // model.vert + model.frag (non-RT). "model_rt" = same + acc b36 / RtU b37 (ray query, MetalModel.swift:1311)
        bool rtl = is("model_rt");
        std::vector<BindDecl> d = {{0, CIS, 1, F, Samp::Dynamic}, {1, CIS, 1, F, Samp::Dynamic}, {2, CIS, 1, F, Samp::Dynamic}, {3, CIS, 1, F, Samp::Dynamic},
            {4, CIS, 1, F, Samp::NearestClamp}, {5, CIS, 1, F, Samp::LinearClamp}, {6, CIS, 1, F, Samp::LinearMipRepeat},
            {7, CIS, 4, F, Samp::Aniso8MipRepeat}, {11, CIS, 4, F, Samp::Aniso8MipRepeat}, {15, CIS, 4, F, Samp::Aniso8MipRepeat},
            {19, CIS, 1, F, Samp::LinearClamp}, {20, CIS, 1, F, Samp::LinearClamp}};
        for (uint32_t i = 21; i <= 25; i++) d.push_back({i, CIS, 1, F, Samp::Aniso8MipRepeat});
        d.push_back({26, CIS, 1, V, Samp::LinearRepeat}); d.push_back({32, UB, 1, V | F, Samp::LinearClamp}); d.push_back({33, UB, 1, F, Samp::LinearClamp}); d.push_back({34, SB, 1, V, Samp::LinearClamp});
        if (rtl) { d.push_back({36, VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR, 1, F, Samp::LinearClamp}); d.push_back({37, UB, 1, F, Samp::LinearClamp}); }
        return layoutFor(rtl ? "model_rt" : "model", d);
    }
    LOG("layoutForShader: unknown %s", file); return nullptr;
}
const Layout* stdLayout() { static Layout L; if (!L.dsl) { L.dsl = g.dsl; L.pl = g.pl; L.decl = {{0, CIS, 1, F, Samp::LinearClamp}, {1, CIS, 1, F, Samp::LinearClamp}, {2, CIS, 1, F, Samp::LinearClamp}, {3, UB, 1, F, Samp::LinearClamp}}; } return &L; }

VkPipeline pipelineForDesc(const PipeDesc& d) {     // == MetalPasses.pipeline/pipelineOver generalised: vert + frag + layout + blend + topology (cached)
    if (!d.layout || !d.frag) return VK_NULL_HANDLE;
    std::string key = std::string("G/") + d.vert + "/" + d.frag + "/" + std::to_string((uintptr_t)d.layout) + "/" + std::to_string((int)d.fmt) + "/" + std::to_string(d.over) + "/" + std::to_string((int)d.topo);
    auto it = pipes.find(key); if (it != pipes.end()) return it->second;
    VkRenderPass rp = rpFor(d.fmt, false); if (!rp) return VK_NULL_HANDLE;
    VkShaderModule vs = shaderMod((std::string("shaders/") + d.vert + ".spv").c_str()), fs = shaderMod((std::string("shaders/") + d.frag + ".spv").c_str());
    if (!vs || !fs) { if (vs) vkDestroyShaderModule(g.dev, vs, nullptr); if (fs) vkDestroyShaderModule(g.dev, fs, nullptr); return VK_NULL_HANDLE; }
    VkPipelineShaderStageCreateInfo st[2]{}; st[0].sType = st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[0].stage = VK_SHADER_STAGE_VERTEX_BIT; st[0].module = vs; st[0].pName = "main"; st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT; st[1].module = fs; st[1].pName = "main";
    VkPipelineVertexInputStateCreateInfo vin{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};   // all ported vertex shaders pull from SSBOs / gl_VertexIndex
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO}; ia.topology = d.topo;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO}; vp.viewportCount = vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO}; rs.polygonMode = VK_POLYGON_MODE_FILL; rs.cullMode = VK_CULL_MODE_NONE; rs.lineWidth = 1.f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO}; ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineColorBlendAttachmentState cba{}; cba.colorWriteMask = 0xF;
    if (d.over) { cba.blendEnable = VK_TRUE; cba.colorBlendOp = cba.alphaBlendOp = VK_BLEND_OP_ADD; cba.srcColorBlendFactor = cba.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE; cba.dstColorBlendFactor = cba.dstAlphaBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA; }
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO}; cb.attachmentCount = 1; cb.pAttachments = &cba;
    VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO}; ds.dynamicStateCount = 2; ds.pDynamicStates = dyn;
    VkGraphicsPipelineCreateInfo pi{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO}; pi.stageCount = 2; pi.pStages = st; pi.pVertexInputState = &vin; pi.pInputAssemblyState = &ia;
    pi.pViewportState = &vp; pi.pRasterizationState = &rs; pi.pMultisampleState = &ms; pi.pColorBlendState = &cb; pi.pDynamicState = &ds; pi.layout = d.layout->pl; pi.renderPass = rp;
    VkPipeline out = VK_NULL_HANDLE; VkResult r = vkCreateGraphicsPipelines(g.dev, VK_NULL_HANDLE, 1, &pi, nullptr, &out);
    vkDestroyShaderModule(g.dev, vs, nullptr); vkDestroyShaderModule(g.dev, fs, nullptr);
    if (r != VK_SUCCESS) { LOG("pipeline %s+%s failed %d", d.vert, d.frag, (int)r); return VK_NULL_HANDLE; }
    pipes[key] = out; return out;
}
VkPipeline pipelineForFile(const char* vert, const char* frag, VkFormat fmt, bool over, VkPrimitiveTopology topo) {   // MetalPasses libKey path: layout picked from the shader family
    auto vp_ = [&](const char* x) { return strncmp(vert, x, strlen(x)) == 0; };   // vertex shaders with extra bindings decide the layout (mesh/warp SSBOs, particle, model, waterUnder)
    PipeDesc d; d.vert = vert; d.frag = frag; d.layout = layoutForShader((vp_("mesh") || vp_("warp") || vp_("particle") || vp_("model") || vp_("waterUnder")) ? vert : frag); d.fmt = fmt; d.over = over; d.topo = topo;
    if (!d.layout) d.layout = stdLayout(); return pipelineForDesc(d);
}
static bool arenaPush(const void* data, uint32_t size, VkDeviceSize& off) {
    if (!cf) return false; uint32_t a = (cf->aused + 255u) & ~255u; if (size < 16) size = 16;
    if ((uint64_t)a + size > kArena) { LOG("arena exhausted (%u + %u)", a, size); return false; }
    if (data) memcpy(cf->amap + a, data, size); else memset(cf->amap + a, 0, size);
    off = a; cf->aused = a + size; return true;
}
static const Bind* findBind(const Bind* b, int n, uint32_t binding, uint32_t idx) { for (int i = 0; i < n; i++) if (b[i].binding == binding && b[i].index == idx) return &b[i]; return nullptr; }
static bool allocSetFor(const Layout* L, const Bind* b, int nb, VkDescriptorSet& ds) {
    if (!cf || !L || cf->used >= kRingSlots) { LOG("allocSetFor: no frame / ring exhausted"); return false; }
    VkDescriptorSetAllocateInfo ai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO}; ai.descriptorPool = cf->dp; ai.descriptorSetCount = 1; ai.pSetLayouts = &L->dsl;
    VKC(vkAllocateDescriptorSets(g.dev, &ai, &ds)); cf->used++;
    size_t ni = 0, nbuf = 0; for (auto& d : L->decl) { if (d.type == CIS) ni += d.count; else nbuf++; }
    // Per-pass scratch: stack arrays, NOT std::vector — this runs for every pass of every frame
    // (dozens of times), and the old vector version churned 4 heap allocations per pass.
    // Caps: layout decls are bounded (largest = model splat/pbr, ~40 slots); defensive-fail beyond.
    constexpr int kMaxImg = 64, kMaxBuf = 64, kMaxWrite = 80, kMaxAS = 4;
    if (ni > kMaxImg || nbuf > kMaxBuf || L->decl.size() > kMaxWrite) { LOG("allocSetFor: layout too large (ni=%zu nbuf=%zu decl=%zu)", ni, nbuf, L->decl.size()); return false; }
    VkDescriptorImageInfo ii[kMaxImg]; size_t nii = 0;
    VkDescriptorBufferInfo bi[kMaxBuf]; size_t nbi = 0;
    VkWriteDescriptorSet w[kMaxWrite]; size_t nw = 0;
    VkWriteDescriptorSetAccelerationStructureKHR asw[kMaxAS]; size_t nasw = 0;
    VkAccelerationStructureKHR ash[kMaxAS]; size_t nash = 0;
    for (auto& d : L->decl) {
        VkWriteDescriptorSet x{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET}; x.dstSet = ds; x.dstBinding = d.binding; x.descriptorType = d.type; x.descriptorCount = d.count;
        if (d.type == VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR) {      // ray query b36
            if (nasw >= kMaxAS) { LOG("allocSetFor: too many AS binds"); return false; }
            const Bind* f = findBind(b, nb, d.binding, 0); if (!f || !f->accel) { LOG("allocSetFor: acceleration structure %u not provided", d.binding); return false; }
            ash[nash++] = f->accel;
            VkWriteDescriptorSetAccelerationStructureKHR a{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET_ACCELERATION_STRUCTURE_KHR}; a.accelerationStructureCount = 1; a.pAccelerationStructures = &ash[nash - 1];
            asw[nasw++] = a; x.pNext = &asw[nasw - 1]; w[nw++] = x; continue;
        }
        if (d.type == CIS) {
            size_t base = nii;
            for (uint32_t k = 0; k < d.count; k++) {
                const Bind* f = findBind(b, nb, d.binding, k);
                VkSampler sm = f && f->sampler ? f->sampler : samplerFor(d.samp == Samp::Dynamic ? Samp::LinearClamp : d.samp);   // Dynamic: caller supplies the material sampler
                ii[nii++] = {sm, f && f->view ? f->view : dummyTex.view, f && f->view ? f->layout : VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL};
            }
            x.pImageInfo = &ii[base];
        } else {
            const Bind* f = findBind(b, nb, d.binding, 0); VkDeviceSize off = 0; uint32_t sz = f && f->size ? f->size : 256;
            if (f && f->buffer) { bi[nbi++] = {f->buffer, 0, VK_WHOLE_SIZE}; x.pBufferInfo = &bi[nbi - 1]; w[nw++] = x; continue; }   // persistent buffer (model vertex SSBO)
            if (!f || !f->data) LOG("allocSetFor: buffer binding %u not provided (zero-filled %u bytes)", d.binding, sz);
            if (!arenaPush(f ? f->data : nullptr, sz, off)) return false;
            bi[nbi++] = {cf->ab, off, sz < 16 ? 16 : sz}; x.pBufferInfo = &bi[nbi - 1];
        }
        w[nw++] = x;
    }
    vkUpdateDescriptorSets(g.dev, (uint32_t)nw, w, 0, nullptr); return true;
}
bool encodeFx(VkCommandBuffer cb, Target& t, VkPipeline pso, const Layout* L, bool load, const Bind* binds, int nb, uint32_t vertexCount, uint32_t instanceCount, const VkRect2D* scissor) {
    if (!pso || !L) return false;
    VkDescriptorSet ds; if (!allocSetFor(L, binds, nb, ds)) return false;
    VkClearValue cv{};
    VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO}; rb.renderPass = rpFor(t.fmt, load); rb.framebuffer = t.fb; rb.renderArea = {{0, 0}, {(uint32_t)t.width, (uint32_t)t.height}}; rb.clearValueCount = 1; rb.pClearValues = &cv;
    vkCmdBeginRenderPass(cb, &rb, VK_SUBPASS_CONTENTS_INLINE);
    VkViewport vp{0.f, (float)t.height, (float)t.width, -(float)t.height, 0.f, 1.f}; VkRect2D sc{{0, 0}, {(uint32_t)t.width, (uint32_t)t.height}};   // negative height: y-up like Metal
    if (scissor) sc = *scissor;
    vkCmdSetViewport(cb, 0, 1, &vp); vkCmdSetScissor(cb, 0, 1, &sc);
    vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, pso); vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, L->pl, 0, 1, &ds, 0, nullptr);
    vkCmdDraw(cb, vertexCount, instanceCount, 0, 0); vkCmdEndRenderPass(cb); return true;
}
#include "vk_model.inc"
VkCommandBuffer currentCmd() { return curCb; }
void shutdownLayouts() { for (auto& l : layouts) { vkDestroyPipelineLayout(g.dev, l.second->pl, nullptr); vkDestroyDescriptorSetLayout(g.dev, l.second->dsl, nullptr); delete l.second; } layouts.clear(); }

bool vkInit(ANativeWindow* win, AAssetManager* am) {
    g.win = win; g.am = am;
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO}; app.pApplicationName = "SaikiMotion"; app.apiVersion = VK_API_VERSION_1_1;
    const char* ie[] = {"VK_KHR_surface", "VK_KHR_android_surface"};
    VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO}; ici.pApplicationInfo = &app; ici.enabledExtensionCount = 2; ici.ppEnabledExtensionNames = ie;
    VKC(vkCreateInstance(&ici, nullptr, &g.inst));
    VkAndroidSurfaceCreateInfoKHR sci{VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR}; sci.window = win; VKC(vkCreateAndroidSurfaceKHR(g.inst, &sci, nullptr, &g.surf));
    uint32_t n = 0; vkEnumeratePhysicalDevices(g.inst, &n, nullptr); if (!n) return false; std::vector<VkPhysicalDevice> pds(n); vkEnumeratePhysicalDevices(g.inst, &n, pds.data());
    for (auto pd : pds) {
        uint32_t qn = 0; vkGetPhysicalDeviceQueueFamilyProperties(pd, &qn, nullptr); std::vector<VkQueueFamilyProperties> qp(qn); vkGetPhysicalDeviceQueueFamilyProperties(pd, &qn, qp.data());
        for (uint32_t i = 0; i < qn; i++) { VkBool32 ok = VK_FALSE; vkGetPhysicalDeviceSurfaceSupportKHR(pd, i, g.surf, &ok); if (ok && (qp[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)) { g.pd = pd; g.qf = i; break; } }
        if (g.pd) break;
    }
    if (!g.pd) return false;
    { VkPhysicalDeviceProperties dp; vkGetPhysicalDeviceProperties(g.pd, &dp); strncpy(g.devName, dp.deviceName, sizeof(g.devName) - 1);
      uint32_t en = 0; vkEnumerateDeviceExtensionProperties(g.pd, nullptr, &en, nullptr); std::vector<VkExtensionProperties> ex(en); vkEnumerateDeviceExtensionProperties(g.pd, nullptr, &en, ex.data());
      bool rq = false, as = false; for (auto& e : ex) { if (!strcmp(e.extensionName, "VK_KHR_ray_query")) rq = true; if (!strcmp(e.extensionName, "VK_KHR_acceleration_structure")) as = true; }
      bool bda = false, dho = false, s14 = false, fc = false; for (auto& e : ex) { if (!strcmp(e.extensionName, "VK_KHR_buffer_device_address")) bda = true; if (!strcmp(e.extensionName, "VK_KHR_deferred_host_operations")) dho = true; if (!strcmp(e.extensionName, "VK_KHR_spirv_1_4")) s14 = true; if (!strcmp(e.extensionName, "VK_KHR_shader_float_controls")) fc = true; }
      g.rt = rq && as && bda && dho && s14 && fc; }   // == MetalCore.supportsRaytracing
    VkPhysicalDeviceFeatures have{}, feat{}; vkGetPhysicalDeviceFeatures(g.pd, &have);   // generic passes: aniso (== MSL max_anisotropy(8)), sampler-array indexing (model splat tD/tN/tR)
    feat.samplerAnisotropy = have.samplerAnisotropy; feat.shaderSampledImageArrayDynamicIndexing = have.shaderSampledImageArrayDynamicIndexing; feat.fragmentStoresAndAtomics = VK_FALSE;
    g.aniso = have.samplerAnisotropy; g.arrDyn = have.shaderSampledImageArrayDynamicIndexing;
    float pr = 1.f; VkDeviceQueueCreateInfo qi{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO}; qi.queueFamilyIndex = g.qf; qi.queueCount = 1; qi.pQueuePriorities = &pr;
    // ray query (slice 7o-b): enabled whenever the device has it (iOS: supportsRaytracing); the shader only runs when a layer switches RT on
    std::vector<const char*> de = {"VK_KHR_swapchain"};
    VkPhysicalDeviceBufferDeviceAddressFeatures bdaF{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_BUFFER_DEVICE_ADDRESS_FEATURES}; bdaF.bufferDeviceAddress = VK_TRUE;
    VkPhysicalDeviceAccelerationStructureFeaturesKHR asF{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ACCELERATION_STRUCTURE_FEATURES_KHR}; asF.accelerationStructure = VK_TRUE;
    VkPhysicalDeviceRayQueryFeaturesKHR rqF{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_RAY_QUERY_FEATURES_KHR}; rqF.rayQuery = VK_TRUE;
    VkPhysicalDeviceFeatures2 f2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2}; f2.features = feat;
    if (g.rt) {
        VkPhysicalDeviceBufferDeviceAddressFeatures q1{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_BUFFER_DEVICE_ADDRESS_FEATURES}; VkPhysicalDeviceAccelerationStructureFeaturesKHR q2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ACCELERATION_STRUCTURE_FEATURES_KHR}; VkPhysicalDeviceRayQueryFeaturesKHR q3{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_RAY_QUERY_FEATURES_KHR};
        q1.pNext = &q2; q2.pNext = &q3; VkPhysicalDeviceFeatures2 qf2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2}; qf2.pNext = &q1; vkGetPhysicalDeviceFeatures2(g.pd, &qf2);
        if (q1.bufferDeviceAddress && q2.accelerationStructure && q3.rayQuery) {
            g.rtOn = true; for (auto n : {"VK_KHR_ray_query", "VK_KHR_acceleration_structure", "VK_KHR_deferred_host_operations", "VK_KHR_buffer_device_address", "VK_KHR_spirv_1_4", "VK_KHR_shader_float_controls"}) de.push_back(n);
            bdaF.pNext = &asF; asF.pNext = &rqF; f2.pNext = &bdaF;
            VkPhysicalDeviceAccelerationStructurePropertiesKHR ap{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ACCELERATION_STRUCTURE_PROPERTIES_KHR}; VkPhysicalDeviceProperties2 p2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2}; p2.pNext = &ap; vkGetPhysicalDeviceProperties2(g.pd, &p2);
            g.asAlign = std::max<VkDeviceSize>(ap.minAccelerationStructureScratchOffsetAlignment, 256);
        } else g.rt = false;
    }
    VkDeviceCreateInfo di{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO}; di.queueCreateInfoCount = 1; di.pQueueCreateInfos = &qi; di.enabledExtensionCount = (uint32_t)de.size(); di.ppEnabledExtensionNames = de.data();
    di.pNext = &f2; di.pEnabledFeatures = nullptr;      // features travel in the VkPhysicalDeviceFeatures2 chain
    VKC(vkCreateDevice(g.pd, &di, nullptr, &g.dev)); vkGetDeviceQueue(g.dev, g.qf, 0, &g.q);
    if (g.rtOn) {
        pfnBDA = (PFN_vkGetBufferDeviceAddressKHR)vkGetDeviceProcAddr(g.dev, "vkGetBufferDeviceAddressKHR"); pfnCreateAS = (PFN_vkCreateAccelerationStructureKHR)vkGetDeviceProcAddr(g.dev, "vkCreateAccelerationStructureKHR");
        pfnDestroyAS = (PFN_vkDestroyAccelerationStructureKHR)vkGetDeviceProcAddr(g.dev, "vkDestroyAccelerationStructureKHR"); pfnASSizes = (PFN_vkGetAccelerationStructureBuildSizesKHR)vkGetDeviceProcAddr(g.dev, "vkGetAccelerationStructureBuildSizesKHR");
        pfnBuildAS = (PFN_vkCmdBuildAccelerationStructuresKHR)vkGetDeviceProcAddr(g.dev, "vkCmdBuildAccelerationStructuresKHR");
        pfnBeginRendering = (PFN_vkCmdBeginRenderingKHR_)vkGetDeviceProcAddr(g.dev, "vkCmdBeginRenderingKHR");
        pfnEndRendering = (PFN_vkCmdEndRenderingKHR_)vkGetDeviceProcAddr(g.dev, "vkCmdEndRenderingKHR");
        if (!pfnBDA || !pfnCreateAS || !pfnDestroyAS || !pfnASSizes || !pfnBuildAS) g.rtOn = false;
    }
    VkCommandPoolCreateInfo cpi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO}; cpi.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT; cpi.queueFamilyIndex = g.qf; VKC(vkCreateCommandPool(g.dev, &cpi, nullptr, &g.pool));
    VkCommandBufferAllocateInfo cai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO}; cai.commandPool = g.pool; cai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY; cai.commandBufferCount = kFrames; VKC(vkAllocateCommandBuffers(g.dev, &cai, g.cmd));
    for (int i = 0; i < kFrames; i++) {
        VkSemaphoreCreateInfo s{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO}; VKC(vkCreateSemaphore(g.dev, &s, nullptr, &g.imgAvail[i]));
        VkFenceCreateInfo f{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO}; f.flags = VK_FENCE_CREATE_SIGNALED_BIT; VKC(vkCreateFence(g.dev, &f, nullptr, &g.inFlight[i]));
    }
    // sampler == MSL linearClamp
    VkSamplerCreateInfo smi{VK_STRUCTURE_TYPE_SAMPLER_CREATE_INFO}; smi.magFilter = smi.minFilter = VK_FILTER_LINEAR; smi.addressModeU = smi.addressModeV = smi.addressModeW = VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
    VKC(vkCreateSampler(g.dev, &smi, nullptr, &g.linearClamp));
    // shared set layout for all fullscreen passes: 3 samplers (0..2) + 1 UBO (3)
    VkDescriptorSetLayoutBinding b[4]{}; for (int i = 0; i < 3; i++) { b[i].binding = i; b[i].descriptorType = VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER; b[i].descriptorCount = 1; b[i].stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT; }
    b[3].binding = 3; b[3].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER; b[3].descriptorCount = 1; b[3].stageFlags = VK_SHADER_STAGE_FRAGMENT_BIT;
    VkDescriptorSetLayoutCreateInfo dli{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO}; dli.bindingCount = 4; dli.pBindings = b; VKC(vkCreateDescriptorSetLayout(g.dev, &dli, nullptr, &g.dsl));
    VkPipelineLayoutCreateInfo pli{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO}; pli.setLayoutCount = 1; pli.pSetLayouts = &g.dsl; VKC(vkCreatePipelineLayout(g.dev, &pli, nullptr, &g.pl));
    VkDescriptorPoolSize ps[2] = {{VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 3 * 64}, {VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 64}};
    VkDescriptorPoolCreateInfo dpi{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO}; dpi.maxSets = 64; dpi.poolSizeCount = 2; dpi.pPoolSizes = ps; VKC(vkCreateDescriptorPool(g.dev, &dpi, nullptr, &g.dpool));
    if (!createSwapchain()) return false;
    // smoke test: blit a generated gradient (proves shader loading, negative-height viewport, texture upload, sampler)
    const int W = 256; std::vector<uint8_t> px(W * W * 4);
    for (int y = 0; y < W; y++) for (int x = 0; x < W; x++) { uint8_t* p = &px[(y * W + x) * 4]; p[0] = x; p[1] = y; p[2] = 128; p[3] = 255; }   // R grows right, G grows DOWN
    if (!makeTexture(W, W, px.data(), g.testTex)) return false;
    if (!initRenderCore()) return false;
    LOG("Vulkan: %s, raytracing=%d, selfTest=%d", g.devName, (int)g.rt, (int)selfTest());   // == MetalCore.status / selfTest
    // stage-0 smoke test: testTex -> RGBA16F target (blit pass) -> swapchain (blit pass)
    if (!makeTarget(g.smoke, W, W, true)) return false;
    bool okb = false; runSync([&](VkCommandBuffer c) { okb = blit(c, g.testTex.view, g.smoke); }); if (!okb) return false;
    g.blitPipe = pipelineFor("blit.frag", g.scFmt); if (!g.blitPipe) return false;
    g.ready = true; LOG("Vulkan core ready %ux%u", g.ext.width, g.ext.height); return true;
}
void vkResize(int, int) { g.needSc = true; }
void vkFrame(float) {
    if (!g.ready) return;
    if (g.needSc) { destroySwapchain(); if (!createSwapchain()) return; }
    int f = g.cur; vkWaitForFences(g.dev, 1, &g.inFlight[f], VK_TRUE, UINT64_MAX);
    cf = &fr[f]; resetFrame(*cf);
    VkDescriptorSet ds; { VkImageView v[3] = {g.smoke.tex.view, nullptr, nullptr}; if (!allocSet(v, nullptr, 0, ds)) return; }
    uint32_t idx; VkResult r = vkAcquireNextImageKHR(g.dev, g.sc, UINT64_MAX, g.imgAvail[f], VK_NULL_HANDLE, &idx);
    if (r == VK_ERROR_OUT_OF_DATE_KHR) { g.needSc = true; return; }
    vkResetFences(g.dev, 1, &g.inFlight[f]); VkCommandBuffer c = g.cmd[f]; vkResetCommandBuffer(c, 0);
    VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO}; vkBeginCommandBuffer(c, &bi); curCb = c;
    VkClearValue cv{}; VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO}; rb.renderPass = g.rp; rb.framebuffer = g.fbs[idx]; rb.renderArea = {{0, 0}, g.ext}; rb.clearValueCount = 1; rb.pClearValues = &cv;
    vkCmdBeginRenderPass(c, &rb, VK_SUBPASS_CONTENTS_INLINE);
    VkViewport vp{0.f, (float)g.ext.height, (float)g.ext.width, -(float)g.ext.height, 0.f, 1.f};   // NEGATIVE HEIGHT: y-up NDC == Metal
    VkRect2D sc{{0, 0}, g.ext}; vkCmdSetViewport(c, 0, 1, &vp); vkCmdSetScissor(c, 0, 1, &sc);
    vkCmdBindPipeline(c, VK_PIPELINE_BIND_POINT_GRAPHICS, g.blitPipe);
    vkCmdBindDescriptorSets(c, VK_PIPELINE_BIND_POINT_GRAPHICS, g.pl, 0, 1, &ds, 0, nullptr);
    vkCmdDraw(c, 3, 1, 0, 0); vkCmdEndRenderPass(c); curCb = VK_NULL_HANDLE; vkEndCommandBuffer(c);
    VkPipelineStageFlags ws = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
    VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO}; si.waitSemaphoreCount = 1; si.pWaitSemaphores = &g.imgAvail[f]; si.pWaitDstStageMask = &ws; si.commandBufferCount = 1; si.pCommandBuffers = &c; si.signalSemaphoreCount = 1; si.pSignalSemaphores = &g.renderDone[idx];
    vkQueueSubmit(g.q, 1, &si, g.inFlight[f]);
    VkPresentInfoKHR pi{VK_STRUCTURE_TYPE_PRESENT_INFO_KHR}; pi.waitSemaphoreCount = 1; pi.pWaitSemaphores = &g.renderDone[idx]; pi.swapchainCount = 1; pi.pSwapchains = &g.sc; pi.pImageIndices = &idx;
    r = vkQueuePresentKHR(g.q, &pi); if (r == VK_ERROR_OUT_OF_DATE_KHR || r == VK_SUBOPTIMAL_KHR) g.needSc = true;
    g.cur = (f + 1) % kFrames;
}
void vkDestroy() {
    if (!g.dev) return; vkDeviceWaitIdle(g.dev); g.ready = false; destroySwapchain();
    destroyTarget(g.smoke); shutdownRenderCore();
    vkDestroyDescriptorPool(g.dev, g.dpool, nullptr); vkDestroyPipelineLayout(g.dev, g.pl, nullptr); vkDestroyDescriptorSetLayout(g.dev, g.dsl, nullptr);
    vkDestroyImageView(g.dev, g.testTex.view, nullptr); vkDestroyImage(g.dev, g.testTex.img, nullptr); vkFreeMemory(g.dev, g.testTex.mem, nullptr); vkDestroySampler(g.dev, g.linearClamp, nullptr);
    for (int i = 0; i < kFrames; i++) { vkDestroySemaphore(g.dev, g.imgAvail[i], nullptr); vkDestroyFence(g.dev, g.inFlight[i], nullptr); }
    vkDestroyRenderPass(g.dev, g.rp, nullptr); vkDestroyCommandPool(g.dev, g.pool, nullptr); vkDestroyDevice(g.dev, nullptr);
    vkDestroySurfaceKHR(g.inst, g.surf, nullptr); vkDestroyInstance(g.inst, nullptr); g = G{};
}
} // namespace saiki
