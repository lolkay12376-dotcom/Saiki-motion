#pragma once
#include <android/native_window.h>
#include <android/asset_manager.h>
#include <vulkan/vulkan.h>
#include <vector>
#include <functional>
#include <string>
#include <cstdint>
namespace saiki {
// VK_KHR_dynamic_rendering (Android loader: resolve via vkGetDeviceProcAddr, not link-time)
using PFN_vkCmdBeginRenderingKHR_ = void (*)(VkCommandBuffer, const VkRenderingInfoKHR*);
extern PFN_vkCmdBeginRenderingKHR_ pfnBeginRendering;
using PFN_vkCmdEndRenderingKHR_ = void (*)(VkCommandBuffer);
extern PFN_vkCmdEndRenderingKHR_ pfnEndRendering;
bool vkInit(ANativeWindow* win, AAssetManager* am);
void vkResize(int w, int h);
void vkFrame(float t);
void vkDestroy();

// ---- render core (port of MetalCore/MetalTarget/MetalPasses) ----
struct Tex { VkImage img = VK_NULL_HANDLE; VkDeviceMemory mem = VK_NULL_HANDLE; VkImageView view = VK_NULL_HANDLE; };
// == MetalPasses.swift FxCommon (std140, 48 bytes). Same defaults.
struct FxCommon { float res[2] = {1, 1}; float lc[2] = {0, 0}; float lx[2] = {2, 0}; float ly[2] = {0, 2}; float time = 0, has0 = 0, has1 = 0, pad = 0; };
struct CompParams { float alpha, mode, maskMode, rgbShift; };   // == MetalPasses.swift CompParams
// == MetalTarget: half ? RGBA16F : RGBA8. `tex`/`fb` swap together (composite swaps two targets instead of copying).
struct Target { int width = 1, height = 1; bool half = false; VkFormat fmt = VK_FORMAT_R8G8B8A8_UNORM; Tex tex; VkFramebuffer fb = VK_NULL_HANDLE; };

bool makeTarget(Target& t, int w, int h, bool half = false);
void destroyTarget(Target& t);
bool readTarget(Target& t, std::vector<uint8_t>& rgba);               // == MetalTarget.readImage (RGBA8 only, top row first)
bool uploadTexture(int w, int h, const uint8_t* rgbaTopRowFirst, Tex& t);   // == MetalPasses.makeTexture
void destroyTex(Tex& t);
VkImageView dummyView();                                              // == MetalPasses.dummy (1x1 transparent)
VkPipeline pipelineFor(const char* fragName, VkFormat fmt, bool over = false);   // == MetalPasses.pipeline/pipelineOver; fragName e.g. "blit.frag"
// == MetalPasses.encode (load=false: clear 0,0,0,0) / encodeLoad (load=true). Texture slots 0..2 (null -> dummy), ubo at binding 3 (<=256 bytes).
bool encodePass(VkCommandBuffer cb, Target& t, VkPipeline pso, bool load, VkImageView v0, VkImageView v1 = VK_NULL_HANDLE, VkImageView v2 = VK_NULL_HANDLE, const void* ubo = nullptr, uint32_t uboSize = 0);
bool blit(VkCommandBuffer cb, VkImageView src, Target& to);
bool composite(VkCommandBuffer cb, VkImageView scene, VkImageView src, VkImageView mask, float alpha, int mode, int maskMode, float rgbShift, Target& out);
bool composite(VkCommandBuffer cb, Target& target, Target& scratch, VkImageView src, VkImageView mask, float alpha, int mode, int maskMode = 0, float rgbShift = 0);
void runSync(const std::function<void(VkCommandBuffer)>& body);      // == MetalPasses.runSync
bool selfTest();

// ---- generic per-shader layouts / pipelines / passes (slice 5; textures b0.., UBO b8, extra buffers per shader header) ----
enum class Samp : uint8_t { LinearClamp, NearestClamp, LinearRepeat, LinearMipRepeat, Aniso8MipRepeat, LinearMipClamp, Dynamic, Aniso4MipRepeat, Aniso4MipClamp };   // MSL constexpr samplers; Dynamic = caller-supplied (per-material); Aniso4* = MetalModel.swift:1103 per-material samplers (linear+mip+aniso4, repeat or clamp)
struct BindDecl { uint32_t binding; VkDescriptorType type; uint32_t count; VkShaderStageFlags stages; Samp samp; };
struct Layout { VkDescriptorSetLayout dsl = VK_NULL_HANDLE; VkPipelineLayout pl = VK_NULL_HANDLE; std::vector<BindDecl> decl; };
// One bound resource. Textures: view (+optional sampler/layout; depth views need VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL). UBO/SSBO: data+size copied into the per-frame arena. Arrays: index = element.
struct Bind { uint32_t binding = 0; uint32_t index = 0; VkImageView view = VK_NULL_HANDLE; VkSampler sampler = VK_NULL_HANDLE; VkImageLayout layout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL; const void* data = nullptr; uint32_t size = 0; VkBuffer buffer = VK_NULL_HANDLE; /* persistent SSBO/UBO (e.g. model vertex buffer, b34); wins over data */ VkAccelerationStructureKHR accel = VK_NULL_HANDLE; /* RT: acceleration structure (b36) */ };
struct PipeDesc { const char* vert = "fs.vert"; const char* frag = nullptr; const Layout* layout = nullptr; VkFormat fmt = VK_FORMAT_R16G16B16A16_SFLOAT; bool over = false; VkPrimitiveTopology topo = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST; };
VkSampler sampler(Samp s);
const Layout* layoutFor(const char* key, const std::vector<BindDecl>& decl);
const Layout* fxLayout(int nTex);                       // b0..nTex-1 textures + UBO b8
const Layout* layoutForShader(const char* fragOrVertName);   // layouts of all ported GLSL (glow*, vdb, flare, particle, mesh/warp, quad/shape, plane*, waterUnder, model); nullptr = old std layout
const Layout* stdLayout();                              // old 3 tex + UBO b3 (blit/composite)
VkPipeline pipelineForDesc(const PipeDesc& d);
VkPipeline pipelineForFile(const char* vert, const char* frag, VkFormat fmt, bool over = false, VkPrimitiveTopology topo = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST);   // == MetalPasses libKey path (external shader files)
bool encodeFx(VkCommandBuffer cb, Target& t, VkPipeline pso, const Layout* L, bool load, const Bind* binds, int nBinds, uint32_t vertexCount = 3, uint32_t instanceCount = 1, const VkRect2D* scissor = nullptr);   // scissor: top-left origin like MTLScissorRect                                                      // == MetalCore.selfTest

// ---- model renderer primitives (vk_model.inc, slice 7l) ----
struct Buf { VkBuffer buf = VK_NULL_HANDLE; VkDeviceMemory mem = VK_NULL_HANDLE; VkDeviceSize size = 0; };
struct DepthTex { int w = 0, h = 0; Tex tex; };   // D32_SFLOAT, rests in DEPTH_STENCIL_READ_ONLY (== MetalModelRenderer.depth)
struct ModelDraw { VkPipeline pso = VK_NULL_HANDLE; const Layout* layout = nullptr; const Bind* binds = nullptr; int nBinds = 0; VkBuffer ib = VK_NULL_HANDLE; bool idx32 = true; uint32_t indexCount = 0; uint32_t instances = 1; uint32_t vertexCount = 0; /* >0 and no ib: non-indexed (waterUnder full-screen triangle) */ bool bias = false; /* MetalModel.swift:1401: collider depth bias (4, 4), clamp 0 */ };
// ---- ray query (slice 7o-b): == MTLAccelerationStructure (primitive, opaque triangles) built from the model's vertex/index buffers ----
struct Accel { VkAccelerationStructureKHR as = VK_NULL_HANDLE; VkBuffer buf = VK_NULL_HANDLE; VkDeviceMemory mem = VK_NULL_HANDLE; VkBuffer sbuf = VK_NULL_HANDLE; VkDeviceMemory smem = VK_NULL_HANDLE; };
bool rtEnabled();                                                   // VK_KHR_ray_query + acceleration_structure + bufferDeviceAddress enabled on the device
Accel* buildAccel(VkCommandBuffer cb, const Buf* const* vb, const Buf* const* ib, const int* idx32, const int* tris, int n);   // == MetalModelRenderer.buildAccel (stride 48, float3 at 0)
void retireAccel(Accel* a);                                         // freed once the frame that may still read it has finished
bool makeBufferData(const void* data, VkDeviceSize size, VkBufferUsageFlags usage, Buf& b);
void destroyBuf(Buf& b);
bool uploadTextureMips(int w, int h, const uint8_t* rgbaTopRowFirst, Tex& t);   // == MetalModel.makeTexture GPU part
bool uploadEnvTex(int w, int h, const uint16_t* rgba16, Tex& t, int* outMips = nullptr);  // == GlobalEnv.tex: RGBA16F equirect + full mip chain (outMips = mipmapLevelCount)
bool makeDepth(DepthTex& d, int w, int h);
void destroyDepth(DepthTex& d);
VkPipeline modelPipeline(const char* frag, VkFormat fmt, bool blend, bool depthOnly, bool depthWrite, bool points, const char* vert = "model.vert", bool always = false, bool rtLayout = false);   // == MetalModelRenderer.pso + dsWrite/dsNoWrite
VkCommandBuffer currentCmd();   // recording command buffer (null outside vkFrame/runSync)
void copyDepth(VkCommandBuffer c, DepthTex& src, DepthTex& dst);
bool encodePlaneDepth(VkCommandBuffer cb, DepthTex& d, bool clearDepth, const Layout* L, const Bind* binds, int nBinds);
bool encodeModelPass(VkCommandBuffer cb, Target& t, DepthTex& d, bool clearDepth, const ModelDraw* draws, int n);

// ---- effect runtime (fx_runtime.cpp == MetalEffects) ----
struct FxStep { std::string key; std::vector<float> props; std::vector<float> colors /* 4 floats per colour */; VkImageView in0 = VK_NULL_HANDLE, in1 = VK_NULL_HANDLE; };
bool fxPrepare(const std::string& key, const std::string& glsl450, const std::string& name);   // idempotent; async shaderc compile
int fxStatus(const std::string& key);                   // -1 unknown, 0 compiling, 1 ready, 2 failed
std::string fxError(const std::string& key);
int fxReadyCount();
bool fxSpv(const std::string& name, std::vector<uint32_t>& out);   // "shaders/fx/<key>.spv" -> runtime SPIR-V
bool fxApply(VkCommandBuffer cb, const FxStep& step, VkImageView src, Target& out, float time, const float* rect = nullptr);
Target& fxApplyChain(VkCommandBuffer cb, const std::vector<FxStep>& steps, Target& a, Target& b, float time, const float* rect = nullptr);
}
