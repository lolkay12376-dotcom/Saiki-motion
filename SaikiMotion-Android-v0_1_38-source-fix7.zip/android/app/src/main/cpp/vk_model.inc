// Included from vk_core.cpp inside namespace saiki (needs the anonymous-namespace internals: g, cf, findMem, makeBuffer, oneShot*, barrier, rpFor, shaderMod, allocSetFor).
// Vulkan primitives for MetalModelRenderer (MetalModel.swift): depth target, persistent buffers, mipped textures, depth pass with N draws, model pipelines.
// Slices 7m-7o done: JNI surface (jni_model.cpp) + Kotlin orchestration (core/MetalModelDraw.kt).

// ---- persistent host-visible buffers (MTLBuffer .storageModeShared). TODO(parity): device-local + staging for large meshes. ----
bool makeBufferData(const void* data, VkDeviceSize size, VkBufferUsageFlags usage, Buf& b) {
    if (size == 0) size = 16;
    if (g.rtOn) usage |= VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT | VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT_KHR;   // vertex/index buffers feed the BLAS build
    if (!makeBuffer(size, usage, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, b.buf, b.mem)) return false;
    b.size = size;
    if (data) { void* p; if (vkMapMemory(g.dev, b.mem, 0, size, 0, &p) != VK_SUCCESS) return false; memcpy(p, data, size); vkUnmapMemory(g.dev, b.mem); }
    return true;
}
void destroyBuf(Buf& b) { if (!g.dev) return; vkDeviceWaitIdle(g.dev); if (b.buf) vkDestroyBuffer(g.dev, b.buf, nullptr); if (b.mem) vkFreeMemory(g.dev, b.mem, nullptr); b = Buf{}; }

// ---- ray query: == MetalModelRenderer.buildAccel. One primitive AS, every non-point primitive of the model as an opaque triangle geometry
//      (vertex stride 48 = 12 floats, position = float3 at offset 0, 16/32-bit indices). Recorded into `cb` (outside a render pass); the build barrier makes it
//      visible to the fragment shader's ray queries. Scratch buffer is kept inside the Accel and freed with it. ----
bool rtEnabled() { return g.rtOn; }
static VkDeviceAddress bufAddr(VkBuffer b) { VkBufferDeviceAddressInfo i{VK_STRUCTURE_TYPE_BUFFER_DEVICE_ADDRESS_INFO}; i.buffer = b; return pfnBDA(g.dev, &i); }
Accel* buildAccel(VkCommandBuffer cb, const Buf* const* vb, const Buf* const* ib, const int* idx32, const int* tris, int n) {
    if (!g.rtOn || !cb || n <= 0) return nullptr;
    std::vector<VkAccelerationStructureGeometryKHR> geo((size_t)n); std::vector<VkAccelerationStructureBuildRangeInfoKHR> rng((size_t)n); std::vector<uint32_t> cnt((size_t)n);
    for (int i = 0; i < n; i++) {
        geo[i] = VkAccelerationStructureGeometryKHR{VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_KHR}; geo[i].geometryType = VK_GEOMETRY_TYPE_TRIANGLES_KHR; geo[i].flags = VK_GEOMETRY_OPAQUE_BIT_KHR;
        auto& t = geo[i].geometry.triangles; t.sType = VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_TRIANGLES_DATA_KHR;
        t.vertexFormat = VK_FORMAT_R32G32B32_SFLOAT; t.vertexData.deviceAddress = bufAddr(vb[i]->buf); t.vertexStride = 48; t.maxVertex = (uint32_t)(vb[i]->size / 48) - 1;
        t.indexType = idx32[i] ? VK_INDEX_TYPE_UINT32 : VK_INDEX_TYPE_UINT16; t.indexData.deviceAddress = bufAddr(ib[i]->buf);
        rng[i] = {}; rng[i].primitiveCount = (uint32_t)tris[i]; cnt[i] = (uint32_t)tris[i];
    }
    VkAccelerationStructureBuildGeometryInfoKHR bi{VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_GEOMETRY_INFO_KHR}; bi.type = VK_ACCELERATION_STRUCTURE_TYPE_BOTTOM_LEVEL_KHR; bi.flags = VK_BUILD_ACCELERATION_STRUCTURE_PREFER_FAST_TRACE_BIT_KHR;
    bi.mode = VK_BUILD_ACCELERATION_STRUCTURE_MODE_BUILD_KHR; bi.geometryCount = (uint32_t)n; bi.pGeometries = geo.data();
    VkAccelerationStructureBuildSizesInfoKHR sz{VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_SIZES_INFO_KHR}; pfnASSizes(g.dev, VK_ACCELERATION_STRUCTURE_BUILD_TYPE_DEVICE_KHR, &bi, cnt.data(), &sz);
    Accel* a = new Accel();
    if (!makeBuffer(sz.accelerationStructureSize, VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_STORAGE_BIT_KHR | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, a->buf, a->mem)) { freeAccel(a); return nullptr; }
    VkAccelerationStructureCreateInfoKHR ci{VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_CREATE_INFO_KHR}; ci.buffer = a->buf; ci.size = sz.accelerationStructureSize; ci.type = VK_ACCELERATION_STRUCTURE_TYPE_BOTTOM_LEVEL_KHR;
    if (pfnCreateAS(g.dev, &ci, nullptr, &a->as) != VK_SUCCESS) { freeAccel(a); return nullptr; }
    if (!makeBuffer(sz.buildScratchSize + g.asAlign, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, a->sbuf, a->smem)) { freeAccel(a); return nullptr; }
    VkDeviceAddress sa = bufAddr(a->sbuf); sa = (sa + g.asAlign - 1) / g.asAlign * g.asAlign;
    bi.dstAccelerationStructure = a->as; bi.scratchData.deviceAddress = sa;
    const VkAccelerationStructureBuildRangeInfoKHR* pr = rng.data(); pfnBuildAS(cb, 1, &bi, &pr);
    VkMemoryBarrier mb{VK_STRUCTURE_TYPE_MEMORY_BARRIER}; mb.srcAccessMask = VK_ACCESS_ACCELERATION_STRUCTURE_WRITE_BIT_KHR; mb.dstAccessMask = VK_ACCESS_ACCELERATION_STRUCTURE_READ_BIT_KHR;
    vkCmdPipelineBarrier(cb, VK_PIPELINE_STAGE_ACCELERATION_STRUCTURE_BUILD_BIT_KHR, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, 0, 1, &mb, 0, nullptr, 0, nullptr);
    return a;
}
void retireAccel(Accel* a) {
    if (!a) return;
    if (cf) asTrash[cf - fr].push_back(a);       // a command buffer of this frame may still read it
    else { vkDeviceWaitIdle(g.dev); freeAccel(a); }
}

// ---- == GlobalEnv.tex (Metal): RGBA16F equirect, level 0 uploaded, full mip chain via linear blits ----
// outMips (optional) receives the mip level count (== MTLTexture.mipmapLevelCount).
bool uploadEnvTex(int w, int h, const uint16_t* rgba16, Tex& t, int* outMips) {
    uint32_t mips = 1; for (int m = std::max(w, h); m > 1; m >>= 1) mips++;
    VkImageCreateInfo ii{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO}; ii.imageType = VK_IMAGE_TYPE_2D; ii.format = VK_FORMAT_R16G16B16A16_SFLOAT;
    ii.extent = {(uint32_t)w, (uint32_t)h, 1}; ii.mipLevels = mips; ii.arrayLayers = 1; ii.samples = VK_SAMPLE_COUNT_1_BIT; ii.tiling = VK_IMAGE_TILING_OPTIMAL;
    ii.usage = VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT; ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    VKC(vkCreateImage(g.dev, &ii, nullptr, &t.img));
    VkMemoryRequirements r; vkGetImageMemoryRequirements(g.dev, t.img, &r);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO}; ai.allocationSize = r.size; ai.memoryTypeIndex = findMem(r.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VKC(vkAllocateMemory(g.dev, &ai, nullptr, &t.mem)); VKC(vkBindImageMemory(g.dev, t.img, t.mem, 0));
    VkBuffer sb; VkDeviceMemory sm; VkDeviceSize sz = (VkDeviceSize)w * h * 8;
    if (!makeBuffer(sz, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, sb, sm)) return false;
    void* p; vkMapMemory(g.dev, sm, 0, sz, 0, &p); memcpy(p, rgba16, sz); vkUnmapMemory(g.dev, sm);
    VkCommandBuffer c = oneShotBegin();
    auto bar = [&](uint32_t base, uint32_t cnt, VkImageLayout from, VkImageLayout to, VkAccessFlags sa, VkAccessFlags da, VkPipelineStageFlags ss, VkPipelineStageFlags ds) {
        VkImageMemoryBarrier b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER}; b.oldLayout = from; b.newLayout = to; b.srcAccessMask = sa; b.dstAccessMask = da;
        b.srcQueueFamilyIndex = b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED; b.image = t.img; b.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, base, cnt, 0, 1};
        vkCmdPipelineBarrier(c, ss, ds, 0, 0, nullptr, 0, nullptr, 1, &b);
    };
    bar(0, mips, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 0, VK_ACCESS_TRANSFER_WRITE_BIT, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
    VkBufferImageCopy rg{}; rg.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1}; rg.imageExtent = {(uint32_t)w, (uint32_t)h, 1};
    vkCmdCopyBufferToImage(c, sb, t.img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &rg);
    int mw = w, mh = h;
    for (uint32_t i = 1; i < mips; i++) {
        bar(i - 1, 1, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_TRANSFER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
        int nw = std::max(1, mw / 2), nh = std::max(1, mh / 2);
        VkImageBlit bl{}; bl.srcSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, i - 1, 0, 1}; bl.srcOffsets[1] = {mw, mh, 1};
        bl.dstSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, i, 0, 1}; bl.dstOffsets[1] = {nw, nh, 1};
        vkCmdBlitImage(c, t.img, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, t.img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &bl, VK_FILTER_LINEAR);
        mw = nw; mh = nh;
    }
    if (mips > 1) bar(0, mips - 1, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, VK_ACCESS_TRANSFER_READ_BIT, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    bar(mips - 1, 1, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    oneShotEnd(c); vkDestroyBuffer(g.dev, sb, nullptr); vkFreeMemory(g.dev, sm, nullptr);
    VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO}; vi.image = t.img; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = ii.format;
    vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, mips, 0, 1}; VKC(vkCreateImageView(g.dev, &vi, nullptr, &t.view));
    if (outMips) *outMips = (int)mips;
    return true;
}

// ---- == MetalModel.makeTexture GPU part: RGBA8 with a full mip chain (generateMipmaps = linear blits) ----
bool uploadTextureMips(int w, int h, const uint8_t* rgba, Tex& t) {
    uint32_t mips = 1; for (int m = std::max(w, h); m > 1; m >>= 1) mips++;
    VkImageCreateInfo ii{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO}; ii.imageType = VK_IMAGE_TYPE_2D; ii.format = VK_FORMAT_R8G8B8A8_UNORM;
    ii.extent = {(uint32_t)w, (uint32_t)h, 1}; ii.mipLevels = mips; ii.arrayLayers = 1; ii.samples = VK_SAMPLE_COUNT_1_BIT; ii.tiling = VK_IMAGE_TILING_OPTIMAL;
    ii.usage = VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_SAMPLED_BIT; ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    VKC(vkCreateImage(g.dev, &ii, nullptr, &t.img));
    VkMemoryRequirements r; vkGetImageMemoryRequirements(g.dev, t.img, &r);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO}; ai.allocationSize = r.size; ai.memoryTypeIndex = findMem(r.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VKC(vkAllocateMemory(g.dev, &ai, nullptr, &t.mem)); VKC(vkBindImageMemory(g.dev, t.img, t.mem, 0));
    VkBuffer sb; VkDeviceMemory sm; VkDeviceSize sz = (VkDeviceSize)w * h * 4;
    if (!makeBuffer(sz, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, sb, sm)) return false;
    void* p; vkMapMemory(g.dev, sm, 0, sz, 0, &p); memcpy(p, rgba, sz); vkUnmapMemory(g.dev, sm);
    VkCommandBuffer c = oneShotBegin();
    auto bar = [&](uint32_t base, uint32_t cnt, VkImageLayout from, VkImageLayout to, VkAccessFlags sa, VkAccessFlags da, VkPipelineStageFlags ss, VkPipelineStageFlags ds) {
        VkImageMemoryBarrier b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER}; b.oldLayout = from; b.newLayout = to; b.srcAccessMask = sa; b.dstAccessMask = da;
        b.srcQueueFamilyIndex = b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED; b.image = t.img; b.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, base, cnt, 0, 1};
        vkCmdPipelineBarrier(c, ss, ds, 0, 0, nullptr, 0, nullptr, 1, &b);
    };
    bar(0, mips, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 0, VK_ACCESS_TRANSFER_WRITE_BIT, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
    VkBufferImageCopy rg{}; rg.imageSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1}; rg.imageExtent = {(uint32_t)w, (uint32_t)h, 1};
    vkCmdCopyBufferToImage(c, sb, t.img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &rg);
    int mw = w, mh = h;
    for (uint32_t i = 1; i < mips; i++) {
        bar(i - 1, 1, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_TRANSFER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
        int nw = std::max(1, mw / 2), nh = std::max(1, mh / 2);
        VkImageBlit bl{}; bl.srcSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, i - 1, 0, 1}; bl.srcOffsets[1] = {mw, mh, 1};
        bl.dstSubresource = {VK_IMAGE_ASPECT_COLOR_BIT, i, 0, 1}; bl.dstOffsets[1] = {nw, nh, 1};
        vkCmdBlitImage(c, t.img, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, t.img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &bl, VK_FILTER_LINEAR);
        mw = nw; mh = nh;
    }
    if (mips > 1) bar(0, mips - 1, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, VK_ACCESS_TRANSFER_READ_BIT, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    bar(mips - 1, 1, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL, VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_SHADER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
    oneShotEnd(c); vkDestroyBuffer(g.dev, sb, nullptr); vkFreeMemory(g.dev, sm, nullptr);
    VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO}; vi.image = t.img; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = ii.format;
    vi.subresourceRange = {VK_IMAGE_ASPECT_COLOR_BIT, 0, mips, 0, 1}; VKC(vkCreateImageView(g.dev, &vi, nullptr, &t.view)); return true;
}

// ---- depth32Float target (== MetalModelRenderer.depth: renderTarget + shaderRead). Rests in DEPTH_STENCIL_READ_ONLY between passes. ----
bool makeDepth(DepthTex& d, int w, int h) {
    d.w = std::max(1, w); d.h = std::max(1, h);
    VkImageCreateInfo ii{VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO}; ii.imageType = VK_IMAGE_TYPE_2D; ii.format = VK_FORMAT_D32_SFLOAT; ii.extent = {(uint32_t)d.w, (uint32_t)d.h, 1};
    ii.mipLevels = 1; ii.arrayLayers = 1; ii.samples = VK_SAMPLE_COUNT_1_BIT; ii.tiling = VK_IMAGE_TILING_OPTIMAL; ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    ii.usage = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT | VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;   // DST: depth snapshot copy (water)
    VKC(vkCreateImage(g.dev, &ii, nullptr, &d.tex.img));
    VkMemoryRequirements r; vkGetImageMemoryRequirements(g.dev, d.tex.img, &r);
    VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO}; ai.allocationSize = r.size; ai.memoryTypeIndex = findMem(r.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    VKC(vkAllocateMemory(g.dev, &ai, nullptr, &d.tex.mem)); VKC(vkBindImageMemory(g.dev, d.tex.img, d.tex.mem, 0));
    VkImageViewCreateInfo vi{VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO}; vi.image = d.tex.img; vi.viewType = VK_IMAGE_VIEW_TYPE_2D; vi.format = ii.format;
    vi.subresourceRange = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 1, 0, 1}; VKC(vkCreateImageView(g.dev, &vi, nullptr, &d.tex.view));
    VkCommandBuffer c = oneShotBegin();
    VkImageMemoryBarrier b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER}; b.oldLayout = VK_IMAGE_LAYOUT_UNDEFINED; b.newLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
    b.dstAccessMask = VK_ACCESS_SHADER_READ_BIT; b.srcQueueFamilyIndex = b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED; b.image = d.tex.img; b.subresourceRange = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 1, 0, 1};
    vkCmdPipelineBarrier(c, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT, 0, 0, nullptr, 0, nullptr, 1, &b);
    oneShotEnd(c); return true;
}
void destroyDepth(DepthTex& d) { if (!g.dev) return; vkDeviceWaitIdle(g.dev); destroyTex(d.tex); d.w = d.h = 0; }

// ---- render pass colour(+LOAD) + depth32 (clear or load); framebuffers are per pass and freed when the frame slot is reused ----
static std::map<int, VkRenderPass> rpModelCache;
static VkRenderPass rpModel(VkFormat f, bool loadColor, bool clearDepth) {
    int key = (int)f * 4 + (loadColor ? 2 : 0) + (clearDepth ? 1 : 0);
    auto it = rpModelCache.find(key); if (it != rpModelCache.end()) return it->second;
    VkAttachmentDescription a[2]{};
    a[0].format = f; a[0].samples = VK_SAMPLE_COUNT_1_BIT; a[0].loadOp = loadColor ? VK_ATTACHMENT_LOAD_OP_LOAD : VK_ATTACHMENT_LOAD_OP_CLEAR; a[0].storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    a[0].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE; a[0].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    a[0].initialLayout = loadColor ? VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL : VK_IMAGE_LAYOUT_UNDEFINED; a[0].finalLayout = VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
    a[1].format = VK_FORMAT_D32_SFLOAT; a[1].samples = VK_SAMPLE_COUNT_1_BIT; a[1].loadOp = clearDepth ? VK_ATTACHMENT_LOAD_OP_CLEAR : VK_ATTACHMENT_LOAD_OP_LOAD; a[1].storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    a[1].stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE; a[1].stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    a[1].initialLayout = clearDepth ? VK_IMAGE_LAYOUT_UNDEFINED : VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL; a[1].finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
    VkAttachmentReference cr{0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL}, dr{1, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
    VkSubpassDescription sp{}; sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS; sp.colorAttachmentCount = 1; sp.pColorAttachments = &cr; sp.pDepthStencilAttachment = &dr;
    VkSubpassDependency d[2]{};
    d[0].srcSubpass = VK_SUBPASS_EXTERNAL; d[0].dstSubpass = 0;
    d[0].srcStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT | VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT | VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT;
    d[0].dstStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT | VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT;
    d[0].srcAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
    d[0].dstAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_COLOR_ATTACHMENT_READ_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_READ_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
    d[1].srcSubpass = 0; d[1].dstSubpass = VK_SUBPASS_EXTERNAL;
    d[1].srcStageMask = VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT | VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT; d[1].dstStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT | VK_PIPELINE_STAGE_TRANSFER_BIT;
    d[1].srcAccessMask = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT; d[1].dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_TRANSFER_READ_BIT;
    VkRenderPassCreateInfo ri{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO}; ri.attachmentCount = 2; ri.pAttachments = a; ri.subpassCount = 1; ri.pSubpasses = &sp; ri.dependencyCount = 2; ri.pDependencies = d;
    VkRenderPass rp = VK_NULL_HANDLE; if (vkCreateRenderPass(g.dev, &ri, nullptr, &rp) != VK_SUCCESS) { LOG("rpModel failed"); return VK_NULL_HANDLE; }
    rpModelCache[key] = rp; return rp;
}

// ---- == MetalModelRenderer.pso(blend:format:rt:depthOnly:). frag "model.frag" (+ "model_rt.frag" for the ray-query variant); depthOnly = vertex only, colour write mask 0.
//      Metal keeps depth state out of the pipeline (dsWrite/dsNoWrite): Vulkan bakes it in, so depthWrite is part of the key. ----
VkPipeline modelPipeline(const char* frag, VkFormat fmt, bool blend, bool depthOnly, bool depthWrite, bool points, const char* vert, bool always, bool rtLayout) {
    if (rtLayout && !g.rtOn) return VK_NULL_HANDLE;
    const Layout* L = layoutForShader(rtLayout ? "model_rt" : vert); if (!L) return VK_NULL_HANDLE;   // every pipeline drawn in an RT pass shares the RT set layout (incl. depth-only colliders)
    std::string key = std::string("M/") + vert + "/" + frag + "/" + (always ? "A" : "L") + (rtLayout ? "R" : "N") + "/" + std::to_string((int)fmt) + "/" + std::to_string(blend) + std::to_string(depthOnly) + std::to_string(depthWrite) + std::to_string(points);
    auto it = pipes.find(key); if (it != pipes.end()) return it->second;
    VkRenderPass rp = rpModel(fmt, true, false); if (!rp) return VK_NULL_HANDLE;   // pipeline is compatible with every clear/load variant of the same formats
    VkShaderModule vs = shaderMod((std::string("shaders/") + vert + ".spv").c_str()), fs = depthOnly ? VK_NULL_HANDLE : shaderMod((std::string("shaders/") + frag + ".spv").c_str());
    if (!vs || (!depthOnly && !fs)) { if (vs) vkDestroyShaderModule(g.dev, vs, nullptr); if (fs) vkDestroyShaderModule(g.dev, fs, nullptr); return VK_NULL_HANDLE; }
    VkPipelineShaderStageCreateInfo st[2]{}; st[0].sType = st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[0].stage = VK_SHADER_STAGE_VERTEX_BIT; st[0].module = vs; st[0].pName = "main"; st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT; st[1].module = fs; st[1].pName = "main";
    VkPipelineVertexInputStateCreateInfo vin{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};   // vertices come from SSBO b34
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO}; ia.topology = points ? VK_PRIMITIVE_TOPOLOGY_POINT_LIST : VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO}; vp.viewportCount = vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO}; rs.polygonMode = VK_POLYGON_MODE_FILL; rs.cullMode = VK_CULL_MODE_NONE; rs.lineWidth = 1.f;   // setCullMode(.none) (MetalModel.swift:1330)
    rs.depthBiasEnable = VK_TRUE;      // per-draw dynamic state (MetalModel.swift:1401: collider 4/4/0, everything else 0/0/0)
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO}; ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineDepthStencilStateCreateInfo dss{VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO}; dss.depthTestEnable = VK_TRUE; dss.depthWriteEnable = depthWrite ? VK_TRUE : VK_FALSE; dss.depthCompareOp = always ? VK_COMPARE_OP_ALWAYS : VK_COMPARE_OP_LESS_OR_EQUAL;
    VkPipelineColorBlendAttachmentState cba{}; cba.colorWriteMask = depthOnly ? 0 : 0xF;
    if (blend && !depthOnly) { cba.blendEnable = VK_TRUE; cba.colorBlendOp = cba.alphaBlendOp = VK_BLEND_OP_ADD; cba.srcColorBlendFactor = cba.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE; cba.dstColorBlendFactor = cba.dstAlphaBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA; }
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO}; cb.attachmentCount = 1; cb.pAttachments = &cba;
    VkDynamicState dyn[3] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR, VK_DYNAMIC_STATE_DEPTH_BIAS};   // depth bias: collider pushes back 4/4/0 (MetalModel.swift:1401)
    VkPipelineDynamicStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO}; ds.dynamicStateCount = 3; ds.pDynamicStates = dyn;
    VkGraphicsPipelineCreateInfo pi{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO}; pi.stageCount = depthOnly ? 1 : 2; pi.pStages = st; pi.pVertexInputState = &vin; pi.pInputAssemblyState = &ia;
    pi.pViewportState = &vp; pi.pRasterizationState = &rs; pi.pMultisampleState = &ms; pi.pDepthStencilState = &dss; pi.pColorBlendState = &cb; pi.pDynamicState = &ds; pi.layout = L->pl; pi.renderPass = rp;
    VkPipeline out = VK_NULL_HANDLE; VkResult r = vkCreateGraphicsPipelines(g.dev, VK_NULL_HANDLE, 1, &pi, nullptr, &out);
    vkDestroyShaderModule(g.dev, vs, nullptr); if (fs) vkDestroyShaderModule(g.dev, fs, nullptr);
    if (r != VK_SUCCESS) { LOG("model pipeline %s failed %d", frag, (int)r); return VK_NULL_HANDLE; }
    pipes[key] = out; return out;
}

// ---- one render pass: colour LOADed (the caller cleared it), depth cleared to 1.0 when clearDepth else loaded; N indexed draws, each with its own descriptor set ----
bool encodeModelPass(VkCommandBuffer cb, Target& t, DepthTex& d, bool clearDepth, const ModelDraw* draws, int n) {
    if (!cf || d.w != t.width || d.h != t.height) return false;
    VkRenderPass rp = rpModel(t.fmt, true, clearDepth); if (!rp) return false;
    VkImageView att[2] = {t.tex.view, d.tex.view};
    VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO}; fi.renderPass = rp; fi.attachmentCount = 2; fi.pAttachments = att; fi.width = t.width; fi.height = t.height; fi.layers = 1;
    VkFramebuffer fb; if (vkCreateFramebuffer(g.dev, &fi, nullptr, &fb) != VK_SUCCESS) return false;
    fbTrash[cf - fr].push_back(fb);
    VkClearValue cv[2]{}; cv[1].depthStencil = {1.f, 0};
    VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO}; rb.renderPass = rp; rb.framebuffer = fb; rb.renderArea = {{0, 0}, {(uint32_t)t.width, (uint32_t)t.height}}; rb.clearValueCount = 2; rb.pClearValues = cv;
    vkCmdBeginRenderPass(cb, &rb, VK_SUBPASS_CONTENTS_INLINE);
    VkViewport vp{0.f, (float)t.height, (float)t.width, -(float)t.height, 0.f, 1.f}; VkRect2D sc{{0, 0}, {(uint32_t)t.width, (uint32_t)t.height}};   // negative height: y-up like Metal
    vkCmdSetViewport(cb, 0, 1, &vp); vkCmdSetScissor(cb, 0, 1, &sc);
    for (int i = 0; i < n; i++) {
        const ModelDraw& m = draws[i]; if (!m.pso || !m.layout || (!m.ib && !m.vertexCount)) continue;
        VkDescriptorSet ds; if (!allocSetFor(m.layout, m.binds, m.nBinds, ds)) continue;
        vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, m.pso);
        vkCmdSetDepthBias(cb, m.bias ? 4.f : 0.f, m.bias ? 4.f : 0.f, 0.f);   // MetalModel.swift:1401: collider sits a hair behind the points on it
        vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, m.layout->pl, 0, 1, &ds, 0, nullptr);
        if (!m.ib) { vkCmdDraw(cb, m.vertexCount, 1, 0, 0); continue; }   // full-screen triangle (waterUnder)
        vkCmdBindIndexBuffer(cb, m.ib, 0, m.idx32 ? VK_INDEX_TYPE_UINT32 : VK_INDEX_TYPE_UINT16);
        vkCmdDrawIndexed(cb, m.indexCount, std::max(1u, m.instances), 0, 0, 0);
    }
    vkCmdEndRenderPass(cb); return true;
}

// ---- == MetalModelRenderer.depthCopyTex blit: snapshot of the depth every earlier layer wrote (water reads it). Outside a render pass. ----
void copyDepth(VkCommandBuffer c, DepthTex& src, DepthTex& dst) {
    auto bar = [&](VkImage im, VkImageLayout from, VkImageLayout to, VkAccessFlags sa, VkAccessFlags da) {
        VkImageMemoryBarrier b{VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER}; b.oldLayout = from; b.newLayout = to; b.srcAccessMask = sa; b.dstAccessMask = da;
        b.srcQueueFamilyIndex = b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED; b.image = im; b.subresourceRange = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 1, 0, 1};
        vkCmdPipelineBarrier(c, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, 0, 0, nullptr, 0, nullptr, 1, &b);
    };
    const VkImageLayout RO = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
    bar(src.tex.img, RO, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT, VK_ACCESS_TRANSFER_READ_BIT);
    bar(dst.tex.img, RO, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_ACCESS_SHADER_READ_BIT, VK_ACCESS_TRANSFER_WRITE_BIT);
    VkImageCopy rg{}; rg.srcSubresource = rg.dstSubresource = {VK_IMAGE_ASPECT_DEPTH_BIT, 0, 0, 1}; rg.extent = {(uint32_t)src.w, (uint32_t)src.h, 1};
    vkCmdCopyImage(c, src.tex.img, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, dst.tex.img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &rg);
    bar(src.tex.img, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, RO, VK_ACCESS_TRANSFER_READ_BIT, VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_READ_BIT);
    bar(dst.tex.img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, RO, VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_SHADER_READ_BIT);
}

// ---- == occludePlane depth pass: depth-only render pass (planeDepthF writes gl_FragDepth), clear or load ----
static std::map<int, VkRenderPass> rpDepthCache;
static VkRenderPass rpDepthOnly(bool clearDepth) {
    auto it = rpDepthCache.find(clearDepth ? 1 : 0); if (it != rpDepthCache.end()) return it->second;
    VkAttachmentDescription a{}; a.format = VK_FORMAT_D32_SFLOAT; a.samples = VK_SAMPLE_COUNT_1_BIT; a.loadOp = clearDepth ? VK_ATTACHMENT_LOAD_OP_CLEAR : VK_ATTACHMENT_LOAD_OP_LOAD; a.storeOp = VK_ATTACHMENT_STORE_OP_STORE;
    a.stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE; a.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE;
    a.initialLayout = clearDepth ? VK_IMAGE_LAYOUT_UNDEFINED : VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL; a.finalLayout = VK_IMAGE_LAYOUT_DEPTH_STENCIL_READ_ONLY_OPTIMAL;
    VkAttachmentReference dr{0, VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL};
    VkSubpassDescription sp{}; sp.pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS; sp.pDepthStencilAttachment = &dr;
    VkSubpassDependency d[2]{};
    d[0].srcSubpass = VK_SUBPASS_EXTERNAL; d[0].dstSubpass = 0;
    d[0].srcStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT | VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT | VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT;
    d[0].dstStageMask = VK_PIPELINE_STAGE_EARLY_FRAGMENT_TESTS_BIT | VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT;
    d[0].srcAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT; d[0].dstAccessMask = VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_READ_BIT | VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
    d[1].srcSubpass = 0; d[1].dstSubpass = VK_SUBPASS_EXTERNAL;
    d[1].srcStageMask = VK_PIPELINE_STAGE_LATE_FRAGMENT_TESTS_BIT; d[1].dstStageMask = VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT | VK_PIPELINE_STAGE_TRANSFER_BIT;
    d[1].srcAccessMask = VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT; d[1].dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_TRANSFER_READ_BIT;
    VkRenderPassCreateInfo ri{VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO}; ri.attachmentCount = 1; ri.pAttachments = &a; ri.subpassCount = 1; ri.pSubpasses = &sp; ri.dependencyCount = 2; ri.pDependencies = d;
    VkRenderPass rp = VK_NULL_HANDLE; if (vkCreateRenderPass(g.dev, &ri, nullptr, &rp) != VK_SUCCESS) { LOG("rpDepthOnly failed"); return VK_NULL_HANDLE; }
    rpDepthCache[clearDepth ? 1 : 0] = rp; return rp;
}
VkPipeline planeDepthPipeline() {
    const Layout* L = layoutForShader("planeDepth.frag"); if (!L) return VK_NULL_HANDLE;
    auto it = pipes.find("PD"); if (it != pipes.end()) return it->second;
    VkRenderPass rp = rpDepthOnly(false); if (!rp) return VK_NULL_HANDLE;
    VkShaderModule vs = shaderMod("shaders/waterUnder.vert.spv"), fs = shaderMod("shaders/planeDepth.frag.spv");
    if (!vs || !fs) { if (vs) vkDestroyShaderModule(g.dev, vs, nullptr); if (fs) vkDestroyShaderModule(g.dev, fs, nullptr); return VK_NULL_HANDLE; }
    VkPipelineShaderStageCreateInfo st[2]{}; st[0].sType = st[1].sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    st[0].stage = VK_SHADER_STAGE_VERTEX_BIT; st[0].module = vs; st[0].pName = "main"; st[1].stage = VK_SHADER_STAGE_FRAGMENT_BIT; st[1].module = fs; st[1].pName = "main";
    VkPipelineVertexInputStateCreateInfo vin{VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO};
    VkPipelineInputAssemblyStateCreateInfo ia{VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO}; ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;
    VkPipelineViewportStateCreateInfo vp{VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO}; vp.viewportCount = vp.scissorCount = 1;
    VkPipelineRasterizationStateCreateInfo rs{VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO}; rs.polygonMode = VK_POLYGON_MODE_FILL; rs.cullMode = VK_CULL_MODE_NONE; rs.lineWidth = 1.f;
    VkPipelineMultisampleStateCreateInfo ms{VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO}; ms.rasterizationSamples = VK_SAMPLE_COUNT_1_BIT;
    VkPipelineDepthStencilStateCreateInfo dss{VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO}; dss.depthTestEnable = VK_TRUE; dss.depthWriteEnable = VK_TRUE; dss.depthCompareOp = VK_COMPARE_OP_LESS_OR_EQUAL;
    VkPipelineColorBlendStateCreateInfo cb{VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO};
    VkDynamicState dyn[2] = {VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR};
    VkPipelineDynamicStateCreateInfo ds{VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO}; ds.dynamicStateCount = 2; ds.pDynamicStates = dyn;
    VkGraphicsPipelineCreateInfo pi{VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO}; pi.stageCount = 2; pi.pStages = st; pi.pVertexInputState = &vin; pi.pInputAssemblyState = &ia;
    pi.pViewportState = &vp; pi.pRasterizationState = &rs; pi.pMultisampleState = &ms; pi.pDepthStencilState = &dss; pi.pColorBlendState = &cb; pi.pDynamicState = &ds; pi.layout = L->pl; pi.renderPass = rp;
    VkPipeline out = VK_NULL_HANDLE; VkResult r = vkCreateGraphicsPipelines(g.dev, VK_NULL_HANDLE, 1, &pi, nullptr, &out);
    vkDestroyShaderModule(g.dev, vs, nullptr); vkDestroyShaderModule(g.dev, fs, nullptr);
    if (r != VK_SUCCESS) { LOG("planeDepth pipeline failed %d", (int)r); return VK_NULL_HANDLE; }
    pipes["PD"] = out; return out;
}
bool encodePlaneDepth(VkCommandBuffer cb, DepthTex& d, bool clearDepth, const Layout* L, const Bind* binds, int nBinds) {
    if (!cf || !L) return false;
    VkPipeline p = planeDepthPipeline(); VkRenderPass rp = rpDepthOnly(clearDepth); if (!p || !rp) return false;
    VkDescriptorSet ds; if (!allocSetFor(L, binds, nBinds, ds)) return false;
    VkFramebufferCreateInfo fi{VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO}; fi.renderPass = rp; fi.attachmentCount = 1; fi.pAttachments = &d.tex.view; fi.width = d.w; fi.height = d.h; fi.layers = 1;
    VkFramebuffer fb; if (vkCreateFramebuffer(g.dev, &fi, nullptr, &fb) != VK_SUCCESS) return false;
    fbTrash[cf - fr].push_back(fb);
    VkClearValue cv{}; cv.depthStencil = {1.f, 0};
    VkRenderPassBeginInfo rb{VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO}; rb.renderPass = rp; rb.framebuffer = fb; rb.renderArea = {{0, 0}, {(uint32_t)d.w, (uint32_t)d.h}}; rb.clearValueCount = 1; rb.pClearValues = &cv;
    vkCmdBeginRenderPass(cb, &rb, VK_SUBPASS_CONTENTS_INLINE);
    VkViewport vp{0.f, (float)d.h, (float)d.w, -(float)d.h, 0.f, 1.f}; VkRect2D sc{{0, 0}, {(uint32_t)d.w, (uint32_t)d.h}};
    vkCmdSetViewport(cb, 0, 1, &vp); vkCmdSetScissor(cb, 0, 1, &sc);
    vkCmdBindPipeline(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, p);
    vkCmdBindDescriptorSets(cb, VK_PIPELINE_BIND_POINT_GRAPHICS, L->pl, 0, 1, &ds, 0, nullptr);
    vkCmdDraw(cb, 3, 1, 0, 0); vkCmdEndRenderPass(cb); return true;
}
