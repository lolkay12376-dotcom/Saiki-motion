@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import com.saiki.motion.core.AnimeDecomposer
import com.saiki.motion.core.AnimeSegModel
import com.saiki.motion.core.CancelToken
import com.saiki.motion.core.CrashLog
import com.saiki.motion.core.DecomposeOptions
import com.saiki.motion.core.DecomposeResult
import com.saiki.motion.core.DecomposedLayer
import com.saiki.motion.core.DrawImport
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.PSDWriter
import com.saiki.motion.core.Paths
import com.saiki.motion.core.Project
import com.saiki.motion.core.ProjectIO
import com.saiki.motion.core.Projects
import com.saiki.motion.ui.C
import com.saiki.motion.app.HomeBigButton
import com.saiki.motion.ui.Icons
import com.saiki.motion.ui.SegPill
import com.saiki.motion.ui.TapView
import com.saiki.motion.ui.Toast

import com.saiki.motion.ui.DrawingEditorViewController
import com.saiki.motion.ui.DrawingGalleryViewController
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UISwitch
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// Port of Sources/Tools/AnimeDecomposeViewController.swift — the "Anime Decomposition" tool screen.
//
// Same dark + orange look as the rest of the app. Pick an image, choose how
// many layers, tap SEPARATE LAYERS (cancel any time), then toggle layers and
// export as PSD, as one image, or straight into a new project.
// Auto Layout is replaced by manual frames in layoutAll() (the porting convention); every
// label, button title and message string is byte-identical to the Swift.

/** Icon-only tap target drawn with the shared vector icons. */
private class ToolIconButton : TapView() {
    var icon = ""
        set(v) { field = v; setNeedsDisplay() }
    var tint: Int = C.TEXT
        set(v) { field = v; setNeedsDisplay() }

    init { setBackgroundColor(0x00000000) }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        Icons.draw(c, icon, rect.midX, rect.midY, 22f, if (isHighlighted) C.GREEN else tint)
    }
}

/** Shows an image, or a stack of layer bitmaps, aspect-fit over a transparency checkerboard. */
private class LayerPreviewCanvas : UiView(com.saiki.motion.uikit.appContext!!) {
    private var canvas = CGSize.zero
    private var entries = ArrayList<Pair<com.saiki.motion.uikit.UiImageView, CGRect>>()
    private var checker = false

    init { setBackgroundColor(0x00000000) }

    fun show(items: List<Pair<Bitmap, CGRect>>, size: CGSize, checker: Boolean) {
        for (e in entries) e.first.removeFromSuperview()
        entries = ArrayList()
        for (item in items) {
            val v = com.saiki.motion.uikit.UiImageView()
            v.image = com.saiki.motion.uikit.UIGraphicsImageRenderer(item.first.width, item.first.height).image { c -> c.canvas.drawBitmap(item.first, 0f, 0f, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)) }
            v.contentMode = com.saiki.motion.uikit.UIViewContentMode.scaleToFill
            addSubview(v)
            entries.add(v to item.second)
        }
        canvas = size
        this.checker = checker
        layoutSubviews()
        setNeedsDisplay()
    }

    fun setHidden(index: Int, hidden: Boolean) {
        entries.getOrNull(index)?.first?.isHidden = hidden
    }

    private fun fitted(): CGRect {
        if (canvas.width <= 0f || canvas.height <= 0f || rectWidth() <= 0f || rectHeight() <= 0f) return CGRect.zero
        val s = min(rectWidth() / canvas.width, rectHeight() / canvas.height)
        val w = canvas.width * s; val h = canvas.height * s
        return CGRect((rectWidth() - w) / 2f, (rectHeight() - h) / 2f, w, h)
    }

    override fun layoutSubviews() {
        super.layoutSubviews()
        val f = fitted()
        if (f.width <= 0f) return
        val s = f.width / canvas.width
        for (e in entries) {
            e.first.frame = CGRect(f.minX + e.second.minX * s, f.minY + e.second.minY * s,
                e.second.width * s, e.second.height * s)
        }
        setNeedsDisplay()
    }

    public override fun draw(rect: CGRect) {
        if (!checker) return
        val c = UIGraphics.getCurrentContext() ?: return
        val f = fitted()
        if (f.width <= 0f) return
        c.saveGState()
        c.canvas.save()
        c.canvas.clipRect(f.toRectF())
        c.setFillColor(C.CARD); c.fill(f)
        val cell = 10f
        var y = f.minY
        var row = 0
        while (y < f.maxY) {
            var x = f.minX + (if (row % 2 == 0) 0f else cell)
            while (x < f.maxX) {
                c.setFillColor(C.CARD2)
                c.canvas.drawRect(RectF(x, y, x + cell, y + cell), c.paint)
                x += cell * 2
            }
            y += cell
            row += 1
        }
        c.canvas.restore()
        c.restoreGState()
    }
}

class AnimeDecomposeViewController : UIViewController() {
    private val pad = 16f

    // state
    private var sourceImage: Bitmap? = null
    private var result: DecomposeResult? = null
    private var opts = DecomposeOptions()

    private var aiSwitch: UISwitch? = null
    private var aiStatus: UILabel? = null
    private var aiDelete: UILabel? = null
    private var aiWorking = false
    private var token: CancelToken? = null
    private var running = false

    // views
    private val back = ToolIconButton()
    private val wordmark = UILabel()
    private val titleLabel = UILabel()
    private val scroll = UIScrollView()
    private val content = UiView()        // the vertical stack equivalent
    private val rows = ArrayList<Pair<UiView, Float>>()   // view, height
    private val canvas = LayerPreviewCanvas()
    private val placeholder = UILabel()
    private val separateBtn = HomeBigButton()
    private val progressCard = UiView()
    private val statusLabel = UILabel()
    private val resultsStack = UiView()
    private val layerList = UiView()
    private val layersTitle = UILabel()
    private val aiRowViews = ArrayList<UiView>()

    private fun aiStatusText(): String {
        if (!AnimeSegModel.runtimeLinked) return "Not available: this build has no ONNX Runtime (add the package to project.yml)"
        if (!AnimeSegModel.onnxInstalled) return "Turn on to download the model (176 MB, once). After that it works offline."
        if (opts.useAI && aiWorking) return "Working ✓ · tested OK (${"%.1f".format(AnimeSegModel.testSecs)}s) · runs offline"
        return "Model downloaded · off"
    }

    private fun aiRefresh() {
        aiStatus?.text = aiStatusText()
        aiDelete?.isHidden = !AnimeSegModel.onnxInstalled
    }

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        CrashLog.note("anime_decompose")
        back.icon = "back"
        back.onClick = { goBack() }
        wordmark.text = "TOOLS"
        wordmark.font = UIFont.boldSystemFont(12f)
        wordmark.textColor = UIColor(C.GREEN)
        titleLabel.text = "Anime Decomposition"
        titleLabel.font = UIFont.boldSystemFont(24f)
        titleLabel.textColor = UIColor(C.TEXT)
        view.addSubview(back); view.addSubview(wordmark); view.addSubview(titleLabel)
        view.addSubview(scroll)
        scroll.addSubview(content)
        buildUi()
    }

    override fun viewWillDisappear(animated: Boolean) {
        super.viewWillDisappear(animated)
        token?.cancel()
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        layoutAll()
    }

    private fun layoutAll() {
        val w = view.rectWidth(); val h = view.rectHeight()
        val sa = view.safeAreaInsets
        wordmark.frame = CGRect(50f, sa.top + 16f, 120f, 16f)
        back.frame = CGRect(6f, sa.top + 20f, 44f, 44f)
        titleLabel.frame = CGRect(50f, sa.top + 34f, w - 50f - pad, 30f)
        scroll.frame = CGRect(0f, titleLabel.frame.maxY + 10f, w, h - titleLabel.frame.maxY - 10f)
        var y = 4f
        for ((v, hh) in rows) { v.frame = CGRect(pad, y, w - 2 * pad, hh); y += hh + 12f }
        content.frame = CGRect(0f, 0f, w, y + 40f)
        scroll.contentSize = CGSize(w, y + 40f)
    }

    private fun add(v: UiView, height: Float) { content.addSubview(v); rows.add(v to height) }

    private fun bigButton(title: String, icon: String, orange: Boolean, action: () -> Unit): HomeBigButton {
        val b = HomeBigButton()
        b.title = title.uppercase()
        b.bg = if (orange) C.GREEN else 0xFF14351F.toInt()
        b.fg = if (orange) C.ONDARK else C.GREEN
        b.icon = icon
        b.tapped = action
        return b
    }

    private fun caption(s: String): UILabel {
        val l = UILabel()
        l.text = s.uppercase()
        l.font = UIFont.semiboldSystemFont(11f)
        l.textColor = UIColor(C.DIM)
        return l
    }

    // MARK: ui

    private fun buildUi() {
        // 1. preview
        val preview = object : UiView() {
            override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                com.saiki.motion.ui.fillRoundRect(c, rect, 14f, C.CARD)
            }
        }
        preview.clipsToBounds = true
        preview.addSubview(canvas)
        placeholder.text = "Tap CHOOSE IMAGE to pick an anime character"
        placeholder.font = UIFont.systemFont(13f)
        placeholder.textColor = UIColor(C.DIM)
        placeholder.textAlignment = NSTextAlignment.center
        placeholder.numberOfLines = 0
        preview.addSubview(placeholder)
        preview.onLayoutSubviews = { canvas.frame = CGRect(8f, 8f, preview.rectWidth() - 16f, preview.rectHeight() - 16f); placeholder.frame = CGRect(30f, preview.rectHeight() / 2f - 20f, preview.rectWidth() - 60f, 40f) }
        add(preview, 340f)

        // 2. choose image
        val chooseBtn = bigButton("Choose image", "import", orange = false) { chooseImage() }
        add(chooseBtn, 46f)

        // 3. settings card
        val settings = UiView()
        val sy = ArrayList<Float>()
        fun put(v: UiView, hh: Float) { settings.addSubview(v); sy.add(hh) }
        put(caption("Settings"), 16f)
        put(segRow(settings, "Quality", listOf("Fast", "Balanced", "High", "Ultra"), opts.quality) { i ->
            opts.quality = i
            opts.maxSide = DecomposeOptions.preset(i).first
            if (i == 3) Toast.show("Ultra uses more memory and time (about 2–5 min)")
        }, 64f)
        put(sliderRow(settings, "Detail", 1f, 10f, opts.detail.toFloat(), { it.roundToInt().toString() }) { opts.detail = it.roundToInt() }, 64f)
        put(sliderRow(settings, "Edge smoothing", 0f, 3f, opts.smoothing.toFloat(), { listOf("Off", "Low", "Medium", "High")[max(0, min(3, it.roundToInt()))] }) { opts.smoothing = it.roundToInt() }, 64f)
        put(caption("Background"), 16f)
        put(switchRow(settings, "Remove background", "Cuts the character out (flat colours and busy scenes)", opts.removeBackground) { opts.removeBackground = it }, 52f)
        put(switchRow(settings, "Keep background layer", "Adds the removed background as its own layer", opts.keepBackground) { opts.keepBackground = it }, 52f)
        put(caption("Parts"), 16f)
        put(switchRow(settings, "Separate eyes, eyelids & mouth", "Eyes, eyelids, eyebrows and mouth become their own layers", opts.splitFace) { opts.splitFace = it }, 52f)
        put(switchRow(settings, "Hair strands", "Splits hair into separate pieces (bangs, sides, back, highlights)", opts.hairStrands) { opts.hairStrands = it }, 52f)
        put(sliderRow(settings, "Max hair layers", 4f, 60f, opts.strandLimit.toFloat(), { it.roundToInt().toString() }) { opts.strandLimit = it.roundToInt() }, 64f)
        put(switchRow(settings, "Separate body parts", "Neck, arms and legs", opts.splitBody) { opts.splitBody = it }, 52f)
        put(switchRow(settings, "Separate clothes", "Top, bottom, footwear by colour", opts.splitClothes) { opts.splitClothes = it }, 52f)
        put(caption("Line art"), 16f)
        put(segRow(settings, "Line art layers", listOf("Merge", "One layer", "Per part"), opts.lineMode) { opts.lineMode = it }, 64f)
        put(sliderRow(settings, "Line sensitivity", 1f, 3f, opts.lineSensitivity.toFloat(), { listOf("", "Low", "Medium", "High")[max(1, min(3, it.roundToInt()))] }) { opts.lineSensitivity = it.roundToInt() }, 64f)
        put(caption("Output"), 16f)
        put(switchRow(settings, "Auto group", "Groups layers into Head, Hair, Body, Clothes… in the project", opts.autoGroup) { opts.autoGroup = it }, 52f)
        put(aiRow(settings), 84f)
        put(switchRow(settings, "Fill hidden gaps", "Adds hidden skin and colour under eyes, hair and lines so parts can move freely", opts.fillGaps) { opts.fillGaps = it }, 52f)
        var syTotal = 0f
        settings.onLayoutSubviews = {
            var yy = 14f
            for ((i, v) in settings.subviewsList().withIndex()) {
                v.frame = CGRect(14f, yy, settings.rectWidth() - 28f, sy[i])
                yy += sy[i] + 8f
            }
        }
        val settingsCard = object : UiView() {
            override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                com.saiki.motion.ui.fillRoundRect(c, rect, 14f, C.CARD)
            }
        }
        settingsCard.addSubview(settings)
        settingsCard.onLayoutSubviews = { settings.frame = CGRect(14f, 14f, settingsCard.rectWidth() - 28f, settingsCard.rectHeight() - 28f) }
        add(settingsCard, 900f)
        aiRowViews.clear()  // heights handled inside settings

        // 4. separate
        separateBtn.title = "Separate layers"
        separateBtn.bg = C.GREEN
        separateBtn.fg = C.ONDARK
        separateBtn.icon = "layers"
        separateBtn.tapped = { startSeparate() }
        separateBtn.alpha = 0.45f
        add(separateBtn, 46f)

        // 5. progress (hidden until running)
        statusLabel.font = UIFont.systemFont(13f)
        statusLabel.textColor = UIColor(C.TEXT)
        statusLabel.text = "Starting…"
        val cancel = bigButton("Cancel", "close", orange = false) { cancelRun() }
        cancel.bg = 0xFF3A1A1A.toInt(); cancel.fg = C.RED
        progressCard.isHidden = true
        progressCard.addSubview(statusLabel); progressCard.addSubview(cancel)
        progressCard.onLayoutSubviews = {
            statusLabel.frame = CGRect(0f, 0f, progressCard.rectWidth(), 20f)
            cancel.frame = CGRect(0f, 30f, progressCard.rectWidth(), 46f)
        }
        add(progressCard, 84f)

        // 6. results (hidden until a run finishes)
        layersTitle.textColor = UIColor(C.GREEN)
        resultsStack.isHidden = true
        resultsStack.addSubview(layersTitle)
        resultsStack.addSubview(layerList)
        resultsStack.addSubview(caption("Export"))
        val psd = bigButton("Export as PSD", "export", orange = false) { exportPSD() }
        val img = bigButton("Export as image", "media", orange = false) { exportImage() }
        val prj = bigButton("Export to project", "plus", orange = true) { exportToProject() }
        val paint = bigButton("Send to Paint", "edit", orange = false) { sendToPaint() }
        for (b in listOf(psd, img, paint, prj)) resultsStack.addSubview(b)
        exportButtons = listOf(psd, img, paint, prj)
        add(resultsStack, 100f)
        layoutAll()
    }

    private var exportButtons = listOf<HomeBigButton>()

    // MARK: setting rows

    private fun sliderRow(parent: UiView, title: String, lo: Float, hi: Float, value: Float,
                          fmt: (Float) -> String, change: (Float) -> Unit): UiView {
        val wrap = UiView()
        val t = UILabel(); t.text = title; t.font = UIFont.semiboldSystemFont(14f); t.textColor = UIColor(C.TEXT)
        val v = UILabel(); v.text = fmt(value); v.font = UIFont.boldSystemFont(14f); v.textColor = UIColor(C.GREEN)
        v.textAlignment = NSTextAlignment.right
        val s = UISlider()
        s.minValue = lo; s.maxValue = hi; s.value = value
        s.onValueChanged = { v.text = fmt(s.value); change(s.value) }
        wrap.addSubview(t); wrap.addSubview(v); wrap.addSubview(s)
        wrap.onLayoutSubviews = {
            t.frame = CGRect(0f, 0f, wrap.rectWidth() / 2f, 20f)
            v.frame = CGRect(wrap.rectWidth() / 2f, 0f, wrap.rectWidth() / 2f, 20f)
            s.frame = CGRect(0f, 26f, wrap.rectWidth(), 32f)
        }
        return wrap
    }

    private fun switchRow(parent: UiView, title: String, sub: String, on: Boolean, change: (Boolean) -> Unit): UiView {
        val wrap = UiView()
        val t = UILabel(); t.text = title; t.font = UIFont.semiboldSystemFont(14f); t.textColor = UIColor(C.TEXT)
        val s = UILabel(); s.text = sub; s.font = UIFont.systemFont(12f); s.textColor = UIColor(C.DIM); s.numberOfLines = 0
        val sw = UISwitch(); sw.isOn = on
        sw.onValueChanged = { change(sw.isOn) }
        wrap.addSubview(t); wrap.addSubview(s); wrap.addSubview(sw)
        wrap.onLayoutSubviews = {
            t.frame = CGRect(0f, 2f, wrap.rectWidth() - 64f, 18f)
            s.frame = CGRect(0f, 22f, wrap.rectWidth() - 64f, 28f)
            sw.frame = CGRect(wrap.rectWidth() - 56f, 8f, 52f, 32f)
        }
        return wrap
    }

    private fun segRow(parent: UiView, title: String, options: List<String>, selected: Int, change: (Int) -> Unit): UiView {
        val wrap = UiView()
        val t = UILabel(); t.text = title; t.font = UIFont.semiboldSystemFont(14f); t.textColor = UIColor(C.TEXT)
        wrap.addSubview(t)
        val pills = ArrayList<SegPill>()
        for ((i, opt) in options.withIndex()) {
            val p = SegPill()
            p.title = opt
            p.on = i == selected
            p.tapped = {
                for (q in pills) q.on = (q === p)
                change(i)
            }
            wrap.addSubview(p); pills.add(p)
        }
        wrap.onLayoutSubviews = {
            t.frame = CGRect(0f, 0f, wrap.rectWidth(), 18f)
            val cw = (wrap.rectWidth() - 8f * (pills.size - 1)) / pills.size
            for ((i, p) in pills.withIndex()) p.frame = CGRect(i * (cw + 8f), 26f, cw, 34f)
        }
        return wrap
    }

    // MARK: AI row

    private fun aiRow(parent: UiView): UiView {
        val wrap = UiView()
        val t = UILabel(); t.text = "AI cut-out (ISNet anime)"; t.font = UIFont.semiboldSystemFont(14f); t.textColor = UIColor(C.TEXT)
        val s = UILabel(); s.font = UIFont.systemFont(12f); s.textColor = UIColor(C.DIM); s.numberOfLines = 0
        val del = UILabel(); del.text = "Delete model (frees 176 MB)"; del.font = UIFont.semiboldSystemFont(12f); del.textColor = UIColor(0xFFFF3B30.toInt())
        del.onClick = { aiConfirmDelete() }
        val sw = UISwitch(); sw.isOn = false
        sw.onValueChanged = { on -> aiToggled(on) }
        aiSwitch = sw; aiStatus = s; aiDelete = del
        opts.useAI = false
        aiRefresh()
        wrap.addSubview(t); wrap.addSubview(s); wrap.addSubview(del); wrap.addSubview(sw)
        wrap.onLayoutSubviews = {
            t.frame = CGRect(0f, 2f, wrap.rectWidth() - 64f, 18f)
            s.frame = CGRect(0f, 22f, wrap.rectWidth() - 64f, 36f)
            del.frame = CGRect(0f, 60f, wrap.rectWidth() - 64f, 18f)
            sw.frame = CGRect(wrap.rectWidth() - 56f, 8f, 52f, 32f)
        }
        aiRowViews.add(wrap)
        return wrap
    }

    private fun aiConfirmDelete() {
        val a = com.saiki.motion.uikit.UIAlertController()
        a.title = "Delete AI model?"; a.message = "You can download it again any time."
        a.addAction(com.saiki.motion.uikit.UIAlertAction("Cancel", com.saiki.motion.uikit.UIAlertActionStyle.cancel, null))
        a.addAction(com.saiki.motion.uikit.UIAlertAction("Delete", com.saiki.motion.uikit.UIAlertActionStyle.destructive) {
            AnimeSegModel.removeModel()
            aiWorking = false
            opts.useAI = false
            aiSwitch?.isOn = false
            aiRefresh()
        })
        a.showOver(this)
    }

    private fun aiToggled(on: Boolean) {
        if (!on) { opts.useAI = false; aiWorking = false; aiRefresh(); return }
        if (!AnimeSegModel.runtimeLinked) { aiFail(aiStatusText()); return }
        if (AnimeSegModel.onnxInstalled) { aiVerifyAndEnable(); return }
        aiSwitch?.isEnabled = false
        aiDelete?.isHidden = true
        aiStatus?.text = "Downloading… 0%"
        AnimeSegModel.download({ f ->
            aiStatus?.text = "Downloading… ${(f * 100).toInt()}%"
        }) { ok ->
            if (ok) aiVerifyAndEnable()
            else aiFail("Download failed. Check your connection, then turn it on again.")
        }
    }

    private fun aiVerifyAndEnable() {
        aiSwitch?.isEnabled = false
        aiStatus?.text = "Testing model on this phone…"
        Thread {
            val ok = AnimeSegModel.verify()
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                if (ok) {
                    aiWorking = true
                    opts.useAI = true
                    aiSwitch?.isOn = true
                    aiSwitch?.isEnabled = true
                    aiRefresh()
                } else {
                    val why = AnimeSegModel.lastError?.let { ": $it" } ?: ""
                    aiFail("Model test failed$why")
                }
            }
        }.start()
    }

    private fun aiFail(msg: String) {
        opts.useAI = false
        aiWorking = false
        aiSwitch?.isOn = false
        aiSwitch?.isEnabled = true
        aiRefresh()
        aiStatus?.text = msg
    }

    // MARK: picking an image

    private fun goBack() {
        token?.cancel()
        navigationController?.popViewController(animated = true)
    }

    private fun chooseImage() {
        if (running) return
        DocPicker.pick { uri ->
            try {
                val img = Paths.appContext.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (img != null) android.os.Handler(android.os.Looper.getMainLooper()).post { setSource(img) }
                else Toast.show("Could not open that image")
            } catch (_: Exception) { Toast.show("Could not open that image") }
        }
    }

    private fun setSource(img: Bitmap) {
        sourceImage = img
        result = null
        placeholder.isHidden = true
        val size = CGSize(img.width.toFloat(), img.height.toFloat())
        canvas.show(listOf(img to CGRect(0f, 0f, size.width, size.height)), size, checker = false)
        resultsStack.isHidden = true
        layerList.subviewsList().forEach { it.removeFromSuperview() }
        separateBtn.alpha = 1f
    }

    // MARK: run

    private fun startSeparate() {
        if (running) return
        val img = sourceImage ?: run { Toast.show("Choose an image first"); return }
        running = true
        val tok = CancelToken()
        token = tok
        val options = opts
        settingsDisabled = true
        separateBtn.isHidden = true
        resultsStack.isHidden = true
        statusLabel.text = "Starting…"
        progressCard.isHidden = false
        layoutAll()
        Thread {
            val px = AnimeDecomposer.loadPixels(img, options.maxSide)
            if (px == null) {
                android.os.Handler(android.os.Looper.getMainLooper()).post { finished(null, false) }
                return@Thread
            }
            val res = AnimeDecomposer.run(px.third, px.first, px.second, options, tok) { f, s ->
                android.os.Handler(android.os.Looper.getMainLooper()).post { setProgress(f, s) }
            }
            android.os.Handler(android.os.Looper.getMainLooper()).post { finished(res, tok.isCancelled) }
        }.start()
    }

    private var settingsDisabled = false

    private fun setProgress(f: Double, s: String) {
        if (!running) return
        statusLabel.text = "$s…"
    }

    private fun cancelRun() {
        if (!running) return
        token?.cancel()
        statusLabel.text = "Cancelling…"
    }

    private fun finished(res: DecomposeResult?, cancelled: Boolean) {
        running = false
        progressCard.isHidden = true
        separateBtn.isHidden = false
        settingsDisabled = false
        if (cancelled) { Toast.show("Cancelled"); return }
        if (res == null) { Toast.show("Could not separate this image"); return }
        showResult(res)
    }

    // MARK: results

    private fun showResult(r: DecomposeResult) {
        result = r
        val items = ArrayList<Pair<Bitmap, CGRect>>()
        val thumbs = ArrayList<Bitmap>()
        for (l in r.layers) {
            val im = AnimeDecomposer.image(l.rgba, l.w, l.h) ?: Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
            thumbs.add(im)
            items.add(im to CGRect(l.x.toFloat(), l.y.toFloat(), l.w.toFloat(), l.h.toFloat()))
        }
        canvas.show(items, CGSize(r.width.toFloat(), r.height.toFloat()), checker = true)

        layersTitle.text = "LAYERS · ${r.layers.size}"
        layerList.subviewsList().forEach { it.removeFromSuperview() }
        val layerRows = ArrayList<Pair<UiView, Float>>()
        val total = max(1, r.layers.sumOf { it.area })
        for ((i, l) in r.layers.withIndex()) {
            layerRows.add(layerRow(i, l, thumbs[i], (l.area.toDouble() / total * 100).roundToInt()) to 72f)
        }
        layerList.onLayoutSubviews = {
            var yy = 0f
            for ((v, hh) in layerRows) { v.frame = CGRect(0f, yy, layerList.rectWidth(), hh); yy += hh + 8f }
        }
        for ((v, _) in layerRows) layerList.addSubview(v)
        resultsStack.isHidden = false
        val groupCount = r.layers.map { it.group }.filter { it.isNotEmpty() }.toSet().size
        Toast.show(if (groupCount > 0) "${r.layers.size} layers in $groupCount groups ready" else "${r.layers.size} layers ready")
        layoutAll()
    }

    private fun layerRow(index: Int, l: DecomposedLayer, thumb: Bitmap, pct: Int): UiView {
        val card = object : UiView() {
            override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                com.saiki.motion.ui.fillRoundRect(c, rect, 12f, C.CARD)
            }
        }
        val box = object : UiView() {
            override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                com.saiki.motion.ui.fillRoundRect(c, rect, 8f, C.CARD2)
            }
        }
        box.clipsToBounds = true
        val iv = com.saiki.motion.uikit.UiImageView()
        iv.image = com.saiki.motion.uikit.UIGraphicsImageRenderer(thumb.width, thumb.height).image { c -> c.canvas.drawBitmap(thumb, 0f, 0f, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)) }
        iv.contentMode = com.saiki.motion.uikit.UIViewContentMode.scaleAspectFit
        box.addSubview(iv)
        val name = UILabel(); name.text = l.name; name.font = UIFont.semiboldSystemFont(15f); name.textColor = UIColor(C.TEXT)
        val meta = UILabel()
        meta.text = (if (l.group.isEmpty()) "" else "${l.group} · ") + "$pct% of figure · ${l.w}×${l.h}"
        meta.font = UIFont.systemFont(12f); meta.textColor = UIColor(C.DIM)
        val eye = ToolIconButton()
        eye.icon = if (l.visible) "eye" else "eye_off"
        eye.tint = if (l.visible) C.GREEN else C.DIM
        eye.onClick = {
            val r = result
            if (r != null) {
                r.layers[index].visible = !r.layers[index].visible
                val vis = r.layers[index].visible
                eye.icon = if (vis) "eye" else "eye_off"
                eye.tint = if (vis) C.GREEN else C.DIM
                canvas.setHidden(index, !vis)
            }
        }
        card.addSubview(box); card.addSubview(name); card.addSubview(meta); card.addSubview(eye)
        card.onLayoutSubviews = {
            box.frame = CGRect(10f, 10f, 52f, 52f)
            iv.frame = CGRect(3f, 3f, 46f, 46f)
            name.frame = CGRect(74f, 14f, card.rectWidth() - 74f - 54f, 20f)
            meta.frame = CGRect(74f, 36f, card.rectWidth() - 74f - 54f, 16f)
            eye.frame = CGRect(card.rectWidth() - 50f, 14f, 44f, 44f)
        }
        return card
    }

    // MARK: export

    private fun busy(text: String, work: () -> File?, done: (File) -> Unit) {
        Toast.show(text)
        Thread {
            val u = work()
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                if (u != null) done(u) else Toast.show("Export failed")
            }
        }.start()
    }

    private fun share(url: File) {
        shareHook?.invoke(url) ?: Toast.show("Saved to ${url.name}")
    }

    /** UIActivityViewController twin — the host wires the Android share intent here. */
    var shareHook: ((File) -> Unit)? = null

    private fun tempFile(name: String): File = File(Paths.appContext.cacheDir, name)

    private fun exportPSD() {
        val r = result ?: return
        busy("Building PSD…", {
            try {
                val comp = AnimeDecomposer.composite(r.layers, r.width, r.height)
                val data = PSDWriter.write(r.width, r.height, r.layers, comp)
                val url = tempFile("anime_layers.psd")
                url.delete()
                url.writeBytes(data)
                url
            } catch (_: Exception) { null }
        }, { url -> share(url) })
    }

    private fun exportImage() {
        val r = result ?: return
        busy("Building image…", {
            try {
                val comp = AnimeDecomposer.composite(r.layers, r.width, r.height)
                val img = AnimeDecomposer.image(comp, r.width, r.height) ?: return@busy null
                val url = tempFile("anime_character.png")
                url.delete()
                url.outputStream().use { img.compress(Bitmap.CompressFormat.PNG, 100, it) }
                url
            } catch (_: Exception) { null }
        }, { url -> share(url) })
    }

    /** Layers → a new artwork in the Drawing Editor's own "Anime Decomposition" gallery folder. */
    private fun sendToPaint() {
        val r = result ?: return
        Toast.show("Sending to Paint…")
        Thread {
            val f = SimpleDateFormat("MMM d HH:mm")
            val art = DrawImport.fromDecomposed(r, "Anime " + f.format(Date()))
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                val nav = navigationController
                nav?.pushViewController(DrawingGalleryViewController(null), animated = true)
                art.parent?.let { pf -> nav?.pushViewController(DrawingGalleryViewController(pf), animated = true) }
                nav?.pushViewController(DrawingEditorViewController(art), animated = true)
                Toast.show("Saved to Gallery › Anime Decomposition")
            }
        }.start()
    }

    /** One full-canvas PNG per layer → a new project with every layer in it. */
    private fun exportToProject() {
        val r = result ?: return
        Toast.show("Creating project…")
        Thread {
            val project = Project(name = "Anime layers", w = r.width, h = r.height, fps = 30)
            val scene = project.scenes[0]
            var ok = true
            val groups = HashMap<String, Layer>()
            val groupOrder = ArrayList<Pair<String, Int>>()
            for ((idx, layer) in r.layers.withIndex()) {
                val full = AnimeDecomposer.fullCanvas(layer, r.width, r.height)
                val img = AnimeDecomposer.image(full, r.width, r.height)
                val png = img?.let { b ->
                    try { val o = java.io.ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.PNG, 100, o); o.toByteArray() } catch (_: Exception) { null }
                }
                val path = png?.let { ProjectIO.writeDataIntoSandbox(it, "${idx + 1}_${layer.name}.png") }
                if (path == null) { ok = false; break }
                val l = Layer(project.nextId, layer.name, LayerType.IMAGE)
                project.nextId += 1
                l.imagePath = path
                l.end = scene.duration
                l.visible = layer.visible
                if (layer.group.isNotEmpty()) {
                    var g = groups[layer.group]
                    if (g == null) {
                        val ng = Layer(project.nextId, layer.group, LayerType.GROUP)
                        project.nextId += 1
                        ng.end = scene.duration
                        groups[layer.group] = ng
                        groupOrder.add(layer.group to layer.order)
                        g = ng
                    }
                    l.parentId = g!!.id
                }
                scene.layers.add(l)
            }
            for ((name, _) in groupOrder.sortedBy { it.second }) {
                groups[name]?.let { scene.layers.add(it) }
            }
            val groupTotal = groups.size
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                if (!ok) { Toast.show("Export failed"); return@post }
                Projects.save(project)
                Toast.show(if (groupTotal == 0) "Project created with ${r.layers.size} layers" else "Project created: ${r.layers.size} layers in $groupTotal groups")
                navigationController?.pushViewController(EditorViewController(project.id), animated = true)
            }
        }.start()
    }
}
