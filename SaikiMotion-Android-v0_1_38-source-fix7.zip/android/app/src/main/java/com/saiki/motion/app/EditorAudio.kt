@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorAudio.swift — audio playback (MediaPlayer → AVAudioPlayer port)
// + PanelBox (the editor property-panel rail: close / + / diamond / graph / cmd / box / more).

package com.saiki.motion.app

import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import com.saiki.motion.core.AudioTools
import com.saiki.motion.core.Editor
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.afxAnimated
import com.saiki.motion.core.afxChainAt
import com.saiki.motion.core.clamp
import com.saiki.motion.ui.C
import com.saiki.motion.ui.IconView
import com.saiki.motion.ui.chipRow
import com.saiki.motion.ui.TabBar
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.UiView
import kotlin.math.abs
import java.io.File

/** android.media.MediaPlayer behind the AVAudioPlayer API surface the editor uses. */
class AVAudioPlayer private constructor(private val mp: MediaPlayer) {
    private var vol: Float = 1f
    var volume: Float
        get() = vol
        set(v) { vol = v; try { mp.setVolume(v, v) } catch (_: Exception) {} }
    val isPlaying: Boolean get() = try { mp.isPlaying } catch (_: Exception) { false }
    var currentTime: Double
        get() = try { mp.currentPosition / 1000.0 } catch (_: Exception) { 0.0 }
        set(ms) { try { mp.seekTo((ms * 1000).toInt()) } catch (_: Exception) {} }

    fun prepareToPlay(): Boolean = true   // created prepared (prepareAsync parity)
    fun play() { try { mp.start() } catch (_: Exception) {} }
    fun pause() { try { if (mp.isPlaying) mp.pause() } catch (_: Exception) {} }
    fun stop() { try { mp.stop() } catch (_: Exception) {} }
    fun release() { try { mp.release() } catch (_: Exception) {} }

    companion object {
        fun contentsOf(path: String): AVAudioPlayer? {
            val mp = MediaPlayer()
            try {
                mp.setDataSource(path)
                mp.prepare()          // called on a background thread (prepareAsync parity)
                return AVAudioPlayer(mp)
            } catch (_: Exception) {
                try { mp.release() } catch (_: Exception) {}
                return null
            }
        }
    }
}

/** safeThread(name) { }: iOS background dispatch + crash-safe toast on throw. */
fun EditorViewController.safeThread(name: String, block: () -> Unit) {
    Thread({
        try { block() } catch (e: Exception) {
            val m = e.message ?: e.javaClass.simpleName
            Handler(Looper.getMainLooper()).post { toast("$name: $m") }
        }
    }, name).start()
}

fun EditorViewController.ensureAudio() {
    // iOS sets AVAudioSession .playback here; Android MediaPlayer needs no session — PORT NOTE.
    val ids = HashSet<Int>()
    val liveIds = HashSet<Int>()
    for (l in Editor.scene.layers) {
        if (l.type != LayerType.AUDIO && l.type != LayerType.VIDEO) continue
        ids.add(l.id)
        val rawPath = l.imagePath ?: continue
        // effect chain → real-time engine path (no AVAudioPlayer for this layer)
        if (l.afx.isNotEmpty()) {
            liveIds.add(l.id)
            players[l.id]?.let { mp -> mp.stop(); mp.release() }
            players.remove(l.id); prepared.remove(l.id)
            liveFx.sync(l, rawPath) {
                if (playing) tickAudio(true)
            }
            continue
        }
        val path = rawPath
        val eff = ""
        if (players[l.id] != null || startingAudio.contains(l.id)) continue
        val id = l.id
        val isVideo = l.type == LayerType.VIDEO
        startingAudio.add(id)
        safeThread("audio-$id") {
            var mp = AVAudioPlayer.contentsOf(path)
            if (mp == null && isVideo) {
                // MediaPlayer can't open every container: pull the sound out to m4a and play that
                val dst = File(com.saiki.motion.core.Paths.cache, "vidaudio-${kotlin.math.abs(path.hashCode())}.m4a")
                if (dst.exists() || AudioTools.extractAudio(path, dst)) {
                    mp = AVAudioPlayer.contentsOf(dst.path)
                }
            }
            Handler(Looper.getMainLooper()).post {
                startingAudio.remove(id)
                val stillWanted = Editor.scene.layers.firstOrNull { it.id == id }?.afx?.isEmpty() ?: false
                players[id]?.stop()          // never leave two players on one layer
                if (mp != null && stillWanted) {
                    players[id] = mp
                    playerFx[id] = eff
                    prepared.add(id)
                }
            }
        }
    }
    liveFx.prune(liveIds)
    for (id in players.keys.toList()) {
        if (!ids.contains(id)) {
            players.remove(id)?.let { it.stop(); it.release() }
            prepared.remove(id)
            startingAudio.remove(id)
        }
    }
}

/** Called by the Audio FX panel after any edit: effects update live (no re-render, no restart). */
fun EditorViewController.audioFxChanged() {
    ensureAudio()
    if (playing) tickAudio(false)
}

fun EditorViewController.releaseAudio() {
    liveFx.removeAll()
    for (mp in players.values) { mp.stop(); mp.release() }
    players.clear()
    prepared.clear()
    startingAudio.clear()
}

fun EditorViewController.stopAudio() {
    liveFx.pauseAll()
    for (mp in players.values) mp.pause()
}

fun EditorViewController.startAudio() {
    ensureAudio()
    if (startingAudio.isNotEmpty()) {      // players still preparing: retry shortly so Play isn't silent
        Handler(Looper.getMainLooper()).postDelayed({
            if (playing) tickAudio(true)
        }, 250)
    }
    tickAudio(true)
}

/** Keeps every audio layer locked to the playhead and corrects drift. */
fun EditorViewController.tickAudio(restart: Boolean = false) {
    val t = Editor.time
    for (l in Editor.scene.layers) {
        val inside = l.visible && t >= l.start && t <= l.end
        val wantMs = ktInt((t - l.start + l.srcOffset) * 1000).toFloat() + audioLead
        val want = wantMs / 1000f
        if (liveFx.has(l.id)) {
            players[l.id]?.let { stray -> stray.stop(); players.remove(l.id) }      // stray player: fx owns this layer now
            if (l.afxAnimated) liveFx.setItems(l.id, l.afxChainAt(t))      // keyframed effect parameters follow the playhead
            liveFx.tick(l.id, inside, want.toDouble(), clamp(l.p("volume", t), 0f, 1f), restart)
            continue
        }
        val mp = players[l.id] ?: continue
        if (!prepared.contains(l.id)) continue
        if (inside) {
            val v = clamp(l.p("volume", t), 0f, 1f)
            mp.volume = v
            if (!mp.isPlaying) {
                mp.currentTime = want.toDouble().toDouble()  // SEEK_CLOSEST parity
                mp.play()
            } else if (restart || kotlin.math.abs(mp.currentTime - want.toDouble()) > 0.35) {
                mp.currentTime = want.toDouble().toDouble()
            }
        } else if (mp.isPlaying) {
            mp.pause()
        }
    }
}

// ================================================================ PanelBox (iOS buildUi() property-panel rail)

/** The property panel: fixed 52pt side rail + PanelScroll of panel rows. */
class PanelBox(private val ed: EditorViewController) : com.saiki.motion.uikit.UiView(com.saiki.motion.uikit.appContext!!) {
    val rail = EVStack()
    val scroll = PanelScroll()

    fun buildRail() {
        fun railIcon(name: String, tint: Int, h: com.saiki.motion.uikit.CGFloat, click: () -> Unit): IconView {
            val v = IconView(name, tint)
            v.onClick = click
            rail.add(EBox(v, 48f, h, 0f, 0f, 0f, 0f))
            return v
        }
        railIcon("close", C.TEXT, 48f) { ed.closePanel() }
        railIcon("plus", C.GREEN, 44f) { ed.fxTab = 1; ed.openPanel(P_FX) }
        ed.diamondSide = railIcon("diamond_f", C.DIM, 44f) { ed.keySelected() }
        railIcon("graph", C.DIM, 44f) {
            val l = ed.selected()
            if (l != null && ed.selKey.isNotEmpty() && l.track(ed.selKey).keys.size >= 2) { ed.graphProp = ed.selKey; ed.graphKey = 0 }
            ed.openPanel(P_GRAPH)
        }
        railIcon("cmd", C.DIM, 44f) { ed.exprSelected() }
        railIcon("box", C.DIM, 44f) { ed.fxTab = 2; ed.openPanel(P_FX) }
        railIcon("more", C.DIM, 44f) { ed.showPanelMenu() }
        addSubview(rail)
        addSubview(scroll)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        rail.frame = CGRect(0f, 0f, 52f, rectHeight())
        scroll.frame = CGRect(52f, 0f, kotlin.math.max(0f, rectWidth() - 52f), rectHeight())
    }
}
