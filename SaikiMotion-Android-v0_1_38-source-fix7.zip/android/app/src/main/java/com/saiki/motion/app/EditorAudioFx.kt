@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorAudioFx.swift — "Audio effects" section of the audio layer
// panel + the custom Equalizer graph + AudioFxCurveView + AudioFxCard.

package com.saiki.motion.app

import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import com.saiki.motion.core.AudioFxItem
import com.saiki.motion.core.Biquad
import com.saiki.motion.core.BiquadKind
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.PropDef
import com.saiki.motion.core.Registry
import com.saiki.motion.core.Track
import com.saiki.motion.core.afxAt
import com.saiki.motion.core.afxLfo
import com.saiki.motion.core.afxCopyTracks
import com.saiki.motion.core.afxDropTracks
import com.saiki.motion.core.afxKey
import com.saiki.motion.core.AFxDefs
import com.saiki.motion.core.AFxParam
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.ui.fillRoundRect
import com.saiki.motion.ui.measureText
import com.saiki.motion.ui.C
import com.saiki.motion.ui.IconView
import com.saiki.motion.ui.RulerSlider
import com.saiki.motion.ui.TapView
import com.saiki.motion.ui.boldFont
import com.saiki.motion.ui.chipRow
import com.saiki.motion.ui.sysFont
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIGestureRecognizerState
import com.saiki.motion.uikit.UIPanGestureRecognizer
import com.saiki.motion.uikit.UITapGestureRecognizer
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.appContext
import com.saiki.motion.ui.fillRoundRect
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.drawText
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.log
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tan
import kotlin.math.tanh

/** Selected eq band (iOS EqSel static). */
private object EqSel { var band = 2 }

// ================================================================ panel section

/** Audio effects as normal effect rows (handle · icon · name · eye · chevron · more), shown in the Applied tab. */
fun EditorViewController.buildAudioFxPanel(p: EVStack, l: Layer) {
    val rows = mutableListOf<UiView>()
    val idxs = mutableListOf<Int>()
    val handles = mutableListOf<UiView>()
    for (idx in 0 until l.afx.count()) {
        val t = l.afx[idx].type
        val key = "${l.id}:afx$idx"
        val isOpen = expanded.contains(key)
        val c = vStack()
        val hdr = audioFxHeader(l, idx, key, isOpen)
        handles.add((hdr as? EHStack)?.arranged?.firstOrNull() ?: hdr)
        c.add(hdr)
        if (isOpen) {
            if (t == "eq") {
                buildEqUi(c, l, idx)
            } else {
                buildFxCurve(c, l, idx)
                for (d in AFxDefs.params(t)) fxRow(c, l, idx, d)
            }
            if (AFxDefs.hasBlend(t)) {
                fxRow(c, l, idx, AFxParam("blend", "Blend (dry ↔ wet)", 0f, 1f, AFxDefs.defaultBlend(t), 2))
            }
        }
        val pr = put(p, c, 0f, 3f, 6f)
        rows.add(pr.superview ?: pr); idxs.add(idx)
    }
    if (rows.count() > 1) {
        for ((n, h) in handles.withIndex()) {
            val pan = ClosurePan()
            pan.cb = { g ->
                dragFx(l, g, n, rows, idxs) { a, b -> val e = l.afx.removeAt(a); l.afx.add(b, e); audioFxChanged() }
            }
            h.addGestureRecognizer(pan)
        }
    }
}

/** Writes one parameter through its keyframe track. */
fun EditorViewController.afxSet(l: Layer, idx: Int, k: String, v: Float) {
    if (idx >= l.afx.count()) return
    val key = l.afxKey(l.afx[idx], k)
    val tr = l.track(key)
    tr.set(Editor.time, v, autoKeyOn)
    if (tr.keys.isEmpty()) {
        tr.base = v
        if (k == "blend") l.afx[idx].blend = v else l.afx[idx].p[k] = v
    }
    audioFxChanged()
}

/** The curve picture of an effect; dragging its dot edits two parameters at once. */
private fun EditorViewController.buildFxCurve(p: EVStack, l: Layer, idx: Int) {
    val it = l.afxAt(l.afx[idx], Editor.time)
    val cv = AudioFxCurveView()
    cv.type = it.type
    cv.item = it
    cv.onBegin = { pushUndo() }
    cv.onDrag = { xk, xv, yk, yv ->
        afxSet(l, idx, xk, xv); afxSet(l, idx, yk, yv)
        syncRows()
    }
    val kx = AudioFxCurveView.handleKeys(it.type)
    val trs = listOfNotNull(kx?.first, kx?.second).map { l.track(l.afxKey(l.afx[idx], it)) }
    cv.keyed = trs.isNotEmpty() && trs.all { it.keyAt(Editor.time) != null }
    put(p, cv, 170f)
    if (kx != null) {
        put(p, pill(if (cv.keyed) "Remove curve keyframe" else "Keyframe curve here", "diamond") {
            pushUndo()
            val t = Editor.time
            for (k in listOf(kx.first, kx.second)) {
                val tr = l.track(l.afxKey(l.afx[idx], k))
                val cur = tr.eval(t)
                if (tr.base != cur && tr.keys.isEmpty()) tr.base = cur
                if (cv.keyed) { if (tr.keyAt(t) != null) tr.toggleKey(t); if (tr.keys.isEmpty()) { tr.base = cur; l.afx[idx].p[k] = cur } }
                else if (tr.keyAt(t) == null) tr.toggleKey(t)
            }
            audioFxChanged(); refreshPanel()
        }, 38f)
        val nx = AFxDefs.params(it.type).firstOrNull { it.key == kx.first }?.label ?: ""
        val ny = AFxDefs.params(it.type).firstOrNull { it.key == kx.second }?.label ?: ""
        text(p, "Drag the dot: ← → $nx, ↑ ↓ $ny. Tap a parameter name, then the diamond, to keyframe it.", C.DIM, 12f)
    }
}

private fun EditorViewController.audioFxHeader(l: Layer, idx: Int, key: String, isOpen: Boolean): UiView {
    val bar = hRow()
    bar.setBackgroundColor(C.CARD)
    bar.add(EBox(IconView("handle", C.DIM, 20f), 36f, 48f, 14f, 0f, 0f, 0f))
    bar.add(EBox(IconView("afx_${l.afx[idx].type}", C.GREEN, 22f), 30f, 48f, 0f, 0f, 0f, 0f))
    val t = UILabel(com.saiki.motion.uikit.appContext!!)
    t.text = AFxDefs.name(l.afx[idx].type)
    t.textColor = argbToUIColor(C.TEXT)
    t.font = boldFont(16f)
    bar.add(growBox(t))
    val off = !l.afx[idx].on
    val eye = IconView(if (off) "eye_off" else "eye", if (off) C.DIM else C.GREEN, 20f)
    eye.onClick = {
        if (idx < l.afx.count()) {
            pushUndo(); l.afx[idx].on = !l.afx[idx].on; audioFxChanged(); refreshPanel()
        }
    }
    bar.add(EBox(eye, 40f, 48f, 0f, 0f, 0f, 0f))
    val chev = IconView(if (isOpen) "chev_up" else "chev_down", C.DIM, 20f)
    chev.onClick = {
        if (expanded.contains(key)) expanded.remove(key) else expanded.add(key)
        refreshPanel()
    }
    bar.add(EBox(chev, 40f, 48f, 0f, 0f, 0f, 0f))
    val more = IconView("more", C.TEXT, 20f)
    more.onClick = {
        if (idx < l.afx.count()) {
        Dlg(this).setTitle(AFxDefs.name(l.afx[idx].type)).setIconItems(listOf("Duplicate", "Reset to default", "Remove"), listOf("dup", "adjust", "trash")) { _, w ->
            if (idx >= l.afx.count()) return@setIconItems
            pushUndo()
            val old = l.afx[idx]
            when (w) {
                0 -> {
                    val n = old.copy(); n.uid = AudioFxItem.newUid()
                    l.afxCopyTracks(old.uid, n.uid)
                    l.afx.add(idx + 1, n)
                }
                1 -> {
                    l.afxDropTracks(old.uid)
                    val n = AudioFxItem(old.type); n.uid = old.uid
                    l.afx[idx] = n
                }
                else -> {
                    l.afxDropTracks(old.uid)
                    l.afx.removeAt(idx)
                }
            }
            audioFxChanged(); refreshPanel()
        }.show()
        }
    }
    bar.add(EBox(more, 40f, 48f, 0f, 0f, 0f, 0f))
    return bar
}

/** One effect parameter as a normal keyframable row. */
private fun EditorViewController.fxRow(p: EVStack, l: Layer, idx: Int, d: AFxParam) {
    if (idx >= l.afx.count()) return
    val it = l.afx[idx]
    val key = l.afxKey(it, d.key)
    val pd = PropDef(key, d.label, d.lo, d.hi, d.def, d.dec)
    Registry.dyn[key] = pd
    val tr: Track
    if (l.props[key] != null) { tr = l.props[key]!! } else { tr = Track(if (d.key == "blend") it.blend else it.v(d.key)); l.props[key] = tr }
    if (tr.keys.isEmpty()) tr.base = if (d.key == "blend") it.blend else it.v(d.key)
    if (d.options != null) {
        text(p, d.label, C.DIM, 12f)
        val cur = tr.eval(Editor.time).toInt()
        p.add(chipRow(d.options!!, cur) { i ->
            pushUndo(); afxSet(l, idx, d.key, i.toFloat()); refreshPanel()
        })
        val has = tr.keyAt(Editor.time) != null
        put(p, pill(if (has) "Remove ${d.label} keyframe" else "Keyframe ${d.label} here", "diamond") {
            pushUndo()
            val cur2 = tr.eval(Editor.time)
            tr.toggleKey(Editor.time)
            if (tr.keys.isEmpty()) { tr.base = cur2; l.afx[idx].p[d.key] = cur2 }
            audioFxChanged(); refreshPanel()
        }, 36f)
        return
    }
    val s = RulerSlider()
    s.label = d.label; s.lo = d.lo; s.hi = d.hi; s.dec = d.dec
    s.value = tr.eval(Editor.time)
    s.onBeginDrag = {
        pushUndo(); selKey = key; syncRows(s)
    }
    s.onChange = { v ->
        afxSet(l, idx, d.key, v)
        syncRows(s)
    }
    s.onLabelTap = {
        selKey = key
        syncRows()
        if (tr.keys.count() >= 2) { graphProp = key; graphKey = 0; openPanel(P_GRAPH) }
        else toast("Tap the diamond to keyframe ${d.label}; add 2 keys to edit its graph")
    }
    put(p, s, 60f)
    rows.add(EditorViewController.Row(s, pd, l))
}

private fun EditorViewController.buildEqUi(p: EVStack, l: Layer, idx: Int) {
    val eq = AudioEqView()
    eq.item = l.afxAt(l.afx[idx], Editor.time)
    eq.selected = EqSel.band
    eq.onBegin = { pushUndo() }
    eq.onChange = { item ->
        if (idx < l.afx.count()) {
            val cur = l.afxAt(l.afx[idx], Editor.time)
            for ((k, v) in item.p) if (Math.abs(v - cur.v(k)) > 1e-6f) afxSet(l, idx, k, v)
            syncRows()
        }
    }
    eq.onSelect = { b -> EqSel.band = b; refreshPanel() }
    put(p, eq, 230f)
    text(p, "Drag a dot: left/right = frequency, up/down = gain. Tap a dot to pick it, double-tap to flatten it.", C.DIM, 12f)
    val b = max(0, min(4, EqSel.band))
    for (k in listOf("q$b", "f$b", "g$b")) {
        val d = AFxDefs.params("eq").firstOrNull { it.key == k }
        if (d != null) fxRow(p, l, idx, d)
    }
    AFxDefs.params("eq").firstOrNull { it.key == "out" }?.let { fxRow(p, l, idx, it) }
    put(p, pill("Reset equalizer") {
        if (idx < l.afx.count()) {
        pushUndo()
        val u = l.afx[idx].uid; l.afxDropTracks(u)
        val n = AudioFxItem("eq"); n.uid = u; l.afx[idx] = n
        audioFxChanged(); refreshPanel()
        }
    }, 40f)
}

// ================================================================ AudioEqView

/** Custom equalizer: log-frequency / gain graph with 5 draggable band dots and the live combined response curve. */
class AudioEqView : UiView(appContext!!) {
    var item = AudioFxItem("eq")
        set(v) { field = v; setNeedsDisplay() }
    var selected = 2
    var onBegin: (() -> Unit)? = null
    var onChange: ((AudioFxItem) -> Unit)? = null
    var onSelect: ((Int) -> Unit)? = null

    private var drag = -1
    private val fMin: Float = 20f
    private val fMax: Float = 20000f
    private val gMax: Float = 18f
    private val bandColors = listOf(0xFFFF3B30.toInt(), 0xFFFF9500.toInt(), 0xFF34C759.toInt(), 0xFF30B0C7.toInt(), 0xFFAF52DE.toInt())

    init {
        val pan = UIPanGestureRecognizer { g -> onPan(g as UIPanGestureRecognizer) }
        addGestureRecognizer(pan)
        val dbl = UITapGestureRecognizer { onDouble() }
        dbl.numberOfTapsRequired = 2
        addGestureRecognizer(dbl)
        val tap = UITapGestureRecognizer { onTap() }
        addGestureRecognizer(tap)
    }

    private val plot: CGRect get() = CGRect(10f, 14f, max(1f, rectWidth() - 20f), max(1f, rectHeight() - 28f))
    private fun xFor(f: Float): Float = plot.minX + log(f / fMin, fMax / fMin) * plot.width
    private fun fFor(x: Float): Float = fMin * (fMax / fMin).pow((x - plot.minX) / plot.width)
    private fun yFor(g: Float): Float = plot.midY - (g / gMax) * plot.height / 2
    private fun gFor(y: Float): Float = ((plot.midY - y) / (plot.height / 2)) * gMax

    private fun nearest(pt: CGPoint): Int {
        var best = -1
        var bd = 44f * 44f
        for (i in 0 until 5) {
            val dx = xFor(item.v("f$i")) - pt.x
            val dy = yFor(item.v("g$i")) - pt.y
            val d = dx * dx + dy * dy
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    private fun onTap() {
        val i = nearest(lastTouchLocation)
        if (i >= 0) { selected = i; setNeedsDisplay(); onSelect?.invoke(i) }
    }
    private fun onDouble() {
        val i = nearest(lastTouchLocation)
        if (i < 0) return
        onBegin?.invoke(); item.p["g$i"] = 0f; selected = i; onChange?.invoke(item); onSelect?.invoke(i)
    }
    private fun onPan(g: UIPanGestureRecognizer) {
        val pt = g.location(this)
        when (g.state) {
            UIGestureRecognizerState.began -> {
                drag = nearest(pt)
                if (drag >= 0) { onBegin?.invoke(); selected = drag }
            }
            UIGestureRecognizerState.changed -> {
                if (drag < 0) return
                item.p["f$drag"] = min(fMax, max(fMin, fFor(pt.x)))
                item.p["g$drag"] = min(gMax, max(-gMax, gFor(pt.y)))
                onChange?.invoke(item)
            }
            UIGestureRecognizerState.ended, UIGestureRecognizerState.cancelled -> {
                if (drag >= 0) onSelect?.invoke(drag)
                drag = -1
            }
            else -> {}
        }
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val r = CGRect(0f, 0f, rect.width, rect.height)
        fillRoundRect(c, r, 12f, C.CARD2)
        val pl = plot
        // grid
        c.paint.style = Paint.Style.STROKE
        c.paint.strokeWidth = 1f
        c.paint.color = 0x1AFFFFFF
        val grid = Path()
        for (f in listOf(50f, 100f, 200f, 500f, 1000f, 2000f, 5000f, 10000f)) {
            grid.moveTo(xFor(f), pl.minY); grid.lineTo(xFor(f), pl.maxY)
        }
        for (g in listOf(-12f, -6f, 6f, 12f)) { grid.moveTo(pl.minX, yFor(g)); grid.lineTo(pl.maxX, yFor(g)) }
        c.canvas.drawPath(grid, c.paint)
        c.paint.color = 0x4DFFFFFF
        val mid = Path(); mid.moveTo(pl.minX, yFor(0f)); mid.lineTo(pl.maxX, yFor(0f))
        c.canvas.drawPath(mid, c.paint)
        for ((f, s) in listOf(100f to "100", 1000f to "1k", 10000f to "10k")) {
            drawText(s, xFor(f) + 2, pl.maxY - 4f, color = 0x73FFFFFF.toInt(), size = 9f)
        }
        for (g in listOf(12, 0, -12)) {
            drawText("$g", pl.minX + 2, yFor(g.toFloat()) - 4f, color = 0x73FFFFFF.toInt(), size = 9f)
        }

        // combined response
        val sr = 44100f
        val bq = ArrayList<Biquad>()
        for (i in 0 until 5) {
            val k: BiquadKind = if (i == 0) BiquadKind.lowShelf else (if (i == 4) BiquadKind.highShelf else BiquadKind.peak)
            bq.add(Biquad().also { it.set(k, item.v("f$i"), item.v("q$i"), item.v("g$i"), sr) })
        }
        val path = Path()
        val n = 160
        for (s in 0..n) {
            val x = pl.minX + pl.width * s / n
            var db = item.v("out")
            for (b in bq) db += b.magnitudeDb(fFor(x), sr)
            val py = min(pl.maxY, max(pl.minY, yFor(db)))
            if (s == 0) path.moveTo(x, py) else path.lineTo(x, py)
        }
        val fill = Path(path)
        fill.lineTo(pl.maxX, yFor(0f)); fill.lineTo(pl.minX, yFor(0f)); fill.close()
        c.paint.style = Paint.Style.FILL
        c.paint.color = (C.GREEN.toLong() and 0xFFFFFF or 0x2E000000L).toInt()
        c.canvas.drawPath(fill, c.paint)
        c.paint.style = Paint.Style.STROKE
        c.paint.strokeWidth = 2.5f
        c.paint.color = C.GREEN
        c.canvas.drawPath(path, c.paint)

        // band dots
        for (i in 0 until 5) {
            val px = xFor(item.v("f$i"))
            val py = yFor(item.v("g$i"))
            val rad = if (i == selected) 13f else 10f
            c.paint.style = Paint.Style.FILL
            c.paint.color = (bandColors[i].toLong() and 0xFFFFFF or (if (i == selected) 0x59L else 0x33L).shl(24)).toInt()
            c.canvas.drawCircle(px, py, rad + 5, c.paint)
            c.paint.color = bandColors[i]
            c.canvas.drawCircle(px, py, rad, c.paint)
            c.paint.style = Paint.Style.STROKE
            c.paint.strokeWidth = if (i == selected) 2.5f else 1.2f
            c.paint.color = 0xFFFFFFFF.toInt()
            c.canvas.drawCircle(px, py, rad, c.paint)
            drawText("${i + 1}", px - 3f, py + 5f, color = 0xFFFFFFFF.toInt(), size = 11f, bold = true)
        }
        // readout of the selected band
        val b = max(0, min(4, selected))
        val f = item.v("f$b")
        val g = item.v("g$b")
        val fs = if (f >= 1000f) String.format("%.2f kHz", f / 1000f) else String.format("%.0f Hz", f)
        val txt = "${AFxDefs.eqNames[b]}  $fs  ${String.format("%+.1f dB", g)}  Q ${String.format("%.2f", item.v("q$b"))}"
        drawText(txt, pl.minX + 6, pl.minY + 10f, color = 0xD9FFFFFF.toInt(), size = 11f, bold = true)
    }
}

// ================================================================ AudioFxCard

/** Browse card for an audio effect (same look as the visual effect cards, with an audio icon instead of a preview). */
class AudioFxCard(private val name: String, icon: String = "audio") : TapView() {
    var badge = false
        set(v) { field = v; setNeedsDisplay() }

    init {
        setBackgroundColor(C.CARD)
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width; val h = rect.height
        c.paint.style = Paint.Style.FILL
        c.paint.color = C.CARD
        c.canvas.drawRoundRect(RectF(0f, 0f, w, h), 14f, 14f, c.paint)
        com.saiki.motion.ui.Icons.draw(c, "audio", w / 2, 26f + 24f, 48f, C.GREEN)
        drawText(name, 16f, h - 34f, color = C.TEXT, size = 16f, bold = true)
        drawText("Audio", 16f, h - 18f, color = C.DIM, size = 13f)
        if (badge) {
            c.paint.color = C.GREEN
            c.canvas.drawCircle(w - 14f, 14f, 6f, c.paint)
        }
    }
}

// ================================================================ AudioFxCurveView

/**
 * Picture of what an effect does, redrawn live: comb response (flanger), notches (phaser),
 * LFO voices (chorus), waveform (modulator), auto-pan path, reverb decay, filter / tilt
 * response, echo taps, distortion transfer curve, compressor transfer curve.
 * One draggable dot edits the two most important parameters at once.
 */
class AudioFxCurveView : UiView(appContext!!) {
    var type = "flanger"
    var item = AudioFxItem("flanger")
        set(v) { field = v; setNeedsDisplay() }
    var keyed = false
        set(v) { field = v; setNeedsDisplay() }
    var onBegin: (() -> Unit)? = null
    var onDrag: ((String, Float, String, Float) -> Unit)? = null

    companion object {
        fun handleKeys(t: String): Pair<String, String>? = when (t) {
            "flanger" -> "delay" to "fb"
            "chorus" -> "rate" to "depth"
            "phaser" -> "freq" to "depth"
            "modulator" -> "freq" to "depth"
            "pan" -> "pan" to "depth"
            "reverb" -> "room" to "damp"
            "muffle" -> "cut" to "res"
            "tone" -> "pivot" to "tone"
            "echo" -> "time" to "fb"
            "dist" -> "tone" to "drive"
            "comp" -> "thresh" to "ratio"
            "wah" -> "freq" to "depth"
            "crush" -> "rate" to "bits"
            else -> null
        }
    }

    private val plot: CGRect get() = CGRect(12f, 16f, max(1f, rectWidth() - 24f), max(1f, rectHeight() - 32f))
    private val accent = C.GREEN

    init {
        addGestureRecognizer(UIPanGestureRecognizer { g -> onPan(g as UIPanGestureRecognizer) })
    }

    // value <-> 0…1 mapping (log for wide positive ranges such as Hz / ms / ratio)
    private fun def(k: String): AFxParam? = AFxDefs.params(type).firstOrNull { it.key == k }
    private fun isLog(d: AFxParam): Boolean = d.lo > 0f && d.hi / d.lo >= 15f
    private fun norm(d: AFxParam, v: Float): Float {
        val x = min(max(v, d.lo), d.hi)
        return if (isLog(d)) log(x / d.lo, d.hi / d.lo) else (x - d.lo) / (d.hi - d.lo)
    }
    private fun denorm(d: AFxParam, u: Float): Float {
        val c = min(max(u, 0f), 1f)
        return if (isLog(d)) d.lo * (d.hi / d.lo).pow(c) else d.lo + (d.hi - d.lo) * c
    }
    private fun handlePoint(): CGPoint? {
        val h = handleKeys(type) ?: return null
        val dx = def(h.first) ?: return null
        val dy = def(h.second) ?: return null
        return CGPoint(plot.minX + norm(dx, item.v(h.first)) * plot.width,
                       plot.maxY - norm(dy, item.v(h.second)) * plot.height)
    }

    private fun onPan(g: UIPanGestureRecognizer) {
        val h = handleKeys(type) ?: return
        val dx = def(h.first) ?: return
        val dy = def(h.second) ?: return
        if (g.state == UIGestureRecognizerState.began) onBegin?.invoke()
        if (g.state != UIGestureRecognizerState.began && g.state != UIGestureRecognizerState.changed) return
        val pt = g.location(this)
        val p = plot
        val xv = denorm(dx, (pt.x - p.minX) / p.width)
        val yv = denorm(dy, (p.maxY - pt.y) / p.height)
        item.p[h.first] = xv; item.p[h.second] = yv
        onDrag?.invoke(h.first, xv, h.second, yv)
    }

    // ---------------------------------------------------------------- drawing helpers
    private fun pts(n: Int, f: (Float) -> Float): List<CGPoint> {
        val p = plot
        return (0..n).map { i ->
            val u = i.toFloat() / n
            CGPoint(p.minX + u * p.width, p.maxY - min(max(f(u), -0.04f), 1.04f) * p.height)
        }
    }
    private fun curve(pt: List<CGPoint>, col: Int, w: Float = 2.5f, fill: Boolean = false) {
        val c = UIGraphics.getCurrentContext() ?: return
        if (pt.isEmpty()) return
        val b = Path(); b.moveTo(pt[0].x, pt[0].y)
        for (q in pt.drop(1)) b.lineTo(q.x, q.y)
        if (fill) {
            val cc = Path(b)
            val last = pt.last()
            cc.lineTo(last.x, plot.maxY); cc.lineTo(pt[0].x, plot.maxY); cc.close()
            c.paint.style = Paint.Style.FILL
            c.paint.color = (col.toLong() and 0xFFFFFF or 0x29000000L).toInt()
            c.canvas.drawPath(cc, c.paint)
        }
        c.paint.style = Paint.Style.STROKE
        c.paint.strokeWidth = w
        c.paint.strokeJoin = Paint.Join.ROUND
        c.paint.color = col
        c.canvas.drawPath(b, c.paint)
    }
    private fun grid(vx: Int, hy: Int) {
        val c = UIGraphics.getCurrentContext() ?: return
        val p = plot
        val path = Path()
        for (i in 0..vx) { val x = p.minX + p.width * i / vx; path.moveTo(x, p.minY); path.lineTo(x, p.maxY) }
        for (i in 0..hy) { val y = p.minY + p.height * i / hy; path.moveTo(p.minX, y); path.lineTo(p.maxX, y) }
        c.paint.style = Paint.Style.STROKE
        c.paint.strokeWidth = 1f
        c.paint.color = 0x14FFFFFF
        c.canvas.drawPath(path, c.paint)
    }
    private fun label(s: String, pt: CGPoint, a: Float = 0.5f) {
        drawText(s, pt.x, pt.y + 8f, color = ((a * 255).toInt() shl 24) or 0xFFFFFF, size = 9f)
    }
    private fun fmt(k: String): String = String.format("%.${def(k)?.dec ?: 2}f", item.v(k))

    private fun cmul(a: Pair<Float, Float>, b: Pair<Float, Float>): Pair<Float, Float> =
        Pair(a.first * b.first - a.second * b.second, a.first * b.second + a.second * b.first)

    // ---------------------------------------------------------------- the pictures
    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 12f, C.CARD2)
        val a = accent
        val dim = (accent.toLong() and 0xFFFFFF or 0x59000000L).toInt()
        val sr = 44100f

        when (type) {
            "flanger" -> {
                grid(5, 4)
                val d0 = item.v("delay"); val dp = item.v("depth"); val fb = item.v("fb")
                fun resp(dMs: Float): (Float) -> Float = { u ->
                    val th = 2f * Math.PI.toFloat() * u * 10000f * dMs * 0.001f
                    val cc = cos(th); val s = sin(th)
                    val dr = 1 - fb * cc; val di = fb * s; val q = max(dr * dr + di * di, 1e-6f)
                    val re = 1 + (cc * dr - s * di) / q
                    val im = (-s * dr - cc * di) / q
                    (10f * log10(max(re * re + im * im, 1e-4f)) + 30f) / 42f
                }
                curve(pts(260, resp(d0)), dim, 1.5f); curve(pts(260, resp(d0 + dp)), dim, 1.5f)
                curve(pts(260, resp(d0 + dp * 0.5f)), a, 2.5f, true)
                label("0", CGPoint(plot.minX + 2, plot.maxY - 10f)); label("5 kHz", CGPoint(plot.midX, plot.maxY - 10f)); label("10 kHz", CGPoint(plot.maxX - 30, plot.maxY - 10f))
            }
            "phaser" -> {
                grid(4, 4)
                val fc = item.v("freq"); val dp = item.v("depth"); val ns = max(2, item.v("stages").toInt())
                fun resp(cc: Float): (Float) -> Float = { u ->
                    val f = 40f * (16000f / 40f).pow(u)
                    val w = 2f * Math.PI.toFloat() * f / sr
                    val z = Pair(cos(w), -sin(w))
                    var P = Pair(1f, 0f)
                    for (s in 0 until ns) {
                        val fs = min(sr * 0.45f, cc * 2f.pow(stagger(s)))
                        val t = tan(Math.PI.toFloat() * fs / sr)
                        val aa = (1 - t) / (1 + t)
                        val num = Pair(aa + z.first, z.second)
                        val den = Pair(1 + aa * z.first, aa * z.second)
                        val dd = max(den.first * den.first + den.second * den.second, 1e-9f)
                        val q = Pair((num.first * den.first + num.second * den.second) / dd,
                                     (num.second * den.first - num.first * den.second) / dd)
                        P = cmul(P, q)
                    }
                    val re = 0.5f * (1 + P.first); val im = 0.5f * P.second
                    (10f * log10(max(re * re + im * im, 1e-5f)) + 40f) / 43f
                }
                val sw = 2f.pow(2.5f * dp)
                curve(pts(240, resp(max(30f, fc / sw))), dim, 1.5f); curve(pts(240, resp(min(sr * 0.4f, fc * sw))), dim, 1.5f)
                curve(pts(240, resp(fc)), a, 2.5f, true)
                label("100", CGPoint(plot.minX + plot.width * 0.17f, plot.maxY - 10f)); label("1k", CGPoint(plot.minX + plot.width * 0.46f, plot.maxY - 10f)); label("10k", CGPoint(plot.minX + plot.width * 0.83f, plot.maxY - 10f))
            }
            "chorus" -> {
                grid(4, 4)
                val dy = item.v("delay"); val dp = item.v("depth"); val nv = item.v("voices")
                for (v in 0 until 4) {
                    val vg = min(max(nv - v, 0f), 1f)
                    if (vg <= 0.01f) continue
                    val base = dy * (1 + 0.12f * v)
                    val off = v.toFloat() / 4f
                    val line = pts(120) { u ->
                        val m = 0.5f + 0.5f * sin(2f * Math.PI.toFloat() * (u * 2f + off))
                        (base + dp * m) / 62f
                    }
                    curve(line, (a.toLong() and 0xFFFFFF or (((0.25f + 0.75f * vg) * 255).toInt().toLong() shl 24)).toInt(), if (v == 0) 2.8f else 1.8f)
                }
                label("delay time of each voice (0–60 ms)", CGPoint(plot.minX + 4, plot.minY + 6f))
            }
            "modulator" -> {
                grid(4, 4)
                val w = item.v("wave").toInt(); val mode = item.v("mode").toInt(); val d = item.v("depth")
                curve(pts(260) { u ->
                    val m = afxLfo((u * 2f) % 1f, w)
                    val g = if (mode == 0) (1 - d) + d * m else 1 - d * (0.5f - 0.5f * m)
                    (g + 1f) / 2f
                }, a, 2.5f, true)
                label("gain", CGPoint(plot.minX + 4, plot.minY + 6f))
            }
            "pan" -> {
                grid(4, 4)
                val pn = item.v("pan"); val rt = item.v("rate"); val dp = item.v("depth")
                curve(pts(200) { u ->
                    val p = min(max(pn + min(rt * 20f, 1f) * dp * sin(2f * Math.PI.toFloat() * u * 2f), -1f), 1f)
                    (p + 1f) / 2f
                }, a, 2.5f)
                label("R", CGPoint(plot.minX + 4, plot.minY + 6f)); label("L", CGPoint(plot.minX + 4, plot.maxY - 10f))
            }
            "reverb" -> {
                grid(4, 4)
                val fbk = item.v("room") * 0.28f + 0.7f; val pre = item.v("pre") * 0.001f; val dmp = item.v("damp")
                val rt = 60f / max(-20f * log10(fbk), 0.05f) * 0.0295f
                val tmax = max(1f, (rt + pre) * 1.1f)
                fun env(r: Float): (Float) -> Float = { u ->
                    val t = u * tmax - pre
                    if (t < 0) 1f else max(0f, 1f - t / max(r, 0.05f))
                }
                curve(pts(80, env(rt * (1 - 0.6f * dmp))), dim, 1.5f)           // high frequencies die sooner when damped
                curve(pts(80, env(rt)), a, 2.5f, true)
                label(String.format("RT60 ≈ %.1f s", rt), CGPoint(plot.minX + 4, plot.minY + 6f), 0.8f)
            }
            "muffle" -> {
                grid(4, 4)
                val cut = item.v("cut"); val res = item.v("res"); val two = item.v("slope") > 0.5f
                val b1 = Biquad().also { it.set(BiquadKind.lowpass, cut, res, 0f, sr) }
                val b2 = Biquad().also { it.set(BiquadKind.lowpass, cut, 0.707f, 0f, sr) }
                curve(pts(200) { u ->
                    val f = 20f * 1000f.pow(u)
                    (b1.magnitudeDb(f, sr) + (if (two) b2.magnitudeDb(f, sr) else 0f) + 48f) / 60f
                }, a, 2.5f, true)
                label("100", CGPoint(plot.minX + plot.width * 0.23f, plot.maxY - 10f)); label("1k", CGPoint(plot.minX + plot.width * 0.56f, plot.maxY - 10f)); label("10k", CGPoint(plot.minX + plot.width * 0.89f, plot.maxY - 10f))
            }
            "tone" -> {
                grid(4, 4)
                val t = item.v("tone"); val pv = item.v("pivot"); val lv = item.v("level")
                val b1 = Biquad().also { it.set(BiquadKind.lowShelf, pv, 0.7f, -t * 12f, sr) }
                val b2 = Biquad().also { it.set(BiquadKind.highShelf, pv, 0.7f, t * 12f, sr) }
                curve(pts(200) { u ->
                    val f = 20f * 1000f.pow(u)
                    (b1.magnitudeDb(f, sr) + b2.magnitudeDb(f, sr) + lv + 18f) / 36f
                }, a, 2.5f, true)
            }
            "echo" -> {
                grid(8, 2)
                val t = item.v("time"); val fb = item.v("fb")
                val span = 3000f
                fun bar(x: Float, h: Float, col: Int, w: Float) {
                    val c2 = UIGraphics.getCurrentContext() ?: return
                    val px = plot.minX + (x / span) * plot.width
                    c2.paint.style = Paint.Style.STROKE
                    c2.paint.strokeWidth = w
                    c2.paint.strokeCap = Paint.Cap.ROUND
                    c2.paint.color = col
                    c2.canvas.drawLine(px, plot.maxY, px, plot.maxY - h * plot.height, c2.paint)
                }
                bar(0f, 1f, 0xB3FFFFFF.toInt(), 4f)
                var k = 1
                while (k < 60) {
                    val x = k.toFloat() * t
                    val h = fb.pow(k.toFloat())
                    if (x > span || h < 0.02f) break
                    bar(x, h, a, 4f); k += 1
                }
                label("0", CGPoint(plot.minX + 2, plot.maxY - 10f)); label("3 s", CGPoint(plot.maxX - 18, plot.maxY - 10f))
            }
            "dist" -> {
                grid(4, 4)
                val dr = 10f.pow(item.v("drive") / 20f); val sh = item.v("shape").toInt(); val lv = 10f.pow(item.v("level") / 20f)
                curve(pts(200) { u ->
                    val x = (u * 2f - 1f) * dr
                    var y: Float = when (sh) {
                        1 -> max(-1f, min(1f, x))
                        2 -> { var yy = x; var k = 0; while (Math.abs(yy) > 1f && k < 6) { yy = if (yy > 1f) 2f - yy else (if (yy < -1f) -2f - yy else yy); k += 1 }; yy }
                        else -> tanh(x)
                    }
                    (y * lv + 1f) / 2f
                }, a, 2.5f)
                label("in → out", CGPoint(plot.minX + 4, plot.minY + 6f))
            }
            "wah" -> {
                grid(4, 4)
                val fc = item.v("freq"); val dp = item.v("depth"); val q = max(0.3f, item.v("res"))
                fun resp(cc: Float): (Float) -> Float = { u ->
                    val x = 40f * (16000f / 40f).pow(u) / cc
                    val m = (x / q) / max(((1 - x * x) * (1 - x * x) + (x / q) * (x / q)).pow(0.5f), 1e-6f)
                    (20f * log10(max(m, 1e-3f)) + 36f) / 42f
                }
                val sw = 2f.pow(2.5f * dp)
                curve(pts(200, resp(max(30f, fc / sw))), dim, 1.5f); curve(pts(200, resp(fc * sw)), dim, 1.5f)
                curve(pts(200, resp(fc)), a, 2.5f, true)
                label("100", CGPoint(plot.minX + plot.width * 0.17f, plot.maxY - 10f)); label("1k", CGPoint(plot.minX + plot.width * 0.46f, plot.maxY - 10f)); label("10k", CGPoint(plot.minX + plot.width * 0.83f, plot.maxY - 10f))
            }
            "crush" -> {
                grid(4, 4)
                val bt = item.v("bits"); val rt = item.v("rate")
                val lv = 2f.pow(max(bt, 1f) - 1f)
                curve(pts(2) { u -> u }, dim, 1.2f)
                curve(pts(240) { u ->
                    val x = u * 2f - 1f
                    val y = max(-1f, min(1f, (x * lv).toInt().toFloat() / lv))
                    (y + 1f) / 2f
                }, a, 2.5f)
                label(String.format("%.1f bit  ·  %.0f Hz", bt, rt), CGPoint(plot.maxX - 90, plot.minY + 6f), 0.8f)
            }
            "comp" -> {
                grid(6, 6)
                val t = item.v("thresh"); val r = max(1f, item.v("ratio")); val w = item.v("knee"); val mk = item.v("makeup")
                val lo = -60f; val hi = 12f
                fun out(x: Float): Float {
                    val o = x - t
                    var y = x
                    if (w < 0.01f) { if (o > 0) y = t + o / r } else if (2 * o > w) y = t + o / r
                    else if (2 * Math.abs(o) <= w) { val q = o + w / 2; y = x + (1 / r - 1) * q * q / (2 * w) }
                    return y + mk
                }
                curve(pts(2) { u -> u * 60f / (hi - lo) }, dim, 1.2f)          // 1:1 reference
                curve(pts(160) { u -> (out(lo + u * 60f) - lo) / (hi - lo) }, a, 2.5f)
                val tx = plot.minX + ((t - lo) / 60f) * plot.width
                val c3 = UIGraphics.getCurrentContext() ?: return
                c3.paint.style = Paint.Style.STROKE
                c3.paint.strokeWidth = 1f
                c3.paint.color = 0x40FFFFFF
                c3.paint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(3f, 3f), 0f)
                c3.canvas.drawLine(tx, plot.minY, tx, plot.maxY, c3.paint)
                c3.paint.pathEffect = null
                label("in (dB)", CGPoint(plot.maxX - 34, plot.maxY - 10f)); label("out", CGPoint(plot.minX + 4, plot.minY + 6f))
            }
        }

        if (keyed) {                                  // diamond = this moment is keyframed
            val c4 = UIGraphics.getCurrentContext() ?: return
            val cx = rect.maxX - 18f
            val cy = 16f
            val d = Path()
            d.moveTo(cx, cy - 7f); d.lineTo(cx + 7f, cy); d.lineTo(cx, cy + 7f); d.lineTo(cx - 7f, cy); d.close()
            c4.paint.style = Paint.Style.FILL
            c4.paint.color = accent
            c4.canvas.drawPath(d, c4.paint)
        }
        // readout + draggable dot
        val h = handleKeys(type)
        val pt = handlePoint()
        if (h != null && pt != null) {
            val c5 = UIGraphics.getCurrentContext() ?: return
            val txt = "${def(h.first)?.label ?: ""}  ${fmt(h.first)}      ${def(h.second)?.label ?: ""}  ${fmt(h.second)}"
            drawText(txt, plot.minX + 4, rect.maxY - 8f, color = 0xCCFFFFFF.toInt(), size = 10f, bold = true)
            c5.paint.style = Paint.Style.FILL
            c5.paint.color = (accent.toLong() and 0xFFFFFF or 0x40000000L).toInt()
            c5.canvas.drawCircle(pt.x, pt.y, 17f, c5.paint)
            c5.paint.color = accent
            c5.canvas.drawCircle(pt.x, pt.y, 9f, c5.paint)
            c5.paint.style = Paint.Style.STROKE
            c5.paint.strokeWidth = 2f
            c5.paint.color = 0xFFFFFFFF.toInt()
            c5.canvas.drawCircle(pt.x, pt.y, 9f, c5.paint)
        }
    }
}
