@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorAudioLibrary.swift — the "Audio" folder picker sheet.
// (The AudioLibrary object + AudioLibraryController already live in core/AudioLibrary.kt.)

package com.saiki.motion.app

import com.saiki.motion.core.AudioLibrary
import com.saiki.motion.core.AudioLibraryController

/** Opens the audio library; picking a file adds it as an audio layer (same path as the Files picker). */
fun EditorViewController.showAudioLibrary() {
    val vc = AudioLibraryController()
    vc.onPick = { file ->
        pendingPick = R_AUDIOFILE
        // iOS reuses the document-picker callback with the library file; the Kotlin flow copies
        // through the same didPickDocumentsAt path via the content Uri of the picked file —
        // simplest parity: hand the absolute path straight to addMedia (already in the sandbox).
        val l = addLayer(com.saiki.motion.core.LayerType.AUDIO)
        l.imagePath = file.path
        l.name = afterFirst(file.name, '_')
        refreshTitle(); refreshPanel(); render()
    }
    vc.onBrowse = { pickFile(R_AUDIOFILE) }
    val nav = com.saiki.motion.uikit.UINavigationController(vc)
    present(nav, animated = true)
}
