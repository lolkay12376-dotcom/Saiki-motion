@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorBlendSpeed.swift — Blending + Speed panels and the time-remap helpers.

package com.saiki.motion.app

import com.saiki.motion.core.Defs
import com.saiki.motion.core.Ease
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Key
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.Registry
import com.saiki.motion.core.clamp
import com.saiki.motion.core.retime
import com.saiki.motion.core.retimeSnapshot
import com.saiki.motion.ui.BlendPicker
import com.saiki.motion.ui.C
import com.saiki.motion.ui.FillSlider
import com.saiki.motion.ui.SwitchRow
import com.saiki.motion.uikit.argbToUIColor
import kotlin.math.abs
import com.saiki.motion.ui.boldFont
import com.saiki.motion.ui.chipRow
import com.saiki.motion.ui.sysFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.appContext

fun EditorViewController.buildBlend(l: Layer) {
    val p = panelList
    text(p, "Blending", C.TEXT, 16f, true)
    addRow(p, l, Defs.transform[3])
    text(p, "Blend mode", C.DIM)
    p.add(BlendPicker.build(l.blend, { m ->
        pushUndo()
        l.blend = m
        refreshPanel(); render()
    }, { refreshPanel() }))
    val mb = SwitchRow()
    mb.label = "Motion blur"; mb.on = l.mblur
    mb.onToggle = { v ->
        pushUndo()
        l.mblur = v
        refreshPanel(); render()
    }
    put(p, mb, 52f)
    if (l.mblur) {
        addRow(p, l, Defs.blur[0])
        addRow(p, l, Defs.blur[1])
        text(p, "Works on every layer: shapes, text, media, video, groups, particles and 3D. A camera with motion blur on blurs all 3D layers below it. More samples is smoother but slower.", C.DIM, 12f)
    }
}

fun EditorViewController.buildSpeed(l: Layer) {
    val p = panelList
    val hasMap = l.props["remapT"]?.keys?.isNotEmpty() == true
    val spd = l.speedAt(Editor.time)
    val head = hRow()
    val ht = UILabel(com.saiki.motion.uikit.appContext!!)
    ht.text = "Playback Speed"
    ht.textColor = argbToUIColor(C.TEXT)
    ht.font = boldFont(16f)
    head.add(growBox(ht))
    val here = UILabel(com.saiki.motion.uikit.appContext!!)
    here.text = String.format(java.util.Locale.US, "%.2fx here", spd)
    here.textColor = argbToUIColor(C.DIM)
    here.font = sysFont(13f)
    head.add(EBox(here, 110f, 20f, 0f, 0f, 0f, 0f))
    put(p, head, 0f, 4f, 4f)
    val fs = FillSlider()
    fs.lo = 0.1f
    fs.hi = 4f
    fs.value = kotlin.math.abs(if (hasMap) 1f else l.track("remapSpeed").eval(Editor.time))
    fs.value = clamp(fs.value, 0.1f, 4f)
    fs.isUserInteractionEnabled = !hasMap
    var rsnap: com.saiki.motion.core.RetimeSnap? = null
    fs.onBeginDrag = { pushUndo(); rsnap = l.retimeSnapshot() }
    fs.onChange = { v ->
        ensureRemap(l)
        l.track("remapSpeed").set(Editor.time, v, autoKeyOn)
        l.retime(rsnap)
        here.text = String.format(java.util.Locale.US, "%.2fx here", v)
        render()
    }
    put(p, fs, 46f)
    val presets = listOf(0.1f, 0.25f, 0.5f, 1f, 2f, 4f)
    val labels = listOf("0.1x", "0.25x", "0.5x", "1.0x", "2.0x", "4.0x")
    for (rowStart in listOf(0, 3)) {
        val rw = hRow()
        rw.spacing = 3f
        for (k in rowStart until rowStart + 3) {
            val on = !hasMap && kotlin.math.abs(spd - presets[k]) < 0.01f
            val b = pill(labels[k], null, if (on) C.GREEN else C.CARD2, if (on) C.ONDARK else C.TEXT) {
                if (!hasMap) {
                    pushUndo()
                    val snap = l.retimeSnapshot()
                    ensureRemap(l)
                    val tr = l.track("remapSpeed")
                    tr.keys.clear()
                    tr.base = presets[k]
                    l.retime(snap)
                    refreshPanel(); render()
                }
            }
            rw.add(EBox(b, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        }
        put(p, rw, 40f)
    }
    if (hasMap) text(p, "Time Remap keyframes are driving playback. Remove them to use the speed slider.", C.AMBER, 12f)

    text(p, "Time Remap", C.TEXT, 16f, true)
    if (!hasMap) {
        text(p, "Keyframe which moment of the source plays at each point in time.", C.DIM, 12f)
        put(p, pill("Add Time Remap keyframes", "plus") {
            pushUndo()
            ensureRemapKeys(l)
            selKey = "remapT"
            refreshPanel(); render()
        }, 44f)
        val q = hRow()
        q.spacing = 3f
        q.add(EBox(pill("Freeze frame") {
            pushUndo()
            val sn = l.retimeSnapshot(); freezeFrame(l); l.retime(sn)
            selKey = "remapT"
            refreshPanel(); render()
        }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        q.add(EBox(pill("Reverse") {
            pushUndo()
            val sn = l.retimeSnapshot(); reverseRemap(l); l.retime(sn)
            selKey = "remapT"
            refreshPanel(); render()
        }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        put(p, q, 40f)
    } else {
        val rd = Registry.get("remap")
        val def = rd?.props?.firstOrNull { it.key == "remapT" }
        if (def != null) addRow(p, l, def, "Time Remap (s)")
        val q = hRow()
        q.spacing = 3f
        q.add(EBox(pill("Freeze frame") {
            pushUndo()
            val sn = l.retimeSnapshot(); freezeFrame(l); l.retime(sn)
            refreshPanel(); render()
        }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        q.add(EBox(pill("Reverse") {
            pushUndo()
            val sn = l.retimeSnapshot(); reverseRemap(l); l.retime(sn)
            refreshPanel(); render()
        }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        put(p, q, 40f)
        put(p, pill("Remove Time Remap", "trash", C.CARD2, C.RED) {
            pushUndo()
            val sn = l.retimeSnapshot()
            l.track("remapT").keys.clear()
            l.retime(sn)
            refreshPanel(); render()
        }, 42f)
        text(p, "Tap the name, then the keyframe diamond, to add a keyframe at the playhead.", C.DIM, 12f)
    }

    text(p, "Frame Interpolation", C.TEXT, 16f, true)
    val itr = l.track("remapInterp")
    p.add(chipRow(listOf("Off", "Frame Blend", "Optical Flow"), ktInt(itr.base)) { i ->
        pushUndo()
        ensureRemap(l)
        itr.keys.clear()
        itr.base = i.toFloat()
        refreshPanel(); render()
    })
    when (ktInt(itr.base)) {
        1 -> text(p, "Blends the two source frames around each moment, so slow motion looks smooth instead of stepping.", C.DIM, 12f)
        2 -> text(p, "Optical Flow currently uses Frame Blend. It applies to video layers.", C.DIM, 12f)
        else -> text(p, "Shows the nearest source frame. Slow motion on video can look steppy.", C.DIM, 12f)
    }
    if (l.type != LayerType.VIDEO) text(p, "Frame interpolation only affects video layers.", C.DIM, 12f)
}

fun EditorViewController.ensureRemap(l: Layer) {
    if (!l.fx.contains("remap")) l.fx.add("remap")
    l.fxOff.remove("remap")
}

/** Creates the two identity Time Remap keyframes when none exist yet. */
fun EditorViewController.ensureRemapKeys(l: Layer) {
    ensureRemap(l)
    val tr = l.track("remapT")
    if (tr.keys.isNotEmpty()) return
    val sp = l.track("remapSpeed").base
    tr.keys.add(Key(l.start, 0f, Ease.LINEAR))
    tr.keys.add(Key(l.end, (l.end - l.start) * sp, Ease.LINEAR))
}

/** Holds the current source frame for one second, pushing later keyframes back. */
fun EditorViewController.freezeFrame(l: Layer) {
    ensureRemapKeys(l)
    val tr = l.track("remapT")
    val t = Editor.time
    val v = tr.eval(t)
    val hold: Float = 1f
    for (k in tr.keys) if (k.t > t + 0.001f) k.t += hold
    if (tr.keys.none { abs(it.t - t) < 0.001f }) tr.keys.add(Key(t, v, Ease.LINEAR))
    tr.keys.add(Key(t + hold, v, Ease.LINEAR))
    tr.keys.sortBy { it.t }
}

/** Plays the layer backwards. */
fun EditorViewController.reverseRemap(l: Layer) {
    ensureRemap(l)
    val tr = l.track("remapT")
    tr.keys.clear()
    tr.keys.add(Key(l.start, l.end - l.start, Ease.LINEAR))
    tr.keys.add(Key(l.end, 0f, Ease.LINEAR))
}
