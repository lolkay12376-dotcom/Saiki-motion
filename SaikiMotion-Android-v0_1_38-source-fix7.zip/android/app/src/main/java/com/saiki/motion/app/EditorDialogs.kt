@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorDialogs.swift — motion blur, parent popup, expressions,
// scene setup dialog, render launcher, panel menu + EditorImport (pickers, addMedia, audio
// extraction, beat markers) + EditorSceneSetup + EditorLiveCache + EditorPen/PointMap/Depth/Pbr.

package com.saiki.motion.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import com.saiki.motion.core.AudioTools
import com.saiki.motion.core.CrashLog
import com.saiki.motion.core.DepthAnything
import com.saiki.motion.core.DepthModelKind
import com.saiki.motion.core.Defs
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Expr
import com.saiki.motion.core.FlareThumbs
import com.saiki.motion.core.FontLibrary
import com.saiki.motion.core.FrameCache
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.MetalModelRenderer
import com.saiki.motion.core.MistSettings
import com.saiki.motion.core.PBRMaps
import com.saiki.motion.core.PlyImport
import com.saiki.motion.core.PreRender
import com.saiki.motion.core.Projects
import com.saiki.motion.core.Registry
import com.saiki.motion.core.SceneRenderer
import com.saiki.motion.core.Scene
import com.saiki.motion.core.VdbVolume
import com.saiki.motion.core.nowMs
import com.saiki.motion.core.optS
import com.saiki.motion.core.retime
import com.saiki.motion.core.retimeSnapshot
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.ui.C
import com.saiki.motion.ui.ColorPickerView
import com.saiki.motion.ui.IconView
import com.saiki.motion.ui.RulerSlider
import com.saiki.motion.ui.SwitchRow
import com.saiki.motion.ui.TapView
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.ui.boldFont
import com.saiki.motion.ui.chipRow
import com.saiki.motion.ui.sysFont
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.ui.AspectPresets
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// ================================================================ motion blur settings + parent popup

fun EditorViewController.showMotionBlurSettings(l: Layer) {
    val box = vStack()
    val on = SwitchRow()
    on.label = "Motion blur"
    on.on = l.mblur
    on.onToggle = { v ->
        pushUndo()
        l.mblur = v
        mbToggle.on = v
        render()
    }
    put(box, on, 52f)
    val stut = SwitchRow()
    stut.label = "Stuttering"
    stut.on = l.mbStutter
    stut.onToggle = { v -> pushUndo(); l.mbStutter = v; render() }
    put(box, stut, 52f)
    val rgb = SwitchRow()
    rgb.label = "Enable RGB sampling"
    rgb.on = l.mbRgb
    rgb.onToggle = { v -> pushUndo(); l.mbRgb = v; render() }
    put(box, rgb, 52f)
    text(box, "Quality", C.DIM, 13f)
    val smp = l.track("mbSamples")
    val q = if (smp.base <= 5f) 0 else (if (smp.base <= 10f) 1 else 2)
    box.add(chipRow(listOf("Low", "Medium", "High"), q) { i ->
        pushUndo()
        smp.keys.clear()
        smp.base = listOf(4f, 8f, 16f)[i]
        render()
    })
    val amt = l.track("mbAmount")
    addPlain(box, "Blur strength", 0f, 4f, amt.base, 2) { v ->
        pushUndo()
        amt.keys.clear()
        amt.base = v
        render()
    }
    if (l.type == LayerType.CAMERA) text(box, "Camera motion blur: every 3D layer below this camera is blurred by the camera's movement.", C.DIM, 12f)
    text(box, "Stuttering snaps the blur samples to whole frames. RGB sampling gives the trails a red-to-blue fringe.", C.DIM, 12f)
    val sv = PanelScroll()
    sv.content.add(box)
    // a scroll view has no intrinsic height → the panel opened empty. Size it to its content.
    Dlg(this).setTitle("Motion blur").setView(sv).setPositiveButton("Done", null).show()
    sv.postLayout2 = { w ->
        box.frame = CGRect(0f, 0f, w ?: 0f, box.totalH)
        sv.content.frame = CGRect(0f, 0f, w ?: 0f, box.totalH)
        sv.frame = CGRect(sv.frame.x, sv.frame.y, w ?: 0f, minOf(box.totalH + 4f, 380f))
    }
}

fun EditorViewController.typeIcon(t: LayerType): String = when (t) {
    LayerType.SHAPE -> "shape"
    LayerType.TEXT -> "text"
    LayerType.IMAGE, LayerType.VIDEO -> "media"
    LayerType.CAMERA -> "camera"
    LayerType.NULL -> "nullobj"
    LayerType.MODEL -> "cube"
    LayerType.PARTICLES -> "particles"
    LayerType.GROUP -> "layers"
    LayerType.ADJUST -> "adjust"
    LayerType.AUDIO -> "audio"
    LayerType.FLARE -> "flare"
}

fun EditorViewController.showParentPopup(l: Layer, anchor: UiView) {
    val cands = Editor.scene.layers.filter { it.id != l.id && !Layer.isDescendant(it, l, Editor.scene.layers) }
    val col = vStack()
    col.setBackgroundColor(C.CARD)
    fun item(icon: String, name: String, on: Boolean, pick: () -> Unit) {
        val row = hRow()
        row.setBackgroundColor(0xFF2A2A30.toInt())
        if (on) row.setBackgroundColor(C.GREEN)
        val ic = IconView(icon, if (on) C.GREEN else C.TEXT, 20f)
        ic.isUserInteractionEnabled = false
        row.add(EBox(ic, 32f, 44f, 10f, 0f, 0f, 0f))
        val tv = UILabel(com.saiki.motion.uikit.appContext!!)
        tv.text = name
        tv.textColor = argbToUIColor(C.TEXT)
        tv.font = sysFont(15f)
        tv.numberOfLines = 1
        row.add(growBox(tv))
        val tap = TapView()
        tap.addSubview(row)
        tap.onClick = pick
        put(col, tap, 46f, 3f, 3f)
        tap.postLayout = { w -> row.frame = CGRect(0f, 0f, w ?: 0f, 46f) }
    }
    item("close", "None", l.parentId < 0) {
        pushUndo()
        com.saiki.motion.core.Xf.reparentKeepingPose(l, -1, Editor.time, autoKeyOn)
        refreshTitle(); refreshPanel(); render()
        Dlg.dismissCurrent()
    }
    for (c in cands) {
        item(typeIcon(c.type), c.name, l.parentId == c.id) {
            pushUndo()
            com.saiki.motion.core.Xf.reparentKeepingPose(l, c.id, Editor.time, autoKeyOn)
            refreshTitle(); refreshPanel(); render()
            Dlg.dismissCurrent()
        }
    }
    val sv = PanelScroll()
    sv.content.add(col)
    Dlg(this).setTitle("Parent").setView(sv).setNegativeButton("Close", null).show()
    sv.postLayout2 = { w ->
        col.frame = CGRect(0f, 0f, min(w ?: 0f, 240f), col.totalH)
        sv.content.frame = CGRect(0f, 0f, min(w ?: 0f, 240f), col.totalH)
        sv.frame = CGRect(sv.frame.x, sv.frame.y, min(w ?: 0f, 240f), minOf(col.totalH + 4f, 360f))
    }
}

// ================================================================ expressions, audio, beats

fun EditorViewController.showExpression(l: Layer, d: com.saiki.motion.core.PropDef) {
    val tr = l.track(d.key)
    val box = vStack()
    val sw = SwitchRow()
    sw.label = "fx  (expression)"
    sw.on = tr.exprOn && tr.exprSrc.trim().isNotEmpty()
    sw.captionOn = "On"; sw.captionOff = "Off"
    val swOn = booleanArrayOf(sw.on)
    sw.onToggle = { v -> swOn[0] = v }
    put(box, sw, 52f)
    text(box, "t = time, v = keyframed value. wiggle(freq, amp), sin, cos, abs, min, max, clamp, pow, sqrt, linear(t, a, b, c, d), noise, floor, round, mix, if(c, a, b), step(a, b), comparisons < > <= >= ==, pi, marker.key(\"name\"), Controls tab: slider, angle, checkbox, pointx, pointy, point3x/y/z, colorr/g/b, layerctl — e.g. angle(\"Layer\") or angle(\"Layer\", 2).", C.DIM, 12f)
    val et = makeField(tr.exprSrc)
    et.font = monoFont(14f)
    et.placeholder = "v + wiggle(3, 0.1)"
    put(box, et, 44f)
    val presets = listOf("v + wiggle(3, 0.1)", "v * (1 + 0.2 * sin(t * 8))", "v + t * 90", "v + abs(sin(t * 4)) * 0.3", "")
    box.add(chipRow(listOf("Wiggle", "Pulse", "Spin", "Bounce", "Clear"), -1) { i ->
        et.text = presets[i]
    })
    val ctls = Expr.allControls()
    if (ctls.isNotEmpty()) {
        text(box, "Controls (tap to insert)", C.DIM, 12f)
        box.add(chipRow(ctls.map { it.first }, -1) { i ->
            et.text = et.text + ctls[i].second
        })
    }
    val names = Editor.scene.markerNames.values.sorted()
    if (names.isNotEmpty()) {
        text(box, "Named markers (tap to insert)", C.DIM, 12f)
        box.add(chipRow(names, -1) { i ->
            et.text = et.text + "marker.key(\"" + names[i] + "\")"
        })
    }
    Dlg(this).setTitle("Expression: " + d.label).setView(box).setPositiveButton("Apply") { _, _ ->
        pushUndo()
        val src = et.text
        if (!tr.setExpr(src)) {
            toast("Expression error")
        } else {
            tr.exprOn = swOn[0] && src.trim().isNotEmpty()
            refreshPanel(); render()
        }
    }.setNegativeButton("Cancel", null).show()
}

fun EditorViewController.snapKeys(l: Layer) {
    val ms = Editor.scene.markers
    for ((_, tr) in l.props) {
        var ch = false
        for (k in tr.keys) {
            val m = ms.minByOrNull { abs(it - k.t) }
            if (m != null && abs(m - k.t) < 0.35f) { k.t = m; ch = true }
        }
        if (ch) tr.keys.sortBy { it.t }
    }
    toast("Keyframes snapped to markers")
}

fun EditorViewController.showPanelMenu() {
    val l = selected() ?: return
    Dlg(this).setTitle("Layer").setItems(listOf("Clear all keyframes", "Reset transform", "Snap keyframes to beat markers")) { _, which ->
        pushUndo()
        if (which == 2) {
            snapKeys(l)
        } else {
            for ((k, tr) in l.props) {
                if (which == 0) {
                    tr.keys.clear()
                    tr.setExpr("")
                    tr.exprOn = false
                } else if (Defs.transform.any { it.key == k }
                           || Defs.rot3d.any { it.key == k } || k == "z") {
                    tr.keys.clear()
                    tr.base = Registry.propDef(k)?.def ?: 0f
                }
            }
        }
        refreshPanel(); render()
    }.show()
}

// ================================================================ scenes + export

val expressionDoc = """
SAIKIMOTION EXPRESSIONS

HOW TO USE
1. Open a layer panel and tap a parameter.
2. Tap the command icon in the left rail.
3. Type an expression, switch it On, tap Apply.
The parameter outline turns orange to red while an expression drives it.

VARIABLES
t           time in seconds
v           the parameter's own (keyframed) value
pi          3.14159
marker.key("name")   value of a named marker

FUNCTIONS
sin(x) cos(x) abs(x) sqrt(x) floor(x) round(x)
min(a, b)  max(a, b)  pow(a, b)
clamp(x, lo, hi)
mix(a, b, k)           a + (b - a) * k
step(a, b)             0 if b < a, else 1
if(c, a, b)            a when c is true, else b
linear(t, a, b, c, d)  maps t from a..b to c..d
wiggle(freq, amp)      smooth random motion
noise(x)               smooth noise
Comparisons: < > <= >= ==
Operators: + - * / with ( )

CONTROLS TAB (Effects > Controls)
Add a control to a layer (usually a Null), then read it anywhere:
slider("Layer")            Slider Control
angle("Layer")             Angle Control (degrees)
checkbox("Layer")          Checkbox Control (0 or 1)
pointx("Layer")  pointy("Layer")                    Point Control
point3x("Layer") point3y("Layer") point3z("Layer")  3D Point Control
colorr("Layer") colorg("Layer") colorb("Layer")     Color Control (0 to 1)
layerctl("Layer")          Layer Control (layer number)
Add ", 2" for the second control of the same kind: angle("Layer", 2)

EXAMPLES
v + wiggle(3, 0.1)                     shake
v * (1 + 0.2 * sin(t * 8))             pulse
v + t * 90                             spin
v + abs(sin(t * 4)) * 0.3              bounce
slider("Null 1") * 2                   drive from a slider
if(checkbox("Null 1"), v, 0)           switch on or off
v + angle("Null 1") * 0.5              follow an angle
linear(t, 0, 2, 0, 100)                ramp 0 to 100 over 2 seconds
clamp(v + wiggle(2, 5), 0, 100)        shake within limits
"""

fun EditorViewController.showExpressionDoc() {
    val tv = PLabel()
    tv.text = expressionDoc; tv.color = C.TEXT; tv.size = 12f
    val sv = PanelScroll()
    sv.content.add(tv)
    Dlg(this).setTitle("Expression reference").setView(sv).setPositiveButton("Copy all") { _, _ ->
        val cm = appContext!!.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("expressions", expressionDoc))
        toast("Copied")
    }.setNegativeButton("Close", null).show()
    sv.postLayout2 = { w ->
        tv.frame = CGRect(0f, 0f, (w ?: 0f) - 8f, tv.height((w ?: 0f) - 20f))
        sv.content.frame = CGRect(0f, 0f, w ?: 0f, tv.height((w ?: 0f) - 20f))
        sv.frame = CGRect(sv.frame.x, sv.frame.y, w ?: 0f, minOf(view.rectHeight() * 0.6f, 480f))
    }
}

fun EditorViewController.showSceneDialog() {
    val box = vStack()
    val dlg = Dlg(this).setTitle("Scene setup").setView(box).create()
    val applyName = arrayOf<() -> Unit>({})
    fun build() {
        box.clear()
        val pr = Editor.project
        val s = Editor.scene

        // ---- project identity
        text(box, "Project name", C.GREEN, 13f, true)
        val nameF = makeField(pr.name)
        put(box, nameF, 44f, 0f, 0f)
        applyName[0] = {
            val nm = nameF.text.trim()
            if (nm.isNotEmpty() && nm != pr.name) {
                pushUndo()
                pr.name = nm
                refreshTitle()
            }
        }

        // ---- canvas + frame rate
        text(box, "Canvas", C.GREEN, 13f, true)
        text(box, "${pr.w} x ${pr.h}  ·  ${Projects.resLabel(pr.w, pr.h)}", C.DIM, 12f)
        val res = AspectPresets.resIndex(pr.w, pr.h)
        val customIdx = AspectPresets.names.count()
        val aspect = AspectPresets.match(pr.w, pr.h) ?: customIdx
        fun applyDims(resIdx: Int, ratio: Double) {
            val (w, h) = AspectPresets.dims(listOf(720, 1080, 1440)[resIdx], ratio)
            if (w == pr.w && h == pr.h) return
            pushUndo()
            pr.w = w
            pr.h = h
            refreshAll()
            build()
        }
        fun askCustom() {
            val wf = makeField("${pr.w}")
            val hf = makeField("${pr.h}")
            wf.numeric = true; hf.numeric = true
            val row = hRow()
            row.add(EBox(wf, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
            row.add(EBox(hf, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
            Dlg(this).setTitle("Custom aspect ratio  (W : H)").setView(row)
                .setPositiveButton("Apply") { _, _ ->
                    applyDims(res, AspectPresets.parse(wf.text, hf.text))
                }
                .setNegativeButton("Cancel", null).show()
        }
        text(box, "Resolution", C.DIM, 12f)
        box.add(chipRow(listOf("720p", "1080p", "1440p"), res) { i ->
            applyDims(i, pr.w.toDouble() / max(pr.h, 1).toDouble())
        })
        text(box, "Aspect ratio", C.GREEN, 13f, true)
        box.add(chipRow(AspectPresets.names + listOf("Custom"), aspect) { i ->
            if (i < customIdx) applyDims(res, AspectPresets.ratios[i]) else askCustom()
        })
        text(box, "Background color", C.GREEN, 13f, true)
        box.add(EBox(colorRow(s.bg) { c -> s.bg = c; render() }, 0f, 48f, 0f, 0f, 0f, 0f))
        val fpsPick = if (pr.fps >= 50) 2 else (if (pr.fps >= 30) 1 else 0)
        text(box, "Frame rate", C.GREEN, 13f, true)
        box.add(chipRow(listOf("24 fps", "30 fps", "60 fps"), fpsPick) { i ->
            pushUndo()
            pr.fps = listOf(24, 30, 60)[i]
            onTimeChanged()
            build()
        })

        // ---- pre-render (groups)
        text(box, "Pre-render", C.GREEN, 13f, true)
        val preSw = SwitchRow()
        preSw.label = "Pre-render groups"
        preSw.captionOn = "On"; preSw.captionOff = "Off"
        preSw.on = PreRender.enabled
        preSw.onToggle = { v ->
            PreRender.enabled = v
            preBurst = v
            timeline.setNeedsDisplay()
            render()
        }
        put(box, preSw, 52f)
        text(box, "Select a group and tap the camera-in-frame icon in the top bar to bake it. Any change inside "
            + "the group re-bakes it, and the final render plays the baked frames. Off = groups always render live.", C.DIM, 12f)

        // ---- live render cache
        text(box, "Live render cache", C.GREEN, 13f, true)
        val lc = SwitchRow()
        lc.label = "Render ahead when idle"
        lc.captionOn = "On"; lc.captionOff = "Off"
        lc.on = FrameCache.enabled
        lc.onToggle = { v ->
            FrameCache.enabled = v
            timeline.setNeedsDisplay()
        }
        put(box, lc, 52f)
        text(box, "Frames are rendered at the playhead while you are not touching anything and "
            + "shown as a green bar on the timeline. Playback then runs from the cache, so heavy scenes stay smooth.", C.DIM, 12f)
        val cacheSizeLbl = text(box, "Cache size: calculating…", C.DIM, 12f)
        Thread {
            val t = FrameCache.sizeText()
            Handler(Looper.getMainLooper()).post { cacheSizeLbl.text = "Cache size: $t" }
        }.start()
        val clearPill = pill("Clear render cache", null, C.CARD2, C.RED) {
            cacheSizeLbl.text = "Clearing…"
            Thread {
                FrameCache.clearAll()
                val t = FrameCache.sizeText()
                Handler(Looper.getMainLooper()).post {
                    cacheSizeLbl.text = "Cache size: $t"
                    timeline.setNeedsDisplay()
                    render()
                }
            }.start()
        }
        put(box, clearPill, 40f)

        // ---- scene setup mode
        text(box, "Scene Setup mode", C.GREEN, 13f, true)
        val ss = SwitchRow()
        ss.label = "Orbit with an editing camera"
        ss.captionOn = "On"; ss.captionOff = "Off"
        ss.on = sceneSetupOn
        ss.onToggle = { v ->
            sceneSetupOn = v
            sceneSetupBtn.set("camera", if (v) C.GREEN else C.TEXT)
        }
        put(box, ss, 52f)
        text(box, "Drag the preview to orbit the 3D scene and pinch to dolly. Your camera layers are not touched.", C.DIM, 12f)

        // ---- guides
        text(box, "Guides", C.GREEN, 13f, true)
        val gs = SwitchRow()
        gs.label = "Guides"; gs.on = overlay.guides
        gs.onToggle = { v ->
            overlay.guides = v
            overlay.setNeedsDisplay()
        }
        put(box, gs, 52f)

        // ---- scenes
        text(box, "Scenes", C.GREEN, 13f, true)
        val sceneNames = pr.scenes.map { it.name }.toMutableList()
        sceneNames.add("New scene")
        box.add(chipRow(sceneNames, Editor.sceneIndex) { i ->
            pushUndo()
            if (i == pr.scenes.count()) {
                pr.scenes.add(Scene("Scene ${pr.scenes.count() + 1}"))
                Editor.sceneIndex = pr.scenes.count() - 1
            } else {
                Editor.sceneIndex = i
            }
            Editor.time = 0f
            selId = -1
            panel = P_NONE
            refreshAll()
            build()
        })
        if (pr.scenes.count() > 1) {
            put(box, pill("Delete this scene", null, C.CARD2, C.RED) {
                pushUndo()
                pr.scenes.removeAll { it === s }
                Editor.sceneIndex = 0
                Editor.time = 0f
                selId = -1
                panel = P_NONE
                refreshAll()
                build()
            }, 40f)
        }
        val f = RulerSlider()
        f.label = "Scene FOV"; f.lo = 15f; f.hi = 90f; f.value = s.fov; f.dec = 0; f.canKey = false
        f.onChange = { v -> s.fov = v; render() }
        put(box, f, 60f)
    }
    build()
    dlg.setPositiveButton("Done") { _, _ -> applyName[0]() }.show()
}

fun EditorViewController.showRenderDialog() {
    if (playing) togglePlay()
    Projects.save(projectId, Editor.project)
    val proj = Editor.project
    com.saiki.motion.ui.RenderUi.settings(this, proj) { st ->
        com.saiki.motion.ui.RenderUi.show(this, proj, st)
    }
}

// ================================================================ EditorSceneSetup.swift

var EditorViewController.sceneSetupOn: Boolean
    get() = SceneRenderer.editCam != null
    set(value) { if (value) enterSceneSetup() else exitSceneSetup() }

private class SceneSetupBox {
    var pill: UiView? = null
    var gestures = mutableListOf<com.saiki.motion.uikit.UIGestureRecognizer>()
}
private val ssBoxes = HashMap<EditorViewController, SceneSetupBox>()
private fun EditorViewController.ssBox(): SceneSetupBox = ssBoxes.getOrPut(this) { SceneSetupBox() }

fun EditorViewController.enterSceneSetup() {
    if (SceneRenderer.editCam != null) return
    var cam = floatArrayOf(Editor.scene.fov, 0f, 0f, 3f, 0f, 0f)
    val c = Editor.scene.layers.firstOrNull { it.type == LayerType.CAMERA && it.visible }
    if (c != null && Editor.time >= c.start && Editor.time <= c.end) {
        val ct = c.editTime("x", Editor.time)
        cam = floatArrayOf(c.p("fov", ct), c.p("x", ct), c.p("y", ct), c.p("z", ct),
                           c.p("rotX", ct), c.p("rotY", ct))
    }
    SceneRenderer.editCam = cam
    buildSceneSetupPill()
    installSceneSetupGestures()
    render()
    toast("Scene setup: drag to orbit, pinch to dolly")
}

fun EditorViewController.exitSceneSetup() {
    SceneRenderer.editCam = null
    val box = ssBox()
    box.pill?.removeFromSuperview()
    box.pill = null
    for (g in box.gestures) (preview.superview as? UiView)?.removeGestureRecognizer(g)
    box.gestures.clear()
    render()
}

fun EditorViewController.toggleSceneSetup() { if (sceneSetupOn) exitSceneSetup() else enterSceneSetup() }

private fun EditorViewController.buildSceneSetupPill() {
    val box = ssBox()
    if (box.pill != null) return
    val pill = UiView(appContext!!)
    pill.setBackgroundColor(0xE6162820.toInt())
    val ic = IconView("camera", C.GREEN, 18f)
    pill.addSubview(ic)
    val lbl = UILabel(appContext!!)
    lbl.text = "SCENE SETUP"
    lbl.font = boldFont(11f)
    lbl.textColor = argbToUIColor(C.GREEN)
    pill.addSubview(lbl)
    val x = IconView("close", C.TEXT, 16f)
    x.onClick = { exitSceneSetup() }
    pill.addSubview(x)
    view.addSubview(pill)
    pill.postLayout = { _ ->
        pill.frame = CGRect(pill.superview!!.rectWidth() / 2 - 80f, 58f, 160f, 34f)
        ic.frame = CGRect(10f, 8f, 18f, 18f)
        lbl.frame = CGRect(34f, 11f, 80f, 12f)
        x.frame = CGRect(138f, 9f, 16f, 16f)
    }
    box.pill = pill
}

private fun EditorViewController.installSceneSetupGestures() {
    val box = ssBox()
    if (box.gestures.isNotEmpty()) return
    val host: UiView = preview.superview ?: return

    val pan = com.saiki.motion.uikit.UIPanGestureRecognizer { g -> ssPanned(g as com.saiki.motion.uikit.UIPanGestureRecognizer) }
    pan.maximumNumberOfTouches = 1
    host.addGestureRecognizer(pan)

    val pinch = com.saiki.motion.uikit.UIPinchGestureRecognizer { g -> ssPinched(g as com.saiki.motion.uikit.UIPinchGestureRecognizer) }
    host.addGestureRecognizer(pinch)

    box.gestures = mutableListOf(pan, pinch)
}

/** Orbit: the eye moves on the sphere, the camera keeps looking at the origin. */
private fun EditorViewController.ssPanned(g: com.saiki.motion.uikit.UIPanGestureRecognizer) {
    if (g.state != com.saiki.motion.uikit.UIGestureRecognizerState.changed) return
    val e = SceneRenderer.editCam ?: return
    if (e.count() != 6) return
    val v = g.translation(preview.superview)
    g.setTranslationZero()
    val dist = max(0.6f, sqrt(e[1] * e[1] + e[2] * e[2] + e[3] * e[3]))
    var pitch = -e[4] + v.y * 0.35f      // elevation in degrees
    val yaw = e[5] - v.x * 0.35f         // azimuth in degrees
    pitch = com.saiki.motion.core.clamp(pitch, -89f, 89f)
    val pr = pitch * Math.PI.toFloat() / 180f
    val yr = yaw * Math.PI.toFloat() / 180f
    e[1] = dist * cos(pr) * sin(yr)            // eye x
    e[2] = dist * sin(pr)                      // eye y
    e[3] = dist * cos(pr) * cos(yr)            // eye z
    e[4] = -pitch                              // rotX looks back at the origin
    e[5] = yaw
    SceneRenderer.editCam = e
    render()
}

/** Dolly: scale the eye vector, rotation stays the same. */
private fun EditorViewController.ssPinched(g: com.saiki.motion.uikit.UIPinchGestureRecognizer) {
    if (g.state != com.saiki.motion.uikit.UIGestureRecognizerState.changed) return
    val e = SceneRenderer.editCam ?: return
    if (e.count() != 6) return
    val dist = max(0.6f, sqrt(e[1] * e[1] + e[2] * e[2] + e[3] * e[3]))
    val nd = com.saiki.motion.core.clamp(dist / max(g.scale, 0.01f), 0.6f, 24f)
    g.scale = 1f
    val k = nd / dist
    e[1] *= k
    e[2] *= k
    e[3] *= k
    SceneRenderer.editCam = e
    render()
}

// ================================================================ EditorLiveCache.swift

fun EditorViewController.startLiveCache() {
    stopLiveCache()
    val t = object : Runnable {
        override fun run() {
            liveTimerOn.let { }
            liveTick()
            if (liveTimerOn) Handler(Looper.getMainLooper()).postDelayed(this, 60)
        }
    }
    liveTimerOn = true
    liveTimer = t
    Handler(Looper.getMainLooper()).postDelayed(t, 60)
}

fun EditorViewController.stopLiveCache() {
    liveTimerOn = false
    liveTimer?.let { Handler(Looper.getMainLooper()).removeCallbacks(it) }
    liveTimer = null
}

fun EditorViewController.liveMemoryWarning() {
    FrameCache.suspended = true       // stop rendering ahead until the editor is reopened
    preview.trimMemory()
}

/** Pre-render button on a selected group: on → bake its frames; off → drop them. */
fun EditorViewController.togglePreRender(g: Layer) {
    if (!PreRender.enabled) {
        toast("Pre-render is off in Scene setup → Pre-render")
        return
    }
    pushUndo()
    g.prerender = !g.prerender
    if (g.prerender) {
        FrameCache.bump()
        refreshTitle()
        val vc = com.saiki.motion.ui.PreRenderProgressViewController(
            g, Editor.project, Editor.scene, preview.quality,
            bake = { grp, idx -> preview.preRenderFrame(grp, idx) },
            onDone = { ok ->
                if (!ok) {          // cancelled or failed: back to a normal live group
                    g.prerender = false
                    PreRender.clear(Editor.project.id, g.id)
                    FrameCache.bump()
                    toast("Pre-render cancelled")
                } else {
                    toast("Pre-render ready")
                }
                refreshTitle()
                render()
            })
        present(vc, animated = true)
        return
    } else {
        PreRender.clear(Editor.project.id, g.id)
        toast("Pre-render off")
    }
    FrameCache.bump()
    refreshTitle()
    render()
}

/** Chip on the preview: orange while frames bake, green when every pre-rendered group is baked. */
fun EditorViewController.updatePreBadge() {
    val b = preBadge ?: return
    // only while a pre-rendered group is selected; leaving the group hides the tag
    val sel = selected()
    var gs: List<Layer> = emptyList()
    if (sel != null && sel.type == LayerType.GROUP && sel.prerender && PreRender.enabled) gs = listOf(sel)
    if (gs.isEmpty()) { b.isHidden = true; return }
    val size = SceneRenderer.size(Editor.project, preview.quality)
    var done = 0; var total = 0
    for (g in gs) {
        val p = PreRender.progress(g, Editor.project, Editor.scene, size[0], size[1])
        done += p.first; total += p.second
    }
    val ready = done >= total
    b.text = if (ready) " PRE-RENDERED ✓ " else " PRE-RENDER $done/$total "
    b.setBackgroundColor(if (ready) 0xFF3DDC84.toInt() else 0xFF4DA3FF.toInt())
    b.isHidden = false
}

/** Bakes one missing frame of a pre-rendered group. Returns true while work remains. */
fun EditorViewController.preBakeStep(): Boolean {
    if (!PreRender.enabled || FrameCache.suspended || playing || !view.isAttachedToWindow) return false
    val groups = PreRender.groups(Editor.scene)
    if (groups.isEmpty()) { preBurst = false; return false }
    val nowT = now()
    if (nowT - lastActivity < (if (preBurst) 0.15 else 0.6)) return true
    if (nowT < preNextAt) return true
    val size = SceneRenderer.size(Editor.project, preview.quality)
    if (size[0] <= 1) return false
    for (g in groups) {
        val idx = PreRender.nextMissing(g, Editor.project, Editor.scene, size[0], size[1], Editor.time) ?: continue
        val t0 = now()
        val ok = preview.preRenderFrame(g, idx)
        val dt = now() - t0
        preNextAt = now() + (if (ok) max(0.01, dt * (if (preBurst) 0.3 else 1.2)) else 1.0)
        val p = PreRender.progress(g, Editor.project, Editor.scene, size[0], size[1])
        subView.text = if (p.first < p.second) "Pre-render ${p.first}/${p.second}" else "Pre-render ready"
        updatePreBadge()
        if (p.first >= p.second) {
            PreRender.purgeStaleOnce(Editor.project.id, g.id,
                                     PreRender.signature(g, Editor.project, Editor.scene))
            preBurst = false; timeline.setNeedsDisplay()
        }
        return true
    }
    preBurst = false
    return false
}

fun EditorViewController.liveTick() {
    if (preBakeStep()) return
    if (!FrameCache.enabled || FrameCache.suspended || FrameCache.liveFull || playing || !view.isAttachedToWindow) return
    val nowT = now()
    if (nowT - lastActivity < 0.6 || nowT < liveNextAt) return
    val k = preview.cacheKey
    if (k.first <= 1 || k.second <= 1) return
    val t = FrameCache.nextUncached(Editor.time, Editor.scene.duration, Editor.project.id, k.first, k.second, k.third)
    if (t == null) {
        if (liveBusy) { liveBusy = false; timeline.setNeedsDisplay() }
        return
    }
    liveBusy = true
    val t0 = now()
    val ok = preview.cacheFrame(t)
    val dt = now() - t0
    liveNextAt = now() + (if (ok) max(0.02, dt * 1.5) else 1.0)
    if (nowT - lastTimelineRefresh > 0.3) {
        lastTimelineRefresh = nowT
        timeline.setNeedsDisplay()
    }
}

// ================================================================ EditorImport.swift

fun EditorViewController.extractAudio(l: Layer) {
    val src = l.imagePath ?: return
    toast("Extracting audio...")
    safeThread("extract-audio") {
        val f = File(com.saiki.motion.core.Paths.cache, "audio_${nowMs()}.m4a")
        if (!AudioTools.extractAudio(src, f)) {
            Handler(Looper.getMainLooper()).post { toast("This video has no audio track") }
        } else {
            // the user-visible copy lands in <Documents>/SaikiMotion on iOS (Files app);
            // on Android the same folder is app-private, mirrored by Projects.mediaDir — PORT NOTE.
            val docs = com.saiki.motion.core.Paths.root
            val base = beforeLast(File(l.name).name, '.') ?: ""
            val music = File(docs, "$base.m4a")
            try { if (music.exists()) music.delete() } catch (_: Exception) {}
            try { f.copyTo(music, overwrite = true) } catch (_: Exception) {}
            val mf = File(Projects.mediaDir(), "${nowMs()}_${alnum(base)}.m4a")
            try { if (mf.exists()) mf.delete() } catch (_: Exception) {}
            try { f.copyTo(mf, overwrite = true) } catch (_: Exception) {}
            try { f.delete() } catch (_: Exception) {}
            Handler(Looper.getMainLooper()).post {
                toast("Saved to Documents/SaikiMotion and added as an audio layer")
                addMedia(mf.path, LayerType.AUDIO)
            }
        }
    }
}

fun EditorViewController.beatsFrom(path: String, offset: Float) {
    if (path.isEmpty()) { toast("Could not analyze audio"); return }
    toast("Analyzing beats...")
    safeThread("beats") {
        val beats = AudioTools.detectBeats(path)
        Handler(Looper.getMainLooper()).post {
            pushUndo()
            val ms = Editor.scene.markers.toMutableList()
            var n = 0
            for (b in beats) {
                val t = offset + b
                if (t <= Editor.scene.duration && ms.none { abs(it - t) < 0.05f }) {
                    ms.add(t); n += 1
                }
            }
            Editor.scene.markers = ms
            render()
            toast("Added $n beat markers")
        }
    }
}

// ================================================================ importing

fun EditorViewController.pickFile(req: Int) {
    pendingPick = req
    // ACTION_GET_CONTENT via the shared DocPicker; multi-select for image/video/pbr — PORT NOTE.
    val multi = req == R_IMAGE || req == R_VIDEO || req == R_PBRALL
    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
        DocPicker.pick { uri ->
            documentPicked(if (multi) android.net.Uri.EMPTY else uri)
        }
    }, 200)
}

/** Adds media through an options sheet: the photo library first, then Files. */
fun EditorViewController.pickMedia(req: Int, photos: Boolean = true) {
    if (!photos) { pickFile(req); return }
    val photoLabel = if (req == R_VIDEO) "Photo Library (video)" else (if (req == R_IMAGE) "Photo Library" else "Choose from Files")
    val a = com.saiki.motion.uikit.UIAlertController()
    if (req == R_IMAGE || req == R_VIDEO) {
        a.addAction(photoLabel) { pickFromPhotos(req) }
        a.addAction("Choose from Files") { pickFile(req) }
    } else {
        a.addAction("Choose from Files") { pickFile(req) }
    }
    a.addAction(com.saiki.motion.uikit.UIAlertAction("Cancel", com.saiki.motion.uikit.UIAlertActionStyle.cancel, null))
    present(a as com.saiki.motion.uikit.UIViewController, animated = true)
}

/** The 3D tool in the bottom bar (iOS EditorImport.swift:104 show3DImport — Import3DSheet). */
fun EditorViewController.show3DImport() {
    com.saiki.motion.ui.Import3DSheet.show(inHost = view,
        model = { pickFile(R_GLB) },          // glbTypes(): any file, 3D types first (loader sniffs content)
        vdb = { pickFile(R_VDB) },            // vdbTypes(): .vdb volumes
        mmd = { pickFile(R_GLB) },            // mmdTypes(): .pmx/.mmd/.vmd/zip — routed by extension on import
        vrm = { pickFile(R_GLB) })            // vrmTypes(): .vrm — renamed to _vrm.glb on import
}

fun EditorViewController.pickFromPhotos(req: Int) { pickFile(req) }

/** DocPicker callback routed into the iOS documentPicker(didPickDocumentsAt:) flow. */
fun EditorViewController.documentPicked(vararg uris: android.net.Uri) {
    val url = uris.firstOrNull() ?: return
    val req = pendingPick
    if (uris.count() > 1 && (req == R_IMAGE || req == R_VIDEO)) {
        for (u in uris) documentPicked(u)
        return
    }
    if (req == R_COLLIDER) {
        val tl = selected() ?: return
        val cur = tl.imagePath ?: return
        if (!PlyImport.isPointMap(cur)) return
        toast("Reading collider...")
        safeThread("collider-import") {
            val src = com.saiki.motion.core.ProjectIO.copyMediaIntoSandbox(url, "")
            val glb = src?.let { PlyImport.attachCollider(it, cur) }
            if (src != null) try { File(src).delete() } catch (_: Exception) {}
            Handler(Looper.getMainLooper()).post {
                if (glb != null) {
                    pushUndo(); tl.imagePath = glb
                    preview.warm(glb); FrameCache.bump(); refreshPanel(); render()
                    toast("Collider attached")
                } else toast(if (PlyImport.lastError.isEmpty()) "Could not read the collider" else PlyImport.lastError)
            }
        }
        return
    }
    if (req == R_PBRMAP || req == R_PBRALL) {
        val tl = selected() ?: return
        val key = gPbrKey
        val all = uris.toList()
        safeThread("pbr-map") {
            val got = mutableListOf<Pair<String, String>>()
            for (u in all) {
                val p = com.saiki.motion.core.ProjectIO.copyMediaIntoSandbox(u, "pbr") ?: continue
                val k = if (req == R_PBRMAP) key else PBRMaps.guessKey(com.saiki.motion.core.Paths.displayName(u))
                if (k.isNotEmpty()) got.add(k to p)
            }
            Handler(Looper.getMainLooper()).post {
                if (got.isEmpty()) { toast(if (req == R_PBRALL) "No map names recognised (use albedo, normal, roughness, metallic, ao, height...)" else "Could not load the map");  }
                pushUndo()
                for ((k, p) in got) { tl.pbrMaps[k] = p; MetalModelRenderer.evictMaps(p) }
                toast("${got.count()} map${if (got.count() == 1) "" else "s"} imported")
                refreshPanel(); render()
            }
        }
        return
    }
    if (req == R_FX || req == R_PRESET) {
        try {
            val txt = url.let { u ->
                appContext!!.contentResolver.openInputStream(u)?.use { it.readBytes().toString(Charsets.UTF_8) }
            } ?: throw Exception("empty")
            if (req == R_FX) {
                val err = Registry.addCustom(txt)
                if (err != null) toast(err)
                else {
                    toast("Effect imported")
                    com.saiki.motion.core.EffectThumbs.generate(this, preview) { refreshPanel() }
                    refreshPanel()
                }
            } else {
                val o = com.saiki.motion.core.parseJson(txt) ?: throw Exception("bad json")
                if (o.optS("name").isEmpty()) throw Exception("no name")
                Registry.savePreset(o)
                toast("Preset imported")
                refreshPanel()
            }
        } catch (_: Exception) { toast("Could not read file") }
        return
    }
    if (req == R_MODELTEX) {
        val tl = selected() ?: return
        val mp = tl.imagePath ?: return
        safeThread("model-tex") {
            val src = com.saiki.motion.core.ProjectIO.copyMediaIntoSandbox(url, "")
            var ok = false
            if (src != null) {
                val dir = File(mp).parentFile
                val stem = File(mp).nameWithoutExtension
                val ext = if (File(src).extension.isEmpty()) "png" else File(src).extension
                val dst = File(dir, "${stem}_tex_color.$ext")
                for (f in dir?.listFiles() ?: emptyArray()) {
                    if (f.name.startsWith(stem + "_tex_color")) try { f.delete() } catch (_: Exception) {}
                }
                try { if (dst.exists()) dst.delete() } catch (_: Exception) {}
                ok = try { File(src).copyTo(dst, overwrite = true); true } catch (_: Exception) { false }
            }
            Handler(Looper.getMainLooper()).post {
                if (ok) {
                    pushUndo()
                    MetalModelRenderer.evict.add(mp)
                    refreshPanel(); render()
                } else toast("Could not read the texture")
            }
        }
        return
    }
    if (req == R_VDBENV) {
        val tl = selected() ?: return
        safeThread("vdb-env") {
            val p = com.saiki.motion.core.ProjectIO.copyMediaIntoSandbox(url, "")
            Handler(Looper.getMainLooper()).post {
                if (p != null) { pushUndo(); tl.vdbEnvPath = p; tl.vdbEnv = true; refreshPanel(); render() }
                else toast("Could not read the environment image")
            }
        }
        return
    }
    if (req == R_FONT) {
        val tl = selected() ?: return
        safeThread("font") {
            // goes into the font library too (a .zip adds every font in it)
            val added = FontLibrary.importURLs(listOf(url), null)
            val p: String? = if (added > 0) FontLibrary.fonts.lastOrNull()?.let { FontLibrary.path(it) }
                             else com.saiki.motion.core.ProjectIO.copyMediaIntoSandbox(url, "font")
            Handler(Looper.getMainLooper()).post {
                if (p != null) {
                    pushUndo()
                    tl.fontPath = p
                    refreshPanel(); render()
                } else {
                    toast("Could not load the font")
                }
            }
        }
        return
    }
    if (req == R_BEAT) {
        safeThread("beat-copy") {
            val f = File(com.saiki.motion.core.Paths.cache, "beat_src")
            var ok = false
            try {
                appContext!!.contentResolver.openInputStream(url)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                ok = true
            } catch (_: Exception) {}
            Handler(Looper.getMainLooper()).post {
                if (ok) beatsFrom(f.path, 0f) else toast("Could not read audio")
            }
        }
        return
    }
    toast("Importing...")
    val vmdTarget = selected()?.let { if (it.type == LayerType.MODEL) it else null }
    safeThread("import-media") {
        var vmdGlb: String? = null
        val type: LayerType = if (req == R_VIDEO) LayerType.VIDEO else (if (req == R_GLB || req == R_VDB) LayerType.MODEL else (if (req == R_AUDIOFILE) LayerType.AUDIO else LayerType.IMAGE))
        var p = com.saiki.motion.core.ProjectIO.copyMediaIntoSandbox(url, "")
        if (type == LayerType.MODEL) {
            val q = p
            if (q != null) {
                val inner = com.saiki.motion.core.GlbModel.unwrapZip(q)
                if (inner != null) p = inner   // zipped model
            }
        }
        if (type == LayerType.MODEL) {
            val q = p
            if (q != null && q.lowercase().endsWith(".vrm")) {   // VRM is a glTF binary
                val g = q.removeSuffix(".vrm") + "_vrm.glb"
                try { if (File(g).exists()) File(g).delete() } catch (_: Exception) {}
                try { File(q).renameTo(File(g)); p = g } catch (_: Exception) {}
            }
        }
        // models: validate right away so an unsupported file explains itself
        var problem: String? = null
        if (type == LayerType.MODEL && p != null) {
            val q = p!!
            val ext = File(q).extension.lowercase()
            if (ext == "abc") {
                val glb = com.saiki.motion.core.GlbModel.transcodeAbc(q)
                if (glb != null) {
                    problem = com.saiki.motion.core.GlbModel.preflight(glb)
                    if (problem == null) p = glb
                } else {
                    problem = "Could not read this Alembic (.abc) file. Export it as Ogawa with triangulated meshes."
                }
            } else if (ext == "pmx" || ext == "mmd") {
                val glb = com.saiki.motion.core.MmdImport.convert(q)
                if (glb != null) p = glb
                else problem = if (com.saiki.motion.core.MmdImport.lastError.isEmpty()) "Could not read this MMD model" else com.saiki.motion.core.MmdImport.lastError
            } else if (ext == "vmd") {
                val t = vmdTarget
                val mp = t?.imagePath
                val glb = if (t != null && mp != null) com.saiki.motion.core.MmdImport.applyVmd(q, mp) else null
                if (glb != null) vmdGlb = glb
                else problem = if (vmdTarget == null) "Select an imported MMD (.pmx) model layer, then import the .vmd"
                               else (if (com.saiki.motion.core.MmdImport.lastError.isEmpty()) "Could not apply this .vmd" else com.saiki.motion.core.MmdImport.lastError)
            } else if (ext == "ply" || ext == "spz") {
                val ld = PlyImport.load(q)
                var glbOut: String? = null
                var limit = 0
                if (ld != null) {
                    limit = ld.count
                    if (ld.count > PlyImport.balanced) {
                        // too much for a phone: ask Low / Balanced / Full (PlyQualitySheet, UI wave)
                        val chosen = intArrayOf(PlyImport.balanced)
                        val latch = java.util.concurrent.CountDownLatch(1)
                        Handler(Looper.getMainLooper()).post {
                            Dlg(this).setTitle("This point cloud is large").setItems(listOf(
                                "Low (${PlyImport.low} points, fastest)",
                                "Balanced (${PlyImport.balanced} points, recommended)",
                                "Full (${min(ld.count, PlyImport.fullCap)} points, heavy)")) { _, w ->
                                chosen[0] = when (w) { 0 -> PlyImport.low; 1 -> PlyImport.balanced; else -> min(ld.count, PlyImport.fullCap) }
                                latch.countDown()
                            }.setNegativeButton("Cancel") { _, _ -> latch.countDown() }.show()
                        }
                        latch.await()
                        limit = chosen[0]
                    }
                    glbOut = PlyImport.finish(ld, q, limit)
                }
                if (glbOut != null) p = glbOut
                else problem = if (PlyImport.lastError.isEmpty()) "Could not read this point cloud" else PlyImport.lastError
            } else if (ext == "vdb") {
                if (VdbVolume.load(q) == null) {
                    problem = "Could not read this .vdb file (needs a float density grid)."
                }
            } else {
                problem = com.saiki.motion.core.GlbModel.preflight(q)
            }
        }
        val vmdDone = vmdGlb
        Handler(Looper.getMainLooper()).post {
            val t = vmdTarget
            if (vmdDone != null && t != null) {         // .vmd applied to the selected model
                pushUndo(); t.imagePath = vmdDone
                preview.warm(vmdDone); FrameCache.bump(); refreshPanel(); render()
                toast("Motion applied"); 
            }
            if (p != null) {
                val pp = p!!
                if (problem != null) {
                    try { File(pp).delete() } catch (_: Exception) {}
                    toast(problem!!)
                } else {
                    if (type == LayerType.MODEL) preview.warm(pp)   // parse now, not on the first frame
                    addMedia(pp, type)
                }
            } else toast(if (req == R_VIDEO) "Import failed on a video" else "Import failed")
        }
    }
}

/** iOS importPHAsset — photo-library import entry (Android routes through DocPicker). */
fun EditorViewController.importPHAsset(a: Any?) { pickMedia(if (a is String && a == "video") R_VIDEO else R_IMAGE) }

// NOTE: openFullMediaBrowser() intentionally NOT defined here. iOS's Editor glue
// (MediaBrowser.swift:338) presents the in-app MediaBrowserViewController fullscreen; the
// ui/MediaBrowser.kt extension does exactly that. An earlier same-package stub here shadowed
// it at the call site (EditorPanelsText onExpand) and opened the system picker instead.

/** Scales a freshly imported image/video so it fits inside the comp (contain). */
fun EditorViewController.fitToComp(l: Layer) {
    val (qw, qh) = com.saiki.motion.core.Xf.quadSize(l)
    val ar = Editor.project.w.toFloat() / max(Editor.project.h, 1).toFloat()
    if (qw <= 0.001f || qh <= 0.001f) return
    val k = min(2 * ar / qw, 2f / qh)
    if (k.isFinite() && k > 0) l.track("scale").base = k
}

/**
 * Opens the drawing editor on this image layer (iOS EditorImport.swift:473 openDirectDrawing).
 * Save swaps the picture and keeps every transform, effect and keyframe — only the
 * layer's image file changes. Back discards the temporary drawing copy.
 */
fun EditorViewController.openDirectDrawing(l: Layer) {
    if (l.type != LayerType.IMAGE) { toast("Could not open this image"); return }
    val path = l.imagePath ?: run { toast("Could not open this image"); return }
    val src = try { android.graphics.BitmapFactory.decodeFile(path) } catch (_: Exception) { null }
        ?: run { toast("Could not open this image"); return }
    // bake orientation so the drawing canvas and the layer agree on width / height
    val upright = src
    val folder = com.saiki.motion.core.DrawStore.folder("Direct edits")
    val item = com.saiki.motion.core.DrawImport.fromImage(upright, l.name, folder.id, paperWhite = false)
        ?: run { toast("Could not open this image"); return }
    val id = l.id
    val vc = com.saiki.motion.ui.DrawingEditorViewController(item)
    vc.onApply = onApply@{ out ->
        val live = Editor.scene.layers.firstOrNull { it.id == id }
        if (live == null) { toast("Could not apply the drawing"); return@onApply }
        val png = java.io.ByteArrayOutputStream().use { o ->
            if (!out.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, o)) null else o.toByteArray()
        }
        val np = if (png != null) com.saiki.motion.core.ProjectIO.writeDataIntoSandbox(png, "drawn_${nowMs()}.png") else null
        if (np == null) { toast("Could not apply the drawing"); return@onApply }
        pushUndo()
        live.imagePath = np
        FrameCache.bump()
        refreshPanel(); render()
        toast("Drawing applied")
    }
    navigationController?.pushViewController(vc, animated = true)
}

fun EditorViewController.addMedia(path: String, type: LayerType) {
    val l = addLayer(type)
    l.imagePath = path
    l.name = afterFirst(File(path).name, '_')
    if (type == LayerType.IMAGE || type == LayerType.VIDEO) fitToComp(l)
    if (type == LayerType.VIDEO || type == LayerType.AUDIO) {
        // MediaMetadataRetriever.METADATA_KEY_DURATION, loaded OFF the main thread.
        val layerId = l.id
        safeThread("media-duration") {
            var dur = 0.0
            try {
                val mmr = android.media.MediaMetadataRetriever()
                mmr.setDataSource(path)
                dur = (mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION) ?: "0").toDouble() / 1000.0
                mmr.release()
            } catch (_: Exception) {}
            Handler(Looper.getMainLooper()).post {
                val liveL = Editor.scene.layers.firstOrNull { it.id == layerId }
                if (liveL != null) {
                    if (dur.isFinite() && dur > 0) {
                        liveL.srcDur = dur.toFloat()
                        val sc = Editor.scene
                        if (liveL.srcDur > 0.5f) sc.duration = max(sc.duration, min(600f, liveL.start + liveL.srcDur))
                        liveL.end = min(sc.duration, liveL.start + max(liveL.srcDur, 0.5f))
                    }
                    refreshTitle(); refreshPanel(); render()
                }
            }
        }
    }
    refreshTitle(); refreshPanel(); render()
}

/** Kotlin exportText wrote into MediaStore Downloads; on iOS the Files-app location is
 *  <Documents>/SaikiMotion (the same convention ProjectIO uses for project exports). */
fun EditorViewController.exportText(name: String, content: String) {
    try {
        val d = File(com.saiki.motion.core.Paths.root, "SaikiMotion")
        d.mkdirs()
        File(d, name).writeText(content, Charsets.UTF_8)
        toast("Saved to Documents/SaikiMotion/$name")
    } catch (_: Exception) { toast("Export failed") }
}

// ================================================================ EditorPen.swift

/** `group`: draw the path as the matte (top layer) of this Mask Group. */
fun EditorViewController.openPenEditor(editing: Layer? = null, group: Layer? = null) {
    val vc = VectorPenViewController(editing?.vpath ?: com.saiki.motion.core.VPath())
    vc.onDone = { p ->
        val t: Layer
        if (editing != null) { pushUndo(); t = editing } else {
            t = addLayer(LayerType.SHAPE); t.name = "Path ${t.id}"; t.color = 0xFFFF8A1A.toInt()
        }
        t.shape = com.saiki.motion.core.ShapeKind.PATH; t.vpath = p
        if (group != null && editing == null) { t.parentId = group.id; t.name = "Mask Path ${t.id}"; t.color = 0xFFFFFFFF.toInt() }
        refreshPanel(); render()
    }
    present(vc, animated = true)
}

// ================================================================ EditorPointMap.swift

fun EditorViewController.buildPointMap(p: EVStack, l: Layer) {
    if (l.type != LayerType.MODEL) return
    val path = l.imagePath ?: return
    if (!PlyImport.isPointMap(path)) return
    fun xs(label: String, lo: Float, hi: Float, key: String, def: Float, dec: Int = 2) {
        val r = RulerSlider(); r.label = label; r.lo = lo; r.hi = hi; r.dec = dec; r.value = l.xf(key, def)
        r.onBeginDrag = { pushUndo() }
        r.onChange = { v -> l.xset(key, v); render() }
        put(p, r, 90f)
    }
    fun sw(label: String, key: String, def: Float) {
        val s = SwitchRow(); s.label = label; s.on = l.xf(key, def) > 0.5f
        s.onToggle = { v -> pushUndo(); l.xset(key, if (v) 1f else 0f); render() }
        put(p, s, 46f)
    }
    text(p, "Point map", C.TEXT, 14f, true)
    text(p, "${PlyImport.pointCount(path)} points loaded (you can re-import to pick a different quality).", C.DIM, 12f)
    xs("Density (fewer / more points)", 0.005f, 1f, "ptDensity", 1f, 3)
    xs("Point size", 0.5f, 20f, "ptSize", 3f, 1)
    text(p, "Animation", C.TEXT, 13f, true)
    p.add(chipRow(listOf("Off", "Ripple", "Shimmer", "Scan", "Burst", "Twist"), ktInt(l.xf("ptAnim", 0f))) { i ->
        pushUndo(); l.xset("ptAnim", i.toFloat()); render()
    })
    xs("Animation amount", 0f, 3f, "ptAmt", 1f)
    xs("Animation speed", 0f, 4f, "ptSpeed", 1f)
    text(p, "Collider mesh", C.TEXT, 13f, true)
    sw("Physical collision (3D objects can't pass through it)", "colPhys", 1f)
    xs("Object collision size", 0.1f, 2f, "colRadius", 0.5f)
    text(p, "A triangle mesh of the scene (walls, floor). It is invisible, but hides the points and any 3D object that is behind it. A mesh inside the imported .ply is used automatically; or import one here (.ply with faces, or .obj) in the same coordinates.", C.DIM, 12f)
    put(p, pill(if (PlyImport.hasCollider(path)) "Replace collider mesh (.ply / .obj)" else "Import collider mesh (.ply / .obj)", "import") {
        pickFile(R_COLLIDER)
    }, 44f)
    if (PlyImport.hasCollider(path)) {
        sw("Occlusion (hide what is behind the collider)", "colOcc", 1f)
        sw("Show collider mesh", "colShow", 0f)
        put(p, pill("Remove collider", "export") {
            val g = PlyImport.removeCollider(path)
            if (g != null) {
                pushUndo(); l.imagePath = g
                preview.warm(g); FrameCache.bump(); refreshPanel(); render()
            }
        }, 42f)
        text(p, "Objects must be drawn after (above) the point map layer in the layer list to be hidden by the wall.", C.DIM, 12f)
    }
}

// ================================================================ EditorDepth.swift

fun EditorViewController.addDepthAnythingPanel(c: EVStack, l: Layer, entry: String) {
    val sel = DepthAnything.selected
    text(c, "AI DEPTH  ·  Depth Anything V2", C.TEXT, 12f)
    for (k in DepthModelKind.entries) {
        val on = k == sel
        val t = (if (DepthAnything.isInstalled(k)) "✓ " else "") + "${k.title} — ${k.detail}"
        put(c, pill(t, null, if (on) C.BLUE else C.CARD2, if (on) C.ONDARK else C.TEXT) {
            DepthAnything.selected = k; refreshPanel()
        }, 42f)
    }
    if (!DepthAnything.isInstalled(sel)) {
        val status = text(c, "Not installed. Needs an internet connection once; the model stays on this device.", C.DIM, 12f)
        put(c, pill("Install Depth Anything (${sel.title})", "layers", C.BLUE) {
            status.text = "Starting download…"
            DepthAnything.install(sel, { f, msg ->
                status.text = "$msg ${ktInt((f * 100).toFloat())}%"
            }, { err ->
                if (err != null) toast("Install failed: $err")
                else toast("Depth Anything ${sel.title} installed")
                refreshPanel()
            })
        }, 46f)
    } else {
        text(c, "Installed. Generates a depth layer from the layer's current frame; it is added as a new layer and set as this effect's Depth Source.", C.DIM, 12f)
        put(c, pill("Generate AI Depth Map", "layers", C.BLUE) {
            generateDepthLayer(l, entry, sel)
        }, 46f)
        put(c, pill("Delete ${sel.title} model", null, C.CARD2, C.RED) {
            DepthAnything.remove(sel); refreshPanel()
        }, 40f)
    }
}

private fun EditorViewController.frameImage(l: Layer, done: (Bitmap?) -> Unit) {
    if (l.type == LayerType.IMAGE) {
        val img = try { BitmapFactory.decodeFile(l.imagePath ?: "") } catch (_: Exception) { null }
        done(img)
        return
    }
    if (l.type == LayerType.VIDEO) {
        val t = max(0.0, (Editor.time - l.start + l.srcOffset).toDouble())
        Thread {
            var bmp: Bitmap? = null
            try {
                val mmr = android.media.MediaMetadataRetriever()
                mmr.setDataSource(l.imagePath ?: "")
                bmp = mmr.getFrameAtTime((t * 1_000_000).toLong(), android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                mmr.release()
            } catch (_: Exception) {}
            Handler(Looper.getMainLooper()).post { done(bmp) }
        }.start()
        return
    }
    done(null)
}

private fun EditorViewController.generateDepthLayer(l: Layer, entry: String, kind: DepthModelKind) {
    toast("Generating depth map…")
    frameImage(l) { img ->
        if (img == null) { toast("Depth maps work on image and video layers."); return@frameImage }
        DepthAnything.depth(img, kind) { out, err ->
            if (out == null) { toast(err ?: "Depth failed"); return@depth }
            try {
                Projects.mediaDir().mkdirs()
                val path = File(Projects.mediaDir(), "${nowMs()}_depth.png").path
                out.compress(Bitmap.CompressFormat.PNG, 100, File(path).outputStream())
                pushUndo()
                val before = Editor.scene.layers.map { it.id }.toSet()
                addMedia(path, LayerType.IMAGE)
                val nl = Editor.scene.layers.firstOrNull { !before.contains(it.id) }
                if (nl != null) {
                    nl.name = "Depth (${kind.title})"
                    l.inputs[entry + ":Depth Source"] = nl.id
                    nl.visible = false
                }
                refreshPanel(); render()
                toast("Depth layer added and linked")
            } catch (_: Exception) { toast("Could not save depth map") }
        }
    }
}

// ================================================================ EditorPbr.swift

fun EditorViewController.buildPbr(p: EVStack, l: Layer) {
    if (l.type != LayerType.MODEL) return
    if (l.xf("water", 0f) >= 0.5f) return
    fun xs(label: String, lo: Float, hi: Float, key: String, def: Float, dec: Int = 2) {
        val r = RulerSlider(); r.label = label; r.lo = lo; r.hi = hi; r.dec = dec; r.value = l.xf(key, def)
        r.onBeginDrag = { pushUndo() }
        r.onChange = { v -> l.xset(key, v); render() }
        put(p, r, 90f)
    }
    fun sw(label: String, key: String, def: Float = 0f) {
        val s = SwitchRow(); s.label = label; s.on = l.xf(key, def) > 0.5f
        s.onToggle = { v -> pushUndo(); l.xset(key, if (v) 1f else 0f); render() }
        put(p, s, 46f)
    }
    text(p, "PBR material (imported maps)", C.TEXT, 14f, true)
    text(p, "Import every map from a material. Names like albedo / normal / roughness / metallic / ao / height / emissive / opacity are recognised automatically.", C.DIM, 12f)
    put(p, pill("Import all maps (pick several files)", "import") {
        gPbrKey = ""; pickFile(R_PBRALL)
    }, 44f)
    for ((key, label) in PBRMaps.keys) {
        val have = l.pbrMaps[key] != null
        put(p, pill(if (have) "$label  ✓  (tap to replace)" else "$label: import", if (have) "checkmark" else "import",
                    if (have) C.GREEN_DARK else C.CARD2) {
            gPbrKey = key; pickFile(R_PBRMAP)
        }, 40f)
        if (have) {
            put(p, pill("Remove ${label.lowercase()}", "trash") {
                pushUndo(); l.pbrMaps.remove(key); refreshPanel(); render()
            }, 34f)
        }
    }
    if (l.pbrMaps.isEmpty()) {
        text(p, "No maps yet. Without maps the model keeps its own materials.", C.DIM, 12f)
        return
    }
    text(p, "Surface", C.TEXT, 13f, true)
    xs("Texture tiling", 0.1f, 30f, "pbrTile", 1f)
    if (l.pbrMaps["normal"] != null) {
        xs("Normal strength", 0f, 3f, "pbrNStr", 1f)
        sw("Flip green channel (DirectX normal map)", "pbrFlip")
    }
    if (l.pbrMaps["rough"] != null) xs("Roughness multiplier", 0f, 2f, "pbrRough", 1f)
    if (l.pbrMaps["metal"] != null) xs("Metallic multiplier", 0f, 2f, "pbrMetal", 1f)
    if (l.pbrMaps["ao"] != null) xs("Ambient occlusion strength", 0f, 1f, "pbrAo", 1f)
    if (l.pbrMaps["emissive"] != null) xs("Emissive strength", 0f, 6f, "pbrEm", 1f)
    if (l.pbrMaps["height"] != null) {
        text(p, "Relief (real 3D)", C.TEXT, 13f, true)
        xs("Displacement (moves real geometry)", 0f, 0.5f, "pbrDisp", 0.05f)
        xs("Mesh subdivision (0 = off, 4 = very dense)", 0f, 4f, "pbrSub", 2f, 0)
        xs("Parallax depth (fine detail)", 0f, 0.08f, "pbrPar", 0.03f)
        xs("Height midpoint", 0f, 1f, "pbrMid", 0.5f)
        text(p, "Displacement needs subdivision: each level multiplies the triangles by four (a plane or cube works best). Parallax and self-shadowing add detail smaller than the triangles.", C.DIM, 12f)
    }
    text(p, "Clear coat", C.TEXT, 13f, true)
    xs("Clear coat (lacquer / car paint)", 0f, 1f, "pbrCoat", 0f)
    xs("Clear coat roughness", 0f, 1f, "pbrCoatR", 0.1f)
}


/** Phaser stage stagger (iOS AFxPhaser.stagger): per-stage all-pass sweep offsets. */
fun stagger(s: Int): Float = 0.55f * (s + 1) - 0.35f * (s + 1) * (s + 1) * 0.18f
