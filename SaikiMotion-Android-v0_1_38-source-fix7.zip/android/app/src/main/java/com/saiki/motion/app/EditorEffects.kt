@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorEffects.swift — Effects panel: applied list, browser,
// presets, custom + SDK IDE. ClosureHold/ClosurePan/FxDragSource live here (iOS bottom of file).

package com.saiki.motion.app

import com.saiki.motion.core.AudioFxItem
import com.saiki.motion.core.EffectDef
import com.saiki.motion.core.EffectThumbs
import com.saiki.motion.core.Editor
import com.saiki.motion.core.FxRecent
import org.json.JSONArray
import org.json.JSONObject
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.Registry
import com.saiki.motion.core.Xf
import com.saiki.motion.core.afxKey
import com.saiki.motion.core.AFxDefs
import com.saiki.motion.ui.C
import com.saiki.motion.ui.EffectCard
import com.saiki.motion.ui.IconView
import com.saiki.motion.ui.SwitchRow
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.ui.fillRoundRect
import kotlin.math.abs
import kotlin.math.max
import com.saiki.motion.ui.boldFont
import com.saiki.motion.ui.chipRow
import com.saiki.motion.ui.ChromaTownDashboardViewController
import com.saiki.motion.ui.MBLEditorViewController
import com.saiki.motion.ui.ShineDashboardViewController
import com.saiki.motion.ui.UniverseDashboardViewController
import com.saiki.motion.ui.LooksEditorViewController
import com.saiki.motion.ui.ParticularDesignerViewController
import com.saiki.motion.ui.mblTools
import com.saiki.motion.ui.sysFont
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UIGestureRecognizer
import com.saiki.motion.uikit.UIGestureRecognizerState
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UILongPressGestureRecognizer
import com.saiki.motion.uikit.UIPanGestureRecognizer
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.core.parseJson

fun EditorViewController.buildFx(l: Layer) {
    val p = panelList
    val hdr = hRow()
    val ht = UILabel(appContext!!)
    ht.text = "Effects  ·  " + l.name
    ht.textColor = argbToUIColor(C.TEXT)
    ht.font = boldFont(20f)
    hdr.add(growBox(ht))
    hdr.add(EBox(pill("Close", "close") { closePanel() }, 112f, 42f, 0f, 0f, 0f, 0f))
    put(p, hdr, 0f, 6f, 8f)
    p.add(chipRow(listOf("Applied", "Browse", "Presets", "Custom"), fxTab) { i ->
        fxTab = i
        showBottom(); refreshPanel()
    })
    when (fxTab) {
        0 -> buildApplied(l)
        1 -> buildBrowse(l)
        2 -> buildPresets(l)
        else -> buildCustom(l)
    }
}

fun EditorViewController.snapFx(l: Layer, entry: String): EditorViewController.FxSnap? {
    val d = Registry.get(entry) ?: return null
    val m = mutableListOf<Pair<String, JSONObject>>()
    if (d.kind == 1) {
        for (pd in d.props) {
            val tr = l.props[pd.key]
            if (tr != null) m.add("=" + pd.key to tr.toJson())
        }
    } else {
        val pre = entry + "__"
        for ((k, tr) in l.props) {
            if (k.startsWith(pre)) m.add(k.drop(pre.length) to tr.toJson())
        }
    }
    val ins = HashMap<String, Int>()
    for ((k, v) in l.inputs) {
        if (k.startsWith(entry + ":")) ins[k.drop(entry.length + 1)] = v
    }
    return EditorViewController.FxSnap(d.id, m, ins, l.fxOff.contains(entry))
}

fun EditorViewController.pasteFx(l: Layer, snap: EditorViewController.FxSnap) {
    val d = Registry.byId[snap.id] ?: return
    val entry: String
    if (d.kind == 1) {
        entry = d.id
        if (!l.fx.contains(entry)) l.fx.add(entry)
    } else {
        entry = Registry.uniqueEntry(l, d.id)
        l.fx.add(entry)
    }
    if (snap.off) l.fxOff.add(entry) else l.fxOff.remove(entry)
    for ((rk, js) in snap.tracks) {
        val key = if (rk.startsWith("=")) rk.drop(1) else entry + "__" + rk
        l.track(key).load(js)
    }
    for ((nm, id) in snap.inputs) l.inputs[entry + ":" + nm] = id
    expanded.add("${l.id}:$entry")
}

fun EditorViewController.resetFx(l: Layer, entry: String) {
    val d = Registry.get(entry) ?: return
    for (pd in d.props) {
        val tr = l.track(l.pkey(entry, pd))
        tr.keys.clear()
        tr.base = pd.def
        tr.setExpr("")
        tr.exprOn = false
    }
    for (cp in d.colors) {
        val ck = l.ckey(entry, cp)
        val dv = cp.def.toLong() and 0xFFFFFFFFL
        val vals = listOf("_r" to ((dv shr 16) and 0xFF).toInt(),
                          "_g" to ((dv shr 8) and 0xFF).toInt(),
                          "_b" to (dv and 0xFF).toInt(),
                          "_a" to ((dv shr 24) and 0xFF).toInt())
        for ((sf, v) in vals) {
            val tr = l.track(ck + sf)
            tr.keys.clear()
            tr.base = v / 255f
        }
    }
}

fun EditorViewController.moveFx(l: Layer, entry: String, dir: Int) {
    val idx = l.fx.indexOf(entry)
    if (idx < 0) return
    val to = idx + dir
    if (to < 0 || to >= l.fx.count()) return
    l.fx.removeAt(idx)
    l.fx.add(to, entry)
}

fun EditorViewController.removeFx(l: Layer, entry: String) {
    l.fx.removeAll { it == entry }
    l.fxOff.remove(entry)
    val pre = entry + "__"
    if (entry.contains("~")) {
        for (k in l.props.keys.toList()) if (k.startsWith(pre)) l.props.remove(k)
    }
    for (k in l.inputs.keys.toList()) if (k.startsWith(entry + ":")) l.inputs.remove(k)
}

fun EditorViewController.fxMenu(l: Layer, entry: String) {
    val d = Registry.get(entry) ?: return
    val idx = l.fx.indexOf(entry)
    val labels = listOf("Copy effect", "Duplicate effect", "Move up", "Move down", "Reset to default", "Remove effect",
                        if (fxClip.isEmpty()) "Paste effect (nothing copied)" else "Paste effect (${fxClip.count()})")
    val icons = listOf("dup", "dup", "chev_up", "chev_down", "adjust", "trash", "import")
    Dlg(this).setTitle(d.name).setIconItems(labels, icons) { _, w ->
        when (w) {
            0 -> {
                val sn = snapFx(l, entry)
                if (sn != null) {
                    fxClip.clear()
                    fxClip.add(sn)
                }
                toast("Effect copied")
            }
            1 -> {
                val sn = snapFx(l, entry)
                if (sn != null) {
                    pushUndo()
                    pasteFx(l, sn)
                    refreshPanel(); render()
                }
            }
            2 -> {
                if (idx > 0) {
                    pushUndo()
                    moveFx(l, entry, -1)
                    refreshPanel(); render()
                }
            }
            3 -> {
                if (idx < l.fx.count() - 1) {
                    pushUndo()
                    moveFx(l, entry, 1)
                    refreshPanel(); render()
                }
            }
            4 -> {
                pushUndo()
                resetFx(l, entry)
                refreshPanel(); render()
            }
            5 -> {
                pushUndo()
                removeFx(l, entry)
                refreshPanel(); render()
            }
            else -> {
                if (fxClip.isEmpty()) { toast("No effect copied") }
                pushUndo()
                for (sn in fxClip) pasteFx(l, sn)
                refreshPanel(); render()
            }
        }
    }.show()
}

fun EditorViewController.fxListMenu(l: Layer) {
    val labels = listOf("Copy all effects",
                        if (fxClip.isEmpty()) "Paste effects (nothing copied)" else "Paste effects (${fxClip.count()})",
                        "Reset all to default", "Remove all effects")
    val icons = listOf("dup", "import", "adjust", "trash")
    Dlg(this).setTitle("Effects").setIconItems(labels, icons) { _, w ->
        when (w) {
            0 -> {
                fxClip.clear()
                for (e in l.fx) snapFx(l, e)?.let { fxClip.add(it) }
                toast(if (fxClip.isEmpty()) "No effects to copy" else "Copied ${fxClip.count()} effects")
            }
            1 -> {
                if (fxClip.isEmpty()) {
                    toast("No effects copied")
                } else {
                    pushUndo()
                    for (sn in fxClip) pasteFx(l, sn)
                    refreshPanel(); render()
                }
            }
            2 -> {
                pushUndo()
                for (e in l.fx) resetFx(l, e)
                refreshPanel(); render()
            }
            else -> {
                pushUndo()
                for (e in l.fx) removeFx(l, e)
                refreshPanel(); render()
            }
        }
    }.show()
}

fun EditorViewController.fxHeader(l: Layer, d: EffectDef, entry: String): UiView {
    val key = "${l.id}:$entry"
    val isOpen = expanded.contains(key)
    val bar = hRow()
    bar.setBackgroundColor(C.CARD)
    bar.add(EBox(IconView("handle", C.DIM, 20f), if (com.saiki.motion.ui.Dev.isPad) 56f else 44f, 52f, 0f, 0f, 0f, 0f))
    val t = UILabel(com.saiki.motion.uikit.appContext!!)
    t.text = if (entry.contains("~")) d.name + " " + afterLast(entry, '~') else d.name
    t.textColor = argbToUIColor(C.TEXT)
    t.font = boldFont(16f)
    bar.add(growBox(t))
    val off = l.fxOff.contains(entry)
    val eye = IconView(if (off) "eye_off" else "eye", if (off) C.DIM else C.GREEN, 20f)
    eye.onClick = {
        pushUndo()
        if (off) l.fxOff.remove(entry) else l.fxOff.add(entry)
        refreshPanel(); render()
    }
    bar.add(EBox(eye, 40f, 48f, 0f, 0f, 0f, 0f))
    val chev = IconView(if (isOpen) "chev_up" else "chev_down", C.DIM, 20f)
    chev.onClick = {
        if (expanded.contains(key)) expanded.remove(key) else expanded.add(key)
        refreshPanel()
    }
    bar.add(EBox(chev, 40f, 48f, 0f, 0f, 0f, 0f))
    val more = IconView("more", C.TEXT, 20f)
    more.onClick = { fxMenu(l, entry) }
    bar.add(EBox(more, 40f, 48f, 0f, 0f, 0f, 0f))
    return bar
}

fun EditorViewController.buildApplied(l: Layer) {
    val p = panelList
    val top = hRow()
    val cnt = UILabel(com.saiki.motion.uikit.appContext!!)
    val totalFx = l.fx.count() + l.afx.count()
    cnt.text = "$totalFx${if (totalFx == 1) " effect" else " effects"}"
    cnt.textColor = argbToUIColor(C.DIM)
    cnt.font = sysFont(13f)
    top.add(growBox(cnt))
    val menu = IconView("more", C.TEXT, 22f)
    menu.onClick = { fxListMenu(l) }
    top.add(EBox(menu, 44f, 40f, 0f, 0f, 0f, 0f))
    put(p, top, 40f, 6f, 2f)
    if (l.fx.isEmpty() && l.afx.isEmpty()) text(p, "No effects yet. Tap Add Effect to browse.")
    if (l.type == LayerType.AUDIO || l.type == LayerType.VIDEO) buildAudioFxPanel(p, l)
    val fxRows = mutableListOf<UiView>()        // the on-screen row of each effect (for drag reordering)
    val fxIdx = mutableListOf<Int>()            // matching index in l.fx
    val fxHandles = mutableListOf<UiView>()
    for ((fi, entry) in l.fx.withIndex()) {
        val d = Registry.get(entry) ?: continue
        val id = d.id
        val c = vStack()
        val hdr = fxHeader(l, d, entry)
        fxHandles.add((hdr as? EHStack)?.arranged?.firstOrNull() ?: hdr)
        c.add(hdr)
        if (expanded.contains("${l.id}:$entry")) {
            text(c, d.desc, C.DIM, 12f)
            Registry.errors[id]?.let { text(c, "Shader error: $it", C.RED, 12f) }
            if (id == "depthmap") addDepthAnythingPanel(c, l, entry)
            if (id == "chromatown" || id == "uglow" || id == "uprism" || id == "upointzoom" || id == "ugofi" || id == "uecto" || id == "ucarousel" || id == "uedge" || id == "uhud" || id == "shine") {
                put(c, pill("Open Dashboard…", "layers", C.BLUE) { if (id == "chromatown") openChromaTownDashboard(l, entry) else if (id == "shine") openShineDashboard(l, entry) else openUniverseDashboard(l, entry) }, 42f)
                for (pd in d.props) if (!(id == "shine" && com.saiki.motion.ui.ShineDashboardViewController.hidden.contains(pd.key))) addRow(c, l, Registry.instProp(l, entry, pd))
                for (cp in d.colors) addColorParam(c, l, Registry.instColor(l, entry, cp))
            } else if (id == "particular") {
                put(c, pill("Open Particle Designer", "layers", C.GREEN, C.ONDARK) { openParticularDesigner(l) }, 46f)
                val basic = setOf("ptRate", "ptSizeX", "ptSizeY", "ptSizeZ", "ptVel", "ptGravity", "ptLife", "ptSize", "ptOpacity")
                for (pd in d.props) if (basic.contains(pd.key)) addRow(c, l, Registry.instProp(l, entry, pd))
                for (cp in d.colors) addColorParam(c, l, Registry.instColor(l, entry, cp))
                val occ = SwitchRow()
                occ.label = "Occlude"; occ.on = l.p("ptOcclude", Editor.time) >= 0.5f
                occ.onToggle = { v -> pushUndo(); l.track("ptOcclude").base = if (v) 1f else 0f; render() }
                put(c, occ, 52f)
                val pmb = SwitchRow()
                pmb.label = "Motion blur"; pmb.on = l.mblur
                pmb.onToggle = { v -> pushUndo(); l.mblur = v; render() }
                put(c, pmb, 52f)
                text(c, "Particles are 3D: they follow the comp camera and are hidden behind 3D layers when Occlude is on.", C.DIM, 12f)
            } else if (id == "mblooks") {
                put(c, pill("Open Looks Editor", "layers") { openLooksEditor(l, entry) }, 42f)
                val pd = d.props.firstOrNull { it.key == "lkInt" }
                if (pd != null) addRow(c, l, Registry.instProp(l, entry, pd))
            } else if (id == "mbl") {
                put(c, pill("Open Magic Bullet Looks", "layers") { openMBLEditor(l, entry) }, 42f)
                val added = mblActiveTools(l, entry)
                if (added.isNotEmpty()) {
                    val sv = TopIconScroll(); sv.showsHorizontalScrollIndicator = false
                    val row = hRow()
                    var x = 4f
                    for (tid in added) {
                        val t = mblTools.first { it.id == tid }
                        val b = com.saiki.motion.app.MblToolButton(tid)
                        b.onClick = { openMBLEditor(l, entry) }
                        row.add(EBox(b, 52f, 66f, 0f, 4f, 0f, 4f))
                        x += 60f
                    }
                    sv.content = row
                    put(c, sv, 76f)
                }
                val pd = d.props.firstOrNull { it.key == "mbInt" }
                if (pd != null) addRow(c, l, Registry.instProp(l, entry, pd))
            } else {
                for (pd in d.props) if (pd.key != "twFrac") addRow(c, l, Registry.instProp(l, entry, pd))
                for (cp in d.colors) addColorParam(c, l, Registry.instColor(l, entry, cp))
            }
            if (id == "particles") {
                val pmb = SwitchRow()
                pmb.label = "Motion blur"; pmb.on = l.mblur
                pmb.onToggle = { v -> pushUndo(); l.mblur = v; render() }
                put(c, pmb, 52f)
                val occ = SwitchRow()
                occ.label = "Occlude"; occ.on = l.p("pOcclude", Editor.time) >= 0.5f
                occ.onToggle = { v ->
                    pushUndo(); l.track("pOcclude").base = if (v) 1f else 0f; render()
                }
                put(c, occ, 52f)
                text(c, "Occlude hides particles that are behind 3D layers and models. Particles follow the scene camera.", C.DIM, 12f)
            }
            for (nm in d.inputs) {
                val rid = l.inputs[entry + ":" + nm]
                val ref = Editor.scene.layers.firstOrNull { it.id == rid }
                put(c, pill(nm + " layer: " + (ref?.name ?: "None"), "layers") {
                    showInputDialog(l, entry, nm)
                }, 42f)
            }
            if (id == "tile") {
                val b = hRow()
                b.spacing = 4f
                for (axis in listOf("tileX", "tileY")) {
                    b.add(EBox(pill("Scroll " + (axis.lastOrNull() ?: '?')) {
                        tileScroll(l, axis)
                    }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
                }
                c.add(b)
            }
        }
        val pr = put(p, c, 0f, 3f, 6f)
        fxRows.add(pr.superview ?: pr)
        fxIdx.add(fi)
    }
    if (fxRows.count() > 1) {
        for ((n, h) in fxHandles.withIndex()) {
            val pan = ClosurePan()
            pan.cb = { g -> dragFx(l, g, n, fxRows, fxIdx) { a, b -> val e = l.fx.removeAt(a); l.fx.add(b, e) } }
            h.addGestureRecognizer(pan)
            // touch-friendly: press and hold the effect's title bar for a moment, then drag it up or down
            val hold = ClosureHold()
            hold.minimumPressDuration = 0.22
            hold.cb = { g -> dragFx(l, g, n, fxRows, fxIdx) { a, b -> val e = l.fx.removeAt(a); l.fx.add(b, e) } }
            (h.superview ?: h).addGestureRecognizer(hold)
        }
    }
    put(p, pill("Add Effect", "plus", C.GREEN, C.ONDARK) {
        fxTab = 1
        showBottom(); refreshPanel()
    }, 48f, 10f, 10f)
}

/** Drag-to-reorder from the three-line handle: the row follows the finger, the others slide out of the way. */
fun EditorViewController.dragFx(l: Layer, g: FxDragSource, n: Int, rows: List<UiView>, idx: List<Int>, commit: (Int, Int) -> Unit) {
    if (n >= rows.count()) return
    val row = rows[n]
    val ty = g.translationInView(row.superview).y
    if (g.state == UIGestureRecognizerState.began || g.frames.count() != rows.count()) g.frames = rows.map { it.frame }
    val frames = g.frames
    val sp = if (rows.count() > 1) max(0f, frames[1].minY - frames[0].maxY) else 0f
    fun target(): Int {
        val cy = frames[n].midY + ty
        var best = n
        var bd = Float.MAX_VALUE
        for (j in 0 until rows.count()) { val d = abs(frames[j].midY - cy); if (d < bd) { bd = d; best = j } }
        return best
    }
    when (g.state) {
        UIGestureRecognizerState.began -> {
            row.superview?.bringChildToFront(row)
            g.lastTarget = n
        }
        UIGestureRecognizerState.changed -> {
            val t = target()
            row.translationY = ty
            if (t != g.lastTarget) g.lastTarget = t
        }
        UIGestureRecognizerState.ended, UIGestureRecognizerState.cancelled -> {
            val t = if (g.state == UIGestureRecognizerState.cancelled) n else target()
            for (r in rows) r.translationY = 0f
            if (t != n) {
                pushUndo()
                commit(idx[n], idx[t])
                render(); refreshPanel()
            }
        }
        else -> {}
    }
}

fun EditorViewController.tileScroll(l: Layer, key: String) {
    pushUndo()
    val tr = l.track(key)
    val mirror = l.p("tileMirror", Editor.time) >= 0.5f
    tr.keys.clear()
    tr.keys.add(com.saiki.motion.core.Key(l.start, 0f, com.saiki.motion.core.Ease.LINEAR))
    tr.keys.add(com.saiki.motion.core.Key(l.end, if (mirror) 2f else 1f, com.saiki.motion.core.Ease.LINEAR))
    refreshPanel(); render()
}

fun EditorViewController.showInputDialog(l: Layer, entry: String, nm: String) {
    val cands = Editor.scene.layers.filter {
        it.id != l.id && it.isRenderable() && it.type != LayerType.MODEL && it.type != LayerType.PARTICLES
    }
    val names = mutableListOf("None")
    names.addAll(cands.map { it.name })
    Dlg(this).setTitle("$nm layer").setItems(names) { _, w ->
        pushUndo()
        if (w == 0) {
            l.inputs.remove(entry + ":" + nm)
        } else {
            l.inputs[entry + ":" + nm] = cands[w - 1].id
        }
        refreshPanel(); render()
    }.show()
}

fun EditorViewController.fxCategory(d: EffectDef): String {
    val nm = d.name.lowercase(); val idl = d.id.lowercase()
    if (nm.startsWith("am ") || nm.startsWith("am-") || nm.startsWith("am_") || idl.startsWith("am-") || idl.startsWith("am_") || idl.startsWith("nova.effect.am-")) return "Alight Motion"
    if (idl.startsWith("nova.effect.capcut")) return "CapCut"
    if (d.id == "mbl" || d.id == "mblooks") return "Color"
    if (d.name.startsWith("BCC")) return "BCC"
    if (d.name.startsWith("uni.")) return "Universe"
    if (d.category == "Node Video") return "Node Video"
    when (d.id) {
        "slidercontrol", "anglecontrol", "checkboxcontrol", "colorcontrol", "pointcontrol", "point3dcontrol", "layercontrol" -> return "Controls"
        "wipelinear" -> return "Transitions"
        "deepglow", "edgerays", "raytrace", "lightsweep", "contour", "lightleak", "godrays", "starburst", "softfocus", "bokeh" -> return "Light and glow"
        "tritone", "duotone", "hueshift", "grayscale", "invert", "rgbsplit", "vignette", "fill",
        "nightvision", "thermal", "oldphoto", "gradientmap", "threshold", "colorcorrect", "levels", "splittone", "channelmix" -> return "Color"
        "etching", "halftone", "zebrafy", "posterize", "filmgrain", "edgelines", "scanlines", "pixelate", "sharpen",
        "ascii", "hexpixel", "sketch", "toon", "emboss", "clay", "matrixrain", "pixelscatter", "crt", "bevel" -> return "Stylize"
        "distortrgb", "kaleido", "bulge", "twirl", "barrel", "wavewarp", "ripple",
        "glassblocks", "droste", "polarwarp", "turbulent", "mirror", "sapshake", "warpbubble", "distortchroma", "distortrgbsapphire", "distortblur" -> return "Distort"
        "blur", "radialblur", "blurmo", "dirblur", "blurmocurves", "sapdeband" -> return "Blur"
        "romantile", "sapscanlines" -> return "Stylize"
        "psykoblobs", "texturefolded", "texturemoire", "starfield", "plasma", "fire", "snow" -> return "Generate"
        "sshake", "twitch", "glitchslices", "vhs", "oscillate", "autoshake", "randisp", "streaks", "timeslice" -> return "Glitch and motion"
        "chromakey", "lumakey" -> return "Keying"
        else -> {
            if (d.id.startsWith("shake_")) return "Glitch and motion"
            if (d.builtin) {
                val known = listOf("Light and glow", "Color", "Stylize", "Distort", "Blur", "Generate", "Glitch and motion", "Keying", "Transitions", "Transform and time")
                return known.firstOrNull { it.lowercase() == d.category.lowercase() } ?: "Transform and time"
            }
            return if (Registry.CATEGORIES.contains(d.category)) d.category else "Custom"
        }
    }
}

fun EditorViewController.buildBrowse(l: Layer) {
    val p = panelList
    val q = makeField(fxQuery)
    q.placeholder = "Search effects"
    val grid = vStack()
    fun fill() {
        grid.clear()
        val qs = fxQuery.trim().lowercase()
        val list = Registry.order.filter { d ->
            if (l.type == LayerType.AUDIO) return@filter false                          // audio layers: audio effects only
            if (l.type == LayerType.NULL && !Xf.isMovementFx(d.id)) return@filter false // null layers: movement effects only
            true
        }.filter {
            qs.isEmpty() || it.name.lowercase().contains(qs) || it.desc.lowercase().contains(qs)
                || fxCategory(it).lowercase().contains(qs)
        }
        var groups = list.filter { fxCatName.isEmpty() || fxCategory(it) == fxCatName }.groupBy { fxCategory(it) }
        val recent = FxRecent.ids.mapNotNull { Registry.byId[it] }.filter { d ->
            (l.type != LayerType.AUDIO) && (l.type != LayerType.NULL || Xf.isMovementFx(d.id)) &&
            (qs.isEmpty() || d.name.lowercase().contains(qs)) }
        var showRecent = recent.isNotEmpty() && (fxCatName.isEmpty() || fxCatName == "Recently used")
        if (fxCatName == "Recently used") groups = emptyMap()
        if (showRecent) groups = groups + mapOf("Recently used" to recent)
        val catOrder = listOf("Recently used", "Alight Motion", "CapCut", "Controls", "BCC", "Universe", "Node Video", "Transitions", "Light and glow", "Color", "Stylize", "Distort", "Blur", "Generate",
                               "Glitch and motion", "Keying", "Transform and time", "Custom")
        val keys = groups.keys.sortedBy { a -> val ia = catOrder.indexOf(a); val ib = 0; ia.coerceAtMost(99) }
        var audioHits = 0
        val cols = max(2, ((view.rectWidth() - 60f) / 200f).toInt())
        if (l.type == LayerType.AUDIO || l.type == LayerType.VIDEO) {
            val ax = AFxDefs.types.filter { qs.isEmpty() || it.second.lowercase().contains(qs) || "audio sound".contains(qs) }
            audioHits = ax.count()
            if (ax.isNotEmpty()) text(grid, "Audio  (" + ax.count() + ")", C.GREEN, 14f, true)
            var i = 0
            while (i < ax.count()) {
                val r = hRow()
                r.spacing = 8f
                for (j in 0 until cols) {
                    if (i + j >= ax.count()) { r.add(EBox(UiView(appContext!!), 0f, 0f, 0f, 0f, 0f, 0f).also { it.grow = 1f }); continue }
                    val a = ax[i + j]
                    val card = AudioFxCard(a.second, "afx_${a.first}")
                    card.badge = l.afx.any { it.type == a.first }
                    card.onClick = {
                        pushUndo()
                        l.afx.add(AudioFxItem(a.first))
                        audioFxChanged()
                        toast("${a.second} added")
                        fxTab = 0
                        refreshPanel()
                    }
                    r.add(EBox(card, 0f, 150f, 4f, 4f, 4f, 4f).also { it.grow = 1f })
                }
                grid.add(r)
                i += cols
            }
        }
        if (keys.isEmpty() && audioHits == 0) text(grid, "No effects match your search.", C.DIM, 13f)
        for (k in keys) {
            val items = if (k == "Recently used") (groups[k] ?: emptyList()) else (groups[k] ?: emptyList()).sortedBy { it.name.lowercase() }
            text(grid, "$k  (${items.count()})", C.GREEN, 14f, true)
            var i = 0
            while (i < items.count()) {
                val r = hRow()
                r.spacing = 8f
                for (j in 0 until cols) {
                    if (i + j >= items.count()) {
                        r.add(EBox(UiView(appContext!!), 0f, 0f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
                        continue
                    }
                    val d = items[i + j]
                    val card = EffectCard(d.name, fxCategory(d))
                    card.anim = d.previewAnim
                    card.thumbId = d.id
                    card.origId = EffectThumbs.origKey(d.id)
                    card.before = EffectThumbs.cache[EffectThumbs.origKey(d.id)]?.let { com.saiki.motion.uikit.UIImage(it) }
                    card.after = EffectThumbs.cache[d.id]?.let { com.saiki.motion.uikit.UIImage(it) }
                    card.badge = l.fx.contains(d.id)
                    card.onClick = { showEffectInfo(d, l) }
                    r.add(EBox(card, 0f, 250f, 4f, 4f, 4f, 4f).also { it.grow = 1f })
                }
                grid.add(r)
                i += cols
            }
        }
    }
    bind(q) { s ->
        fxQuery = s
        fill()
    }
    put(p, q, 44f)
    // swipeable category chips: tap one to jump straight to that category
    val chipScroll = TopIconScroll()
    chipScroll.showsHorizontalScrollIndicator = false
    val chipRow = hRow()
    chipRow.spacing = 8f
    val chipNames = listOf("All", "Recently used", "Alight Motion", "CapCut", "Controls", "BCC", "Universe", "Node Video", "Transitions", "Light and glow", "Color", "Stylize", "Distort", "Blur", "Generate",
                           "Glitch and motion", "Keying", "Transform and time", "Custom")
    val chipBtns = mutableListOf<CategoryChip>()
    for (nm in chipNames) {
        val b = CategoryChip(nm)
        b.on = (nm == "All" && fxCatName.isEmpty()) || nm == fxCatName
        b.onClick = {
            fxCatName = if (nm == "All") "" else nm
            for (ob in chipBtns) ob.on = (ob.label == "All" && fxCatName.isEmpty()) || ob.label == fxCatName
            fill()
        }
        chipBtns.add(b)
        chipRow.add(EBox(b, 0f, 32f, 0f, 0f, 0f, 0f).also { it.grow = 0f })
    }
    chipScroll.content = chipRow
    put(p, chipScroll, 40f)
    fill()
    p.add(grid)
    if (Registry.order.any { !EffectThumbs.ready(it.id) }) {
        EffectThumbs.generate(this, preview) {
            if (panel == P_FX && fxTab == 1) refreshPanel()
        }
    }
    if (EffectThumbs.lastError.isNotEmpty()) text(p, "Preview error: " + EffectThumbs.lastError, C.RED, 11f)
    Registry.errors["__gl"]?.let { text(p, "GL error: $it", C.RED, 11f) }
}

fun EditorViewController.showEffectInfo(d: EffectDef, l: Layer) {
    val box = vStack()
    val card = EffectCard(d.name, d.category)
    card.anim = d.previewAnim
    card.thumbId = d.id
    card.origId = EffectThumbs.origKey(d.id)
    card.before = EffectThumbs.cache[EffectThumbs.origKey(d.id)]?.let { com.saiki.motion.uikit.UIImage(it) }
    card.after = EffectThumbs.cache[d.id]?.let { com.saiki.motion.uikit.UIImage(it) }
    box.add(EBox(card, 0f, 280f, 0f, 0f, 0f, 0f))
    var sb = d.desc + "\n\nParameters: "
    sb += if (d.props.isEmpty()) "none" else d.props.map { it.label }.joinToString(", ")
    if (d.inputs.isNotEmpty()) sb += "\nLayer inputs: " + d.inputs.joinToString(", ")
    if (!d.builtin) sb += "\nCustom effect"
    Registry.errors[d.id]?.let { sb += "\n\nShader error:\n$it" }
    val info = PLabel()
    info.text = sb; info.color = C.TEXT; info.size = 14f
    box.add(EBox(info, 0f, 0f, 0f, 10f, 0f, 0f).also { it.dyn = { w -> info.height(w) } })
    var b = Dlg(this).setTitle(d.name).setView(box)
        .setPositiveButton("Add to layer") { _, _ ->
            pushUndo()
            if (d.id == "bccstrands" && l.type != LayerType.SHAPE) { addStrands() }
            val entry = if (d.kind == 1) d.id else Registry.uniqueEntry(l, d.id)
            val isNew = !l.fx.contains(entry)
            if (isNew) l.fx.add(entry)
            FxRecent.push(d.id)
            if (isNew && d.id == "particles") l.track("pShowSrc").base = 0f
            if (isNew && (d.id == "particular" || d.id == "bccstrands" || d.id == "bccextrude")) l.is3d = true   // follows camera, nulls and 3D transform
            if (isNew && d.id == "bccstrands") l.track("stShowSrc").base = 0f
            l.fxOff.remove(entry)
            expanded.add("${l.id}:$entry")
            fxTab = 0
            showBottom(); refreshPanel(); render()
        }
        .setNegativeButton("Close", null)
    if (!d.builtin) {
        b = b.setNeutralButton("Export") { _, _ ->
            exportText(d.id + ".saikieffect.json", prettyJson(Registry.toJson(d)))
        }
    }
    b.show()
}

fun EditorViewController.buildPresets(l: Layer) {
    val p = panelList
    put(p, pill("Save current effects as preset", "plus", C.GREEN, C.ONDARK) {
        if (l.fx.isEmpty()) { toast("Add an effect first"); return@pill }
        val et = makeField("My preset")
        Dlg(this).setTitle("Preset name").setView(et).setPositiveButton("Save") { _, _ ->
            var n = et.text
            if (n.trim().isEmpty()) n = "My preset"
            Registry.savePreset(Registry.capturePreset(l, n, Editor.time))
            refreshPanel()
        }.setNegativeButton("Cancel", null).show()
    }, 44f)
    put(p, pill("Import preset file", "import") { pickFile(R_PRESET) }, 44f)
    for (pr in Registry.presets()) {
        text(p, pr.name + (if (pr.builtin) "  (built in)" else ""), C.TEXT, 15f, true)
        val r = hRow()
        r.spacing = 4f
        r.add(EBox(pill("Apply") {
            pushUndo()
            Registry.applyPreset(l, pr.json)
            fxTab = 0
            refreshPanel(); render()
        }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        r.add(EBox(pill("Export") {
            exportText(pr.name + ".saikipreset.json", prettyJson(pr.json))
        }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        if (!pr.builtin) {
            r.add(EBox(pill("Delete", null, C.CARD2, C.RED) {
                Registry.deletePreset(pr.name)
                refreshPanel()
            }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        }
        put(p, r, 40f)
    }
}

fun EditorViewController.buildCustom(l: Layer) {
    val p = panelList
    put(p, pill("Open Effect Editor", "edit", C.GREEN, C.ONDARK) {
        openEffectEditor()
    }, 48f)
    val r0 = hRow()
    r0.spacing = 4f
    r0.add(EBox(pill("New effect", "plus") { openEffectEditor(null, true) }, 0f, 42f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    r0.add(EBox(pill("Import file", "import") { pickFile(R_FX) }, 0f, 42f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    put(p, r0, 42f)
    text(p, "Each effect is a folder with effect.json and effect.glsl. Edit them in the full-screen editor, or put folders in the sdk/ folder of the app. See SDK.md.", C.DIM, 12f)
    val custom = Registry.order.filter { !it.builtin }
    if (custom.isEmpty()) text(p, "No custom effects yet.")
    for (d in custom) {
        text(p, d.name + (if (d.bundled) "  (bundled)" else ""), C.TEXT, 15f, true)
        text(p, d.desc, C.DIM, 12f)
        if (Registry.errors[d.id] != null) text(p, "Shader error. Open the editor and press Run to see the line.", C.RED, 12f)
        val r = hRow()
        r.spacing = 4f
        r.add(EBox(pill("Info") { showEffectInfo(d, l) }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        r.add(EBox(pill(if (d.bundled) "View" else "Edit") { openEffectEditor(d.source) }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        r.add(EBox(pill("Export") {
            exportText(d.id + ".saikieffect.json", prettyJson(Registry.toJson(d)))
        }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        if (!d.bundled) {
            r.add(EBox(pill("Delete", null, C.CARD2, C.RED) {
                Registry.deleteCustom(d.id)
                EffectThumbs.cache.remove(d.id)
                refreshPanel()
            }, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        }
        put(p, r, 40f)
    }
}

/** Opens the full-screen SDK IDE (SdkIdeActivity on Android). */
fun EditorViewController.openEffectEditor(openPath: String? = null, newEffect: Boolean = false) {
    val ide = SdkIdeViewController()
    ide.openPath = openPath
    ide.newEffect = newEffect
    ide.onDone = {
        Registry.reloadSdk()
        for (k in EffectThumbs.cache.keys.toList()) {
            if (Registry.byId[k]?.builtin == false || k.startsWith("__orig:custom:")) EffectThumbs.cache.remove(k)
        }
        EffectThumbs.generate(this, preview) { refreshPanel() }
        refreshPanel(); render()
    }
    val nav = com.saiki.motion.uikit.UINavigationController(ide)
    present(nav, animated = true)
}

fun EditorViewController.showCreateEffect() {
    val box = vStack()
    fun field(hint: String, initText: String): com.saiki.motion.uikit.UITextField {
        val e = makeField(initText)
        e.placeholder = hint
        e.font = sysFont(13f)
        box.add(EBox(e, 0f, 40f, 0f, 4f, 0f, 4f))
        return e
    }
    fun area(hint: String, initText: String, lines: Int): com.saiki.motion.uikit.UITextView {
        val e = com.saiki.motion.uikit.UITextView()
        e.text = initText
        e.font = monoFont(13f)
        e.backing.setTextColor(C.TEXT)
        e.setBackgroundColor(C.CARD2)
        box.add(EBox(e, 0f, lines * 22f + 16f, 0f, 4f, 0f, 4f))
        return e
    }
    val name = field("Name", "My Effect")
    val desc = field("Description", "Mixes the image with grayscale.")
    val params = area("Parameters, one per line: name,label,min,max,default", "amount,Amount,0,1,1", 3)
    val code = area("GLSL code",
                    "vec4 effect(vec2 uv) {\n  vec4 c = src(uv);\n  return vec4(mix(c.rgb, vec3(luma(c.rgb)) * c.a, amount), c.a);\n}", 8)
    Dlg(this).setTitle("Create effect").setView(box).setPositiveButton("Create") { _, _ ->
        try {
            val pa = JSONArray()
            for (line in params.text.split("\n")) {
                val f = line.split(",").map { it.trim() }
                if (f.count() >= 5) {
                    val mn = f[2].toDoubleOrNull() ?: throw Exception("bad number")
                    val mx = f[3].toDoubleOrNull() ?: throw Exception("bad number")
                    val df = f[4].toDoubleOrNull() ?: throw Exception("bad number")
                    pa.put(JSONObject().put("name", f[0]).put("label", f[1]).put("min", mn).put("max", mx).put("def", df))
                }
            }
            val o = JSONObject().put("name", name.text).put("description", desc.text)
                .put("params", pa).put("code", code.text)
            val err = Registry.addCustom(o.toString())
            if (err != null) {
                toast(err)
            } else {
                toast("Effect created")
                EffectThumbs.generate(this, preview) { refreshPanel() }
                refreshPanel()
            }
        } catch (_: Exception) { toast("Check the parameter lines") }
    }.setNegativeButton("Cancel", null).show()
}

// ---- dashboard / editor launchers (iOS bottom extension) ----

fun EditorViewController.openChromaTownDashboard(l: Layer, entry: String) {
    pushUndo()
    present(ChromaTownDashboardViewController(l, entry) { refreshPanel(); render() }, animated = true)
}

fun EditorViewController.openShineDashboard(l: Layer, entry: String) {
    pushUndo()
    present(ShineDashboardViewController(l, entry) { refreshPanel(); render() }, animated = true)
}

fun EditorViewController.openUniverseDashboard(l: Layer, entry: String) {
    pushUndo()
    present(UniverseDashboardViewController(l, entry) { refreshPanel(); render() }, animated = true)
}

/** Full-screen MB Looks editor (own preview, Apply / Close). */
fun EditorViewController.openParticularDesigner(l: Layer) {
    pushUndo()
    present(ParticularDesignerViewController(l, this) { refreshPanel(); render() }, animated = true)
}

fun EditorViewController.openMBLEditor(l: Layer, entry: String) {
    pushUndo()
    present(MBLEditorViewController(l, entry) { refreshPanel(); render() }, animated = true)
}

fun EditorViewController.openLooksEditor(l: Layer, entry: String) {
    pushUndo()
    present(LooksEditorViewController(l, entry) { refreshPanel(); render() }, animated = true)
}

/** Ids of the tools added in an MBL instance (what the editor's chain shows). */
fun mblActiveTools(l: Layer, entry: String): List<String> =
    (l.pbrMaps["mbmods:$entry"] ?: "").split(",").filter { id -> mblTools.any { it.id == id } }

// ================================================================ drag sources (iOS ClosureHold/ClosurePan)

/** Common drag-source surface (iOS FxDragSource protocol). */
interface FxDragSource {
    val state: UIGestureRecognizerState
    var lastTarget: Int
    var frames: List<CGRect>
    fun translationInView(v: UiView?): CGPoint
}

/** Press-and-hold drag source: after a short hold the row follows the finger (works anywhere on the title bar). */
class ClosureHold : UIGestureRecognizer(null), FxDragSource {
    var cb: ((ClosureHold) -> Unit)? = null
    override var lastTarget = -1
    override var frames: List<CGRect> = emptyList()
    private var start = CGPoint(0f, 0f)
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var fire: Runnable? = null
    private var downX = 0f
    private var downY = 0f

    override fun onTouchEvent(e: android.view.MotionEvent, v: UiView): Boolean {
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
                val r = Runnable {
                    state = UIGestureRecognizerState.began
                    start = location(null)
                    cb?.invoke(this@ClosureHold)
                }
                fire = r
                handler.postDelayed(r, (minimumPressDuration * 1000).toLong())
            }
            android.view.MotionEvent.ACTION_MOVE -> {
                if (state == UIGestureRecognizerState.possible &&
                    (kotlin.math.abs(e.x - downX) > 12 || kotlin.math.abs(e.y - downY) > 12)) {
                    fire?.let { handler.removeCallbacks(it) }
                    state = UIGestureRecognizerState.failed
                } else if (state == UIGestureRecognizerState.began) {
                    cb?.invoke(this@ClosureHold)
                }
            }
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                fire?.let { handler.removeCallbacks(it) }
                if (state == UIGestureRecognizerState.began) { state = UIGestureRecognizerState.ended; cb?.invoke(this@ClosureHold) }
            }
        }
        return true
    }

    override fun translationInView(v: UiView?): CGPoint {
        val p = location(null)
        return CGPoint(p.x - start.x, p.y - start.y)
    }
}

class ClosurePan : UIPanGestureRecognizer({ g -> (g as ClosurePan).dispatch() }), FxDragSource {
    var cb: ((ClosurePan) -> Unit)? = null
    override var lastTarget = -1
    override var frames: List<CGRect> = emptyList()

    init {
        maximumNumberOfTouches = 1
    }

    private fun dispatch() { cb?.invoke(this) }

    override fun translationInView(v: UiView?): CGPoint = translation(v)
}

/** Ids of the tools added in an MBL instance. */
class MblToolButton(val id: String) : com.saiki.motion.ui.TapView() {
    public override fun draw(rect: CGRect) {
        val c = com.saiki.motion.uikit.UIGraphics.getCurrentContext() ?: return
        fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 8f, com.saiki.motion.ui.C.CARD2)
        val nm = mblTools.firstOrNull { it.id == id }?.name ?: id
        com.saiki.motion.uikit.drawText(nm, rect.midX, rect.midY + 4f, color = com.saiki.motion.ui.C.TEXT, size = 9f,
            align = com.saiki.motion.uikit.NSTextAlignment.center)
    }
}
