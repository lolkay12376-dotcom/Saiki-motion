@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorFlare.swift — the full-screen Optical Flare editor.

package com.saiki.motion.app

import com.saiki.motion.core.Defs
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Flare
import com.saiki.motion.core.FlareEl
import com.saiki.motion.core.IrisDef
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.LensDef
import com.saiki.motion.core.FlareThumbs
import com.saiki.motion.ui.C
import com.saiki.motion.ui.IconView
import com.saiki.motion.ui.FlareDriver
import com.saiki.motion.ui.FlareEditorView
import com.saiki.motion.ui.FlareThumb
import com.saiki.motion.ui.IrisPreview
import com.saiki.motion.ui.IrisThumb
import com.saiki.motion.ui.SwitchRow
import com.saiki.motion.ui.TabBar
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.ui.boldFont
import com.saiki.motion.ui.chipRow
import com.saiki.motion.ui.sysFont
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.max
import kotlin.math.min
import com.saiki.motion.core.optF
import com.saiki.motion.core.optB

/** UI-only state for the flare editor (extensions cannot hold stored properties). */
enum class FlareUIState { ;
    companion object { var lens = 0 }
}

fun EditorViewController.showFlareLibrary() {
    val l = addLayer(LayerType.FLARE)
    l.name = "Optical Flare ${l.id}"
    l.flare = Flare.builtin().firstOrNull()?.copy() ?: Flare.deflt()
    val asp = Editor.project.w.toFloat() / Editor.project.h.toFloat()
    l.track("x").base = -0.45f * asp
    l.track("y").base = 0.3f
    flTab = 0
    openFlareEditor(l, isNew = true)
}

/** Moves the light to the spot a reference preset was built for (skipped for 3D lights and when the preset has none). */
fun EditorViewController.applyFlareAnchor(l: Layer, f: Flare) {
    val a = f.anchor ?: return
    if (l.is3d) return
    val asp = Editor.project.w.toFloat() / Editor.project.h.toFloat()
    l.track("x").base = (a.x - 0.5f) * 2f * asp
    l.track("y").base = (0.5f - a.y) * 2f
}

fun EditorViewController.addFlare(f: Flare, customize: Boolean) {
    val l = addLayer(LayerType.FLARE)
    l.name = "Optical Flare ${l.id}"
    l.flare = f
    val asp = Editor.project.w.toFloat() / Editor.project.h.toFloat()
    l.track("x").base = -0.45f * asp
    l.track("y").base = 0.3f
    applyFlareAnchor(l, f)
    if (customize) openFlareEditor(l, isNew = true) else { render(); refreshPanel() }
}

fun EditorViewController.openFlareEditor(l: Layer, isNew: Boolean = false) {
    if (flareOverlay != null) return
    if (l.flare == null) l.flare = Flare.deflt()
    pushUndo()
    flareLayer = l
    flIsNew = isNew
    val b = org.json.JSONObject().put("flare", l.flare!!.toJson())
    for (d in Defs.flare) b.put(d.key, l.track(d.key).base.toDouble())
    b.put("opacity", l.track("opacity").base.toDouble())
    b.put("is3d", l.is3d)
    flareBackup = b
    if (!isNew) flTab = 1
    flSel = 0
    Flare.loadUser()
    IrisDef.loadUser()
    buildFlareOverlay()
}

fun EditorViewController.closeFlareEditor(save: Boolean) {
    stopFlareSweep()
    val l = flareLayer
    val b = flareBackup
    if (l != null && !save && b != null) {
        if (flIsNew) {
            Editor.scene.layers.removeAll { it === l }
            onSelect(-1)
        } else {
            b.optJSONObject("flare")?.let { l.flare = Flare.fromJson(it) }
            for (d in Defs.flare) l.track(d.key).base = b.optF(d.key, d.def)
            l.track("opacity").base = b.optF("opacity", 1f)
            l.is3d = b.optB("is3d", l.is3d)
        }
    }
    // hand the live preview back to the editor
    val parent = flareParent
    if (parent != null) {
        parent.addSubview(aspect)
        aspect.frame = CGRect(0f, 0f, parent.rectWidth(), parent.rectHeight())
    }
    flareParent = null
    flareOverlay?.removeFromSuperview()
    flareOverlay = null; flareContent = null; flareLayer = null; flareTabs = null
    render(); refreshAll()
}

// ---------------------------------------------------------------- light animation

fun EditorViewController.toggleFlareSweep() {
    if (flareDriver != null) { stopFlareSweep(); return }
    val l = flareLayer ?: return
    val asp = Editor.project.w.toFloat() / Editor.project.h.toFloat()
    flareSweepBase = Pair(l.track("x").base, l.track("y").base)
    val d = FlareDriver()
    d.tick = tick@{ t ->
        val ll = flareLayer ?: return@tick
        val tt = t.toFloat()
        ll.track("x").base = asp * 0.85f * sin(tt * 0.8f)
        ll.track("y").base = 0.6f * sin(tt * 1.15f + 1.0f)
        render()
    }
    flareDriver = d
    d.start()
    toast("Move the light with your finger or watch it drift")
}

fun EditorViewController.stopFlareSweep() {
    flareDriver?.stop()
    flareDriver = null
    val l = flareLayer
    val b = flareSweepBase
    if (l != null && b != null) {
        l.track("x").base = b.first
        l.track("y").base = b.second
    }
    flareSweepBase = null
    render()
}

// ---------------------------------------------------------------- overlay

fun EditorViewController.buildFlareOverlay() {
    val ov = FlareEditorView(appContext!!)
    ov.setBackgroundColor(C.BG)

    // top bar
    ov.bar.setBackgroundColor(C.PANEL)
    val cancel = pill("Cancel") { closeFlareEditor(false) }
    val apply = pill("Apply", "check", C.GREEN, C.ONDARK) { closeFlareEditor(true) }
    cancel.frame = CGRect(10f, 7f, 92f, 40f)
    apply.frame = CGRect(0f, 7f, 102f, 40f)
    val tt = UILabel(com.saiki.motion.uikit.appContext!!)
    tt.text = "Optical Flare"
    tt.textColor = argbToUIColor(C.TEXT)
    tt.font = boldFont(17f)
    tt.textAlignment = com.saiki.motion.uikit.NSTextAlignment.center
    ov.bar.addSubview(cancel); ov.bar.addSubview(tt); ov.bar.addSubview(apply)

    // live preview: move the real preview up here
    ov.holder.setBackgroundColor(0xFF161618.toInt())
    ov.holder.clipsToBounds = true
    flareParent = aspect.superview
    ov.holder.addSubview(aspect)

    // tools row
    ov.tools.setBackgroundColor(C.PANEL)
    val anim = pill("Animate light", "play", C.CARD2, C.TEXT) { toggleFlareSweep() }
    anim.frame = CGRect(10f, 5f, 150f, 40f)
    val hint = UILabel(com.saiki.motion.uikit.appContext!!)
    hint.text = "Drag the light in the preview. Ghosts, spikes and glints react like a real lens."
    hint.textColor = argbToUIColor(C.DIM)
    hint.font = sysFont(11f)
    hint.numberOfLines = 3
    ov.tools.addSubview(anim); ov.tools.addSubview(hint)

    // tabs
    val tabs = TabBar(listOf("Presets", "Elements", "Edit", "Iris", "Global"), flTab) { i ->
        flTab = i
        refreshFlare()
    }
    flareTabs = tabs
    ov.tabs = tabs

    // panel
    val content = vStack()
    ov.content.add(content)
    flareContent = content

    ov.preview = aspect
    screen.addSubview(ov)
    flareOverlay = ov
    ov.postLayout2 = { w ->
        val ww = w ?: 0f
        ov.bar.frame = CGRect(0f, 0f, ww, 54f)
        tt.frame = CGRect(110f, 0f, ww - 224f, 54f)
        apply.frame = CGRect(ww - 112f, 7f, 102f, 40f)
        ov.holder.frame = CGRect(0f, 54f, ww, ww * 9f / 16f)
        aspect.frame = CGRect(0f, 0f, ov.holder.rectWidth(), ov.holder.rectHeight())
        ov.tools.frame = CGRect(0f, 54f + ov.holder.rectHeight(), ww, 50f)
        hint.frame = CGRect(170f, 0f, ww - 180f, 50f)
        tabs.frame = CGRect(0f, 54f + ov.holder.rectHeight() + 50f, ww, 44f)
        ov.scroll.frame = CGRect(0f, 54f + ov.holder.rectHeight() + 94f, ww, ov.rectHeight() - (54f + ov.holder.rectHeight() + 94f))
    }
    refreshFlare()
    render()
}

fun EditorViewController.refreshFlare() {
    val l = flareLayer ?: return
    val f = l.flare ?: return
    val p = flareContent ?: return
    p.clear()
    flareTabs?.sel = flTab
    flareTabs?.setNeedsDisplay()
    if (flSel >= f.els.count()) flSel = max(f.els.count() - 1, 0)
    when (flTab) {
        0 -> flarePresets(p, l, f)
        1 -> flareElements(p, l, f)
        2 -> flareEditEl(p, l, f)
        3 -> flareIris(p, l, f)
        else -> flareGlobal(p, l, f)
    }
}

// ---------------------------------------------------------------- presets

fun EditorViewController.flarePresets(p: EVStack, l: Layer, f: Flare) {
    val all = Flare.builtin() + Flare.user
    FlareThumbs.generate(all) { }
    text(p, "Presets", C.GREEN, 14f, true)
    var row: EHStack? = null
    for ((i, pr) in all.withIndex()) {
        if (i % 3 == 0) {
            val r = hRow()
            p.add(r)
            row = r
        }
        val th = FlareThumb(pr.sig(), pr.name)
        th.onClick = {
            l.flare = pr.copy()
            applyFlareAnchor(l, pr)
            flSel = 0
            render(); refreshFlare()
        }
        row?.add(EBox(th, 0f, 92f, 3f, 3f, 3f, 3f).also { it.grow = 1f })
    }
    val rem = all.count() % 3
    if (rem != 0) row?.let { r -> for (i in 0 until 3 - rem) r.add(EBox(UiView(appContext!!), 0f, 0f, 0f, 0f, 0f, 0f).also { it.grow = 1f }) }
    put(p, pill("Save as my preset", "plus") {
        val et = makeField("")
        et.placeholder = "Preset name"
        et.text = f.name
        Dlg(this).setTitle("Save preset").setView(et).setPositiveButton("Save") { _, _ ->
            val c = f.copy()
            val nm = et.text.trim()
            c.name = if (nm.isEmpty()) "My flare ${Flare.user.count() + 1}" else nm
            Flare.user.add(c)
            Flare.saveUser()
            refreshFlare()
        }.setNegativeButton("Cancel", null).show()
    }, 46f, 10f, 4f)
    text(p, "Tap a preset to load it, then fine-tune it in Elements, Edit and Iris.", C.DIM, 12f)
}

// ---------------------------------------------------------------- elements

fun EditorViewController.flareElements(p: EVStack, l: Layer, f: Flare) {
    put(p, pill(if (flBrowse) "Close element browser" else "Add element", if (flBrowse) "check" else "plus", C.GREEN, C.ONDARK) {
        flBrowse = !flBrowse; refreshFlare()
    }, 46f)
    if (flBrowse) flareElementBrowser(p, f)
    if (f.els.isEmpty()) text(p, "No elements. Add a Glow to start.", C.DIM, 13f)
    for ((i, e) in f.els.withIndex()) {
        val row = hRow()
        row.setBackgroundColor(if (i == flSel) 0xFF2A2A30.toInt() else C.CARD)
        val eye = IconView(if (e.enabled) "eye" else "eye_off", if (e.enabled) 0xFFFFFFFF.toInt() else C.DIM, 20f)
        eye.onClick = { e.enabled = !e.enabled; refreshFlare(); render() }
        row.add(EBox(eye, 40f, 48f, 4f, 0f, 0f, 0f))
        val sw = UiView(appContext!!)
        sw.setBackgroundColor(e.color or 0xFF000000.toInt())
        row.add(EBox(sw, 10f, 26f, 0f, 0f, 0f, 0f))
        val tv = UILabel(com.saiki.motion.uikit.appContext!!)
        tv.text = "  " + e.label() + "  (" + String.format("%.2f", e.pos) + ")"
        tv.textColor = argbToUIColor(C.TEXT)
        tv.font = sysFont(14f)
        tv.numberOfLines = 1
        val tap = com.saiki.motion.ui.TapView()
        tap.addSubview(tv)
        tap.onClick = {
            flSel = i; flTab = if (e.isIris) 3 else 2
            refreshFlare()
        }
        row.add(growBox(tap))
        fun btn(icon: String, tint: Int, click: () -> Unit) {
            val b = IconView(icon, tint, 18f)
            b.onClick = click
            row.add(EBox(b, 34f, 48f, 0f, 0f, 0f, 0f))
        }
        btn("chev_up", 0xFFFFFFFF.toInt()) {
            if (i > 0) { val e2 = f.els.removeAt(i); f.els.add(i - 1, e2); flSel = i - 1; refreshFlare(); render() }
        }
        btn("chev_down", 0xFFFFFFFF.toInt()) {
            if (i < f.els.count() - 1) { val e2 = f.els.removeAt(i); f.els.add(i + 1, e2); flSel = i + 1; refreshFlare(); render() }
        }
        btn("dup", 0xFFFFFFFF.toInt()) {
            if (f.els.count() < FlareEl.MAX) {
                f.els.add(i + 1, e.copy())
                flSel = i + 1
                refreshFlare(); render()
            }
        }
        btn("trash", C.RED) {
            f.els.removeAt(i)
            refreshFlare(); render()
        }
        put(p, row, 0f, 3f, 3f)
    }
    text(p, "Position 0 is the light itself, 1 is the screen center and 2 is the opposite side. Tap an element to edit it.", C.DIM, 12f)
}

fun EditorViewController.flareElementBrowser(p: EVStack, f: Flare) {
    val all = FlareThumbs.elementPreviews()
    FlareThumbs.generate(all) { }
    text(p, "Tap an element to add it to the flare", C.DIM, 12f)
    var row: EHStack? = null
    for ((i, pr) in all.withIndex()) {
        if (i % 3 == 0) {
            val r = hRow()
            p.add(r); row = r
        }
        val th = FlareThumb(pr.sig(), pr.name)
        th.onClick = onClick@{
            val ff = flareLayer?.flare ?: return@onClick
            if (ff.els.count() >= FlareEl.MAX) { toast("A flare can hold ${FlareEl.MAX} elements"); return@onClick }
            val e = FlareEl.make(i)
            ff.els.add(e)
            flSel = ff.els.count() - 1
            flBrowse = false
            flTab = if (e.isIris) 3 else 2
            refreshFlare(); render()
        }
        row?.add(EBox(th, 0f, 92f, 3f, 3f, 3f, 3f).also { it.grow = 1f })
    }
    val rem = all.count() % 3
    if (rem != 0) row?.let { r -> for (i in 0 until 3 - rem) r.add(EBox(UiView(appContext!!), 0f, 0f, 0f, 0f, 0f, 0f).also { it.grow = 1f }) }
}

// ---------------------------------------------------------------- edit element

fun EditorViewController.flareEditEl(p: EVStack, l: Layer, f: Flare) {
    if (f.els.isEmpty()) { text(p, "Add an element in the Elements tab first.", C.DIM, 13f); return }
    val e = f.els[flSel]
    text(p, "Editing: " + e.label() + "  (" + (flSel + 1) + " of " + f.els.count() + ")", C.GREEN, 14f, true)
    p.add(chipRow(FlareEl.TYPES, e.type) { i ->
        val old = e.type
        e.type = i
        if (i == 13 && old != 13) e.sides = max(e.sides, 3)
        refreshFlare(); render()
    })
    val t = e.type
    text(p, "Color of this element", C.GREEN, 13f, true)
    addColorRow(p, e.color) { c -> e.color = c; render() }
    addPlain(p, "Position on axis", -1f, 3f, e.pos, 2) { e.pos = it; render() }
    addPlain(p, "Size", 0.01f, 2.5f, e.size, 3) { e.size = it; render() }
    addPlain(p, "Brightness", 0f, 4f, e.bright, 2) { e.bright = it; render() }
    if (listOf(0, 1, 5, 9, 13, 14, 16, 2).contains(t)) {
        addPlain(p, if (t == 9 || t == 2) "Length" else "Stretch (width / height)", 0.1f, 20f, e.stretch, 2) { e.stretch = it; render() }
    }
    addPlain(p, "Off-axis shift (up / down from the axis)", -1.5f, 1.5f, e.off, 3) { e.off = it; render() }
    addPlain(p, "Rotation", -180f, 180f, e.rot, 0) { e.rot = it; render() }
    if (t != 6) addPlain(p, "Softness", 0f, 1f, e.soft, 2) { e.soft = it; render() }
    if (listOf(1, 2, 4, 5, 8, 9, 11, 14, 15, 16).contains(t)) {
        val nm = if (t == 4) "Outline thickness (1 = filled)" else (if (t == 11) "Band width" else "Thickness")
        addPlain(p, nm, 0.01f, 1f, e.thick, 2) { e.thick = it; render() }
    }
    if (listOf(3, 7, 10, 12).contains(t)) addPlain(p, "Rays", 2f, 40f, e.rays.toFloat(), 0) { e.rays = it.toInt(); render() }
    if (listOf(7, 10, 12).contains(t)) addPlain(p, if (t == 12) "Shimmer amount" else "Random ray length", 0f, 1f, e.noise, 2) { e.noise = it; render() }
    if (listOf(1, 2, 4, 5, 8, 9, 11, 13, 14, 15, 16).contains(t)) addPlain(p, "Rainbow fringe", 0f, 1f, e.chroma, 2) { e.chroma = it; render() }
    if (t == 15) addPlain(p, "Arc length", 0.05f, 1f, e.spread, 2) { e.spread = it; render() }
    if (t == 14 || t == 16) {
        addPlain(p, if (t == 16) "Number of lenses" else "Copies", 2f, 8f, e.rays.toFloat(), 0) { e.rays = it.toInt(); render() }
        addPlain(p, "Spacing along the axis", 0.05f, 1f, e.spread, 2) { e.spread = it; render() }
        if (t == 14) addPlain(p, "Size variation", 0f, 1f, e.noise, 2) { e.noise = it; render() }
    }
    if (t == 14 || t == 16) {
        addPlain(p, "Brightness gain where lenses overlap", 0f, 3f, e.gain, 2) { e.gain = it; render() }
    }
    if (t == 16) flareLenses(p, e)
    if (e.isIris) {
        addPlain(p, "Blades", 3f, 16f, e.sides.toFloat(), 0) { e.sides = it.toInt(); render() }
        put(p, pill("Open iris browser", "edit", C.CARD2, C.TEXT) {
            flTab = 3; refreshFlare()
        }, 44f, 6f, 4f)
    }
    addPlain(p, "Spin when the light moves", -1f, 1f, e.spin, 2) { e.spin = it; render() }
    val fo = SwitchRow()
    fo.label = "Turn with the flare axis"
    fo.on = e.follow
    fo.onToggle = { e.follow = it; render() }
    put(p, fo, 52f)
}

// ---------------------------------------------------------------- lens stack

fun EditorViewController.flareLenses(p: EVStack, e: FlareEl) {
    if (e.lenses.isEmpty()) e.lenses = LensDef.defaultStack()
    while (e.lenses.count() < 8) e.lenses.add(LensDef())
    val n = min(max(e.rays, 1), 8)
    FlareUIStateCompanion.lens = min(FlareUIStateCompanion.lens, n - 1)
    text(p, "Lens stack: pick a lens, then choose its type", C.GREEN, 13f, true)
    p.add(chipRow((1..n).map { "Lens $it" }, FlareUIStateCompanion.lens) { i ->
        FlareUIStateCompanion.lens = i; refreshFlare()
    })
    val k = FlareUIStateCompanion.lens
    text(p, "Lens type", C.DIM, 12f)
    p.add(chipRow(LensDef.KINDS, e.lenses[k].kind) { i -> e.lenses[k].kind = i; render() })
    addPlain(p, "Lens size", 0.2f, 2.5f, e.lenses[k].size, 2) { e.lenses[k].size = it; render() }
    addPlain(p, "Lens brightness", 0f, 3f, e.lenses[k].bright, 2) { e.lenses[k].bright = it; render() }
    addPlain(p, "Extra distance along the axis", -1f, 1f, e.lenses[k].offset, 2) { e.lenses[k].offset = it; render() }
    addPlain(p, "Lens turn", -180f, 180f, e.lenses[k].rot, 0) { e.lenses[k].rot = it; render() }
    text(p, "Lens coating tint", C.DIM, 12f)
    addColorRow(p, e.lenses[k].color) { c -> e.lenses[k].color = c; render() }
    put(p, pill("Randomize all lenses") {
        val tints = listOf(0xFFFFFFFFL, 0xFFBFD8FFL, 0xFFFFD2A0L, 0xFFC8FFD8L, 0xFFE4C8FFL, 0xFFFFE8B8L, 0xFFFFB8C8L)
        for (i in 0 until 8) {
            e.lenses[i].kind = kotlin.random.Random.nextInt(LensDef.KINDS.count())
            e.lenses[i].size = kotlin.random.Random.nextDouble(0.55, 1.25).toFloat()
            e.lenses[i].bright = kotlin.random.Random.nextDouble(0.5, 1.1).toFloat()
            e.lenses[i].rot = kotlin.random.Random.nextDouble(-40.0, 40.0).toFloat()
            e.lenses[i].color = tints[kotlin.random.Random.nextInt(tints.count())].toInt()
        }
        render(); refreshFlare()
    }, 44f, 6f, 4f)
    put(p, pill("Reset to the realistic stack") {
        e.lenses = LensDef.defaultStack(); e.rays = 6
        render(); refreshFlare()
    }, 44f, 4f, 4f)
}

/** Companion holder (Kotlin enum-class companion of FlareUIState). */
val FlareUIStateCompanion: FlareUIState.Companion = FlareUIState.Companion

// ---------------------------------------------------------------- iris browser

fun EditorViewController.flareIris(p: EVStack, l: Layer, f: Flare) {
    text(p, "Procedural iris browser", C.GREEN, 14f, true)
    if (f.els.isEmpty() || flSel !in f.els.indices || !f.els[flSel].isIris) {
        text(p, "Pick an Iris, Multi iris, Polygon or Ring polygon element, or add a new iris.", C.DIM, 13f)
        put(p, pill("Add iris element", "plus", C.GREEN, C.ONDARK) {
            val ff = flareLayer?.flare ?: return@pill
            if (ff.els.count() >= FlareEl.MAX) return@pill
            ff.els.add(FlareEl.make(13))
            flSel = ff.els.count() - 1
            refreshFlare(); render()
        }, 46f, 8f, 4f)
        return
    }
    val e = f.els[flSel]
    val cur = IrisDef(e)

    val pv = IrisPreview()
    pv.def = cur
    pv.tint = e.color or 0xFF000000.toInt()
    put(p, pv, 130f, 4f, 6f)

    val nBuiltin = IrisDef.builtin().count()
    val all = IrisDef.builtin() + IrisDef.user
    val cats = mutableListOf<String>()
    for (d in all) if (!cats.contains(d.cat)) cats.add(d.cat)
    for (cat in cats) {
        text(p, cat, C.DIM, 12f, true)
        var row: EHStack? = null
        var n = 0
        for ((i, d) in all.withIndex()) {
            if (d.cat != cat) continue
            if (n % 4 == 0) {
                val r = hRow()
                p.add(r); row = r
            }
            n += 1
            val th = IrisThumb(d)
            th.picked = (d.sides == e.sides && abs(d.round - e.round) < 0.001f && abs(d.star - e.star) < 0.001f && abs(d.curve - e.curve) < 0.001f && abs(d.thick - e.thick) < 0.001f)
            th.onClick = {
                d.apply(e)
                if (!e.isIris) e.type = 13
                render(); refreshFlare()
            }
            if (i >= nBuiltin) {
                th.onLongPress = {
                    Dlg(this).setTitle("Delete \"${d.name}\"?").setPositiveButton("Delete") { _, _ ->
                        val k = i - nBuiltin
                        if (k in IrisDef.user.indices) { IrisDef.user.removeAt(k); IrisDef.saveUser() }
                        refreshFlare()
                    }.setNegativeButton("Cancel", null).show()
                }
            }
            row?.add(EBox(th, 0f, 78f, 3f, 3f, 3f, 3f).also { it.grow = 1f })
        }
        row?.let { r -> for (i in 0 until (4 - n % 4) % 4) r.add(EBox(UiView(appContext!!), 0f, 0f, 0f, 0f, 0f, 0f).also { it.grow = 1f }) }
    }

    val btns = hRow(); btns.spacing = 8f
    btns.add(EBox(pill("Surprise me", "plus", C.CARD2, C.TEXT) {
        IrisDef.random().apply(e)
        if (!e.isIris) e.type = 13
        render(); refreshFlare()
    }, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    btns.add(EBox(pill("Save iris", "plus", C.GREEN, C.ONDARK) {
        val et = makeField("")
        et.placeholder = "Iris name"
        Dlg(this).setTitle("Save iris").setView(et).setPositiveButton("Save") { _, _ ->
            val d = IrisDef(e)
            val nm = et.text.trim()
            d.name = if (nm.isEmpty()) "My iris ${IrisDef.user.count() + 1}" else nm
            IrisDef.user.add(d)
            IrisDef.saveUser()
            refreshFlare()
        }.setNegativeButton("Cancel", null).show()
    }, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    put(p, btns, 46f, 6f, 6f)

    addPlain(p, "Blades", 3f, 16f, e.sides.toFloat(), 0) { e.sides = it.toInt(); pv.def = IrisDef(e); render() }
    addPlain(p, "Roundness (1 = circle)", 0f, 1f, e.round, 2) { e.round = it; pv.def = IrisDef(e); render() }
    addPlain(p, "Star depth", 0f, 1f, e.star, 2) { e.star = it; pv.def = IrisDef(e); render() }
    addPlain(p, "Edge curve (− scallop / + bulge)", -1f, 1f, e.curve, 2) { e.curve = it; pv.def = IrisDef(e); render() }
    addPlain(p, "Thickness (1 = filled)", 0.05f, 1f, e.thick, 2) { e.thick = it; pv.def = IrisDef(e); render() }
    addPlain(p, "Edge softness", 0f, 1f, e.soft, 2) { e.soft = it; pv.def = IrisDef(e); render() }
    addPlain(p, "Edge brightness", 0f, 1f, e.grad, 2) { e.grad = it; pv.def = IrisDef(e); render() }
    addPlain(p, "Rainbow fringe", 0f, 1f, e.chroma, 2) { e.chroma = it; pv.def = IrisDef(e); render() }
    text(p, "Long-press one of your saved irises to delete it. Position, size, color and brightness are in the Edit tab.", C.DIM, 12f)
}

// ---------------------------------------------------------------- global

fun EditorViewController.flareGlobal(p: EVStack, l: Layer, f: Flare) {
    text(p, "Whole flare", C.GREEN, 14f, true)
    val opTr = l.track("opacity")
    addPlain(p, "Layer opacity", 0f, 1f, opTr.base, 2) { opTr.base = it; render() }
    text(p, "Tint (multiplies every element)", C.DIM, 12f)
    addColorRow(p, f.tint) { c -> f.tint = c; render() }
    text(p, "Set one color on every element", C.DIM, 12f)
    addColorRow(p, f.els.firstOrNull()?.color ?: 0xFFFFFFFF.toInt()) { c ->
        for (el in f.els) el.color = c
        render()
    }
    put(p, pill("Reset element colors to white") {
        for (el in f.els) el.color = 0xFFFFFFFF.toInt()
        render(); refreshFlare()
    }, 44f, 4f, 4f)
    for (d in Defs.flare) {
        val tr = l.track(d.key)
        addPlain(p, d.label, d.min, d.max, tr.base, d.dec) { v ->
            tr.base = v
            render()
        }
        if (tr.keys.isNotEmpty()) text(p, d.label + " is keyframed. Edit it in the layer's Edit panel.", C.AMBER, 11f)
    }
    addPlain(p, "Rays / spikes strength (0 = no rays)", 0f, 1.5f, f.rayAmt, 2) { f.rayAmt = it; render() }
    text(p, "Optics (realism)", C.GREEN, 14f, true)
    addPlain(p, "Realism (0 = flat graphic, 1 = optical)", 0f, 1f, f.realism, 2) { f.realism = it; render() }
    addPlain(p, "Veiling glare (haze around the light)", 0f, 1f, f.veil, 2) { f.veil = it; render() }
    addPlain(p, "Dust and scratches on the glass", 0f, 1f, f.dust, 2) { f.dust = it; render() }
    addPlain(p, "3D occlusion (objects hide the light)", 0f, 1f, f.occlusion, 2) { f.occlusion = it; render() }
    addPlain(p, "Occlusion edge softness (size of the light)", 0f, 1f, f.occlSoft, 2) { f.occlSoft = it; render() }
    text(p, "Occlusion needs the flare layer set to 3D; models and 3D planes in front of the light then cut the flare, like a sun going behind a building.", C.DIM, 11f)
    text(p, "Life", C.GREEN, 14f, true)
    addPlain(p, "Flicker", 0f, 1f, f.flicker, 2) { f.flicker = it; render() }
    addPlain(p, "Shimmer / flicker speed", 0f, 4f, f.speed, 2) { f.speed = it; render() }
    text(p, "3D and camera", C.GREEN, 14f, true)
    addPlain(p, "Size change with distance", 0f, 1f, f.depthScale, 2) { f.depthScale = it; render() }
    addPlain(p, "Fade when the light leaves the screen", 0.01f, 1.5f, f.edgeFade, 2) { f.edgeFade = it; render() }
    val d3 = SwitchRow()
    d3.label = "3D layer (follows the camera)"
    d3.on = l.is3d
    d3.onToggle = { _ ->
        l.is3d = !l.is3d
        render()
        refreshFlare()
    }
    put(p, d3, 52f)
    text(p, "With 3D on, the light is projected through the camera: it shrinks with distance, slides with camera moves and vanishes behind the camera. Opacity and blend work like any layer.", C.DIM, 12f)
}
