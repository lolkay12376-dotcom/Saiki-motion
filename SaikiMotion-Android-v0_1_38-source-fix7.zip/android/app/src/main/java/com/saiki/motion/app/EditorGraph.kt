@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorGraph.swift — the graph editor panel (value plot, easing curve, presets).

package com.saiki.motion.app

import com.saiki.motion.core.Editor
import com.saiki.motion.core.Key
import com.saiki.motion.core.Layer
import com.saiki.motion.core.Registry
import com.saiki.motion.core.clamp
import kotlin.math.max
import com.saiki.motion.ui.C
import com.saiki.motion.ui.GraphPanelView
import com.saiki.motion.ui.GraphView
import com.saiki.motion.ui.ValueGraphView
import com.saiki.motion.ui.chipRow
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UiView

fun EditorViewController.buildGraph(l: Layer) {
    val p = panelList
    graphOverlayView?.removeFromSuperview(); graphOverlayView = null
    text(p, "Graph editor", C.TEXT, 16f, true)
    // Kotlin props is a HashMap (unordered); sorted here so the chip row is stable.
    val animated = l.props.filter { it.value.keys.count() >= 2 }.map { it.key }.sorted()
    if (animated.isEmpty()) {
        text(p, "Add two keyframes to a parameter (tap its name, then the keyframe button) or tap a keyframe in the timeline.")
        return
    }
    if (!animated.contains(graphProp)) { graphProp = animated[0]; graphKey = 0 }
    val chips = chipRow(animated.map { Registry.propDef(it)?.label ?: it },
        animated.indexOf(graphProp).let { if (it < 0) 0 else it }) { i ->
        graphProp = animated[i]
        graphKey = 0
        refreshPanel()
    }
    val tr = l.track(graphProp)
    if (tr.keys.count() >= 2) {
        graphKey = clamp(graphKey, 0, tr.keys.count() - 2)
    }
    if (tr.keys.count() < 2 || graphKey !in tr.keys.indices) return
    val key = tr.keys[graphKey]
    // the panel: Ease / Value / Speed tabs, curve-type dropdown, draggable knobs, preset column
    val gp = GraphPanelView(key)
    gp.tab = graphTab
    gp.title = Registry.propDef(graphProp)?.label ?: graphProp
    gp.segText = "◆${graphKey + 1} → ◆${graphKey + 2}"
    gp.onBeginCb = { pushUndo() }
    gp.onChange = { render() }
    gp.onRefresh = { refreshPanel() }
    gp.onTab = { i -> graphTab = i; refreshPanel() }
    gp.onClose = { closePanel() }
    gp.onCycleSegment = {
        graphKey = (graphKey + 1) % max(tr.keys.count() - 1, 1)
        refreshPanel()
    }
    gp.onCopy = {
        curveClip = Key(0f, 0f, com.saiki.motion.core.Ease.CUSTOM)
        curveClip?.copyCurveFrom(key)
        Snack.show("Curve copied (tap the clipboard to paste it elsewhere)")
    }
    gp.onPaste = {
        val c = curveClip
        if (c == null) { Snack.show("Long-press the clipboard to copy this curve first") } else {
            pushUndo()
            key.copyCurveFrom(c)
            refreshPanel(); render()
        }
    }
    gp.makeValueView = { speed ->
        val vg = ValueGraphView()
        vg.track = tr
        vg.speedMode = speed
        vg.t0 = max(0f, (tr.keys.firstOrNull()?.t ?: 0f) - 0.3f)
        vg.t1 = max(vg.t0 + 0.5f, (tr.keys.lastOrNull()?.t ?: 1f) + 0.3f)
        vg.selIdx = graphKey
        vg.onPick = { i ->
            if (tr.keys.count() >= 2) graphKey = clamp(i, 0, tr.keys.count() - 2)
            if (i in tr.keys.indices) Editor.time = tr.keys[i].t
            onTimeChanged(); refreshPanel()
        }
        vg
    }
    gp.build()
    presentGraphOverlay(gp, chips)     // big panel over the lower part of the screen (the preview stays visible above)
    text(p, "Drag the knobs: green = strength, orange = count (drag sideways). Right: pick a curve type, then a preset. ⋯ = copy / paste / save.", C.DIM, 12f)
    addPlain(p, "Keyframe time (s)", 0f, Editor.scene.duration, key.t, 2) { v ->
        key.t = v
        tr.keys.sortBy { it.t }
        render()
    }
    val pd = Registry.propDef(graphProp)
    if (pd != null) {
        addPlain(p, "Keyframe value", pd.min, pd.max, key.v, pd.dec) { v ->
            key.v = v
            render()
        }
    }
    put(p, pill("Apply this curve to every segment") {
        pushUndo()
        for (k in tr.keys) k.copyCurveFrom(key)
        render()
    }, 42f)
}


/** The graph editor as a large panel (portrait: bottom ~58% of the screen, landscape: right ~56%)
 *  instead of a 292 pt strip inside the small bottom panel. */
fun EditorViewController.presentGraphOverlay(gp: GraphPanelView, chips: UiView) {
    graphOverlayView?.removeFromSuperview()
    val host: UiView = view
    val box = GraphOverlayBox(this, gp, chips)
    box.setBackgroundColor(0xFF141416.toInt())
    host.addSubview(box)
    graphOverlayView = box
}

/** Host box of the big graph editor overlay: chips row on top, GraphPanelView below (EditorGraph.swift). */
private class GraphOverlayBox(val ed: EditorViewController, val gp: GraphPanelView, val chips: UiView) : UiView(com.saiki.motion.uikit.appContext!!) {
    init {
        clipsToBounds = true
        addSubview(chips)
        addSubview(gp)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        chips.frame = CGRect(8f, 6f, max(0f, rectWidth() - 16f), 40f)
        gp.frame = CGRect(0f, 48f, rectWidth(), max(0f, rectHeight() - 48f))
        gp.build()
    }
}

