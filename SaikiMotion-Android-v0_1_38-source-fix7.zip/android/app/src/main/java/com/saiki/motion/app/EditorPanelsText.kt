@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorPanelsText.swift — property-panel framework +
// Media/Shapes/Edit/Text panels + the color rows.

package com.saiki.motion.app

import android.graphics.Bitmap
import android.graphics.Canvas
import com.saiki.motion.core.Defs
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.PreRender
import com.saiki.motion.core.Projects
import com.saiki.motion.core.PropDef
import com.saiki.motion.core.Registry
import com.saiki.motion.core.ShapeKind
import com.saiki.motion.core.TextAnim
import com.saiki.motion.core.TextFx
import com.saiki.motion.core.TextRaster
import com.saiki.motion.core.Track
import com.saiki.motion.core.argbColor
import com.saiki.motion.core.colorAlpha
import com.saiki.motion.core.colorBlue
import com.saiki.motion.core.colorGreen
import com.saiki.motion.core.colorRed
import com.saiki.motion.core.nowMs
import kotlin.math.abs
import com.saiki.motion.ui.C
import com.saiki.motion.ui.CloudSettings
import com.saiki.motion.ui.MediaBrowserView
import com.saiki.motion.ui.importPHAssets
import com.saiki.motion.ui.openFullMediaBrowser   // the real one: in-app MediaBrowserViewController fullscreen (iOS MediaBrowser.swift:338)
import com.saiki.motion.ui.FontBrowserViewController
import com.saiki.motion.ui.ColorPickerView
import com.saiki.motion.ui.GraphView
import com.saiki.motion.ui.RulerSlider
import com.saiki.motion.ui.SwitchRow
import com.saiki.motion.ui.TapView
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.ui.boldFont
import com.saiki.motion.ui.chipRow
import com.saiki.motion.ui.fillRoundRect
import com.saiki.motion.ui.shapeGrid
import com.saiki.motion.ui.sysFont
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UITapGestureRecognizer
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.drawText
import com.saiki.motion.uikit.measureText
import java.io.File
import kotlin.math.abs
import kotlin.math.min

/** Sweep-gradient circle that opens the full color picker (iOS RainbowCircleView). */
private class RainbowCircleView : TapView() {
    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val r = min(rectWidth(), rectHeight()) / 2 - 1f
        c.saveGState()
        c.translateBy(rectWidth() / 2, rectHeight() / 2)
        val n = 36
        for (i in 0 until n) {
            val a0 = i.toFloat() / n * 2f * Math.PI.toFloat()
            val a1 = (i + 1).toFloat() / n * 2f * Math.PI.toFloat()
            val hue = android.graphics.Color.HSVToColor(floatArrayOf(i.toFloat() / n * 360f, 1f, 1f))
            c.paint.color = hue
            c.paint.style = android.graphics.Paint.Style.FILL
            val p = android.graphics.Path()
            p.moveTo(0f, 0f)
            p.arcTo(android.graphics.RectF(-r, -r, r, r), a0 * 180f / Math.PI.toFloat(), (a1 - a0) * 180f / Math.PI.toFloat())
            p.close()
            c.canvas.drawPath(p, c.paint)
        }
        c.restoreGState()
    }
}

// ================================================================ panels

fun EditorViewController.refreshPanel() {
    panelList.clear()
    rows.clear()
    if (panel != P_GRAPH) { graphOverlayView?.removeFromSuperview(); graphOverlayView = null }
    if (panel == P_NONE) return
    if (panel == P_MEDIA) buildMedia()
    else if (panel == P_SHAPES) buildShapes()
    else {
        val l = selected() ?: run { closePanel(); return }
        when (panel) {
            P_EDIT -> buildEdit(l)
            P_XFORM -> buildXform(l)
            P_FX -> buildFx(l)
            P_BLEND -> buildBlend(l)
            P_SPEED -> buildSpeed(l)
            P_GRAPH -> buildGraph(l)
            P_PUPPET -> buildPuppet(l)
            P_RIGANIM -> buildRigAnim(l)
        }
    }
    syncRows()
}

fun EditorViewController.addRow(parent: UiView, l: Layer, d: PropDef, label: String? = null) {
    if (d.options != null) { addOptionRow(parent, l, d); return }
    val tr = l.track(d.key)
    val s = RulerSlider()
    s.label = label ?: d.label
    s.lo = d.min; s.hi = d.max; s.dec = d.dec
    s.infinite = d.inf
    s.span = if (d.span > 0f) d.span else 1f
    s.value = tr.eval(l.editTime(d.key, Editor.time))
    s.onBeginDrag = {
        pushUndo()
        selKey = d.key
        syncRows(s)
    }
    s.onChange = { v ->
        if (d.key == "anchorX" || d.key == "anchorY") {
            // move only the pivot: shift x/y so the media stays put
            val t = l.editTime("anchorX", Editor.time)
            val ax = if (d.key == "anchorX") v else l.p("anchorX", t)
            val ay = if (d.key == "anchorY") v else l.p("anchorY", t)
            setAnchorKeepVisual(l, ax, ay)
        } else {
            tr.set(l.editTime(d.key, Editor.time), v, autoKeyOn)
        }
        syncRows(s)
        render()
    }
    s.onLabelTap = {
        selKey = d.key
        syncRows()
        // tapping a parameter name opens its graph
        if (tr.keys.count() >= 2) {
            graphProp = d.key; graphKey = 0
            openPanel(P_GRAPH)
        } else {
            toast("Add 2 keyframes to ${d.label} to edit its graph")
        }
    }
    s.onKeyTap = {
        selKey = d.key
        pushUndo()
        tr.toggleKey(l.editTime(d.key, Editor.time))
        syncRows(); render()
    }
    put(parent, s, 60f)
    rows.add(EditorViewController.Row(s, d, l))
}

fun EditorViewController.addOptionRow(parent: UiView, l: Layer, d: PropDef) {
    val tr = l.track(d.key)
    val opts = d.options ?: emptyList()
    if (opts.count() == 2) {
        val sw = SwitchRow()
        sw.label = d.label
        sw.on = tr.base >= 0.5f
        sw.captionOff = opts[0]; sw.captionOn = opts[1]
        sw.onToggle = { v ->
            pushUndo()
            tr.set(l.editTime(d.key, Editor.time), if (v) 1f else 0f, autoKeyOn)
            render()
        }
        put(parent, sw, 52f)
        return
    }
    text(parent, d.label, C.TEXT, 14f, true)
    val cr = chipRow(opts, ktInt(tr.base)) { i ->
        pushUndo()
        tr.set(l.editTime(d.key, Editor.time), i.toFloat(), autoKeyOn)
        refreshPanel()
        render()
    }
    (parent as? EVStack)?.add(cr) ?: parent.addSubview(cr)
}

/** Numeric parameter that owns a keyframe track (key = unique id), shown as a normal row. */
fun EditorViewController.addKeyedRow(parent: UiView, l: Layer, key: String, label: String,
                                     lo: Float, hi: Float, def: Float, dec: Int, stored: Float) {
    val d = PropDef(key, label, lo, hi, def, dec)
    Registry.dyn[key] = d
    if (l.props[key] == null) l.props[key] = Track(stored)
    addRow(parent, l, d)
}

/** Colour with a keyframe button: tap it to key the colour at the playhead. */
fun EditorViewController.addKeyedColor(parent: UiView, l: Layer, name: String, field: Int,
                                       set: (Int) -> Unit) {
    val base = "tc_" + name
    val sfx = listOf("_r", "_g", "_b", "_a")
    val animated = sfx.any { !(l.props[base + it]?.keys?.isEmpty() ?: true) }
    val cur = TextRaster.col(l, name, field, Editor.time)
    fun write(c: Int, key: Boolean) {
        val vals = listOf(colorRed(c), colorGreen(c), colorBlue(c), colorAlpha(c)).map { it / 255f }
        for ((i, sf) in sfx.withIndex()) {
            val tr = l.track(base + sf)
            if (key) {
                val tt = Editor.time
                if (tr.keyAt(tt) == null) tr.toggleKey(tt)
                tr.set(tt, vals[i], true)
            } else {
                tr.base = vals[i]
            }
        }
    }
    addColorRow(parent, cur) { c ->
        pushUndo()
        set(c)
        if (l.props[base + "_r"] != null) write(c, animated)
        render()
    }
    put(parent, pill(if (animated) "Key color here ($name)" else "Keyframe this color", "diamond") {
        pushUndo()
        write(cur, true)
        set(cur)
        refreshPanel(); render()
    }, 38f)
    if (animated) {
        put(parent, pill("Remove color keyframes", "close") {
            pushUndo()
            for (sf in sfx) l.props.remove(base + sf)
            set(cur)
            refreshPanel(); render()
        }, 38f)
    }
}

fun EditorViewController.addPlain(parent: UiView, label: String, lo: Float, hi: Float, v: Float,
                                  dec: Int, onChange: (Float) -> Unit) {
    val s = RulerSlider()
    s.label = label; s.lo = lo; s.hi = hi; s.value = v; s.dec = dec; s.canKey = false
    s.onBeginDrag = { pushUndo() }
    s.onChange = onChange
    put(parent, s, 60f)
}

fun EditorViewController.syncRows(except: RulerSlider? = null) {
    for (r in rows) {
        val tr = r.layer.track(r.d.key)
        val t = r.layer.editTime(r.d.key, Editor.time)
        if (r.slider !== except) r.slider.value = tr.eval(t)
        r.slider.hasKey = tr.keyAt(t) != null
        r.slider.hasAnim = tr.keys.isNotEmpty()
        r.slider.hasExpr = tr.exprActive()
        r.slider.rowSelected = r.d.key == selKey
        r.slider.setNeedsDisplay()
    }
    diamondSide.set("diamond_f",
        if (rows.any { it.d.key == selKey && it.slider.hasKey }) C.GREEN
        else (if (rows.any { it.d.key == selKey }) C.TEXT else C.DIM))
}

/** ⌘ icon: opens the expression editor for the parameter that was tapped last. */
fun EditorViewController.exprSelected() {
    val r = rows.firstOrNull { it.d.key == selKey } ?: run {
        toast("Tap a parameter first, then tap the ⌘ icon")
        return
    }
    showExpression(r.layer, r.d)
}

/** Adds or removes a keyframe on the parameter that was tapped last. */
fun EditorViewController.keySelected() {
    val r = rows.firstOrNull { it.d.key == selKey } ?: run {
        toast("Tap a parameter first, then tap the keyframe button")
        return
    }
    pushUndo()
    r.layer.track(r.d.key).toggleKey(r.layer.editTime(r.d.key, Editor.time))
    syncRows(); render()
}

/** Full color picker: saturation, hue, opacity, hex and an eyedropper that samples the preview. */
fun EditorViewController.showColorPicker(initial: Int, onPick: (Int) -> Unit) {
    val box = vStack()
    val cp = ColorPickerView()
    cp.setColor(initial)
    put(box, cp, 250f, 0f, 0f)
    val row = hRow()
    val hex = makeField("")
    hex.font = monoFont(14f)
    hex.text = String.format("%08X", initial.toLong() and 0xFFFFFFFFL)
    hex.placeholder = "#RRGGBB"
    val sw = UiView(appContext!!)
    sw.setBackgroundColor(initial)
    val lock = booleanArrayOf(false)
    cp.onChange = { c ->
        sw.setBackgroundColor(c)
        lock[0] = true
        hex.text = String.format("%08X", c.toLong() and 0xFFFFFFFFL)
        lock[0] = false
        onPick(c)
    }
    bind(hex) { s ->
        if (lock[0]) return@bind
        var t = s.trim()
        if (t.startsWith("#")) t = t.removePrefix("#")
        var v: Int? = null
        if (t.length == 6) {
            val u = t.toLongOrNull(16)
            if (u != null) v = (0xFF000000L or u).toInt()
        } else if (t.length == 8) {
            val u = t.toLongOrNull(16)
            if (u != null) v = u.toInt()
        }
        if (v != null) {
            cp.setColor(v!!)
            sw.setBackgroundColor(v)
            onPick(v)
        }
    }
    row.add(EBox(hex, 0f, 40f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    row.add(EBox(sw, 52f, 40f, 0f, 0f, 0f, 0f))
    box.add(row)
    val ref = arrayOfNulls<Dlg>(1)
    put(box, pill("Pen: pick a color from the preview", "pipette") {
        ref[0]?.dismiss()
        startEyedropper { c ->
            showColorPicker(c, onPick)
            onPick(c)
        }
    }, 44f, 6f, 6f)
    pushUndo()
    ref[0] = Dlg(this).setTitle("Color").setView(box).setPositiveButton("Done") { _, _ ->
        // never leave the eyedropper armed after the dialog is gone
        overlay.pick = null
    }.show()
}

fun EditorViewController.startEyedropper(cb: (Int) -> Unit) {
    toast("Tap the preview to pick a color")
    overlay.pick = pick@{ x, y ->
        overlay.pick = null   // one shot
        val w = preview.rectWidth().toInt()
        val h = preview.rectHeight().toInt()
        if (w <= 0 || h <= 0) return@pick
        // PORT NOTE: PixelCopy.request → drawHierarchy snapshot read from a 1x1 read.
        try {
            val img = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            preview.draw(Canvas(img))
            val ix = x.toInt().coerceIn(0, w - 1)
            val iy = y.toInt().coerceIn(0, h - 1)
            val p = img.getPixel(ix, iy)
            img.recycle()
            cb(argbColor(255, android.graphics.Color.red(p), android.graphics.Color.green(p), android.graphics.Color.blue(p)))
        } catch (_: Exception) {
            toast("Eyedropper is not available here")
        }
    }
    // and a timeout: if the user never taps the preview, stand down
    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ overlay.pick = null }, 10000)
}

fun EditorViewController.colorRow(cur: Int, onPick: (Int) -> Unit): UiView {
    val colors = listOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt(),
        0xFFF44336.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(), 0xFF22C55E.toInt(),
        0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFF7C4DFF.toInt(), 0xFFFF4081.toInt())
    val row = hRow()
    val now = TapView()
    now.setBackgroundColor(cur)
    now.onClick = { showColorPicker(cur, onPick) }
    row.add(EBox(now, 44f, 36f, 4f, 6f, 10f, 6f))
    for (col in colors) {
        val v = TapView()
        v.setBackgroundColor(col)
        v.onClick = { onPick(col) }
        row.add(EBox(v, 32f, 32f, 3f, 6f, 3f, 6f))
    }
    val more = RainbowCircleView()
    more.onClick = { showColorPicker(cur, onPick) }
    row.add(EBox(more, 36f, 36f, 8f, 4f, 4f, 4f))
    val sv = TopIconScroll()
    sv.showsHorizontalScrollIndicator = false
    sv.content = row
    return sv
}

fun EditorViewController.addColorRow(parent: UiView, cur: Int, onPick: (Int) -> Unit) {
    (parent as? EVStack)?.add(EBox(colorRow(cur, onPick), 0f, 48f, 0f, 0f, 0f, 0f))
}

fun EditorViewController.setColorParam(l: Layer, cp: com.saiki.motion.core.ColorParam, col: Int) {
    val vals = listOf("_r" to colorRed(col), "_g" to colorGreen(col),
                      "_b" to colorBlue(col), "_a" to colorAlpha(col))
    for ((suffix, v) in vals) {
        val tr = l.track(cp.key + suffix)
        tr.keys.clear()
        tr.base = v / 255f
    }
}

fun EditorViewController.addColorParam(parent: UiView, l: Layer, cp: com.saiki.motion.core.ColorParam) {
    fun cur(): Int {
        // no track yet → show the effect's real default colour (it used to read as black)
        val d = cp.def.toLong() and 0xFFFFFFFFL
        fun comp(suffix: String, shift: Long): Int {
            val tr = l.props[cp.key + suffix]
            if (tr != null) return ktInt(tr.eval(Editor.time) * 255)
            return ((d shr shift.toInt()) and 0xFFL).toInt()
        }
        return argbColor(comp("_a", 24), comp("_r", 16), comp("_g", 8), comp("_b", 0))
    }
    val row = hRow()
    row.setBackgroundColor(C.CARD)
    val tv = UILabel(com.saiki.motion.uikit.appContext!!)
    tv.text = cp.label
    tv.textColor = argbToUIColor(C.TEXT)
    tv.font = boldFont(15f)
    row.add(growBox(tv))
    val sw = TapView()
    sw.setBackgroundColor(cur())
    sw.onClick = {
        showColorPicker(cur()) { col ->
            pushUndo()
            setColorParam(l, cp, col)
            sw.setBackgroundColor(col)
            render()
        }
    }
    row.add(EBox(sw, 72f, 34f, 0f, 0f, 0f, 0f))
    put(parent, row, 52f)
}

// ---------------------------------------------------------------- media + shapes

fun EditorViewController.buildMedia() {
    val p = panelList
    text(p, "Media", C.TEXT, 16f, true)
    // iOS embeds PHPickerViewController here (embedPhotoPicker); the Android photo library is
    // reached through the pickers (pickMedia) — PORT NOTE.
    val browser = MediaBrowserView(4, true)
    browser.onPick = { a -> importPHAsset(a) }
    browser.onPickMany = { l -> importPHAssets(l) }
    browser.onExpand = { openFullMediaBrowser() }
    put(p, browser, 120f)
    put(p, pill("Import video from Files", "import") { pickFile(R_VIDEO) }, 44f)
    put(p, pill("Import image from Files", "import") { pickFile(R_IMAGE) }, 44f)
    put(p, pill("Import audio", "import") { showAudioLibrary() }, 44f)
    put(p, pill("Beat markers from an audio file", "graph") { pickFile(R_BEAT) }, 44f)
    var files = Projects.mediaDir().listFiles()?.toList() ?: emptyList()
    files = files.sortedByDescending { it.lastModified() }
    files = files.take(12)
    if (files.isNotEmpty()) text(p, "Recent media", C.DIM, 13f)
    for (f in files) {
        val ext = f.extension.lowercase()
        val type: LayerType = if (ext == "glb" || ext == "vdb") LayerType.MODEL
            else if (listOf("mp4", "mov", "mkv", "webm", "3gp", "m4v").contains(ext)) LayerType.VIDEO
            else if (listOf("m4a", "mp3", "aac", "wav", "ogg", "flac").contains(ext)) LayerType.AUDIO
            else LayerType.IMAGE
        val ic = if (type == LayerType.VIDEO) "media" else (if (type == LayerType.MODEL) "cube" else "media")
        put(p, pill(afterFirst(f.name, '_'), ic) {
            addMedia(f.path, type)
        }, 40f)
    }
}

fun EditorViewController.buildShapes() {
    text(panelList, "Add shape", C.TEXT, 16f, true)
    panelList.add(shapeGrid(null) { k ->
        val l = addLayer(LayerType.SHAPE)
        l.shape = k
        render()
    })
}

// ---------------------------------------------------------------- edit

fun EditorViewController.buildEdit(l: Layer) {
    val p = panelList
    when (l.type) {
        LayerType.TEXT -> buildText(p, l)
        LayerType.SHAPE -> {
            text(p, "Shape", C.TEXT, 16f, true)
            if (l.shape == ShapeKind.PATH) {
                p.add(EBox(pill("Edit path with Vector Pen") { openPenEditor(l) }, 0f, 44f, 0f, 3f, 0f, 3f))
            }
            p.add(shapeGrid(l.shape) { k ->
                pushUndo()
                l.shape = k
                refreshPanel(); render()
            })
            if (l.shape.usesRound || l.shape == ShapeKind.ROUND) addRow(p, l, Defs.shapeRound)
            if (l.shape.usesThick) addRow(p, l, Defs.shapeThick)
            text(p, "Color", C.DIM)
            addKeyedColor(p, l, "color", l.color) { l.color = it }
            if (l.shape != ShapeKind.PATH) {
                val names = listOf("Gradient: Off", "Gradient: Linear", "Gradient: Radial")
                put(p, pill(names[l.gradMode % 3]) {
                    pushUndo()
                    l.gradMode = (l.gradMode + 1) % 3
                    refreshPanel(); render(); overlay.setNeedsDisplay()
                }, 38f)
                if (l.gradMode > 0) {
                    text(p, "End color (drag the knobs on the viewport: 1 = start, 2 = end)", C.DIM, 12f)
                    addColorRow(p, l.color2) { c ->
                        pushUndo(); l.color2 = c; render()
                    }
                }
            }
        }
        LayerType.GROUP -> {
            text(p, "Group", C.TEXT, 16f, true)
            text(p, "Put layers inside with Parent in their Transform panel. Tap the ^ arrow in the timeline to open or close the group. Groups can have effects, and 3D layers inside a group keep their 3D look.", C.DIM, 12f)
            text(p, "Pre-render", C.GREEN, 13f, true)
            val prs = SwitchRow(); prs.label = "Pre-render this group (bake to frames)"; prs.on = l.prerender && PreRender.enabled
            prs.onToggle = { v ->
                if (v != l.prerender) togglePreRender(l)
                refreshPanel()
            }
            put(p, prs, 46f)
            text(p, if (PreRender.enabled) "Bakes the group to frames so playback and render are fast; any change re-bakes it. The group becomes a flat plane, like an After Effects pre-comp, and a camera inside it drives only its own layers." else "Pre-render is switched off in Scene setup → Pre-render.", C.DIM, 12f)
            text(p, "Mask", C.GREEN, 13f, true)
            text(p, "The top layer inside the group masks the layers beneath it.", C.DIM, 12f)
            p.add(EBox(pill("Draw mask with Vector Pen", "layers") {
                if (l.mask == 0) { pushUndo(); l.mask = 1 }
                openPenEditor(group = l)
            }, 0f, 44f, 0f, 3f, 0f, 3f))
            p.add(chipRow(listOf("None", "Alpha", "Inverted alpha", "Luma", "Inverted luma"), l.mask) { i ->
                pushUndo()
                l.mask = i
                refreshPanel(); render()
            })
        }
        LayerType.AUDIO -> {
            text(p, "Audio", C.TEXT, 16f, true)
            text(p, l.name)
            addRow(p, l, Defs.audio[0])
            put(p, pill("Beat markers from this audio", "graph") {
                beatsFrom(l.imagePath ?: "", l.start)
            }, 42f)
            text(p, "Plays during preview and is mixed into the render (the first audio layer; AAC or MP3 files work best).", C.DIM, 12f)
            text(p, "Audio effects: open Effects → Browse → Audio. They work like any other effect (eye button, drag handle).", C.DIM, 12f)
        }
        LayerType.FLARE -> {
            text(p, "Optical Flare", C.TEXT, 16f, true)
            put(p, pill("Customize", "edit", C.GREEN, C.ONDARK) {
                openFlareEditor(l)
            }, 48f)
            for (d in Defs.flare) addRow(p, l, d)
            text(p, "Move the light with the Transform panel or drag it in the preview. Turn the 3D cube on and it follows a camera and shrinks with distance.", C.DIM, 12f)
        }
        LayerType.ADJUST -> {
            text(p, "Adjustment layer", C.TEXT, 16f, true)
            text(p, "Add effects to it in the Effects panel. They apply to everything below it for as long as the layer lasts.")
        }
        LayerType.CAMERA -> {
            text(p, "Camera", C.TEXT, 16f, true)
            addRow(p, l, Defs.camera[0])
            val rtSw = SwitchRow(); rtSw.label = "Ray tracing"; rtSw.on = l.rtOn
            rtSw.onToggle = { v -> pushUndo(); l.rtOn = v; refreshPanel(); render() }
            put(p, rtSw, 46f)
            if (l.rtOn) {
                val ri = RulerSlider()
                ri.label = "Ray tracing intensity"; ri.lo = 0f; ri.hi = 1f; ri.dec = 2; ri.value = l.rtInt
                ri.onBeginDrag = { pushUndo() }
                ri.onChange = { v -> l.rtInt = v; render() }
                put(p, ri, 90f)
                val rr = RulerSlider()
                rr.label = "Occlusion radius"; rr.lo = 0.05f; rr.hi = 2f; rr.dec = 2; rr.value = l.rtRad
                rr.onBeginDrag = { pushUndo() }
                rr.onChange = { v -> l.rtRad = v; render() }
                put(p, rr, 90f)
                text(p, "Traced shadows and ambient occlusion (needs an iPhone with ray tracing, A13 or newer).", C.DIM, 12f)
            }
            text(p, "Position and rotate it in Transform. It controls every layer whose 3D cube is on.")
        }
        LayerType.NULL -> {
            text(p, "Null object", C.TEXT, 16f, true)
            text(p, "An invisible layer. Turn its 3D cube on, then pick it as Parent in other layers' Transform panel.")
        }
        else -> {
            text(p, cap(l.type.name.lowercase()), C.TEXT, 16f, true)
            text(p, l.name)
            if (l.type == LayerType.VIDEO) {
                text(p, "Length: " + String.format("%.1f", l.srcDur) + " s. Decoded with the system decoder.")
                addRow(p, l, Defs.audio[0])      // volume: slider + keyframes, same as audio layers
                put(p, pill("Extract audio", "export") { extractAudio(l) }, 42f)
                put(p, pill("Beat markers from this video", "graph") {
                    beatsFrom(l.imagePath ?: "", l.start)
                }, 42f)
            }
            if (l.type == LayerType.IMAGE) {
                put(p, pill("Direct Drawing Editor", "edit", C.GREEN, C.ONDARK) { openDirectDrawing(l) }, 46f)
                text(p, "Draw on this picture, press Save, and it replaces the image here. Position, effects and animation stay as they are.", C.DIM, 12f)
            }
            if (l.type == LayerType.MODEL && l.xf("mist", 0f) > 0.5f) buildMistPanel(p, l)
            if (l.type == LayerType.MODEL && l.xf("cloud", 0f) > 0.5f) buildCloudPanel(p, l)
            if (l.type == LayerType.MODEL && l.xf("cloud", 0f) < 0.5f && l.xf("mist", 0f) < 0.5f &&
                (l.imagePath ?: "").lowercase().endsWith(".vdb")) buildVdbPanel(p, l)
            if (l.type == LayerType.MODEL && !(l.imagePath ?: "").lowercase().endsWith(".vdb")) buildModelPanel(p, l)
            if (l.type == LayerType.MODEL && (l.xf("pbrExtra", 0f) > 0.5f || l.xf("water", 0f) > 0.5f)) buildSurfacePanel(p, l)
            if (l.type == LayerType.MODEL) { buildPointMap(p, l); buildPbr(p, l) }
            if (l.type == LayerType.MODEL) {
                text(p, "Static mesh with PBR materials, textures and vertex colours (.glb / .gltf / .fbx / .obj). Node transforms are baked on load; the model is centred and drawn with a real depth buffer.")
            }
        }
    }
}

private fun EditorViewController.xs(parent: UiView, label: String, lo: Float, hi: Float, key: String, def: Float, dec: Int = 2, l: Layer) {
    val r = RulerSlider(); r.label = label; r.lo = lo; r.hi = hi; r.dec = dec; r.value = l.xf(key, def)
    r.onBeginDrag = { pushUndo() }
    r.onChange = { v -> l.xset(key, v); render() }
    put(parent, r, 90f)
}

private fun EditorViewController.sw(parent: UiView, label: String, key: String, def: Float = 0f, l: Layer) {
    val s = SwitchRow(); s.label = label; s.on = l.xf(key, def) > 0.5f
    s.onToggle = { v -> pushUndo(); l.xset(key, if (v) 1f else 0f); render() }
    put(parent, s, 46f)
}

/** Mist subsection (iOS buildEdit MODEL mist branch). */
private fun EditorViewController.buildMistPanel(p: EVStack, l: Layer) {
    val kind = ktInt(l.xf("mKind", 0f))
    val dd = com.saiki.motion.core.MistSettings.defaults[kind] ?: com.saiki.motion.core.MistSettings.defaults[0]!!
    text(p, "Mist", C.TEXT, 14f, true)
    text(p, "Type", C.DIM, 13f)
    p.add(chipRow(com.saiki.motion.core.MistGen.kinds, kind) { i ->
        pushUndo(); l.xset("mKind", i.toFloat())
        for ((j, k) in com.saiki.motion.core.MistSettings.shapeKeys.withIndex()) {
            l.xset(k, (com.saiki.motion.core.MistSettings.defaults[i] ?: com.saiki.motion.core.MistSettings.defaults[0]!!)[j])
        }
        com.saiki.motion.core.MistSettings.rebuildSoon(l) { refreshPanel(); render() }
    })
    put(p, pill("New random shape", "export") {
        pushUndo(); l.xset("mSeed", (nowMs() % 9973).toFloat()); com.saiki.motion.core.MistSettings.rebuildSoon(l) { render() }
    }, 42f)
    text(p, "Look (sets colour and brightness)", C.DIM, 13f)
    p.add(chipRow(com.saiki.motion.core.MistSettings.looks, -1) { i ->
        pushUndo(); com.saiki.motion.core.MistSettings.applyLook(l, i); refreshPanel(); render()
    })
    text(p, "Light and colour", C.TEXT, 13f, true)
    fun look(label: String, lo: Float, hi: Float, get: () -> Float, set: (Float) -> Unit, dec: Int = 2) {
        val r = RulerSlider(); r.label = label; r.lo = lo; r.hi = hi; r.dec = dec; r.value = get()
        r.onBeginDrag = { pushUndo() }
        r.onChange = { v -> set(v); render() }
        put(p, r, 90f)
    }
    look("Density", 0.05f, 8f, { l.vdbDens }, { l.vdbDens = it })
    look("Brightness", 0f, 4f, { l.vdbBright }, { l.vdbBright = it })
    look("Shadow depth (self-shadowing)", 0f, 3f, { l.xf("vdbShadow", 0.6f) }, { l.xset("vdbShadow", it) })
    look("Softness / contrast", 0.2f, 3f, { l.xf("vdbContrast", 0.8f) }, { l.xset("vdbContrast", it) })
    text(p, "Colour", C.DIM, 13f)
    p.add(EBox(colorRow(l.vdbTint) { c -> pushUndo(); l.vdbTint = c; render() }, 0f, 48f, 0f, 0f, 0f, 0f))
    val ev = SwitchRow(); ev.label = "Light from environment (sky)"; ev.on = l.vdbEnv
    ev.onToggle = { v -> pushUndo(); l.vdbEnv = v; l.vdbSurround = v; refreshPanel(); render() }
    put(p, ev, 46f)
    val oc = SwitchRow(); oc.label = "Hide behind models"; oc.on = l.occlude
    oc.onToggle = { v -> pushUndo(); l.occlude = v; render() }
    put(p, oc, 46f)
    text(p, "Shape", C.TEXT, 13f, true)
    val sk = com.saiki.motion.core.MistSettings.shapeKeys
    val defs = com.saiki.motion.core.MistSettings.defaults
    xs(p, "Layer thickness", 0.04f, 1f, sk[0], defs[kind]!![0], 2, l)
    xs(p, "Ground hugging (denser low)", 0f, 6f, sk[1], defs[kind]!![1], 2, l)
    xs(p, "Coverage (clear gaps to solid)", 0f, 1f, sk[2], defs[kind]!![2], 2, l)
    xs(p, "Patch size (higher = smaller)", 0.2f, 4f, sk[3], defs[kind]!![3], 2, l)
    xs(p, "Wisp detail", 0f, 1f, sk[4], defs[kind]!![4], 2, l)
    xs(p, "Swirl / turbulence", 0f, 1f, sk[5], defs[kind]!![5], 2, l)
    xs(p, "Edge softness", 0.03f, 0.5f, sk[6], defs[kind]!![6], 2, l)
    xs(p, "Wind streaks", 0f, 1f, sk[7], defs[kind]!![7], 2, l)
    xs(p, "Wind direction", 0f, 360f, sk[8], defs[kind]!![8], 0, l)
    text(p, "Quality", C.TEXT, 13f, true)
    look("Steps (lower = faster)", 16f, 96f, { l.xf("vdbSteps", 48f) }, { l.xset("vdbSteps", it) }, 0)
    text(p, "Scale the layer to cover your scene and place it at ground level. Point lights placed inside glow through the mist.", C.DIM, 12f)
}


/** Clouds subsection. */
private fun EditorViewController.buildCloudPanel(p: EVStack, l: Layer) {
    fun cs(label: String, lo: Float, hi: Float, key: String, def: Float, dec: Int = 2) {
        val r = RulerSlider(); r.label = label; r.lo = lo; r.hi = hi; r.dec = dec; r.value = l.xf(key, def)
        r.onBeginDrag = { pushUndo() }
        r.onChange = { v -> l.xset(key, v); CloudSettings.apply(l); render() }
        put(p, r, 90f)
    }
    fun csw(label: String, key: String, def: Float, rebuild: Boolean) {
        val s = SwitchRow(); s.label = label; s.on = l.xf(key, def) > 0.5f
        s.onToggle = { v ->
            pushUndo(); l.xset(key, if (v) 1f else 0f)
            if (rebuild) CloudSettings.rebuild(l)
            CloudSettings.apply(l); refreshPanel(); render()
        }
        put(p, s, 46f)
    }
    text(p, "Clouds", C.TEXT, 14f, true)
    text(p, "Type", C.DIM, 13f)
    p.add(chipRow(com.saiki.motion.core.CloudGen.types, ktInt(l.xf("cType", 0f))) { i ->
        pushUndo(); l.xset("cType", i.toFloat()); CloudSettings.rebuild(l); refreshPanel(); render()
    })
    put(p, pill("New random shape", "export") {
        pushUndo(); l.xset("cSeed", (nowMs() % 9973).toFloat()); CloudSettings.rebuild(l); render()
    }, 42f)
    csw("Procedural scatter (many clouds)", "cScatter", 0f, true)
    cs("Day  ←→  Night", 0f, 1f, "cDay", 0f)
    cs("Density", 0.5f, 8f, "cDens", 3f)
    cs("Brightness", 0.2f, 3f, "cBright", 1f)
    text(p, "Tint", C.DIM, 13f)
    p.add(EBox(colorRow((0xFF000000.toInt()) or (l.xf("cTint", 16777215f).toInt() and 0xFFFFFF)) { c ->
        pushUndo(); l.xset("cTint", (c.toLong() and 0xFFFFFF).toFloat()); CloudSettings.apply(l); render()
    }, 0f, 48f, 0f, 0f, 0f, 0f))
    text(p, "Edge colour", C.DIM, 13f)
    p.add(EBox(colorRow((0xFF000000.toInt()) or (l.xf("cEdgeCol", 16777215f).toInt() and 0xFFFFFF)) { c ->
        pushUndo(); l.xset("cEdgeCol", (c.toLong() and 0xFFFFFF).toFloat()); CloudSettings.apply(l); render()
    }, 0f, 48f, 0f, 0f, 0f, 0f))
    cs("Edge amount", 0f, 1f, "cEdge", 0.4f)
    cs("Shadow strength", 0f, 3f, "vdbShadow", 1f)
    cs("Contrast", 0.3f, 3f, "vdbContrast", 1f)
    cs("Quality (steps, lower = faster)", 16f, 96f, "vdbSteps", 30f, 0)
    csw("Light from environment", "cEnv", 1f, false)
    if (l.vdbEnv) {
        put(p, pill(if (l.vdbEnvPath == null) "Use own environment image / HDR" else "Change environment image", "export") {
            pickFile(R_VDBENV)
        }, 42f)
    }
}

/** VDB volume subsection. */
private fun EditorViewController.buildVdbPanel(p: EVStack, l: Layer) {
    text(p, "Volume (VDB)", C.TEXT, 14f, true)
    xs(p, "Density", 0f, 8f, "vdbDensX", 1f, 2, l) // placeholder replaced below
    val ds = RulerSlider()
    ds.label = "Density"; ds.lo = 0f; ds.hi = 8f; ds.dec = 2
    ds.value = l.vdbDens
    ds.onBeginDrag = { pushUndo() }
    ds.onChange = { v -> l.vdbDens = v; render() }
    put(p, ds, 90f)
    text(p, "Tint", C.DIM, 13f)
    p.add(EBox(colorRow(l.vdbTint) { c -> pushUndo(); l.vdbTint = c; render() }, 0f, 48f, 0f, 0f, 0f, 0f))
    val bs = RulerSlider()
    bs.label = "Brightness"; bs.lo = 0f; bs.hi = 4f; bs.dec = 2
    bs.value = l.vdbBright
    bs.onBeginDrag = { pushUndo() }
    bs.onChange = { v -> l.vdbBright = v; render() }
    put(p, bs, 90f)
    val ev = SwitchRow(); ev.label = "Enable environment"; ev.on = l.vdbEnv
    ev.onToggle = { v -> pushUndo(); l.vdbEnv = v; refreshPanel(); render() }
    put(p, ev, 46f)
    if (l.vdbEnv) {
        put(p, pill(if (l.vdbEnvPath == null) "Import image / HDR / EXR" else "Change environment image", "export") {
            pickFile(R_VDBENV)
        }, 42f)
        val sv = SwitchRow(); sv.label = "Use surroundings (no image)"; sv.on = l.vdbSurround
        sv.onToggle = { v -> pushUndo(); l.vdbSurround = v; render() }
        put(p, sv, 46f)
    }
    val oc = SwitchRow(); oc.label = "Occlusion (hidden behind models)"; oc.on = l.occlude
    oc.onToggle = { v -> pushUndo(); l.occlude = v; render() }
    put(p, oc, 46f)
}

/** 3D settings subsection. */
private fun EditorViewController.buildModelPanel(p: EVStack, l: Layer) {
    text(p, "3D settings", C.TEXT, 14f, true)
    put(p, pill("Texture (image for this model)", "export") {
        pickFile(R_MODELTEX)
    }, 42f)
    val rows = listOf(Triple("Environment light", l.m3Env, { v: Boolean -> l.m3Env = v }),
                      Triple("Metallic reflectivity", l.m3Metal, { v: Boolean -> l.m3Metal = v }),
                      Triple("Ambient occlusion (texture)", l.m3Ao, { v: Boolean -> l.m3Ao = v }))
    for ((name, on, set) in rows) {
        val r = SwitchRow(); r.label = name; r.on = on
        r.onToggle = { v -> pushUndo(); set(v); render() }
        put(p, r, 46f)
    }
    val rtSw = SwitchRow(); rtSw.label = "Ray tracing"; rtSw.on = l.rtOn
    rtSw.onToggle = { v -> pushUndo(); l.rtOn = v; refreshPanel(); render() }
    put(p, rtSw, 46f)
    if (l.rtOn) {
        val ri = RulerSlider()
        ri.label = "Ray tracing intensity"; ri.lo = 0f; ri.hi = 1f; ri.dec = 2; ri.value = l.rtInt
        ri.onBeginDrag = { pushUndo() }
        ri.onChange = { v -> l.rtInt = v; render() }
        put(p, ri, 90f)
        val rr = RulerSlider()
        rr.label = "Occlusion radius"; rr.lo = 0.05f; rr.hi = 2f; rr.dec = 2; rr.value = l.rtRad
        rr.onBeginDrag = { pushUndo() }
        rr.onChange = { v -> l.rtRad = v; render() }
        put(p, rr, 90f)
        text(p, "Traced shadows and ambient occlusion (needs an iPhone with ray tracing, A13 or newer).", C.DIM, 12f)
    }
    p.add(chipRow(listOf("Final", "Base", "Rough", "Metal", "Occl", "Emis"), l.m3View) { i ->
        pushUndo(); l.m3View = i; refreshPanel(); render()
    })
    text(p, "Chips show the PBR textures: base colour, roughness, metalness, occlusion, emissive.", C.DIM, 12f)
}

/** Water / PBR surface subsection. */
private fun EditorViewController.buildSurfacePanel(p: EVStack, l: Layer) {
    fun xs2(label: String, lo: Float, hi: Float, key: String, def: Float) {
        val r = RulerSlider(); r.label = label; r.lo = lo; r.hi = hi; r.dec = 2; r.value = l.xf(key, def)
        r.onBeginDrag = { pushUndo() }
        r.onChange = { v -> l.xset(key, v); render() }
        put(p, r, 90f)
    }
    if (l.xf("water", 0f) > 0.5f) {
        text(p, "Water", C.TEXT, 14f, true)
        text(p, "Type (sets everything below, then tweak)", C.DIM, 12f)
        p.add(chipRow(com.saiki.motion.core.WaterPresets.names, ktInt(l.xf("wType", 0f))) { i ->
            pushUndo(); l.xset("wType", i.toFloat()); com.saiki.motion.core.WaterPresets.apply(i, l); refreshPanel(); render()
        })
        text(p, "Waves", C.TEXT, 13f, true)
        xs2("Swell height (far, long waves)", 0f, 2f, "wSwell", 0.8f); xs2("Swell length", 0.05f, 0.5f, "wSwellLen", 0.15f)
        xs2("Wave height", 0f, 0.25f, "wAmp", 0.03f); xs2("Wave size (higher = smaller waves)", 0.5f, 30f, "wFreq", 6f)
        xs2("Wave speed", 0f, 4f, "wSpeed", 1f); xs2("Choppiness", 0f, 1f, "wChop", 0.5f)
        xs2("Foam", 0f, 1f, "wFoam", 0.5f); xs2("Whitecaps (patches)", 0f, 1f, "wCaps", 0.5f)
        text(p, "Water body", C.TEXT, 13f, true)
        xs2("Depth (shallow to deep)", 0f, 1f, "wDepth", 0.5f)
        xs2("Clarity (murky to crystal)", 0f, 1f, "wClar", 0.6f); xs2("Turbidity", 0f, 1f, "wTurb", 0.15f)
        xs2("Refraction", 0f, 1f, "wRefr", 0.5f); xs2("Subsurface glow", 0f, 1.5f, "wSss", 0.5f)
        xs2("Sun / light glints", 0f, 2f, "wGlint", 1f); xs2("Ripple detail", 0f, 1.5f, "wDetail", 0.6f)
        xs2("Wave variation (anti-repeat)", 0f, 1f, "wVar", 0.7f); xs2("Flow direction", 0f, 360f, "wDir", 30f)
        xs2("Seabed when nothing is below", 0f, 1f, "wSeabed", 0.7f)
        text(p, "Water colour", C.TEXT, 13f, true)
        val colSw = SwitchRow(); colSw.label = "Custom colours + gradient"; colSw.on = l.xf("wColOn", 0f) > 0.5f
        colSw.onToggle = { v -> pushUndo(); l.xset("wColOn", if (v) 1f else 0f); refreshPanel(); render() }
        put(p, colSw, 46f)
        if (l.xf("wColOn", 0f) > 0.5f) {
            val n3 = l.xf("wColN", 3f) > 2.5f
            p.add(chipRow(listOf("2 colours", "3 colours"), if (n3) 1 else 0) { i ->
                pushUndo(); l.xset("wColN", if (i == 1) 3f else 2f); refreshPanel(); render()
            })
            fun wc(title: String, key: String, d: Long) {
                text(p, title, C.DIM, 12f)
                p.add(EBox(colorRow((0xFF000000.toInt()) or (l.xf(key, d.toFloat()).toInt() and 0xFFFFFF)) { c ->
                    pushUndo(); l.xset(key, (c.toLong() and 0xFFFFFF).toFloat()); render()
                }, 0f, 48f, 0f, 0f, 0f, 0f))
            }
            wc("Shallow colour", "wCol0", 0x2FD0C8)
            if (n3) wc("Middle colour", "wCol1", 0x1E7FD0)
            wc("Deep colour", "wCol2", 0x08285A)
            text(p, "Gradient", C.DIM, 12f)
            p.add(chipRow(listOf("By depth", "Flowing bands", "Patches"), ktInt(l.xf("wGrad", 0f))) { i ->
                pushUndo(); l.xset("wGrad", i.toFloat()); refreshPanel(); render()
            })
            if (l.xf("wGrad", 0f) > 0.5f) xs2("Gradient size (higher = smaller)", 0.05f, 6f, "wGradScale", 1f)
        }
        text(p, "Reflections and light", C.TEXT, 13f, true)
        val rf = SwitchRow(); rf.label = "Reflect surface (caustics + surroundings)"; rf.on = l.xf("wRefl", 0f) > 0.5f
        rf.onToggle = { v -> pushUndo(); l.xset("wRefl", if (v) 1f else 0f); render() }
        put(p, rf, 46f)
        val ry = SwitchRow(); ry.label = "Rays (volumetric light underwater)"; ry.on = l.xf("wRays", 0f) > 0.5f
        ry.onToggle = { v -> pushUndo(); l.xset("wRays", if (v) 1f else 0f); render() }
        put(p, ry, 46f)
        if (l.xf("wRays", 0f) > 0.5f) {
            xs2("Ray strength", 0f, 3f, "wRayStr", 1f); xs2("Ray length / depth reach", 0.2f, 3f, "wRayLen", 1f)
            xs2("Ray sharpness", 0f, 2f, "wRayWid", 1f); xs2("Ray speed", 0f, 3f, "wRaySpd", 1f)
        }
        text(p, "Collision", C.TEXT, 13f, true)
        val cl = SwitchRow(); cl.label = "Water collision (rocks / shores)"; cl.on = l.xf("wColl", 0f) > 0.5f
        cl.onToggle = { v -> pushUndo(); l.xset("wColl", if (v) 1f else 0f); refreshPanel(); render() }
        put(p, cl, 46f)
        if (l.xf("wColl", 0f) > 0.5f) {
            val rk = SwitchRow(); rk.label = "Rocks (foam bursts on steep contact)"; rk.on = l.xf("wCollRock", 1f) > 0.5f
            rk.onToggle = { v -> pushUndo(); l.xset("wCollRock", if (v) 1f else 0f); render() }
            put(p, rk, 46f)
            val sh = SwitchRow(); sh.label = "Shores (waves wash up and back)"; sh.on = l.xf("wCollShore", 1f) > 0.5f
            sh.onToggle = { v -> pushUndo(); l.xset("wCollShore", if (v) 1f else 0f); render() }
            put(p, sh, 46f)
            xs2("Foam width", 0f, 1f, "wFoamW", 0.4f)
        }
        text(p, "Objects under the surface are lit and clear when shallow and get darker and bluer with depth (1 unit = 1 m). A camera under the surface sees the volume. Scene lights and the sun reflect on the surface; use the layer colour to tint it.", C.DIM, 12f)
    } else {
        text(p, "PBR surface", C.TEXT, 14f, true)
        xs2("Bump strength", 0.05f, 3f, "pbrNorm", 1.3f); xs2("Parallax depth", 0f, 0.06f, "pbrPom", 0.025f)
        val pg = SwitchRow(); pg.label = "Procedurally generate (while scaling)"; pg.on = l.xf("pgOn", 0f) > 0.5f
        pg.onToggle = { v ->
            pushUndo(); l.xset("pgOn", if (v) 1f else 0f)
            if (v) l.xset("pgRef", maxOf(l.p("scale", Editor.time), 1e-4f))
            render()
        }
        put(p, pg, 46f)
        put(p, pill("Lay flat", "square.grid.3x3") {
            pushUndo()
            for ((k, v) in listOf("rotX" to -90f, "rotY" to 0f, "rotZ" to 0f, "y" to 0f)) l.track(k).set(Editor.time, v, false)
            refreshPanel(); render()
        }, 42f)
        text(p, "Procedural keeps the texture density constant (new tiles are generated, never stretched) when you scale the layer. Lay flat puts it on the grid.", C.DIM, 12f)
    }
}

fun EditorViewController.buildText(p: EVStack, l: Layer) {
    text(p, "Text", C.TEXT, 16f, true)
    p.add(chipRow(listOf("Text", "Style", "Animate"), textTab) { i ->
        textTab = i
        refreshPanel()
    })
    when (textTab) {
        0 -> {
            val et = makeField(l.text)
            bind(et) { s ->
                l.text = s
                render()
            }
            put(p, et, 44f)
            text(p, "Alignment", C.GREEN, 13f, true)
            p.add(chipRow(listOf("Left", "Center", "Right"), l.align) { i ->
                pushUndo()
                l.align = i
                render()
            })
            text(p, "Letter case", C.GREEN, 13f, true)
            p.add(chipRow(listOf("As typed", "UPPER", "lower"), l.caps) { i ->
                pushUndo()
                l.caps = i
                render()
            })
            val sb = SwitchRow()
            sb.label = "Bold"; sb.on = l.bold
            sb.onToggle = { v -> pushUndo(); l.bold = v; render() }
            put(p, sb, 52f)
            val si = SwitchRow()
            si.label = "Italic"; si.on = l.italic
            si.onToggle = { v -> pushUndo(); l.italic = v; render() }
            put(p, si, 52f)
            val su = SwitchRow()
            su.label = "Underline"; su.on = l.underline
            su.onToggle = { v -> pushUndo(); l.underline = v; render() }
            put(p, su, 52f)
            val ss = SwitchRow()
            ss.label = "Strikethrough"; ss.on = l.strike
            ss.onToggle = { v -> pushUndo(); l.strike = v; render() }
            put(p, ss, 52f)
            addRow(p, l, Defs.text[4])
            text(p, "Font", C.GREEN, 13f, true)
            val fams = listOf("sans-serif", "serif", "monospace", "cursive", "casual", "sans-serif-condensed",
                              "sans-serif-light", "sans-serif-medium", "sans-serif-black", "serif-monospace")
            val names = listOf("Sans", "Serif", "Mono", "Cursive", "Casual", "Condensed", "Light", "Medium", "Black", "Typewriter")
            val sel = if (l.fontPath != null) -1 else (fams.indexOf(l.font))
            p.add(chipRow(names, sel) { i ->
                pushUndo()
                l.font = fams[i]
                l.fontPath = null
                refreshPanel(); render()
            })
            val curName = l.fontPath?.let { fp -> com.saiki.motion.core.FontLibrary.fonts.firstOrNull { com.saiki.motion.core.FontLibrary.path(it) == File(fp).path }?.name }
            put(p, pill(if (l.fontPath != null) "Font: " + (curName ?: "custom") + "  ·  Browse" else "Font library — import, folders, ZIP packs",
                        "folder") {
                val vc = FontBrowserViewController(null)
                vc.currentPath = l.fontPath
                vc.onPick = { f: com.saiki.motion.core.FontRecord ->
                    pushUndo()
                    l.fontPath = com.saiki.motion.core.FontLibrary.path(f)
                    refreshPanel(); render()
                }
                val nav = com.saiki.motion.uikit.UINavigationController(vc)
                present(nav, animated = true)
            }, 42f)
            put(p, pill("Import a single font file (.ttf or .otf)", "import") {
                pickFile(R_FONT)
            }, 42f)
            text(p, "Color", C.GREEN, 13f, true)
            addKeyedColor(p, l, "color", l.color) { l.color = it }
            addRow(p, l, Defs.transform[2], "Size")
        }
        1 -> {
            text(p, "Stroke", C.GREEN, 13f, true)
            addRow(p, l, Defs.text[0])
            addKeyedColor(p, l, "strokeColor", l.strokeColor) { l.strokeColor = it }
            text(p, "Stroke position", C.DIM, 12f)
            p.add(chipRow(listOf("Outside", "Center", "Inside"), l.strokePos) { i ->
                pushUndo()
                l.strokePos = i
                render()
            })
            text(p, "Corners", C.DIM, 12f)
            p.add(chipRow(listOf("Round", "Sharp"), l.strokeJoin) { i ->
                pushUndo()
                l.strokeJoin = i
                render()
            })
            text(p, "Second stroke (outside the first)", C.GREEN, 13f, true)
            addRow(p, l, Defs.text[8])
            addKeyedColor(p, l, "stroke2Color", l.stroke2Color) { l.stroke2Color = it }
            text(p, "Border box", C.GREEN, 13f, true)
            addRow(p, l, Defs.text[1])
            addRow(p, l, Defs.text[2])
            addRow(p, l, Defs.text[9])
            addKeyedColor(p, l, "borderColor", l.borderColor) { l.borderColor = it }
            val bd = SwitchRow()
            bd.label = "Dashed border"; bd.on = l.borderDash
            bd.onToggle = { v -> pushUndo(); l.borderDash = v; render() }
            put(p, bd, 52f)
            text(p, "Box fill", C.DIM, 12f)
            addKeyedColor(p, l, "borderFill", if (colorAlpha(l.borderFill) == 0) 0xFF000000.toInt() else l.borderFill) { l.borderFill = it }
            put(p, pill("No box fill", "close") {
                pushUndo(); l.borderFill = 0
                for (sf in listOf("_r", "_g", "_b", "_a")) l.props.remove("tc_borderFill" + sf)
                refreshPanel(); render()
            }, 40f)
            text(p, "Shadow", C.GREEN, 13f, true)
            val sh = SwitchRow()
            sh.label = "Shadow"; sh.on = l.shadowOn
            sh.onToggle = { v ->
                pushUndo()
                l.shadowOn = v
                refreshPanel(); render()
            }
            put(p, sh, 52f)
            if (l.shadowOn) {
                addKeyedColor(p, l, "shadowColor", l.shadowColor) { l.shadowColor = it }
                addRow(p, l, Defs.text[5])
                addRow(p, l, Defs.text[6])
                addRow(p, l, Defs.text[7])
            }
            text(p, "Spacing", C.GREEN, 13f, true)
            addRow(p, l, Defs.text[3])
        }
        else -> buildTextAnim(p, l)
    }
}

fun EditorViewController.buildTextAnim(p: EVStack, l: Layer) {
    // presets: each one builds a normal custom animation the user can keep editing
    fun fxOf(kind: Int, vals: List<Float>): TextFx { val f = TextFx(kind); for ((i, x) in vals.withIndex()) if (i < f.v.count()) f.v[i] = x; return f }
    val presets: List<Pair<String, () -> TextAnim>> = listOf(
        Pair("Slide up", { val a = TextAnim(12); a.fx = mutableListOf(fxOf(0, listOf(0f, 0.3f, 1f, 0f, 0f))); a }),
        Pair("Slide down", { val a = TextAnim(12); a.fx = mutableListOf(fxOf(0, listOf(0f, -0.3f, 1f, 0f, 0f))); a }),
        Pair("Fade in", { val a = TextAnim(12); a.fx = mutableListOf(fxOf(0, listOf(0f, 0f, 1f, 0f, 0f))); a }),
        Pair("Pop", { val a = TextAnim(12); a.ease = 3; a.fx = mutableListOf(fxOf(0, listOf(0f, 0f, 0f, 0f, 0f))); a }),
        Pair("Typewriter", { val a = TextAnim(12); a.dur = 0.05f; a.stagger = 0.08f; a.fx = mutableListOf(fxOf(0, listOf(0f, 0f, 1f, 0f, 0f))); a }),
        Pair("Rotate in", { val a = TextAnim(12); a.fx = mutableListOf(fxOf(0, listOf(0f, 0f, 1f, 90f, 0f))); a }),
        Pair("Slide up out", { val a = TextAnim(12, 1); a.start = 1f; a.fx = mutableListOf(fxOf(0, listOf(0f, -0.3f, 1f, 0f, 0f))); a }),
        Pair("Slide down out", { val a = TextAnim(12, 1); a.start = 1f; a.fx = mutableListOf(fxOf(0, listOf(0f, 0.3f, 1f, 0f, 0f))); a }),
        Pair("Bounce in", { val a = TextAnim(12); a.ease = 3; a.fx = mutableListOf(fxOf(0, listOf(0f, 0.3f, 1f, 0f, 0f))); a }),
        Pair("Fade out", { val a = TextAnim(12, 1); a.fx = mutableListOf(fxOf(0, listOf(0f, 0f, 1f, 0f, 0f))); a })
    )
    put(p, pill("Add preset", "plus", C.GREEN, C.ONDARK) {
        Dlg(this).setTitle("Add preset").setItems(presets.map { it.first }) { _, w ->
            pushUndo()
            val a = presets[w].second()
            if (a.mode == 1) a.start = 1f
            l.anims.add(a)
            expanded.add("anim:${l.id}:${l.anims.count() - 1}")
            refreshPanel(); render()
        }.show()
    }, 46f)
    put(p, pill("Animate — new custom animation", "plus", C.GREEN, C.ONDARK) {
        pushUndo()
        val a = TextAnim(12)
        a.start = 0f; a.dur = 1f
        l.anims.add(a)
        expanded.add("anim:${l.id}:${l.anims.count() - 1}")
        refreshPanel(); render()
    }, 46f)
    if (l.anims.isEmpty()) {
        text(p, "Tap Animate to build your own: set a start and end, then add animation types (Transform, Wiggle, 3D, Tracking, Skew) and tune every value. Presets are just starting points you can edit.", C.DIM, 12f)
    }
    for ((i, a) in l.anims.withIndex()) {
        val key = "anim:${l.id}:$i"
        val isOpen = expanded.contains(key)
        val card = vStack()
        val bar = hRow()
        bar.setBackgroundColor(C.CARD)
        val tv = UILabel(com.saiki.motion.uikit.appContext!!)
        tv.text = a.name()
        tv.textColor = argbToUIColor(C.TEXT)
        tv.font = boldFont(16f)
        bar.add(growBox(tv))
        val chev = IconView2(if (isOpen) "chev_up" else "chev_down", C.DIM, 20f)
        chev.onClick = {
            if (expanded.contains(key)) expanded.remove(key) else expanded.add(key)
            refreshPanel()
        }
        bar.add(EBox(chev, 40f, 48f, 0f, 0f, 0f, 0f))
        val del = IconView2("trash", C.RED, 20f)
        del.onClick = {
            pushUndo()
            l.anims.removeAll { it === a }
            for (k in l.props.keys.toList()) {
                if (k.startsWith("an_${a.id}_") || a.fx.any { k.startsWith("fx_${it.id}_") }) l.props.remove(k)
            }
            refreshPanel(); render()
        }
        bar.add(EBox(del, 40f, 48f, 0f, 0f, 0f, 0f))
        card.add(bar)
        if (isOpen) {
            if (a.type == 12) {
                addKeyedRow(card, l, "an_${a.id}_start", "Start (s)", 0f, 30f, 0f, 2, a.start)
                addKeyedRow(card, l, "an_${a.id}_end", "End (s)", 0.05f, 30f, 1f, 2, a.start + a.dur)
                addKeyedRow(card, l, "an_${a.id}_stag", "Delay per letter (s)", 0f, 0.5f, 0.04f, 2, a.stagger)
                card.add(chipRow(listOf("In", "Out", "Loop"), a.mode) { m ->
                    pushUndo(); a.mode = m; refreshPanel(); render()
                })
                text(card, "Easing", C.DIM, 12f)
                card.add(chipRow(listOf("Linear", "Ease out", "Ease in-out", "Bounce", "Custom curve"), a.ease) { e ->
                    pushUndo(); a.ease = e
                    if (e == 4) a.curve.ease = com.saiki.motion.core.Ease.CUSTOM
                    refreshPanel(); render()
                })
                if (a.ease == 4) {
                    val gv = GraphView()
                    gv.key = a.curve
                    gv.onBeginCb = { pushUndo() }
                    gv.onChange = { render() }
                    put(card, gv, 200f)
                }
                for ((fi, fx) in a.fx.withIndex()) {
                    val hdr = hRow()
                    val tl = UILabel(appContext!!); tl.text = fx.name(); tl.textColor = argbToUIColor(C.GREEN); tl.font = boldFont(14f)
                    hdr.add(growBox(tl))
                    val dl = IconView2("trash", C.RED, 18f)
                    dl.onClick = {
                        pushUndo(); a.fx.removeAt(fi)
                        for (k in l.props.keys.toList()) if (k.startsWith("fx_${fx.id}_")) l.props.remove(k)
                        refreshPanel(); render()
                    }
                    hdr.add(EBox(dl, 40f, 40f, 0f, 0f, 0f, 0f))
                    put(card, hdr, 40f)
                    for ((vi, pd) in TextFx.PARAMS[fx.kind].withIndex()) {
                        addKeyedRow(card, l, "fx_${fx.id}_$vi", pd.label + " · " + fx.name(), pd.lo, pd.hi, pd.def, pd.dec, fx.v[vi])
                    }
                }
                put(card, pill("Add animation type", "plus") {
                    Dlg(this).setTitle("Animation type").setItems(TextFx.KINDS) { _, w ->
                        pushUndo(); a.fx.add(TextFx(w)); refreshPanel(); render()
                    }.show()
                }, 42f)
            } else {
                card.add(chipRow(listOf("In", "Out", "Loop"), a.mode) { m ->
                    pushUndo()
                    a.mode = m
                    refreshPanel(); render()
                })
                addPlain(card, "Start (s)", 0f, 10f, a.start, 2) { v -> a.start = v; render() }
                addPlain(card, "Duration (s)", 0.05f, 5f, a.dur, 2) { v -> a.dur = v; render() }
                addPlain(card, "Delay per letter (s)", 0f, 0.5f, a.stagger, 2) { v -> a.stagger = v; render() }
                addPlain(card, "Distance", 0f, 3f, a.distance, 2) { v -> a.distance = v; render() }
                addPlain(card, "Scale from", 0f, 3f, a.scaleFrom, 2) { v -> a.scaleFrom = v; render() }
                addPlain(card, "Rotate from (deg)", -360f, 360f, a.rotFrom, 0) { v -> a.rotFrom = v; render() }
                addPlain(card, "Speed (loops)", 0f, 10f, a.speed, 1) { v -> a.speed = v; render() }
                text(card, "Easing", C.DIM, 12f)
                card.add(chipRow(listOf("Linear", "Ease out", "Ease in-out", "Bounce", "Custom curve"), a.ease) { e ->
                    pushUndo()
                    a.ease = e
                    if (e == 4) a.curve.ease = com.saiki.motion.core.Ease.CUSTOM
                    refreshPanel(); render()
                })
                if (a.ease == 4) {
                    val gv = GraphView()
                    gv.key = a.curve
                    gv.onBeginCb = { pushUndo() }
                    gv.onChange = { render() }
                    put(card, gv, 200f)
                }
                val sf = SwitchRow()
                sf.label = "Fade while moving"; sf.on = a.fade
                sf.onToggle = { v -> pushUndo(); a.fade = v; render() }
                put(card, sf, 52f)
            }
        }
        put(p, card, 0f, 3f, 6f)
    }
}

/** Local alias so panel code reads like iOS IconView(name, tint, size). */
private fun IconView2(name: String, tint: Int, size: Float) = com.saiki.motion.ui.IconView(name, tint, size)
