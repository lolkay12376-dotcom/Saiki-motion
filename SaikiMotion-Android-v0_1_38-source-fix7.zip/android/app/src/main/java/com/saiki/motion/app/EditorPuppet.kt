@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorPuppet.swift — Puppet panel (Pin / Mesh / Sway / Bend tabs).
// Pins are placed and dragged right in the viewport (see OverlayView); this file is the panel.

package com.saiki.motion.app

import com.saiki.motion.core.BendLayer
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.Puppet
import com.saiki.motion.core.PuppetEdit
import com.saiki.motion.core.PuppetPin
import com.saiki.motion.core.PropDef
import com.saiki.motion.core.Rig
import com.saiki.motion.ui.RigEditorViewController
import com.saiki.motion.core.SwayLayer
import com.saiki.motion.ui.C
import com.saiki.motion.ui.FillSlider
import com.saiki.motion.ui.PillButton
import com.saiki.motion.ui.RulerSlider
import com.saiki.motion.ui.SwitchRow
import com.saiki.motion.ui.TabBar
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.ui.boldFont
import com.saiki.motion.ui.chipRow
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import kotlin.math.max
import kotlin.math.min

// ---- rig

fun EditorViewController.createRig() {
    val g = addLayer(com.saiki.motion.core.LayerType.GROUP)
    g.name = "Rig Group ${g.id}"
    g.rig = Rig()
    refreshToolbar(); render()
    toast("Rig group created — tap Cubism Editor")
}

fun EditorViewController.openRigEditor(g: Layer) {
    if (g.rig == null) return
    pushUndo()
    present(RigEditorViewController(g, this), animated = true)
}

/** Imports the selected layer into a rig group chosen from the app's own list. */
fun EditorViewController.importToRig(l: Layer) {
    val groups = Editor.scene.layers.filter { it.rig != null }
    if (groups.isEmpty()) { toast("No rig group yet — tap Create Rig first"); return }
    Dlg(this).setTitle("Import to rig group").setItems(groups.map { it.name }) { _, i ->
        val g = groups[i]
        pushUndo()
        if (!g.rig!!.members.contains(l.id)) g.rig!!.members.add(l.id)
        l.parentId = g.id
        toast("${l.name} added to ${g.name}")
        render()
    }.show()
}

/** Animate Rig panel: every rig parameter as a keyframe-able slider (same rows as any property). */
fun EditorViewController.buildRigAnim(l: Layer) {
    val r = l.rig ?: return
    val p = panelList
    if (r.params.isEmpty()) {
        text(p, "No parameters yet. Open the Cubism Editor and add some (Angle X, Eye open…).", C.DIM, 13f)
        return
    }
    text(p, "Move a slider, then press its keyframe button to animate the rig on the timeline.", C.DIM, 12f)
    for (q in r.params) {
        addRow(p, l, PropDef(q.key, q.name, q.lo, q.hi, q.def, 2))
    }
}

fun EditorViewController.openPuppet() {
    val l = selected() ?: return
    if (l.puppet == null) { pushUndo(); l.puppet = Puppet() }
    PuppetEdit.sel.clear()
    PuppetEdit.onChange = {
        val id = PuppetEdit.sel.lastOrNull()
        if (id != null) selKey = "pp${id}x"
        refreshPanel(); render()
    }
    openPanel(P_PUPPET)
}

fun EditorViewController.buildPuppet(l: Layer) {
    val pp = l.puppet ?: return
    val p = panelList
    put(p, TabBar(listOf("Pin", "Mesh", "Sway", "Bend"), PuppetEdit.tab) { i ->
        PuppetEdit.tab = i; refreshPanel(); render()
    }, 44f)
    when (PuppetEdit.tab) {
        0 -> puppetPinTab(l, pp)
        1 -> puppetMeshTab(l, pp)
        2 -> puppetSwayTab(l, pp)
        else -> puppetBendTab(l, pp)
    }
}

// ---------------------------------------------------------------- helpers

private fun EditorViewController.btnRow(spacing: Float = 8f): EHStack {
    val r = hRow(); r.spacing = spacing; return r
}

private fun EditorViewController.puppetBtn(text: String, icon: String?, on: Boolean = false, enabled: Boolean = true,
                                            click: () -> Unit): PillButton {
    val b = PillButton(text, icon, if (on) C.GREEN else (if (enabled) C.CARD2 else C.CARD),
                       if (on) C.ONDARK else (if (enabled) C.TEXT else C.DIM))
    b.onClick = if (enabled) click else ({ })
    return b
}

private fun EditorViewController.puppetEdit(body: () -> Unit) {
    pushUndo(); body(); PuppetEdit.onChange?.invoke()
}

// ---------------------------------------------------------------- Pin tab

private fun EditorViewController.puppetPinTab(l: Layer, pp: Puppet) {
    val p = panelList
    val has = PuppetEdit.sel.isNotEmpty()

    val top = btnRow()
    val sw = SwitchRow()
    sw.label = "Puppet"; sw.on = pp.on; sw.captionOn = "on"; sw.captionOff = "off"
    sw.onToggle = { v -> pushUndo(); pp.on = v; render() }
    top.add(EBox(sw, 190f, 48f, 0f, 0f, 0f, 0f))
    top.add(spacer())
    top.add(EBox(puppetBtn("Auto-key", null, on = autoKeyOn) {
        autoKeyOn = !autoKeyOn; refreshPanel()
    }, 104f, 44f, 0f, 0f, 0f, 0f))
    top.add(EBox(puppetBtn("⋮", null) { puppetMenu(l, pp) }, 48f, 44f, 0f, 0f, 0f, 0f))
    put(p, top, 0f, 6f, 4f)

    val modes = btnRow()
    modes.add(EBox(puppetBtn("Add", "plus", on = PuppetEdit.mode == 0) {
        PuppetEdit.mode = 0; PuppetEdit.onChange?.invoke()
    }, 112f, 44f, 0f, 0f, 0f, 0f))
    modes.add(EBox(puppetBtn("Select", null, on = PuppetEdit.mode == 1) {
        PuppetEdit.mode = 1; PuppetEdit.onChange?.invoke()
    }, 112f, 44f, 0f, 0f, 0f, 0f))
    modes.add(EBox(puppetBtn("Multi", null, on = PuppetEdit.mode == 2) {
        PuppetEdit.mode = 2; PuppetEdit.onChange?.invoke()
    }, 100f, 44f, 0f, 0f, 0f, 0f))
    modes.add(EBox(puppetBtn(if (pp.showMesh) "Mesh: on" else "Mesh: off", null, on = pp.showMesh) {
        pp.showMesh = !pp.showMesh; refreshPanel(); render()
    }, 104f, 44f, 0f, 0f, 0f, 0f))
    modes.add(spacer())
    put(p, modes, 0f, 4f, 4f)
    if (PuppetEdit.sel.count() == 1) {            // one pin selected -> Point Bend: bends everything below / above it
        val pb = btnRow()
        pb.add(EBox(puppetBtn("Point Bend from this pin", null, on = true) {
            pushUndo()
            val b = BendLayer(); b.applyPreset(0); b.mode = 2; b.name = "Point Bend"; b.angle = 35f; b.smooth = 0.8f
            b.pins = mutableListOf(PuppetEdit.sel[0])
            pp.bends.add(b); pp.bendSel = pp.bends.count() - 1
            PuppetEdit.tab = 3; refreshPanel(); render()
        }, 260f, 44f, 0f, 0f, 0f, 0f))
        pb.add(spacer())
        put(p, pb, 0f, 2f, 4f)
    }
    if (PuppetEdit.sel.count() >= 2) {            // multi-select pins -> Create Bend (first selected = pivot)
        val cb = btnRow()
        cb.add(EBox(puppetBtn("Create Bend (${PuppetEdit.sel.count()} pins)", null, on = true) {
            pushUndo()
            val b = BendLayer(); b.applyPreset(0); b.pins = PuppetEdit.sel.toMutableList()
            pp.bends.add(b); pp.bendSel = pp.bends.count() - 1
            PuppetEdit.tab = 3; refreshPanel(); render()
        }, 240f, 44f, 0f, 0f, 0f, 0f))
        cb.add(spacer())
        put(p, cb, 0f, 2f, 4f)
    }

    val nav = btnRow()
    fun step(d: Int) {
        if (pp.pins.isEmpty()) return
        val cur = PuppetEdit.sel.lastOrNull()?.let { id -> pp.pins.indexOfFirst { it.id == id } } ?: (if (d > 0) -1 else 0)
        val n = (cur + d + pp.pins.count()) % pp.pins.count()
        PuppetEdit.sel.clear(); PuppetEdit.sel.add(pp.pins[n].id); PuppetEdit.onChange?.invoke()
    }
    nav.add(EBox(puppetBtn("", "prev") { step(-1) }, 58f, 44f, 0f, 0f, 0f, 0f))
    val lab = UILabel(com.saiki.motion.uikit.appContext!!)
    lab.textAlignment = com.saiki.motion.uikit.NSTextAlignment.center
    lab.textColor = argbToUIColor(C.TEXT)
    lab.font = boldFont(15f)
    val id0 = PuppetEdit.sel.lastOrNull()
    if (id0 != null && pp.pin(id0) != null) {
        lab.text = if (PuppetEdit.sel.count() > 1) "${PuppetEdit.sel.count()} pins selected" else "Pin ${pp.number(id0)}"
    } else {
        lab.text = if (pp.pins.isEmpty()) "Tap the picture to add a pin" else "Tap a pin to select it"
    }
    nav.add(EBox(lab, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    nav.add(EBox(puppetBtn("", "next") { step(1) }, 58f, 44f, 0f, 0f, 0f, 0f))
    put(p, nav, 0f, 4f, 4f)

    val acts = btnRow()
    acts.add(EBox(puppetBtn("Duplicate pin", "dup", enabled = has) {
        puppetEdit {
            val made = mutableListOf<Int>()
            for (id in PuppetEdit.sel) {
                val src = pp.pin(id) ?: continue
                val n = PuppetPin(pp.nextId, src.rx, src.ry); pp.nextId += 1
                pp.pins.add(n)
                l.track("pp${n.id}x").base = (l.props["pp${id}x"]?.eval(Editor.time) ?: 0f) + 0.08f
                l.track("pp${n.id}y").base = (l.props["pp${id}y"]?.eval(Editor.time) ?: 0f) - 0.08f
                made.add(n.id)
            }
            PuppetEdit.sel.clear(); PuppetEdit.sel.addAll(made)
        }
    }, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    acts.add(EBox(puppetBtn("Reset to rest", "undo", enabled = has) {
        puppetEdit {
            for (id in PuppetEdit.sel) {
                l.track("pp${id}x").set(Editor.time, 0f, autoKeyOn)
                l.track("pp${id}y").set(Editor.time, 0f, autoKeyOn)
            }
        }
    }, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    acts.add(EBox(puppetBtn("Delete pin", "trash", enabled = has) {
        puppetEdit {
            for (id in PuppetEdit.sel) {
                pp.pins.removeAll { it.id == id }
                l.props.remove("pp${id}x"); l.props.remove("pp${id}y")
                for (w in pp.sways) w.chain.removeAll { it == id }
            }
            PuppetEdit.sel.clear()
        }
    }, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    put(p, acts, 46f, 4f, 4f)

    // Every pin can be animated: select one or many (or all) and each selected pin gets its own keyable X / Y.
    val all = btnRow()
    all.add(EBox(puppetBtn("Select all pins", null, enabled = pp.pins.isNotEmpty()) {
        PuppetEdit.sel.clear(); PuppetEdit.sel.addAll(pp.pins.map { it.id }); PuppetEdit.onChange?.invoke()
    }, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    all.add(EBox(puppetBtn("Key all pins", null, enabled = pp.pins.isNotEmpty()) {
        puppetEdit {
            for (q in pp.pins) {
                for (k in listOf("pp${q.id}x", "pp${q.id}y")) { val tk = l.track(k); tk.set(Editor.time, tk.eval(Editor.time), true) }
            }
        }
    }, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    put(p, all, 46f, 4f, 4f)
    val shown = PuppetEdit.sel.filter { pp.pin(it) != null }
    for (id in shown.take(8)) {                       // cap keeps the panel from overcrowding
        val n = pp.number(id)
        addRow(p, l, PropDef("pp${id}x", "Pin $n X", -2f, 2f, 0f, 3))
        addRow(p, l, PropDef("pp${id}y", "Pin $n Y", -2f, 2f, 0f, 3))
    }
    if (shown.count() > 8) { text(p, "+${shown.count() - 8} more selected pins move together. Use Key all pins to keyframe them.", C.DIM, 12f) }

    val fine = btnRow()
    fine.add(spacer())
    fine.add(EBox(puppetBtn("Fine", null, on = PuppetEdit.fine) {
        PuppetEdit.fine = !PuppetEdit.fine; PuppetEdit.onChange?.invoke()
    }, 90f, 40f, 0f, 0f, 0f, 0f))
    put(p, fine, 0f, 4f, 4f)
    text(p, "Fine slows dragging to a quarter so small moves are easy. Auto-key records each move as a keyframe.", C.DIM, 12f)
}

private fun EditorViewController.puppetMenu(l: Layer, pp: Puppet) {
    val a = com.saiki.motion.uikit.UIAlertController()
    a.addAction("Reset all pins to rest") {
        puppetEdit {
            for (q in pp.pins) {
                l.track("pp${q.id}x").set(Editor.time, 0f, autoKeyOn)
                l.track("pp${q.id}y").set(Editor.time, 0f, autoKeyOn)
            }
        }
    }
    a.addAction(com.saiki.motion.uikit.UIAlertAction("Delete all pins", com.saiki.motion.uikit.UIAlertActionStyle.destructive) {
        puppetEdit {
            for (q in pp.pins) { l.props.remove("pp${q.id}x"); l.props.remove("pp${q.id}y") }
            pp.pins.clear(); pp.sways.clear(); PuppetEdit.sel.clear()
        }
    })
    a.addAction(com.saiki.motion.uikit.UIAlertAction("Cancel", com.saiki.motion.uikit.UIAlertActionStyle.cancel, null))
    a.showOver(this)
}

// ---------------------------------------------------------------- Mesh tab

private fun EditorViewController.puppetMeshTab(l: Layer, pp: Puppet) {
    val p = panelList
    val sm = SwitchRow()
    sm.label = "Show mesh"; sm.on = pp.showMesh
    sm.onToggle = { v -> pp.showMesh = v; render() }
    put(p, sm, 52f)
    text(p, "Mesh detail", C.TEXT, 14f, true)
    p.add(chipRow(listOf("Low", "Medium", "High", "Ultra"), pp.density) { i ->
        pushUndo(); pp.density = i; refreshPanel(); render()
    })
    text(p, "Stiffness — higher keeps the bend close to each pin", C.TEXT, 14f, true)
    val fs = FillSlider()
    fs.lo = 1f; fs.hi = 4f; fs.value = pp.stiffness; fs.suffix = ""
    fs.onBeginDrag = { pushUndo() }
    fs.onChange = { v -> pp.stiffness = v; render() }
    put(p, fs, 44f)
}

// ---------------------------------------------------------------- Sway tab

private fun EditorViewController.puppetSwayTab(l: Layer, pp: Puppet) {
    val p = panelList
    val row = btnRow()
    val a = SwitchRow(); a.label = "Auto Sway"; a.on = pp.swayOn
    a.onToggle = { v ->
        pushUndo(); pp.swayOn = v
        if (v && pp.sways.isEmpty() && pp.pins.isNotEmpty()) {
            val w = SwayLayer(); w.chain = pp.pins.map { it.id }.toMutableList(); pp.sways = mutableListOf(w); pp.swaySel = 0
        }
        refreshPanel(); render()
    }
    val r = SwitchRow(); r.label = "Lock root"; r.on = pp.lockRoot
    r.onToggle = { v -> pushUndo(); pp.lockRoot = v; render() }
    row.add(EBox(a, 0f, 52f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    row.add(EBox(r, 0f, 52f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    put(p, row, 52f)

    // ---- the list of sway effects on this layer (any mix of Wave and Physics)
    pp.swaySel = min(max(pp.swaySel, 0), max(pp.sways.count() - 1, 0))
    val list = TopIconScroll(); list.showsHorizontalScrollIndicator = false
    val listRow = hRow()
    var x = 3f
    for ((i, w) in pp.sways.withIndex()) {
        val sel = i == pp.swaySel
        val nm = (if (w.kind == 0) "Wave " else "Physics ") + "${i + 1}" + (if (w.on) "" else " (off)")
        val b = PillButton(nm, null, if (sel) C.GREEN else C.CARD2, if (sel) C.ONDARK else C.TEXT)
        b.onClick = { pp.swaySel = i; refreshPanel() }
        listRow.add(EBox(b, 112f, 38f, 0f, 4f, 0f, 4f))
        x += 118f
    }
    fun adder(title: String, kind: Int) {
        val b = PillButton(title, null, C.CARD2, C.TEXT)
        b.onClick = {
            pushUndo()
            val w = SwayLayer(); w.kind = kind; w.chain = pp.pins.map { it.id }.toMutableList()
            pp.sways.add(w); pp.swaySel = pp.sways.count() - 1; pp.swayOn = true
            refreshPanel(); render()
        }
        listRow.add(EBox(b, 104f, 38f, 0f, 4f, 0f, 4f))
        x += 110f
    }
    adder("+ Wave", 0); adder("+ Physics", 1)
    list.content = listRow
    put(p, list, 46f)

    if (pp.swaySel !in pp.sways.indices) {
        text(p, "Tap + Wave or + Physics. You can stack as many as you like on one layer.", C.DIM, 13f)
        return
    }
    val idx = pp.swaySel
    val w = pp.sways[idx]

    p.add(chipRow(listOf("Wave", "Physics"), w.kind) { i ->
        pushUndo(); w.kind = i; refreshPanel(); render()
    })
    p.add(chipRow(listOf("Normal", "Hair", "Skirt", "Breeze"), w.style) { i ->
        pushUndo(); w.applyStyle(i); refreshPanel(); render()
    })
    if (w.kind == 0) {
        val preset = if (w.deg < 15f) 0 else (if (w.deg < 28f) 1 else 2)
        p.add(chipRow(listOf("Light", "Medium", "Heavy"), preset) { i ->
            pushUndo(); w.deg = listOf(10f, 20f, 35f)[i]; refreshPanel(); render()
        })
    } else {
        // link: a Wave sway drives this physics (wave = the intention, physics = the follow-through)
        val waves = pp.sways.withIndex().filter { it.value.kind == 0 }.map { it.index }
        text(p, "Driven by", C.DIM, 12f)
        p.add(chipRow(listOf("Movement only") + waves.map { "Wave ${it + 1}" },
                      (waves.indexOf(w.link).let { if (it >= 0) it else -1 }) + 1) { i ->
            pushUndo(); w.link = if (i == 0) -1 else waves[i - 1]; refreshPanel(); render()
        })
        if (waves.isEmpty()) { text(p, "Add a + Wave to link it: the wave moves the chain, the physics adds lag and overshoot.", C.DIM, 12f) }
        else if (w.link >= 0) { text(p, "Linked: Wave ${w.link + 1} drives the chain and this Physics follows it with weight, lag and overshoot.", C.DIM, 12f) }
        p.add(chipRow(listOf("Light", "Medium", "Heavy"), w.weight) { i ->
            pushUndo(); w.weight = i; refreshPanel(); render()
        })
        text(p, "Physics follows motion: parent this layer to another layer (like normal). It hangs on the parent, follows the parent\u2019s puppet pins too, and the chain swings after any movement.", C.DIM, 12f)
    }

    if (pp.pins.isEmpty()) {
        text(p, "Add pins on the Pin tab first.", C.DIM, 12f)
    } else {
        if (w.chain.count() < 2) text(p, "Pick at least 2 pins", C.AMBER, 13f)
        val sv = TopIconScroll(); sv.showsHorizontalScrollIndicator = false
        val content = hRow()
        val allOn = w.chain.count() == pp.pins.count()
        val bAll = PillButton("All in order", null, if (allOn) C.GREEN else C.CARD2, if (allOn) C.ONDARK else C.TEXT)
        bAll.onClick = {
            pushUndo(); w.chain = pp.pins.map { it.id }.toMutableList(); pp.swayOn = true
            refreshPanel(); render()
        }
        content.add(EBox(bAll, 110f, 38f, 3f, 4f, 0f, 4f))
        val bClr = PillButton("Clear", null, C.CARD2, C.TEXT)
        bClr.onClick = {
            pushUndo(); w.chain.clear(); refreshPanel(); render()
        }
        content.add(EBox(bClr, 70f, 38f, 6f, 4f, 0f, 4f))
        for ((i, q) in pp.pins.withIndex()) {
            val k = w.chain.indexOf(q.id)
            val nm = "Pin ${i + 1}"
            val b = PillButton(if (k != null) "${k + 1} · $nm" else nm, null,
                               if (k != null) C.GREEN else C.CARD2, if (k != null) C.ONDARK else C.TEXT)
            b.onClick = {
                pushUndo()
                val kk = w.chain.indexOf(q.id)
                if (kk >= 0) w.chain.removeAt(kk) else w.chain.add(q.id)
                refreshPanel(); render()
            }
            content.add(EBox(b, 100f, 38f, 6f, 4f, 0f, 4f))
        }
        sv.content = content
        put(p, sv, 46f)
    }

    /** `key` set → also writes a layer track so keyframes / expressions can drive the value. */
    fun slider(label: String, lo: Float, hi: Float, dec: Int, v: Float, key: String? = null,
               set: (Float) -> Unit) {
        val s = RulerSlider()
        s.label = label; s.lo = lo; s.hi = hi; s.dec = dec; s.value = v
        s.canKey = false
        s.onBeginDrag = { pushUndo() }
        s.onChange = { x2 ->
            set(x2)
            if (key != null) l.props[key]?.let { tr -> tr.base = x2 }
            render()
        }
        put(p, s, 60f)
    }
    if (w.kind == 0) {
        slider("Speed (/s)", 0.1f, 3f, 2, w.speed) { w.speed = it }
        slider("Strength (°)", 0f, 90f, 0, w.deg) { w.deg = it }
        slider("Wave", 0f, 3f, 2, w.wave) { w.wave = it }
        slider("Tip weight", 0.2f, 4f, 2, w.tip) { w.tip = it }
        slider("Randomness (%)", 0f, 100f, 0, w.rand * 100f) { w.rand = it / 100f }
        slider("Seed", 0f, 99f, 0, w.seed.toFloat()) { w.seed = it.toInt() }
    } else {
        slider("Stiffness", 0f, 100f, 0, w.stiff, key = "sw${idx}stiff") { w.stiff = it }
        slider("Damping", 0f, 100f, 0, w.damp, key = "sw${idx}damp") { w.damp = it }
        slider("Gravity", 0f, 100f, 0, w.grav, key = "sw${idx}grav") { w.grav = it }
        slider("Wind (%)", -100f, 100f, 0, w.wind, key = "sw${idx}wind") { w.wind = it }
        slider("Strength (°)", 0f, 90f, 0, w.deg) { w.deg = it }
        // link a value to keyframes / an expression: creates the layer track the physics reads
        val link = btnRow()
        for ((nm, k, v) in listOf(Triple("Link stiffness", "stiff", w.stiff), Triple("Link damping", "damp", w.damp),
                                  Triple("Link gravity", "grav", w.grav), Triple("Link wind", "wind", w.wind))) {
            val key = "sw$idx$k"
            val on = l.props[key] != null
            val b = PillButton(if (on) "✓ $nm" else nm, null, if (on) C.GREEN else C.CARD2, if (on) C.ONDARK else C.TEXT)
            b.onClick = {
                pushUndo()
                if (on) l.props.remove(key) else l.track(key).base = v
                refreshPanel(); render()
            }
            link.add(EBox(b, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
        }
        put(p, link, 46f)
        slider("Mass x", 0.2f, 4f, 2, w.massMul) { w.massMul = it }
        slider("Wind speed (Hz)", 0.05f, 3f, 2, w.windFreq) { w.windFreq = it }
        slider("Max stretch", 0.05f, 3f, 2, w.limit) { w.limit = it }
        text(p, "A linked value becomes a track named sw${idx}stiff / damp / grav / wind. Keyframe it or add an expression to it in the graph editor.", C.DIM, 11f)
    }

    // ---- link to another layer's Wave: this sway moves with it (back skirt follows front skirt)
    val cands = mutableListOf<Triple<String, Int, Int>>()
    for (o in Editor.scene.layers) {
        if (o.id == l.id) continue
        val op = o.puppet ?: continue
        if (!op.swayOn) continue
        for ((j, ow) in op.sways.withIndex()) if (ow.kind == 0 && ow.on) cands.add(Triple("${o.name} · Wave ${j + 1}", o.id, j))
    }
    val fl = btnRow()
    val cur = cands.firstOrNull { it.second == w.followId && it.third == w.followIdx }?.first
    val fb = PillButton(if (cur != null) "Follows: $cur" else "Follow another layer's wave", null,
                        if (cur != null) C.GREEN else C.CARD2, if (cur != null) C.ONDARK else C.TEXT)
    fb.onClick = {
        val a = com.saiki.motion.uikit.UIAlertController()
        a.title = "Follow wave"
        if (cands.isEmpty()) a.message = "No other layer has a Wave yet."
        a.addAction("None") { pushUndo(); w.followId = -1; refreshPanel(); render() }
        for (c in cands) {
            a.addAction(com.saiki.motion.uikit.UIAlertAction(c.first, com.saiki.motion.uikit.UIAlertActionStyle.default) {
                pushUndo(); w.followId = c.second; w.followIdx = c.third; refreshPanel(); render()
            })
        }
        a.addAction(com.saiki.motion.uikit.UIAlertAction("Cancel", com.saiki.motion.uikit.UIAlertActionStyle.cancel, null))
        a.showOver(this)
    }
    fl.add(EBox(fb, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    put(p, fl, 46f)
    if (w.followId >= 0) {
        slider("Follow strength", 0f, 2f, 2, w.followAmt) { w.followAmt = it }
        slider("Follow delay (s)", 0f, 2f, 2, w.delay) { w.delay = it }
    }

    val del = btnRow()
    val en = PillButton(if (w.on) "Disable this sway" else "Enable this sway", null, C.CARD2, C.TEXT)
    en.onClick = { pushUndo(); w.on = !w.on; refreshPanel(); render() }
    val rm = PillButton("Delete this sway", null, C.CARD2, C.TEXT)
    rm.onClick = {
        pushUndo(); pp.sways.removeAt(idx); pp.swaySel = max(0, idx - 1)
        refreshPanel(); render()
    }
    del.add(EBox(en, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    del.add(EBox(rm, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    put(p, del, 46f)
}

// ---------------------------------------------------------------- Bend tab

/** EditorViewController.bendKeys twin: key suffix <-> parameter name (iOS EditorPuppet.swift). */
val bendKeys = listOf("amt" to "amount", "ang" to "angle", "smo" to "smooth", "tip" to "falloff", "tgt" to "target")

private fun EditorViewController.puppetBendTab(l: Layer, pp: Puppet) {
    val p = panelList
    pp.bendSel = min(max(pp.bendSel, 0), max(pp.bends.count() - 1, 0))
    if (pp.bendSel !in pp.bends.indices) {
        text(p, "Pin tab: switch to Multi, tap 2+ pins (first = pivot), then tap Create Bend.", C.DIM, 13f)
        return
    }
    val idx = pp.bendSel
    val b = pp.bends[idx]
    val list = TopIconScroll(); list.showsHorizontalScrollIndicator = false
    val listRow = hRow()
    var x = 3f
    for ((i, bd) in pp.bends.withIndex()) {
        val sel = i == idx
        val bt = PillButton(bd.name + (if (bd.on) "" else " (off)"), null, if (sel) C.GREEN else C.CARD2, if (sel) C.ONDARK else C.TEXT)
        bt.onClick = { pp.bendSel = i; refreshPanel() }
        listRow.add(EBox(bt, 130f, 38f, 0f, 4f, 0f, 4f))
        x += 136f
    }
    list.content = listRow
    put(p, list, 46f)
    text(p, "Presets", C.DIM, 12f)
    p.add(chipRow(BendLayer.presetNames, BendLayer.presetNames.indexOf(b.name).let { if (it >= 0) it else -1 }) { i ->
        pushUndo(); b.applyPreset(i)
        // parameters that already own a track (keyframes / expression) take the preset value as their base
        val vals = listOf("amt" to b.amt, "ang" to b.angle, "smo" to b.smooth, "tip" to b.tip, "tgt" to b.target)
        for ((k, v) in vals) { l.props["bnd$idx$k"]?.let { tr -> tr.base = v } }
        refreshPanel(); render()
    })
    p.add(chipRow(listOf("Bend", "Eyelid", "Point"), b.mode) { i ->
        pushUndo(); b.mode = i; refreshPanel(); render()
    })
    if (b.mode == 2) {
        text(p, if (b.pins.isNotEmpty()) "Point: Pin ${pp.number(b.pins[0])}" else "Point: none", C.DIM, 12f)
        p.add(chipRow(listOf("Bend below", "Bend above"), b.side) { i ->
            pushUndo(); b.side = i; refreshPanel(); render()
        })
    }
    // every parameter is a normal keyframable row: tap the diamond to key it, tap the name to open its graph
    fun cur(k: String, v: Float): Float = l.props["bnd$idx$k"]?.base ?: v
    addKeyedRow(p, l, "bnd${idx}amt", "Amount", 0f, 1f, 1f, 2, cur("amt", b.amt))
    addKeyedRow(p, l, "bnd${idx}ang", if (b.mode != 1) "Angle (°)" else "Strength (%)",
                if (b.mode != 1) -180f else -150f, if (b.mode != 1) 180f else 150f, 45f, if (b.mode != 1) 1 else 0, cur("ang", b.angle))
    if (b.mode == 0) { addKeyedRow(p, l, "bnd${idx}tgt", "Target (0 root · 0.5 middle)", 0f, 0.98f, 0f, 2, cur("tgt", b.target)) }
    addKeyedRow(p, l, "bnd${idx}smo", "Smoothness", 0f, 1f, 0.7f, 2, cur("smo", b.smooth))
    addKeyedRow(p, l, "bnd${idx}tip", "Falloff", 0.2f, 4f, 1f, 2, cur("tip", b.tip))

    // when the layer is linked (wave follow / physics / parent), choose what the bend also drives
    val aw = SwitchRow(); aw.label = "Affect wave / other"; aw.on = b.affectWave
    aw.onToggle = { v -> pushUndo(); b.affectWave = v; render() }
    val ap = SwitchRow(); ap.label = "Affect physics"; ap.on = b.affectPhys
    ap.onToggle = { v -> pushUndo(); b.affectPhys = v; render() }
    val chk = btnRow()
    chk.add(EBox(aw, 0f, 52f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    chk.add(EBox(ap, 0f, 52f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    put(p, chk, 52f)

    val row = btnRow()
    val us = PillButton(if (b.mode == 2) "Use selected pin as point" else "Use selected pins", null, C.CARD2, C.TEXT)
    us.onClick = {
        if (PuppetEdit.sel.count() >= (if (b.mode == 2) 1 else 2)) {
            pushUndo(); b.pins = (if (b.mode == 2) listOf(PuppetEdit.sel[0]) else PuppetEdit.sel.toList()).toMutableList(); refreshPanel(); render()
        }
    }
    val en = PillButton(if (b.on) "Disable" else "Enable", null, C.CARD2, C.TEXT)
    en.onClick = { pushUndo(); b.on = !b.on; refreshPanel(); render() }
    row.add(EBox(us, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    row.add(EBox(en, 0f, 44f, 0f, 0f, 0f, 0f).also { it.grow = 1f })
    put(p, row, 46f)
    val rm = PillButton("Delete bend", null, C.CARD2, C.TEXT)
    rm.onClick = {
        pushUndo()
        for ((k, _) in bendKeys) l.props.remove("bnd$idx$k")
        if (idx + 1 < pp.bends.count()) {                // shift the keyframe tracks of the later bends down one slot
            for (j in idx + 1 until pp.bends.count()) { for ((k, _) in bendKeys) {
                val tr = l.props["bnd${j}$k"]
                if (tr != null) l.props["bnd${j - 1}$k"] = tr else l.props.remove("bnd${j - 1}$k")
                l.props.remove("bnd${j}$k")
            } }
        }
        pp.bends.removeAt(idx); pp.bendSel = max(0, idx - 1)
        refreshPanel(); render()
    }
    put(p, rm, 46f)
    text(p, "Bend hinges at Target (0 = first pin, 0.5 = middle) and swings the pins after it, easing in smoothly. Eyelid squashes pins to their centre line. Affect physics: physics lags behind the bend. Affect wave: waves swing around the bent shape. Tap a diamond to keyframe.", C.DIM, 11f)
}
