// EditorSeams.kt — minimal seams for editor-referenced types whose full iOS source belongs to a
// LATER porting wave. The S3 panels/dashboards are now full ports in ui/.
// DepthAnything (Effects/DepthAnything.swift) is now the full port in core/DepthAnything.kt;
// VectorPenViewController (Tools/VectorPenViewController.swift) is now the full port in
// app/VectorPenViewController.kt.

package com.saiki.motion.app

import com.saiki.motion.core.Prefs
import com.saiki.motion.ui.C
import com.saiki.motion.ui.TapView
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.core.DepthAnything
import com.saiki.motion.core.DepthModelKind

// ================================================================ small widget gaps

/** Lock icon button (zoom/move lock on the preview). */
class LockButton(private val sfName: String) : TapView() {
    private var on = false
    fun setOn(v: Boolean) { on = v; setNeedsDisplay() }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        c.paint.color = if (on) 0xF2383838.toInt() else 0xD9161618.toInt()
        c.canvas.drawRoundRect(android.graphics.RectF(0f, 0f, rect.width, rect.height), 12f, 12f, c.paint)
        if (on) {
            c.paint.style = android.graphics.Paint.Style.STROKE
            c.paint.strokeWidth = 1.5f
            c.paint.color = C.GREEN
            c.canvas.drawRoundRect(android.graphics.RectF(0.75f, 0.75f, rect.width - 0.75f, rect.height - 0.75f), 12f, 12f, c.paint)
            c.paint.style = android.graphics.Paint.Style.FILL
        }
        val icon = when {
            sfName.startsWith("plus") -> "grid"
            sfName.startsWith("arrow") -> "move"
            else -> "grid"
        }
        com.saiki.motion.ui.Icons.draw(c, icon, rect.width / 2, rect.height / 2, 22f, if (on) C.GREEN else 0xFFFFFFFF.toInt())
    }
}

/** Category chip for the effect browser (iOS UIButton pill). */
class CategoryChip(val label: String) : TapView() {
    var on = false
        set(v) { field = v; setNeedsDisplay() }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        c.paint.color = if (on) C.GREEN else C.CARD2
        c.canvas.drawRoundRect(android.graphics.RectF(0f, 2f, rect.width, rect.height - 4f), 16f, 16f, c.paint)
        val txt = com.saiki.motion.uikit.measureText(label, 13f)
        com.saiki.motion.uikit.drawText(label, (rect.width - txt) / 2 + 14f, rect.midY + 4.5f,
            color = if (on) C.BG else C.TEXT, size = 13f)
    }
}
