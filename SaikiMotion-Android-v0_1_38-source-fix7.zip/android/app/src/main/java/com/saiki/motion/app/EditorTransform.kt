@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/App/Editor/EditorTransform.swift — Transform panel: position/scale/rotation/anchor/align/parent.

package com.saiki.motion.app

import com.saiki.motion.core.Defs
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Ease
import com.saiki.motion.core.Key
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.PropDef
import com.saiki.motion.core.Registry
import com.saiki.motion.core.Xf
import com.saiki.motion.core.clamp
import com.saiki.motion.ui.C
import com.saiki.motion.ui.GridPick
import com.saiki.motion.ui.IconView
import com.saiki.motion.ui.MovePadView
import com.saiki.motion.ui.SwitchRow
import com.saiki.motion.ui.TabBar
import com.saiki.motion.ui.chipRow
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.ui.boldFont
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

fun EditorViewController.buildXform(l: Layer) {
    val p = panelList
    p.add(EBox(TabBar(listOf("Attributes", "Anchor & Align"), xformTab) { i ->
        xformTab = i
        refreshPanel()
    }, 0f, 44f, 0f, 0f, 0f, 0f))
    if (xformTab == 1) { buildAnchorAlign(l); return }
    val threeD = l.is3d || l.type == LayerType.MODEL || l.type == LayerType.CAMERA || Xf.isParticles(l)
    val s3 = SwitchRow()
    s3.label = "3D layer"; s3.on = l.is3d || l.type == LayerType.MODEL || l.type == LayerType.CAMERA
    s3.onToggle = { _ -> toggle3d() }
    put(p, s3, 52f)
    if ((l.is3d || l.type == LayerType.MODEL) && l.type != LayerType.PARTICLES && l.type != LayerType.CAMERA) {
        val oc = SwitchRow(); oc.label = "Occlusion (hide what is behind)"; oc.on = l.occlude
        oc.onToggle = { v -> pushUndo(); l.occlude = v; render() }
        put(p, oc, 46f)
    }
    if (l.type == LayerType.GROUP) {
        val pc = SwitchRow()
        pc.label = "Precomp (render group as one image)"; pc.on = l.precomp
        pc.onToggle = { v -> pushUndo(); l.precomp = v; refreshPanel(); render() }
        put(p, pc, 52f)
        text(p, if (l.precomp) "Children render together first, then effects, mask, opacity and blend apply to the whole group."
                else "Flat group: children draw straight onto the scene.", C.DIM, 12f)
    }
    if (l.type == LayerType.NULL && !l.is3d) {
        text(p, "This Null is 2D, so it will not move other layers. Turn 3D on.", C.AMBER)
    }
    groupHeader(p, "Position") { showPositionMenu(l, threeD) }
    if (moveMode || !sepDims) addMovePad(p, l)
    if (sepDims) { addRow(p, l, Defs.transform[0]); addRow(p, l, Defs.transform[1]) }
    if (threeD) addRow(p, l, Defs.pos3d[0])
    if (l.type != LayerType.CAMERA) {
        val sh = hRow()
        val stt = UILabel(com.saiki.motion.uikit.appContext!!)
        stt.text = "Scale"
        stt.textColor = argbToUIColor(C.TEXT)
        stt.font = boldFont(15f)
        sh.add(growBox(stt))
        val chain = IconView(if (scaleLinked) "link" else "unlink", 0xFFFFFFFF.toInt(), 22f)
        chain.onClick = {
            scaleLinked = !scaleLinked
            refreshPanel()
        }
        sh.add(EBox(chain, 44f, 40f, 0f, 0f, 0f, 0f))
        put(p, sh, 0f, 4f, 0f)
        addRow(p, l, Defs.transform[2], if (scaleLinked) "Scale (X and Y together)" else "Scale (all)")
        if (!scaleLinked) {
            addRow(p, l, Defs.scaleXY[0])
            addRow(p, l, Defs.scaleXY[1])
        } else {
            val lt0 = l.editTime("scaleX", Editor.time)
            if (abs(l.p("scaleX", lt0) - 1f) > 0.001f || abs(l.p("scaleY", lt0) - 1f) > 0.001f) {
                text(p, "X and Y are stretched separately. Tap the chain to edit them.", C.DIM, 12f)
            }
        }
    }
    if (l.type == LayerType.MODEL) addRow(p, l, Defs.scaleZ)
    val rotDefs: List<PropDef> = if (threeD) listOf(Defs.transform[4], Defs.rot3d[0], Defs.rot3d[1]) else listOf(Defs.transform[4])
    groupHeader(p, "Rotation") { showParamMenu(l, "Rotation", rotDefs) }
    for (d in rotDefs) addRow(p, l, d)
    if (l.isRenderable() || l.type == LayerType.GROUP) {
        groupHeader(p, "Opacity") { showParamMenu(l, "Opacity", listOf(Defs.transform[3])) }
        addRow(p, l, Defs.transform[3])
    }
    val par = Editor.scene.layers.firstOrNull { it.id == l.parentId }
    put(p, pill("Parent: " + (par?.name ?: "None"), "layers") { showParentDialog(l) }, 42f)
    val b = hRow()
    b.spacing = 4f
    for (axis in listOf("rotX", "rotY", "rotZ")) {
        if (!threeD && axis != "rotZ") continue
        b.add(EBox(pill("Spin " + (axis.lastOrNull() ?: '?')) { spin(l, axis) }, 0f, 40f, 0f, 0f, 0f, 0f))
    }
    put(p, b, 40f)
}

fun EditorViewController.groupHeader(p: UiView, title: String, onMenu: () -> Unit) {
    val h = hRow()
    val t = UILabel(com.saiki.motion.uikit.appContext!!)
    t.text = title
    t.textColor = argbToUIColor(C.TEXT)
    t.font = boldFont(15f)
    h.add(growBox(t))
    val m = IconView("more", C.TEXT, 20f)
    m.onClick = onMenu
    h.add(EBox(m, 44f, 40f, 0f, 0f, 0f, 0f))
    put(p, h, 0f, 4f, 0f)
}

/** The three-dot menu used by Scale, Rotation and Opacity. */
fun EditorViewController.showParamMenu(l: Layer, title: String, defs: List<PropDef>) {
    Dlg(this).setTitle(title).setIconItems(listOf("Reset to default", "Clear keyframes (keep current value)", "Expression..."),
        listOf("adjust", "close", "box")) { _, w ->
        pushUndo()
        when (w) {
            0 -> {
                for (d in defs) {
                    val tr = l.track(d.key)
                    tr.keys.clear(); tr.base = d.def
                    tr.setExpr(""); tr.exprOn = false
                }
            }
            1 -> {
                for (d in defs) {
                    val tr = l.track(d.key)
                    val v = tr.eval(l.editTime(d.key, Editor.time))
                    tr.keys.clear(); tr.base = v
                }
            }
            else -> {
                if (defs.size == 1) { showExpression(l, defs[0]); return@setIconItems }
                Dlg(this).setTitle("Expression for").setItems(defs.map { it.label }) { _, i ->
                    showExpression(l, defs[i])
                }.show()
                return@setIconItems
            }
        }
        refreshPanel(); render()
    }.show()
}

fun EditorViewController.addMovePad(p: UiView, l: Layer) {
    val pad = MovePadView()
    val t0 = l.editTime("x", Editor.time)
    pad.px = l.track("x").eval(t0)
    pad.py = l.track("y").eval(t0)
    pad.onBeginDrag = { pushUndo() }
    pad.onMove = { dx, dy ->
        val t = l.editTime("x", Editor.time)
        val d = Xf.toParentSpace(l, Editor.time, dx, dy)
        val nx = l.track("x").eval(t) + d.first
        val ny = l.track("y").eval(t) + d.second
        l.track("x").setMove(t, nx, autoKeyOn)
        l.track("y").setMove(t, ny, autoKeyOn)
        pad.px = nx; pad.py = ny
        pad.setNeedsDisplay()
        syncRows(); render()
    }
    put(p, pad, 150f)
}

fun EditorViewController.showPositionMenu(l: Layer, threeD: Boolean) {
    Dlg(this).setTitle("Position").setIconItems(
        listOf("Separate dimensions  (" + (if (sepDims) "on" else "off") + ")",
            "Move mode  (" + (if (moveMode) "on" else "off") + ")",
            "Reset to default",
            "Expression..."),
        listOf("grid", "move", "adjust", "box")) { _, w ->
        when (w) {
            0 -> sepDims = !sepDims
            1 -> moveMode = !moveMode
            2 -> {
                pushUndo()
                for (k in listOf("x", "y", "z")) {
                    val tr = l.track(k)
                    tr.keys.clear(); tr.base = 0f
                    tr.setExpr(""); tr.exprOn = false
                }
            }
            else -> {
                val names = if (threeD) listOf("Position X", "Position Y", "Position Z") else listOf("Position X", "Position Y")
                Dlg(this).setTitle("Expression for").setItems(names) { _, i ->
                    showExpression(l, if (i == 2) Defs.pos3d[0] else Defs.transform[i])
                }.show()
                return@setIconItems
            }
        }
        refreshPanel()
    }.show()
}

// ---------------------------------------------------------------- anchor + align

fun EditorViewController.buildAnchorAlign(l: Layer) {
    val p = panelList
    text(p, "Anchor", C.TEXT, 15f, true)
    addRow(p, l, Defs.anchor[0])
    addRow(p, l, Defs.anchor[1])
    if (l.is3d || l.type == LayerType.MODEL) addRow(p, l, Defs.anchor[2])   // 3D pivot depth
    val lt = l.editTime("anchorX", Editor.time)
    val ax = l.p("anchorX", lt)
    val ay = l.p("anchorY", lt)
    text(p, "Preset Anchor", C.TEXT, 15f, true)
    val g = GridPick()
    g.sel = (0..8).firstOrNull { abs((it % 3) * 50f - ax) < 0.5f && abs((it / 3) * 50f - ay) < 0.5f } ?: -1
    g.onPick = { i ->
        pushUndo()
        setAnchorKeepVisual(l, (i % 3) * 50f, (i / 3) * 50f)
        refreshPanel(); render()
    }
    put(p, g, 128f)
    text(p, "Align to Canvas", C.TEXT, 15f, true)
    val rows = listOf(listOf("align_l", "align_hc", "align_r"), listOf("align_t", "align_vc", "align_b"))
    for ((ri, rowIcons) in rows.withIndex()) {
        val h = hRow()
        for ((ci, ic) in rowIcons.withIndex()) {
            val b = IconView(ic, C.TEXT, 24f)
            b.setBackgroundColor(C.CARD)
            b.onClick = {
                pushUndo()
                alignToCanvas(l, ri * 3 + ci)
                refreshPanel(); render()
            }
            h.add(EBox(b, 0f, 52f, 3f, 3f, 3f, 3f).also { it.grow = 1f })
        }
        put(p, h)
    }
    text(p, "Align uses the layer's size and rotation. Choosing a preset anchor keeps the layer where it is.", C.DIM, 12f)
}

/** Offset of the layer centre from its position, in world units, for the current anchor. */
fun EditorViewController.anchorOffset(l: Layer, lt: Float, ax: Float, ay: Float): Pair<Float, Float> {
    val (qw, qh) = Xf.quadSize(l)
    val sc = l.p("scale", lt)
    val ox = -(ax - 50f) / 100f * qw * sc * l.p("scaleX", lt)
    val oy = (ay - 50f) / 100f * qh * sc * l.p("scaleY", lt)
    val a = l.p("rotZ", lt).toDouble() * Math.PI / 180.0
    val c = cos(a).toFloat()
    val sn = sin(a).toFloat()
    return Pair(ox * c - oy * sn, ox * sn + oy * c)
}

fun EditorViewController.setAnchorKeepVisual(l: Layer, nx: Float, ny: Float) {
    val t = l.editTime("anchorX", Editor.time)
    val oa = anchorOffset(l, t, l.p("anchorX", t), l.p("anchorY", t))
    val na = anchorOffset(l, t, nx, ny)
    l.track("x").set(t, l.p("x", t) + oa.first - na.first, autoKeyOn)
    l.track("y").set(t, l.p("y", t) + oa.second - na.second, autoKeyOn)
    l.track("anchorX").set(t, nx, autoKeyOn)
    l.track("anchorY").set(t, ny, autoKeyOn)
}

/** which: 0 left, 1 h-centre, 2 right, 3 top, 4 v-centre, 5 bottom. */
fun EditorViewController.alignToCanvas(l: Layer, which: Int) {
    val t = l.editTime("x", Editor.time)
    val (qw, qh) = Xf.quadSize(l)
    val sc = abs(l.p("scale", t))
    val hw = qw * sc * abs(l.p("scaleX", t)) / 2f
    val hh = qh * sc * abs(l.p("scaleY", t)) / 2f
    val a = l.p("rotZ", t).toDouble() * Math.PI / 180.0
    val c = abs(cos(a).toFloat())
    val sn = abs(sin(a).toFloat())
    val bw = c * hw + sn * hh
    val bh = sn * hw + c * hh
    val w = Editor.project.w.toFloat() / Editor.project.h.toFloat()
    val off = anchorOffset(l, t, l.p("anchorX", t), l.p("anchorY", t))
    when (which) {
        0 -> l.track("x").set(t, -w + bw - off.first, autoKeyOn)
        1 -> l.track("x").set(t, -off.first, autoKeyOn)
        2 -> l.track("x").set(t, w - bw - off.first, autoKeyOn)
        3 -> l.track("y").set(t, 1 - bh - off.second, autoKeyOn)
        4 -> l.track("y").set(t, -off.second, autoKeyOn)
        else -> l.track("y").set(t, -1 + bh - off.second, autoKeyOn)
    }
}

fun EditorViewController.spin(l: Layer, key: String) {
    pushUndo()
    val tr = l.track(key)
    tr.keys.clear()
    tr.keys.add(Key(l.start, 0f, Ease.LINEAR))
    tr.keys.add(Key(l.end, 360f, Ease.LINEAR))
    refreshPanel(); render()
}

fun EditorViewController.showParentDialog(l: Layer) {
    // no cycles (a layer can't be parented to anything inside it) and the layer stays where it is
    val cands = Editor.scene.layers.filter { it.id != l.id && !Layer.isDescendant(it, l, Editor.scene.layers) }
    val names = mutableListOf("None")
    names.addAll(cands.map {
        it.name + (if (it.type == LayerType.NULL) " (Null)" else (if (it.type == LayerType.GROUP) " (Group)" else ""))
    })
    Dlg(this).setTitle("Parent").setItems(names) { _, w ->
        pushUndo()
        Xf.reparentKeepingPose(l, if (w == 0) -1 else cands[w - 1].id, Editor.time, autoKeyOn)
        refreshTitle(); refreshPanel(); render()
    }.show()
}
