@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName", "SemicolonSpace")

// Port of Sources/App/EditorViewController.swift — the editor shell.
// Stored state, lifecycle, UI skeleton (top bar / preview / transport / timeline /
// toolbar / panel rail), playback, undo-redo and the EditHost / TimelineHost glue.
// Everything else lives in app/Editor<Name>.kt (extension functions), mirroring
// Sources/App/Editor/*.swift one file per extension.

package com.saiki.motion.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import com.saiki.motion.core.CrashLog
import com.saiki.motion.core.Editor
import com.saiki.motion.core.EffectGuard
import com.saiki.motion.core.EffectThumbs
import com.saiki.motion.core.Flare
import com.saiki.motion.core.FrameCache
import com.saiki.motion.core.FreezeWatchdog
import com.saiki.motion.core.JSONWriter
import com.saiki.motion.core.Key
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.PreRender
import com.saiki.motion.core.Project
import com.saiki.motion.core.Projects
import com.saiki.motion.core.Registry
import com.saiki.motion.core.Rig
import com.saiki.motion.core.Scene
import com.saiki.motion.core.SceneRenderer
import com.saiki.motion.core.Track
import com.saiki.motion.core.Xf
import com.saiki.motion.core.clamp
import com.saiki.motion.core.toCompact
import com.saiki.motion.ui.AspectLayout
import com.saiki.motion.ui.Scene3DView
import com.saiki.motion.ui.C
import com.saiki.motion.ui.ChipView
import com.saiki.motion.ui.Dev
import com.saiki.motion.ui.IconView
import com.saiki.motion.ui.OverlayView
import com.saiki.motion.ui.PillButton
import com.saiki.motion.ui.PillToggle
import com.saiki.motion.ui.PreviewView
import com.saiki.motion.ui.TabBar
import com.saiki.motion.ui.TimelineView
import com.saiki.motion.ui.ToolButton
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.ui.boldFont
import com.saiki.motion.ui.sysFont
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.UIGestureRecognizer
import com.saiki.motion.uikit.UIGestureRecognizerState
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIPinchGestureRecognizer
import com.saiki.motion.uikit.UIPanGestureRecognizer
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.appContext
import java.io.File
import java.lang.ref.WeakReference
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

// Panel ids (Kotlin P_*) and picker request codes (Kotlin R_*), at file scope so
// closures can reference them (iOS EditorViewController.swift:57-62).
const val P_NONE = 0; const val P_MEDIA = 1; const val P_SHAPES = 2; const val P_EDIT = 3
const val P_XFORM = 4; const val P_FX = 5; const val P_BLEND = 6; const val P_SPEED = 7; const val P_GRAPH = 8; const val P_PUPPET = 9; const val P_RIGANIM = 10
const val R_VIDEO = 51; const val R_IMAGE = 52; const val R_GLB = 53; const val R_FX = 54; const val R_PRESET = 55
const val R_VDBENV = 60; const val R_MODELTEX = 61
const val R_BEAT = 57; const val R_AUDIOFILE = 58; const val R_FONT = 59
const val R_PBRMAP = 62; const val R_PBRALL = 63; const val R_COLLIDER = 70
const val R_VDB = 71   // Import3DSheet "Import VDB" (iOS vdbTypes(): .vdb volumes as MODEL layers)
/** which PBR map slot the file picker is filling (iOS gPbrKey, file scope). */
var gPbrKey = ""

/** CADisplayLink target that does not retain the view controller (Choreographer twin). */
private class DisplayLinkProxy(vc0: EditorViewController) : Choreographer.FrameCallback {
    val vc = WeakReference(vc0)
    var isPaused = false
    private var valid = false
    fun add() { valid = true; Choreographer.getInstance().postFrameCallback(this) }
    fun invalidate() { valid = false; Choreographer.getInstance().removeFrameCallback(this) }
    override fun doFrame(ns: Long) {
        if (!valid) return
        val v = vc.get()
        if (v != null && !isPaused) v.doFrame()
        Choreographer.getInstance().postFrameCallback(this)
    }
}

/** LinearLayout-with-weights replacement for the editor root (iOS RootLayout). */
class RootLayout : UiView(appContext!!) {
    var top: UiView? = null
    var previewBox: UiView? = null
    var tr: UiView? = null
    var timeline: UiView? = null
    var toolbarBox: UiView? = null
    var panelBox: UiView? = null

    private fun panelH(): Float =
        if (rectWidth() > rectHeight()) (if (Dev.isPad) 340f else 220f) else (if (Dev.isPad) 420f else 300f)

    private fun lay(its: List<Triple<UiView?, CGFloat, Float>>, r: CGRect) {
        val vis = its.mapNotNull { it ->
            val v = it.first ?: return@mapNotNull null
            if (v.parent === this && !v.isHidden) Triple(v, it.second, it.third) else null
        }
        var fixed = 0f
        var tw = 0f
        for ((_, h, w) in vis) {
            val hh = if (h < 0) panelH() else h
            if (hh > 0) fixed += hh else tw += w
        }
        val free = max(0f, r.height - fixed)
        var y = r.minY
        for ((v, h, w) in vis) {
            val hh = if (h < 0) panelH() else if (h > 0) h else (if (tw > 0) free * (w / tw) else 0f)
            v.frame = CGRect(r.minX, y, r.width, hh)
            y += hh
        }
    }

    // Show/hide of toolbar/panel boxes calls requestLayout() but the root size is unchanged, so the
    // base onLayout(changed=false) never re-ran layoutSubviews -> panelBox stayed 0x0 (bottom UI vanished).
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) { super.onLayout(true, l, t, r, b) }

    override fun layoutSubviews() {
        super.layoutSubviews()
        val area = CGRect(0f, 0f, rectWidth(), rectHeight())
        if (rectWidth() > rectHeight()) {
            val lw = floor(area.width * 0.46f)
            lay(listOf(Triple(top, 52f, 0f), Triple(previewBox, 0f, 1f), Triple(tr, 48f, 0f)),
                CGRect(0f, 0f, lw, area.height))
            lay(listOf(Triple(timeline, 0f, 1.15f), Triple(toolbarBox, 76f, 0f), Triple(panelBox, -1f, 0f)),
                CGRect(lw, 0f, area.width - lw, area.height))
        } else {
            lay(listOf(Triple(top, 52f, 0f), Triple(previewBox, 0f, 1f), Triple(tr, 48f, 0f), Triple(timeline, 0f, 1.15f),
                Triple(toolbarBox, 76f, 0f), Triple(panelBox, -1f, 0f)), area)
        }
    }
}

/** Scroll strip for the top-bar icons (iOS TopIconScroll: hugs its content). */
class TopIconScroll : UIScrollView(appContext!!) {
    var content: UiView? = null
        set(v) { field = v; v?.let { addSubview(it) } }
    override fun layoutSubviews() {
        super.layoutSubviews()
        val c = content ?: return
        c.frame = CGRect(0f, 0f, max(rectWidth(), c.rectWidth()), rectHeight())
        contentSize = com.saiki.motion.uikit.CGSize(c.rectWidth(), rectHeight())
    }
}

/** The preview area (iOS previewBox + AspectLayout + pre-badge + cube/lock buttons). */
private class PreviewBox(val ed: EditorViewController) : UiView(appContext!!) {
    override fun layoutSubviews() {
        super.layoutSubviews()
        ed.aspect.frame = CGRect(0f, 0f, rectWidth(), rectHeight())
        ed.preBadge.frame = CGRect(8f, 6f, 150f, 16f)
        ed.s3Box.frame = CGRect(rectWidth() - 46f, 8f, 40f, 40f)
        ed.zoomLockBtn.frame = CGRect(rectWidth() - 46f, 54f, 40f, 40f)
        ed.moveLockBtn.frame = CGRect(rectWidth() - 46f, 100f, 40f, 40f)
    }
}

/** Timeline host box with the floating action bar over it. */
private class TimelineBox(val ed: EditorViewController) : UiView(appContext!!) {
    override fun layoutSubviews() {
        super.layoutSubviews()
        ed.timeline.frame = CGRect(0f, 0f, rectWidth(), rectHeight())
        val w = 4 * 52f + 16f
        ed.actionBar.frame = CGRect((rectWidth() - w) / 2, rectHeight() - 56f, w, 48f)
    }
}

class EditorViewController(val projectId: String) : UIViewController(), com.saiki.motion.ui.EditHost, com.saiki.motion.ui.EditHost2, com.saiki.motion.ui.TimelineHost2 {
    lateinit var screen: UiView

    // ---- chrome
    lateinit var preview: PreviewView
    lateinit var overlay: OverlayView
    lateinit var aspect: AspectLayout
    lateinit var timeline: TimelineView
    lateinit var titleView: UILabel
    lateinit var subView: UILabel
    lateinit var playIcon: IconView
    lateinit var markIcon: IconView
    lateinit var cubeIcon: IconView
    lateinit var mbToggle: PillToggle
    lateinit var parentIcon: IconView
    lateinit var preIcon: IconView
    lateinit var moreIcon: IconView
    lateinit var gearIcon: IconView
    lateinit var sceneSetupBtn: IconView
    lateinit var renderBtn: UiView
    lateinit var preRenderBtn: UiView           // top-bar Pre-render pill: replaces Render while a group is selected
    lateinit var preRenderPill: PillButton
    lateinit var actionBar: UiView
    lateinit var qualityChip: ChipView
    lateinit var toolbarBox: UiView
    lateinit var toolbarRow: EHStack
    lateinit var panelBox: PanelBox
    lateinit var panelList: EVStack
    lateinit var diamondSide: IconView
    var xformTab = 0
    var scaleLinked = true
    var sepDims = true
    var moveMode = false
    lateinit var s3Box: UiView
    lateinit var zoomLockBtn: UiView
    lateinit var moveLockBtn: UiView
    lateinit var rootLayout: RootLayout
        lateinit var preBadge: com.saiki.motion.uikit.UILabel

    var selId = -1                 // PORT NOTE: Kotlin `selectedId` property
    var panel = 0
    var fxTab = 0
    var fxCatName = ""             // effect browser category filter ("" = all)
    var fxCat = 0                  // kept for parity (unused in Kotlin too)
    var playing = false
        set(v) { field = v; FrameCache.playing = v }
    var scrubEndWork: Runnable? = null
    // live render cache (see Editor/EditorLiveCache.swift)
    var liveTimer: Runnable? = null
    var liveTimerOn = false
    var lastActivity: Double = 0.0
    var liveNextAt: Double = 0.0
    var liveBusy = false
    var preNextAt: Double = 0.0    // pre-render (see EditorLiveCache.swift)
    var preBurst = false
    var lastTimelineRefresh: Double = 0.0
    var lastTs: Double = 0.0
    var autoKeyOn = false          // PORT NOTE: Kotlin `autoKey` property
    var quality = 1
    var graphProp = ""
    var curveClip: Key? = null
    var graphKey = 0
    var graphTab = 1               // graph editor view: 0 ease / 1 value / 2 speed
    var graphOverlayView: UiView? = null      // big graph editor panel (EditorGraph.swift)
    var selKey = ""
    var textTab = 0
    val players = HashMap<Int, AVAudioPlayer>()
    val playerFx = HashMap<Int, String>()      // effect-chain key each player was loaded with ("" = dry file)
    var fxRefreshWork: Runnable? = null
    val liveFx = com.saiki.motion.core.AudioFxLive
    val startingAudio = HashSet<Int>()
    val prepared = HashSet<Int>()
    val audioLead = 110
    val multi = mutableListOf<Int>()          // LinkedHashSet semantics: ordered + unique
    var multiMode = false
    val clipboard = mutableListOf<Layer>()
    var propsClip: Layer? = null              // Layers > Properties

    val expanded = HashSet<String>()

    class Row(val slider: com.saiki.motion.ui.RulerSlider, val d: com.saiki.motion.core.PropDef, val layer: Layer)
    val rows = mutableListOf<Row>()
    var undoStack = mutableListOf<String>()   // Kotlin `undo`
    var redoStack = mutableListOf<String>()   // Kotlin `redo`

    var fxQuery = ""
    class FxSnap(val id: String, val tracks: List<Pair<String, org.json.JSONObject>>, val inputs: Map<String, Int>, val off: Boolean)
    val fxClip = mutableListOf<FxSnap>()

    var pendingPick = 0
    var kbInset: CGFloat = 0f

    private var displayLink: DisplayLinkProxy? = null

    // ---- autosave architecture (rounds 11/14/19)
    var dirty = false                       // unsaved edits exist
    var lastEditTs: Double = 0.0            // when the last edit landed
    var saveWork: Runnable? = null
    var lastSavedText = ""
    var idleSaving = false                  // re-entry guard (IDLE_SAVE lesson)

    var flareLayer: Layer? = null
    var flareBackup: org.json.JSONObject? = null
    var flareOverlay: UiView? = null
    var flareContent: EVStack? = null
    var flareTabs: TabBar? = null
    var flTab = 0
    var flSel = 0
    var flBrowse = false
    var flIsNew = false
    var flareParent: UiView? = null
    var flareDriver: com.saiki.motion.ui.FlareDriver? = null
    var flareSweepBase: Pair<Float, Float>? = null

    // ================================================================ lifecycle

    override fun viewDidLoad() {
        super.viewDidLoad()
        EffectGuard.onDone = { msg ->
            if (msg != null) toast(msg)
            refreshPanel(); preview.requestDraw()
        }
        // PORT NOTE: MetalEffects.readyNote has no Kotlin twin; the Vulkan core reports
        // fxReadyCount() and the render path redraws anyway.
        Rig.onLiveTick = { render() }     // live (slider-driven) physics keeps re-rendering while it settles
        Registry.initialize()
        CrashLog.install()
        FreezeWatchdog.start()
        val p = Projects.load(projectId)
        if (p != null) {
            Editor.project = p
        } else {
            Editor.project = Project(name = "Untitled")
            Editor.project.id = projectId
            // never silently replace a file that exists but could not be read
            val u = Projects.fileURL(projectId)
            if (u.exists()) {
                try { u.copyTo(File(u.parentFile, u.nameWithoutExtension + ".corrupt"), overwrite = true) } catch (_: Exception) {}
                Handler(Looper.getMainLooper()).postDelayed({ Snack.show("Project file was unreadable — a copy was kept as .corrupt") }, 500)
            }
        }
        lastSavedText = Editor.project.toJson().toCompact()
        Editor.sceneIndex = 0
        Editor.time = 0f
        selId = -1
        buildUi()
        refreshAll()
        safe("previews") {
            // cards pick thumbnails up from the cache themselves — no full panel rebuild
            EffectThumbs.generate(this, preview) { }
        }
        // iOS also saves on willResignActive/didEnterBackground/willTerminate; on Android the
        // debounced scheduleSave + viewWillDisappear save cover the same guarantees — PORT NOTE.
    }

    override fun viewWillAppear(animated: Boolean) {
        super.viewWillAppear(animated)
        preview.requestDraw()      // Kotlin: preview.onResume() (GLKView has no pause; redraw)
        FrameCache.suspended = false
        startLiveCache()
    }

    override fun viewWillDisappear(animated: Boolean) {
        super.viewWillDisappear(animated)
        playing = false
        stopAudio()
        displayLink?.isPaused = true
        playIcon.set("play", C.GREEN)
        saveThumbnail()
        preview.releaseVideos()    // Kotlin: preview.onPause()
        saveWork?.let { Handler(Looper.getMainLooper()).removeCallbacks(it) }
        FrameCache.playing = false
        stopLiveCache()
        Projects.save(projectId, Editor.project)
        dirty = false              // the explicit save above covers everything
        FreezeWatchdog.setDirty(false)
    }

    /** iOS deinit: displayLink invalidate + observers + audio release (called when popped). */
    fun deinitLike() {
        displayLink?.invalidate()
        displayLink = null
        releaseAudio()
    }

    // ================================================================ autosave (rounds 11/14/19)

    /** Every edit funnels through pushUndo()/beginEdit(), so this is the one place that marks the project dirty. */
    fun markDirty() {
        dirty = true
        lastActivity = now()
        FrameCache.bump()              // every edit makes cached frames stale
        if (PreRender.groups(Editor.scene).isNotEmpty()) {
            preBurst = true; preNextAt = 0.0   // re-bake right away, not only after the idle save
            updatePreBadge()                  // badge must stop claiming "PRE-RENDERED ✓" at once
            val l = selected()
            if (l != null && l.type == LayerType.GROUP) refreshTitle()
        }
        lastEditTs = now()
        scheduleSave()
        FreezeWatchdog.setDirty(true)
        CrashLog.note("edit")
    }

    /** A debounced save fires ~0.4 s after the last edit (see EditorViewController.swift:407 round-19 note). */
    fun scheduleSave() {
        saveWork?.let { Handler(Looper.getMainLooper()).removeCallbacks(it) }
        val w = Runnable { saveNow() }
        saveWork = w
        Handler(Looper.getMainLooper()).postDelayed(w, 400)
    }

    /** Saves whenever the serialized project differs from what is on disk. */
    fun saveNow() {
        saveWork?.let { Handler(Looper.getMainLooper()).removeCallbacks(it) }
        if (idleSaving) return
        idleSaving = true
        try {
            // updatedAt is rewritten by every save, so it must not take part in the comparison.
            val stamp = Editor.project.updatedAt
            Editor.project.updatedAt = 0L
            val text = Editor.project.toJson().toCompact()
            Editor.project.updatedAt = stamp
            if (text == lastSavedText) { dirty = false; FreezeWatchdog.setDirty(false); return }
            val firstSave = lastSavedText.isEmpty()
            lastSavedText = text
            if (!firstSave) {
                FrameCache.bump()                 // the picture changed → cached frames are stale
                if (PreRender.groups(Editor.scene).isNotEmpty()) { preBurst = true; preNextAt = 0.0 }
            }
            CrashLog.note("save")
            Projects.save(projectId, Editor.project)
            if (Projects.lastError != null) { toast("Save failed: " + Projects.lastError); lastSavedText = "" }
            dirty = Projects.lastError != null
            FreezeWatchdog.setDirty(false)
        } finally { idleSaving = false }
    }

    fun maybeIdleSave() {
        if (!dirty || idleSaving) return
        if (now() - lastEditTs < 10.0) return
        idleSaving = true
        CrashLog.note("save")
        Projects.save(projectId, Editor.project)
        dirty = false
        FreezeWatchdog.setDirty(false)
        idleSaving = false
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        rootLayout.frame = CGRect(0f, 0f, view.rectWidth(), view.rectHeight())
        applyFullPanelFrame()
        layoutGraphOverlay()
    }

    /** Frames the big graph editor overlay (EditorGraph.swift presentGraphOverlay): portrait = bottom
     *  ~58% of the screen, landscape = right ~56%, inside the safe area. */
    fun layoutGraphOverlay() {
        val box = graphOverlayView ?: return
        val host = view
        val sa = host.safeAreaInsets
        if (host.rectWidth() > host.rectHeight()) {
            val w = host.rectWidth() * 0.56f
            box.frame = CGRect(host.rectWidth() - w, sa.top, w, max(0f, host.rectHeight() - sa.top - sa.bottom))
        } else {
            val h = host.rectHeight() * 0.58f
            box.frame = CGRect(0f, host.rectHeight() - sa.bottom - h, host.rectWidth(), h)
        }
    }

    fun toast(s: String) { Snack.show(this, s) }

    /** Snapshot of the comp for the My Playground card. */
    fun saveThumbnail() {
        if (preview.rectWidth() <= 1f || preview.rectHeight() <= 1f) return
        try {
            val w = 360f
            val h = max(1f, w * preview.rectHeight() / preview.rectWidth())
            val img = Bitmap.createBitmap(w.toInt(), h.toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            preview.draw(Canvas(img))
            Projects.thumbFile(projectId).outputStream().use { img.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        } catch (_: Exception) {}
    }

    fun safe(step: String, block: () -> Unit) {
        try { block() } catch (e: Exception) {
            var m = e.message ?: ""
            if (m.isEmpty()) m = e.javaClass.simpleName
            toast(step + ": " + m)
        }
    }

    fun now(): Double = System.nanoTime() / 1e9

    // ================================================================ UI skeleton (buildUi)

    fun buildUi() {
                view.setBackgroundColor(C.BG)

        // ---- top bar
        val top = hRow()
        addIcon(top, icon("back", C.GREEN) { onBack() }, 40f)
        val tcol = vStack()
        titleView = UILabel()
        titleView.textColor = argbToUIColor(C.TEXT)
        titleView.font = boldFont(17f)
        titleView.numberOfLines = 1
        subView = UILabel()
        subView.textColor = argbToUIColor(C.GREEN)
        subView.font = monoTimeFontS(11f)
        subView.numberOfLines = 1
        tcol.add(EBox(titleView, 0f, 20f, 0f, 1f, 0f, 1f))
        tcol.add(EBox(subView, 0f, 14f, 0f, 1f, 0f, 1f))
        top.add(growBox(tcol))
        // The tool icons live in a horizontal strip so a narrow phone scrolls them instead of
        // squeezing (and losing) the Render button; Render itself is pinned outside the strip.
        val iconRow = hRow()
        val iconScroll = TopIconScroll()
        iconScroll.showsHorizontalScrollIndicator = false
        iconScroll.content = iconRow
        cubeIcon = icon("cube") { toggle3d() }
        addIcon(iconRow, cubeIcon, 40f)
        mbToggle = PillToggle()
        mbToggle.onClick = {
            val l = selected()
            if (l != null) {
                pushUndo()
                l.mblur = !l.mblur
                mbToggle.on = l.mblur
                refreshPanel(); render()
            }
        }
        mbToggle.onLong = {
            val l = selected()
            if (l != null) showMotionBlurSettings(l)
        }
        iconRow.add(EBox(mbToggle, 52f, 40f, 0f, 0f, 0f, 0f))
        parentIcon = icon("dup") {
            val l = selected() ?: return@icon
            showParentPopup(l, parentIcon)
        }
        addIcon(iconRow, parentIcon, 40f)
        // Pre-render (groups only): bake the group to frames; playback + render use those
        preIcon = icon("prerender") {
            val l = selected() ?: return@icon
            if (l.type == LayerType.GROUP) togglePreRender(l)
        }
        addIcon(iconRow, preIcon, 40f)
        moreIcon = icon("more") { showLayersMenu() }
        addIcon(iconRow, moreIcon, 40f)
        gearIcon = icon("gear") { showSceneDialog() }
        addIcon(iconRow, gearIcon, 40f)
        sceneSetupBtn = icon("camera") { toggleSceneSetup() }
        addIcon(iconRow, sceneSetupBtn, 40f)
        top.add(growBox(iconScroll))
        renderBtn = EBox(pill("Render", "export", C.GREEN, C.ONDARK) { showRenderDialog() }, 104f, 38f, 0f, 0f, 0f, 0f)
        top.add(renderBtn)
        preRenderPill = pill("Pre-render", "prerender", C.GREEN, C.ONDARK) {
            val l = selected() ?: return@pill
            if (l.type == LayerType.GROUP) togglePreRender(l)
        }
        preRenderBtn = EBox(preRenderPill, 128f, 38f, 0f, 0f, 0f, 0f)
        preRenderBtn.isHidden = true
        top.add(preRenderBtn)

        // ---- preview area
        val previewBox = PreviewBox(this)
        previewBox.setBackgroundColor(0xFF161618.toInt())
        aspect = AspectLayout(appContext!!)
        preview = PreviewView(appContext!!)
        overlay = OverlayView(this, null)
        aspect.addSubview(preview)
        aspect.addSubview(overlay)
        previewBox.addSubview(aspect)
        aspect.enableViewportGestures(previewBox)     // two-finger zoom / pan of the comp view
        preBadge = UILabel()
        preBadge.font = monoTimeFontS(10f)
        preBadge.textColor = argbToUIColor(0xFF000000.toInt())
        preBadge.isHidden = true
        preBadge.isUserInteractionEnabled = false
        previewBox.addSubview(preBadge)
        // ---- right-edge tool column: cube button opens the Scene 3D editor
        val s3Icon = IconView("cube", C.GREEN, 22f)
        s3Icon.onClick = { Scene3DView.present(this) }
        s3Box = UiView(appContext!!)
        s3Box.setBackgroundColor(0xD9161618.toInt())
        s3Box.addSubview(s3Icon)
        s3Icon.frame = CGRect(7f, 7f, 26f, 26f)
        previewBox.addSubview(s3Box)

        fun paintLock(b: UiView, on: Boolean) {
            (b as? LockButton)?.setOn(on)
        }
        zoomLockBtn = LockButton("plus.magnifyingglass")
        zoomLockBtn.onClick = {
            aspect.zoomLocked = !aspect.zoomLocked; paintLock(zoomLockBtn, aspect.zoomLocked)
            toast(if (aspect.zoomLocked) "Zoom locked" else "Zoom unlocked")
        }
        previewBox.addSubview(zoomLockBtn)
        moveLockBtn = LockButton("arrow.up.and.down.and.arrow.left.and.right")
        moveLockBtn.onClick = {
            aspect.moveLocked = !aspect.moveLocked; paintLock(moveLockBtn, aspect.moveLocked)
            toast(if (aspect.moveLocked) "Movement locked" else "Movement unlocked")
        }
        previewBox.addSubview(moveLockBtn)

        // ---- transport row (utilities left, playback centered, history right)
        val tr = hRow()
        addIcon(tr, icon("fit") { timeline.fitToScene() }, 34f)
        qualityChip = ChipView("Full")
        qualityChip.onClick = { cycleQuality() }
        tr.add(EBox(qualityChip, 48f, 48f, 0f, 0f, 0f, 0f))
        markIcon = icon("bookmark") { toggleMarker() }
        markIcon.onLong = { nameMarker() }
        addIcon(tr, markIcon, 34f)
        tr.add(spacer())
        val playGroup = hRow()
        val prev = icon("prev") { jump(-1) }
        prev.onLong = { stepFrame(-1) }
        playGroup.add(EBox(prev, 34f, 44f, 0f, 0f, 0f, 0f))
        playIcon = IconView("play", C.GREEN, 30f)
        playIcon.onClick = { togglePlay() }
        playGroup.add(EBox(playIcon, 40f, 44f, 0f, 0f, 0f, 0f))
        val next = icon("next") { jump(1) }
        next.onLong = { stepFrame(1) }
        playGroup.add(EBox(next, 34f, 44f, 0f, 0f, 0f, 0f))
        val playPill = UiView(appContext!!)
        playPill.setBackgroundColor(0xFF241A12.toInt())
        playPill.addSubview(playGroup)
        playPill.postLayout = { w ->
            playGroup.frame = CGRect(6f, 0f, (w ?: 0f) - 12f, 44f)
        }
        tr.add(EBox(playPill, 150f, 44f, 0f, 2f, 0f, 2f))
        tr.add(spacer())
        addIcon(tr, icon("layers") { showLayersMenu() }, 34f)
        addIcon(tr, icon("undo") { doUndo() }, 34f)
        addIcon(tr, icon("redo") { doRedo() }, 34f)

        timeline = TimelineView(this, this)

        // The floating action bar over the timeline: trim in / split / trim out / delete.
        val tlBox = TimelineBox(this)
        tlBox.clipsToBounds = true          // the playhead / ruler must not bleed over the panels
        tlBox.addSubview(timeline)
        val abar = hRow()
        abar.setBackgroundColor(0xE61E1E22.toInt())
        addIcon(abar, icon("trimin") { trimTo(true) }, 52f, 48f)
        addIcon(abar, icon("split") { splitAtPlayhead(false) }, 52f, 48f)
        addIcon(abar, icon("trimout") { trimTo(false) }, 52f, 48f)
        addIcon(abar, icon("trash", C.RED) { deleteLayer() }, 52f, 48f)
        actionBar = abar
        actionBar.isHidden = true
        tlBox.addSubview(abar)

        // ---- bottom tool bar
        toolbarBox = TopIconScroll()
        toolbarBox.setBackgroundColor(C.PANEL)
        toolbarRow = hRow()
        (toolbarBox as TopIconScroll).content = toolbarRow

        // ---- property panel (side rail + scroll)
        panelBox = PanelBox(this)
        panelBox.setBackgroundColor(C.PANEL)
        panelBox.buildRail()

        // ---- root (the Kotlin LinearLayout with orientation branches)
        rootLayout = RootLayout()
        rootLayout.top = top
        rootLayout.previewBox = previewBox
        rootLayout.tr = tr
        rootLayout.timeline = tlBox
        rootLayout.toolbarBox = toolbarBox
        rootLayout.panelBox = panelBox
        // The slots must actually live in the hierarchy — RootLayout.lay() only frames
        // views whose superview is itself (placePanel() re-parents panelBox later).
        rootLayout.addSubview(top)
        rootLayout.addSubview(previewBox)
        rootLayout.addSubview(tr)
        rootLayout.addSubview(tlBox)
        rootLayout.addSubview(toolbarBox)
        rootLayout.addSubview(panelBox)
        view.addSubview(rootLayout)
        screen = view

        toolbarBox.isHidden = false
        panelBox.isHidden = true
    }

    // ================================================================ small helpers

    fun selected(): Layer? = Editor.scene.layers.firstOrNull { it.id == selId }

    fun render() {
        FreezeWatchdog.beat()          // main thread is alive (R15/R19)
        lastActivity = now()
        if (!playing) scheduleSave()   // any visible change → saved shortly after
        // draw preview and gizmo together in the same pass so the gizmo never trails the picture
        preview.requestDraw()
        overlay.setNeedsDisplay()
        timeline.setNeedsDisplay()
        updatePreBadge()
    }

    // ================================================================ refresh

    fun refreshAll() {
        aspect.ratio = Editor.project.w.toFloat() / Editor.project.h.toFloat()
        if (selected() == null) selId = -1
        safe("title") { refreshTitle() }
        safe("toolbar") { refreshToolbar() }
        safe("panel") { showBottom() }
        safe("panel") { refreshPanel() }
        safe("time") { onTimeChanged() }
        safe("audio") { ensureAudio() }
    }

    /** Hide a top-bar icon AND its fixed-width wrapper (iOS hideSlot). */
    fun hideSlot(v: UiView, hidden: Boolean) {
        v.isHidden = hidden
        val w = v.superview
        if (w != null) w.isHidden = hidden
    }

    fun refreshTitle() {
        val l = selected()
        titleView.text = l?.name ?: Editor.project.name
        val on = l != null && (l.is3d || l.type == LayerType.MODEL || l.type == LayerType.CAMERA || Xf.isParticles(l))
        cubeIcon.set("cube", if (on) C.GREEN else C.TEXT)
        val sel = l != null
        hideSlot(cubeIcon, !sel)
        hideSlot(mbToggle, !sel || l!!.type == LayerType.AUDIO)
        hideSlot(parentIcon, !sel)
        hideSlot(preIcon, !(sel && l!!.type == LayerType.GROUP))
        if (l != null && l.type == LayerType.GROUP) {
            var col = C.TEXT
            if (l.prerender && PreRender.enabled) {
                val sz = SceneRenderer.size(Editor.project, preview.quality)
                val baked = PreRender.nextMissing(l, Editor.project, Editor.scene, sz[0], sz[1], l.start) == null
                col = if (baked) C.GREEN else C.AMBER
            }
            preIcon.set("prerender", col)
        }
        updatePreBadge()
        hideSlot(moreIcon, !sel)
        hideSlot(gearIcon, sel)
        hideSlot(sceneSetupBtn, sel)
        sceneSetupBtn.set("camera", if (sceneSetupOn) C.GREEN else C.TEXT)
        val isGroup = sel && l!!.type == LayerType.GROUP
        renderBtn.isHidden = sel
        preRenderBtn.isHidden = !isGroup
        if (isGroup && l != null) {
            val on2 = l.prerender && PreRender.enabled
            preRenderPill.text = if (on2) "Un-bake" else "Pre-render"
            preRenderPill.fillColor = if (on2) C.AMBER else C.GREEN
        }
        if (l != null) {
            mbToggle.on = l.mblur
            parentIcon.set("dup", if (l.parentId >= 0) C.GREEN else C.TEXT)
        }
        actionBar.isHidden = !sel
    }

    /** The Effects panel covers the whole screen; every other panel sits under the timeline. */
    fun placePanel(full: Boolean) {
        val cur = panelBox.superview
        if (full) {
            if (cur !== screen) {
                panelBox.removeFromSuperview()
                screen.addSubview(panelBox)
            }
            screen.bringChildToFront(panelBox)
            applyFullPanelFrame()
            rootLayout.requestLayout()
        } else if (cur !== rootLayout) {
            panelBox.removeFromSuperview()
            rootLayout.addSubview(panelBox)   // re-appended last — its layout slot
            rootLayout.requestLayout()
        }
    }

    fun applyFullPanelFrame() {
        if (panelBox.superview !== screen) return
        var f = CGRect(0f, view.safeAreaInsets.top, view.rectWidth(), max(0f, view.rectHeight() - view.safeAreaInsets.top))
        f = CGRect(f.x, f.y, f.width, max(0f, f.height - kbInset))
        panelBox.frame = f
    }

    fun showBottom() {
        placePanel(panel == P_FX && fxTab == 1)
        toolbarBox.isHidden = panel != P_NONE
        panelBox.isHidden = panel == P_NONE
        rootLayout.requestLayout()   // visibility changes must re-flow the weighted layout
    }

    fun onTimeChanged() {
        syncRows()
        subView.text = timeline.timecode(Editor.time) + " / " + timeline.timecode(Editor.scene.duration)
        val has = Editor.scene.markers.any { abs(it - Editor.time) < 0.02f }
        markIcon.set(if (has) "bookmark_f" else "bookmark", if (has) C.BLUE else C.TEXT)
        render()
    }

    fun onBack() {
        if (panel != P_NONE) {
            closePanel()
        } else if (selId != -1) {
            onSelect(-1)
        } else if (navigationController != null) {
            deinitLike()
            navigationController?.popViewController(animated = true)
        } else {
            deinitLike()
            popOrDismiss(animated = true)
        }
    }

    fun openPanel(p: Int) {
        if (p != P_MEDIA && p != P_SHAPES && selected() == null) { toast("Select a layer first"); return }
        panel = p
        showBottom(); refreshPanel()
    }

    fun closePanel() { panel = P_NONE; graphOverlayView?.removeFromSuperview(); graphOverlayView = null; showBottom() }

    // ================================================================ tool bar

    fun refreshToolbar() {
        toolbarRow.clear()
        fun tool(ic: String, label: String, tint: Int = C.TEXT, click: () -> Unit) {
            val b = ToolButton(ic, label)
            b.tint = tint
            b.onClick = click
            toolbarRow.add(EBox(b, 76f, 76f, 0f, 0f, 0f, 0f))
        }
        val l = selected()
        if (l == null) {
            tool("media", "Media") { openPanel(P_MEDIA) }
            tool("text", "Text") { addLayer(LayerType.TEXT) }
            tool("solid", "Solid") { addSolid() }
            tool("adjust", "Adjustment") { addLayer(LayerType.ADJUST) }
            tool("audio", "Audio") { showAudioLibrary() }
            tool("nullobj", "Null") { addLayer(LayerType.NULL) }
            tool("shape", "Shape") { openPanel(P_SHAPES) }
            tool("shape", "Vector Pen") { openPenEditor() }
            tool("camera", "Camera") { addLayer(LayerType.CAMERA) }
            tool("particles", "Particles") { addParticles() }
            tool("flare", "Optical Flare") { showFlareLibrary() }
            tool("layers", "Group") { addLayer(LayerType.GROUP) }
            tool("puppet", "Create Rig") { createRig() }
            tool("cube", "3D") { show3DImport() }
            return
        }
        toolbarRow.add(EBox(icon("back", C.GREEN) { onSelect(-1) }, 44f, 76f, 0f, 0f, 0f, 0f))
        if (l.type == LayerType.VIDEO) tool("audio", "Extract audio") { extractAudio(l) }
        if (l.type == LayerType.GROUP && l.rig != null) {
            tool("puppet", "Cubism Editor", C.GREEN) { openRigEditor(l) }
            tool("sparkle", "Animate Rig", C.GREEN) { openPanel(P_RIGANIM) }
        }
        tool("edit", "Edit") { openPanel(P_EDIT) }
        tool("edit", "Rename") { renameLayer(l) }
        tool("move", "Transform") { openPanel(P_XFORM) }
        if (l.isRenderable() || l.type == LayerType.GROUP || l.type == LayerType.ADJUST) {
            tool("sparkle", "Effects") { openPanel(P_FX) }
            tool("drop", "Blending") { openPanel(P_BLEND) }
            tool("speed", "Speed") { openPanel(P_SPEED) }
            if (l.type == LayerType.IMAGE || l.type == LayerType.VIDEO || l.type == LayerType.TEXT || l.type == LayerType.GROUP) {
                tool("puppet", "Puppet") { openPuppet() }
            }
        }
        if (l.type == LayerType.AUDIO || l.type == LayerType.NULL) {       // audio: audio effects only · null: movement effects only
            tool("sparkle", "Effects") { openPanel(P_FX) }
        }
        if (l.isRenderable() && l.rig == null && l.deformer == 0) {
            tool("layers", "To Rig") { importToRig(l) }     // last: rarely needed now
        }
    }

    // ================================================================ playback (Choreographer → CADisplayLink)

    fun doFrame() {
        FreezeWatchdog.beat()          // playback frames count as liveness
        maybeIdleSave()
        if (!playing) return
        val ts = now()
        if (lastTs != 0.0 && ts > lastTs) {
            var t = Editor.time + (ts - lastTs).toFloat()
            var wrapped = false
            if (t >= Editor.scene.duration) { t = 0f; wrapped = true }
            Editor.time = t
            if (wrapped) startAudio() else tickAudio()
            onTimeChanged()
        }
        lastTs = ts
    }

    fun togglePlay() {
        CrashLog.note("play")
        playing = !playing
        playIcon.set(if (playing) "pause" else "play", C.GREEN)
        if (playing) {
            lastTs = 0.0
            if (displayLink == null) {
                val link = DisplayLinkProxy(this)
                link.add()
                displayLink = link
            }
            displayLink?.isPaused = false
            startAudio()
        } else {
            displayLink?.isPaused = true
            stopAudio()
        }
    }

    fun stepFrame(dir: Int) {
        Editor.time = clamp(Editor.time + dir.toFloat() / Editor.project.fps, 0f, Editor.scene.duration)
        onTimeChanged()
    }

    fun jump(dir: Int) {
        // stops: start + end of the comp, the user's markers, and the selected layer's keyframes
        val times = mutableListOf(0f, Editor.scene.duration)
        times.addAll(Editor.scene.markers)
        selected()?.let { l ->
            for ((_, tr) in l.props) for (k in tr.keys) times.add(k.t)
        }
        val sorted = times.filter { it >= 0f && it <= Editor.scene.duration }.sorted()
        val nowT = Editor.time
        val target = if (dir > 0) sorted.firstOrNull { it > nowT + 0.02f } else sorted.lastOrNull { it < nowT - 0.02f }
        if (target != null) { Editor.time = target; onTimeChanged() }
    }

    fun toggleMarker() {
        val ms = Editor.scene.markers.toMutableList()
        val ex = ms.firstOrNull { abs(it - Editor.time) < 0.02f }
        pushUndo()
        if (ex != null) {
            Editor.scene.setMarkerName(ex, "")
            ms.removeAll { it == ex }
        } else {
            ms.add(Editor.time)
        }
        Editor.scene.markers = ms
        onTimeChanged()
    }

    fun nameMarker() {
        val ms = Editor.scene.markers.toMutableList()
        var m: Float? = ms.firstOrNull { abs(it - Editor.time) < 0.02f }
        if (m == null) {
            pushUndo()
            ms.add(Editor.time)
            m = Editor.time
            Editor.scene.markers = ms
            onTimeChanged()
        }
        val tm = m ?: return
        val box = vStack()
        text(box, timeline.timecode(tm), C.DIM, 13f)
        val et = makeField("")
        et.placeholder = "Marker name"
        et.text = Editor.scene.markerName(tm) ?: ""
        box.add(EBox(et, 0f, 44f, 4f, 0f, 4f, 0f))
        text(box, "Expressions can reach this marker by name:  marker.key(\"name\")", C.DIM, 12f)
        Dlg(this).setTitle("Name marker").setView(box).setPositiveButton("Save") { _, _ ->
            pushUndo()
            Editor.scene.setMarkerName(tm, et.text)
            timeline.setNeedsDisplay()
            render()
        }.setNegativeButton("Cancel", null).show()
    }

    fun cycleQuality() {
        quality = if (quality == 1) 2 else (if (quality == 2) 4 else 1)
        preview.quality = quality
        qualityChip.text = if (quality == 1) "Full" else (if (quality == 2) "1/2" else "1/4")
        qualityChip.setNeedsDisplay()
        render()
    }

    // ================================================================ undo / redo

    fun snapshot(): String = Editor.project.toJson().toCompact()

    fun pushUndo() {
        markDirty()                    // every edit passes through here (R11/R19)
        val s = snapshot()
        if (undoStack.lastOrNull() == s) return
        undoStack.add(s)
        if (undoStack.size > 40) undoStack.removeAt(0)
        redoStack.clear()
    }

    fun restore(js: String) {
        FrameCache.bump()
        markDirty()
        val o = com.saiki.motion.core.parseJson(js)
        if (o != null) Editor.project = Project.fromJson(o)
        // a restored project with zero scenes must not wedge sceneIndex at -1
        if (Editor.project.scenes.isEmpty()) {
            Editor.project.scenes = mutableListOf(Scene("Scene 1"))
        }
        Editor.sceneIndex = clamp(Editor.sceneIndex, 0, Editor.project.scenes.size - 1)
        Editor.time = clamp(Editor.time, 0f, Editor.scene.duration)
        refreshAll()
    }

    fun doUndo() {
        if (undoStack.isEmpty()) { toast("Nothing to undo"); return }
        redoStack.add(snapshot())
        val js = undoStack.removeAt(undoStack.size - 1)
        restore(js)
    }

    fun doRedo() {
        if (redoStack.isEmpty()) { toast("Nothing to redo"); return }
        undoStack.add(snapshot())
        val js = redoStack.removeAt(redoStack.size - 1)
        restore(js)
    }

    // ================================================================ hosts (EditHost / TimelineHost)

    override fun selectedLayer(): Layer? = selected()
    override fun autoKey(): Boolean = autoKeyOn
    override fun beginEdit() { pushUndo() }
    override fun onEdited() { syncRows(); render() }
    override fun selectedId(): Int = selId
    override fun isSelected(id: Int): Boolean = id == selId || multi.contains(id)
    override fun puppetPanelOpen(): Boolean { return panel == P_PUPPET }
    override fun gradientKnobsOn(): Boolean { return panel == P_EDIT }
    override fun moveAnchor(l: Layer, ax: Float, ay: Float) { setAnchorKeepVisual(l, ax, ay); onEdited() }
    override fun onSeek(t: Float) {
        FrameCache.scrubbing = true
        Editor.time = t
        onTimeChanged()
        scrubEndWork?.let { Handler(Looper.getMainLooper()).removeCallbacks(it) }
        val w = Runnable { FrameCache.scrubbing = false }
        scrubEndWork = w
        Handler(Looper.getMainLooper()).postDelayed(w, 350)
    }

    override fun onSelect(id: Int) {
        if (multiMode && id >= 0) {
            val i = multi.indexOf(id)
            if (i >= 0) multi.removeAt(i) else multi.add(id)
            selId = id
            panel = P_NONE
            refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
            return
        }
        if (!multiMode) multi.clear()
        selId = id
        panel = if (id >= 0 && selected()?.type == LayerType.TEXT) P_EDIT else P_NONE
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
    }

    override fun onToggleVisible(l: Layer) {
        pushUndo()
        l.visible = !l.visible
        render()
    }

    override fun onTimingChanged() { render() }

    override fun onReorder(l: Layer, listIndex: Int) {
        pushUndo()
        val ls = Editor.scene.layers
        ls.removeAll { it === l }
        ls.add(clamp(listIndex, 0, ls.size), l)
        render()
    }

    override fun onKeyTap(l: Layer, key: String, idx: Int) {
        selId = l.id
        graphProp = key
        graphKey = idx
        val ks = l.track(key).keys
        if (idx in ks.indices) Editor.time = ks[idx].t
        // Tapping a keyframe only selects it and moves the playhead; it no longer forces the
        // graph panel open (use the graph button). If the graph is already open it follows.
        selKey = key
        if (panel == P_GRAPH) { refreshTitle(); refreshToolbar(); showBottom(); refreshPanel() }
        onTimeChanged()
    }
}
