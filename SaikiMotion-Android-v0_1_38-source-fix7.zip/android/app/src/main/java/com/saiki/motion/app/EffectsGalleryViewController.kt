@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.app

import com.saiki.motion.core.EffectDef
import com.saiki.motion.core.EffectThumbs
import com.saiki.motion.core.L10n
import com.saiki.motion.core.Registry
import com.saiki.motion.ui.C
import com.saiki.motion.ui.EffectCard
import com.saiki.motion.ui.fillRoundRect
import com.saiki.motion.ui.sysFont
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UICollectionView
import com.saiki.motion.uikit.UICollectionViewCell
import com.saiki.motion.uikit.UICollectionViewDataSource
import com.saiki.motion.uikit.UICollectionViewDelegate
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIEdgeInsets
import com.saiki.motion.uikit.capScrollOf
import com.saiki.motion.uikit.argbToUIColor
import java.util.Locale

// Port of Sources/App/EffectsGalleryViewController.swift — the effects browser (Community tab).
// Grid of Registry entries rendered through EffectThumbs. Browse mode shows before/after cards
// and an info page per effect; pick mode hands a def back to the caller.

class EffectsGalleryViewController(private val mode: Mode) : UIViewController() {

    enum class Mode { pick, browse }

    var onPick: ((EffectDef) -> Unit)? = null

    private var defs: List<EffectDef> = emptyList()
    private var searchQuery = ""
    private var collectionView: UICollectionView? = null

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        title = L10n.tr("Example effects")

        val layout = UICollectionView(com.saiki.motion.uikit.appContext!!)
        layout.itemSize = CGSize(116f, 168f)
        layout.sectionInset = UIEdgeInsets(12f, 12f, 12f, 12f)
        layout.minimumInteritemSpacing = 10f
        layout.minimumLineSpacing = 14f
        layout.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        layout.dataSource = object : UICollectionViewDataSource {
            override fun numberOfItems(cv: UICollectionView): Int = defs.count()
            override fun cellForItem(cv: UICollectionView, index: Int): UICollectionViewCell {
                val cell = EffectCell()
                defs.getOrNull(index)?.let { cell.show(it) }
                return cell
            }
        }
        layout.delegate = object : UICollectionViewDelegate {
            override fun didSelectItem(cv: UICollectionView, index: Int) {
                defs.getOrNull(index)?.let { pick(it) }
            }
        }
        view.addView(layout)
        collectionView = layout

        reload()
        EffectThumbs.generate(this, null) {
            collectionView?.reloadData()
        }
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        val top = view.safeAreaInsets.top
        collectionView?.frame = CGRect(0f, top, view.rectWidth(), (view.rectHeight() - top).coerceAtLeast(0f))
        collectionView?.reloadData()
    }

    private fun reload() {
        Registry.initialize()
        val q = searchQuery.trim().lowercase()
        val interesting = Registry.order.filter { d -> d.kind != 1 }   // hide the internal single-instance helpers
        defs = if (q.isEmpty()) interesting else interesting.filter {
            it.name.lowercase().contains(q) || it.desc.lowercase().contains(q)
        }
    }

    private fun pick(def: EffectDef) {
        if (mode == Mode.pick) {
            onPick?.invoke(def)
            popOrDismiss(animated = true)
        } else {
            pushScreen(EffectInfoViewController(def), animated = true)
        }
    }
}

/// Card cell: before/after thumbnail + name + category.
class EffectCell : UICollectionViewCell() {
    private val card = EffectCard("", "")
    private var defId: String? = null

    init {
        card.frame = CGRect(0f, 0f, 0f, 0f)
        contentView.addView(card)
    }

    override fun layoutSubviews() {
        super.layoutSubviews()
        card.frame = CGRect(0f, 0f, contentView.rectWidth(), contentView.rectHeight())
    }

    fun show(def: EffectDef) {
        defId = def.id
        card.name = def.name
        card.category = def.category
        card.anim = def.previewAnim
        card.thumbId = def.id
        card.origId = EffectThumbs.origKey(def.id)
        card.before = EffectThumbs.cache[EffectThumbs.origKey(def.id)]?.let { UIImage(it) }
            ?: EffectThumbs.raw(def.id)?.let { UIImage(it) }
        card.after = EffectThumbs.cache[def.id]?.let { UIImage(it) }
        card.setNeedsDisplay()
    }
}

/// Read-only viewer for one effect definition.
class EffectInfoViewController(private val def: EffectDef) : UIViewController() {

    private val scroll = capScrollOf(com.saiki.motion.uikit.appContext!!)
    private val col = UiView(scroll.context)

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        title = def.name
        view.addView(scroll)
        scroll.addView(col)

        val card = EffectCard(def.name, def.category)
        card.anim = def.previewAnim
        card.thumbId = def.id
        card.origId = EffectThumbs.origKey(def.id)
        card.before = EffectThumbs.cache[EffectThumbs.origKey(def.id)]?.let { UIImage(it) }
            ?: EffectThumbs.raw(def.id)?.let { UIImage(it) }
        card.after = EffectThumbs.cache[def.id]?.let { UIImage(it) }
        card.frame = CGRect(0f, 0f, 10f, 240f)
        col.addView(card)

        var text = "${def.name} — ${def.category}\n\n${def.desc}\n\nParameters:\n"
        if (def.props.isEmpty()) text += "  none\n"
        for (p in def.props) {
            val opts = p.options
            if (opts != null) {
                text += "  • ${p.label} — ${opts.joinToString(" / ")}\n"
            } else {
                text += String.format(Locale.US, "  • %s — %g … %g (default %g)\n", p.label, p.min.toDouble(), p.max.toDouble(), p.def.toDouble())
            }
        }
        if (def.colors.isNotEmpty()) {
            text += "\nColors:\n"
            for (cp in def.colors) {
                text += String.format(Locale.US, "  • %s — #%08X\n", cp.label, cp.def.toLong() and 0xFFFFFFFFL)
            }
        }
        if (def.inputs.isNotEmpty()) {
            text += "\nLayer inputs: " + def.inputs.joinToString(", ") + "\n"
        }
        if (!def.builtin) text += "\nCustom effect"
        Registry.errors[def.id]?.let { err -> text += "\n\nShader error:\n$err" }

        val tv = MLText(text, 13f, com.saiki.motion.ui.C.TEXT)
        col.addView(tv)
        layoutDone = {
            val w = view.rectWidth()
            scroll.frame = CGRect(0f, view.safeAreaInsets.top, w, view.rectHeight() - view.safeAreaInsets.top)
            val cw = w - 16f - 16f
            var y = 12f
            card.frame = CGRect(0f, y, cw, 240f); y += 240f + 8f
            tv.build(cw); tv.frame = CGRect(0f, y, cw, tv.height()); y += tv.height() + 12f
            col.frame = CGRect(16f, 0f, cw, y)
            scroll.contentSize = CGSize(w, y + 24f)
        }
        layoutDone?.invoke()
    }

    private var layoutDone: (() -> Unit)? = null

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        layoutDone?.invoke()
    }
}

/// UITableViewCell with a working detail label under registration.
class SubtitleCell : com.saiki.motion.uikit.UITableViewCell() {
    init {
        // .subtitle style twin: the detail label exists from the start
        detailTextLabel = com.saiki.motion.uikit.UILabel()
    }
}
