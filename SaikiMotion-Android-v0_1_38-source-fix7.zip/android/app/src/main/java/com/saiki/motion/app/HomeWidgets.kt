@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.app

import com.saiki.motion.ui.C
import com.saiki.motion.ui.Icons
import com.saiki.motion.ui.TapView
import com.saiki.motion.ui.drawText
import com.saiki.motion.ui.measureText
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.CGLineCap
import com.saiki.motion.uikit.CGLineJoin
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIBezierPath
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import kotlin.math.min

// Port of Sources/App/HomeWidgets.swift — home-screen widgets: the five-tab bar button
// with its icons, the big action buttons and the segmented pills of the creation sheet.

/** One bottom-bar item: custom icon above an uppercase letter-spaced label. */
class HomeTabButton : TapView() {

    var icon: String = ""
        set(v) { field = v; iconView.name = icon; iconView.setNeedsDisplay() }
    var on: Boolean = false
        set(v) {
            field = v
            iconView.color = if (on) C.GREEN else C.DIM
            iconView.setNeedsDisplay()
            label.textColor = com.saiki.motion.uikit.argbToUIColor(if (on) C.GREEN else C.DIM)
        }
    var tapped: (() -> Unit)? = null

    private val iconView = TabIcon()
    private val label = UILabel()

    init {
        onClick = { tapped?.invoke() }
        iconView.frame = CGRect(0f, 0f, 24f, 24f)
        addSubview(iconView)
        label.font = com.saiki.motion.uikit.UIFont.semiboldSystemFont(9f)
        label.textAlignment = NSTextAlignment.center
        addSubview(label)
    }

    fun setLabel(a: com.saiki.motion.uikit.NSAttributedString) {
        label.attributedText = a
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.8f
        requestLayout()
    }

    override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth()
        iconView.frame = CGRect(w / 2 - 12f, 7f, 24f, 24f)
        label.frame = CGRect(2f, 7f + 24f + 3f, w - 4f, 14f)
    }
}

/** The five tab icons (person / film frame / sparkles / two people / toolbox / grid with +). */
class TabIcon : UiView(com.saiki.motion.uikit.appContext!!) {

    var color: Int = C.DIM
    var name: String = ""

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val s = min(rect.width, rect.height)
        c.saveGState()
        c.translateBy(rect.midX - s / 2, rect.midY - s / 2)
        c.scaleBy(s / 24, s / 24)
        c.setStrokeColor(color)
        c.setFillColor(color)
        c.setLineWidth(1.8f)
        c.setLineCap(CGLineCap.round)
        c.setLineJoin(CGLineJoin.round)

        fun star(cx: CGFloat, cy: CGFloat, r: CGFloat) {
            val p = com.saiki.motion.uikit.CGPath()
            p.move(CGPoint(cx, cy - r))
            p.addQuadCurve(to = CGPoint(cx + r, cy), control = CGPoint(cx + r * 0.18f, cy - r * 0.18f))
            p.addQuadCurve(to = CGPoint(cx, cy + r), control = CGPoint(cx + r * 0.18f, cy + r * 0.18f))
            p.addQuadCurve(to = CGPoint(cx - r, cy), control = CGPoint(cx - r * 0.18f, cy + r * 0.18f))
            p.addQuadCurve(to = CGPoint(cx, cy - r), control = CGPoint(cx - r * 0.18f, cy - r * 0.18f))
            p.closeSubpath()
            c.addPath(p.path)
            c.fillPath()
        }

        when (name) {
            "account" -> {
                c.strokeEllipse(CGRect(8.4f, 3.6f, 7.2f, 7.2f))
                val body = com.saiki.motion.uikit.CGPath()
                body.addArc(CGPoint(12f, 21f), 8.4f, Math.PI.toFloat(), 0f, true)
                c.addPath(body.path)
                c.strokePath()
            }
            "film" -> {
                val r = UIBezierPath(CGRect(3.5f, 4.5f, 17f, 15f), cornerRadius = 2.5f)
                c.addPath(r.cgPath); c.strokePath()
                val inner = UIBezierPath(CGRect(8f, 7.5f, 8f, 9f), cornerRadius = 1.5f)
                c.addPath(inner.cgPath); c.strokePath()
                for (y in listOf<CGFloat>(7f, 13f)) {
                    c.fill(CGRect(5.4f, y, 1.6f, 2.6f))
                    c.fill(CGRect(17f, y, 1.6f, 2.6f))
                }
            }
            "sparkle_tab" -> {
                star(10f, 10f, 6.5f)
                star(17f, 16.5f, 3.6f)
                c.setLineWidth(1.6f)
                val plus = com.saiki.motion.uikit.CGPath()
                plus.move(CGPoint(17.5f, 6.5f)); plus.addLine(CGPoint(21.5f, 6.5f))
                plus.move(CGPoint(19.5f, 4.5f)); plus.addLine(CGPoint(19.5f, 8.5f))
                c.addPath(plus.path); c.strokePath()
            }
            "people" -> {
                c.setLineWidth(1.6f)
                c.strokeEllipse(CGRect(4.2f, 6.2f, 6f, 6f))
                val b1 = com.saiki.motion.uikit.CGPath()
                b1.addArc(CGPoint(7.2f, 19.5f), 6.4f, Math.PI.toFloat(), 0f, true)
                c.addPath(b1.path); c.strokePath()
                c.strokeEllipse(CGRect(13.8f, 7.2f, 5.4f, 5.4f))
                val b2 = com.saiki.motion.uikit.CGPath()
                b2.addArc(CGPoint(16.5f, 19.5f), 5.8f, (Math.PI * 1.12).toFloat(), (-0.12 * Math.PI).toFloat(), true)
                c.addPath(b2.path); c.strokePath()
            }
            "tools" -> {
                // toolbox: body, handle, lid line, latch
                val body = UIBezierPath(CGRect(3.5f, 8.5f, 17f, 11.5f), cornerRadius = 2.4f)
                c.addPath(body.cgPath); c.strokePath()
                val handle = com.saiki.motion.uikit.CGPath()
                handle.move(CGPoint(8.5f, 8.5f)); handle.addLine(CGPoint(8.5f, 6f))
                handle.addQuadCurve(to = CGPoint(9.5f, 5f), control = CGPoint(8.5f, 5f))
                handle.addLine(CGPoint(14.5f, 5f))
                handle.addQuadCurve(to = CGPoint(15.5f, 6f), control = CGPoint(15.5f, 5f))
                handle.addLine(CGPoint(15.5f, 8.5f))
                handle.move(CGPoint(3.5f, 13.2f)); handle.addLine(CGPoint(20.5f, 13.2f))
                c.addPath(handle.path); c.strokePath()
                c.fill(CGRect(10.6f, 11.6f, 2.8f, 3.2f))
            }
            "grid_plus" -> {
                for (p in listOf(CGPoint(4f, 4f), CGPoint(13.5f, 4f), CGPoint(4f, 13.5f))) {
                    val x = p.x; val y = p.y
                    val r = UIBezierPath(CGRect(x, y, 6.5f, 6.5f), cornerRadius = 1.6f)
                    c.addPath(r.cgPath); c.strokePath()
                }
                val plus = com.saiki.motion.uikit.CGPath()
                plus.move(CGPoint(16.75f, 13.5f)); plus.addLine(CGPoint(16.75f, 20f))
                plus.move(CGPoint(13.5f, 16.75f)); plus.addLine(CGPoint(20f, 16.75f))
                c.addPath(plus.path); c.strokePath()
            }
        }
        c.restoreGState()
    }
}

/** Full-width action button used by NEW PROJECT (orange) and IMPORT PROJECT FILE. */
class HomeBigButton : TapView() {

    var title: String? = null
        set(v) { field = v; label.attributedText = null; label.text = v; setNeedsDisplay() }
    var attributedTitle: com.saiki.motion.uikit.NSAttributedString? = null
        set(v) { field = v; label.attributedText = v; setNeedsDisplay() }
    private fun fH(): Float = 18f
    var bg: Int = C.GREEN
        set(v) { field = v; setNeedsDisplay() }
    var fg: Int = C.ONDARK
        set(v) { field = v; setNeedsDisplay() }
    var icon: String? = null
        set(v) { field = v; setNeedsDisplay() }
    var tapped: (() -> Unit)? = null

    private val label = UILabel()

    init {
        onClick = { tapped?.invoke() }
        clipsToBounds = true
        label.textAlignment = NSTextAlignment.center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.8f
        addSubview(label)
    }

    override fun layoutSubviews() {
        super.layoutSubviews()
        setNeedsDisplay()
        val t = label.attributedText?.string() ?: label.text ?: ""
        val sizeW = label.attributedText?.size()?.width ?: com.saiki.motion.ui.measureText(t, 15f, true)
        val tw = sizeW.coerceAtLeast(0f).coerceAtMost(boundsRect.width - 100f)
        val th = fH()
        val shift: CGFloat = if (icon != null) 12f else 0f
        label.frame = CGRect(boundsRect.midX - tw / 2 + shift, boundsRect.midY - th / 2, tw, th)
    }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        com.saiki.motion.ui.fillRoundRect(c, rect, 23f, bg)
        label.textColor = com.saiki.motion.uikit.argbToUIColor(fg)
        val t = label.attributedText?.string() ?: label.text
        if (t != null) {
            val f = (label.attributedText?.attrs?.get("font") as? com.saiki.motion.uikit.UIFont) ?: label.font
            val k = (label.attributedText?.attrs?.get("kern") as? CGFloat) ?: 0f
            val p = f.toPaint(); p.color = fg
            if (k > 0f && f.size > 0f) p.letterSpacing = k / f.size
            val h = label.rectHeight().coerceAtLeast(f.size)
            c.canvas.drawText(t, label.frame.x, label.frame.midY + f.size * 0.35f, p)
        }
        icon?.let { ic ->
            Icons.draw(c, ic, label.frame.minX - 16f, boundsRect.midY, 20f, fg)
        }
    }
}

/** One option pill: orange with dark text when selected, card-gray otherwise. */
class SegPill : TapView() {

    var title: String = ""
        set(v) { field = v; label.text = v; setNeedsDisplay() }
    var on: Boolean = false
        set(v) { field = v; setNeedsDisplay() }
    var tapped: (() -> Unit)? = null

    private val label = UILabel()

    init {
        onClick = { tapped?.invoke() }
        clipsToBounds = true
        label.font = com.saiki.motion.uikit.UIFont.semiboldSystemFont(13f)
        label.textAlignment = NSTextAlignment.center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.7f
        addSubview(label)
    }

    override fun layoutSubviews() {
        super.layoutSubviews()
        label.frame = boundsRect.insetBy(dx = 4f, dy = 0f)
    }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        com.saiki.motion.ui.fillRoundRect(c, rect, 10f, if (on) C.GREEN else C.CARD2)
        label.textColor = com.saiki.motion.uikit.argbToUIColor(if (on) C.ONDARK else C.TEXT)
        val t = label.text ?: return
        drawText(t, rect.midX, rect.midY + 4.5f, color = if (on) C.ONDARK else C.TEXT, size = 13f, bold = true, align = NSTextAlignment.center)
    }
}
