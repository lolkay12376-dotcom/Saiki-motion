@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.app

import com.saiki.motion.core.Assets
import com.saiki.motion.core.EffectDef
import com.saiki.motion.core.EffectThumbs
import com.saiki.motion.core.Registry
import com.saiki.motion.core.parseJson
import com.saiki.motion.ui.C
import com.saiki.motion.ui.EffectCard
import com.saiki.motion.ui.Icons
import com.saiki.motion.ui.IconView
import com.saiki.motion.ui.PillButton
import com.saiki.motion.ui.TapView
import com.saiki.motion.ui.boldFont
import com.saiki.motion.ui.sysFont
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSRange
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UITextView
import com.saiki.motion.uikit.UITapGestureRecognizer
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.capScrollOf
import java.io.File

// Port of Sources/App/SdkIdeViewController.swift — full-screen effect SDK IDE:
// file explorer, tabbed code editor with GLSL/JSON syntax highlighting, live preview
// card, Run (compile + render) and a problems list.
// "bundle:" sources are read-only views into the app assets (shared/resources);
// user files live under <store>/sdk (Registry.sdkRoot()).

// MARK: - Syntax highlighting

object Hl {
    val rxNumber = Regex("\\b\\d+(\\.\\d+)?([eE][+-]?\\d+)?\\b")
    val rxKeyword = Regex("\\b(float|int|bool|void|vec2|vec3|vec4|mat2|mat3|mat4|if|else|for|while|return|break|continue|discard|const|uniform|varying|in|out|inout|true|false|precision|highp|mediump|lowp|struct)\\b")
    val rxBuiltin = Regex("\\b(sin|cos|tan|asin|acos|atan|pow|exp|log|sqrt|abs|sign|floor|ceil|fract|mod|min|max|clamp|mix|step|smoothstep|length|distance|dot|cross|normalize|reflect|texture2D|radians|degrees)\\b")
    val rxSdk = Regex("\\b(effect|src|srcW|in0|in1|luma|hash11|hash21|vnoise|fbm|rot|hsv2rgb|unpremul|uTime|uRes|uHas0|uHas1)\\b")
    val rxComment = Regex("//[^\\n]*|/\\*[\\s\\S]*?\\*/")
    val rxJsonString = Regex("\"(\\\\.|[^\"\\\\])*\"")
    val rxJsonKey = Regex("\"(\\\\.|[^\"\\\\])*(?=\\s*:)")
    val rxJsonLit = Regex("\\b(true|false|null)\\b")

    /** Adds foreground-color spans for every match (NSAttributedString .foregroundColor twin). */
    fun paint(editor: UITextView, rx: Regex, hex: Int) {
        val s = editor.text
        for (m in rx.findAll(s)) {
            editor.spanColor(NSRange(m.range.first, m.range.last - m.range.first + 1), 0xFF000000.toInt() or (hex and 0xFFFFFF))
        }
    }
}

// MARK: - The IDE

class SdkIdeViewController : UIViewController() {
    var openPath: String? = null
    var newEffect = false
    var onDone: (() -> Unit)? = null

    private class OpenFile(val path: String, val readOnly: Boolean, var text: String) {
        var saved: String = text
        val undoStack = ArrayList<String>()
        val redoStack = ArrayList<String>()
        val dirty: Boolean get() = text != saved
    }

    private class Problem(val line: Int?, val text: String)

    private val openFiles = ArrayList<OpenFile>()
    private var cur: OpenFile? = null
    private var problems: List<Problem> = emptyList()
    private var loading = false
    private var changed = false

    private lateinit var editor: UITextView
    private lateinit var banner: UILabel
    private lateinit var titleView: UILabel
    private lateinit var tabRow: UiView
    private lateinit var tabsScroll: UIScrollView
    private lateinit var problemsList: UiView
    private lateinit var probsScroll: UIScrollView
    private lateinit var card: EffectCard
    private lateinit var explorerBox: UiView
    private lateinit var explorerScroll: UIScrollView
    private lateinit var explorerCol: UiView
    private lateinit var scrim: UiView
    private lateinit var editorCol: UiView
    private lateinit var previewPane: UiView
    private val wide: Boolean get() = view.rectWidth() > 900
    private var previewOpen = false

    private val mono: UIFont = UIFont.monospacedFont(13f)
    private val hlHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var hlRunnable: Runnable? = null
    private var histRunnable: Runnable? = null

    // ---------------------------------------------------------------- lifecycle

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        buildUi()
        if (newEffect) {
            val f = Registry.newEffectFolder("My Effect")
            rebuildTree()
            openFile(File(f, "effect.glsl").path)
        } else if (openPath != null) {
            rebuildTree()
            openFile(openPath!!)
        } else {
            rebuildTree()
            // Open the first user effect when nothing was requested.
            val root = Registry.sdkRoot()
            val fs = root.listFiles()?.sortedBy { it.name } ?: emptyList()
            for (d in fs) {
                val j = File(d, "effect.json")
                if (j.exists()) { openFile(j.path); break }
            }
        }
        loadCurrentIntoEditor()
    }

    override fun viewWillDisappear(animated: Boolean) {
        super.viewWillDisappear(animated)
        saveAll()
        onDone?.invoke()
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        view.setBackgroundColor(C.BG)
        val ctx = com.saiki.motion.uikit.appContext!!

        // top bar
        val bar = UiView(ctx)
        bar.setBackgroundColor(C.PANEL)
        view.addView(bar)

        val back = IconView("back", C.GREEN)
        back.onClick = { dismiss(animated = true) }
        bar.addView(back)
        val burger = IconView("layers", C.TEXT)
        burger.onClick = { openDrawer() }
        bar.addView(burger)
        titleView = UILabel()
        titleView.textColor = com.saiki.motion.uikit.argbToUIColor(C.TEXT)
        titleView.font = boldFont(15f)
        bar.addView(titleView)
        val btns = ArrayList<PillButton>()
        btns.add(pillBtn("New", "plus", C.GREEN, C.ONDARK) { newFile() })
        btns.add(pillBtn("Run", "play", C.GREEN, C.ONDARK) { run() })
        btns.add(pillBtn("Save", "save") { saveAll(); Snack.show("Saved") })
        btns.add(pillBtn("?", null) { showReference() })
        for (b in btns) bar.addView(b)

        // explorer column
        explorerBox = UiView(ctx)
        explorerBox.setBackgroundColor(0xFF141419.toInt())
        view.addView(explorerBox)
        explorerScroll = capScrollOf(ctx)
        explorerBox.addView(explorerScroll)
        explorerCol = UiView(ctx)
        explorerScroll.addView(explorerCol)

        // scrim for the compact drawer
        scrim = TapView()
        scrim.setBackgroundColor(0x80000000.toInt())
        scrim.isHidden = true
        scrim.onClick = { closeDrawer() }
        view.addView(scrim)

        // editor column: tabs, banner, editor, symbol bar, problems
        editorCol = UiView(ctx)
        view.addView(editorCol)
        tabsScroll = UIScrollView(ctx)
        tabsScroll.showsHorizontalScrollIndicator = false
        editorCol.addView(tabsScroll)
        tabRow = UiView(ctx)
        tabsScroll.addView(tabRow)

        banner = UILabel()
        banner.text = "  Read-only: this effect ships inside the app."
        banner.textColor = com.saiki.motion.uikit.argbToUIColor(C.AMBER)
        banner.font = sysFont(11f)
        banner.setBackgroundColor(0xFF2A2410.toInt())
        banner.isHidden = true
        editorCol.addView(banner)

        editor = UITextView(ctx)
        editor.font = mono
        editor.backing.setTextColor(0xFFE6E6E6.toInt())
        editor.setBackgroundColor(0xFF111116.toInt())
        editor.isEditable = true
        editor.textContainerInset = com.saiki.motion.uikit.UIEdgeInsets(10f, 8f, 10f, 8f)
        editor.onDidChange = { textViewDidChange() }
        editorCol.addView(editor)

        editorCol.addView(buildSymbolBar(ctx))

        probsScroll = capScrollOf(ctx)
        problemsList = UiView(ctx)
        probsScroll.addView(problemsList)
        editorCol.addView(probsScroll)

        // preview pane
        previewPane = UiView(ctx)
        previewPane.setBackgroundColor(0xFF141419.toInt())
        previewPane.isHidden = true
        view.addView(previewPane)
        card = EffectCard("", "")
        card.thumbHeight = 0.75f
        previewPane.addView(card)

        applyLayoutForWidth()
        showProblems()
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        val w = view.rectWidth(); val h = view.rectHeight()
        val barH = 48f
        scrim.frame = CGRect(0f, 0f, w, h)
        // bar children
        val bar = view.subviews.firstOrNull() ?: return
        bar.frame = CGRect(0f, 0f, w, barH)
        var bx = 4f
        for (v in bar.subviews) {
            when (v) {
                is IconView -> { v.frame = CGRect(bx, 4f, 40f, 40f); bx += 44f }
                is UILabel -> { v.frame = CGRect(bx, 0f, w * 0.3f, barH); bx += w * 0.3f }
                is PillButton -> { v.frame = CGRect(0f, 0f, 0f, 0f) }
            }
        }
        // pill buttons pinned right
        val pills = bar.subviews.filterIsInstance<PillButton>()
        var px = w - 8f
        for (b in pills.reversed()) {
            val bw = if (b === pills.last()) 44f else 84f
            b.frame = CGRect(px - bw, 5f, bw, 38f)
            px -= bw + 6f
        }
        // mid split
        val top = barH
        val midH = h - top
        explorerBox.frame = CGRect(0f, top, 250f, midH)
        explorerBox.isHidden = !wide
        explorerScroll.frame = CGRect(0f, 0f, 250f, midH)
        layoutExplorerCol()
        val exW = if (wide) 250f else 0f
        val pvW = if (previewOpen) 240f else 0f
        previewPane.frame = CGRect(w - pvW, top, pvW, midH)
        card.frame = CGRect(8f, 30f, (pvW - 16f).coerceAtLeast(0f), midH - 38f)
        editorCol.frame = CGRect(exW, top, (w - exW - pvW).coerceAtLeast(0f), midH)
        layoutEditorCol()
    }

    private fun layoutEditorCol() {
        var y = 0f
        tabsScroll.frame = CGRect(0f, y, editorCol.rectWidth(), 34f); y += 34f
        tabRow.subviews.forEach { it.removeFromSuperview() }
        rebuildTabs()
        if (!banner.isHidden) { banner.frame = CGRect(0f, y, editorCol.rectWidth(), 18f); y += 18f }
        val symbolH = 40f
        val probsH = 110f
        editor.frame = CGRect(0f, y, editorCol.rectWidth(), (editorCol.rectHeight() - y - symbolH - probsH).coerceAtLeast(50f))
        y += editor.rectHeight()
        editorCol.subviews.firstOrNull { it is UIScrollView && it !== tabsScroll && it !== probsScroll }?.frame = CGRect(0f, y, editorCol.rectWidth(), symbolH)
        y += symbolH
        probsScroll.frame = CGRect(0f, y, editorCol.rectWidth(), probsH)
        problemsList.frame = CGRect(0f, 0f, probsScroll.rectWidth(), probsScroll.rectHeight())
        layoutProblems()
    }

    private fun applyLayoutForWidth() {
        if (wide) { explorerBox.isHidden = false; scrim.isHidden = true }
        else explorerBox.isHidden = true
    }

    private fun pillBtn(t: String, ic: String?, fill: Int = C.CARD2, tc: Int = C.TEXT, click: () -> Unit): PillButton {
        val b = PillButton(t, ic, fill, tc)
        b.onClick = click
        return b
    }

    /** Quick-insert bar for GLSL building blocks. */
    private fun buildSymbolBar(ctx: android.content.Context): UiView {
        val sv = UIScrollView(ctx)
        sv.showsHorizontalScrollIndicator = false
        sv.setBackgroundColor(C.PANEL)
        val row = UiView(ctx)
        sv.addView(row)
        val keys: List<Pair<String, String>> = listOf(
            Pair("src", "src(uv)"), Pair("srcW", "srcW(uv, 2.0)"), Pair("uTime", "uTime"), Pair("uRes", "uRes"),
            Pair("luma", "luma(c.rgb)"), Pair("hash", "hash21(p)"), Pair("fbm", "fbm(p)"), Pair("rot", "rot(p, a)"),
            Pair("vec2", "vec2(0.0)"), Pair("vec3", "vec3(0.0)"), Pair("vec4", "vec4(0.0)"), Pair("mix", "mix(a, b, t)"),
            Pair("clamp", "clamp(x, 0.0, 1.0)"), Pair("smoothstep", "smoothstep(0.0, 1.0, x)"), Pair("for", "for (int i = 0; i < 8; i++) { }"))
        var x = 4f
        for ((label, insert) in keys) {
            val b = PillButton(label, null, C.CARD2, C.TEXT)
            b.onClick = { insertText(insert) }
            b.frame = CGRect(x, 5f, com.saiki.motion.ui.measureText(label, 15f, true) + 28f, 30f)
            x += b.rectWidth() + 4f
            row.addView(b)
        }
        row.frame = CGRect(0f, 0f, x, 40f)
        sv.contentSize = CGSize(x, 40f)
        return sv
    }

    // ---------------------------------------------------------------- explorer

    private fun openDrawer() {
        if (wide) return
        explorerBox.isHidden = false
        scrim.isHidden = false
    }

    private fun closeDrawer() {
        if (!wide) { explorerBox.isHidden = true; scrim.isHidden = true }
    }

    private fun children(path: String): List<File> {
        if (path == "bundle:") {
            return listOf(File("bundle:sdk/examples/scan_wipe"), File("bundle:sdk/examples/tint_pulse"))
        }
        val dir = File(path)
        return dir.listFiles()?.sortedBy { it.name } ?: emptyList()
    }

    private fun rebuildTree() {
        explorerRows.clear()
        explorerRows.add(ExplorerRow(0, null, null, "  SDK", null))
        for (c in children(Registry.sdkRoot().path)) {
            explorerRows.add(ExplorerRow(0, if (c.isDirectory) "folder" else "file", C.TEXT, c.name, c.path))
        }
        explorerRows.add(ExplorerRow(0, null, null, "  Bundled examples (read-only)", null))
        for (ex in listOf("scan_wipe", "tint_pulse")) {
            explorerRows.add(ExplorerRow(0, "folder", C.TEXT, ex, "bundle:sdk/examples/$ex"))
        }
        layoutExplorerCol()
    }

    private class ExplorerRow(val depth: Int, val icon: String?, val tint: Int?, val label: String, val path: String?)

    private val explorerRows = ArrayList<ExplorerRow>()

    private fun layoutExplorerCol() {
        for (r in explorerCol.subviews) r.removeFromSuperview()
        var y = 4f
        val w = explorerScroll.rectWidth().coerceAtLeast(1f)
        for (r in explorerRows) {
            if (r.path == null) {
                val l = MLText(r.label, 12f, C.DIM, bold = true)
                l.build(w - 8f)
                l.frame = CGRect(4f, y, w - 8f, l.height())
                explorerCol.addView(l); y += l.height() + 8f
            } else {
                val row = object : TapView() {
                    override fun draw(rect: CGRect) {
                        val c = com.saiki.motion.uikit.UIGraphics.getCurrentContext() ?: return
                        com.saiki.motion.ui.drawText(r.label, 34f, rect.midY + 5f, color = C.TEXT, size = 13f, bold = false, align = NSTextAlignment.left)
                    }
                }
                row.drawBlock = { c ->
                    val cg = com.saiki.motion.uikit.UIGraphics.getCurrentContext()!!
                    r.icon?.let { Icons.draw(cg, it, 18f, 22f, 18f, r.tint ?: C.TEXT) }
                }
                val p = r.path
                row.onClick = { onNodeTap(p); closeDrawer() }
                row.frame = CGRect(4f, y, w - 8f, 34f)
                explorerCol.addView(row); y += 34f
            }
        }
        explorerCol.frame = CGRect(0f, 0f, w, y)
        explorerScroll.contentSize = CGSize(w, y)
    }

    private fun onNodeTap(path: String) {
        val real = if (path.startsWith("bundle:")) pathFromBundle(path) else path
        val f = File(real)
        if (f.exists() && f.isDirectory) return
        openFile(path)
    }

    /** "bundle:sdk/examples/x/effect.json" -> the assets-relative path, or the input. */
    private fun pathFromBundle(p: String): String {
        val rel = p.removePrefix("bundle:")
        val parts = rel.split("/")
        if (parts.size < 3) return p
        return rel
    }

    // ---------------------------------------------------------------- files + tabs

    private fun openFile(path0: String) {
        val readOnly = path0.startsWith("bundle:") || path0.contains(".app/sdk/") || !path0.startsWith(Registry.sdkRoot().path)
        openFiles.firstOrNull { it.path == path0 }?.let { ex ->
            cur = ex
            rebuildTabs()
            loadCurrentIntoEditor()
            return
        }
        val txt: String? = if (path0.startsWith("bundle:")) Assets.readText(path0.removePrefix("bundle:"))
            else try { File(path0).readText(Charsets.UTF_8) } catch (_: Exception) { null }
        if (txt == null) {
            Snack.show("Could not open " + File(path0).name)
            return
        }
        val f = OpenFile(path0, readOnly, txt)
        openFiles.add(f)
        cur = f
        rebuildTabs()
        loadCurrentIntoEditor()
    }

    private fun rebuildTabs() {
        if (!this::tabRow.isInitialized) return
        for (r in tabRow.subviews) r.removeFromSuperview()
        var x = 0f
        for (f in openFiles) {
            val on = f === cur
            val name = File(if (f.path.startsWith("bundle:")) f.path.drop(7) else f.path).name
            val b = PillButton(name + (if (f.dirty) " *" else ""), null, if (on) C.GREEN else C.CARD2, if (on) C.ONDARK else C.TEXT)
            b.onClick = {
                if (this.cur === f) closeTab(f)
                else {
                    saveCurrentText()
                    this.cur = f
                    loadCurrentIntoEditor()
                    rebuildTabs()
                }
            }
            val bw = com.saiki.motion.ui.measureText(name, 15f, true) + 30f
            b.frame = CGRect(x, 3f, bw, 28f)
            x += bw + 4f
            tabRow.addView(b)
        }
        tabRow.frame = CGRect(0f, 0f, x, 34f)
        if (this::tabsScroll.isInitialized) tabsScroll.contentSize = CGSize(x, 34f)
    }

    private fun closeTab(f: OpenFile) {
        saveCurrentText()
        val i = openFiles.indexOfFirst { it === f }.let { if (it < 0) 0 else it }
        openFiles.removeAll { it === f }
        if (cur === f) cur = openFiles.getOrNull(minOf(i, openFiles.size - 1))
        rebuildTabs()
        loadCurrentIntoEditor()
    }

    private fun loadCurrentIntoEditor() {
        loading = true
        val f = cur
        if (f != null) {
            banner.isHidden = !f.readOnly
            editor.isEditable = !f.readOnly
            editor.text = f.text
        } else {
            editor.text = ""
            editor.isEditable = false
            banner.isHidden = true
        }
        loading = false
        highlight()
        updateTitle()
    }

    private fun updateTitle() {
        if (!this::titleView.isInitialized) return
        val f = cur ?: run { titleView.text = "Effect Editor"; return }
        val p = if (f.path.startsWith("bundle:")) f.path.drop(7) else f.path
        val parts = p.split("/")
        titleView.text = if (parts.size >= 2) parts[parts.size - 2] + " / " + parts.last() else (parts.lastOrNull() ?: "")
    }

    // ---------------------------------------------------------------- editing

    private fun textViewDidChange() {
        if (loading) return
        val f = cur ?: return
        f.text = editor.text
        scheduleHighlight()
        scheduleHistory()
        rebuildTabs()
    }

    private fun insertText(text: String) {
        val f = cur ?: return
        if (f.readOnly) return
        val r = editor.selectedRange
        val s = editor.text
        val newText = s.substring(0, r.loc) + text + s.substring(minOf(r.loc + r.len, s.length))
        editor.text = newText
        f.text = newText
        editor.selectedRange = NSRange(r.loc + text.length, 0)
        scheduleHighlight()
        rebuildTabs()
    }

    private fun scheduleHighlight() {
        hlRunnable?.let { hlHandler.removeCallbacks(it) }
        val r = Runnable { highlight() }
        hlRunnable = r
        hlHandler.postDelayed(r, 180)
    }

    private fun scheduleHistory() {
        histRunnable?.let { hlHandler.removeCallbacks(it) }
        val r = Runnable {
            val f = cur ?: return@Runnable
            if (f.undoStack.isEmpty() || f.undoStack.last() != f.text) {
                f.undoStack.add(f.text)
                if (f.undoStack.size > 100) f.undoStack.removeAt(0)
                f.redoStack.clear()
            }
        }
        histRunnable = r
        hlHandler.postDelayed(r, 500)
    }

    private fun highlight() {
        val f = cur ?: return
        editor.clearSpans()
        if (f.text.length < 60000) {
            val ext = File(f.path).extension.lowercase()
            if (ext == "json") {
                Hl.paint(editor, Hl.rxNumber, 0xF5B301)
                Hl.paint(editor, Hl.rxJsonLit, 0xFF79C6)
                Hl.paint(editor, Hl.rxJsonString, 0x9AE59A)
                Hl.paint(editor, Hl.rxJsonKey, 0x7DD3FC)
            } else if (ext in listOf("glsl", "frag", "vert", "fsh")) {
                Hl.paint(editor, Hl.rxNumber, 0xF5B301)
                Hl.paint(editor, Hl.rxKeyword, 0xFF79C6)
                Hl.paint(editor, Hl.rxBuiltin, 0x7DD3FC)
                Hl.paint(editor, Hl.rxSdk, 0x4CD964)
                Hl.paint(editor, Hl.rxComment, 0x6B8E6B)
            }
        }
    }

    // ---------------------------------------------------------------- save / new

    private fun saveCurrentText() {
        val f = cur
        if (f != null && !loading) f.text = editor.text
    }

    private fun writeFile(f: OpenFile) {
        if (f.readOnly) return
        val path = if (f.path.startsWith("bundle:")) pathFromBundle(f.path) else f.path
        try {
            val tmp = File(path + ".tmp")
            tmp.writeText(f.text, Charsets.UTF_8)
            if (!tmp.renameTo(File(path))) { File(path).delete(); tmp.renameTo(File(path)) }
            f.saved = f.text
            changed = true
        } catch (_: Exception) {
            Snack.show("Could not save " + File(path).name)
        }
    }

    private fun saveAll() {
        saveCurrentText()
        for (f in openFiles) if (f.dirty) writeFile(f)
        rebuildTabs()
    }

    private fun newFile() {
        val et = com.saiki.motion.uikit.UITextField()
        et.placeholder = "New effect name"
        et.frame = CGRect(0f, 0f, 0f, 40f)
        Dlg(this).setTitle("New effect").setView(et).setPositiveButton("Create") { _, _ ->
            val nm = et.text.trim()
            if (nm.isEmpty()) return@setPositiveButton
            val f = Registry.newEffectFolder(nm)
            rebuildTree()
            openFile(File(f, "effect.glsl").path)
        }.setNegativeButton("Cancel", null).show()
    }

    // ---------------------------------------------------------------- run + problems

    private fun effectFolderOf(path: String): String? {
        if (path.startsWith("bundle:")) return path
        var f: File? = File(path).parentFile
        val rootPath = Registry.sdkRoot().path
        while (f != null && f.path.startsWith(rootPath)) {
            if (File(f, "effect.json").exists()) return f.path
            f = f.parentFile
        }
        return null
    }

    private fun effectIdOf(folder: String): String? {
        val o = if (folder.startsWith("bundle:")) {
            val real = pathFromBundle(folder + "/effect.json")
            Assets.readText(real)?.let { parseJson(it) }
        } else {
            try { parseJson(File(folder, "effect.json").readText(Charsets.UTF_8)) } catch (_: Exception) { null }
        } ?: return null
        val id = o.optString("id", "")
        return if (id.isEmpty()) null else id
    }

    private fun run() {
        saveAll()
        Registry.reloadSdk()
        val f = cur ?: run {
            problems = listOf(Problem(null, "Open a file from the explorer, or tap New."))
            showProblems()
            return
        }
        val folder = effectFolderOf(f.path)
        val id = folder?.let { effectIdOf(it) }
        for (k in EffectThumbs.cache.keys) {
            if (k == id || k.startsWith("__orig:custom:")) EffectThumbs.cache.remove(k)
        }
        val def = id?.let { Registry.byId[it] }
        if (id == null) {
            problems = listOf(Problem(null, if (folder == null) "This file is not inside an effect folder (a folder with effect.json)." else "effect.json has no id."))
            showProblems()
            return
        }
        if (def == null) {
            val msg = Registry.sdkErrors[File(folder!!).name] ?: "The effect could not be loaded."
            problems = listOf(Problem(null, "effect.json: $msg"))
            showProblems()
            return
        }
        card.name = def.name
        card.category = def.category
        card.anim = def.previewAnim
        card.thumbId = id
        card.origId = EffectThumbs.origKey(id)
        card.before = null
        card.after = null
        problems = emptyList()
        showProblems("Rendering...")
        previewOpen = true
        previewPane.isHidden = false
        viewDidLayoutSubviews()
        card.setNeedsDisplay()
        EffectThumbs.generate {
            val d2 = Registry.byId[id]
            card.before = EffectThumbs.cache[EffectThumbs.origKey(id)]?.let { com.saiki.motion.uikit.UIImage(it) }
            card.after = EffectThumbs.cache[id]?.let { com.saiki.motion.uikit.UIImage(it) }
            card.anim = d2?.previewAnim ?: "swipe"
            card.setNeedsDisplay()
            val raw = Registry.errors[id]
            this.problems = if (raw != null && d2 != null) parseErrors(raw, d2) else emptyList()
            showProblems()
        }
    }

    /** Turns a GLSL compiler log into tap-to-jump problems, offset by the prelude line count. */
    private fun parseErrors(raw: String, d: EffectDef): List<Problem> {
        val out = ArrayList<Problem>()
        val off = Registry.codeLineOffset(d)
        for (line in raw.split("\n")) {
            val at = line.indexOf(':')
            if (at < 0) continue
            val head = line.substring(0, at)
            val tail = line.substring(at + 1).trim()
            val c1 = head.lastOrNull()
            val c2 = if (head.length >= 2) head[head.length - 2] else null
            if (c1?.isDigit() == true && c2?.isDigit() == true) {
                val lnum = c2.digitToInt()
                val l = lnum - off
                out.add(Problem(l, "Line $l: " + tail.take(120)))
            } else {
                out.add(Problem(null, line.take(140)))
            }
            if (out.size > 8) break
        }
        if (out.isEmpty()) out.add(Problem(null, raw.take(140)))
        return out
    }

    private fun showProblems(status: String? = null) {
        if (!this::problemsList.isInitialized) return
        layoutProblems(status)
    }

    private fun layoutProblems(status: String? = null) {
        if (!this::problemsList.isInitialized) return
        for (r in problemsList.subviews) r.removeFromSuperview()
        val w = probsScroll.rectWidth().coerceAtLeast(1f)
        var y = 4f
        fun addLine(text: String, color: Int, size: Float, bold: Boolean, mono: Boolean) {
            val l = MLText("  " + text, size, color, bold = bold)
            l.build(w - 16f)
            l.frame = CGRect(8f, y, w - 16f, l.height())
            problemsList.addView(l)
            y += l.height() + 4f
        }
        if (status != null) {
            addLine(status, C.DIM, 12f, false, false)
        } else if (problems.isEmpty()) {
            addLine("No problems. Tap Run to compile and preview the effect.", C.DIM, 12f, false, false)
        } else {
            for (pr in problems) {
                addLine((if (pr.line != null) "Line ${pr.line}: " else "") + pr.text, C.RED, 11f, false, true)
            }
        }
        problemsList.frame = CGRect(0f, 0f, w, y + 8f)
        probsScroll.contentSize = CGSize(w, y + 8f)
    }

    private fun showReference() {
        val msg = """
        vec4 effect(vec2 uv) runs once per pixel. uv goes 0..1 across the layer.

        Available: every param in effect.json (float, same name), every color (vec4),
        src(uv), srcW(uv, pad) - the layer pixel (premultiplied), in0(uv), in1(uv) - layer
        inputs, luma(rgb), hash11(x), hash21(vec2), vnoise(p), fbm(p), rot(p, angle),
        hsv2rgb(vec3), unpremul(c), uTime (seconds), uRes (pixels).

        Files: each effect folder holds effect.json (name, description, category, params,
        colors, inputs, preview) and effect.glsl (the code). User folders live in the SDK
        directory; the bundled examples are read-only.
        """.trimIndent()
        Dlg(this).setTitle("Effect SDK reference").setMessage(msg).setPositiveButton("Close", null).show()
    }
}
