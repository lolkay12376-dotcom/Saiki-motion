@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.app

import com.saiki.motion.core.VPath
import com.saiki.motion.core.VPt
import com.saiki.motion.ui.Icons
import com.saiki.motion.ui.TapView
import com.saiki.motion.ui.measureText
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UIButton
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIStackView
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.appContext
import kotlin.math.hypot
import kotlin.math.min

// Port of Sources/Tools/VectorPenViewController.swift — full-screen vector pen.
// Tools: Pen (tap = add point, tap a line = insert, drag = move, tap first point = close),
// Curve (drag a point to pull out handles, drag handles, drag a line to bend it),
// Delete (tap a point), Close toggle. Done creates / updates a SHAPE layer with shape == .PATH.

private class PenCanvas : UiView(appContext!!) {
    enum class Tool { pen, curve, delete }
    private sealed class Drag {
        object none : Drag()
        data class point(val i: Int) : Drag()
        data class inH(val i: Int) : Drag()
        data class outH(val i: Int) : Drag()
        data class seg(val i: Int, val start: VPath, val u0: FloatArray) : Drag()
    }

    var path = VPath()
        set(v) { field = v; setNeedsDisplay() }
    var tool: Tool = Tool.pen
        set(v) { field = v; setNeedsDisplay() }
    var selected = -1
    var onBeginEdit: (() -> Unit)? = null
    private var drag: Drag = Drag.none
    private var moved = false
    private var downPt = CGPoint.zero
    private val orange = 0xFFFF8A1A.toInt()   // UIColor(red: 1, green: 0.54, blue: 0.1, alpha: 1)

    private val box: CGRect
        get() { val s = min(rectWidth(), rectHeight()) - 32f; return CGRect((rectWidth() - s) / 2f, (rectHeight() - s) / 2f, s, s) }

    private fun pt(x: Float, y: Float): CGPoint =
        CGPoint(box.minX + (x * 0.5f + 0.5f) * box.width, box.minY + (y * 0.5f + 0.5f) * box.height)

    private fun unit(p: CGPoint): FloatArray =
        floatArrayOf((p.x - box.minX) / box.width * 2f - 1f, (p.y - box.minY) / box.height * 2f - 1f)

    private fun dist(a: CGPoint, b: CGPoint): Float = hypot(a.x - b.x, a.y - b.y)

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        c.setFillColor(0xFF121212.toInt()); c.fill(CGRect(0f, 0f, rectWidth(), rectHeight()))
        c.setFillColor(0xFF1F1F1F.toInt()); c.fill(box)
        c.setStrokeColor(0xFF333333.toInt()); c.setLineWidth(1f)
        for (i in 1..3) {
            val f = i.toFloat() / 4f
            c.move(CGPoint(box.minX + f * box.width, box.minY)); c.addLine(CGPoint(box.minX + f * box.width, box.maxY))
            c.move(CGPoint(box.minX, box.minY + f * box.height)); c.addLine(CGPoint(box.maxX, box.minY + f * box.height))
        }
        c.strokePath()
        if (path.pts.isEmpty()) return
        val bz = path.bezier { x, y -> val p = pt(x, y); Pair(p.x, p.y) }
        if (path.closed) { c.paint.style = android.graphics.Paint.Style.FILL; c.paint.color = (orange and 0x00FFFFFF) or 0x40FF8A1A.toInt(); c.canvas.drawPath(bz, c.paint) }
        c.paint.style = android.graphics.Paint.Style.STROKE; c.paint.strokeWidth = 2.5f; c.paint.color = orange; c.canvas.drawPath(bz, c.paint)
        for ((i, p) in path.pts.withIndex()) {
            val c0 = pt(p.x, p.y)
            if ((tool == Tool.curve || i == selected) && p.curved) {
                for (h in listOf(pt(p.x + p.ix, p.y + p.iy), pt(p.x + p.ox, p.y + p.oy))) {
                    c.setStrokeColor(0x99FFFFFF.toInt()); c.setLineWidth(1f)
                    c.move(c0); c.addLine(h); c.strokePath()
                    c.setFillColor(0xFF00FFFF.toInt())
                    c.canvas.drawCircle(h.x, h.y, 5f, c.paint)
                }
            }
            c.setFillColor(if (i == selected) 0xFFFFFF00.toInt() else 0xFFFFFFFF.toInt())
            val r = if (i == selected) 8f else 6f
            c.fill(CGRect(c0.x - r, c0.y - r, r * 2f, r * 2f))
            if (i == 0 && !path.closed && path.pts.size >= 3 && tool == Tool.pen) {
                c.setStrokeColor(orange); c.setLineWidth(2f)
                c.canvas.drawCircle(c0.x, c0.y, 14f, c.paint)
            }
        }
    }

    private fun hitPoint(p: CGPoint): Int? =
        path.pts.indices.reversed().firstOrNull { dist(pt(path.pts[it].x, path.pts[it].y), p) < 22f }

    private fun hitSeg(p: CGPoint): Pair<Int, Float>? {
        var best: Triple<Int, Float, Float>? = null
        for (i in 0 until (if (path.closed) path.pts.size else maxOf(0, path.pts.size - 1))) {
            val s = path.segment(i) { x, y -> val q = pt(x, y); Pair(q.x, q.y) } ?: continue
            for (k in 0..24) {
                val t = k.toFloat() / 24f; val u = 1f - t
                val qx = u * u * u * s[0] + 3f * u * u * t * s[2] + 3f * u * t * t * s[4] + t * t * t * s[6]
                val qy = u * u * u * s[1] + 3f * u * u * t * s[3] + 3f * u * t * t * s[5] + t * t * t * s[7]
                val d = dist(CGPoint(qx, qy), p)
                if (d < 18f && d < (best?.third ?: Float.MAX_VALUE)) best = Triple(i, t, d)
            }
        }
        return best?.let { Pair(it.first, it.second) }
    }

    override fun touchesBegan(touches: Set<UITouch>, event: com.saiki.motion.uikit.UIEvent?) {
        val p = touches.first()?.location(this) ?: return
        downPt = p; moved = false; drag = Drag.none
        if (selected >= 0 && selected < path.pts.size) {            // handles of the selected point first
            val q = path.pts[selected]
            if (q.curved) {
                if (dist(pt(q.x + q.ix, q.y + q.iy), p) < 20f) { onBeginEdit?.invoke(); drag = Drag.inH(selected); return }
                if (dist(pt(q.x + q.ox, q.y + q.oy), p) < 20f) { onBeginEdit?.invoke(); drag = Drag.outH(selected); return }
            }
        }
        val i = hitPoint(p)
        if (i != null) {
            selected = i
            when (tool) {
                Tool.delete -> { onBeginEdit?.invoke(); path.pts.removeAt(i); selected = -1; if (path.pts.size < 3) path.closed = false }
                Tool.pen -> {
                    if (i == 0 && path.pts.size >= 3 && !path.closed) { onBeginEdit?.invoke(); path.closed = true } else { onBeginEdit?.invoke(); drag = Drag.point(i) }
                }
                Tool.curve -> { onBeginEdit?.invoke(); drag = Drag.point(i) }
            }
        } else {
            val hit = hitSeg(p)
            if (hit != null && tool != Tool.delete) {
                onBeginEdit?.invoke()
                val (si, t) = hit
                if (tool == Tool.pen) { path.split(si, t); selected = si + 1; drag = Drag.point(si + 1) }
                else drag = Drag.seg(si, path, unit(p))
            } else if (tool == Tool.pen) {
                onBeginEdit?.invoke()
                val u = unit(p); path.pts.add(VPt(u[0], u[1])); selected = path.pts.size - 1; drag = Drag.point(selected)
            } else selected = -1
        }
        setNeedsDisplay()
    }

    override fun touchesMoved(touches: Set<UITouch>, event: com.saiki.motion.uikit.UIEvent?) {
        val p = touches.first()?.location(this) ?: return
        if (dist(p, downPt) > 3f) moved = true
        val u = unit(p)
        when (val d = drag) {
            is Drag.none -> return
            is Drag.point -> {
                val i = d.i
                if (tool == Tool.curve) {                            // pull symmetric handles out of the point
                    val dx = u[0] - path.pts[i].x; val dy = u[1] - path.pts[i].y
                    path.pts[i].ox = dx; path.pts[i].oy = dy; path.pts[i].ix = -dx; path.pts[i].iy = -dy
                } else { path.pts[i].x = u[0]; path.pts[i].y = u[1] }
            }
            is Drag.outH -> {
                val i = d.i
                path.pts[i].ox = u[0] - path.pts[i].x; path.pts[i].oy = u[1] - path.pts[i].y
                path.pts[i].ix = -path.pts[i].ox; path.pts[i].iy = -path.pts[i].oy
            }
            is Drag.inH -> {
                val i = d.i
                path.pts[i].ix = u[0] - path.pts[i].x; path.pts[i].iy = u[1] - path.pts[i].y
                path.pts[i].ox = -path.pts[i].ix; path.pts[i].oy = -path.pts[i].iy
            }
            is Drag.seg -> {                                          // bend a line: both handles follow the finger
                val i = d.i; val start = d.start; val u0 = d.u0
                val dx = (u[0] - u0[0]) * (4f / 3f); val dy = (u[1] - u0[1]) * (4f / 3f)
                val j = (i + 1) % start.pts.size
                path.pts[i].ox = start.pts[i].ox + dx; path.pts[i].oy = start.pts[i].oy + dy
                path.pts[j].ix = start.pts[j].ix + dx; path.pts[j].iy = start.pts[j].iy + dy
            }
        }
        setNeedsDisplay()
    }

    override fun touchesEnded(touches: Set<UITouch>, event: com.saiki.motion.uikit.UIEvent?) { drag = Drag.none }
    override fun touchesCancelled(touches: Set<UITouch>, event: com.saiki.motion.uikit.UIEvent?) { drag = Drag.none }
}

class VectorPenViewController(path0: VPath) : UIViewController() {
    var onDone: ((VPath) -> Unit)? = null
    private val canvas = PenCanvas()
    private val undoStack = ArrayList<VPath>()
    private val tools = ArrayList<Pair<UIButton, PenCanvas.Tool?>>()
    private val hint = UILabel()
    private val top = UIStackView()
    private val bottom = UIStackView()
    private val orange = 0xFFFF8A1A.toInt()

    init { canvas.path = path0 }

    private val iconBtn = HashMap<UIButton, Pair<String, String>>()   // button -> (symbol, fallback)

    private fun btn(sym: String, fallback: String = "scribble", action: () -> Unit): UIButton {
        val b = object : UIButton() {
            override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                val sel = isSelectedTool(this)
                c.paint.style = android.graphics.Paint.Style.FILL
                c.paint.color = if (sel) orange else 0xFF292929.toInt()
                c.canvas.drawRoundRect(android.graphics.RectF(0f, 0f, rect.width, rect.height), 12f, 12f, c.paint)
                val pair = iconBtn[this] ?: return
                val name = Icons.sf(pair.first)?.let { pair.first } ?: pair.second
                Icons.draw(c, name, rect.width / 2f, rect.height / 2f, 24f,
                    if (sel) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
            }
        }
        iconBtn[b] = sym to fallback
        b.onTouchUpInside = action
        return b
    }

    private var toolOfBtn = HashMap<UIButton, PenCanvas.Tool>()
    private fun isSelectedTool(b: UIButton): Boolean = toolOfBtn[b] == canvas.tool

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(0xFF000000.toInt())
        canvas.onBeginEdit = { undoStack.add(canvas.path) }
        val cancel = btn("xmark") { dismiss(animated = true) }
        val done = btn("checkmark") {
            if (canvas.path.pts.size >= 2) onDone?.invoke(canvas.path)
            dismiss(animated = true)
        }
        hint.textColor = UIColor(0xFFAAAAAA.toInt())
        hint.font = com.saiki.motion.uikit.UIFont.systemFont(13f)
        hint.textAlignment = com.saiki.motion.uikit.NSTextAlignment.center
        hint.numberOfLines = 2
        val top = this.top
        top.alignment = com.saiki.motion.uikit.UIStackViewAlignment.center
        top.spacing = 8f
        top.addArrangedSubview(cancel); top.addArrangedSubview(hint); top.addArrangedSubview(done)
        val pen = btn("plus.diamond") { }
        val curve = btn("point.topleft.down.curvedto.point.bottomright.up") { }
        val del = btn("minus.circle") { }
        for ((b, t) in listOf(pen to PenCanvas.Tool.pen, curve to PenCanvas.Tool.curve, del to PenCanvas.Tool.delete)) {
            b.onTouchUpInside = { setTool(t!!) }
            tools.add(b to t); toolOfBtn[b] = t
        }
        val close = btn("circle") {
            if (canvas.path.pts.size >= 3) {
                undoStack.add(canvas.path); canvas.path.closed = !canvas.path.closed; refreshHint()
            }
        }
        val undo = btn("arrow.uturn.backward") {
            val p = undoStack.removeLastOrNull() ?: return@btn
            canvas.path = p; canvas.selected = -1
        }
        val bottom = this.bottom
        bottom.spacing = 10f
        bottom.addArrangedSubview(undo); bottom.addArrangedSubview(UiView()); bottom.addArrangedSubview(pen)
        bottom.addArrangedSubview(curve); bottom.addArrangedSubview(del); bottom.addArrangedSubview(close)
        view.addSubview(top); view.addSubview(canvas); view.addSubview(bottom)
        setTool(PenCanvas.Tool.pen)
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        val w = view.rectWidth(); val h = view.rectHeight()
        val topH = 56f
        val btnW = 52f
        val bottomH = 56f
        // top row: cancel | hint | done (centered)
        layoutRow(top, 12f, 8f, w - 24f, topH - 16f, btnW, 48f, withHint = true)
        // bottom row: undo, pen, curve, del, close (centered)
        layoutRow(bottom, 12f, h - bottomH, w - 24f, bottomH - 8f, btnW, 48f, withHint = false)
        canvas.frame = CGRect(0f, topH + 8f, w, h - topH - bottomH - 16f)
    }

    private fun layoutRow(stack: UIStackView, x: Float, y: Float, w: Float, h: Float, btnW: Float, btnH: Float, withHint: Boolean) {
        val n = stack.arrangedSubviews.size
        val sp = stack.spacing
        if (withHint) {
            // [cancel 52] sp [hint 220] sp [done 52], centered in w
            val totalW = 2 * btnW + 220f + 2 * sp
            var cx = x + (w - totalW) / 2f
            for (v in stack.arrangedSubviews) {
                val bw = if (v === hint) 220f else btnW
                v.frame = CGRect(cx, y + (h - btnH) / 2f, bw, btnH)
                cx += bw + sp
            }
        } else {
            val totalW = n * btnW + (n - 1) * sp
            var cx = x + (w - totalW) / 2f
            for (v in stack.arrangedSubviews) {
                v.frame = CGRect(cx, y + (h - btnH) / 2f, btnW, btnH)
                cx += btnW + sp
            }
        }
        stack.frame = CGRect(x, y, w, h)
    }

    private fun setTool(t: PenCanvas.Tool) {
        canvas.tool = t
        for ((b, k) in tools) b.setNeedsDisplay()
        refreshHint()
    }

    private fun refreshHint() {
        hint.text = when (canvas.tool) {
            PenCanvas.Tool.pen -> "Pen: tap to add points, tap a line to insert, drag to move." + (if (canvas.path.closed) " (closed)" else " Tap the first point to close.")
            PenCanvas.Tool.curve -> "Curve: drag a point to pull out handles, drag a line to bend it."
            PenCanvas.Tool.delete -> "Delete: tap a point to remove it."
        }
    }
}
