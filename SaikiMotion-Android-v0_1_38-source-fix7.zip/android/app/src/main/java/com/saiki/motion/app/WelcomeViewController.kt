@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.app

import android.graphics.BitmapFactory
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.saiki.motion.core.Prefs
import com.saiki.motion.ui.C
import com.saiki.motion.ui.PillButton
import com.saiki.motion.ui.fillRoundRect
import com.saiki.motion.ui.measureText
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.capScrollOf
import com.saiki.motion.uikit.CGSize

// Port of Sources/App/WelcomeViewController.swift — the launch "What's New" card.
// Black full-screen, scrollable column: splash art, kerned "SAIKI MOTION" wordmark,
// big "Welcome", the bordered disclaimer card (NOT A MOD / paragraph / Developers /
// TikTok credits), the "What's New" changelog and the two-button row.
// Shown on every launch until "Don't show again" (hideWelcome in prefs).
class WelcomeViewController : UIViewController() {

    companion object {
        val UPDATES: List<String> = listOf(
            "NEW — Link Physics to Wave: in a Physics sway choose 'Driven by' a Wave; the wave moves the chain and the physics adds weight, lag and overshoot on top",
            "NEW — Physics sway uses the parent: parent the layer like normal and its Physics follows the parent's movement AND the parent's puppet pins (the layer hangs on the parent's deformed mesh, each strand is carried by its own part of it)",
            "NEW — Drawing editor: Clipping mask (long-press a layer > Clipping mask). The layer only shows where the layer below has paint, takes its opacity, and several layers can share one base",
            "FIX — Blur brush blends colour and edges correctly on premultiplied layers",
            "FIX — Importing a zip that contains another zip (e.g. a zipped .ply / .spz inside a zip) now works instead of showing 'Not a readable model'",
            "FIX — Puppet pins keep the same on-screen size at any viewport zoom, so they are usable for hair and fine detail",
            "NEW — Drawing editor: Blur brush (in Tools) and an Alpha lock button in the bottom bar",
            "NEW — Auto-sway types: Normal, Hair, Skirt and Breeze presets for both Wave and Physics sways",
            "FIX — Export: videos with Chroma Key (and any video layer) no longer export fully black; each frame is now decoded before it is drawn",
            "FIX — Graph editor: opens as a large panel over the lower part of the screen with the preview still visible above, bigger knobs, property chips on top",
            "FIX — Optical Flare: if the flare shader cannot run, the flare is now drawn by the Metal renderer instead of disappearing",
            "Saiki Motion is currently in BETA — expect rough edges, and please report anything that breaks",
            "This is the beginning of Saiki Motion. We are building it into a powerful editing app, and there is much more to come",
            "FIX — Audio: no more doubled audio when playback lags; a late-loading player can no longer play on top of another one",
            "FIX — Projects: a project can no longer be overwritten by, or turn into, another project when you switch between them",
            "FIX — Chroma Key / Luma Key: clean edges, and exports no longer come out black, stop early or skip the effect",
            "NEW — Volume: video layers now have a Volume slider too (keyframe it like any other value) and keyframed volume is heard in the export",
            "FIX — Groups: copying a layer out of a group now pastes it outside the group, and copying a group brings its contents",
            "FIX — Adjustment layers: Shake and Motion Tile now replace the picture below instead of showing a second copy",
            "FIX — Drawing editor: transparent pixels are now locked by default in Direct Drawing (Tools → Transparent pixels), so brush and smudge can no longer paint over or wipe out the transparent area of a cut-out picture; Clear layer now asks first and can be undone",
            "FIX — Parenting: the Parent button in Transform keeps the layer where it is and can no longer create loops; Parent Lock (movement) now freezes the whole parent chain",
            "NEW — Import: .ply and .spz files are now supported, with Gaussian splatting so you can bring splat scenes straight into your project",
            "NEW — Rig editor: a redesigned rig editor that makes building, selecting and adjusting bones and joints faster and clearer",
            "NEW — 3D scene UI: a cleaner, easier to use 3D scene interface with improved layout and controls",
            "NEW — Lighting: improved 3D lighting with ray tracing, now affecting PBR materials for more realistic shadows, reflections and highlights",
            "NEW — Rigging physics: rigs now react to basic transformations such as moving, rotating and scaling, so motion feels natural",
            "COMING SOON — The Android version of Saiki Motion will be developed in the next few days",
            "NEW — My Playground: project thumbnails, folders (create, rename, delete, move projects in and out) — all with our own icons, no emojis or system icons",
            "NEW — 3D editor: fixed the gizmo lagging behind when you move things, including the camera. The gizmo and the preview now update on the same frame",
            "NEW — Export screen: all settings sit above Cancel / Export — Quality, Frames per second (parameter slider + FPS presets), Bitrate, Include audio and Export project file",
            "NEW — Project settings: Duration removed; Aspect ratio and Background color are now at the top under Canvas",
        )
    }

    private val scroll = capScrollOf(com.saiki.motion.uikit.appContext!!)
    private val content = UiView(com.saiki.motion.uikit.appContext!!)

    // static text layouts (width-dependent; built in layout())
    private var disclaimerLayout: StaticLayout? = null
    private var lineLayouts: List<StaticLayout> = emptyList()
    private var art: android.graphics.Bitmap? = null
    private val never = PillButton("Don't show again", null, C.CARD2, 0xFFFFFFFF.toInt())
    private val close = PillButton("Close", null, C.GREEN, C.ONDARK)

    private val DISCLAIMER = "Saiki Motion is an independent app. We built it with a similar interface and feature set to Keyflow by Angkin, and it is free for all users. We are currently in development and we are excited for the future of Saiki Motion."

    private fun tp(size: Float, color: Int, bold: Boolean, kern: Float = 0f): TextPaint =
        TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; this.textSize = size; isFakeBoldText = bold
            if (kern > 0f && size > 0f) letterSpacing = kern / size
        }

    private fun layout(s: String, w: Float, p: TextPaint, mul: Float = 1f): StaticLayout =
        StaticLayout.Builder.obtain(s, 0, s.length, p, w.toInt().coerceAtLeast(1))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(0f, mul).build()

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        art = try {
            com.saiki.motion.uikit.appContext!!.assets.open("img/splash_chibi.png").use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) { null }
        view.addView(scroll)
        scroll.addView(content)

        never.onClick = {
            Prefs.setBool("hideWelcome", true)
            dismiss(animated = true)
        }
        close.onClick = { dismiss(animated = true) }
        content.addView(never)
        content.addView(close)
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        val w = view.rectWidth()
        val h = view.rectHeight()
        scroll.frame = CGRect(0f, 0f, w, h)
        val cw = w - 22f - 22f

        var y = 28f
        // 1 - splash art (288 tall, aspect fit)
        art?.let { b ->
            val box = UiView(com.saiki.motion.uikit.appContext!!)
            box.drawBlock = { c -> val s = minOf(cw / b.width, 288f / b.height); val dw = b.width * s; val dh = b.height * s
                c.drawBitmap(b, null, android.graphics.RectF((cw - dw) / 2, 0f, (cw + dw) / 2, dh),
                    android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)) }
            // replace-in-place pattern: content holds a stable subview order; art is content itself via drawBlock below
            y += 288f
        }
        // 2 - kerned wordmark (28 = 14 text + 14 pad)
        val markH = 14f + 17f
        // 3 - Welcome (pad 4/18)
        val welcomeH = 4f + 38f + 18f
        // 4 - disclaimer card
        val disclaimer = layout(DISCLAIMER, cw - 18f - 18f, tp(14f, 0xFFFFFFFF.toInt(), false), 1.2f)
        disclaimerLayout = disclaimer
        val cardH = 16f + 20f /*notMod*/ + 10f + disclaimer.height + 14f + 15f /*devs*/ + 4f + 36f /*tiktok x2*/ + 16f
        // 5 - header (pad 22/4/0/6)
        val headerH = 22f + 16f + 6f
        // 6 - changelog lines
        val lp = tp(14f, 0xFFFFFFFF.toInt(), false)
        lineLayouts = UPDATES.map { layout("\u2022  $it", cw - 8f, lp) }
        var linesH = 0f
        for (l in lineLayouts) linesH += 6f + l.height + 6f
        // 7 - buttons (pad 26 above, 50 tall)
        val btnsH = 26f + 50f

        val total = (art?.let { 288f } ?: 0f) + markH + welcomeH + cardH + headerH + linesH + btnsH + 24f
        content.frame = CGRect(0f, 0f, w, total)
        scroll.contentSize = CGSize(w, total)

        // positions of the regions (drawn in content.drawBlock-style below)
        val artY = 28f
        val markY = artY + (art?.let { 288f } ?: 0f)
        val welcomeY = markY + markH
        val cardY = welcomeY + welcomeH
        val headerY = cardY + cardH
        var lineY = headerY + headerH
        val lineYs = ArrayList<Float>()
        for (l in lineLayouts) { lineYs.add(lineY + 3f); lineY += 3f + l.height + 3f + 4f }
        val btnY = lineY + 26f

        val items = lineLayouts
        val ys = lineYs
        val bmp = art
        val markPaint = tp(14f, C.GREEN, true, 0.3f)
        val welcomePaint = tp(32f, 0xFFF2F2F2.toInt(), true)
        val notModPaint = tp(16f, C.GREEN, true)
        val devsPaint = tp(12f, 0xFF8C8C96.toInt(), true)
        val tiktokPaint = tp(15f, 0xFFFFFFFF.toInt(), false)
        val headerPaint = tp(13f, C.GREEN, true)
        val artBoxH = if (art != null) 288f else 0f

        content.drawBlock = { c ->
            // 1 - splash art
            if (bmp != null) {
                val s = minOf(cw / bmp.width, artBoxH / bmp.height)
                val dw = bmp.width * s; val dh = bmp.height * s
                c.drawBitmap(bmp, null, android.graphics.RectF(22f + (cw - dw) / 2, artY + (artBoxH - dh) / 2,
                    22f + (cw + dw) / 2, artY + (artBoxH + dh) / 2),
                    android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
            }
            // 2 - kerned wordmark
            c.save(); c.translate(22f, markY + 14f)
            c.drawText("SAIKI MOTION", (cw - markPaint.measureText("SAIKI MOTION")) / 2, 14f, markPaint)
            c.restore()
            // 3 - Welcome
            c.save(); c.translate(22f, welcomeY + 4f)
            val wt = "Welcome"
            c.drawText(wt, (cw - welcomePaint.measureText(wt)) / 2, 32f, welcomePaint)
            c.restore()
            // 4 - disclaimer card
            com.saiki.motion.ui.fillRoundRect(UIGraphics.getCurrentContext()!!, CGRect(22f, cardY, cw, cardH), 20f, 0xFF1C2121.toInt())
            com.saiki.motion.ui.strokeRoundRect(UIGraphics.getCurrentContext()!!, CGRect(22.5f, cardY + 0.5f, cw - 1f, cardH - 1f), 20f, 1f, 0xFF2A2A30.toInt())
            c.save(); c.translate(22f + 18f, cardY + 16f)
            c.drawText("THIS APP IS NOT A MOD OF KEYFLOW.", 0f, 16f, notModPaint)
            c.translate(0f, 20f + 10f)
            disclaimer.draw(c)
            c.translate(0f, disclaimer.height + 14f)
            c.drawText("Developers", 0f, 12f, devsPaint)
            c.translate(0f, 15f + 4f)
            c.drawText("TikTok  @quintsuxf", 0f, 15f, tiktokPaint)
            c.translate(0f, 18f)
            c.drawText("TikTok  @naviya903", 0f, 15f, tiktokPaint)
            c.restore()
            // 5 - What's New header
            c.save(); c.translate(22f + 4f, headerY + 22f)
            c.drawText("What's New", 0f, 13f, headerPaint)
            c.restore()
            // 6 - changelog lines
            for (i in items.indices) {
                c.save(); c.translate(22f + 4f, ys[i]); items[i].draw(c); c.restore()
            }
        }

        // 7 - button row
        val bw = (cw - 8f) / 2
        never.frame = CGRect(22f, btnY, bw, 50f)
        close.frame = CGRect(22f + bw + 8f, btnY, bw, 50f)
    }
}
