package com.saiki.motion.core

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

// Port of Sources/Model/Anim.swift — keyframes, tracks, easing math, expression language. Line-for-line; Float math throughout.

enum class Ease(val raw: Int, val label: String) {
    LINEAR(0, "Linear"), EASE_IN(1, "Ease In"), EASE_OUT(2, "Ease Out"), EASE_IN_OUT(3, "Ease In-Out"), CUSTOM(4, "Custom"),
    BOUNCE(5, "Bounce"), ELASTIC(6, "Elastic"), WAVE(7, "Wave"), STEPS(8, "Steps");
    companion object { fun of(raw: Int): Ease? = values().firstOrNull { it.raw == raw } }
}

class Key(var t: Float, var v: Float, var ease: Ease) {
    var x1 = 0.42f; var y1 = 0.0f
    var x2 = 0.58f; var y2 = 1.0f
    var amp = 1f
    var cn = 3
    var bm = 0
    var rev = false

    fun isBezier() = ease == Ease.CUSTOM || ease == Ease.LINEAR || ease == Ease.EASE_IN || ease == Ease.EASE_OUT || ease == Ease.EASE_IN_OUT

    fun preset(e: Ease) {
        ease = e
        when (e) {
            Ease.LINEAR -> { x1 = 0f; y1 = 0f; x2 = 1f; y2 = 1f }
            Ease.EASE_IN -> { x1 = 0.42f; y1 = 0f; x2 = 1f; y2 = 1f }
            Ease.EASE_OUT -> { x1 = 0f; y1 = 0f; x2 = 0.58f; y2 = 1f }
            Ease.EASE_IN_OUT -> { x1 = 0.42f; y1 = 0f; x2 = 0.58f; y2 = 1f }
            Ease.BOUNCE -> { amp = 1f; cn = 8; bm = 0 }
            Ease.ELASTIC -> { amp = 1f; cn = 3; bm = 0 }
            else -> {}
        }
    }

    fun copyCurveFrom(o: Key) { ease = o.ease; x1 = o.x1; y1 = o.y1; x2 = o.x2; y2 = o.y2; amp = o.amp; cn = o.cn; rev = o.rev; bm = o.bm }
    fun copy(): Key { val k = Key(t, v, ease); k.copyCurveFrom(this); return k }

    fun toJson(): JSONObject {
        val o = JSONObject().putF("t", t).putF("v", v).putL("ease", ease.raw.toLong())
        o.putF("x1", x1).putF("y1", y1).putF("x2", x2).putF("y2", y2)
        o.putF("amp", amp).putL("cn", cn.toLong()); o.put("rev", rev); o.putL("bm", bm.toLong())
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Key {
            val k = Key(o.optF("t"), o.optF("v"), Ease.of(o.optI("ease")) ?: Ease.LINEAR)
            k.x1 = o.optF("x1", 0.42f); k.y1 = o.optF("y1", 0f)
            k.x2 = o.optF("x2", 0.58f); k.y2 = o.optF("y2", 1f)
            k.amp = o.optF("amp", 1f); k.cn = o.optI("cn", 3); k.bm = o.optI("bm", 3)
            k.rev = o.optB("rev")
            return k
        }
    }
}

class Track(var base: Float = 0f) {
    var keys = mutableListOf<Key>()
    var exprSrc = ""
    var exprOn = false

    fun eval(t: Float): Float {
        if (keys.isEmpty()) return base
        if (keys.size == 1) return keys[0].v
        if (t <= keys[0].t) return keys[0].v
        if (t >= keys[keys.size - 1].t) return keys[keys.size - 1].v
        for (i in 0 until keys.size - 1) {
            val a = keys[i]; val b = keys[i + 1]
            if (t >= a.t && t <= b.t) {
                val span = b.t - a.t
                if (span <= 0) return b.v
                var u = (t - a.t) / span
                var va = a.v; var vb = b.v
                if (a.rev) { u = 1 - u; va = b.v; vb = a.v }
                return va + (vb - va) * easeAt(a, u)
            }
        }
        return base
    }

    fun set(t: Float, v: Float, autoKey: Boolean) {
        if (keys.isEmpty()) {
            if (autoKey) keys.add(Key(t, v, Ease.EASE_IN_OUT)) else base = v
            return
        }
        val i = keys.indexOfFirst { abs(it.t - t) < 0.02f }
        if (i >= 0) { keys[i].v = v; return }
        keys.add(Key(t, v, Ease.EASE_IN_OUT))
        keys.sortBy { it.t }
    }

    fun setMove(t: Float, v: Float, autoKey: Boolean, mul: Boolean = false) {
        if (keys.isEmpty() || autoKey) { set(t, v, autoKey); return }
        set(t, v, true)
    }

    fun toggleKey(t: Float) {
        val i = keys.indexOfFirst { abs(it.t - t) < 0.02f }
        if (i >= 0) keys.removeAt(i) else { keys.add(Key(t, eval(t), Ease.EASE_IN_OUT)); keys.sortBy { it.t } }
    }

    fun keyAt(t: Float): Key? = keys.firstOrNull { abs(it.t - t) < 0.04f }

    fun setExpr(src: String): Boolean {
        if (src.trim().isEmpty()) { exprSrc = ""; return true }
        if (Expr.compile(src) == null) return false
        exprSrc = src
        return true
    }

    fun exprActive() = exprOn && exprSrc.trim().isNotEmpty()

    fun evalExpr(t: Float, time: Float, markers: Map<String, Float>): Float {
        val v = eval(t)
        if (!exprActive()) return v
        Expr.currentTime = time
        val fn = Expr.compile(exprSrc) ?: return v
        return fn(v, time, markers)
    }

    fun copyExprFrom(o: Track) { exprSrc = o.exprSrc; exprOn = o.exprOn }

    fun toJson(): JSONObject {
        val o = JSONObject().putF("base", base); o.put("expr", exprSrc); o.put("exprOn", exprOn)
        val arr = JSONArray(); for (k in keys) arr.put(k.toJson())
        o.put("keys", arr)
        return o
    }

    fun load(o: JSONObject) {
        base = o.optF("base")
        exprSrc = o.optS("expr")
        exprOn = o.optB("exprOn")
        keys = mutableListOf()
        o.optJSONArray("keys")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { keys.add(Key.fromJson(it)) } }
        keys.sortBy { it.t }
    }

    companion object {
        fun easeAt(a: Key, u: Float): Float = when (a.ease) {
            Ease.LINEAR -> u
            Ease.EASE_IN, Ease.EASE_OUT, Ease.EASE_IN_OUT, Ease.CUSTOM -> bezier(u, a.x1, a.y1, a.x2, a.y2)
            Ease.BOUNCE -> if (a.bm == 3) bounceOut(u) else bounceCurve(u, a.amp, a.cn, a.bm)
            Ease.ELASTIC -> if (a.bm == 3) elasticOut(u, a.amp, a.cn) else elasticCurve(u, a.amp, a.cn, a.bm)
            Ease.WAVE -> wave(u, a.amp, a.cn)
            Ease.STEPS -> stepped(u, a.cn)
        }

        fun bezier(u: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
            if (u <= 0) return 0f
            if (u >= 1) return 1f
            fun cx(t: Float) = ((1 - 3 * x2 + 3 * x1) * t + (3 * x2 - 6 * x1)) * t * t + 3 * x1 * t
            fun cy(t: Float) = ((1 - 3 * y2 + 3 * y1) * t + (3 * y2 - 6 * y1)) * t * t + 3 * y1 * t
            var t = u
            for (n in 0 until 8) {
                val x = cx(t) - u
                if (abs(x) < 1e-5f) break
                val d = (3 * (1 - 3 * x2 + 3 * x1) * t + 2 * (3 * x2 - 6 * x1)) * t + 3 * x1
                if (abs(d) < 1e-6f) break
                t -= x / d
            }
            t = clamp(t, 0f, 1f)
            return cy(t)
        }

        fun bounceIn(u: Float, amp: Float, n: Int): Float {
            val cells = max(n, 1).toFloat() + 0.5f
            val x = u * cells; val f = x - floor(x)
            return amp * 4 * f * (1 - f) + (1 - amp) * u
        }

        fun bounceCurve(u: Float, amp: Float, n: Int, mode: Int): Float {
            if (u <= 0) return 0f
            if (u >= 1) return 1f
            return when (mode) {
                1 -> 1 - bounceIn(1 - u, amp, n)
                2 -> if (u < 0.5f) 0.5f * bounceIn(2 * u, amp, n) else 1 - 0.5f * bounceIn(2 * (1 - u), amp, n)
                else -> bounceIn(u, amp, n)
            }
        }

        fun elasticCurve(u: Float, amp: Float, n: Int, mode: Int): Float {
            if (u <= 0) return 0f
            if (u >= 1) return 1f
            fun out(x: Float): Float {
                val e = exp(-7 * x); val c = cos(2 * Math.PI.toFloat() * max(n, 1).toFloat() * x)
                return 1 - e * c + (amp - 1) * e * (1 - c)
            }
            return when (mode) {
                1 -> 1 - out(1 - u)
                2 -> if (u < 0.5f) 0.5f * (1 - out(1 - 2 * u)) else 0.5f + 0.5f * out(2 * u - 1)
                else -> out(u)
            }
        }

        fun bounceOut(u: Float): Float {
            val n1 = 7.5625f; val d1 = 2.75f
            if (u < 1 / d1) return n1 * u * u
            if (u < 2 / d1) { val x = u - 1.5f / d1; return n1 * x * x + 0.75f }
            if (u < 2.5f / d1) { val x = u - 2.25f / d1; return n1 * x * x + 0.9375f }
            val x = u - 2.625f / d1
            return n1 * x * x + 0.984375f
        }

        fun elasticOut(u: Float, amp: Float, n: Int): Float {
            if (u <= 0) return 0f
            if (u >= 1) return 1f
            val p = 0.3f * amp
            val s = p / 4
            return 2f.pow(-10 * u) * sin((u - s) * (2 * Math.PI.toFloat()) / p) * amp + 1
        }

        fun wave(u: Float, amp: Float, n: Int): Float {
            val c = max(n.toFloat(), 1f)
            return u + sin(u * c * 2 * Math.PI.toFloat()) * 0.5f * amp / c
        }

        fun stepped(u: Float, n: Int): Float {
            val c = max(n, 1)
            return floor(u * c.toFloat()) / c.toFloat()
        }
    }
}

// ---------------------------------------------------------------- Expressions
object Expr {
    @JvmField var currentTime: Float = 0f
    private var sliderDepth = 0

    fun sliderValue(name: String, index: Int): Float {
        if (sliderDepth >= 8) return 0f
        sliderDepth++
        try {
            val l = Editor.scene.layers.firstOrNull { it.name == name } ?: return 0f
            val entries = l.fx.filter { Registry.get(it)?.id == "slidercontrol" }
            if (index < 1 || index > entries.size) return 0f
            val key = entries[index - 1] + "__slider"
            val tr = l.props[key] ?: return 0f
            val t = currentTime
            return tr.evalExpr(l.editTime(key, t), t, if (tr.exprActive()) Editor.scene.markersByName() else emptyMap())
        } finally { sliderDepth-- }
    }

    fun controlValue(name: String, index: Int, eid: String, key: String): Float {
        if (sliderDepth >= 8) return 0f
        sliderDepth++
        try {
            val l = Editor.scene.layers.firstOrNull { it.name == name } ?: return 0f
            val entries = l.fx.filter { Registry.get(it)?.id == eid }
            if (index < 1 || index > entries.size) return 0f
            val k = entries[index - 1] + "__" + key
            val tr = l.props[k] ?: return 0f
            val t = currentTime
            return tr.evalExpr(l.editTime(k, t), t, if (tr.exprActive()) Editor.scene.markersByName() else emptyMap())
        } finally { sliderDepth-- }
    }

    fun allControls(): List<Pair<String, String>> {
        val fnFor = mapOf("slidercontrol" to listOf("slider"), "anglecontrol" to listOf("angle"), "checkboxcontrol" to listOf("checkbox"),
            "colorcontrol" to listOf("colorr", "colorg", "colorb"), "pointcontrol" to listOf("pointx", "pointy"),
            "point3dcontrol" to listOf("point3x", "point3y", "point3z"), "layercontrol" to listOf("layerctl"))
        val out = mutableListOf<Pair<String, String>>()
        for (l in Editor.scene.layers) for (eid in ControlFx.ids) {
            val n = l.fx.count { Registry.get(it)?.id == eid }
            if (n == 0) continue
            for (i in 1..n) for (f in fnFor[eid] ?: emptyList())
                out.add(((l.name + " " + f) + (if (n > 1) " $i" else "") to (f + "(\"" + l.name + "\"" + (if (i > 1) ", $i" else "") + ")")))
        }
        return out
    }

    fun allSliders(): List<Pair<String, Int>> {
        val out = mutableListOf<Pair<String, Int>>()
        for (l in Editor.scene.layers) { val n = l.fx.count { Registry.get(it)?.id == "slidercontrol" }; if (n > 0) for (i in 1..n) out.add(l.name to i) }
        return out
    }

    private class Ctx(val t: Float, val v: Float, val markers: Map<String, Float>)

    private sealed class Node {
        class Num(val d: Float) : Node()
        object TVar : Node()
        object VVar : Node()
        object PiC : Node()
        class Marker(val name: String) : Node()
        class Slider(val name: String, val idx: Int) : Node()
        class Ctl(val name: String, val idx: Int, val eid: String, val key: String) : Node()
        class Neg(val a: Node) : Node()
        class Bin(val op: String, val a: Node, val b: Node) : Node()
        class Cmp(val op: String, val a: Node, val b: Node) : Node()
        class Call(val name: String, val args: List<Node>) : Node()
    }

    private class Parser(val toks: List<String>) {
        var pos = 0
        fun peek(): String? = if (pos < toks.size) toks[pos] else null
        fun next(): String? { val r = peek(); if (pos < toks.size) pos++; return r }
        fun expect(s: String) = next() == s

        fun parseExpr(): Node? {
            var left = parseCmp() ?: return null
            while (true) { val op = peek(); if (op != "&&" && op != "||") break; next(); val right = parseCmp() ?: return null; left = Node.Bin(op!!, left, right) }
            return left
        }
        fun parseCmp(): Node? {
            var left = parseAdd() ?: return null
            while (true) { val op = peek(); if (op == null || op !in listOf("<", ">", "<=", ">=", "==", "!=")) break; next(); val right = parseAdd() ?: return null; left = Node.Cmp(op, left, right) }
            return left
        }
        fun parseAdd(): Node? {
            var left = parseMul() ?: return null
            while (true) { val op = peek(); if (op != "+" && op != "-") break; next(); val right = parseMul() ?: return null; left = Node.Bin(op!!, left, right) }
            return left
        }
        fun parseMul(): Node? {
            var left = parsePow() ?: return null
            while (true) { val op = peek(); if (op != "*" && op != "/" && op != "%") break; next(); val right = parsePow() ?: return null; left = Node.Bin(op!!, left, right) }
            return left
        }
        fun parsePow(): Node? {
            val left = parseUnary() ?: return null
            val op = peek()
            if (op == "^") { next(); val right = parsePow() ?: return null; return Node.Bin(op, left, right) }
            return left
        }
        fun parseUnary(): Node? {
            val op = peek()
            if (op == "-") { next(); val n = parseUnary() ?: return null; return Node.Neg(n) }
            if (op == "+") { next(); return parseUnary() }
            return parseAtom()
        }
        fun parseAtom(): Node? {
            val tok = next() ?: return null
            parseSwiftFloat(tok)?.let { return Node.Num(it) }
            if (tok == "t") return Node.TVar
            if (tok == "v") return Node.VVar
            if (tok == "pi") return Node.PiC
            if (tok == "(") { val inner = parseExpr(); if (!expect(")")) return null; return inner }
            if (tok == "slider") {
                if (!expect("(")) return null
                val nameTok = next() ?: return null
                if (!nameTok.startsWith("s:")) return null
                var idx = 1
                if (peek() == ",") { next(); val nt = next() ?: return null; val n = nt.toIntOrNull() ?: return null; idx = max(1, n) }
                if (!expect(")")) return null
                return Node.Slider(nameTok.substring(2), idx)
            }
            val fn = ControlFx.fns[tok]
            if (fn != null && tok != "slider") {
                if (!expect("(")) return null
                val nameTok = next() ?: return null
                if (!nameTok.startsWith("s:")) return null
                var idx = 1
                if (peek() == ",") { next(); val nt = next() ?: return null; val n = nt.toIntOrNull() ?: return null; idx = max(1, n) }
                if (!expect(")")) return null
                return Node.Ctl(nameTok.substring(2), idx, fn.first, fn.second)
            }
            if (tok == "marker") {
                if (peek() == ".") {
                    next()
                    if (next() == "key" && expect("(")) {
                        val nameTok = next()
                        if (nameTok != null && expect(")")) {
                            var raw: String = nameTok
                            if (raw.startsWith("s:")) raw = raw.substring(2)
                            raw = raw.substring(if (raw.startsWith("\"")) 1 else 0)
                            if (raw.endsWith("\"")) raw = raw.dropLast(1)
                            return Node.Marker(raw)
                        }
                    }
                    return null
                }
                return null
            }
            if (peek() == "(") {
                next()
                val args = mutableListOf<Node>()
                if (peek() != ")") {
                    while (true) {
                        val a = parseExpr() ?: return null
                        args.add(a)
                        if (peek() == ",") { next(); continue }
                        break
                    }
                }
                if (!expect(")")) return null
                return Node.Call(tok, args)
            }
            return null
        }
    }

    fun compile(src: String): ((Float, Float, Map<String, Float>) -> Float)? {
        val toks = tokenize(src)
        if (toks.isEmpty()) return null
        val p = Parser(toks)
        val ast = p.parseExpr() ?: return null
        if (p.pos < toks.size) return null
        return { t, v, markers -> eval(ast, Ctx(t, v, markers)) }
    }

    private fun tokenize(s: String): List<String> {
        val out = mutableListOf<String>()
        var i = 0
        val end = s.length
        while (i < end) {
            val c = s[i]
            if (c.isWhitespace()) { i++; continue }
            if (c.isDigit() || c == '.') {
                var j = i
                while (j < end && (s[j].isDigit() || s[j] == '.')) j++
                out.add(s.substring(i, j)); i = j
            } else if (c.isLetter() || c == '_') {
                var j = i
                while (j < end && (s[j].isLetter() || s[j].isDigit() || s[j] == '_')) j++
                out.add(s.substring(i, j)); i = j
            } else if (c == '"') {
                var j = i + 1
                while (j < end && s[j] != '"') j++
                out.add("s:" + s.substring(i + 1, j))
                i = if (j < end) j + 1 else j
            } else {
                val two = if (i + 1 < end) s.substring(i, i + 2) else ""
                if (two in listOf("<=", ">=", "==", "!=", "&&", "||")) { out.add(two); i += 2 }
                else { out.add(c.toString()); i++ }
            }
        }
        return out
    }

    private fun eval(n: Node, ctx: Ctx): Float = when (n) {
        is Node.Num -> n.d
        Node.TVar -> ctx.t
        Node.VVar -> ctx.v
        Node.PiC -> Math.PI.toFloat()
        is Node.Marker -> ctx.markers[n.name] ?: 0f
        is Node.Slider -> sliderValue(n.name, n.idx)
        is Node.Ctl -> controlValue(n.name, n.idx, n.eid, n.key)
        is Node.Neg -> -eval(n.a, ctx)
        is Node.Bin -> {
            val x = eval(n.a, ctx); val y = eval(n.b, ctx)
            when (n.op) {
                "+" -> x + y
                "-" -> x - y
                "*" -> x * y
                "/" -> if (y == 0f) 0f else x / y
                "%" -> if (y == 0f) 0f else x.rem(y)
                "^" -> x.pow(y)
                "&&" -> if (x != 0f && y != 0f) 1f else 0f
                "||" -> if (x != 0f || y != 0f) 1f else 0f
                else -> 0f
            }
        }
        is Node.Cmp -> {
            val x = eval(n.a, ctx); val y = eval(n.b, ctx)
            when (n.op) {
                "<" -> if (x < y) 1f else 0f
                ">" -> if (x > y) 1f else 0f
                "<=" -> if (x <= y) 1f else 0f
                ">=" -> if (x >= y) 1f else 0f
                "==" -> if (x == y) 1f else 0f
                else -> if (x != y) 1f else 0f
            }
        }
        is Node.Call -> {
            val a = n.args.map { eval(it, ctx) }
            when (n.name) {
                "sin" -> if (a.isNotEmpty()) sin(a[0]) else 0f
                "cos" -> if (a.isNotEmpty()) cos(a[0]) else 0f
                "abs" -> if (a.isNotEmpty()) abs(a[0]) else 0f
                "min" -> if (a.size > 1) min(a[0], a[1]) else (a.firstOrNull() ?: 0f)
                "max" -> if (a.size > 1) max(a[0], a[1]) else (a.firstOrNull() ?: 0f)
                "clamp" -> if (a.size > 2) clamp(a[0], a[1], a[2]) else (a.firstOrNull() ?: 0f)
                "pow" -> if (a.size > 1) a[0].pow(a[1]) else 0f
                "sqrt" -> if (a.isNotEmpty()) sqrt(max(0f, a[0])) else 0f
                "floor" -> if (a.isNotEmpty()) floor(a[0]) else 0f
                "round" -> if (a.isNotEmpty()) roundAway(a[0]) else 0f
                "ceil" -> if (a.isNotEmpty()) ceil(a[0]) else 0f
                "mix" -> if (a.size > 2) a[0] + (a[1] - a[0]) * a[2] else (a.firstOrNull() ?: 0f)
                "if" -> if (a.size > 2) (if (a[0] != 0f) a[1] else a[2]) else (a.firstOrNull() ?: 0f)
                "step" -> if (a.size > 1) (if (a[1] >= a[0]) 1f else 0f) else 0f
                "linear" -> if (a.size > 3) {
                    val u = clamp((a[0] - a[1]) / max(0.0001f, a[2] - a[1]), 0f, 1f)
                    a[3] + (a[if (4 < a.size) 4 else 3] - a[3]) * u
                } else (a.firstOrNull() ?: 0f)
                "wiggle" -> if (a.size > 1) {
                    val f = max(0.01f, a[0])
                    val i0 = floor(ctx.t * f).toInt()
                    val fr = ctx.t * f - i0.toFloat()
                    // golden-ratio hash in UInt64 (bit-identical to the Swift &* wrap)
                    val s = longArrayOf((i0.toLong().toULong() * 0x9E3779B97F4A7C15UL).toLong())
                    ktRandom(s)
                    val r0 = (ktRandom(s) % 2000UL).toFloat() / 1000f - 1
                    val r1 = (ktRandom(s) % 2000UL).toFloat() / 1000f - 1
                    val u = fr * fr * (3 - 2 * fr)
                    (r0 + (r1 - r0) * u) * a[1]
                } else 0f
                "noise" -> if (a.isNotEmpty()) noise1(a[0]) * 2 - 1 else 0f
                "random" -> kotlin.random.Random.nextFloat()
                else -> 0f
            }
        }
    }
}
