@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

// Port of Sources/Tools/AnimeDecomposer.swift — on-device anime character decomposition (Tools tab).
//
// Splits a character illustration into editable, auto-grouped parts: face skin,
// eyes, eyelids, eyebrows, mouth, hair (optionally strand by strand), neck, arms,
// legs, clothes, accessories and line art. Everything runs on the phone — no
// network, no model download.
//
//   1. cut-out           plain-colour flood fill and/or Apple's on-device subject
//                        mask (iOS 17), holes filled, soft edge
//   2. line art          thin dark strokes found by local contrast; thick dark
//                        areas (black hair, dark clothes) stay fills
//   3. colour regions    edge-preserving denoise → k-means in Lab → majority filter
//                        → connected pieces → tiny pieces merged into neighbours
//   4. understanding     face found from the biggest skin region, chin from the
//                        width profile; eyes / mouth / brows from position inside
//                        the face; hair from the head box + colour palette;
//                        neck, arms, legs, clothes from what is left
//   5. layers            disjoint cropped RGBA bitmaps (composite == source) with a
//                        little hidden "underlap" so moving a part never shows a hole
//   6. groups            Head / Hair / Body / Clothes / Accessories / Line art
//
// Pure data in, pure data out: the view controller owns all UI.
// PARITY-NOTE(AnimeDecomposer.swift:372): visionMask (VNGenerateForegroundInstanceMaskRequest) is Apple Vision framework
//  with no Android system twin (no on-device subject-lift API without shipping an ML model); flood-fill + AnimeSegModel (ISNet)
//  cover the cut-out, exactly like iOS when the Vision request is unavailable (iOS 16 / failure paths return nil).

class DecomposeOptions(
    var quality: Int = 2,
    var maxSide: Int = 1600,          // working resolution (longest side)
    var detail: Int = 6,              // 1...10 — how many colour regions (more = finer parts)
    var smoothing: Int = 1,           // 0...3 majority-filter passes
    var lineSensitivity: Int = 2,     // 1...3 — how readily thin dark strokes count as line art
    var lineMode: Int = 0,            // 0 merge into parts · 1 one "Line art" layer · 2 line art per part
    var removeBackground: Boolean = true,
    var keepBackground: Boolean = false,
    var splitFace: Boolean = true,    // eyes, eyelids, eyebrows, mouth as their own layers
    var hairStrands: Boolean = true,  // hair pieces become separate layers
    var strandLimit: Int = 24,        // 4...60
    var splitBody: Boolean = true,    // neck, arms, legs separate
    var splitClothes: Boolean = true, // garments separate
    var autoGroup: Boolean = true,    // Head / Hair / Body / Clothes … groups
    var useAI: Boolean = false,       // ISNet anime model for the cut-out when installed
    var fillGaps: Boolean = true      // hidden underlap so parts can move without holes
) {
    companion object {
        /** quality preset 0 Fast · 1 Balanced · 2 High · 3 Ultra — sets resolution + effort. */
        fun preset(q: Int): Pair<Int, Int> = when (q) {
            0 -> Pair(1024, 4)
            1 -> Pair(1400, 5)
            3 -> Pair(2304, 9)
            else -> Pair(1600, 6)
        }
    }
}

class DecomposedLayer(
    val name: String,
    val x: Int,
    val y: Int,
    val w: Int,
    val h: Int,
    val rgba: ByteArray,          // w*h*4, un-premultiplied, cropped to the box
    var visible: Boolean = true,
    val area: Int,
    val group: String = "",       // "" = ungrouped
    val order: Int = 0            // stacking hint, low = bottom
)

class DecomposeResult(val width: Int, val height: Int, val layers: List<DecomposedLayer>)

class CancelToken {
    private val lock = Object()
    private var flag = false
    fun cancel() { synchronized(lock) { flag = true } }
    val isCancelled: Boolean get() = synchronized(lock) { flag }
}

object AnimeDecomposer {

    // MARK: pixels in / out

    /** Draws the image into an un-premultiplied RGBA buffer, longest side <= maxSide (never upscaled). */
    fun loadPixels(image: Bitmap, maxSide: Int): Triple<Int, Int, ByteArray>? {
        val sw = image.width.toFloat()
        val sh = image.height.toFloat()
        if (sw <= 0f || sh <= 0f) return null
        val k = min(1f, maxSide / max(sw, sh))
        val w = max(1, Math.round(sw * k))
        val h = max(1, Math.round(sh * k))
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(image, null, android.graphics.RectF(0f, 0f, w.toFloat(), h.toFloat()), p)
        val px = ByteArray(w * h * 4)
        val intBuf = IntArray(w * h)
        bmp.getPixels(intBuf, 0, w, 0, 0, w, h)
        for (i in intBuf.indices) {
            val v = intBuf[i]
            px[i * 4] = ((v shr 16) and 0xFF).toByte()
            px[i * 4 + 1] = ((v shr 8) and 0xFF).toByte()
            px[i * 4 + 2] = (v and 0xFF).toByte()
            px[i * 4 + 3] = ((v shr 24) and 0xFF).toByte()
        }
        // already un-premultiplied via getPixels (straight alpha)
        return Triple(w, h, px)
    }

    /** RGBA (un-premultiplied) → Bitmap. */
    fun image(rgba: ByteArray, w: Int, h: Int): Bitmap? {
        if (w <= 0 || h <= 0 || rgba.size < w * h * 4) return null
        val out = IntArray(w * h)
        for (i in out.indices) {
            val r = rgba[i * 4].toInt() and 0xFF
            val g = rgba[i * 4 + 1].toInt() and 0xFF
            val b = rgba[i * 4 + 2].toInt() and 0xFF
            val a = rgba[i * 4 + 3].toInt() and 0xFF
            out[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    /** One layer placed on a full, transparent canvas. */
    fun fullCanvas(layer: DecomposedLayer, w: Int, h: Int): ByteArray {
        val out = ByteArray(w * h * 4)
        for (row in 0 until layer.h) {
            val dy = layer.y + row
            if (dy < 0 || dy >= h) continue
            for (col in 0 until layer.w) {
                val dx = layer.x + col
                if (dx < 0 || dx >= w) continue
                val s = (row * layer.w + col) * 4
                val d = (dy * w + dx) * 4
                out[d] = layer.rgba[s]; out[d + 1] = layer.rgba[s + 1]
                out[d + 2] = layer.rgba[s + 2]; out[d + 3] = layer.rgba[s + 3]
            }
        }
        return out
    }

    /** Visible layers painted bottom → top ("over" with straight alpha). */
    fun composite(layers: List<DecomposedLayer>, w: Int, h: Int): ByteArray {
        val out = ByteArray(w * h * 4)
        for (layer in layers) if (layer.visible) {
            for (row in 0 until layer.h) {
                val dy = layer.y + row
                if (dy < 0 || dy >= h) continue
                for (col in 0 until layer.w) {
                    val dx = layer.x + col
                    if (dx < 0 || dx >= w) continue
                    val s = (row * layer.w + col) * 4
                    val sa = layer.rgba[s + 3].toInt() and 0xFF
                    if (sa == 0) continue
                    val d = (dy * w + dx) * 4
                    val da = out[d + 3].toInt() and 0xFF
                    if (sa == 255 || da == 0) {
                        out[d] = layer.rgba[s]; out[d + 1] = layer.rgba[s + 1]
                        out[d + 2] = layer.rgba[s + 2]; out[d + 3] = sa.toByte()
                    } else {
                        val fs = sa / 255f; val fd = da / 255f
                        val oa = fs + fd * (1 - fs)
                        for (c in 0 until 3) {
                            val v = ((layer.rgba[s + c].toInt() and 0xFF) * fs + (out[d + c].toInt() and 0xFF) * fd * (1 - fs)) / oa
                            out[d + c] = max(0, min(255, v.toInt())).toByte()
                        }
                        out[d + 3] = max(0, min(255, (oa * 255).toInt())).toByte()
                    }
                }
            }
        }
        return out
    }

    // MARK: colour

    private val lin: FloatArray = FloatArray(256) { i ->
        val c = i / 255f
        if (c <= 0.04045f) c / 12.92f else ((c + 0.055f) / 1.055f).pow(2.4f)
    }

    private fun labF(t: Float): Float = if (t > 0.008856f) Math.cbrt(t.toDouble()).toFloat() else (7.787f * t + 16.0f / 116.0f)

    private fun toLab(src: ByteArray, n: Int, L: FloatArray, A: FloatArray, B: FloatArray) {
        for (i in 0 until n) {
            val r = lin[src[i * 4].toInt() and 0xFF]
            val g = lin[src[i * 4 + 1].toInt() and 0xFF]
            val b = lin[src[i * 4 + 2].toInt() and 0xFF]
            val x = (0.4124f * r + 0.3576f * g + 0.1805f * b) / 0.95047f
            val y = 0.2126f * r + 0.7152f * g + 0.0722f * b
            val z = (0.0193f * r + 0.1192f * g + 0.9505f * b) / 1.08883f
            val fx = labF(x); val fy = labF(y); val fz = labF(z)
            L[i] = 116 * fy - 16
            A[i] = 500 * (fx - fy)
            B[i] = 200 * (fy - fz)
        }
    }

    // MARK: connected components

    private class Comps(val ids: IntArray, val areas: IntArray, val boxes: Array<IntArray>)

    private fun components(mask: ByteArray, w: Int, h: Int, eight: Boolean): Comps {
        val n = w * h
        val ids = IntArray(n) { -1 }
        val areas = ArrayList<Int>()
        val boxes = ArrayList<IntArray>()
        val stack = IntArray(n)
        for (s in 0 until n) if (mask[s].toInt() != 0 && ids[s] < 0) {
            val cid = areas.size
            ids[s] = cid
            var sp = 0
            stack[sp++] = s
            var area = 0
            var bx0 = w; var by0 = h; var bx1 = -1; var by1 = -1
            while (sp > 0) {
                val cur = stack[--sp]
                val x = cur % w; val y = cur / w
                area += 1
                if (x < bx0) bx0 = x
                if (x > bx1) bx1 = x
                if (y < by0) by0 = y
                if (y > by1) by1 = y
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        if (dx == 0 && dy == 0) continue
                        if (!eight && dx != 0 && dy != 0) continue
                        val nx = x + dx; val ny = y + dy
                        if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                        val j = ny * w + nx
                        if (mask[j].toInt() != 0 && ids[j] < 0) {
                            ids[j] = cid
                            stack[sp++] = j
                        }
                    }
                }
            }
            areas.add(area)
            boxes.add(intArrayOf(bx0, by0, bx1, by1))
        }
        return Comps(ids, areas.toIntArray(), boxes.toTypedArray())
    }

    // MARK: - helpers --------------------------------------------------------------

    private enum class Part { none, face, eyes, eyebrows, mouth, hair, body, cloth, acc }

    private class Reg {
        var area = 0
        var l = 0f; var a = 0f; var b = 0f          // mean Lab
        var r = 0f; var g = 0f; var bl = 0f         // mean RGB
        var x0 = Int.MAX_VALUE; var y0 = Int.MAX_VALUE; var x1 = -1; var y1 = -1
        var cx = 0f; var cy = 0f
        var part = Part.none
        var skin = false
    }

    private class LDef(val name: String, val group: String, val order: Int)

    private fun skinTone(r: Float, g: Float, b: Float): Boolean {
        val cb = 128 - 0.168736f * r - 0.331264f * g + 0.5f * b
        val cr = 128 + 0.5f * r - 0.418688f * g - 0.081312f * b
        return cb >= 70 && cb <= 130 && cr >= 131 && cr <= 180
            && r >= 120 && r >= g && g >= b * 0.85f && (r - b) >= 12
    }

    private fun labDist(l1: Float, a1: Float, b1: Float, l2: Float, a2: Float, b2: Float): Float {
        val x = l1 - l2; val y = a1 - a2; val z = b1 - b2
        return sqrt(x * x + y * y + z * z)
    }

    /** Integral image of a 0/1 mask (Int), (w+1)*(h+1). */
    private fun integral(m: ByteArray, w: Int, h: Int): IntArray {
        val w1 = w + 1
        val out = IntArray((w + 1) * (h + 1))
        for (y in 0 until h) {
            var row = 0
            for (x in 0 until w) {
                row += m[y * w + x].toInt()
                out[(y + 1) * w1 + x + 1] = out[y * w1 + x + 1] + row
            }
        }
        return out
    }

    /** Morphological opening with a (2t+1) square: what survives is "thick". */
    private fun opening(m: ByteArray, w: Int, h: Int, t: Int): ByteArray {
        val n = w * h
        val w1 = w + 1
        var integ = integral(m, w, h)
        val eroded = ByteArray(n)
        for (y in 0 until h) {
            val ya = max(0, y - t); val yb = min(h - 1, y + t)
            for (x in 0 until w) if (m[y * w + x].toInt() != 0) {
                val xa = max(0, x - t); val xb = min(w - 1, x + t)
                val s = integ[(yb + 1) * w1 + xb + 1] - integ[ya * w1 + xb + 1] -
                    integ[(yb + 1) * w1 + xa] + integ[ya * w1 + xa]
                if (s == (xb - xa + 1) * (yb - ya + 1)) eroded[y * w + x] = 1
            }
        }
        integ = integral(eroded, w, h)
        val out = ByteArray(n)
        for (y in 0 until h) {
            val ya = max(0, y - t); val yb = min(h - 1, y + t)
            for (x in 0 until w) {
                val xa = max(0, x - t); val xb = min(w - 1, x + t)
                val s = integ[(yb + 1) * w1 + xb + 1] - integ[ya * w1 + xb + 1] -
                    integ[(yb + 1) * w1 + xa] + integ[ya * w1 + xa]
                if (s > 0) out[y * w + x] = 1
            }
        }
        return out
    }

    // MARK: - 1 cut-out ---------------------------------------------------------------

    /** Apple's on-device subject mask (iOS 17+). null when unavailable or implausible. */
    private fun visionMask(px: ByteArray, w: Int, h: Int): ByteArray? {
        // PARITY-NOTE(AnimeDecomposer.swift:372): VNGenerateForegroundInstanceMaskRequest has no Android system API twin;
        // returning null = "unavailable", the same result iOS gives below iOS 17 / when the request fails.
        return null
    }

    private class Cut(val mask: ByteArray, val alpha: ByteArray)

    private fun foreground(px: ByteArray, L: FloatArray, A: FloatArray, B: FloatArray,
                           w: Int, h: Int, removeBg: Boolean, useAI: Boolean): Cut {
        val n = w * h
        var mask = ByteArray(n) { 1 }
        var alpha = ByteArray(n) { 255.toByte() }

        // images that already carry transparency: trust the alpha channel
        var transparent = 0
        for (i in 0 until n) if ((px[i * 4 + 3].toInt() and 0xFF) < 250) transparent += 1
        if (transparent > n / 100) {
            for (i in 0 until n) {
                alpha[i] = px[i * 4 + 3]
                mask[i] = if ((px[i * 4 + 3].toInt() and 0xFF) > 24) 1 else 0
            }
            return Cut(mask, alpha)
        }
        if (!removeBg || w <= 8 || h <= 8) return Cut(mask, alpha)

        // background colour = median of the border ring
        val bl = ArrayList<Float>(); val ba = ArrayList<Float>(); val bb = ArrayList<Float>()
        fun take(i: Int) { bl.add(L[i]); ba.add(A[i]); bb.add(B[i]) }
        for (x in 0 until w) { take(x); take(w + x); take((h - 1) * w + x); take((h - 2) * w + x) }
        for (y in 2 until h - 2) { take(y * w); take(y * w + 1); take(y * w + w - 1); take(y * w + w - 2) }
        bl.sort(); ba.sort(); bb.sort()
        val ring = bl.size
        val mL = bl[ring / 2]; val mA = ba[ring / 2]; val mB = bb[ring / 2]
        fun dBg(i: Int): Float = labDist(L[i], A[i], B[i], mL, mA, mB)
        fun dPair(i: Int, j: Int): Float = labDist(L[i], A[i], B[i], L[j], A[j], B[j])

        var near = 0
        for (x in 0 until w) {
            if (dBg(x) < 12f) near += 1
            if (dBg((h - 1) * w + x) < 12f) near += 1
        }
        for (y in 0 until h) {
            if (dBg(y * w) < 12f) near += 1
            if (dBg(y * w + w - 1) < 12f) near += 1
        }
        val plain = near.toFloat() / (2 * (w + h)).toFloat() > 0.80f

        // flood fill from the border through background-like pixels
        fun flood(): ByteArray {
            val seen = ByteArray(n)
            var stack = IntArray(n / 4 + 16); var sp = 0
            fun seed(i: Int) { if (seen[i].toInt() == 0 && dBg(i) < 12f) { seen[i] = 1; if (sp == stack.size) stack = stack.copyOf(stack.size * 2); stack[sp++] = i } }
            for (x in 0 until w) { seed(x); seed((h - 1) * w + x) }
            for (y in 0 until h) { seed(y * w); seed(y * w + w - 1) }
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w; val y = i / w
                var k = 0
                while (k < 4) {
                    var nx = x; var ny = y
                    when (k) { 0 -> nx -= 1; 1 -> nx += 1; 2 -> ny -= 1; else -> ny += 1 }
                    k += 1
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val j = ny * w + nx
                    if (seen[j].toInt() != 0) continue
                    val d = dBg(j)
                    if (d < 12f || (d < 26f && dPair(i, j) < 2.0f)) {
                        seen[j] = 1
                        if (sp == stack.size) stack = stack.copyOf(stack.size * 2)
                        stack[sp++] = j
                    }
                }
            }
            // keep the anti-aliased fringe
            val give = ArrayList<Int>()
            for (y in 1 until h - 1) {
                for (x in 1 until w - 1) {
                    val i = y * w + x
                    if (seen[i].toInt() == 0) continue
                    if ((seen[i - 1].toInt() == 0 || seen[i + 1].toInt() == 0 || seen[i - w].toInt() == 0 || seen[i + w].toInt() == 0) && dBg(i) > 4f) {
                        give.add(i)
                    }
                }
            }
            for (i in give) seen[i] = 0
            val out = ByteArray(n) { 1 }
            for (i in 0 until n) if (seen[i].toInt() != 0) out[i] = 0
            return out
        }

        val ml = if (useAI) AnimeSegModel.mask(px, w, h) else null
        val vm = if (ml == null) visionMask(px, w, h) else null
        var fgm: ByteArray
        if (ml != null) {
            fgm = ml.first
        } else if (plain) {
            fgm = flood()
            // gaps between arm and body etc.: flat background-coloured areas that the
            // subject mask also calls background
            if (vm != null) {
                val bgLike = ByteArray(n)
                for (i in 0 until n) if (fgm[i].toInt() != 0 && dBg(i) < 9f) bgLike[i] = 1
                val comps = components(bgLike, w, h, false)
                val minA = max(40, n / 20000)
                val vis = IntArray(comps.areas.size)
                for (i in 0 until n) {
                    val id = comps.ids[i]
                    if (id >= 0 && vm[i].toInt() != 0) vis[id] += 1
                }
                for (i in 0 until n) {
                    val id = comps.ids[i]
                    if (id >= 0 && comps.areas[id] >= minA && vis[id].toFloat() < 0.12f * comps.areas[id]) fgm[i] = 0
                }
            }
        } else if (vm != null) {
            fgm = vm
        } else {
            fgm = flood()
        }

        // fill small holes, drop dust
        val inv = ByteArray(n)
        for (i in 0 until n) if (fgm[i].toInt() == 0) inv[i] = 1
        val holes = components(inv, w, h, false)
        val holeMax = max(16, n / 20000)
        for (i in 0 until n) {
            val id = holes.ids[i]
            if (id < 0) continue
            val b = holes.boxes[id]
            val touches = b[0] <= 0 || b[1] <= 0 || b[2] >= w - 1 || b[3] >= h - 1
            if (!touches && holes.areas[id] < holeMax) fgm[i] = 1
        }
        val comps = components(fgm, w, h, false)
        val keep = max(6, n / 50000)
        var kept = 0
        for (i in 0 until n) if (fgm[i].toInt() != 0) {
            val id = comps.ids[i]
            if (id >= 0 && comps.areas[id] < keep) fgm[i] = 0 else kept += 1
        }
        if (kept == 0) return Cut(mask, alpha)      // never return an empty figure
        mask = fgm
        if (ml != null) for (i in 0 until n) if (mask[i].toInt() != 0) alpha[i] = max(ml.second[i].toInt(), 1).toByte()

        // soft edge on flat backgrounds
        if (plain && ml == null) {
            for (y in 1 until h - 1) {
                for (x in 1 until w - 1) {
                    val i = y * w + x
                    if (mask[i].toInt() == 0) continue
                    if (mask[i - 1].toInt() == 0 || mask[i + 1].toInt() == 0 || mask[i - w].toInt() == 0 || mask[i + w].toInt() == 0) {
                        val t = max(0f, min(1f, (dBg(i) - 3f) / 17f))
                        alpha[i] = max(40, min(255, (t * 255).toInt())).toByte()
                    }
                }
            }
        }
        return Cut(mask, alpha)
    }

    // MARK: - 2 denoise + line art -------------------------------------------------------

    private fun denoise(L: FloatArray, A: FloatArray, B: FloatArray, fg: ByteArray, w: Int, h: Int, passes: Int) {
        if (passes <= 0) return
        for (pass in 0 until passes) {
            val nl = L.copyOf(); val na = A.copyOf(); val nb = B.copyOf()
            for (y in 1 until h - 1) {
                for (x in 1 until w - 1) {
                    val i = y * w + x
                    if (fg[i].toInt() == 0) continue
                    var sl = 0f; var sa = 0f; var sb = 0f; var c = 0f
                    for (dy in -1..1) {
                        for (dx in -1..1) {
                            val j = i + dy * w + dx
                            if (labDist(L[i], A[i], B[i], L[j], A[j], B[j]) < 7f) {
                                sl += L[j]; sa += A[j]; sb += B[j]; c += 1f
                            }
                        }
                    }
                    if (c > 0f) { nl[i] = sl / c; na[i] = sa / c; nb[i] = sb / c }
                }
            }
            System.arraycopy(nl, 0, L, 0, nl.size); System.arraycopy(na, 0, A, 0, na.size); System.arraycopy(nb, 0, B, 0, nb.size)
        }
    }

    private fun lineMask(L: FloatArray, fg: ByteArray, w: Int, h: Int, sens: Int): ByteArray {
        val n = w * h
        val w1 = w + 1
        var integ = IntArray((w + 1) * (h + 1))
        for (y in 0 until h) {
            var row = 0
            for (x in 0 until w) {
                row += max(0, min(100, L[y * w + x].toInt()))
                integ[(y + 1) * w1 + x + 1] = integ[y * w1 + x + 1] + row
            }
        }
        val r = max(3, max(w, h) / 320)
        val contrast = if (sens <= 1) 16f else (if (sens == 2) 12f else 9f)
        val cand = ByteArray(n)
        var candCount = 0
        var fgCount = 0
        for (y in 0 until h) {
            val ya = max(0, y - r); val yb = min(h - 1, y + r)
            for (x in 0 until w) {
                val i = y * w + x
                if (fg[i].toInt() == 0) continue
                fgCount += 1
                val xa = max(0, x - r); val xb = min(w - 1, x + r)
                val s = integ[(yb + 1) * w1 + xb + 1] - integ[ya * w1 + xb + 1] -
                    integ[(yb + 1) * w1 + xa] + integ[ya * w1 + xa]
                val mean = s.toFloat() / ((xb - xa + 1) * (yb - ya + 1)).toFloat()
                val l = L[i]
                if (l < 30f || (l < 66f && l < mean - contrast)) { cand[i] = 1; candCount += 1 }
            }
        }
        integ = IntArray(0)
        if (candCount == 0) return cand
        // thick dark areas (black hair, dark clothes) are fills, not strokes
        val core = opening(cand, w, h, max(2, r * 2 / 3))
        // …and so are dense dark areas that are only broken up by a few highlights
        val dens = integral(cand, w, h)
        val dr = r + 1
        val out = cand.copyOf()
        var lines = 0
        for (y in 0 until h) {
            val ya = max(0, y - dr); val yb = min(h - 1, y + dr)
            for (x in 0 until w) {
                val i = y * w + x
                if (cand[i].toInt() == 0) continue
                var fill = core[i].toInt() != 0
                if (!fill) {
                    val xa = max(0, x - dr); val xb = min(w - 1, x + dr)
                    val s = dens[(yb + 1) * w1 + xb + 1] - dens[ya * w1 + xb + 1] -
                        dens[(yb + 1) * w1 + xa] + dens[ya * w1 + xa]
                    fill = s.toFloat() >= 0.62f * ((xb - xa + 1) * (yb - ya + 1)).toFloat()
                }
                if (fill) out[i] = 0 else lines += 1
            }
        }
        if (lines > fgCount * 3 / 10) return ByteArray(n)
        return out
    }

    // MARK: - 3 colour regions --------------------------------------------------------------

    private fun cluster(L: FloatArray, A: FloatArray, B: FloatArray, elig: ByteArray, n: Int,
                        k0: Int, samples: Int, iters: Int, token: CancelToken): ShortArray? {
        var total = 0
        for (i in 0 until n) if (elig[i].toInt() != 0) total += 1
        if (total == 0) return null
        val step = max(1, total / samples)
        val pts = ArrayList<Int>()
        var c = 0
        for (i in 0 until n) if (elig[i].toInt() != 0) {
            if (c % step == 0) pts.add(i)
            c += 1
        }
        val m = pts.size
        val k = max(2, min(k0, m))
        val wa = 1.3f
        val fl = FloatArray(m); val fa = FloatArray(m); val fb = FloatArray(m)
        for (j in 0 until m) {
            val p = pts[j]
            fl[j] = L[p]; fa[j] = A[p] * wa; fb[j] = B[p] * wa
        }
        var seed = 0x9E3779B97F4A7C15UL
        fun rnd(): Float {
            seed = seed * 6364136223846793005UL + 1442695040888963407UL
            return ((seed shr 40) and 0xFFFFFFUL).toFloat() / 0x1000000f
        }
        val cL = ArrayList<Float>(); val cA = ArrayList<Float>(); val cB = ArrayList<Float>()
        val first = min(m - 1, (rnd() * m).toInt())
        cL.add(fl[first]); cA.add(fa[first]); cB.add(fb[first])
        val dmin = FloatArray(m) { Float.MAX_VALUE }
        while (cL.size < k) {
            val li = cL.size - 1
            var sum = 0.0
            for (j in 0 until m) {
                val dl = fl[j] - cL[li]; val da = fa[j] - cA[li]; val db = fb[j] - cB[li]
                val d = dl * dl + da * da + db * db
                if (d < dmin[j]) dmin[j] = d
                sum += dmin[j].toDouble()
            }
            if (sum <= 0.0) break
            var target = rnd().toDouble() * sum
            var pick = m - 1
            for (j in 0 until m) {
                target -= dmin[j].toDouble()
                if (target <= 0.0) { pick = j; break }
            }
            cL.add(fl[pick]); cA.add(fa[pick]); cB.add(fb[pick])
        }
        val kk = cL.size
        var cnt = IntArray(kk)
        for (it in 0 until iters) {
            val sL = DoubleArray(kk); val sA = DoubleArray(kk); val sB = DoubleArray(kk)
            cnt = IntArray(kk)
            for (j in 0 until m) {
                var best = 0
                var bd = Float.MAX_VALUE
                for (q in 0 until kk) {
                    val dl = fl[j] - cL[q]; val da = fa[j] - cA[q]; val db = fb[j] - cB[q]
                    val d = dl * dl + da * da + db * db
                    if (d < bd) { bd = d; best = q }
                }
                sL[best] += fl[j].toDouble(); sA[best] += fa[j].toDouble(); sB[best] += fb[j].toDouble()
                cnt[best] += 1
            }
            for (q in 0 until kk) if (cnt[q] > 0) {
                cL[q] = (sL[q] / cnt[q]).toFloat()
                cA[q] = (sA[q] / cnt[q]).toFloat()
                cB[q] = (sB[q] / cnt[q]).toFloat()
            }
            if (token.isCancelled) return null
        }
        // merge centroids that are nearly the same colour
        val par = IntArray(kk) { it }
        fun root(x: Int): Int { var r = x; while (par[r] != r) r = par[r]; return r }
        for (p in 0 until kk) {
            for (q in p + 1 until kk) {
                val dl = cL[p] - cL[q]; val da = cA[p] - cA[q]; val db = cB[p] - cB[q]
                if (sqrt(dl * dl + da * da + db * db) < 6.5f) {
                    val rp = root(p); val rq = root(q)
                    if (rp != rq) par[rq] = rp
                }
            }
        }
        val newId = IntArray(kk) { -1 }
        val mL = ArrayList<Float>(); val mA = ArrayList<Float>(); val mB = ArrayList<Float>(); val mC = ArrayList<Float>()
        for (p in 0 until kk) {
            val r = root(p)
            if (newId[r] < 0) {
                newId[r] = mL.size
                mL.add(0f); mA.add(0f); mB.add(0f); mC.add(0f)
            }
            val id = newId[r]
            val wgt = max(1, cnt[p]).toFloat()
            mL[id] += cL[p] * wgt; mA[id] += cA[p] * wgt; mB[id] += cB[p] * wgt; mC[id] += wgt
        }
        val m2 = mL.size
        for (q in 0 until m2) { mL[q] /= mC[q]; mA[q] /= mC[q]; mB[q] /= mC[q] }

        val out = ShortArray(n) { -1 }
        for (i in 0 until n) if (elig[i].toInt() != 0) {
            val l = L[i]; val a = A[i] * wa; val b = B[i] * wa
            var best = 0
            var bd = Float.MAX_VALUE
            for (q in 0 until m2) {
                val dl = l - mL[q]; val da = a - mA[q]; val db = b - mB[q]
                val d = dl * dl + da * da + db * db
                if (d < bd) { bd = d; best = q }
            }
            out[i] = best.toShort()
            if (i and 0x3FFFF == 0 && token.isCancelled) return null
        }
        return out
    }

    private fun majority(cl: ShortArray, w: Int, h: Int, passes: Int) {
        if (passes <= 0) return
        var tmp = cl.copyOf()
        val nb = ShortArray(8)
        for (pass in 0 until passes) {
            for (y in 1 until h - 1) {
                for (x in 1 until w - 1) {
                    val i = y * w + x
                    val c = cl[i]
                    if (c < 0) continue
                    nb[0] = cl[i - w - 1]; nb[1] = cl[i - w]; nb[2] = cl[i - w + 1]
                    nb[3] = cl[i - 1];                            nb[4] = cl[i + 1]
                    nb[5] = cl[i + w - 1]; nb[6] = cl[i + w]; nb[7] = cl[i + w + 1]
                    var same = 0
                    for (v in nb) if (v == c) same += 1
                    if (same >= 3) { tmp[i] = c; continue }
                    var best = c
                    var bc = 0
                    for (v in nb) if (v >= 0) {
                        var k = 0
                        for (u in nb) if (u == v) k += 1
                        if (k > bc) { bc = k; best = v }
                    }
                    tmp[i] = if (bc >= 5) best else c
                }
            }
            System.arraycopy(tmp, 0, cl, 0, tmp.size)
            tmp = cl.copyOf()
        }
    }

    /** 4-connected pieces of equal cluster id. */
    private class Pcs(val ids: IntArray, val count: Int)

    private fun pieces(cl: ShortArray, w: Int, h: Int): Pcs {
        val n = w * h
        val ids = IntArray(n) { -1 }
        var count = 0
        val stack = IntArray(n)
        for (s in 0 until n) if (cl[s] >= 0 && ids[s] < 0) {
            val c = cl[s]
            ids[s] = count
            var sp = 0; stack[sp++] = s
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w; val y = i / w
                if (x > 0) { val j = i - 1; if (ids[j] < 0 && cl[j] == c) { ids[j] = count; stack[sp++] = j } }
                if (x < w - 1) { val j = i + 1; if (ids[j] < 0 && cl[j] == c) { ids[j] = count; stack[sp++] = j } }
                if (y > 0) { val j = i - w; if (ids[j] < 0 && cl[j] == c) { ids[j] = count; stack[sp++] = j } }
                if (y < h - 1) { val j = i + w; if (ids[j] < 0 && cl[j] == c) { ids[j] = count; stack[sp++] = j } }
            }
            count += 1
        }
        return Pcs(ids, count)
    }

    private class Adj(val a: Int, val b: Int, val c: Int)

    private fun edgeList(map: IntArray, w: Int, h: Int, count: Int): Array<HashMap<Int, Int>> {
        val edges = HashMap<Long, Int>()
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val p = map[i]
                if (p < 0) continue
                if (x + 1 < w) {
                    val q = map[i + 1]
                    if (q >= 0 && q != p) {
                        val a = min(p, q).toLong(); val b = max(p, q).toLong()
                        edges[(a shl 32) or b] = (edges[(a shl 32) or b] ?: 0) + 1
                    }
                }
                if (y + 1 < h) {
                    val q = map[i + w]
                    if (q >= 0 && q != p) {
                        val a = min(p, q).toLong(); val b = max(p, q).toLong()
                        edges[(a shl 32) or b] = (edges[(a shl 32) or b] ?: 0) + 1
                    }
                }
            }
        }
        val adj = Array(count) { HashMap<Int, Int>() }
        for ((key, c) in edges) {
            val a = (key shr 32).toInt(); val b = (key and 0xFFFFFFFF).toInt()
            adj[a][b] = (adj[a][b] ?: 0) + c
            adj[b][a] = (adj[b][a] ?: 0) + c
        }
        return adj
    }

    // MARK: - hair locks ---------------------------------------------------------------
    /** Splits the hair mask into locks. Pieces = same-colour regions; tiny ones merge into the
     *  neighbour they share most border with; too many -> smallest merge away; too few ->
     *  the biggest lock is cut lengthwise (side-by-side strands) until `target` is reached. */
    private class Locks(val map: ShortArray, val count: Int)

    private fun hairLocks(hm: ByteArray, reg: IntArray, line: ByteArray, near: IntArray,
                          w: Int, h: Int, minLock: Int, target: Int,
                          token: CancelToken): Locks {
        val n = w * h
        val cid = IntArray(n) { -1 }
        var C = 0
        var stack = IntArray(n)
        val cArea = ArrayList<Int>(); val cSX = ArrayList<Double>(); val cSY = ArrayList<Double>()
        for (s0 in 0 until n) if (hm[s0].toInt() != 0 && cid[s0] < 0) {
            val rg = reg[s0]
            cid[s0] = C; var sp = 0; stack[sp++] = s0
            var a = 0; var sx = 0.0; var sy = 0.0
            while (sp > 0) {
                val i = stack[--sp]; val x = i % w; val y = i / w
                a += 1; sx += x.toDouble(); sy += y.toDouble()
                if (x > 0) { val j = i - 1; if (hm[j].toInt() != 0 && cid[j] < 0 && reg[j] == rg) { cid[j] = C; stack[sp++] = j } }
                if (x < w - 1) { val j = i + 1; if (hm[j].toInt() != 0 && cid[j] < 0 && reg[j] == rg) { cid[j] = C; stack[sp++] = j } }
                if (y > 0) { val j = i - w; if (hm[j].toInt() != 0 && cid[j] < 0 && reg[j] == rg) { cid[j] = C; stack[sp++] = j } }
                if (y < h - 1) { val j = i + w; if (hm[j].toInt() != 0 && cid[j] < 0 && reg[j] == rg) { cid[j] = C; stack[sp++] = j } }
            }
            cArea.add(a); cSX.add(sx); cSY.add(sy)
            C += 1
        }
        if (C == 0 || token.isCancelled) return Locks(ShortArray(0), 0)
        val full = cid.copyOf()
        for (i in 0 until n) if (cid[i] < 0 && line[i].toInt() != 0 && near[i] >= 0) {
            val c = cid[near[i]]
            if (c >= 0) full[i] = c
        }
        val adjArr = edgeList(full, w, h, C)
        val adj = Array(C) { HashMap<Int, Int>() }
        for (a in 0 until C) for ((q, c) in adjArr[a]) adj[a][q] = c
        val parent = IntArray(C) { it }
        fun find(x: Int): Int {
            var r = x
            while (parent[r] != r) r = parent[r]
            var c = x
            while (parent[c] != r) { val nx = parent[c]; parent[c] = r; c = nx }
            return r
        }
        val alive = HashSet<Int>((0 until C).toList())
        fun merge(a: Int, b: Int) {
            parent[a] = b
            cArea[b] += cArea[a]; cSX[b] += cSX[a]; cSY[b] += cSY[a]
            for ((q, c) in adj[a]) if (q != b) {
                adj[b][q] = (adj[b][q] ?: 0) + c
                adj[q][b] = (adj[q][b] ?: 0) + c
                adj[q].remove(a)
            }
            adj[b].remove(a)
            adj[a] = HashMap()
            alive.remove(a)
        }
        fun bestFor(a: Int): Int? {
            var best = -1
            var bs = -1
            for ((q, c) in adj[a]) if (q != a) {
                if (c > bs || (c == bs && best >= 0 && cArea[q] > cArea[best])) { bs = c; best = q }
            }
            if (best >= 0) return best
            val ax = cSX[a] / cArea[a]; val ay = cSY[a] / cArea[a]
            var bd = Double.MAX_VALUE
            for (q in alive) if (q != a) {
                val dx = cSX[q] / cArea[q] - ax; val dy = cSY[q] / cArea[q] - ay
                val d = dx * dx + dy * dy
                if (d < bd) { bd = d; best = q }
            }
            return if (best >= 0) best else null
        }
        val small = alive.sortedBy { cArea[it] }
        for (a in small) if (alive.contains(a) && cArea[a] < minLock && alive.size > 1) {
            bestFor(a)?.let { b -> merge(a, b) }
        }
        while (alive.size > target) {
            val a = alive.minByOrNull { cArea[it] } ?: break
            val b = bestFor(a) ?: break
            merge(a, b)
        }
        if (token.isCancelled) return Locks(ShortArray(0), 0)
        val live = alive.sorted()
        val newId = IntArray(C) { -1 }
        for ((k, a) in live.withIndex()) newId[a] = k
        var K = live.size
        val lock = ShortArray(n) { -1 }
        for (i in 0 until n) if (cid[i] >= 0) lock[i] = newId[find(cid[i])].toShort()
        var area = IntArray(K)
        var bx0 = IntArray(K) { w }; var by0 = IntArray(K) { h }
        var bx1 = IntArray(K) { -1 }; var by1 = IntArray(K) { -1 }
        for (i in 0 until n) if (lock[i] >= 0) {
            val k = lock[i].toInt(); val x = i % w; val y = i / w
            area[k] += 1
            if (x < bx0[k]) bx0[k] = x
            if (x > bx1[k]) bx1[k] = x
            if (y < by0[k]) by0[k] = y
            if (y > by1[k]) by1[k] = y
        }
        var frozen = BooleanArray(K)
        var tries = 0
        while (K < target && K < 200 && tries < 400) {
            tries += 1
            if (token.isCancelled) break
            var g = -1; var ga = 0
            for (k in 0 until K) if (!frozen[k] && area[k] >= 2 * minLock && area[k] > ga) { ga = area[k]; g = k }
            if (g < 0) break
            val xs = ArrayList<Int>()
            var mx = 0.0; var my = 0.0
            val gl = g.toShort()
            for (y in by0[g]..by1[g]) {
                for (x in bx0[g]..bx1[g]) if (lock[y * w + x] == gl) {
                    xs.add(y * w + x); mx += x.toDouble(); my += y.toDouble()
                }
            }
            val m = xs.size
            if (m < 2) { frozen[g] = true; continue }
            mx /= m.toDouble(); my /= m.toDouble()
            var sxx = 0.0; var sxy = 0.0; var syy = 0.0
            for (p in xs) {
                val dx = (p % w).toDouble() - mx; val dy = (p / w).toDouble() - my
                sxx += dx * dx; sxy += dx * dy; syy += dy * dy
            }
            val th = 0.5 * atan2(2 * sxy, sxx - syy)
            val ct = cos(th); val sn = sin(th)
            val pu = FloatArray(m); val pv = FloatArray(m)
            var vv = 0.0
            for ((j, p) in xs.withIndex()) {
                val dx = (p % w).toDouble() - mx; val dy = (p / w).toDouble() - my
                val u = dx * ct + dy * sn; val v = -dx * sn + dy * ct
                pu[j] = (u * 0.35).toFloat(); pv[j] = v.toFloat(); vv += v * v
            }
            val sv = sqrt(vv / m).toFloat()
            var c0u = 0f; var c0v = -sv; var c1u = 0f; var c1v = sv
            val asg = ByteArray(m)
            for (it in 0 until 8) {
                var s0u = 0f; var s0v = 0f; var n0 = 0; var s1u = 0f; var s1v = 0f; var n1 = 0
                for (j in 0 until m) {
                    val d0 = (pu[j] - c0u) * (pu[j] - c0u) + (pv[j] - c0v) * (pv[j] - c0v)
                    val d1 = (pu[j] - c1u) * (pu[j] - c1u) + (pv[j] - c1v) * (pv[j] - c1v)
                    if (d0 <= d1) { asg[j] = 0; s0u += pu[j]; s0v += pv[j]; n0 += 1 }
                    else { asg[j] = 1; s1u += pu[j]; s1v += pv[j]; n1 += 1 }
                }
                if (n0 > 0) { c0u = s0u / n0; c0v = s0v / n0 }
                if (n1 > 0) { c1u = s1u / n1; c1v = s1v / n1 }
            }
            var n1c = 0
            for (a in asg) if (a.toInt() == 1) n1c += 1
            if (n1c < minLock || m - n1c < minLock) { frozen[g] = true; continue }
            val nk = K
            K += 1
            var ob = intArrayOf(w, h, -1, -1); var nb = intArrayOf(w, h, -1, -1)
            for ((j, p) in xs.withIndex()) {
                val x = p % w; val y = p / w
                if (asg[j].toInt() == 1) {
                    lock[p] = nk.toShort()
                    if (x < nb[0]) nb[0] = x; if (y < nb[1]) nb[1] = y; if (x > nb[2]) nb[2] = x; if (y > nb[3]) nb[3] = y
                } else {
                    if (x < ob[0]) ob[0] = x; if (y < ob[1]) ob[1] = y; if (x > ob[2]) ob[2] = x; if (y > ob[3]) ob[3] = y
                }
            }
            area[g] = m - n1c; bx0[g] = ob[0]; by0[g] = ob[1]; bx1[g] = ob[2]; by1[g] = ob[3]
            area = area.copyOf(K + 1); bx0 = bx0.copyOf(K + 1); by0 = by0.copyOf(K + 1)
            bx1 = bx1.copyOf(K + 1); by1 = by1.copyOf(K + 1)
            area[nk] = n1c; bx0[nk] = nb[0]; by0[nk] = nb[1]; bx1[nk] = nb[2]; by1[nk] = nb[3]
            if (frozen.size < K + 1) {
                frozen = frozen.copyOf(K + 1)
            }
        }
        return Locks(lock, K)
    }

    // MARK: - pipeline ------------------------------------------------------------------------

    fun run(rgba: ByteArray, w: Int, h: Int, o: DecomposeOptions,
            token: CancelToken, progress: (Double, String) -> Unit): DecomposeResult? {
        val n = w * h
        if (n <= 0 || rgba.size < n * 4 || w < 16 || h < 16) return null
        val px = rgba

        progress(0.03, "Reading image")
        val L = FloatArray(n); val A = FloatArray(n); val B = FloatArray(n)
        toLab(px, n, L, A, B)
        if (token.isCancelled) return null

        // 1 — cut-out
        progress(0.08, "Cutting out the character")
        val cut = foreground(px, L, A, B, w, h, o.removeBackground, o.useAI)
        val fg = cut.mask
        val fa = cut.alpha
        if (o.useAI) progress(0.12, if (AnimeSegModel.lastUsed == true) "AI cut-out used ✓" else "AI cut-out failed — used classic cut-out")
        var fgCount = 0
        var fx0 = w; var fy0 = h; var fx1 = -1; var fy1 = -1
        for (y in 0 until h) {
            for (x in 0 until w) if (fg[y * w + x].toInt() != 0) {
                fgCount += 1
                if (x < fx0) fx0 = x
                if (x > fx1) fx1 = x
                if (y < fy0) fy0 = y
                if (y > fy1) fy1 = y
            }
        }
        if (fgCount < 64) return null
        val figW = fx1 - fx0 + 1; val figH = fy1 - fy0 + 1
        if (token.isCancelled) return null

        // 2 — denoise, line art
        progress(0.16, "Cleaning the image")
        denoise(L, A, B, fg, w, h, if (o.quality >= 3) 3 else (if (o.quality == 0) 0 else 1))
        if (token.isCancelled) return null
        progress(0.22, "Tracing line art")
        val line = lineMask(L, fg, w, h, o.lineSensitivity)
        val elig = ByteArray(n)
        for (i in 0 until n) if (fg[i].toInt() != 0 && line[i].toInt() == 0) elig[i] = 1
        if (token.isCancelled) return null

        // 3 — colour regions
        progress(0.30, "Finding colour regions")
        val kWanted = 8 + o.detail * 3
        val samples = if (o.quality == 0) 50_000 else (if (o.quality >= 3) 160_000 else 100_000)
        val cl0 = cluster(L, A, B, elig, n, kWanted, samples, if (o.quality == 0) 6 else 10, token) ?: return null
        val cl = cl0
        progress(0.46, "Smoothing edges")
        majority(cl, w, h, o.smoothing)
        if (token.isCancelled) return null

        progress(0.52, "Splitting into pieces")
        val pc = pieces(cl, w, h)
        val pid = pc.ids
        val P = pc.count
        if (P == 0) return null

        // nearest region pixel for every line pixel
        val near = IntArray(n) { -1 }
        run {
            var frontier = ArrayList<Int>()
            for (y in 0 until h) {
                for (x in 0 until w) {
                    val i = y * w + x
                    if (line[i].toInt() == 0) continue
                    var found = -1
                    for (dy in -1..1) {
                        for (dx in -1..1) {
                            if (found >= 0) break
                            val nx = x + dx; val ny = y + dy
                            if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                            val j = ny * w + nx
                            if (pid[j] >= 0) found = j
                        }
                    }
                    if (found >= 0) { near[i] = found; frontier.add(i) }
                }
            }
            while (frontier.isNotEmpty()) {
                val next = ArrayList<Int>()
                for (f in frontier) {
                    val x = f % w; val y = f / w
                    for (dy in -1..1) {
                        for (dx in -1..1) {
                            val nx = x + dx; val ny = y + dy
                            if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                            val j = ny * w + nx
                            if (line[j].toInt() != 0 && near[j] < 0) {
                                near[j] = near[f]
                                next.add(j)
                            }
                        }
                    }
                }
                frontier = next
            }
        }
        if (token.isCancelled) return null

        // piece graph (lines are see-through) and merging of tiny pieces
        val pf = IntArray(n) { -1 }
        for (i in 0 until n) {
            if (pid[i] >= 0) pf[i] = pid[i]
            else if (near[i] >= 0) pf[i] = pid[near[i]]
        }
        val pArea = IntArray(P); val pL = FloatArray(P); val pA = FloatArray(P); val pB = FloatArray(P)
        for (i in 0 until n) {
            val p = pid[i]
            if (p < 0) continue
            pArea[p] += 1; pL[p] += L[i]; pA[p] += A[i]; pB[p] += B[i]
        }
        val adj = edgeList(pf, w, h, P)
        val parent = IntArray(P) { it }
        fun find(x: Int): Int {
            var r = x
            while (parent[r] != r) r = parent[r]
            var c = x
            while (parent[c] != r) { val nx = parent[c]; parent[c] = r; c = nx }
            return r
        }
        val minArea = max(6, n / (60000 + o.detail * 15000))
        val byArea = (0 until P).sortedBy { pArea[it] }
        for (p in byArea) {
            val rp = find(p)
            if (pArea[rp] >= minArea) continue
            var best = -1
            var bestScore = -1f
            val fp = max(1, pArea[rp]).toFloat()
            for ((q, c) in adj[p]) {
                val rq = find(q)
                if (rq == rp) continue
                val fq = max(1, pArea[rq]).toFloat()
                val d = labDist(pL[rp] / fp, pA[rp] / fp, pB[rp] / fp, pL[rq] / fq, pA[rq] / fq, pB[rq] / fq)
                val score = c / (1 + d / 8)
                if (score > bestScore) { bestScore = score; best = rq }
            }
            if (best >= 0) {
                parent[rp] = best
                pArea[best] += pArea[rp]
                pL[best] += pL[rp]; pA[best] += pA[rp]; pB[best] += pB[rp]
            }
        }
        if (token.isCancelled) return null

        // compact region ids
        val regOfRoot = IntArray(P) { -1 }
        val regOfPiece = IntArray(P) { -1 }
        var R = 0
        for (p in 0 until P) {
            val r = find(p)
            if (regOfRoot[r] < 0) { regOfRoot[r] = R; R += 1 }
            regOfPiece[p] = regOfRoot[r]
        }
        val reg = IntArray(n) { -1 }        // region of region pixels
        val regF = IntArray(n) { -1 }       // …filled under line pixels
        for (i in 0 until n) {
            if (pid[i] >= 0) { reg[i] = regOfPiece[pid[i]]; regF[i] = reg[i] }
        }
        for (i in 0 until n) if (line[i].toInt() != 0) {
            if (near[i] >= 0) regF[i] = reg[near[i]]
        }

        // region statistics
        val regs = Array(R) { Reg() }
        val sumR = FloatArray(R); val sumG = FloatArray(R); val sumBl = FloatArray(R)
        val sumL = FloatArray(R); val sumA2 = FloatArray(R); val sumB2 = FloatArray(R)
        val sumX = DoubleArray(R); val sumY = DoubleArray(R)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val r = reg[i]
                if (r < 0) continue
                regs[r].area += 1
                sumR[r] += (px[i * 4].toInt() and 0xFF).toFloat(); sumG[r] += (px[i * 4 + 1].toInt() and 0xFF).toFloat(); sumBl[r] += (px[i * 4 + 2].toInt() and 0xFF).toFloat()
                sumL[r] += L[i]; sumA2[r] += A[i]; sumB2[r] += B[i]
                sumX[r] += x.toDouble(); sumY[r] += y.toDouble()
                if (x < regs[r].x0) regs[r].x0 = x
                if (x > regs[r].x1) regs[r].x1 = x
                if (y < regs[r].y0) regs[r].y0 = y
                if (y > regs[r].y1) regs[r].y1 = y
            }
        }
        for (r in 0 until R) if (regs[r].area > 0) {
            val f = regs[r].area.toFloat()
            regs[r].r = sumR[r] / f; regs[r].g = sumG[r] / f; regs[r].bl = sumBl[r] / f
            regs[r].l = sumL[r] / f; regs[r].a = sumA2[r] / f; regs[r].b = sumB2[r] / f
            regs[r].cx = (sumX[r] / regs[r].area).toFloat()
            regs[r].cy = (sumY[r] / regs[r].area).toFloat()
            regs[r].skin = skinTone(regs[r].r, regs[r].g, regs[r].bl)
        }
        val radjRaw = edgeList(regF, w, h, R)
        if (token.isCancelled) return null

        // 4 — understanding
        progress(0.66, "Finding face, hair and body")
        val fgc = fgCount
        val figTop = fy0.toFloat(); val figHf = figH.toFloat()

        // The face is the skin patch that has eyes / brows / mouth sitting inside it and
        // lies high on the figure — NOT simply the biggest skin patch (on bust shots that
        // is the chest / shoulders, which shifted every Hair / Neck / Arm label).
        var faceMain = -1
        var bestScore = 0f
        for (r in 0 until R) if (regs[r].skin && regs[r].area >= max(minArea, fgc / 400)) {
            val c = regs[r]
            val rel = (c.cy - figTop) / max(1f, figHf)
            if (rel > 0.72f) continue
            var holes = 0
            for ((q, _) in radjRaw[r]) {
                val n2 = regs[q]
                if (!n2.skin && n2.area < c.area
                    && n2.x0 >= c.x0 - 2 && n2.x1 <= c.x1 + 2 && n2.y0 >= c.y0 - 2 && n2.y1 <= c.y1 + 2) {
                    holes += 1
                }
            }
            val score = sqrt(c.area.toFloat()) * (1 + min(holes, 8).toFloat()) * max(0.2f, 1.3f - rel)
            if (score > bestScore) { bestScore = score; faceMain = r }
        }
        if (faceMain < 0) {
            var bestArea = 0
            for (r in 0 until R) if (regs[r].skin && regs[r].cy < figTop + 0.6f * figHf && regs[r].area > bestArea) {
                bestArea = regs[r].area; faceMain = r
            }
        }

        val inSkin = BooleanArray(R)
        var faceX0 = 0; var faceX1 = 0; var ty = 0; var chin = 0
        var faceFound = false
        if (faceMain >= 0) {
            // skin regions connected to the face
            val queue = ArrayList<Int>()
            queue.add(faceMain)
            inSkin[faceMain] = true
            while (queue.isNotEmpty()) {
                val r = queue.removeAt(queue.size - 1)
                for ((q, _) in radjRaw[r]) if (regs[q].skin && !inSkin[q]) {
                    inSkin[q] = true
                    queue.add(q)
                }
            }
            val m = regs[faceMain]
            val mw = m.x1 - m.x0 + 1
            val rx0 = max(0, m.x0 - mw / 4); val rx1 = min(w - 1, m.x1 + mw / 4)
            ty = m.y0
            val yEnd = max(ty, min(h - 1, ty + (0.6f * figHf).toInt()))
            val rowMin = IntArray(h) { w }
            val rowMax = IntArray(h) { -1 }
            for (y in ty..yEnd) {
                for (x in rx0..rx1) {
                    val rr = reg[y * w + x]
                    if (rr >= 0 && inSkin[rr]) {
                        if (x < rowMin[y]) rowMin[y] = x
                        if (x > rowMax[y]) rowMax[y] = x
                    }
                }
            }
            var runMax = 0; var yMaxRow = ty
            var chinRow = -1
            for (y in ty..yEnd) {
                val e = if (rowMax[y] >= 0) rowMax[y] - rowMin[y] + 1 else 0
                if (e > runMax) { runMax = e; yMaxRow = y }
                else if (runMax > 0 && e.toFloat() < 0.62f * runMax.toFloat() && y > yMaxRow + runMax / 6) {
                    chinRow = y; break
                }
            }
            if (chinRow < 0) chinRow = min(fy1, ty + (1.15f * runMax).toInt())
            chin = min(fy1, max(ty + 8, chinRow))
            faceX0 = w; faceX1 = -1
            for (y in ty..min(chin, yEnd)) if (rowMax[y] >= 0) {
                if (rowMin[y] < faceX0) faceX0 = rowMin[y]
                if (rowMax[y] > faceX1) faceX1 = rowMax[y]
            }
            faceFound = faceX1 - faceX0 >= 12 && chin - ty >= 12
            // a "face" as wide / tall as the whole figure is a mis-detection: fall back to
            // generic names instead of confidently wrong ones
            if (faceFound && ((faceX1 - faceX0 + 1).toFloat() > 0.8f * figW.toFloat() || (chin - ty + 1).toFloat() > 0.7f * figHf)) {
                faceFound = false
            }
        }

        for (r in 0 until R) regs[r].part = Part.none
        val defs = ArrayList<LDef>()
        val defIndex = HashMap<String, Int>()
        fun def(name: String, group: String, order: Int): Int {
            defIndex[name]?.let { return it }
            defs.add(LDef(name, group, order))
            defIndex[name] = defs.size - 1
            return defs.size - 1
        }
        val regLayer = IntArray(R) { -1 }

        val fW = (faceX1 - faceX0 + 1).toFloat(); val fH = (chin - ty + 1).toFloat()
        val fcx = (faceX0 + faceX1) * 0.5f
        val tyF = ty.toFloat(); val chinF = chin.toFloat()
        val fx0F = faceX0.toFloat(); val fx1F = faceX1.toFloat()

        fun inHeadBox(r: Int): Boolean {
            val c = regs[r]
            val okX = c.cx >= fx0F - 0.9f * fW && c.cx <= fx1F + 0.9f * fW
            return okX && c.cy <= chinF + 0.2f * fH
        }
        fun inInterior(r: Int): Boolean {
            val c = regs[r]
            val okX = c.x0.toFloat() >= fx0F - 0.05f * fW && c.x1.toFloat() <= fx1F + 0.05f * fW
            val okY = c.y0.toFloat() >= tyF - 0.05f * fH && c.y1.toFloat() <= chinF + 0.05f * fH
            return okX && okY
        }

        val palette = ArrayList<Triple<Float, Float, Float>>()
        fun paletteDist(r: Int): Float {
            var best = Float.MAX_VALUE
            for (p in palette) best = min(best, labDist(regs[r].l, regs[r].a, regs[r].b, p.first, p.second, p.third))
            return best
        }

        if (faceFound) {
            // skin: face vs everything else
            for (r in 0 until R) if (regs[r].skin) {
                val c = regs[r]
                if (inSkin[r]) {
                    val inside = c.cy <= chinF && c.cx >= fx0F - 0.12f * fW && c.cx <= fx1F + 0.12f * fW
                    regs[r].part = if (inside) Part.face else Part.body
                } else {
                    regs[r].part = if (inInterior(r) && c.cy <= chinF) Part.face else Part.body
                }
            }
            // hair seeds: non-skin regions in the head box that are not inside the face
            val seeds = ArrayList<Int>()
            for (r in 0 until R) if (regs[r].part == Part.none && !inInterior(r) && inHeadBox(r) && regs[r].area >= minArea * 2) {
                regs[r].part = Part.hair
                seeds.add(r)
            }
            seeds.sortByDescending { regs[it].area }
            for (r in seeds) if (palette.size < 6) {
                if (palette.isEmpty() || paletteDist(r) > 14f) palette.add(Triple(regs[r].l, regs[r].a, regs[r].b))
            }
            if (palette.isEmpty()) {
                for (r in 0 until R) if (regs[r].part == Part.none && inHeadBox(r)) regs[r].part = Part.hair
            }
            // inside the face: bangs, eyes, brows, mouth
            for (r in 0 until R) if (regs[r].part == Part.none && inInterior(r)) {
                val c = regs[r]
                var touchesHair = false
                for ((q, _) in radjRaw[r]) if (regs[q].part == Part.hair) touchesHair = true
                if (touchesHair && palette.isNotEmpty() && paletteDist(r) < 22f) { regs[r].part = Part.hair; continue }
                val relY = (c.cy - tyF) / max(1f, fH)
                val aspect = (c.x1 - c.x0 + 1).toFloat() / max(1, c.y1 - c.y0 + 1).toFloat()
                if (relY > 0.62f && abs(c.cx - fcx) < 0.3f * fW) regs[r].part = Part.mouth
                else if (c.a > 12f && c.l > 60f && relY > 0.45f) regs[r].part = Part.face   // blush
                else if (aspect > 2.6f && relY < 0.4f) regs[r].part = Part.eyebrows
                else regs[r].part = Part.eyes
            }
            // hair that continues below the head (long hair, tails)
            for (it in 0 until 6) {
                var changed = false
                for (r in 0 until R) if (regs[r].part == Part.none && !regs[r].skin) {
                    if (regs[r].cy > figTop + 0.92f * figHf) continue
                    var touches = 0
                    for ((q, cnt) in radjRaw[r]) if (regs[q].part == Part.hair) touches += cnt
                    if (touches == 0 || palette.isEmpty()) continue
                    val tol = if (regs[r].cy > chinF + 0.5f * fH) 11f else 16f
                    if (paletteDist(r) < tol) { regs[r].part = Part.hair; changed = true }
                }
                if (!changed) break
            }
            // shading that sits on skin
            for (r in 0 until R) if (regs[r].part == Part.none && regs[r].area < fgc / 60 && regs[r].l > 35f) {
                var tot = 0; var skinB = 0; var bestCnt = 0
                var bestPart = Part.none
                for ((q, cnt) in radjRaw[r]) {
                    tot += cnt
                    val pq = regs[q].part
                    if (pq == Part.face || pq == Part.body) {
                        skinB += cnt
                        if (cnt > bestCnt) { bestCnt = cnt; bestPart = pq }
                    }
                }
                if (tot > 0 && skinB * 10 >= tot * 6) regs[r].part = bestPart
            }
            // what is left: accessories near the head, otherwise clothes
            for (r in 0 until R) if (regs[r].part == Part.none) {
                regs[r].part = if (inHeadBox(r) && regs[r].area < fgc / 40) Part.acc else Part.cloth
            }
        } else {
            for (r in 0 until R) {
                if (regs[r].skin) regs[r].part = Part.body
                else if (regs[r].cy < figTop + 0.3f * figHf) regs[r].part = Part.hair
                else regs[r].part = Part.cloth
            }
        }
        if (token.isCancelled) return null

        // 5 — layers
        progress(0.76, "Building layers")
        val faceLayer = if (faceFound) def("Head", "Head", 30) else -1
        val splitFace = o.splitFace && faceFound
        val counters = HashMap<String, Int>()
        fun numbered(base: String): String {
            val c = (counters[base] ?: 0) + 1
            counters[base] = c
            return if (c == 1) base else "$base $c"
        }

        // face parts
        for (r in 0 until R) {
            when (regs[r].part) {
                Part.face -> regLayer[r] = faceLayer
                Part.eyes -> regLayer[r] = if (splitFace) def("Eyes", "Head", 40) else faceLayer
                Part.eyebrows -> regLayer[r] = if (splitFace) def("Eyebrows", "Head", 42) else faceLayer
                Part.mouth -> regLayer[r] = if (splitFace) def("Mouth", "Head", 43) else faceLayer
                else -> {}
            }
        }

        // hair
        val hairRegs = (0 until R).filter { regs[it].part == Part.hair }.sortedByDescending { regs[it].area }
        var hairPix = ShortArray(0)
        var hairLayerOf = IntArray(0)
        if (o.hairStrands) {
            val hm = ByteArray(n)
            var hairPx = 0
            for (i in 0 until n) {
                val r = reg[i]
                if (r >= 0 && regs[r].part == Part.hair) { hm[i] = 1; hairPx += 1 }
            }
            val target = max(1, o.strandLimit)
            val minLock = max(minArea * 3, hairPx / (target * 10))
            val res = hairLocks(hm, reg, line, near, w, h, minLock, target, token)
            if (token.isCancelled) return null
            if (res.count > 0) {
                val sx = DoubleArray(res.count); val sy = DoubleArray(res.count)
                val ar = IntArray(res.count)
                for (i in 0 until n) {
                    val k = res.map[i].toInt()
                    if (k >= 0) { ar[k] += 1; sx[k] += (i % w).toDouble(); sy[k] += (i / w).toDouble() }
                }
                val ord = (0 until res.count).filter { ar[it] > 0 }.sortedByDescending { ar[it] }
                hairLayerOf = IntArray(res.count) { -1 }
                for (k in ord) {
                    val cx = (sx[k] / ar[k]).toFloat(); val cy = (sy[k] / ar[k]).toFloat()
                    var base = "Hair strand"
                    if (faceFound) {
                        if (cy < tyF) base = "Hair top"
                        else if (cx < fx0F) base = "Hair left"
                        else if (cx > fx1F) base = "Hair right"
                        else if (cy > chinF) base = "Hair back"
                        else base = "Bangs"
                    }
                    hairLayerOf[k] = def(numbered(base), "Hair", 50)
                }
                hairPix = res.map
            }
            for (r in hairRegs) regLayer[r] = def("Hair", "Hair", 50)
        } else if (hairRegs.isNotEmpty()) {
            val pal = ArrayList<Triple<Float, Float, Float>>()
            val palLayer = ArrayList<Int>()
            for (r in hairRegs) {
                var bi = -1
                var bd = 16f
                for ((i, p) in pal.withIndex()) {
                    val d = labDist(regs[r].l, regs[r].a, regs[r].b, p.first, p.second, p.third)
                    if (d < bd) { bd = d; bi = i }
                }
                if (bi < 0) {
                    var nm = "Hair"
                    if (pal.isNotEmpty()) {
                        nm = if (regs[r].l > pal[0].first + 6f) numbered("Hair highlight") else numbered("Hair shadow")
                    }
                    pal.add(Triple(regs[r].l, regs[r].a, regs[r].b))
                    palLayer.add(def(nm, "Hair", 50))
                    bi = pal.size - 1
                }
                regLayer[r] = palLayer[bi]
            }
        }

        // clothes: same-coloured touching regions form one garment
        val clothRegs = (0 until R).filter { regs[it].part == Part.cloth }
        if (clothRegs.isNotEmpty()) {
            if (!o.splitClothes) {
                val d = def("Clothes", "Clothes", 25)
                for (r in clothRegs) regLayer[r] = d
            } else {
                val cp = IntArray(R) { it }
                fun croot(x: Int): Int { var r = x; while (cp[r] != r) r = cp[r]; return r }
                for (r in clothRegs) {
                    for ((q, _) in radjRaw[r]) if (regs[q].part == Part.cloth) {
                        val d = labDist(regs[r].l, regs[r].a, regs[r].b, regs[q].l, regs[q].a, regs[q].b)
                        if (d < 26f) {
                            val a = croot(r); val b = croot(q)
                            if (a != b) cp[b] = a
                        }
                    }
                }
                val compArea = HashMap<Int, Int>()
                for (r in clothRegs) compArea[croot(r)] = (compArea[croot(r)] ?: 0) + regs[r].area
                val comps = compArea.keys.sortedByDescending { compArea[it] ?: 0 }
                val kept = ArrayList<Int>()
                for (c in comps) if (kept.size < 8 && (compArea[c] ?: 0) >= fgc / 150) kept.add(c)
                if (kept.isEmpty()) comps.firstOrNull()?.let { kept.add(it) }
                val rootOf = HashMap<Int, Int>()
                val members = HashMap<Int, MutableList<Int>>()
                for (r in clothRegs) { val c = croot(r); rootOf[r] = c; members.getOrPut(c) { ArrayList() }.add(r) }
                val compLayer = HashMap<Int, Int>()
                for (c in kept) {
                    var sy = 0.0; var cnt = 0.0
                    for (r in members[c] ?: emptyList()) { sy += regs[r].cy.toDouble() * regs[r].area; cnt += regs[r].area.toDouble() }
                    val rel = ((sy / max(1.0, cnt)).toFloat() - figTop) / max(1f, figHf)
                    val fullFig = faceFound && (chinF - tyF) < 0.30f * figHf   // head is small => whole body in frame
                    val base = if (fullFig) (if (rel > 0.86f) "Footwear" else (if (rel > 0.6f) "Clothes bottom" else "Clothes top")) else (if (rel > 0.8f) "Clothes bottom" else "Clothes top")
                    compLayer[c] = def(numbered(base), "Clothes", 25)
                }
                for (r in clothRegs) {
                    val c = rootOf[r] ?: r
                    val dl = compLayer[c]
                    if (dl != null) { regLayer[r] = dl; continue }
                    var bi = kept[0]
                    var bd = Float.MAX_VALUE
                    for (k in kept) {
                        var best = Float.MAX_VALUE
                        for (q in members[k] ?: emptyList()) {
                            val dx = regs[q].cx - regs[r].cx; val dy = regs[q].cy - regs[r].cy
                            best = min(best, dx * dx + dy * dy)
                        }
                        if (best < bd) { bd = best; bi = k }
                    }
                    regLayer[r] = compLayer[bi] ?: 0
                }
            }
        }

        // accessories
        for (r in 0 until R) if (regs[r].part == Part.acc) regLayer[r] = def("Accessories", "Accessories", 60)

        // per-pixel layer map
        val layerOf = ShortArray(n) { -1 }
        val pending = ByteArray(n)      // skin that still needs neck / arm / leg naming
        val neckX0 = fx0F + 0.05f * fW; val neckX1 = fx1F - 0.05f * fW
        val neck = ByteArray(n)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val r = reg[i]
                if (r < 0) continue
                val part = regs[r].part
                if (part == Part.body || (part == Part.face && faceFound && y > chin)) {
                    pending[i] = 1
                    if (faceFound && y > chin && y <= chin + (0.55f * fH).toInt()
                        && x.toFloat() >= neckX0 && x.toFloat() <= neckX1) neck[i] = 1
                } else if (regLayer[r] >= 0) {
                    var ll = regLayer[r]
                    if (hairPix.isNotEmpty() && hairPix[i] >= 0) ll = hairLayerOf[hairPix[i].toInt()]
                    layerOf[i] = ll.toShort()
                }
            }
        }
        // body skin
        run {
            var anyPending = false
            for (i in 0 until n) if (pending[i].toInt() != 0) { anyPending = true; break }
            if (anyPending) {
                if (!o.splitBody) {
                    val d = def("Body skin", "Body", 20)
                    for (i in 0 until n) if (pending[i].toInt() != 0) layerOf[i] = d.toShort()
                } else {
                    val base = def("Body skin", "Body", 20)
                    var neckLayer = -1
                    val rest = ByteArray(n)
                    var neckCount = 0
                    for (i in 0 until n) if (pending[i].toInt() != 0) {
                        if (neck[i].toInt() != 0) neckCount += 1 else rest[i] = 1
                    }
                    if (neckCount > 20) {
                        neckLayer = def("Neck", "Body", 21)
                        for (i in 0 until n) if (neck[i].toInt() != 0) layerOf[i] = neckLayer.toShort()
                    }
                    val comps = components(rest, w, h, true)
                    val order = (0 until comps.areas.size).sortedByDescending { comps.areas[it] }
                    val compLayer = IntArray(comps.areas.size) { base }
                    var made = 0
                    val cxFig = (fx0 + fx1) * 0.5f
                    val fullBody = faceFound && (chinF - tyF) < 0.30f * figHf
                    for (c in order) if (made < 8 && comps.areas[c] >= max(40, fgc / 150)) {
                        val b = comps.boxes[c]
                        val cx = (b[0] + b[2]) * 0.5f; val cy = (b[1] + b[3]) * 0.5f
                        val rel = (cy - figTop) / max(1f, figHf)
                        val bw = (b[2] - b[0] + 1).toFloat()
                        val nm: String
                        if (rel > 0.62f && fullBody && comps.areas[c] >= fgc / 80 && (b[3] - b[1] + 1).toFloat() >= 0.10f * figHf) {
                            nm = if (bw > 0.5f * figW) "Legs" else (if (cx < cxFig) "Leg L" else "Leg R")
                        } else if (abs(cx - cxFig) < 0.12f * figW && bw < 0.3f * figW) {
                            nm = "Torso skin"
                        } else {
                            nm = if (cx < cxFig) "Arm L" else "Arm R"
                        }
                        compLayer[c] = def(numbered(nm), "Body", 20)
                        made += 1
                    }
                    for (i in 0 until n) if (rest[i].toInt() != 0) {
                        val id = comps.ids[i]
                        layerOf[i] = (if (id >= 0) compLayer[id] else base).toShort()
                    }
                }
            }
        }

        // line pixels
        var compKind = ByteArray(0)
        var lineComps: Comps? = null
        var eyesY = tyF + 0.5f * fH
        if (faceFound) {
            var sy = 0f; var sa = 0f
            for (r in 0 until R) if (regs[r].part == Part.eyes) { sy += regs[r].cy * regs[r].area; sa += regs[r].area.toFloat() }
            if (sa > 0f) eyesY = sy / sa
            val lc = components(line, w, h, true)
            lineComps = lc
            compKind = ByteArray(lc.areas.size)
            for (c in 0 until lc.areas.size) {
                val b = lc.boxes[c]
                val okX = b[0].toFloat() >= fx0F + 0.05f * fW && b[2].toFloat() <= fx1F - 0.05f * fW
                val okY = b[1].toFloat() >= tyF - 0.05f * fH && b[3].toFloat() <= chinF - 0.02f * fH
                if (!(okX && okY && lc.areas[c] < fgc / 25)) continue
                val cx = (b[0] + b[2]) * 0.5f; val cy = (b[1] + b[3]) * 0.5f
                if (cy > chinF - 0.34f * fH && abs(cx - fcx) < 0.3f * fW) compKind[c] = 3   // mouth
                else if (abs(cy - eyesY) <= 0.14f * fH) compKind[c] = 1                     // eyelids
                else if (cy < eyesY - 0.14f * fH) compKind[c] = 2                            // eyebrows
                else compKind[c] = 4                                                          // nose etc.
            }
        }
        for (i in 0 until n) if (line[i].toInt() != 0) {
            val nr = near[i]
            val nearLayer: Int = if (nr >= 0) layerOf[nr].toInt() else -1
            var target = -1
            val lc = lineComps
            if (lc != null && (splitFace || faceFound)) {
                val id = lc.ids[i]
                val kind = if (id >= 0 && id < compKind.size) compKind[id].toInt() else 0
                if (kind != 0) {
                    if (!splitFace) target = faceLayer
                    else if (kind == 1) target = def("Eyelids", "Head", 41)
                    else if (kind == 2) target = def("Eyebrows", "Head", 42)
                    else if (kind == 3) target = def("Mouth", "Head", 43)
                    else target = def("Head lines", "Head", 71)
                }
            }
            if (o.hairStrands && hairPix.isNotEmpty() && target < 0 && nearLayer >= 0 && o.lineMode != 1) {
                val rr0 = regF[i]
                if (rr0 >= 0 && regs[rr0].part == Part.hair) target = nearLayer
            }
            if (target < 0) {
                if (o.lineMode == 0) {
                    target = if (nearLayer >= 0) nearLayer else def("Line art", if (o.autoGroup) "Line art" else "", 70)
                } else if (o.lineMode == 1) {
                    target = def("Line art", "Line art", 70)
                } else {
                    val rr = regF[i]
                    var nm = "Line art"; var grp = "Line art"
                    if (rr >= 0) {
                        when (regs[rr].part) {
                            Part.hair -> { nm = "Hair lines"; grp = "Hair" }
                            Part.face, Part.eyes, Part.eyebrows, Part.mouth -> { nm = "Head lines"; grp = "Head" }
                            Part.body -> { nm = "Body lines"; grp = "Body" }
                            Part.cloth -> { nm = "Clothes lines"; grp = "Clothes" }
                            Part.acc -> { nm = "Accessory lines"; grp = "Accessories" }
                            Part.none -> {}
                        }
                    }
                    target = def(nm, grp, 70)
                }
            }
            layerOf[i] = target.toShort()
        }

        // background + stragglers
        var bgLayer = -1
        if (o.keepBackground) {
            var any = false
            for (i in 0 until n) if (fg[i].toInt() == 0 && (px[i * 4 + 3].toInt() and 0xFF) > 8) { any = true; break }
            if (any) bgLayer = def("Background", "Background", 0)
        }
        var strayLayer = -1
        for (i in 0 until n) {
            if (fg[i].toInt() != 0) {
                if (layerOf[i] < 0) {
                    if (strayLayer < 0) strayLayer = def("Details", "", 65)
                    layerOf[i] = strayLayer.toShort()
                }
            } else if (bgLayer >= 0 && (px[i * 4 + 3].toInt() and 0xFF) > 8) {
                layerOf[i] = bgLayer.toShort()
            }
        }

        // 6 — bitmaps
        progress(0.88, "Cutting layers")
        val count = defs.size
        val x0 = IntArray(count) { w }
        val y0 = IntArray(count) { h }
        val x1 = IntArray(count) { -1 }
        val y1 = IntArray(count) { -1 }
        val ar = IntArray(count)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val l = layerOf[y * w + x].toInt()
                if (l < 0) continue
                ar[l] += 1
                if (x < x0[l]) x0[l] = x
                if (x > x1[l]) x1[l] = x
                if (y < y0[l]) y0[l] = y
                if (y > y1[l]) y1[l] = y
            }
        }
        val ids = (0 until count).filter { ar[it] >= 1 && x1[it] >= 0 }.sortedWith { a, b ->
            if (defs[a].order != defs[b].order) defs[a].order.compareTo(defs[b].order) else a.compareTo(b)
        }
        val rank = IntArray(count)
        for ((k, d) in ids.withIndex()) rank[d] = k
        val baseD = if (o.fillGaps) min(14, max(3, max(figW, figH) / 90)) else 0
        val layers = ArrayList<DecomposedLayer>()
        for (d in ids) {
            if (token.isCancelled) return null
            var D = 0
            if (o.fillGaps && defs[d].order < 65 && d != bgLayer) {
                D = baseD
                if (d == faceLayer && faceFound) D = max(D, (0.15f * fW).toInt())
            }
            val ex0 = max(0, x0[d] - D); val ey0 = max(0, y0[d] - D)
            val ex1 = min(w - 1, x1[d] + D); val ey1 = min(h - 1, y1[d] + D)
            val lw = ex1 - ex0 + 1; val lh = ey1 - ey0 + 1
            val buf = ByteArray(lw * lh * 4)
            val st = ByteArray(lw * lh)     // 1 filled · 2 pending
            val d16 = d.toShort()
            for (yy in 0 until lh) {
                val y = ey0 + yy
                for (xx in 0 until lw) {
                    val i = y * w + ex0 + xx
                    if (layerOf[i] != d16) continue
                    val o4 = (yy * lw + xx) * 4
                    buf[o4] = px[i * 4]; buf[o4 + 1] = px[i * 4 + 1]; buf[o4 + 2] = px[i * 4 + 2]
                    buf[o4 + 3] = if (d == bgLayer) px[i * 4 + 3] else fa[i]
                    st[yy * lw + xx] = 1
                }
            }
            if (D > 0) {
                // hidden underlap: only below fully opaque pixels of layers stacked above this one,
                // only inside the figure, colour = average of the already-filled neighbours (no streaks)
                fun elig(xx: Int, yy: Int): Boolean {
                    val i = (ey0 + yy) * w + ex0 + xx
                    val l = layerOf[i].toInt()
                    return l >= 0 && l != d && l != bgLayer && fg[i].toInt() != 0 && (fa[i].toInt() and 0xFF) == 255 && rank[l] > rank[d]
                }
                var frontier = ArrayList<Int>()
                for (yy in 0 until lh) {
                    for (xx in 0 until lw) if (st[yy * lw + xx].toInt() == 1) {
                        if ((xx > 0 && st[yy * lw + xx - 1].toInt() == 0 && elig(xx - 1, yy))
                            || (xx < lw - 1 && st[yy * lw + xx + 1].toInt() == 0 && elig(xx + 1, yy))
                            || (yy > 0 && st[(yy - 1) * lw + xx].toInt() == 0 && elig(xx, yy - 1))
                            || (yy < lh - 1 && st[(yy + 1) * lw + xx].toInt() == 0 && elig(xx, yy + 1))) {
                            frontier.add(yy * lw + xx)
                        }
                    }
                }
                var step = 0
                while (frontier.isNotEmpty() && step < D) {
                    val next = ArrayList<Int>()
                    for (f in frontier) {
                        val fx = f % lw; val fy = f / lw
                        var k = 0
                        while (k < 4) {
                            var nx = fx; var ny = fy
                            when (k) { 0 -> nx -= 1; 1 -> nx += 1; 2 -> ny -= 1; else -> ny += 1 }
                            k += 1
                            if (nx < 0 || ny < 0 || nx >= lw || ny >= lh) continue
                            val j = ny * lw + nx
                            if (st[j].toInt() == 0 && elig(nx, ny)) { st[j] = 2; next.add(j) }
                        }
                    }
                    for (j in next) {
                        val jx = j % lw; val jy = j / lw
                        var sr = 0; var sg = 0; var sb = 0; var c = 0
                        for (dy in -1..1) {
                            for (dx in -1..1) {
                                if (dx == 0 && dy == 0) continue
                                val nx = jx + dx; val ny = jy + dy
                                if (nx < 0 || ny < 0 || nx >= lw || ny >= lh) continue
                                val q = ny * lw + nx
                                if (st[q].toInt() == 1) { sr += buf[q * 4].toInt() and 0xFF; sg += buf[q * 4 + 1].toInt() and 0xFF; sb += buf[q * 4 + 2].toInt() and 0xFF; c += 1 }
                            }
                        }
                        if (c > 0) {
                            buf[j * 4] = (sr / c).toByte(); buf[j * 4 + 1] = (sg / c).toByte(); buf[j * 4 + 2] = (sb / c).toByte()
                            buf[j * 4 + 3] = 255.toByte()
                        }
                    }
                    for (j in next) st[j] = 1
                    frontier = next
                    step += 1
                }
            }
            layers.add(DecomposedLayer(defs[d].name, ex0, ey0, lw, lh, buf, true, ar[d],
                if (o.autoGroup) defs[d].group else "", defs[d].order))
        }
        if (layers.isEmpty()) return null
        progress(1.0, "Done")
        return DecomposeResult(w, h, layers)
    }
}
