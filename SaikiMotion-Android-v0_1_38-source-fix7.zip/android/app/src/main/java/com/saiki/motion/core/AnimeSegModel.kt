@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.core

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

// Port of Sources/Tools/AnimeSegModel.swift — optional on-device AI cut-out
// (ISNet anime segmentation).
//
// The Swift looks for a model whose file name contains "isnet" or "anime"
// (.mlmodelc / .mlpackage / .mlmodel) inside the app bundle or Documents, or an
// isnetis.onnx (Hugging Face skytnt/anime-seg) download. Inference runs through
// OnnxRuntime (the Android AAR twin of OnnxRuntimeBindings).

object AnimeSegModel {
    const val onnxName = "isnetis.onnx"
    const val onnxRemote = "https://huggingface.co/skytnt/anime-seg/resolve/main/isnetis.onnx"

    @Volatile var lastError: String? = null
        private set
    @Volatile var lastUsed: Boolean? = null
        private set
    @Volatile var testSecs: Double = 0.0

    private val lock = ReentrantLock()

    val onnxURL: File?
        get() {
            val dirs = ArrayList<File>()
            dirs.add(File(Paths.appContext.filesDir, "AnimeSeg"))
            dirs.add(Paths.appContext.filesDir)
            for (d in dirs) {
                val exact = File(d, onnxName)
                if (exact.exists()) return exact
                val list = try { d.listFiles() } catch (_: Exception) { null } ?: continue
                for (u in list) if (u.extension.lowercase() == "onnx") {
                    val nm = u.name.lowercase()
                    if (nm.contains("isnet") || nm.contains("anime")) return u
                }
            }
            return null
        }

    val onnxInstalled: Boolean get() = onnxURL != null

    /** OnnxRuntimeBindings linked → true on Android (ORT AAR is a dependency). */
    val runtimeLinked: Boolean get() = true

    val isAvailable: Boolean get() = onnxInstalled && runtimeLinked

    // ---- ORT session (AnimeSegModel.swift:171-190 session()) -------------------------------------
    @Volatile private var ortSession: OrtSession? = null
    @Volatile private var ortFailed = false
    private var ortIn = "img"
    private var ortOut = "mask"

    private fun session(): OrtSession? = lock.withLock {
        ortSession?.let { return it }
        if (ortFailed) return null
        val url = onnxURL ?: return null
        return try {
            val env = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
            val s = env.createSession(url.path, opts)
            ortIn = s.inputNames.firstOrNull() ?: "img"
            ortOut = s.outputNames.firstOrNull() ?: "mask"
            ortSession = s
            s
        } catch (e: Exception) { ortFailed = true; lastError = e.message; null }
    }

    /** Loads the model for real; false = the file is missing/corrupt or the runtime isn't linked. */
    fun verify(): Boolean {
        val s = session()
        if (s == null) { if (lastError == null) lastError = "model not found"; return false }
        return true
    }

    fun removeModel() {
        lock.withLock { ortSession?.close(); ortSession = null; ortFailed = false }
        onnxURL?.delete()
    }

    /** One-tap download into filesDir/AnimeSeg (176 MB, needs internet once). */
    fun download(progress: (Double) -> Unit, done: (Boolean) -> Unit) {
        Thread {
            var ok = false
            try {
                val conn = URL(onnxRemote).openConnection() as HttpURLConnection
                conn.connectTimeout = 30000
                conn.readTimeout = 30000
                conn.setRequestProperty("User-Agent", "SaikiMotion/1.0")
                val code = conn.responseCode
                if (code == 200) {
                    val dir = File(Paths.appContext.filesDir, "AnimeSeg")
                    dir.mkdirs()
                    val dest = File(dir, onnxName)
                    dest.delete()
                    var written = 0L
                    val total = conn.contentLengthLong
                    FileOutputStream(dest).use { os ->
                        val buf = ByteArray(1 shl 16)
                        while (true) {
                            val c = conn.inputStream.read(buf)
                            if (c < 0) break
                            os.write(buf, 0, c); written += c
                            if (total > 0) progress(written.toDouble() / total)
                        }
                    }
                    ok = written > 50_000_000
                    if (!ok) dest.delete()
                }
                conn.disconnect()
            } catch (_: Exception) {}
            done(ok)
        }.start()
    }

    /** Foreground mask (>0.5) and soft alpha at the working resolution, or null. */
    fun mask(px: ByteArray, w: Int, h: Int): Pair<ByteArray, ByteArray>? {
        val r = onnxMask(px, w, h)
        if (r != null) return r
        lastUsed = false
        return null
    }

    private class RawOut internal constructor(val map: FloatArray, val S: Int, val ox: Int, val oy: Int, val nw: Int, val nh: Int)

    @Volatile private var ortSize = 1024

    // ---- onnxRaw (AnimeSegModel.swift:204-246): bilinear planes → ORT run → float map -------
    private fun onnxRaw(px: ByteArray, w: Int, h: Int): RawOut? {
        val sess = session() ?: run { lastError = lastError ?: "ONNX runtime is not linked into this build"; return null }
        val sizes = if (ortSize == 1024) intArrayOf(1024, 640) else intArrayOf(640, 1024)
        for (S in sizes) {
            try {
                val sc = S.toFloat() / max(w, h).toFloat()
                val nw = max(1, Math.round(w * sc)); val nh = max(1, Math.round(h * sc))
                val ox = (S - nw) / 2; val oy = (S - nh) / 2
                val plane = S * S
                val fp = FloatArray(3 * plane)   // zero padded
                for (y in 0 until nh) {
                    val fy = max(0f, min((h - 1).toFloat(), (y + 0.5f) / sc - 0.5f))
                    val y0 = fy.toInt(); val y1 = min(h - 1, y0 + 1); val ty = fy - y0
                    for (x in 0 until nw) {
                        val fx = max(0f, min((w - 1).toFloat(), (x + 0.5f) / sc - 0.5f))
                        val x0 = fx.toInt(); val x1 = min(w - 1, x0 + 1); val tx = fx - x0
                        for (c in 0 until 3) {
                            val a = (px[(y0 * w + x0) * 4 + c].toInt() and 0xFF) * (1 - tx) + (px[(y0 * w + x1) * 4 + c].toInt() and 0xFF) * tx
                            val b = (px[(y1 * w + x0) * 4 + c].toInt() and 0xFF) * (1 - tx) + (px[(y1 * w + x1) * 4 + c].toInt() and 0xFF) * tx
                            fp[c * plane + (y + oy) * S + (x + ox)] = (a * (1 - ty) + b * ty) / 255f
                        }
                    }
                }
                val env = OrtEnvironment.getEnvironment()
                val shape = longArrayOf(1, 3, S.toLong(), S.toLong())
                OnnxTensor.createTensor(env, FloatBuffer.wrap(fp), shape).use { input ->
                    sess.run(mapOf(ortIn to input)).use { out ->
                        @Suppress("UNCHECKED_CAST")
                        val ov = out[0].value as? Array<FloatArray> ?: out.get(0).value as? Array<FloatArray>
                        val map = FloatArray(plane)
                        when (val v = out[0].value) {
                            is Array<*> -> {
                                // [1][1][S][S] nested arrays
                                fun flat(a: Any?, dst: FloatArray, idx: Int = 0): Int {
                                    when (a) {
                                        is Float -> if (idx < dst.size) dst[idx] = a
                                        is Array<*> -> { var i = idx; for (e in a) i = flat(e, dst, i); return i }
                                        else -> {}
                                    }
                                    return idx + 1
                                }
                                flat(v, map)
                            }
                            is FloatBuffer -> { v.position(0); v.get(map, 0, min(v.remaining(), plane)) }
                            else -> if (ov != null && ov.isNotEmpty() && ov[0].size == plane) {
                                for (i in 0 until plane) map[i] = ov[0][i]
                            }
                        }
                        ortSize = S
                        return RawOut(map, S, ox, oy, nw, nh)
                    }
                }
            } catch (e: Exception) { lastError = e.message; continue }
        }
        return null
    }

    private fun onnxMask(px: ByteArray, w: Int, h: Int): Pair<ByteArray, ByteArray>? {
        val r = onnxRaw(px, w, h) ?: run { lastUsed = false; return null }
        val res = finish(r.map, r.S, r.S, r.ox, r.oy, r.nw, r.nh, w, h)
        lastUsed = res != null
        if (res == null) lastError = "model returned an empty or full mask"
        return res
    }

    /** Runs the model once on a generated test picture; proves inference works on this phone. */
    fun selfTest(): Pair<Boolean, Double> {
        val n = 384
        val px = ByteArray(n * n * 4) { 255.toByte() }
        for (y in 0 until n) for (x in 0 until n) {
            val i = (y * n + x) * 4
            val dx = (x - n / 2).toFloat(); val dy = (y - 130).toFloat()
            if (dx * dx / (70f * 70f) + dy * dy / (85f * 85f) < 1f) {
                if (dy < -30f) { px[i] = 50.toByte(); px[i + 1] = 35.toByte(); px[i + 2] = 60.toByte() }
                else { px[i] = 250.toByte(); px[i + 1] = 222.toByte(); px[i + 2] = 205.toByte() }
            } else if (y > 205 && kotlin.math.abs(dx) < 90f) { px[i] = 70.toByte(); px[i + 1] = 90.toByte(); px[i + 2] = 160.toByte() }
        }
        val t0 = System.nanoTime()
        val r = onnxRaw(px, n, n) ?: return Pair(false, 0.0)
        var ok = true
        for (v in r.map) if (!v.isFinite()) { ok = false; break }
        if (!ok) lastError = "model output was not valid numbers"
        testSecs = (System.nanoTime() - t0) / 1e9
        return Pair(ok, testSecs)
    }

    /** sigmoid if needed → bilinear resize of the (cropped) map to w×h → mask + alpha. */
    private fun finish(map0: FloatArray, mw: Int, mh: Int, cropX: Int, cropY: Int, cropW: Int, cropH: Int,
                       w: Int, h: Int): Pair<ByteArray, ByteArray>? {
        val map = map0.copyOf()
        var lo = Float.MAX_VALUE; var hi = -Float.MAX_VALUE
        for (v in map) { if (v < lo) lo = v; if (v > hi) hi = v }
        if (lo < -0.01f || hi > 1.01f) for (i in map.indices) map[i] = 1f / (1f + exp(-map[i]))
        val mask = ByteArray(w * h)
        val alpha = ByteArray(w * h)
        var on = 0
        for (y in 0 until h) {
            val fy = max(0f, min((cropH - 1).toFloat(), (y + 0.5f) * cropH / h.toFloat() - 0.5f))
            val y0 = fy.toInt(); val y1 = min(cropH - 1, y0 + 1); val ty = fy - y0
            for (x in 0 until w) {
                val fx = max(0f, min((cropW - 1).toFloat(), (x + 0.5f) * cropW / w.toFloat() - 0.5f))
                val x0 = fx.toInt(); val x1 = min(cropW - 1, x0 + 1); val tx = fx - x0
                val r0 = (cropY + y0) * mw + cropX; val r1 = (cropY + y1) * mw + cropX
                val a = map[r0 + x0] * (1 - tx) + map[r0 + x1] * tx
                val b = map[r1 + x0] * (1 - tx) + map[r1 + x1] * tx
                val v = max(0f, min(1f, a * (1 - ty) + b * ty))
                alpha[y * w + x] = (v * 255).toInt().toByte()
                if (v > 0.5f) { mask[y * w + x] = 1; on += 1 }
            }
        }
        val frac = on.toFloat() / (w * h).toFloat()
        if (frac < 0.004f || frac > 0.985f) return null
        return Pair(mask, alpha)
    }
}
