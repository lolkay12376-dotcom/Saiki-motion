package com.saiki.motion.core

// Port of Sources/Support/AppInfo.swift — version identity.
object AppInfo {
    /** Marketing version. Keep in lockstep with the app's build.gradle versionName. */
    const val version = "0.1.36"
    /** Build number. Bump on EVERY build. */
    const val build = 74
    /** Bundle identifier of the app. */
    const val bundleId = "com.saiki.motion.app"

    /** Display string for the Account/About tab. */
    val displayVersion: String get() = "$version ($build)"
}
