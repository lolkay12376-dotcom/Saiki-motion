package com.saiki.motion.core

/** Bundle.main.resourceURL equivalent: shared/resources is packaged as Android assets (build.gradle assets.srcDirs). */
object Assets {
    fun readText(path: String): String? = try {
        Paths.appContext.assets.open(path).use { String(it.readBytes(), Charsets.UTF_8) }
    } catch (_: Exception) { null }

    fun list(path: String): List<String> = try { Paths.appContext.assets.list(path)?.toList() ?: emptyList() } catch (_: Exception) { emptyList() }
}
