package com.saiki.motion.core

import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tan
import kotlin.math.tanh

private fun exp2v(x: Float): Float = 2f.pow(x)

// Port of Sources/Media/AudioFx.swift — per-audio-layer effect chain: model, parameter defs, offline DSP
// and render cache. Effects: Flanger, Chorus, Modulator, Phaser, Panning, Reverb, Muffle, Tone, Equalizer,
// Echo, Distortion, Compressor, Auto-Wah, Bitcrusher, Stereo Widener, Noise Gate.
// Every parameter can be keyframed (tracks named afx<uid>__<param> on the layer); processors smooth every change.
// The chain renders offline (streaming, chunked) into a cached stereo WAV the preview and exporter both use.
class AudioFxItem(val type: String) {
    var on = true
    var blend = 0.5f
    var p = HashMap<String, Float>()
    var uid: Int = newUid()        // stable id: keyframe tracks are named afx<uid>__<param>

    init {
        blend = AFxDefs.defaultBlend(type)
        for (d in AFxDefs.params(type)) p[d.key] = d.def
    }

    fun v(k: String): Float = p[k] ?: AFxDefs.params(type).firstOrNull { it.key == k }?.def ?: 0f

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("type", type); o.put("on", on); o.put("blend", blend.toDouble()); o.put("uid", uid.toLong())
        val po = JSONObject()
        for (k in p.keys.sorted()) po.put(k, (p[k] ?: 0f).toDouble())
        o.put("p", po)
        return o
    }

    fun copy(): AudioFxItem {
        val it = AudioFxItem(type)
        it.on = on; it.blend = blend; it.uid = uid
        it.p.putAll(p)
        return it
    }

    companion object {
        private var nextUid = 1
        fun newUid(): Int { nextUid += 1; return nextUid }

        fun fromJson(o: JSONObject): AudioFxItem {
            val it = AudioFxItem(o.optString("type"))
            it.on = o.optBoolean("on", true)
            it.blend = o.optDouble("blend", it.blend.toDouble()).toFloat()
            val u = o.optInt("uid", 0)
            if (u > 0) { it.uid = u; nextUid = max(nextUid, u) }
            val po = o.optJSONObject("p")
            if (po != null) for (k in po.keys()) it.p[k] = po.optDouble(k).toFloat()
            return it
        }
    }
}

class AFxParam(val key: String, val label: String, val lo: Float, val hi: Float, val def: Float, val dec: Int = 2, val options: List<String>? = null)

object AFxDefs {
    val types = listOf(
        Pair("flanger", "Flanger"), Pair("chorus", "Chorus"), Pair("modulator", "Modulator"), Pair("phaser", "Phaser"),
        Pair("pan", "Panning"), Pair("reverb", "Reverb"), Pair("muffle", "Muffle"), Pair("tone", "Tone"), Pair("eq", "Equalizer"),
        Pair("echo", "Echo"), Pair("dist", "Distortion"), Pair("comp", "Compressor"), Pair("wah", "Auto-Wah"), Pair("crush", "Bitcrusher"),
        Pair("widen", "Stereo Widener"), Pair("gate", "Noise Gate"))

    fun name(id: String): String = types.firstOrNull { it.first == id }?.second ?: id
    fun hasBlend(t: String): Boolean = t != "pan" && t != "eq"
    fun defaultBlend(t: String): Float = when (t) {
        "reverb" -> 0.3f
        "echo" -> 0.35f
        "muffle", "tone", "modulator", "dist", "phaser", "flanger", "chorus", "comp", "wah", "crush", "widen", "gate" -> 1f
        else -> 0.5f
    }

    // Equalizer: 5 bands — low shelf, 3 peaking, high shelf
    val eqDefaultFreq = floatArrayOf(80f, 300f, 1000f, 3500f, 10000f)
    val eqNames = listOf("Low", "Low-mid", "Mid", "High-mid", "High")

    fun params(t: String): List<AFxParam> = when (t) {
        "flanger" -> listOf(AFxParam("rate", "Rate (Hz)", 0.05f, 5f, 0.3f), AFxParam("depth", "Depth (ms)", 0.1f, 5f, 2f),
                            AFxParam("delay", "Delay (ms)", 0.5f, 10f, 2f), AFxParam("fb", "Feedback", -0.95f, 0.95f, 0.5f))
        "chorus" -> listOf(AFxParam("rate", "Rate (Hz)", 0.1f, 8f, 1.2f), AFxParam("depth", "Depth (ms)", 0f, 15f, 5f),
                           AFxParam("delay", "Delay (ms)", 5f, 40f, 20f, 1), AFxParam("voices", "Voices", 1f, 4f, 3f, 0))
        "modulator" -> listOf(AFxParam("wave", "Wave", 0f, 3f, 0f, 0, listOf("Sine", "Triangle", "Square", "Saw")),
                              AFxParam("mode", "Mode", 0f, 1f, 0f, 0, listOf("Ring", "Tremolo")),
                              AFxParam("freq", "Frequency (Hz)", 0.5f, 2000f, 30f, 1), AFxParam("depth", "Depth", 0f, 1f, 1f))
        "phaser" -> listOf(AFxParam("rate", "Rate (Hz)", 0.05f, 5f, 0.5f), AFxParam("depth", "Depth", 0f, 1f, 0.8f),
                           AFxParam("stages", "Stages", 2f, 12f, 6f, 0), AFxParam("freq", "Center (Hz)", 200f, 4000f, 1000f, 0),
                           AFxParam("fb", "Feedback", -0.9f, 0.9f, 0.4f))
        "comp" -> listOf(AFxParam("thresh", "Threshold (dB)", -60f, 0f, -18f, 1), AFxParam("ratio", "Ratio", 1f, 20f, 4f, 1),
                         AFxParam("attack", "Attack (ms)", 0.1f, 200f, 10f, 1), AFxParam("release", "Release (ms)", 10f, 1000f, 150f, 0),
                         AFxParam("knee", "Knee (dB)", 0f, 24f, 6f, 1), AFxParam("makeup", "Make-up (dB)", 0f, 24f, 0f, 1))
        "wah" -> listOf(AFxParam("rate", "Rate (Hz)", 0.05f, 10f, 1.2f), AFxParam("freq", "Center (Hz)", 200f, 4000f, 900f, 0),
                        AFxParam("depth", "Depth", 0f, 1f, 0.7f), AFxParam("res", "Resonance (Q)", 0.5f, 12f, 4f, 1),
                        AFxParam("follow", "Follow input", 0f, 1f, 0.3f))
        "crush" -> listOf(AFxParam("bits", "Bit depth", 1f, 16f, 8f, 1), AFxParam("rate", "Sample rate (Hz)", 500f, 48000f, 8000f, 0),
                          AFxParam("smooth", "Smooth", 0f, 1f, 0f))
        "gate" -> listOf(AFxParam("thresh", "Threshold (dB)", -80f, 0f, -40f, 1), AFxParam("range", "Reduction (dB)", 0f, 80f, 60f, 1),
                         AFxParam("attack", "Attack (ms)", 0.1f, 100f, 3f, 1), AFxParam("release", "Release (ms)", 5f, 1000f, 120f, 0),
                         AFxParam("hold", "Hold (ms)", 0f, 500f, 40f, 0))
        "widen" -> listOf(AFxParam("width", "Width (0 mono · 1 normal · 2 wide)", 0f, 2f, 1.4f),
                          AFxParam("bass", "Keep bass mono (Hz, 0 = off)", 0f, 400f, 120f, 0))
        "pan" -> listOf(AFxParam("pan", "Pan (L ← → R)", -1f, 1f, 0f), AFxParam("rate", "Auto-pan rate (Hz)", 0f, 5f, 0f, 2),
                        AFxParam("depth", "Auto-pan depth", 0f, 1f, 0.5f))
        "reverb" -> listOf(AFxParam("room", "Room size", 0f, 1f, 0.6f), AFxParam("damp", "Damping", 0f, 1f, 0.5f),
                           AFxParam("width", "Width", 0f, 1f, 1f), AFxParam("pre", "Pre-delay (ms)", 0f, 150f, 15f, 0))
        "muffle" -> listOf(AFxParam("cut", "Cutoff (Hz)", 100f, 8000f, 800f, 0), AFxParam("res", "Resonance", 0.5f, 3f, 0.7f),
                           AFxParam("slope", "Slope", 0f, 1f, 1f, 0, listOf("12 dB", "24 dB")))
        "tone" -> listOf(AFxParam("tone", "Tone (dark ← → bright)", -1f, 1f, 0f), AFxParam("pivot", "Pivot (Hz)", 200f, 4000f, 1000f, 0),
                         AFxParam("level", "Output (dB)", -12f, 12f, 0f, 1))
        "echo" -> listOf(AFxParam("time", "Time (ms)", 20f, 1500f, 350f, 0), AFxParam("fb", "Feedback", 0f, 0.95f, 0.4f),
                         AFxParam("damp", "Damping", 0f, 1f, 0.3f), AFxParam("ping", "Ping-pong", 0f, 1f, 0f, 0, listOf("Off", "On")))
        "dist" -> listOf(AFxParam("drive", "Drive (dB)", 0f, 40f, 12f, 1), AFxParam("shape", "Shape", 0f, 2f, 0f, 0, listOf("Soft", "Hard", "Fold")),
                         AFxParam("tone", "Tone (Hz)", 500f, 16000f, 8000f, 0), AFxParam("level", "Output (dB)", -24f, 6f, -6f, 1))
        "eq" -> {
            val a = ArrayList<AFxParam>()
            for (i in 0 until 5) {
                a.add(AFxParam("f$i", "${eqNames[i]} freq", 20f, 20000f, eqDefaultFreq[i], 0))
                a.add(AFxParam("g$i", "${eqNames[i]} gain (dB)", -18f, 18f, 0f, 1))
                a.add(AFxParam("q$i", "${eqNames[i]} Q", 0.3f, 8f, 1f, 2))
            }
            a.add(AFxParam("out", "Output (dB)", -12f, 12f, 0f, 1))
            a
        }
        else -> emptyList()
    }
}

// MARK: - DSP primitives

enum class BiquadKind { lowpass, lowShelf, highShelf, peak }

class Biquad {
    var b0 = 1f; var b1 = 0f; var b2 = 0f; var a1 = 0f; var a2 = 0f
    var x1 = 0f; var x2 = 0f; var y1 = 0f; var y2 = 0f

    fun set(k: BiquadKind, fIn: Float, qIn: Float, gainDb: Float, sr: Float) {
        val f = min(max(fIn, 10f), sr * 0.45f); val q = max(qIn, 0.1f)
        val w = 2 * Math.PI.toFloat() * f / sr; val cw = cos(w); val sw = sin(w)
        val a = 10.0.pow((gainDb / 40f).toDouble()).toFloat(); val al = sw / (2 * q)
        var nb0 = 1f; var nb1 = 0f; var nb2 = 0f; var a0 = 1f; var na1 = 0f; var na2 = 0f
        when (k) {
            BiquadKind.lowpass -> {
                nb0 = (1 - cw) / 2; nb1 = 1 - cw; nb2 = (1 - cw) / 2
                a0 = 1 + al; na1 = -2 * cw; na2 = 1 - al
            }
            BiquadKind.peak -> {
                nb0 = 1 + al * a; nb1 = -2 * cw; nb2 = 1 - al * a
                a0 = 1 + al / a; na1 = -2 * cw; na2 = 1 - al / a
            }
            BiquadKind.lowShelf -> {
                val s = 2 * kotlin.math.sqrt(a) * al
                nb0 = a * ((a + 1) - (a - 1) * cw + s); nb1 = 2 * a * ((a - 1) - (a + 1) * cw); nb2 = a * ((a + 1) - (a - 1) * cw - s)
                a0 = (a + 1) + (a - 1) * cw + s; na1 = -2 * ((a - 1) + (a + 1) * cw); na2 = (a + 1) + (a - 1) * cw - s
            }
            BiquadKind.highShelf -> {
                val s = 2 * kotlin.math.sqrt(a) * al
                nb0 = a * ((a + 1) + (a - 1) * cw + s); nb1 = -2 * a * ((a - 1) + (a + 1) * cw); nb2 = a * ((a + 1) + (a - 1) * cw - s)
                a0 = (a + 1) - (a - 1) * cw + s; na1 = 2 * ((a - 1) - (a + 1) * cw); na2 = (a + 1) - (a - 1) * cw - s
            }
        }
        b0 = nb0 / a0; b1 = nb1 / a0; b2 = nb2 / a0; a1 = na1 / a0; a2 = na2 / a0
    }

    fun copyFrom(o: Biquad) { b0 = o.b0; b1 = o.b1; b2 = o.b2; a1 = o.a1; a2 = o.a2 }

    fun tick(x: Float): Float {
        val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1; x1 = x; y2 = y1; y1 = y
        return y
    }

    /** Magnitude response in dB at `f` (used by the Equalizer graph). */
    fun magnitudeDb(f: Float, sr: Float): Float {
        val w = 2 * Math.PI.toFloat() * f / sr
        val c1 = cos(w); val s1 = sin(w); val c2 = cos(2 * w); val s2 = sin(2 * w)
        val nr = b0 + b1 * c1 + b2 * c2; val ni = -(b1 * s1 + b2 * s2)
        val dr = 1 + a1 * c1 + a2 * c2; val di = -(a1 * s1 + a2 * s2)
        val n = nr * nr + ni * ni; val d = max(dr * dr + di * di, 1e-12f)
        return 10 * log10(max(n / d, 1e-12f))
    }
}

/** Circular delay line with linear (`read`) and cubic-Hermite (`readCubic`) reads. */
class DelayLine(maxSamples: Int) {
    val buf = FloatArray(max(4, maxSamples + 4))
    var w = 0

    fun write(x: Float) { buf[w] = x; w++; if (w >= buf.size) w = 0 }

    fun read(d: Float): Float {
        var p = w - d
        val n = buf.size.toFloat()
        while (p < 0) p += n
        val i = p.toInt(); val fr = p - i
        val a = buf[i % buf.size]; val b = buf[(i + 1) % buf.size]
        return a + (b - a) * fr
    }

    /** 4-point Hermite read: far less interpolation grit than linear on swept delays. `d` must be >= 3 samples. */
    fun readCubic(d: Float): Float {
        val n = buf.size
        var p = w - d
        while (p < 0) p += n.toFloat()
        val i = p.toInt(); val fr = p - i
        val y0 = buf[(i + n - 1) % n]; val y1 = buf[i % n]; val y2 = buf[(i + 1) % n]; val y3 = buf[(i + 2) % n]
        val c1 = 0.5f * (y2 - y0); val c2 = y0 - 2.5f * y1 + 2 * y2 - 0.5f * y3; val c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2)
        return ((c3 * fr + c2) * fr + c1) * fr + y1
    }
}

fun afxLfo(ph: Float, wave: Int): Float = when (wave) {   // −1…1
    1 -> if (ph < 0.5f) 4 * ph - 1 else 3 - 4 * ph
    2 -> if (ph < 0.5f) 1f else -1f
    3 -> 2 * ph - 1
    else -> sin(2 * Math.PI.toFloat() * ph)
}

// MARK: - smoothing + processor base

/** One-pole parameter smoother: every target change glides, so nothing ever steps or zippers. */
class Sm(x: Float, sr: Float, ms: Float = 25f) {
    var v = x; var t = x; var c = 1 - exp(-1f / max(1f, ms * 0.001f * sr))
    fun next(): Float { v += (t - v) * c; return v }
    fun advance(k: Float) { v += (t - v) * (1 - (1 - c).pow(k)) }
    fun snap(x: Float) { v = x; t = x }
}

interface AFxProc {
    fun update(it: AudioFxItem)
    fun process(l: FloatArray, r: FloatArray, n: Int, off: Int = 0)
}

/** Processors live for as long as the effect exists. `update` only moves smoothed targets. */
abstract class AFxBase(val sr: Float) : AFxProc {
    var first = true
    fun tgt(s: Sm, v: Float) { if (first) s.snap(v) else s.t = v }
    override fun update(it: AudioFxItem) { apply(it); first = false }
    open fun apply(it: AudioFxItem) {}
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {}
}

/** Dry/wet blend (smoothed). */
class AFxBlend(private val inner: AFxBase, sr: Float) : AFxBase(sr) {
    val mix = Sm(1f, sr)
    var dl = FloatArray(8192); var dr = FloatArray(8192)
    override fun apply(it: AudioFxItem) { inner.update(it); tgt(mix, min(max(it.blend, 0f), 1f)) }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        if (mix.t > 0.999f && mix.v > 0.9995f) { inner.process(l, r, n, off); return }
        if (dl.size < n) { dl = FloatArray(n); dr = FloatArray(n) }
        for (i in 0 until n) { dl[i] = l[off + i]; dr[i] = r[off + i] }
        inner.process(l, r, n, off)
        for (i in 0 until n) { val m = mix.next(); l[off + i] = dl[i] * (1 - m) + l[off + i] * m; r[off + i] = dr[i] * (1 - m) + r[off + i] * m }
    }
}

/** Flanger: short (0.1–15 ms) LFO-swept delay summed with the dry signal. */
class AFxFlanger(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val dL: DelayLine; val dR: DelayLine
    val rate = Sm(0.3f, sr, 60f); val depth = Sm(2f, sr, 40f); val delay = Sm(2f, sr, 40f); val fb = Sm(0f, sr, 30f)
    var ph = 0f
    var hxL = 0f; var hyL = 0f; var hxR = 0f; var hyR = 0f
    init {
        val m = (18 * 0.001f * sr).toInt() + 16
        dL = DelayLine(m); dR = DelayLine(m)
        update(it)
    }
    override fun apply(it: AudioFxItem) { tgt(rate, it.v("rate")); tgt(depth, it.v("depth")); tgt(delay, it.v("delay")); tgt(fb, it.v("fb")) }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        val ms = 0.001f * sr
        for (i in 0 until n) {
            val rt = rate.next(); val dp = depth.next(); val dy = delay.next(); val f = fb.next()
            val a = 0.5f + 0.5f * sin(2 * Math.PI.toFloat() * ph); val b = 0.5f + 0.5f * sin(2 * Math.PI.toFloat() * (ph + 0.25f))
            val xl = l[off + i]; val xr = r[off + i]
            val wl = dL.readCubic(max(3f, (dy + dp * a) * ms)); val wr = dR.readCubic(max(3f, (dy + dp * b) * ms))
            val sl = tanh(wl * f); val sR = tanh(wr * f)
            val ol = sl - hxL + 0.995f * hyL; hxL = sl; hyL = ol
            val or = sR - hxR + 0.995f * hyR; hxR = sR; hyR = or
            dL.write(xl + ol); dR.write(xr + or)
            l[off + i] = (xl + wl) * 0.6f; r[off + i] = (xr + wr) * 0.6f
            ph += rt / sr; if (ph >= 1f) ph -= 1f
        }
    }
}

/** Chorus: 5–55 ms delays with slow LFOs, up to 4 voices with spread LFO phases. */
class AFxChorus(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val dL: DelayLine; val dR: DelayLine
    val rate = Sm(1f, sr, 60f); val depth = Sm(5f, sr, 40f); val delay = Sm(20f, sr, 40f); val voices = Sm(3f, sr, 80f)
    var ph = 0f
    init {
        val m = (62 * 0.001f * sr).toInt() + 16
        dL = DelayLine(m); dR = DelayLine(m)
        update(it)
    }
    override fun apply(it: AudioFxItem) { tgt(rate, it.v("rate")); tgt(depth, it.v("depth")); tgt(delay, it.v("delay")); tgt(voices, it.v("voices")) }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        val ms = 0.001f * sr
        for (i in 0 until n) {
            val rt = rate.next(); val dp = depth.next(); val dy = delay.next(); val nv = voices.next()
            val xl = l[off + i]; val xr = r[off + i]
            dL.write(xl); dR.write(xr)
            var sl = 0f; var sR = 0f; var gs = 0f
            for (v in 0 until 4) {
                val vg = min(max(nv - v, 0f), 1f)
                if (vg <= 0.0005f) continue
                val o = v / 4f; val base = dy * (1 + 0.12f * v)
                val ml = 0.5f + 0.5f * sin(2 * Math.PI.toFloat() * (ph + o)); val mr = 0.5f + 0.5f * sin(2 * Math.PI.toFloat() * (ph + o + 0.5f))
                sl += dL.readCubic(max(3f, (base + dp * ml) * ms)) * vg
                sR += dR.readCubic(max(3f, (base + dp * mr) * ms)) * vg
                gs += vg
            }
            val g = 1 / max(1f, gs).let { kotlin.math.sqrt(it) }
            l[off + i] = (xl + sl * g) * 0.7071f; r[off + i] = (xr + sR * g) * 0.7071f
            ph += rt / sr; if (ph >= 1f) ph -= 1f
        }
    }
}

class AFxModulator(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val freq = Sm(30f, sr, 40f); val depth = Sm(1f, sr, 25f); val gs = Sm(1f, sr, 0.08f)
    var wave = 0; var mode = 0
    var ph = 0f
    init { update(it) }
    override fun apply(it: AudioFxItem) {
        tgt(freq, it.v("freq")); tgt(depth, it.v("depth"))
        wave = Math.round(it.v("wave")).toInt(); mode = Math.round(it.v("mode")).toInt()
    }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        for (i in 0 until n) {
            val f = freq.next(); val d = depth.next()
            val m = afxLfo(ph, wave)
            gs.t = if (mode == 0) (1 - d) + d * m else 1 - d * (0.5f - 0.5f * m)     // ring / tremolo; edge-smoothed so a square wave doesn't click
            val g = gs.next()
            l[off + i] *= g; r[off + i] *= g
            ph += f / sr; if (ph >= 1f) ph -= floor(ph)
        }
    }
}

/** Phaser: N staggered first-order all-pass stages swept exponentially, summed with the dry signal. */
class AFxPhaser(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val rate = Sm(0.5f, sr, 60f); val depth = Sm(0.8f, sr, 40f); val stages = Sm(6f, sr, 80f)
    val freq = Sm(1000f, sr, 40f); val fb = Sm(0.4f, sr, 30f)
    var ph = 0f
    val zL = FloatArray(12); val zR = FloatArray(12)
    val aL = FloatArray(12); val aR = FloatArray(12)
    var fL = 0f; var fR = 0f; var ctl = 0
    var hxL = 0f; var hyL = 0f; var hxR = 0f; var hyR = 0f
    init { update(it) }
    override fun apply(it: AudioFxItem) {
        tgt(rate, it.v("rate")); tgt(depth, it.v("depth")); tgt(stages, it.v("stages")); tgt(freq, it.v("freq")); tgt(fb, it.v("fb"))
    }
    private fun coeffs(fc: Float, dp: Float) {
        val sL = sin(2 * Math.PI.toFloat() * ph); val sR = sin(2 * Math.PI.toFloat() * (ph + 0.25f))
        for (s in 0 until 12) {
            val off = (s - 5.5f) * 0.12f
            val fl = min(sr * 0.45f, max(20f, fc * exp2v(sL * 2.5f * dp + off))); val fr = min(sr * 0.45f, max(20f, fc * exp2v(sR * 2.5f * dp + off)))
            val tl = tan(Math.PI.toFloat() * fl / sr); val tr = tan(Math.PI.toFloat() * fr / sr)
            aL[s] = (1 - tl) / (1 + tl); aR[s] = (1 - tr) / (1 + tr)
        }
    }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        for (i in 0 until n) {
            val rt = rate.next(); val dp = depth.next(); val ns = stages.next(); val fc = freq.next(); val f = fb.next()
            if (ctl == 0) coeffs(fc, dp)
            ctl = (ctl + 1) and 7
            val sl = tanh(fL * f); val sR = tanh(fR * f)
            val ol = sl - hxL + 0.995f * hyL; hxL = sl; hyL = ol
            val or = sR - hxR + 0.995f * hyR; hxR = sR; hyR = or
            val dl = l[off + i]; val dr = r[off + i]
            var xl = dl + ol; var xr = dr + or
            for (s in 0 until 12) {
                val w = min(max(ns - s, 0f), 1f)
                if (w <= 0f) break
                val yl = aL[s] * xl + zL[s]; zL[s] = xl - aL[s] * yl
                val yr = aR[s] * xr + zR[s]; zR[s] = xr - aR[s] * yr
                xl += (yl - xl) * w; xr += (yr - xr) * w
            }
            fL = xl; fR = xr
            l[off + i] = (dl + xl) * 0.5f; r[off + i] = (dr + xr) * 0.5f
            ph += rt / sr; if (ph >= 1f) ph -= 1f
        }
    }
}

class AFxPan(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val pan = Sm(0f, sr, 30f); val rate = Sm(0f, sr, 60f); val depth = Sm(0.5f, sr, 40f)
    var ph = 0f
    init { update(it) }
    override fun apply(it: AudioFxItem) { tgt(pan, it.v("pan")); tgt(rate, it.v("rate")); tgt(depth, it.v("depth")) }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        for (i in 0 until n) {
            val pn = pan.next(); val rt = rate.next(); val dp = depth.next()
            val act = min(rt * 20f, 1f)
            val p = min(max(pn + act * dp * sin(2 * Math.PI.toFloat() * ph), -1f), 1f)
            ph += rt / sr; if (ph >= 1f) ph -= 1f
            val a = (p + 1) * 0.25f * Math.PI.toFloat()
            l[off + i] *= min(cos(a) * 1.41421356f, 1f); r[off + i] *= min(sin(a) * 1.41421356f, 1f)
        }
    }
}

class AFxReverb(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    class Comb(val b: FloatArray) { var i = 0; var s = 0f }
    private val combT = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
    private val apT = intArrayOf(556, 441, 341, 225)
    val cl: Array<Comb>; val cr: Array<Comb>; val al: Array<Comb>; val ar: Array<Comb>
    val fbk = Sm(0.85f, sr, 80f); val damp = Sm(0.2f, sr, 60f); val width = Sm(1f, sr, 40f); val preS = Sm(0f, sr, 80f)
    val pre: DelayLine; val preR: DelayLine
    init {
        val k = sr / 44100f; val spread = 23
        fun mk(t: Int) = Comb(FloatArray(max(8, (t * k).toInt())))
        cl = combT.map { mk(it) }.toTypedArray()
        cr = combT.map { mk(it + spread) }.toTypedArray()
        al = apT.map { mk(it) }.toTypedArray()
        ar = apT.map { mk(it + spread) }.toTypedArray()
        val mx = (0.16f * sr).toInt() + 8
        pre = DelayLine(mx); preR = DelayLine(mx)
        update(it)
    }
    override fun apply(it: AudioFxItem) {
        tgt(fbk, it.v("room") * 0.28f + 0.7f); tgt(damp, it.v("damp") * 0.4f); tgt(width, it.v("width")); tgt(preS, it.v("pre") * 0.001f * sr)
    }
    private fun comb(c: Comb, x: Float, fb: Float, dm: Float): Float {
        val o = c.b[c.i]
        c.s = o * (1 - dm) + c.s * dm
        c.b[c.i] = x + c.s * fb
        c.i++; if (c.i >= c.b.size) c.i = 0
        return o
    }
    private fun allp(c: Comb, x: Float): Float {
        val o = c.b[c.i]; val y = o - x
        c.b[c.i] = x + o * 0.5f
        c.i++; if (c.i >= c.b.size) c.i = 0
        return y
    }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        for (i in 0 until n) {
            val fb = fbk.next(); val dm = damp.next(); val wd = width.next(); val p = preS.next()
            val w1 = wd * 0.5f + 0.5f; val w2 = (1 - wd) * 0.5f
            pre.write(l[off + i]); preR.write(r[off + i])
            val inp = if (p > 1f) (pre.read(p) + preR.read(p)) * 0.015f else (l[off + i] + r[off + i]) * 0.015f
            var sl = 0f; var sR = 0f
            for (j in 0 until 8) { sl += comb(cl[j], inp, fb, dm); sR += comb(cr[j], inp, fb, dm) }
            for (j in 0 until 4) { sl = allp(al[j], sl); sR = allp(ar[j], sR) }
            l[off + i] = (sl * w1 + sR * w2) * 3; r[off + i] = (sR * w1 + sl * w2) * 3
        }
    }
}

class AFxEcho(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val dL: DelayLine; val dR: DelayLine
    val time: Sm; val fb = Sm(0.4f, sr, 40f); val damp = Sm(0.3f, sr, 40f); val ping = Sm(0f, sr, 60f)
    var lpL = 0f; var lpR = 0f
    init {
        val mx = (1.55f * sr).toInt() + 16
        dL = DelayLine(mx); dR = DelayLine(mx)
        time = Sm(0.35f * sr, sr, 150f)
        update(it)
    }
    override fun apply(it: AudioFxItem) {
        tgt(time, it.v("time") * 0.001f * sr); tgt(fb, it.v("fb")); tgt(damp, it.v("damp") * 0.85f); tgt(ping, if (it.v("ping") > 0.5f) 1f else 0f)
    }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        for (i in 0 until n) {
            val t = max(3f, time.next()); val f = fb.next(); val dm = damp.next(); val p = ping.next()
            val a = dL.readCubic(t); val b = dR.readCubic(t)
            lpL = a * (1 - dm) + lpL * dm; lpR = b * (1 - dm) + lpR * dm
            dL.write(l[off + i] + f * (lpL * (1 - p) + lpR * p))                     // ping-pong crossfades the feedback path L↔R
            dR.write(r[off + i] * (1 - p) + f * (lpR * (1 - p) + lpL * p))
            l[off + i] += a; r[off + i] += b
        }
    }
}

/** A biquad whose frequency / Q / gain glide; coefficients refresh every 32 samples. */
class SBand(val kind: BiquadKind, val sr: Float, f0: Float, q0: Float, g0: Float) {
    val f: Sm; val q: Sm; val g: Sm          // f is stored as log2(Hz) so sweeps are musical
    val bl = Biquad(); val br = Biquad()
    init {
        f = Sm(log2(max(f0, 10f)), sr, 30f); q = Sm(q0, sr, 30f); g = Sm(g0, sr, 30f)
        refresh()
    }
    fun target(f0: Float, q0: Float, g0: Float, snap: Boolean) {
        val lf = log2(max(f0, 10f))
        if (snap) { f.snap(lf); q.snap(q0); g.snap(g0); refresh() } else { f.t = lf; q.t = q0; g.t = g0 }
    }
    fun step(k: Float) { f.advance(k); q.advance(k); g.advance(k); refresh() }
    fun refresh() {
        bl.set(kind, exp2v(f.v), q.v, g.v, sr)
        br.copyFrom(bl)
    }
}

class AFxFilterChain(it: AudioFxItem, sr: Float) : AFxBase(sr) {          // Muffle / Tone / Equalizer
    val type: String
    val bands: Array<SBand>
    val gain: Sm
    init {
        type = it.type
        bands = when (it.type) {
            "muffle" -> arrayOf(SBand(BiquadKind.lowpass, sr, 800f, 0.7f, 0f), SBand(BiquadKind.lowpass, sr, 800f, 0.707f, 0f))
            "tone" -> arrayOf(SBand(BiquadKind.lowShelf, sr, 1000f, 0.7f, 0f), SBand(BiquadKind.highShelf, sr, 1000f, 0.7f, 0f))
            else -> (0 until 5).map { i -> SBand(if (i == 0) BiquadKind.lowShelf else (if (i == 4) BiquadKind.highShelf else BiquadKind.peak), sr, AFxDefs.eqDefaultFreq[i], 1f, 0f) }.toTypedArray()
        }
        gain = Sm(1f, sr, 25f)
        update(it)
    }
    override fun apply(it: AudioFxItem) {
        val sn = first
        when (type) {
            "muffle" -> {
                val cut = it.v("cut")
                bands[0].target(cut, it.v("res"), 0f, sn)
                bands[1].target(if (it.v("slope") > 0.5f) cut else 20000f, 0.707f, 0f, sn)
                tgt(gain, 1f)
            }
            "tone" -> {
                val t = it.v("tone"); val p = it.v("pivot")
                bands[0].target(p, 0.7f, -t * 12f, sn); bands[1].target(p, 0.7f, t * 12f, sn)
                tgt(gain, 10f.pow(it.v("level") / 20f))
            }
            else -> {
                for (i in 0 until 5) bands[i].target(it.v("f$i"), it.v("q$i"), it.v("g$i"), sn)
                tgt(gain, 10f.pow(it.v("out") / 20f))
            }
        }
    }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        var i = 0
        while (i < n) {
            val m = min(32, n - i)
            for (b in bands) b.step(m.toFloat())
            for (j in i until i + m) {
                var a = l[off + j]; var c = r[off + j]
                for (b in bands) { a = b.bl.tick(a); c = b.br.tick(c) }
                val g = gain.next()
                l[off + j] = a * g; r[off + j] = c * g
            }
            i += m
        }
    }
}

class AFxDist(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val drive = Sm(4f, sr, 25f); val out = Sm(0.5f, sr, 25f)
    val w: Array<Sm>
    val tone: SBand
    init {
        w = (0 until 3).map { Sm(0f, sr, 15f) }.toTypedArray()
        tone = SBand(BiquadKind.lowpass, sr, 8000f, 0.707f, 0f)
        update(it)
    }
    override fun apply(it: AudioFxItem) {
        tgt(drive, 10f.pow(it.v("drive") / 20f)); tgt(out, 10f.pow(it.v("level") / 20f))
        val s = Math.round(it.v("shape")).toInt()
        for (i in 0 until 3) tgt(w[i], if (i == s) 1f else 0f)
        tone.target(it.v("tone"), 0.707f, 0f, first)
    }
    private fun fold(x: Float): Float {
        var y = x; var k = 0
        while (abs(y) > 1 && k < 6) { y = if (y > 1) 2 - y else (if (y < -1) -2 - y else y); k++ }
        return y
    }
    private fun shape(x: Float, w0: Float, w1: Float, w2: Float): Float {
        var y = 0f
        if (w0 > 0.001f) y += tanh(x) * w0
        if (w1 > 0.001f) y += max(-1f, min(1f, x)) * w1
        if (w2 > 0.001f) y += fold(x) * w2
        return y
    }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        var i = 0
        while (i < n) {
            val m = min(32, n - i)
            tone.step(m.toFloat())
            for (j in i until i + m) {
                val d = drive.next(); val o = out.next(); val w0 = w[0].next(); val w1 = w[1].next(); val w2 = w[2].next()
                l[off + j] = tone.bl.tick(shape(l[off + j] * d, w0, w1, w2)) * o
                r[off + j] = tone.br.tick(shape(r[off + j] * d, w0, w1, w2)) * o
            }
            i += m
        }
    }
}

/** Compressor: stereo-linked peak detector in dB, soft-knee gain computer, attack/release ballistics, make-up gain. */
class AFxComp(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val thr = Sm(-18f, sr, 30f); val ratio = Sm(4f, sr, 30f); val knee = Sm(6f, sr, 30f); val makeup = Sm(0f, sr, 30f)
    var att = 10f; var rel = 150f
    var gr = 0f
    init { update(it) }
    override fun apply(it: AudioFxItem) {
        tgt(thr, it.v("thresh")); tgt(ratio, it.v("ratio")); tgt(knee, it.v("knee")); tgt(makeup, it.v("makeup"))
        att = it.v("attack"); rel = it.v("release")
    }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        val ac = exp(-1f / max(1f, att * 0.001f * sr)); val rc = exp(-1f / max(1f, rel * 0.001f * sr))
        for (i in 0 until n) {
            val t = thr.next(); val rr = max(1f, ratio.next()); val wd = knee.next(); val mk = makeup.next()
            val lv = 20 * log10(max(max(abs(l[off + i]), abs(r[off + i])), 1e-6f))
            val over = lv - t
            var target = 0f                                    // gain change in dB (≤ 0)
            if (wd < 0.01f) { if (over > 0) target = -over * (1 - 1 / rr) }
            else if (2 * over > wd) target = -over * (1 - 1 / rr)
            else if (2 * abs(over) <= wd) { val x = over + wd / 2; target = -(1 - 1 / rr) * x * x / (2 * wd) }
            val c = if (target < gr) ac else rc
            gr = c * gr + (1 - c) * target
            val g = exp((gr + mk) * 0.11512925f)
            l[off + i] *= g; r[off + i] *= g
        }
    }
}

/** Auto-Wah: resonant band-pass (TPT state-variable filter) swept by an LFO and/or the input level. */
class AFxWah(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val rate = Sm(1.2f, sr, 60f); val freq = Sm(900f, sr, 40f); val depth = Sm(0.7f, sr, 40f)
    val res = Sm(4f, sr, 40f); val follow = Sm(0.3f, sr, 40f)
    var ph = 0f; var env = 0f; var ctl = 0
    var ic1L = 0f; var ic2L = 0f; var ic1R = 0f; var ic2R = 0f
    var a1L = 0f; var a2L = 0f; var a3L = 0f; var a1R = 0f; var a2R = 0f; var a3R = 0f; var kk = 0.25f
    init { update(it) }
    override fun apply(it: AudioFxItem) { tgt(rate, it.v("rate")); tgt(freq, it.v("freq")); tgt(depth, it.v("depth")); tgt(res, it.v("res")); tgt(follow, it.v("follow")) }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        val ac = 1 - exp(-1f / (0.005f * sr)); val rc = 1 - exp(-1f / (0.08f * sr))
        for (i in 0 until n) {
            val rt = rate.next(); val fc = freq.next(); val dp = depth.next(); val q = max(0.3f, res.next()); val fo = follow.next()
            val lv = max(abs(l[off + i]), abs(r[off + i]))
            env += (lv - env) * (if (lv > env) ac else rc)
            if (ctl == 0) {
                val e = min(env * 4, 1f)
                val mL = (1 - fo) * (0.5f + 0.5f * sin(2 * Math.PI.toFloat() * ph)) + fo * e
                val mR = (1 - fo) * (0.5f + 0.5f * sin(2 * Math.PI.toFloat() * (ph + 0.25f))) + fo * e
                kk = 1 / q
                fun co(m: Float): Triple<Float, Float, Float> {
                    val f = min(sr * 0.45f, max(30f, fc * exp2v((m - 0.5f) * 5 * dp)))
                    val g = tan(Math.PI.toFloat() * f / sr); val a1 = 1 / (1 + g * (g + kk)); val a2 = g * a1
                    return Triple(a1, a2, g * a2)
                }
                val cl = co(mL); a1L = cl.first; a2L = cl.second; a3L = cl.third
                val cr = co(mR); a1R = cr.first; a2R = cr.second; a3R = cr.third
            }
            ctl = (ctl + 1) and 7
            val xl = l[off + i]; val xr = r[off + i]
            val v3l = xl - ic2L; val v1l = a1L * ic1L + a2L * v3l; val v2l = ic2L + a2L * ic1L + a3L * v3l
            ic1L = 2 * v1l - ic1L; ic2L = 2 * v2l - ic2L
            val v3r = xr - ic2R; val v1r = a1R * ic1R + a2R * v3r; val v2r = ic2R + a2R * ic1R + a3R * v3r
            ic1R = 2 * v1r - ic1R; ic2R = 2 * v2r - ic2R
            l[off + i] = v1l * kk * 2; r[off + i] = v1r * kk * 2                      // unity-peak band-pass, +6 dB make-up
            ph += rt / sr; if (ph >= 1f) ph -= 1f
        }
    }
}

/** Noise gate: closes (by `range` dB) when the level stays under the threshold. */
class AFxGate(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val thr = Sm(-40f, sr, 30f); val rng = Sm(60f, sr, 30f); val atk = Sm(3f, sr, 30f)
    val rel = Sm(120f, sr, 30f); val hold = Sm(40f, sr, 30f)
    var env = 0f; var gain = 1f; var holdLeft = 0f
    init { update(it) }
    override fun apply(it: AudioFxItem) {
        tgt(thr, it.v("thresh")); tgt(rng, it.v("range")); tgt(atk, it.v("attack"))
        tgt(rel, it.v("release")); tgt(hold, it.v("hold"))
    }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        for (i in 0 until n) {
            val th = 10f.pow(thr.next() / 20f); val floorG = 10f.pow(-rng.next() / 20f)
            val a = 1 - exp(-1f / max(1f, atk.next() * 0.001f * sr)); val rl = 1 - exp(-1f / max(1f, rel.next() * 0.001f * sr))
            val hs = hold.next() * 0.001f * sr
            val lvl = max(abs(l[off + i]), abs(r[off + i]))
            env = if (lvl > env) lvl else env + (lvl - env) * 0.002f          // fast-up / slow-down peak follower
            var target = floorG
            if (env > th) { target = 1f; holdLeft = hs } else if (holdLeft > 0) { target = 1f; holdLeft -= 1 }
            gain += (target - gain) * (if (target > gain) a else rl)
            l[off + i] *= gain; r[off + i] *= gain
        }
    }
}

/** Stereo widener: mid/side width control; the side signal below `bass` Hz stays untouched. */
class AFxWiden(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val width = Sm(1f, sr, 30f); val bass = Sm(120f, sr, 40f)
    var lp = 0f
    init { update(it) }
    override fun apply(it: AudioFxItem) { tgt(width, it.v("width")); tgt(bass, it.v("bass")) }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        for (i in 0 until n) {
            val w = width.next(); val b = bass.next()
            val m = (l[off + i] + r[off + i]) * 0.5f; val sd = (l[off + i] - r[off + i]) * 0.5f
            val sOut: Float
            if (b > 1) {
                val c = min(1f, 2 * Math.PI.toFloat() * b / sr)
                lp += (sd - lp) * c
                sOut = (sd - lp) * w + lp * min(w, 1f)       // highs get the full width, lows never go wider than normal
            } else sOut = sd * w
            l[off + i] = m + sOut; r[off + i] = m - sOut
        }
    }
}

/** Bitcrusher: bit-depth reduction + sample-rate reduction (sample & hold) with an optional smoothing low-pass. */
class AFxCrush(it: AudioFxItem, sr: Float) : AFxBase(sr) {
    val bits = Sm(8f, sr, 30f); val lrate = Sm(13f, sr, 40f); val smooth = Sm(0f, sr, 30f)
    var acc = 1f; var hL = 0f; var hR = 0f; var lpL = 0f; var lpR = 0f
    init { update(it) }
    override fun apply(it: AudioFxItem) { tgt(bits, it.v("bits")); tgt(lrate, log2(max(it.v("rate"), 100f))); tgt(smooth, it.v("smooth")) }
    override fun process(l: FloatArray, r: FloatArray, n: Int, off: Int) {
        for (i in 0 until n) {
            val lv = 2f.pow(max(bits.next(), 1f) - 1f); val rt = min(exp2v(lrate.next()), sr); val sm = smooth.next()
            acc += rt / sr
            if (acc >= 1f) { acc -= 1f; hL = roundAway(l[off + i] * lv) / lv; hR = roundAway(r[off + i] * lv) / lv }
            val c = min(1f, rt * 0.45f * 2 * Math.PI.toFloat() / sr)
            lpL += (hL - lpL) * c; lpR += (hR - lpR) * c
            l[off + i] = hL + (lpL - hL) * sm; r[off + i] = hR + (lpR - hR) * sm
        }
    }
}

// MARK: - automation (keyframes) baked for the offline renderer

/** Keyframed parameter curves sampled at 100 Hz of *source* time. */
class AFxAuto {
    var curves = HashMap<String, FloatArray>()       // "<uid>__<param>"
    var t0 = 0f

    fun apply(it: AudioFxItem, srcT: Float): AudioFxItem {
        if (curves.isEmpty()) return it
        val o = it.copy()
        val x = max(0f, srcT) * rate
        val pre = "${it.uid}__"
        for ((k, c) in curves) {
            if (!k.startsWith(pre) || c.size < 2) continue
            val i = min(x.toInt(), c.size - 2); val f = min(max(x - i, 0f), 1f)
            val v = c[i] + (c[i + 1] - c[i]) * f
            val name = k.drop(pre.length)
            if (name == "blend") o.blend = v else o.p[name] = v
        }
        return o
    }

    fun signature(): String {
        var h = -0x40e2d2071e8f9b5bL                 // 0xcbf29ce484222325 unsigned
        for (k in curves.keys.sorted()) {
            for (b in k.encodeToByteArray()) h = (h xor b.toLong().toULong().toLong()) * 0x100000001b3L
            for (v in curves[k]!!) h = (h xor ((v * 1000).let { kotlin.math.round(it).toInt() }.toLong())) * 0x100000001b3L
        }
        return java.lang.Long.toUnsignedString(h, 16)
    }

    companion object { const val rate = 100f }
}

// MARK: - Layer helpers

fun Layer.afxKey(it: AudioFxItem, k: String): String = "afx${it.uid}__$k"
private fun Layer.afxKeys(it: AudioFxItem): List<String> = AFxDefs.params(it.type).map { it.key } + (if (AFxDefs.hasBlend(it.type)) listOf("blend") else emptyList())

/** True when any effect parameter of this layer has keyframes. */
val Layer.afxAnimated: Boolean get() = props.any { it.key.startsWith("afx") && it.key.contains("__") && it.value.keys.isNotEmpty() }

/** The effect with every parameter evaluated at timeline time `t`. */
fun Layer.afxAt(it: AudioFxItem, t: Float): AudioFxItem {
    val o = it.copy()
    for (k in afxKeys(it)) {
        val tr = props[afxKey(it, k)] ?: continue
        val v = tr.eval(t)
        if (k == "blend") o.blend = v else o.p[k] = v
    }
    return o
}
fun Layer.afxChainAt(t: Float): List<AudioFxItem> = afx.map { afxAt(it, t) }

fun Layer.afxDropTracks(uid: Int) {
    val p = "afx${uid}__"
    for (k in props.keys.toList()) if (k.startsWith(p)) props.remove(k)
}

fun Layer.afxCopyTracks(a: Int, b: Int) {
    val pa = "afx$a" + "__"; val pb = "afx$b" + "__"
    for ((k, tr) in props) {
        if (!k.startsWith(pa)) continue
        val n = Track(tr.base)
        n.keys = tr.keys.map { Key.fromJson(it.toJson()) }.toMutableList()
        props[pb + k.drop(pa.length)] = n
    }
}

/** Samples every keyframed effect parameter for the offline renderer / exporter. */
fun Layer.afxBake(): AFxAuto {
    val a = AFxAuto()
    a.t0 = start - srcOffset
    val n = max(2, min((((max(0f, end - start) + srcOffset + 4f) * AFxAuto.rate).toInt()), (AFxAuto.rate * 3600).toInt()))
    for (it in afx) {
        if (!it.on) continue
        for (k in afxKeys(it)) {
            val tr = props[afxKey(it, k)] ?: continue
            if (tr.keys.isEmpty()) continue
            val c = FloatArray(n)
            for (i in 0 until n) c[i] = tr.eval(a.t0 + i / AFxAuto.rate)
            a.curves["${it.uid}__$k"] = c
        }
    }
    return a
}

// MARK: - factory + offline rendering

object AudioFxProc {
    fun make(it: AudioFxItem, sr: Float): AFxBase? {
        if (!it.on) return null
        val core: AFxBase = when (it.type) {
            "flanger" -> AFxFlanger(it, sr)
            "chorus" -> AFxChorus(it, sr)
            "modulator" -> AFxModulator(it, sr)
            "phaser" -> AFxPhaser(it, sr)
            "pan" -> return AFxPan(it, sr)
            "reverb" -> AFxReverb(it, sr)
            "echo" -> AFxEcho(it, sr)
            "dist" -> AFxDist(it, sr)
            "comp" -> AFxComp(it, sr)
            "wah" -> AFxWah(it, sr)
            "crush" -> AFxCrush(it, sr)
            "widen" -> AFxWiden(it, sr)
            "gate" -> AFxGate(it, sr)
            "muffle", "tone" -> AFxFilterChain(it, sr)
            "eq" -> return AFxFilterChain(it, sr)
            else -> return null
        }
        val b = AFxBlend(core, sr)
        b.update(it)
        return b
    }

    /** Chain key for a layer: "" when nothing audible would change. */
    fun key(chain: List<AudioFxItem>, auto: AFxAuto = AFxAuto()): String {
        val act = chain.filter { it.on }
        if (act.isEmpty()) return ""
        var s = "v3|" + act.joinToString("|") { it.toJson().toString() }        // v3 = smoothed DSP; old renders are never reused
        if (auto.curves.isNotEmpty()) s += "#" + auto.signature()
        return s
    }

    private val lock = Object()
    private val inflight = HashSet<String>()
    private val failed = HashSet<String>()          // sources that could not be rendered (e.g. video without sound): never retried
    private val queue = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "audiofx") }

    private fun fnv(s: String): String {
        var h = -0x40e2d2071e8f9b5bL
        for (b in s.encodeToByteArray()) h = (h xor b.toLong().toULong().toLong()) * 0x100000001b3L
        return java.lang.Long.toUnsignedString(h, 16)
    }

    private val dir: File get() = File(Paths.appContext.cacheDir, "AudioFx").apply { mkdirs() }

    private fun cacheURL(path: String, key: String): File {
        val f = File(path)
        val mod = if (f.exists()) f.lastModified() else 0L
        val size = if (f.exists()) f.length() else 0L
        return File(dir, fnv("${f.name}|$size|$mod|$key") + ".wav")
    }

    /** The rendered file when it already exists. */
    fun cachedURL(path: String, chain: List<AudioFxItem>, auto: AFxAuto = AFxAuto()): File? {
        val k = key(chain, auto)
        if (k.isEmpty()) return null
        val u = cacheURL(path, k)
        return if (u.exists()) u else null
    }

    /** Renders in the background (once per distinct chain); `done` runs on the main thread. */
    fun prepare(path: String, chain: List<AudioFxItem>, auto: AFxAuto = AFxAuto(), done: () -> Unit) {
        val k = key(chain, auto)
        if (k.isEmpty()) return
        val u = cacheURL(path, k)
        if (u.exists()) return
        synchronized(lock) {
            if (inflight.contains(u.absolutePath) || failed.contains(u.absolutePath)) return
            inflight.add(u.absolutePath)
        }
        queue.execute {
            val ok = render(path, chain, auto, u)
            synchronized(lock) { inflight.remove(u.absolutePath); if (!ok) failed.add(u.absolutePath) }
            android.os.Handler(android.os.Looper.getMainLooper()).post { done() }
        }
    }

    /** Blocking version for the exporter. */
    fun renderSync(path: String, chain: List<AudioFxItem>, auto: AFxAuto = AFxAuto()): File? {
        val k = key(chain, auto)
        if (k.isEmpty()) return null
        val u = cacheURL(path, k)
        if (u.exists()) return u
        return if (render(path, chain, auto, u)) u else null
    }

    /** Streaming decode (MediaCodec) -> DSP chain -> 16-bit stereo WAV writer. */
    private fun render(path: String, chain: List<AudioFxItem>, auto: AFxAuto, dst: File): Boolean {
        // video files: if the decoder cannot open the container, pull the sound track out to m4a first
        var fopen = AndroidAudioReader.open(path)
        if (fopen == null) {
            val tmpA = File(Paths.appContext.cacheDir, "fxsrc-${abs(path.hashCode())}.m4a")
            if (tmpA.exists() || AudioTools.extractAudio(path, tmpA)) {
                fopen = AndroidAudioReader.open(tmpA.absolutePath)
            }
        }
        val f = fopen ?: return false
        try {
            val sr = f.sampleRate
            val pairs = ArrayList<Pair<AFxBase, AudioFxItem>>()
            for (it in chain) make(it, sr)?.let { p -> pairs.add(p to it) }
            if (pairs.isEmpty()) return false
            var done = 0.0                                  // source frames already rendered (drives keyframed parameters)
            val tmp = File(dst.absolutePath + ".tmp")
            tmp.delete()
            val wav = Wav16Writer(tmp, sr) ?: return false
            val bufL = FloatArray(32768); val bufR = FloatArray(32768)
            // reverb / delay tails: keep feeding silence for 2 s after the file ends so the tail is not cut
            var tailLeft = (sr * 2).toInt()
            val hasTail = chain.any { it.on && (it.type == "reverb" || it.type == "flanger" || it.type == "chorus" || it.type == "echo" || it.type == "phaser") }
            while (true) {
                var n = 0
                if (!f.atEnd) {
                    n = f.read(bufL, bufR, 32768)
                }
                if (n == 0) {
                    if (!hasTail || tailLeft <= 0) break
                    n = min(32768, tailLeft); tailLeft -= n
                    java.util.Arrays.fill(bufL, 0, n, 0f); java.util.Arrays.fill(bufR, 0, n, 0f)
                }
                var off = 0
                while (off < n) {                                       // 256-sample steps: parameters follow their keyframes
                    val m = min(256, n - off)
                    val st = ((done + off) / sr).toFloat()
                    for ((p, it) in pairs) p.update(auto.apply(it, st))
                    for ((p, _) in pairs) p.process(bufL, bufR, m, off)
                    off += m
                }
                done += n.toDouble()
                for (i in 0 until n) { bufL[i] = min(1f, max(-1f, bufL[i])); bufR[i] = min(1f, max(-1f, bufR[i])) }
                wav.write(bufL, bufR, n)
            }
            wav.close()
            dst.delete()
            return tmp.renameTo(dst)
        } finally {
            f.close()
        }
    }
}

/** MediaCodec-based stereo float reader (AVAudioFile twin). */
class AndroidAudioReader private constructor(private val ex: android.media.MediaExtractor, private val codec: android.media.MediaCodec) {
    var sampleRate = 44100f; private set
    private val info = android.media.MediaCodec.BufferInfo()
    private var eos = false
    val atEnd: Boolean get() = eos && noBuffered

    private var pendBuf: ByteBuffer? = null
    private var pendOff = 0
    private var pendEnd = 0
    private var pendSr = 0
    private var noBuffered = false
    private var ch = 1

    fun read(l: FloatArray, r: FloatArray, max: Int): Int {
        var total = 0
        while (total < max) {
            if (pendBuf == null || pendOff >= pendEnd) {
                if (!fill()) break
            }
            val bb = pendBuf!!
            bb.order(ByteOrder.LITTLE_ENDIAN)
            bb.position(pendOff)
            val frames = (pendEnd - pendOff) / (2 * ch)
            val n = min(frames, max - total)
            for (i in 0 until n) {
                val sl = bb.short.toInt()
                val sr = if (ch > 1) bb.short.toInt() else sl
                l[total + i] = sl / 32768f
                r[total + i] = sr / 32768f
            }
            pendOff += n * 2 * ch
            total += n
        }
        if (total == 0) noBuffered = true
        return total
    }

    private fun fill(): Boolean {
        while (true) {
            val outIdx = codec.dequeueOutputBuffer(info, 10_000)
            if (outIdx >= 0) {
                val ob = codec.getOutputBuffer(outIdx)
                if (ob != null && info.size > 0) {
                    pendBuf = ob
                    pendOff = ob.position()
                    pendEnd = pendOff + info.size
                    codec.releaseOutputBuffer(outIdx, false)
                    return true
                }
                codec.releaseOutputBuffer(outIdx, false)
                continue
            }
            if (outIdx == android.media.MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val f = codec.outputFormat
                ch = f.getInteger(android.media.MediaFormat.KEY_CHANNEL_COUNT)
                continue
            }
            if (eos) return false
            val inIdx = codec.dequeueInputBuffer(10_000)
            if (inIdx >= 0) {
                val ib = codec.getInputBuffer(inIdx)!!
                val n = ex.readSampleData(ib, 0)
                if (n < 0) {
                    codec.queueInputBuffer(inIdx, 0, 0, 0, android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    eos = true
                } else {
                    codec.queueInputBuffer(inIdx, 0, n, ex.sampleTime, 0)
                    ex.advance()
                }
            }
        }
    }

    fun close() {
        try { codec.stop() } catch (_: Exception) {}
        codec.release()
        ex.release()
    }

    /** Seek to a microsecond position (flushes the codec; next read continues from there). */
    fun seekToUs(us: Long) {
        try {
            codec.flush()
            ex.seekTo(us, android.media.MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            eos = false
            noBuffered = false
            pendBuf = null; pendOff = 0; pendEnd = 0
        } catch (_: Exception) {}
    }

    companion object {
        fun open(path: String): AndroidAudioReader? {
            val ex = android.media.MediaExtractor()
            try {
                ex.setDataSource(path)
                var track = -1
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    if (f.getString(android.media.MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; break }
                }
                if (track < 0) { ex.release(); return null }
                ex.selectTrack(track)
                val fmt = ex.getTrackFormat(track)
                val mime = fmt.getString(android.media.MediaFormat.KEY_MIME) ?: return null
                val codec = try { android.media.MediaCodec.createDecoderByType(mime) } catch (_: Exception) { ex.release(); return null }
                codec.configure(fmt, null, null, 0)
                codec.start()
                val r = AndroidAudioReader(ex, codec)
                r.sampleRate = fmt.getInteger(android.media.MediaFormat.KEY_SAMPLE_RATE).toFloat()
                r.ch = fmt.getInteger(android.media.MediaFormat.KEY_CHANNEL_COUNT)
                return r
            } catch (_: Exception) {
                try { ex.release() } catch (_: Exception) {}
                return null
            }
        }
    }
}

/** Minimal streaming 16-bit stereo WAV writer. */
class Wav16Writer(private val file: File, private val sr: Float) {
    private val out = RandomAccessFile(file, "rw")
    private var frames = 0L
    private val hdr = ByteArray(44)

    init {
        out.setLength(0)
        out.write(hdr)
    }

    fun write(l: FloatArray, r: FloatArray, n: Int) {
        val bytes = ByteArray(n * 4)
        var o = 0
        for (i in 0 until n) {
            val ls = (min(1f, max(-1f, l[i])) * 32767f).toInt().toShort()
            val rs = (min(1f, max(-1f, r[i])) * 32767f).toInt().toShort()
            bytes[o++] = (ls.toInt() and 0xFF).toByte(); bytes[o++] = ((ls.toInt() shr 8) and 0xFF).toByte()
            bytes[o++] = (rs.toInt() and 0xFF).toByte(); bytes[o++] = ((rs.toInt() shr 8) and 0xFF).toByte()
        }
        out.write(bytes)
        frames += n
    }

    fun close() {
        val srI = sr.toInt()
        val dataLen = (frames * 4).toInt()
        val bb = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(0, 0x46464952)                       // "RIFF"
        bb.putInt(4, 36 + dataLen)
        bb.putInt(8, 0x45564157)                       // "WAVE"
        bb.putInt(12, 16)
        bb.putShort(16, 1)                             // PCM
        bb.putShort(18, 2)                             // channels
        bb.putInt(20, srI)
        bb.putInt(24, srI * 4)
        bb.putShort(28, 4)
        bb.putShort(30, 16)
        bb.putInt(32, dataLen)
        out.seek(0)
        out.write(hdr)
        out.close()
    }
}
