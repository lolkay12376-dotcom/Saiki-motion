package com.saiki.motion.core

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.abs
import kotlin.math.max

// Port of Sources/Media/AudioFxLive.swift — real-time playback of audio layers that carry effects.
// iOS: AVAudioEngine + custom AUAudioUnit. Android: AudioTrack (float stereo) + a render thread that
// runs the SAME DSP as the exporter (AudioFx.kt), so editing a slider is heard immediately and the
// render sounds identical. Only the effects whose settings changed are rebuilt, so dragging one
// slider never resets the others (reverb tails, LFO phases).
class AFxLiveUnit(val sampleRate: Int) {
    private class Slot(val uid: Int, val type: String, val p: AFxBase)

    private val lock = Object()
    private var slots = ArrayList<Slot>()            // main thread only
    private var pending: List<AFxBase> = emptyList() // handed to the render thread under `lock`
    private var dirty = false
    private var local: List<AFxBase> = emptyList()   // render thread only
    private var chain: List<AudioFxItem> = emptyList()

    /** Main thread: new (keyframe-evaluated) settings. Existing processors are only *updated*. */
    fun setChain(items: List<AudioFxItem>, sampleRate: Int) {
        chain = items
        val ns = ArrayList<Slot>()
        var changed = false
        for (item in items) {
            if (!item.on) continue
            val old = slots.firstOrNull { item.uid == it.uid && item.type == it.type }
            if (old != null) { old.p.update(item); ns.add(old) }
            else {
                val p = AudioFxProc.make(item, sampleRate.toFloat())
                if (p != null) { ns.add(Slot(item.uid, item.type, p)); changed = true }
            }
        }
        if (ns.size != slots.size) changed = true
        else for (i in ns.indices) if (ns[i].p !== slots[i].p) changed = true
        slots = ns
        if (changed) {
            synchronized(lock) { pending = ns.map { it.p }; dirty = true }
        }
    }

    /** Render thread: swaps in a new processor list if the main thread published one, then processes. */
    fun process(l: FloatArray, r: FloatArray, n: Int) {
        synchronized(lock) {
            if (dirty) { local = pending; dirty = false }
        }
        for (p in local) p.process(l, r, n)
    }
}

/** One live player for every effected layer (AVAudioEngine twin). */
object AudioFxLive {
    private class Entry(
        val reader: AndroidAudioReader,
        val track: AudioTrack,
        val unit: AFxLiveUnit,
        var segStart: Double = 0.0,
        var playing: Boolean = false,
        val path: String,
        val thread: Thread)

    private val entries = HashMap<Int, Entry>()
    private val pending = HashSet<Int>()
    private val failed = HashSet<String>()

    fun has(id: Int): Boolean = entries.containsKey(id)
    /** True while a layer's file is still being opened (play dry-silent instead of falling back). */
    fun isPending(id: Int): Boolean = synchronized(entries) { pending.contains(id) }

    /** Creates / updates the chain of a layer. `done` runs on main when a new entry became ready. */
    fun sync(l: Layer, path: String, done: () -> Unit) {
        val id = l.id
        synchronized(entries) {
            val e = entries[id]
            if (e != null && e.path == path) { e.unit.setChain(l.afxChainAt(Editor.time), e.reader.sampleRate.toInt()); return }
            if (entries.containsKey(id)) remove(id)
            if (pending.contains(id) || failed.contains(path)) return
            pending.add(id)
        }
        val chainCopy = l.afxChainAt(Editor.time)
        Thread {
            var f = AndroidAudioReader.open(path)
            if (f == null) {      // video container: pull the sound out first
                val tmp = File(Paths.appContext.cacheDir, "fxsrc-${abs(path.hashCode())}.m4a")
                if (tmp.exists() || AudioTools.extractAudio(path, tmp)) f = AndroidAudioReader.open(tmp.absolutePath)
            }
            val reader = f
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                if (reader == null) {
                    synchronized(entries) { pending.remove(id); failed.add(path) }
                    return@post
                }
                startEntry(id, path, reader, chainCopy, done)
            }
        }.start()
    }

    private fun startEntry(id: Int, path: String, reader: AndroidAudioReader, chainCopy: List<AudioFxItem>, done: () -> Unit) {
        val sr = reader.sampleRate.toInt()
        val unit = AFxLiveUnit(sr)
        unit.setChain(chainCopy, reader.sampleRate.toInt())
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
        val track = AudioTrack(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build(),
            AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build(),
            max(minBuf, 8192), AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE)
        val quit = java.util.concurrent.atomic.AtomicBoolean(false)
        val bufL = FloatArray(2048); val bufR = FloatArray(2048)
        val inter = FloatArray(4096)
        val thread = Thread {
            while (!quit.get()) {
                val n = reader.read(bufL, bufR, 2048)
                if (n <= 0) { quit.set(true); break }
                unit.process(bufL, bufR, n)
                for (i in 0 until n) { inter[i * 2] = bufL[i]; inter[i * 2 + 1] = bufR[i] }
                track.write(inter, 0, n * 2, AudioTrack.WRITE_BLOCKING)
            }
        }
        thread.name = "afx-live-$id"
        thread.isDaemon = true
        track.play()
        thread.start()
        synchronized(entries) {
            pending.remove(id)
            entries[id] = Entry(reader, track, unit, path = path, thread = thread)
        }
        done()
    }

    /** Playback tick: pushes keyframed parameter values (evaluated at the playhead) into the running processors. */
    fun setItems(id: Int, items: List<AudioFxItem>) {
        val e = synchronized(entries) { entries[id] } ?: return
        e.unit.setChain(items, e.reader.sampleRate.toInt())
    }

    fun remove(id: Int) {
        val e = synchronized(entries) { entries.remove(id) } ?: return
        e.track.stop(); e.track.release()
        // reader closed by its thread exit
    }

    fun prune(keep: Set<Int>) {
        val drop = synchronized(entries) { entries.keys.filter { !keep.contains(it) } }
        for (id in drop) remove(id)
    }

    fun removeAll() {
        val all = synchronized(entries) { entries.keys.toList() }
        for (id in all) remove(id)
    }

    fun pauseAll() {
        synchronized(entries) { for (e in entries.values) if (e.playing) { e.track.pause(); e.playing = false } }
    }

    /** Keeps the layer locked to the timeline. `want` = seconds into the source file. */
    fun tick(id: Int, inside: Boolean, want: Double, volume: Float, restart: Boolean) {
        val e = synchronized(entries) { entries[id] } ?: return
        e.track.setVolume(volume)
        if (inside) {
            // Android AudioTrack cannot seek a live stream cheaply; restart only on real drift (same 140 ms rule).
            val drift = abs(e.segStart - want)
            if (!e.playing || restart || drift > 0.14) {
                e.reader.seekTo(want)
                e.segStart = max(0.0, want)
                e.playing = true
            }
        } else if (e.playing) {
            e.track.pause(); e.playing = false
        }
    }
}

/** Seek helper on the MediaCodec reader (AVAudioFramePosition twin). */
fun AndroidAudioReader.seekTo(seconds: Double) {
    seekToUs((max(0.0, seconds) * 1_000_000).toLong())
}
