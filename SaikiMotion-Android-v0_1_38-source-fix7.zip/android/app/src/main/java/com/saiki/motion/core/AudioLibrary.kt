package com.saiki.motion.core

import com.saiki.motion.uikit.UIBarButtonItem
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UINavigationItem
import com.saiki.motion.uikit.UITableViewController
import com.saiki.motion.uikit.UITableView
import com.saiki.motion.uikit.UITableViewCell
import java.io.File

// Port of Sources/App/Editor/EditorAudioLibrary.swift — the "Audio" folder. Users paste audio
// files into Files > SaikiMotion > Audio; the editor's Audio tool lists everything in it.
// (Android: the folder is <filesDir>/SaikiMotion/Audio — Paths.root — and is reachable via
// the system file manager / adb; the empty-list hint keeps the same text as iOS.)

object AudioLibrary {
    val exts: Set<String> = setOf("mp3", "m4a", "wav", "aac", "aif", "aiff", "caf", "flac", "ogg", "mp4")

    /** <Documents>/SaikiMotion/Audio (created on first access so it shows up in the Files app). */
    val dir: File get() = File(Paths.root, "Audio").apply { mkdirs() }

    fun files(): List<File> {
        val all = dir.listFiles()?.filter { !it.name.startsWith(".") } ?: return emptyList()
        return all.filter { exts.contains(it.extension.lowercase()) }
            .sortedWith { a, b -> a.name.lowercase().compareTo(b.name.lowercase()) }
    }
}

class AudioLibraryController : UITableViewController() {
    var files: List<File> = emptyList()
    var onPick: ((File) -> Unit)? = null
    var onBrowse: (() -> Unit)? = null

    override fun viewDidLoad() {
        super.viewDidLoad()
        title = "Audio library"
        files = AudioLibrary.files()
        tableView.setBackgroundColor(UIColor.rgb(0.07f, 0.07f, 0.07f, 1f).toInt())
        navigationItem = UINavigationItem()
        navigationItem?.leftBarButtonItem = UIBarButtonItem("Close") { close() }
        navigationItem?.rightBarButtonItem = UIBarButtonItem("Browse Files") { browse() }
    }
    private fun close() { dismiss(animated = true) }
    private fun browse() { dismiss(animated = true) { onBrowse?.invoke() } }

    override fun numberOfRows(t: UITableView, section: Int): Int = maxOf(files.size, 1)
    override fun cellForRow(t: UITableView, row: Int): UITableViewCell {
        val c = UITableViewCell()
        c.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        c.textLabel?.textColor = UIColor.white
        c.textLabel?.numberOfLines = 0
        if (files.isEmpty()) {
            c.textLabel?.text = "Empty. Paste audio into Files › SaikiMotion › Audio, then reopen this list."
            c.textLabel?.textColor = UIColor.lightGray
            c.selectionStyle = 0
        } else {
            c.textLabel?.text = files[row].name
        }
        return c
    }
    override fun didSelectRow(t: UITableView, row: Int) {
        t.deselectRow(row)
        if (row >= files.size) return
        val u = files[row]
        dismiss(animated = true) { onPick?.invoke(u) }
    }
}
