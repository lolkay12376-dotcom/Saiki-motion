package com.saiki.motion.core

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// Port of Sources/Media/AudioTools.swift — audio extraction + beat detection.
// extractAudio: MediaExtractor+MediaMuxer pass-through of the audio track (AVAssetExportSession m4a).
// detectBeats: energy-onset detector — RMS windows off a mono decode, peaks above a local adaptive
// threshold become markers. Cheap, fully offline, good enough to snap cuts to music.
object AudioTools {
    /** Extracts the audio track of `srcPath` into `dest` (.m4a). */
    fun extractAudio(srcPath: String, dest: File): Boolean {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(srcPath)
            var audioTrack = -1
            var format: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { audioTrack = i; format = f; break }
            }
            if (audioTrack < 0 || format == null) return false
            ex.selectTrack(audioTrack)
            dest.delete()
            val muxer = try { MediaMuxer(dest.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4) } catch (_: Exception) { return false }
            try {
                val out = muxer.addTrack(format)
                muxer.start()
                val buf = ByteBuffer.allocate(1 shl 16)
                val info = MediaCodec.BufferInfo()
                var sps: Long = 0
                while (true) {
                    info.offset = 0
                    info.size = ex.readSampleData(buf, 0)
                    if (info.size < 0) break
                    info.presentationTimeUs = ex.sampleTime
                    info.flags = ex.sampleFlags
                    muxer.writeSampleData(out, buf, info)
                    sps = ex.sampleTime
                    ex.advance()
                }
                if (sps == 0L && dest.length() == 0L) return false
                return true
            } finally {
                try { muxer.stop() } catch (_: Exception) {}
                muxer.release()
            }
        } catch (_: Exception) {
            return false
        } finally {
            ex.release()
        }
    }

    /** Beat times (seconds) for an audio file. Empty when the file can't be decoded or is silent. */
    fun detectBeats(path: String): FloatArray {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(path)
            var audioTrack = -1
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { audioTrack = i; break }
            }
            if (audioTrack < 0) return FloatArray(0)
            ex.selectTrack(audioTrack)
            val fmt = ex.getTrackFormat(audioTrack)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return FloatArray(0)
            val codec = try { MediaCodec.createDecoderByType(mime) } catch (_: Exception) { return FloatArray(0) }
            try {
                codec.configure(fmt, null, null, 0)
                codec.start()
                // 1024-sample RMS windows (~23 ms at 44.1 kHz), mono mix-down
                val rms = ArrayList<Float>(20000)
                val buf = ArrayList<Float>(1024)
                var eos = false
                val info = MediaCodec.BufferInfo()
                while (!eos) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val ib = codec.getInputBuffer(inIdx)!!
                        val n = ex.readSampleData(ib, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            eos = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                    var outIdx = codec.dequeueOutputBuffer(info, 10_000)
                    while (outIdx >= 0) {
                        val ob = codec.getOutputBuffer(outIdx)
                        if (ob != null && info.size > 0) {
                            val bb = ob.order(ByteOrder.LITTLE_ENDIAN)
                            val shorts = info.size / 2
                            for (i in 0 until shorts) {
                                buf.add(bb.getShort().toFloat() / 32768f)
                                if (buf.size >= 1024) {
                                    var sum = 0f
                                    for (s in buf) sum += s * s
                                    rms.add(sqrt(sum / buf.size))
                                    buf.clear()
                                }
                            }
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        outIdx = codec.dequeueOutputBuffer(info, 0)
                    }
                }
                if (rms.size <= 8) return FloatArray(0)
                // window length in seconds: decode rate is the file's rate; both 44.1 and 48 kHz land at ~22-23 ms.
                val winSec = 1024f / 44100f
                // adaptive threshold: beat when energy exceeds the local mean by 42 % and is a local
                // maximum, with 120 ms de-duplication.
                val beats = ArrayList<Float>()
                val n = rms.size
                for (i in 1 until n - 1) {
                    val span = 24
                    val lo = max(0, i - span); val hi = min(n, i + span)
                    var sum = 0f
                    for (j in lo until hi) sum += rms[j]
                    val mean = sum / (hi - lo)
                    if (rms[i] > mean * 1.42f && rms[i] > rms[i - 1] && rms[i] >= rms[i + 1] && rms[i] > 0.004f) {
                        val t = i * winSec
                        if (beats.isEmpty() || t - beats[beats.size - 1] > 0.12f) beats.add(t)
                    }
                }
                return beats.toFloatArray()
            } finally {
                try { codec.stop() } catch (_: Exception) {}
                codec.release()
            }
        } catch (_: Exception) {
            return FloatArray(0)
        } finally {
            ex.release()
        }
    }
}
