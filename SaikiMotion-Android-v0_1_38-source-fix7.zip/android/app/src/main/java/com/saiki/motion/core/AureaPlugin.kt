package com.saiki.motion.core

import org.json.JSONObject

// Port of Sources/Effects/AureaPlugin.swift (multi-pass .aureaplugin: plugin.json + pass .frag files).
// PARITY-NOTE(AureaPlugin.swift:2): the plugin runtime is not ported. iOS runs the passes only in its GL renderer
//   (SceneRenderer.applyPluginEffect); Android has no GL renderer, so frames carrying a plugin effect take the CPU fallback
//   (SceneRenderer.ineligibleReason: "GL-only plugin"). A Vulkan multi-pass runtime (named pass targets, `aurea` uniform
//   {layer, time}, aurea_source / pass-input samplers) would be needed; aureaPassSource() below is spec text only.

private fun en(o: JSONObject?, fallback: String = ""): String {
    if (o == null) return fallback
    val e = o.optS("en")
    if (e.isNotEmpty()) return e
    val it = o.keys()
    while (it.hasNext()) { val v = o.optS(it.next()); if (v.isNotEmpty()) return v }
    return fallback
}

private fun trimWs(s: String) = s.trim { it == ' ' || it == '\t' }

/**
 * Loads one plugin folder (AureaPlugin.swift:28 EffectDef.fromAureaPlugin). `dirName` = folder name, `source` = EffectDef.source,
 * `readFile(rel)` returns a file of that folder as text. null when plugin.json / a pass shader is missing.
 */
fun EffectDef.Companion.fromAureaPlugin(dirName: String, source: String, readFile: (String) -> String?): EffectDef? {
    val txt = readFile("plugin.json") ?: return null
    val o = parseJson(txt) ?: return null
    val name = en(o.optJSONObject("name"), dirName)
    val pid = o.optS("id")
    var slug = (if (pid.isEmpty()) name else pid).lowercase().map { c -> if (c.isLetterOrDigit()) c else '_' }.joinToString("")
    slug = slug.trim('_')
    val d = EffectDef("aurea_$slug", name, en(o.optJSONObject("description")), o.optS("category", "Glitch"), source = source)

    o.optJSONArray("params")?.let { pa ->
        for (i in 0 until pa.length()) {
            val po = pa.optJSONObject(i) ?: continue
            val key = trimWs(po.optS("id"))
            if (key.isEmpty()) continue
            val label = en(po.optJSONObject("label"), key)
            when (po.optS("type")) {
                "color" -> d.colors.add(ColorParam(key, label, EffectDef.parseColor(po.optS("default", "#FFFFFF"))))
                "bool" -> d.props.add(PropDef(key, label, 0f, 1f, if (po.optB("default")) 1f else 0f, 0, listOf("Off", "On")))
                "enum" -> {
                    val opts = ArrayList<String>()
                    po.optJSONArray("options")?.let { oa -> for (j in 0 until oa.length()) opts.add(en(oa.optJSONObject(j), oa.optS(j))) }
                    d.props.add(PropDef(key, label, 0f, maxOf(opts.size - 1, 0).toFloat(), po.optF("default"), 0, opts))
                }
                "int" -> d.props.add(PropDef(key, label, po.optF("min"), po.optF("max", 100f), po.optF("default"), 0))
                else -> {
                    val lo = po.optF("min"); val hi = po.optF("max", 1f)
                    val span = hi - lo
                    d.props.add(PropDef(key, label, lo, hi, po.optF("default"), if (span <= 5) 2 else (if (span <= 100) 1 else 0)))
                }
            }
        }
    }
    val rs = o.optF("renderScale", 1f)
    d.renderScale = if (rs > 0) minOf(maxOf(rs, 0.2f), 1f) else 1f
    val pa = o.optJSONArray("passes")
    if (pa == null || pa.length() == 0) return null
    for (i in 0 until pa.length()) {
        val po = pa.optJSONObject(i) ?: return null
        val code = readFile(po.optS("shader")) ?: return null
        val inputs = LinkedHashMap<String, String>()
        po.optJSONObject("inputs")?.let { io -> val it = io.keys(); while (it.hasNext()) { val k = it.next(); inputs[k] = io.optS(k) } }
        val sc = po.optF("scale", 1f)
        val t = po.optS("target")
        d.passes.add(FxPass(code, if (t.isEmpty()) null else t, if (sc > 0) minOf(sc, 1f) else 1f, inputs))
    }
    d.sharedPassProgram = d.passes.size > 1 && d.passes.map { it.code }.toSet().size == 1
    return d
}

/** GLSL ES 3.00 source of pass `i` (AureaPlugin.swift:85, verbatim spec text). */
fun EffectDef.aureaPassSource(i: Int): String {
    val ps = passes[i]
    val s = StringBuilder("""#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
in vec2 vUv;
out vec4 aureaOut;
uniform sampler2D aurea_source;

""")
    for (k in ps.inputs.keys.sorted()) s.append("uniform sampler2D $k;\n")
    s.append(if (sharedPassProgram) "uniform int aurea_pass_u;\n#define AUREA_PASS_INDEX aurea_pass_u\n" else "#define AUREA_PASS_INDEX $i\n")
    s.append("struct AureaU { vec3 layer; vec3 time; };\nuniform AureaU aurea;\n")
    for (p in props) s.append("uniform float ${p.key};\n")
    for (c in colors) s.append("uniform vec4 ${c.key};\n")
    s.append("""float aurea_hash(vec2 p) { vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
float aurea_noise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(aurea_hash(i), aurea_hash(i + vec2(1.0, 0.0)), u.x),
               mix(aurea_hash(i + vec2(0.0, 1.0)), aurea_hash(i + vec2(1.0, 1.0)), u.x), u.y);
}
vec2 aurea_px_to_uv(vec2 px) { return px / max(aurea.layer.xy, vec2(1.0)); }
vec2 aurea_uv_to_px(vec2 uv) { return uv * max(aurea.layer.xy, vec2(1.0)); }
vec2 aurea_hash2(vec2 p) { return vec2(aurea_hash(p), aurea_hash(p + vec2(17.31, 41.7))); }
vec2 aurea_layer_uv(vec2 p) { return p; }
vec4 aurea_unpremultiply(vec4 c) { return c.a > 0.0 ? vec4(c.rgb / c.a, c.a) : vec4(0.0); }
vec3 aurea_srgb_to_linear(vec3 c) { return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), c)); }
vec3 aurea_linear_to_srgb(vec3 c) { return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), c)); }
vec4 aurea_srgb_to_linear(vec4 c) { return vec4(aurea_srgb_to_linear(c.rgb), c.a); }
vec4 aurea_linear_to_srgb(vec4 c) { return vec4(aurea_linear_to_srgb(c.rgb), c.a); }

""")
    s.append(ps.code)
    s.append("\nvoid main() { aureaOut = aurea_main(vUv); }\n")
    return s.toString()
}
