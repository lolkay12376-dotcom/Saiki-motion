package com.saiki.motion.core

import android.util.Log
import org.json.JSONObject

/**
 * Sources/Effects/Builtins*.swift (the built-in effect catalog, 175 EffectDef + 5 examples).
 * The Swift is code (loops, string helpers), so the defs are NOT hand-ported: tools/dump_catalog.sh compiles the iOS Builtins*.swift
 * unchanged (macOS swiftc, or the swift.org Linux toolchain + a ld.gold->ld.bfd symlink) and writes
 * shared/resources/catalog/builtins.json (ids, props, colours, inputs, categories, GLSL text exactly, in Builtins.all() order).
 * This object only reads that file. The committed catalog was generated from SaikiMotion v0.1.22: 175 builtins + 5 examples.
 */
object Builtins {
    private const val CATALOG = "catalog/builtins.json"
    private var cache: JSONObject? = null

    @Synchronized private fun catalog(): JSONObject? {
        cache?.let { return it }
        val t = Assets.readText(CATALOG)
        if (t == null) { Log.e("Builtins", "missing asset $CATALOG: run tools/dump_catalog.sh"); return null }
        val o = parseJson(t)
        if (o == null) Log.e("Builtins", "$CATALOG is not valid JSON")
        cache = o
        return o
    }

    private fun parse(o: JSONObject): EffectDef {
        val d = EffectDef(o.optS("id"), o.optS("name"), o.optS("desc"), o.optS("category", "Custom"), o.optI("kind"),
            previewAnim = o.optS("preview", "swipe"), builtin = o.optB("builtin"), bundled = o.optB("bundled"),
            source = if (o.has("source")) o.optS("source") else null, glsl = o.optS("glsl"))
        if (o.has("msl")) d.msl = o.optS("msl")
        o.optJSONArray("props")?.let { pa ->
            for (i in 0 until pa.length()) {
                val p = pa.getJSONObject(i)
                var opts: MutableList<String>? = null
                p.optJSONArray("options")?.let { oa -> opts = ArrayList(); for (j in 0 until oa.length()) opts!!.add(oa.optS(j)) }
                d.props.add(PropDef(p.optS("key"), p.optS("label"), p.optF("min"), p.optF("max"), p.optF("def"), p.optI("dec", 2), opts, p.optB("inf"), p.optF("span", 1f)))
            }
        }
        o.optJSONArray("colors")?.let { ca ->
            for (i in 0 until ca.length()) { val c = ca.getJSONObject(i); d.colors.add(ColorParam(c.optS("key"), c.optS("label"), c.optColor("def"))) }
        }
        o.optJSONArray("inputs")?.let { ia -> for (i in 0 until ia.length()) d.inputs.add(ia.optS(i)) }
        return d
    }

    /** Builtins.all() (Builtins.swift:1641). */
    fun all(): List<EffectDef> {
        val out = ArrayList<EffectDef>()
        val a = catalog()?.optJSONArray("builtins")
        if (a != null) for (i in 0 until a.length()) out.add(parse(a.getJSONObject(i)))
        for (d in out) {
            d.builtin = true
            if (d.name.startsWith("uni.")) d.category = "Universe"
            if (d.glsl.isEmpty()) d.glsl = "return src(uv);"
        }
        return out
    }

    /** The five bundled SDK examples (Builtins.swift:1689). */
    val exampleIds = listOf("filmgrain", "tint_pulse", "crt_tv", "scan_wipe", "chroma")

    /** Builtins.exampleById: unknown ids give the "filmgrain" example (the Swift switch default). */
    fun exampleById(id: String): EffectDef? {
        val a = catalog()?.optJSONArray("examples") ?: return null
        var fallback: JSONObject? = null
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optS("id") == id) return parse(o)
            if (o.optS("id") == "filmgrain") fallback = o
        }
        return fallback?.let { parse(it) }
    }
}
