@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsAM.swift — Alight Motion style effects (ids exactly as in the
// XML: nova.effect.am-* / com.alightcreative.gradientoverlay). Every EffectDef comes from the
// generated catalog (core/Builtins.kt). This twin keeps the exported id set (EffectThumbs)
// and the snz() 2D-simplex-noise snippet builder the file exports.

/** BuiltinsAM.swift:9 */
val amFxIds: Set<String> = setOf(
    "nova.effect.am-auto-shake", "nova.effect.am-oscillate", "nova.effect.am-posterize",
    "nova.effect.am-grunge", "nova.effect.am-pulse-opacity-legacy", "nova.effect.am-scale-assist", "com.alightcreative.gradientoverlay")

/** BuiltinsAM.swift:13 — 2D simplex noise, inlined; `s` makes every local name unique. */
internal fun snz(s: String, vx: String, vy: String, out: String): String {
    val t = """
    { vec2 v$s = vec2($vx, $vy);
      vec2 i$s = floor(v$s + vec2((v$s.x + v$s.y) * 0.366025403784439));
      vec2 a$s = v$s - i$s + vec2((i$s.x + i$s.y) * 0.211324865405187);
      float s$s = step(a$s.y, a$s.x); vec2 o$s = vec2(s$s, 1.0 - s$s);
      vec2 b$s = a$s - o$s + vec2(0.211324865405187); vec2 c$s = a$s - vec2(0.577350269189626);
      i$s = mod(i$s, 289.0);
      vec3 p$s = vec3(i$s.y) + vec3(0.0, o$s.y, 1.0); p$s = mod((p$s * 34.0 + 1.0) * p$s, 289.0);
      p$s = p$s + vec3(i$s.x) + vec3(0.0, o$s.x, 1.0); p$s = mod((p$s * 34.0 + 1.0) * p$s, 289.0);
      vec3 m$s = max(vec3(0.5) - vec3(dot(a$s, a$s), dot(b$s, b$s), dot(c$s, c$s)), vec3(0.0)); m$s = m$s * m$s; m$s = m$s * m$s;
      vec3 x$s = 2.0 * fract(p$s * 0.024390243902439) - 1.0; vec3 h$s = abs(x$s) - 0.5; vec3 q$s = floor(x$s + 0.5); vec3 k$s = x$s - q$s;
      m$s = m$s * (1.79284291400159 - 0.85373472095314 * (k$s * k$s + h$s * h$s));
      vec3 g$s = vec3(k$s.x * a$s.x + h$s.x * a$s.y, k$s.y * b$s.x + h$s.y * b$s.y, k$s.z * c$s.x + h$s.z * c$s.y);
      $out = 130.0 * dot(m$s, g$s); }
    """
    return t + "\n"
}
