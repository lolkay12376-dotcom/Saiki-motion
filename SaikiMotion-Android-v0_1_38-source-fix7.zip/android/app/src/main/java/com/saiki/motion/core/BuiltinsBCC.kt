@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsBCC.swift — BCC Grunge, BCC Caustics, BCC Extruded EPS-SVG
// (2.5D) and Linear Wipe. Every EffectDef comes from the generated catalog (core/Builtins.kt);
// bccprism/bccmosaic/bcclightsweep/bccstrands live in BuiltinsSapphire4.swift territory and their
// thumbnail id set is ported in core/BuiltinsSapphire4.kt. This file exports no other tables.

/** BuiltinsBCC.swift:3 — the apply-mode labels shared by the BCC tables. */
val bccApplyModes = listOf("Normal", "Multiply", "Screen", "Overlay", "Soft Light", "Hard Light", "Add", "Difference", "Color Burn", "Linear Burn")
