@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsCapCut.swift — CapCut-style effects (ids kept as in the XML:
// nova.effect.capcut.*) plus the Voronoi Cells generator. Every EffectDef comes from the
// generated catalog (core/Builtins.kt). This twin keeps the exported id set (EffectThumbs).

/** BuiltinsCapCut.swift:7 */
val capcutFxIds: Set<String> = setOf("nova.effect.capcut.voronoi", "nova.effect.capcut.fuzzy", "nova.effect.capcut.golden.hour")
