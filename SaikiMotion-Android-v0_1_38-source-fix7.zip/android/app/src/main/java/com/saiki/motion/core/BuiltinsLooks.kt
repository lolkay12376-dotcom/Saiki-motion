@file:Suppress("unused", "FunctionName")

package com.saiki.motion.core

import kotlin.math.max
import kotlin.math.min

// Port of Sources/Effects/BuiltinsLooks.swift — the tables the Looks editor shares with the effect:
// looksPresetNames, looksCurveChannels, looksCurveProps(), looksCurveGlsl().
// The "mblooks" EffectDef itself (props/colors/GLSL) is NOT hand-ported: the effect catalog
// (shared/resources/catalog/builtins.json, generated from the Swift) carries it byte-for-byte,
// exactly like every other Builtins*.swift entry (see core/Builtins.kt).

/** BuiltinsLooks.swift:9 */
val looksPresetNames = listOf("Custom", "Teal & Orange", "Bleach Bypass", "Vintage Film", "Cool Noir", "Warm Sunset",
    "Cyberpunk", "Matte Fade", "Moody Green", "Dreamy Glow", "High Contrast B&W",
    "Faded Pastel", "Golden Hour")

/** BuiltinsLooks.swift:92 — 7 points per channel at x = i/6, Catmull-Rom between them; Master + R + G + B. */
val looksCurveChannels = listOf("M", "R", "G", "B")

/** BuiltinsLooks.swift:94 */
fun looksCurveProps(): List<PropDef> {
    val out = ArrayList<PropDef>()
    for (ch in looksCurveChannels) {
        for (i in 0 until 7) out.add(PropDef("lkCv$ch$i", "Curve $ch$i", 0f, 1f, i.toFloat() / 6f, 3))
    }
    return out
}

/** BuiltinsLooks.swift:102 — the GLSL curve evaluation block (string builder, identical maths). */
fun looksCurveGlsl(): String {
    fun ev(v: String, P: String, o: String, id: String): String {
        val s = StringBuilder("{ float t$id = clamp($v, 0.0, 1.0) * 6.0; float fi$id = min(floor(t$id), 5.0); float f$id = t$id - fi$id; float q0$id = 0.0; float q1$id = 0.0; float q2$id = 0.0; float q3$id = 0.0;\n")
        for (seg in 0 until 6) {
            val idx = intArrayOf(max(seg - 1, 0), seg, seg + 1, min(seg + 2, 6))
            val head = if (seg == 0) "if" else "else if"
            val cond = if (seg == 5) "" else " (fi$id < ${seg + 0.5})"
            val assign = (0 until 4).joinToString(" ") { "q$it$id = lkCv$P${idx[it]};" }
            s.append(if (seg == 5) "else { $assign }\n" else "$head$cond { $assign }\n")
        }
        s.append("$o = 0.5 * (2.0 * q1$id + (q2$id - q0$id) * f$id + (2.0 * q0$id - 5.0 * q1$id + 4.0 * q2$id - q3$id) * f$id * f$id + (3.0 * q1$id - q0$id - 3.0 * q2$id + q3$id) * f$id * f$id * f$id); }\n")
        return s.toString()
    }
    val g = StringBuilder("if (lkCurvAmt > 0.001) {\nvec3 cvIn = clamp(c, 0.0, 1.0);\nvec3 cvOut = cvIn;\nfloat cvT = 0.0;\n")
    for ((comp, P) in listOf("r" to "R", "g" to "G", "b" to "B")) {
        g.append(ev("cvIn.$comp", "M", "cvT", "m$comp"))
        g.append(ev("cvT", P, "cvOut.$comp", "k$comp"))
    }
    g.append("c = mix(c, cvOut, lkCurvAmt);\n}\n")
    return g.toString()
}
