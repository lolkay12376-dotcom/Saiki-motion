@file:Suppress("unused", "FunctionName")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsMBL.swift — the tables the MBL editor shares with the effect:
// mblHslNames, mblHslHue, mblHazePresets (+ the mblSMask/mblSetLum GLSL helpers used by the catalog GLSL).
// The "mbl" EffectDef itself is carried by the generated effect catalog (core/Builtins.kt), exactly
// like every other Builtins*.swift entry.

/** BuiltinsMBL.swift:7 */
val mblHslNames = listOf("Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple", "Magenta")

/** BuiltinsMBL.swift:8 */
val mblHslHue = floatArrayOf(0f, 30f, 60f, 120f, 180f, 240f, 270f, 300f)

/** Haze/Flare preset: name, [key: value], tint RGB 0...1. Index 0 = None. */
class MBLHazePreset(val name: String, val v: Map<String, Float>, val tint: Triple<Float, Float, Float>)

/** BuiltinsMBL.swift:22 */
val mblHazePresets: List<MBLHazePreset> = listOf(
    MBLHazePreset("None", emptyMap(), Triple(0.226f, 0.181f, 1.0f)),
    MBLHazePreset("Warm Sunset", mapOf("mbHfSp" to 30f, "mbHfSo" to 60f, "mbHfRe" to 65f, "mbHfEx" to -0.5f, "mbHfRx" to -1f, "mbHfRf" to 1f, "mbHfBx" to 40f, "mbHfSh" to 60f), Triple(1.0f, 0.55f, 0.2f)),
    MBLHazePreset("Cool Daylight", mapOf("mbHfSp" to 18f, "mbHfSo" to 55f, "mbHfRe" to 50f, "mbHfEx" to -1f, "mbHfRx" to -1.5f, "mbHfRf" to 1f, "mbHfBx" to 50f, "mbHfSh" to 70f), Triple(0.55f, 0.75f, 1.0f)),
    MBLHazePreset("Tungsten Spill", mapOf("mbHfSp" to 26f, "mbHfSo" to 70f, "mbHfRe" to 45f, "mbHfEx" to -0.8f, "mbHfRx" to -2f, "mbHfRf" to 0f, "mbHfBx" to 55f, "mbHfSh" to 75f), Triple(1.0f, 0.7f, 0.35f)),
    MBLHazePreset("Neon Haze", mapOf("mbHfSp" to 40f, "mbHfSo" to 80f, "mbHfRe" to 75f, "mbHfEx" to 0f, "mbHfRx" to 0f, "mbHfRf" to 1f, "mbHfBx" to 30f, "mbHfSh" to 40f), Triple(1.0f, 0.2f, 0.9f)),
    MBLHazePreset("Subtle Veil", mapOf("mbHfSp" to 10f, "mbHfSo" to 90f, "mbHfRe" to 85f, "mbHfEx" to -1.5f, "mbHfRx" to -3f, "mbHfRf" to 0f, "mbHfBx" to 70f, "mbHfSh" to 50f), Triple(0.8f, 0.85f, 1.0f)),
)

/** BuiltinsMBL.swift:11 — S-curve mask shared by Vignette / Spot / Grad (the kernels' `potS` lo/hi curve). */
fun mblSMask(u: String, f: String, out: String, n: String): String =
    "float s$n = clamp($f, 0.001, 0.999); float k$n = abs(s$n - 0.5) * 5.0 + 2.5; float x1$n = $u / s$n; float x2$n = ($u - 1.0) / (s$n - 1.0); " +
    "float lo$n = min((x1$n > 0.0 ? pow(x1$n, k$n) : 0.0) * s$n, s$n); float hi$n = max((x2$n > 0.0 ? pow(x2$n, k$n) : 0.0) * (s$n - 1.0) + 1.0, s$n); float $out = lo$n - s$n + hi$n;\n"

/** BuiltinsMBL.swift:16 — Duotone `comLum` (SetLum + ClipColor) for colour `cv`, result in `out`. */
fun mblSetLum(cv: String, out: String, n: String): String =
    "vec3 c$n = $cv + vec3(l1 - dot($cv, vec3(0.3, 0.59, 0.11))); float l$n = dot(c$n, vec3(0.3, 0.59, 0.11)); float n$n = min(c$n.r, min(c$n.g, c$n.b)); float m$n = max(c$n.r, c$n.b); " +
    "if (n$n < 0.0) { c$n = (c$n - l$n) * l$n / (l$n - n$n) + l$n; } if (m$n > 1.0) { c$n = (c$n - l$n) * (1.0 - l$n) / (m$n - l$n) + l$n; } vec3 $out = c$n;\n"
