@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsMotion.swift — Oscillate, Squeeze, Twitch and Motion Tile.
// Every EffectDef comes from the generated catalog (core/Builtins.kt). Oscillate/Twitch are
// "moving" effects: the renderer evaluates them per motion-blur sub-sample (SceneRenderer.movingFx,
// core/SceneRenderer.kt:407) and Twitch's Time operator retimes the layer
// (SceneRenderer.twitchRetime, core/SceneRenderer.kt:958) — both twins exist.
// This twin keeps the onOff labels the file exports.

/** BuiltinsMotion.swift:10 */
private val onOff = listOf("Off", "On")

/** The shared Off/On option list used by the motion tables (exposed name follows the Swift's private let). */
val motionOnOff: List<String> get() = onOff
