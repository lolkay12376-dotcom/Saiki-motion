@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsSapphire2.swift — Sapphire-style Etching, Film Damage and Warp Bubble 2.
// EffectDefs come from the generated catalog (core/Builtins.kt + shared/resources/catalog/builtins.json);
// this twin keeps the snippet builders (wrap2/bubbleSet/bubbleProps) that the Swift file exports.

/** BuiltinsSapphire2.swift:6 */
private val wrap2Opts = listOf("No", "Tile", "Reflect")

/** BuiltinsSapphire2.swift:10 */
private fun wrap2(v: String, wx: String, wy: String): String =
    "float inb = 1.0;\n" +
    "if ($wx < 0.5) { if ($v.x < 0.0 || $v.x > 1.0) { inb = 0.0; } }\n" +
    "else if ($wx < 1.5) { $v.x = fract($v.x); }\n" +
    "else { $v.x = 1.0 - abs(mod($v.x, 2.0) - 1.0); }\n" +
    "if ($wy < 0.5) { if ($v.y < 0.0 || $v.y > 1.0) { inb = 0.0; } }\n" +
    "else if ($wy < 1.5) { $v.y = fract($v.y); }\n" +
    "else { $v.y = 1.0 - abs(mod($v.y, 2.0) - 1.0); }\n\n"

/** BuiltinsSapphire2.swift:24 — one bubble set (A or B): displacement into `nA` / `nB`. */
internal fun bubbleSet(s: String, k: String): String =
    "vec2 pp$s = q0 * ${k}Freq + vec2(${k}ShX, ${k}ShY) + vec2(${k}SpdX, ${k}SpdY) * uTime + vec2(${k}Seed * 17.3, ${k}Seed * 9.1);\n" +
    "vec2 n$s = vec2(0.0);\n" +
    "float amp$s = 1.0;\n" +
    "float tot$s = 0.0;\n" +
    "for (int i = 0; i < 10; i++) {\n" +
    "    if (float(i) < ${k}Oct) {\n" +
    "        vec2 pq = rot(pp$s, 0.9) + vec2(5.3, 8.1);\n" +
    "        n$s += amp$s * vec2(0.5 * (vnoise(pp$s) + vnoise(pq)) - 0.5,\n" +
    "                            0.5 * (vnoise(pp$s + vec2(31.7, 17.3)) + vnoise(pq + vec2(11.1, 23.9))) - 0.5);\n" +
    "        tot$s += amp$s;\n" +
    "        amp$s *= 0.5;\n" +
    "        pp$s *= 2.0;\n" +
    "    }\n" +
    "}\n" +
    "n$s = n$s / max(tot$s, 0.0001) * 2.0 * ${k}Amp * 2.0 / max(${k}Freq, 0.01);\n\n"

/** BuiltinsSapphire2.swift:45 */
internal fun bubbleProps(k: String, nm: String, seed: Float, spd: Float): List<PropDef> = listOf(
    PropDef("${k}Amp", "$nm Amplitude", -3f, 3f, 0.25f, 3),
    PropDef("${k}Freq", "$nm Frequency", 0.01f, 200f, 4f, 2),
    PropDef("${k}Oct", "$nm Octaves", 1f, 10f, 1f, 0),
    PropDef("${k}Seed", "$nm Seed", 0f, 100f, seed, 3),
    PropDef("${k}ShX", "$nm Shift Start X", -100f, 100f, 0f, 3),
    PropDef("${k}ShY", "$nm Shift Start Y", -100f, 100f, 0f, 3),
    PropDef("${k}SpdX", "$nm Speed X", -10f, 10f, spd, 3),
    PropDef("${k}SpdY", "$nm Speed Y", -10f, 10f, 0f, 3))
