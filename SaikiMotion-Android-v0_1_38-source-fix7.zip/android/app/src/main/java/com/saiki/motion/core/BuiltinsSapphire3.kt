@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsSapphire3.swift — Sapphire-style Texture Folded and Edge Rays.
// EffectDefs come from the generated catalog (core/Builtins.kt); this twin keeps the
// edgeAt/rayLoop snippet builders the Swift file exports.

/** BuiltinsSapphire3.swift:10 — colour-difference edge of the source at `p`, written into `out`. */
internal fun edgeAt(p: String, out: String): String =
    "vec3 $out;\n" +
    "{\n" +
    "    vec2 ex = vec2(eth / asp.x, 0.0);\n" +
    "    vec2 ey = vec2(0.0, eth);\n" +
    "    vec4 a0 = src($p + ex); vec4 a1 = src($p - ex);\n" +
    "    vec4 a2 = src($p + ey); vec4 a3 = src($p - ey);\n" +
    "    vec4 dd = abs(a0 - a1) + abs(a2 - a3);\n" +
    "    $out = mix(dd.rgb, vec3(dd.a), erFromA) * erEdgeBr;\n" +
    "    if (erShAmp > 0.0) {\n" +
    "        vec2 sq = ($p - 0.5) * asp * erShFreq + vec2(erShSX, erShSY) + vec2(erShVX, erShVY) * uTime + vec2(erShSeed * 31.7, erShSeed * 7.3);\n" +
    "        $out *= mix(1.0, vnoise(sq) * 2.0, clamp(erShAmp, 0.0, 1.0));\n" +
    "    }\n" +
    "}\n\n"

/** BuiltinsSapphire3.swift:30 — one ray-marching loop accumulating into `acc` with ray length `len`. */
internal fun rayLoop(acc: String, swz: String, len: String): String =
    "for (int i = 0; i < 24; i++) {\n" +
    "    float tt = (float(i) + 0.5 + jit) / 24.0;\n" +
    "    float tr = mix(-erRev, 1.0, tt);\n" +
    "    float wt = ((1.0 - erBias) * (1.0 - abs(tr)) + erBias * abs(tr)) * 2.0;\n" +
    "    vec2 sp = cen + (uv - cen) * (1.0 - $len * tr);\n" +
    edgeAt("sp", "ee") +
    "    $acc += ee$swz * wt;\n" +
    "}\n\n"

/** BuiltinsSapphire3.swift:44 — the Texture Folded / Edge Rays Combine options. */
internal val sapphire3Combine = listOf("Texture Only", "Mult", "Add", "Screen", "Difference", "Overlay")
