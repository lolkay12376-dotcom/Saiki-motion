@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsSapphire4.swift — S_Feedback, S_GradientMulti, S_WipeChecker,
// S_Zebrafy, BCC+ Prism, BCC Mosaic, BCC Light Sweep, Prism Displacement, BCC Organic Strands.
// EffectDefs come from the generated catalog (core/Builtins.kt); this twin keeps the exported
// id set (used by EffectThumbs.sampleIndex) and the shared snippet builders.

/** BuiltinsSapphire4.swift:9 — effects whose browser thumbnail uses the skyscraper sample photo. */
val skyscraperFxIds: Set<String> = setOf(
    "sfeedback", "sgradientmulti", "swipechecker", "szebrafy", "bccprism", "bccmosaic", "bcclightsweep",
    "prismdisplacement", "bccstrands", "bccgrunge", "bcccaustics", "bccextrude", "uprism", "upointzoom")

/** BuiltinsSapphire4.swift:11 */
internal fun sapphire4MaskProps(k: String): List<PropDef> = listOf(
    PropDef(k + "Maskuse", "Mask Use", 0f, 1f, 0f, 0, listOf("Luma", "Alpha")),
    PropDef(k + "InvMask", "Invert Mask", 0f, 1f, 0f, 0, listOf("Off", "On")))

/** BuiltinsSapphire4.swift:16 — needs `vec4 s0 = src(uv);` and `vec4 o` in scope. */
internal fun sapphire4MaskTail(k: String): String =
    "    if (uHas0 > 0.5) {\n" +
    "        vec4 mk = in0(uv);\n" +
    "        float mm = ${k}Maskuse < 0.5 ? luma(mk.rgb) : mk.a;\n" +
    "        if (${k}InvMask > 0.5) { mm = 1.0 - mm; }\n" +
    "        o = mix(s0, o, mm);\n" +
    "    }\n" +
    "    return o;\n"

/** BuiltinsSapphire4.swift:22 */
internal val applyModes = listOf("Normal", "Add", "Multiply", "Screen", "Difference")

/** BuiltinsSapphire4.swift:24 — Apply `s` over `d` with a blend (both premultiplied). Expects `k + "Apply"` float. */
internal fun applyExpr(k: String, d: String, s: String, out: String): String =
    "    vec4 $out = $s;\n" +
    "    if (${k}Apply > 3.5) { $out = vec4(abs($d.rgb - $s.rgb), max($d.a, $s.a)); }\n" +
    "    else if (${k}Apply > 2.5) { $out = vec4(1.0 - (1.0 - $d.rgb) * (1.0 - $s.rgb), max($d.a, $s.a)); }\n" +
    "    else if (${k}Apply > 1.5) { $out = vec4($d.rgb * $s.rgb, $s.a); }\n" +
    "    else if (${k}Apply > 0.5) { $out = $d + $s; }\n"
