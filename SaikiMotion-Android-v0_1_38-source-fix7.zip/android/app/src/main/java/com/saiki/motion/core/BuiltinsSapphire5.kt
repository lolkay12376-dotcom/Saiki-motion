@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsSapphire5.swift — S_Clouds, S_CloudsPsyko, S_Invert, S_Monochrome.
// EffectDefs come from the generated catalog (core/Builtins.kt); this twin keeps the
// s5* snippet builders the Swift file exports.

/** BuiltinsSapphire5.swift:6 */
internal fun s5MaskProps(k: String): List<PropDef> = listOf(
    PropDef(k + "Maskuse", "Mask Use", 0f, 1f, 0f, 0, listOf("Luma", "Alpha")),
    PropDef(k + "InvMask", "Invert Mask", 0f, 1f, 0f, 0, listOf("Off", "On")))

/** BuiltinsSapphire5.swift:11 — needs `vec4 s0` and `vec4 o` in scope. */
internal fun s5MaskTail(k: String): String =
    "    if (uHas0 > 0.5) {\n" +
    "        vec4 mk = in0(uv);\n" +
    "        float mm = ${k}Maskuse < 0.5 ? luma(mk.rgb) : mk.a;\n" +
    "        if (${k}InvMask > 0.5) { mm = 1.0 - mm; }\n" +
    "        o = mix(s0, o, mm);\n" +
    "    }\n" +
    "    return o;\n"

/** BuiltinsSapphire5.swift:23 — statements that define `float n` (0..1 cloud value). */
internal fun s5Noise(k: String): String =
    "    float asp = uRes.x / uRes.y;\n" +
    "    vec2 q = (uv - 0.5) * vec2(asp, 1.0) * ${k}Freq * 3.0 * vec2(${k}FreqX, 1.0);\n" +
    "    q += vec2(${k}ShX, ${k}ShY) + vec2(${k}SpX, ${k}SpY) * uTime * 0.5 + vec2(${k}Seed * 37.0, ${k}Seed * 11.0);\n" +
    "    float n = 0.0; float amp = 0.5; float tot = 0.0;\n" +
    "    for (int i = 0; i < 10; i++) {\n" +
    "        if (float(i) >= ${k}Oct) { break; }\n" +
    "        float fi = float(i);\n" +
    "        vec2 bo = vec2(0.0);\n" +
    "        if (${k}Boil > 0.5) {\n" +
    "            float ang = hash11(fi * 7.13 + ${k}Seed) * 6.2831 + uTime * ${k}BSpd * (0.3 + ${k}BDet * fi * 0.35);\n" +
    "            bo = vec2(cos(ang), sin(ang)) * (0.6 + 0.2 * fi);\n" +
    "        }\n" +
    "        n += amp * vnoise(q + bo + vec2(fi * 17.3, fi * 9.1));\n" +
    "        tot += amp; amp *= 0.5; q *= 2.0;\n" +
    "    }\n" +
    "    n = clamp(n / max(tot, 0.0001) * 1.35 - 0.175, 0.0, 1.0);\n"

/** BuiltinsSapphire5.swift:43 */
internal fun s5NoiseProps(k: String, seed: Float): List<PropDef> = listOf(
    PropDef(k + "Freq", "Frequency", 0.01f, 30f, 2f, 2),
    PropDef(k + "FreqX", "Frequency Rel X", 0.01f, 5f, 0.4f, 2),
    PropDef(k + "Oct", "Octaves", 1f, 10f, 8f, 0),
    PropDef(k + "Seed", "Seed", 0f, 100f, seed, 3),
    PropDef(k + "Boil", "Boiling Mode", 0f, 1f, 0f, 0, listOf("Off", "On")),
    PropDef(k + "BDet", "Boil Details", 0f, 1f, 0.55f, 2),
    PropDef(k + "BSpd", "Boil Speed", -10f, 10f, 1f, 2),
    PropDef(k + "ShX", "Shift Start X", -50f, 50f, 0f, 2),
    PropDef(k + "ShY", "Shift Start Y", -50f, 50f, 0f, 2),
    PropDef(k + "SpX", "Shift Speed X", -10f, 10f, 0.5f, 2),
    PropDef(k + "SpY", "Shift Speed Y", -10f, 10f, 0.5f, 2))

/** BuiltinsSapphire5.swift:56 */
internal fun s5cat(vararg parts: List<PropDef>): List<PropDef> = parts.flatMap { it }

/** BuiltinsSapphire5.swift:57 */
internal val s5CombineOpts = listOf("Clouds Only", "Mult", "Add", "Screen", "Difference", "Overlay")

/** BuiltinsSapphire5.swift:58 */
internal fun s5Combine(k: String): String =
    "    vec4 s0 = src(uv);\n" +
    "    vec3 bg = (s0.a > 0.0001 ? s0.rgb / s0.a : vec3(0.0)) * ${k}BgBr;\n" +
    "    vec3 res = cl;\n" +
    "    if (${k}Comb > 4.5) { res = mix(2.0 * bg * cl, 1.0 - 2.0 * (1.0 - bg) * (1.0 - cl), step(0.5, bg)); }\n" +
    "    else if (${k}Comb > 3.5) { res = abs(bg - cl); }\n" +
    "    else if (${k}Comb > 2.5) { res = 1.0 - (1.0 - bg) * (1.0 - cl); }\n" +
    "    else if (${k}Comb > 1.5) { res = bg + cl; }\n" +
    "    else if (${k}Comb > 0.5) { res = bg * cl; }\n" +
    "    float oa = ${k}OutOp > 0.5 ? s0.a : 1.0;\n" +
    "    vec4 o = vec4(max(res, vec3(0.0)) * oa, oa);\n"

/** BuiltinsSapphire5.swift:72 */
internal fun s5CombineProps(k: String): List<PropDef> = listOf(
    PropDef(k + "BgBr", "Bg Brightness", 0f, 4f, 1f, 2),
    PropDef(k + "Comb", "Combine", 0f, 5f, 0f, 0, s5CombineOpts),
    PropDef(k + "OutOp", "Output Opacity", 0f, 1f, 1f, 0, listOf("All Opaque", "Copy From Input")))
