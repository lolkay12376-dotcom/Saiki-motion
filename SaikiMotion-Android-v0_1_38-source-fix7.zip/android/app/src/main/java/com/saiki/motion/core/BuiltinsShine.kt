@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsShine.swift — "Shine": volumetric light rays.
// The shine EffectDef comes from the generated catalog (core/Builtins.kt) and the runtime camera
// resolver (enum ShineCam) is ported in core/ShineCam.kt; the shinePresets table and the
// dashboard live in ui/ShineDashboard.kt. This twin keeps only the shOnOff labels.

/** BuiltinsShine.swift:14 */
val shOnOff = listOf("Off", "On")
