@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsUniverse.swift — Universe ShrinkRay (tilt-shift miniature),
// Universe Noir and BCC+ Chroma Bands. EffectDefs come from the generated catalog
// (core/Builtins.kt); this twin keeps the ShrinkRay patch-mode labels the dashboard reuses.

/** BuiltinsUniverse.swift:11 */
val universePatchModes = listOf("Off", "Focus", "Blur")
