@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsUniverse2.swift — Universe Glow (U_Glow), Universe Prism
// Displacement and uni.Point Zoom (the UniversePreset struct + dashboard presets already live in
// core/UniversePresets.kt, which also covers the UniversePresets extension at BuiltinsUniverse2.swift:274).
// EffectDefs come from the generated catalog (core/Builtins.kt); this twin keeps the
// ugB/upWrap/upMap GLSL snippet builders the Swift file exports.

/** BuiltinsUniverse2.swift:14 — input-channel selection expression for a vec4 `c`. */
internal fun ugB(c: String): String =
    "(ugCh < 0.5 ? $c.r : ugCh < 1.5 ? $c.g : ugCh < 2.5 ? $c.b : ugCh < 3.5 ? $c.a : ugCh < 4.5 ? max(max($c.r, $c.g), $c.b) : ugCh < 5.5 ? 0.5 * (max(max($c.r, $c.g), $c.b) + min(min($c.r, $c.g), $c.b)) : luma($c.rgb))"

/** BuiltinsUniverse2.swift:17 */
internal fun upWrap(p: String): String =
    "$p = upWrap > 2.5 ? clamp($p, 0.0, 1.0) : (upWrap > 1.5 ? 1.0 - abs(1.0 - mod($p, 2.0)) : (upWrap > 0.5 ? fract($p) : $p));\n"

/** BuiltinsUniverse2.swift:20 — samples the displacement map at `pos` into `t` (vec4) and `v` (float). */
internal fun upMap(pos: String): String =
    "    t = uHas0 > 0.5 ? in0($pos) : src($pos);\n" +
    "        v = luma(t.rgb / max(t.a, 0.0001));\n" +
    "        if (upSrc > 0.5 && upSrc < 1.5) { v = mix(0.5, v, t.a); } else if (upSrc > 1.5) { v = luma(t.rgb); }\n" +
    "        v = pow(clamp((v - upBlack) / max(upWhite - upBlack, 0.001), 0.0, 1.0), 1.0 / max(upGam, 0.05));\n"
