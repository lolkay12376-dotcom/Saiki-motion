@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsUniverse3.swift — uni.Glo Fi II, uni.Ecto, uni.Carousel.
// EffectDefs come from the generated catalog (core/Builtins.kt); the dashboard preset tables
// (gofiSchemes/ectoColors/ectoLooks + UniversePresets extension) live in core/UniversePresets.kt
// (Sources/BuiltinsUniverse3.swift:311). This twin keeps only the GLSL snippet builders
// (vf/blendCode/fractal) the Swift file exports for reuse.

/** BuiltinsUniverse3.swift:31 — 0xAARRGGBB colour as a GLSL vec3 literal. */
internal fun vf(c: Long): String =
    "vec3(" + "%.3f".format(((c shr 16) and 255).toFloat() / 255f) + ", " + "%.3f".format(((c shr 8) and 255).toFloat() / 255f) + ", " + "%.3f".format((c and 255).toFloat() / 255f) + ")"

/** BuiltinsUniverse3.swift:35 */
internal val universe3BlendOpts = listOf("Normal", "Add", "Screen", "Multiply", "Difference")

/** BuiltinsUniverse3.swift:36 — GLSL: `vec3 out` = a blended with b by float `m`. */
internal fun blendCode(m: String, a: String, b: String, out: String): String =
    "    vec3 $out = $b;\n" +
    "    if ($m > 3.5) { $out = abs($a - $b); } else if ($m > 2.5) { $out = $a * $b; }\n" +
    "    else if ($m > 1.5) { $out = 1.0 - (1.0 - $a) * (1.0 - $b); } else if ($m > 0.5) { $out = $a + $b; }\n"

/** BuiltinsUniverse3.swift:44 — GLSL: declares `float out` = fractal value (0..1) at point expression p. */
internal fun fractalGlsl(out: String, p: String): String =
    "    float $out = 0.0; float ${out}_a = 0.5; float ${out}_t = 0.0; vec2 ${out}_q = $p;\n" +
    "        for (int i = 0; i < 10; i++) {\n" +
    "            if (float(i) >= ecCx) { break; }\n" +
    "            $out += ${out}_a * vnoise(${out}_q); ${out}_t += ${out}_a; ${out}_a *= mix(0.35, 0.65, ecDet / 300.0); ${out}_q = ${out}_q * 2.03 + 5.1;\n" +
    "        }\n" +
    "        $out = $out / max(${out}_t, 0.0001);\n" +
    "        float ${out}_r = 1.0 - abs(2.0 * $out - 1.0);\n" +
    "        $out = ecPat < 0.5 ? $out : (ecPat < 1.5 ? 0.5 + 0.5 * sin($out * 12.0) : (ecPat < 2.5 ? ${out}_r : ${out}_r * ${out}_r));\n"
