@file:Suppress("unused", "FunctionName", "MemberVisibilityCanBePrivate")

package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsUniverse4.swift — uni.Edge Glow, uni.HUD Components,
// Checkerboard, Grid, Depth Map (universe5Fx in the same file) and the UniversePresets.edge/.hud
// dashboard tables (those live in core/UniversePresets.kt). EffectDefs come from the generated
// catalog (core/Builtins.kt); this twin keeps the hudTypes/hudAnims/blendNames labels and the
// hudElemGLSL/blendGLSL/sizeProps/cellGLSL snippet builders the Swift file exports.

/** BuiltinsUniverse4.swift:5 */
val hudTypes = listOf("None", "Arc", "Square Outline", "Chevron", "Triangle Outline", "Target Brackets", "Crosshair", "Hex Outline", "Radar Ticks", "Dot Grid", "Pointer")

/** BuiltinsUniverse4.swift:6 */
val hudAnims = listOf("None", "Oscillate Horizontal", "Oscillate Vertical", "Orbit 2D", "Rotate", "Pulse Scale")

/** BuiltinsUniverse4.swift:7 — one HUD element's draw code (k = 1..4; element k links to element 1 when Link is on). */
internal fun hudElemGLSL(k: Int): String {
    val P = "h$k"
    fun L(n: String): String = if (k == 1) "$P$n" else "(${P}Link > 0.5 ? h1$n : $P$n)"
    return "    if (${P}Type > 0.5) {\n" +
        "        vec2 pos = vec2(${L("PX")}, ${L("PY")}) * fxs; float rz = ${L("RZ")}; float sc = ${L("Sc")};\n" +
        "        float an = ${L("Anim")}; float at = uTime * ${L("Spd")} * hMS; float amp = ${L("Amp")}; float orad = ${L("Orb")};\n" +
        "        vec2 off = vec2(0.0);\n" +
        "        if (an > 0.5 && an < 1.5) { off.x = sin(at * 3.0) * amp * 20.0 * fxs; }\n" +
        "        else if (an < 2.5 && an > 1.5) { off.y = sin(at * 3.0) * amp * 20.0 * fxs; }\n" +
        "        else if (an < 3.5 && an > 2.5) { off = vec2(cos(at * 2.0), sin(at * 2.0)) * orad * 10.0 * fxs; }\n" +
        "        else if (an < 4.5 && an > 3.5) { rz += at * 60.0; }\n" +
        "        else if (an > 4.5) { sc *= 1.0 + 0.15 * amp * sin(at * 3.0); }\n" +
        "        float R = ${P}Rad * fxs; float sw = ${P}SW * fxs; float seg = ${P}Seg;\n" +
        "        int nc = int(${P}Cn);\n" +
        "        for (int i = 0; i < 100; i++) {\n" +
        "            if (i > nc) { break; }\n" +
        "            float ci = float(i);\n" +
        "            vec2 rnd = vec2(hash21(vec2(ci, ${P}RS + hSeed)), hash21(vec2(ci + 7.0, ${P}RS + hSeed + 3.0))) - 0.5;\n" +
        "            vec2 q = p0 - pos - off - vec2(${P}CX, ${P}CY) * fxs * ci - rnd * ${P}RO * 10.0 * fxs;\n" +
        "            float ang = radians(rz + ${P}CR * ci + rnd.x * ${P}RR * 3.6);\n" +
        "            float s = max(sc * (1.0 + ${P}CS * ci / 100.0) * (1.0 + rnd.y * ${P}RSc / 100.0), 0.02);\n" +
        "            float ca = cos(ang), sa = sin(ang);\n" +
        "            q = vec2(ca * q.x + sa * q.y, -sa * q.x + ca * q.y) / s;\n" +
        "            float d = 1000.0; float t = ${P}Type; vec2 aq = abs(q);\n" +
        "            if (t < 1.5) { d = abs(length(q) - R) - sw * 0.5; float dg = mod(degrees(atan(q.y, q.x)) + 360.0, 360.0); if (dg > seg) { d = 1000.0; } }\n" +
        "            else if (t < 2.5) { d = abs(max(aq.x, aq.y) - R) - sw * 0.5; }\n" +
        "            else if (t < 3.5) { d = max(abs(q.y + aq.x * 0.6 - R * 0.3) * 0.857 - sw * 0.5, aq.x - R); }\n" +
        "            else if (t < 4.5) { d = abs(max(aq.x * 0.866 + q.y * 0.5, -q.y) - R * 0.5) - sw * 0.5; }\n" +
        "            else if (t < 5.5) { d = abs(max(aq.x, aq.y) - R) - sw * 0.5; if (min(aq.x, aq.y) < R * 0.5) { d = 1000.0; } }\n" +
        "            else if (t < 6.5) { d = min(max(abs(q.y) - sw * 0.5, abs(aq.x - R * 0.6) - R * 0.4), max(abs(q.x) - sw * 0.5, abs(q.y - R * 0.6) - R * 0.4)); }\n" +
        "            else if (t < 7.5) { d = abs(max(aq.x * 0.866 + aq.y * 0.5, aq.y) - R * 0.866) - sw * 0.5; }\n" +
        "            else if (t < 8.5) { float a2 = atan(q.y, q.x); float da = abs(fract(a2 * 36.0 / 6.2831853 + 0.5) - 0.5) * 6.2831853 / 36.0 * length(q); d = max(da - sw * 0.5, abs(length(q) - (R - 10.0)) - 10.0); }\n" +
        "            else if (t < 9.5) { float cs = max(R * 0.25, 2.0); d = length(fract(q / cs + 0.5) - 0.5) * cs - sw * 0.8; d = max(d, max(aq.x, aq.y) - R); }\n" +
        "            else { d = max(aq.x * 0.866 + q.y * 0.5, -q.y) - R * 0.25; }\n" +
        "            d *= s;\n" +
        "            float fade = clamp(1.0 - ci * ${P}CF / 100.0, 0.0, 1.0) * clamp(1.0 + rnd.x * ${P}RO2 / 50.0, 0.0, 1.0) * ${P}Op / 100.0;\n" +
        "            float a = (1.0 - smoothstep(-0.5, 1.0, d)) * fade;\n" +
        "            float gl = exp(-max(d, 0.0) / max(hGR * 0.25 * fxs, 1.0)) * 0.5 * fade * hGI * hGM / 100.0;\n" +
        "            hud += ${P}C.rgb * a + mix(${P}C.rgb, hGC.rgb, hGCM / 100.0) * gl;\n" +
        "        }\n" +
        "    }\n"
}

/** BuiltinsUniverse4.swift:189 */
internal val universe4BlendNames = listOf("None", "Normal", "Add", "Screen", "Multiply", "Overlay", "Difference", "Soft Light")

/** BuiltinsUniverse4.swift:191 — combines base `B` and top `T` (vec3) by mode variable `m` into `bl`. */
internal fun blendGLSL(m: String): String =
    "    vec3 bl = T;\n" +
    "    if ($m > 6.5) { bl = (1.0 - 2.0 * T) * B * B + 2.0 * T * B; }\n" +
    "    else if ($m > 5.5) { bl = abs(B - T); }\n" +
    "    else if ($m > 4.5) { bl = mix(2.0 * B * T, 1.0 - 2.0 * (1.0 - B) * (1.0 - T), step(0.5, B)); }\n" +
    "    else if ($m > 3.5) { bl = B * T; }\n" +
    "    else if ($m > 2.5) { bl = 1.0 - (1.0 - B) * (1.0 - T); }\n" +
    "    else if ($m > 1.5) { bl = min(B + T, vec3(1.0)); }\n"

/** BuiltinsUniverse4.swift:201 */
internal fun sizeProps(k: String): List<PropDef> = listOf(
    PropDef(k + "AX", "Anchor X", -1f, 2f, 0.5f, 3), PropDef(k + "AY", "Anchor Y", -1f, 2f, 0.5f, 3),
    PropDef(k + "From", "Size From", 0f, 2f, 1f, 0, listOf("Corner Point", "Width Slider", "Width & Height Sliders")),
    PropDef(k + "CX", "Corner X", -1f, 2f, 0.6f, 3), PropDef(k + "CY", "Corner Y", -1f, 2f, 0.6f, 3),
    PropDef(k + "W", "Width", 1f, 2000f, 100f, 0), PropDef(k + "H", "Height", 1f, 2000f, 100f, 0))

/** BuiltinsUniverse4.swift:206 */
internal fun cellGLSL(k: String): String =
    "    vec2 A = vec2(${k}AX, ${k}AY) * uRes; vec2 pp = uv * uRes;\n" +
    "    vec2 sz = ${k}From < 0.5 ? abs(vec2(${k}CX, ${k}CY) - vec2(${k}AX, ${k}AY)) * uRes : (${k}From < 1.5 ? vec2(${k}W) : vec2(${k}W, ${k}H));\n" +
    "    sz = max(sz, vec2(1.0));\n" +
    "    vec2 t = (pp - A) / sz; vec2 fr = fract(t);\n" +
    "    float de = min(min(fr.x, 1.0 - fr.x) * sz.x, min(fr.y, 1.0 - fr.y) * sz.y);\n"
