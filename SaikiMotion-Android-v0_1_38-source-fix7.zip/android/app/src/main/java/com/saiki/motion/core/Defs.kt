package com.saiki.motion.core

// Port of Sources/Model/Project.swift `enum Defs` (parameter tables). Order matters: panels index into these.
/** One animatable parameter definition. */
class PropDef(val key: String, val label: String, val min: Float, val max: Float, var def: Float,
              var dec: Int = 2, var options: List<String>? = null, var inf: Boolean = false, var span: Float = 1f)

/** One color parameter of an effect (stored as four _r/_g/_b/_a tracks). */
class ColorParam(val key: String, val label: String, var def: Int)

object Defs {
    val shapeRound = PropDef("shapeRound", "Roundness", 0f, 1f, 0.12f, 2)
    val shapeThick = PropDef("shapeThick", "Thickness", 0.05f, 0.95f, 0.3f, 2)
    val transform = listOf(
        PropDef("x", "Position X", -4f, 4f, 0f, 3, null, true, 4f),
        PropDef("y", "Position Y", -4f, 4f, 0f, 3, null, true, 4f),
        PropDef("scale", "Scale", 0.02f, 1e9f, 1f, 3, null, true, 2f),
        PropDef("opacity", "Opacity", 0f, 1f, 1f, 2),
        PropDef("rotZ", "Rotation Z", -360f, 360f, 0f, 1))
    val scaleXY = listOf(
        PropDef("scaleX", "Scale X", 0.02f, 1e9f, 1f, 3, null, true, 2f),
        PropDef("scaleY", "Scale Y", 0.02f, 1e9f, 1f, 3, null, true, 2f))
    val scaleZ = PropDef("scaleZ", "Scale Z (depth)", 0.02f, 1e9f, 1f, 3, null, true, 2f)
    val pos3d = listOf(PropDef("z", "Position Z", -100000f, 100000f, 0f, 3, null, true, 4f))
    val rot3d = listOf(
        PropDef("rotX", "Rotation X", -360f, 360f, 0f, 1),
        PropDef("rotY", "Rotation Y", -360f, 360f, 0f, 1))
    val anchor = listOf(
        PropDef("anchorX", "Anchor X", 0f, 100f, 50f, 1),
        PropDef("anchorY", "Anchor Y", 0f, 100f, 50f, 1),
        PropDef("anchorZ", "Anchor Z (3D)", -100f, 100f, 0f, 1))
    val text = listOf(
        PropDef("strokeW", "Stroke width", 0f, 0.3f, 0f, 3),
        PropDef("borderW", "Border width", 0f, 0.5f, 0f, 3),
        PropDef("borderPad", "Border padding", 0f, 0.6f, 0.12f, 3),
        PropDef("spacing", "Letter spacing", 0f, 0.5f, 0f, 3),
        PropDef("fontSize", "Font size", 0.05f, 4f, 0.45f, 3),
        PropDef("shadowX", "Shadow offset X", -0.2f, 0.2f, 0.03f, 3),
        PropDef("shadowY", "Shadow offset Y", -0.2f, 0.2f, 0.03f, 3),
        PropDef("shadowBlur", "Shadow blur", 0f, 0.4f, 0.06f, 3),
        PropDef("stroke2W", "Second stroke width", 0f, 0.3f, 0f, 3),
        PropDef("borderRadius", "Border corner radius", 0f, 0.3f, 0.06f, 3))
    val audio = listOf(PropDef("volume", "Volume", 0f, 1f, 1f, 2))
    val camera = listOf(PropDef("fov", "Field of view", 15f, 120f, 55f, 0))
    val flare = listOf(
        PropDef("fIntensity", "Intensity", 0f, 4f, 1f, 2),
        PropDef("fAxis", "Axis length", 0f, 2f, 1f, 2))
    val blur = listOf(
        PropDef("mbSamples", "Samples", 2f, 24f, 8f, 0),
        PropDef("mbAmount", "Blur strength", 0f, 4f, 1f, 2))
}
