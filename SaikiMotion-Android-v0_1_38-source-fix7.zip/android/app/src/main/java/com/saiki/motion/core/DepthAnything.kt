@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.core

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer
import java.util.concurrent.locks.ReentrantLock
import java.util.zip.Inflater
import kotlin.concurrent.withLock
import kotlin.math.max
import kotlin.math.min

// Port of Sources/Effects/DepthAnything.swift — in-app install + on-device inference for
// Depth Anything V2 (Small / Large). iOS uses Apple Core ML builds; Android runs the same
// models' ONNX twins from onnx-community (small fp32 ≈99 MB, large fp16 ≈668 MB) through
// ONNX Runtime, with the identical kind titles/details, install flow and progress strings.

enum class DepthModelKind(val raw: String, val title: String, val detail: String) {
    small("small", "Small", "≈50 MB · fast · Apache-2.0"),
    large("large", "Large", "≈620 MB · best detail · non-commercial license (CC-BY-NC-4.0)");

    companion object { fun fromRaw(r: String): DepthModelKind = entries.firstOrNull { it.raw == r } ?: small }
}

object DepthAnything {
    // ONNX twins of the iOS Core ML builds (same weights; iOS smallBase/largeZip kept in comments).
    // iOS small: huggingface.co/apple/coreml-depth-anything-v2-small/.../DepthAnythingV2SmallF16.mlpackage/
    // iOS large: huggingface.co/LloydAI/DepthAnything_v2-Large-CoreML/.../DepthAnything_v2-Large.mlpackage.zip
    private const val smallOnnx = "https://huggingface.co/onnx-community/depth-anything-v2-small/resolve/main/onnx/model.onnx"
    private const val largeOnnx = "https://huggingface.co/onnx-community/depth-anything-v2-large/resolve/main/onnx/model_fp16.onnx"

    private val main = Handler(Looper.getMainLooper())
    private val lock = ReentrantLock()

    var selected: DepthModelKind
        get() = DepthModelKind.fromRaw(Prefs.getString("depthModel", null) ?: "")
        set(v) { Prefs.setString("depthModel", v.raw) }

    fun dir(): File {
        val d = File(Paths.appContext.filesDir, "DepthAnything")
        if (!d.exists()) d.mkdirs()
        return d
    }

    /** DepthAnything.swift:44 compiled(k) — the installed-model marker file ("<kind>.onnx"). */
    fun compiled(k: DepthModelKind): File = File(dir(), "${k.raw}.onnx")

    fun isInstalled(k: DepthModelKind): Boolean = compiled(k).length() > 50_000_000

    fun remove(k: DepthModelKind) {
        lock.withLock { sessions.remove(k)?.close() }
        compiled(k).delete()
    }

    @Volatile private var active: Downloader? = null

    private fun fail(m: String): Exception = Exception(m)

    // MARK: install
    /** progress(0...1, status) and done(error) are called on the main thread. */
    fun install(k: DepthModelKind, progress: (Double, String) -> Unit, done: (String?) -> Unit) {
        val work = File(dir(), "tmp_${k.raw}")
        work.deleteRecursively()
        work.mkdirs()
        fun finish(e: String?) {
            active = null
            work.deleteRecursively()
            main.post { done(e) }
        }
        val dl = Downloader()
        active = dl
        val url = URL(if (k == DepthModelKind.small) smallOnnx else largeOnnx)
        val label = if (k == DepthModelKind.small) "Downloading Depth Anything Small…" else "Downloading Depth Anything Large…"
        dl.start(url, { f -> main.post { progress(f * 0.95, label) } }) { r ->
            val tmp = r.getOrNull()
            if (tmp == null) { finish(r.exceptionOrNull()?.message ?: "download failed"); return@start }
            main.post { progress(0.97, "Optimizing for this device…") }
            Thread {
                try {
                    val dst = compiled(k)
                    dst.delete()
                    if (!tmp.renameTo(dst)) throw fail("Could not store the model")
                    lock.withLock { sessions.remove(k)?.close() }
                    finish(null)
                } catch (e: Exception) { finish(e.message) }
            }.start()
        }
    }

    // ---- inference (ORT twin of VNCoreMLRequest; iOS DepthAnything.swift:109-146) ----------
    private val sessions = HashMap<DepthModelKind, OrtSession>()

    private fun session(k: DepthModelKind): OrtSession? = lock.withLock {
        sessions[k]?.let { return it }
        if (!isInstalled(k)) return null
        return try {
            val env = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
            val s = env.createSession(compiled(k).path, opts)
            sessions[k] = s
            s
        } catch (_: Exception) { null }
    }

    /** Returns a grayscale depth image (white = near) the size of `image` (long side capped at 2048). */
    fun depth(image: Bitmap, kind: DepthModelKind, done: (Bitmap?, String?) -> Unit) {
        Thread {
            val sess = session(kind)
            if (sess == null) { main.post { done(null, "Model not installed.") }; return@Thread }
            try {
                val norm = normalized(image)
                val W = norm.width; val H = norm.height
                // input: 518-long-side, aspect-preserving, zero-padded to a multiple of 14 (the model's grid)
                val m = 518
                val sc = m.toFloat() / max(W, H).toFloat()
                var nw = max(1, (W * sc).toInt()); var nh = max(1, (H * sc).toInt())
                nw = nw / 14 * 14; nh = nh / 14 * 14
                nw = max(14, nw); nh = max(14, nh)
                val plane = nw * nh
                val fp = FloatArray(3 * plane)   // zero padded, /255, RGB planes
                val px = IntArray(W * H)
                norm.getPixels(px, 0, W, 0, 0, W, H)
                for (y in 0 until nh) {
                    val fy = min(H - 1f, (y + 0.5f) * H / nh.toFloat() - 0.5f).coerceAtLeast(0f)
                    val y0 = fy.toInt(); val y1 = min(H - 1, y0 + 1); val ty = fy - y0
                    for (x in 0 until nw) {
                        val fx = min(W - 1f, (x + 0.5f) * W / nw.toFloat() - 0.5f).coerceAtLeast(0f)
                        val x0 = fx.toInt(); val x1 = min(W - 1, x0 + 1); val tx = fx - x0
                        for (c in 0 until 3) {
                            val p00 = px[y0 * W + x0]; val p01 = px[y0 * W + x1]
                            val p10 = px[y1 * W + x0]; val p11 = px[y1 * W + x1]
                            fun ch(p: Int): Float = when (c) { 0 -> (p shr 16 and 0xFF) / 255f; 1 -> (p shr 8 and 0xFF) / 255f; else -> (p and 0xFF) / 255f }
                            val a = ch(p00) * (1 - tx) + ch(p01) * tx
                            val b = ch(p10) * (1 - tx) + ch(p11) * tx
                            fp[c * plane + y * nw + x] = a * (1 - ty) + b * ty
                        }
                    }
                }
                val env = OrtEnvironment.getEnvironment()
                val shape = longArrayOf(1, 3, nh.toLong(), nw.toLong())
                val vals: FloatArray
                OnnxTensor.createTensor(env, FloatBuffer.wrap(fp), shape).use { input ->
                    sess.run(mapOf(sess.inputNames.first() to input)).use { out ->
                        vals = flatten(out[0].value, plane)
                    }
                }
                if (vals.size < plane) throw fail("Unexpected model output.")
                // model output is nh×nw; scale back to the normalized image size
                val w2 = norm.width; val h2 = norm.height
                var lo = Float.MAX_VALUE; var hi = -Float.MAX_VALUE
                for (i in 0 until plane) { if (vals[i] < lo) lo = vals[i]; if (vals[i] > hi) hi = vals[i] }
                val scl = 255f / max(hi - lo, 1e-6f)
                val gray = IntArray(w2 * h2)
                for (y in 0 until h2) {
                    val fy = min(plane / nw - 1f, (y + 0.5f) * nh / h2.toFloat() - 0.5f).coerceAtLeast(0f)
                    val y0 = fy.toInt(); val y1 = min(nh - 1, y0 + 1); val ty = fy - y0
                    for (x in 0 until w2) {
                        val fx = min(nw - 1f, (x + 0.5f) * nw / w2.toFloat() - 0.5f).coerceAtLeast(0f)
                        val x0 = fx.toInt(); val x1 = min(nw - 1, x0 + 1); val tx = fx - x0
                        val a = vals[y0 * nw + x0] * (1 - tx) + vals[y0 * nw + x1] * tx
                        val b = vals[y1 * nw + x0] * (1 - tx) + vals[y1 * nw + x1] * tx
                        val g = ((a * (1 - ty) + b * ty - lo) * scl).toInt().coerceIn(0, 255)
                        gray[y * w2 + x] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
                    }
                }
                val bmp = Bitmap.createBitmap(gray, w2, h2, Bitmap.Config.ARGB_8888)
                main.post { done(bmp, null) }
            } catch (e: Exception) {
                main.post { done(null, e.message ?: "Inference failed.") }
            }
        }.start()
    }

    /** [1][1][H][W] (or flatter) nested output → FloatArray. */
    private fun flatten(v: Any, expect: Int): FloatArray {
        val out = FloatArray(expect)
        fun walk(a: Any?, dst: FloatArray, idx: Int): Int {
            when (a) {
                is Float -> if (idx < dst.size) dst[idx] = a
                is Array<*> -> { var i = idx; for (e in a) i = walk(e, dst, i); return i }
                is FloatArray -> { for (i in a.indices) if (idx + i < dst.size) dst[idx + i] = a[i]; return idx + a.size }
                else -> {}
            }
            return idx + 1
        }
        walk(v, out, 0)
        return out
    }

    /** DepthAnything.swift:163 — long side capped at 2048, scale-1 render of the source. */
    private fun normalized(img: Bitmap): Bitmap {
        val m = 2048f
        val w = img.width.toFloat(); val h = img.height.toFloat()
        val s = minOf(1f, m / maxOf(w, h))
        val sz = intArrayOf(maxOf(1, Math.round(w * s)), maxOf(1, Math.round(h * s)))
        val out = Bitmap.createBitmap(sz[0], sz[1], Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(img, null, android.graphics.RectF(0f, 0f, sz[0].toFloat(), sz[1].toFloat()), null)
        return out
    }

    // MARK: minimal zip extractor (stored + deflate, no zip64) — DepthAnything.swift:174
    // (kept for opening zipped ONNX bundles a user may side-load)
    private fun u16(d: ByteArray, o: Int): Int = (d[o].toInt() and 0xFF) or ((d[o + 1].toInt() and 0xFF) shl 8)
    private fun u32(d: ByteArray, o: Int): Int = u16(d, o) or (u16(d, o + 2) shl 16)

    fun unzip(zip: File, out: File) {
        RandomAccessFile(zip, "r").use { fh ->
            val size = fh.length().toInt()
            val tailLen = minOf(size, 70000)
            fh.seek((size - tailLen).toLong())
            val tail = ByteArray(tailLen); fh.readFully(tail)
            var e = tail.size - 22
            while (e >= 0 && u32(tail, e) != 0x06054b50) e -= 1
            check(e >= 0) { "Bad zip file." }
            val count = u16(tail, e + 10); val cdSize = u32(tail, e + 12); val cdOff = u32(tail, e + 16)
            check(cdOff != -1) { "Zip64 archives are not supported." }
            fh.seek(cdOff.toLong())
            val cd = ByteArray(cdSize); fh.readFully(cd)
            var p = 0
            repeat(count) {
                if (p + 46 > cd.size || u32(cd, p) != 0x02014b50) return@repeat
                val method = u16(cd, p + 10); val cs = u32(cd, p + 20)
                val nl = u16(cd, p + 28); val el = u16(cd, p + 30); val cl = u16(cd, p + 32); val lo = u32(cd, p + 42)
                val name = String(cd, p + 46, nl, Charsets.UTF_8)
                p += 46 + nl + el + cl
                if (name.endsWith("/") || name.startsWith("__MACOSX") || name.contains("..")) return@repeat
                check(cs != -1) { "Zip64 archives are not supported." }
                fh.seek(lo.toLong())
                val lh = ByteArray(30); fh.readFully(lh)
                check(lh.size == 30 && u32(lh, 0) == 0x04034b50) { "Bad zip entry." }
                val dataOff = lo + 30 + u16(lh, 26) + u16(lh, 28)
                val dst = File(out, name)
                dst.parentFile?.mkdirs()
                dst.createNewFile()
                RandomAccessFile(dst, "rw").use { oh ->
                    fh.seek(dataOff.toLong())
                    if (method == 0) {
                        var left = cs
                        val buf = ByteArray(1 shl 20)
                        while (left > 0) {
                            val c = fh.read(buf, 0, minOf(left, buf.size))
                            if (c <= 0) break
                            oh.write(buf, 0, c); left -= c
                        }
                    } else if (method == 8) {
                        inflate(fh, cs, oh)
                    } else throw fail("Unsupported zip compression.")
                }
            }
        }
    }

    private fun inflate(fh: RandomAccessFile, compSize: Int, out: RandomAccessFile) {
        val inf = Inflater(true)
        try {
            var left = compSize
            val buf = ByteArray(1 shl 20)
            while (left > 0 && !inf.finished()) {
                val c = fh.read(buf, 0, minOf(left, buf.size))
                if (c <= 0) break
                inf.setInput(buf, 0, c)
                val o = ByteArray(1 shl 20)
                while (!inf.needsInput() && !inf.finished()) {
                    val n = inf.inflate(o)
                    if (n > 0) out.write(o, 0, n)
                }
                left -= c
            }
        } finally { inf.end() }
    }
}

/** One download at a time with progress (HttpURLConnection; the URLSession delegate twin). */
class Downloader {
    fun start(url: URL, progress: (Double) -> Unit, completion: (Result<File>) -> Unit) {
        Thread {
            try {
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 30000
                conn.readTimeout = 30000
                conn.setRequestProperty("User-Agent", "SaikiMotion/1.0")
                val code = conn.responseCode
                if (code >= 400) {
                    conn.disconnect()
                    completion(Result.failure(Exception("Download failed (HTTP $code).")))
                    return@Thread
                }
                val total = conn.contentLengthLong
                val keep = File.createTempFile("dl", ".bin", Paths.appContext.cacheDir)
                FileOutputStream(keep).use { os ->
                    val buf = ByteArray(1 shl 16)
                    var written = 0L
                    while (true) {
                        val c = conn.inputStream.read(buf)
                        if (c < 0) break
                        os.write(buf, 0, c); written += c
                        if (total > 0) progress(written.toDouble() / total)
                    }
                }
                conn.disconnect()
                completion(Result.success(keep))
            } catch (e: Exception) { completion(Result.failure(e)) }
        }.start()
    }
}
