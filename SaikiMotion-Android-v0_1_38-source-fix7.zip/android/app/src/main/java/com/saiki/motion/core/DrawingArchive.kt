@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.util.UUID

// Port of Sources/Tools/DrawingArchive.swift — the `.saikidrawing` single-file bundle for
// Drawing Editor artworks.
//
//   "SAIKIDRW1\n"                      10-byte magic
//   u32  json length (LE)              JSON-encoded DrawItem
//   u32  file count
//   per file: u16 name length, name (UTF-8, e.g. "<layerId>.png"), u64 data length, data
//
// Layer PNGs are keyed by layer id, so import only has to remap ids.

object DrawingArchive {
    const val fileExtension = "saikidrawing"
    private val magic = "SAIKIDRW1\n".toByteArray()

    private fun le(v: Long, n: Int): ByteArray = ByteArray(n) { i -> ((v shr (8 * i)) and 0xFF).toByte() }

    private fun RandomAccessFile.readExact(n: Int): ByteArray? {
        if (n == 0) return ByteArray(0)
        if (n < 0) return null
        val d = ByteArray(n)
        var off = 0
        while (off < n) {
            val c = read(d, off, n - off)
            if (c < 0) return null
            off += c
        }
        return d
    }

    private fun num(d: ByteArray): Long {
        var v = 0L
        for (i in d.indices) v = v or ((d[i].toLong() and 0xFF) shl (8 * i))
        return v
    }

    fun isArchive(url: File): Boolean {
        try {
            RandomAccessFile(url, "r").use { fh ->
                val m = fh.readExact(magic.size) ?: return false
                return m.contentEquals(magic)
            }
        } catch (_: Exception) { return false }
    }

    /// Writes "<name>.saikidrawing" into the cache folder. Returns null on failure.
    fun export(id: String): File? {
        val item = DrawStore.item(id) ?: return null
        if (item.isFolder) return null
        val json = item.toJson().toString().toByteArray()
        val safe = item.name.replace("/", "-")
        val out = File(Paths.appContext.cacheDir, "$safe.$fileExtension")
        out.delete()
        try {
            RandomAccessFile(out, "rw").use { fh ->
                val files = ArrayList<Pair<String, File>>()
                for (l in item.layers) if (!l.isFolder) {
                    val u = DrawStore.layerFile(id, l.id)
                    if (u.exists()) files.add(l.id + ".png" to u)
                }
                val t = DrawStore.thumbFile(id)
                if (t.exists()) files.add("thumb.png" to t)

                fh.write(magic)
                fh.write(le(json.size.toLong(), 4)); fh.write(json)
                fh.write(le(files.size.toLong(), 4))
                for ((name, url) in files) {
                    val data = try { url.readBytes() } catch (_: Exception) { continue }
                    val nb = name.toByteArray()
                    fh.write(le(nb.size.toLong(), 2)); fh.write(nb)
                    fh.write(le(data.size.toLong(), 8)); fh.write(data)
                }
            }
            return out
        } catch (_: Exception) { return null }
    }

    /// Imports a .saikidrawing as a new artwork (fresh ids) into `parent`.
    fun importFile(url: File, parent: String?): DrawItem? {
        try {
            RandomAccessFile(url, "r").use { fh ->
                val head = fh.readExact(magic.size) ?: return null
                if (!head.contentEquals(magic)) return null
                val jl = fh.readExact(4) ?: return null
                val json = fh.readExact(num(jl).toInt()) ?: return null
                val item = try { DrawItem.fromJson(JSONObject(String(json))) } catch (_: Exception) { return null }
                val cnt = fh.readExact(4) ?: return null

                val blobs = HashMap<String, ByteArray>()
                repeat(num(cnt).toInt()) {
                    val nl = fh.readExact(2) ?: return@repeat
                    val nb = fh.readExact(num(nl).toInt()) ?: return@repeat
                    val name = String(nb, Charsets.UTF_8)
                    val dl = fh.readExact(8) ?: return@repeat
                    val data = fh.readExact(num(dl).toInt()) ?: return@repeat
                    blobs[name] = data
                }

                val newId = UUID.randomUUID().toString()
                val idMap = HashMap<String, String>()
                for (l in item.layers) idMap[l.id] = UUID.randomUUID().toString()
                for (i in item.layers.indices) {
                    val old = item.layers[i].id
                    item.layers[i].id = idMap[old]!!
                    item.layers[i].parent?.let { p -> item.layers[i].parent = idMap[p] }
                    blobs[old + ".png"]?.let { d ->
                        try { DrawStore.layerFile(newId, item.layers[i].id).writeBytes(d) } catch (_: Exception) {}
                    }
                }
                item.activeLayer?.let { a -> item.activeLayer = idMap[a] }
                blobs["thumb.png"]?.let { d ->
                    try { DrawStore.thumbFile(newId).writeBytes(d) } catch (_: Exception) {}
                }
                item.id = newId
                item.parent = parent
                item.updated = System.currentTimeMillis()
                DrawStore.upsert(item)
                return item
            }
        } catch (_: Exception) { return null }
    }
}
