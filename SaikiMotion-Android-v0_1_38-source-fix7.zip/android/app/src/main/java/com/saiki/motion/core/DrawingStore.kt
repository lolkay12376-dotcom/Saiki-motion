@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// Port of Sources/Tools/DrawingStore.swift — persistence for the Drawing Editor
// (gallery items, folders, layers).
//
// Layout on disk:  filesDir/Drawings/index.json
//                  filesDir/Drawings/<artId>/<layerId>.png   (one PNG per bitmap layer)
//                  filesDir/Drawings/<artId>/thumb.png
// Folders in the gallery are index entries only (isFolder == true).

class DrawLayerMeta(
    var id: String = UUID.randomUUID().toString(),
    var name: String = "",
    var visible: Boolean = true,
    var opacity: Float = 1f,
    var isFolder: Boolean = false,
    var parent: String? = null,
    var expanded: Boolean = true,
    var clipToBelow: Boolean? = null      // clipping mask: only shows where the layer below (the base) has paint
) {
    val isClip: Boolean get() = clipToBelow == true
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id); o.put("name", name); o.put("visible", visible); o.put("opacity", opacity.toDouble())
        o.put("isFolder", isFolder); parent?.let { o.put("parent", it) }; o.put("expanded", expanded)
        clipToBelow?.let { o.put("clipToBelow", it) }
        return o
    }
    companion object {
        fun fromJson(o: JSONObject): DrawLayerMeta = DrawLayerMeta(
            id = o.optString("id", UUID.randomUUID().toString()),
            name = o.optString("name", ""),
            visible = o.optBoolean("visible", true),
            opacity = o.optDouble("opacity", 1.0).toFloat(),
            isFolder = o.optBoolean("isFolder", false),
            parent = if (o.has("parent")) o.optString("parent") else null,
            expanded = o.optBoolean("expanded", true))
    }
}

class DrawItem(
    var id: String = UUID.randomUUID().toString(),
    var name: String = "",
    var isFolder: Boolean = false,
    var parent: String? = null,       // gallery folder id, null = root
    var w: Int = 0,
    var h: Int = 0,
    var paperWhite: Boolean = true,   // false = transparent canvas
    var updated: Long = System.currentTimeMillis(),
    var layers: MutableList<DrawLayerMeta> = ArrayList(),
    var activeLayer: String? = null
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id); o.put("name", name); o.put("isFolder", isFolder)
        parent?.let { o.put("parent", it) }
        o.put("w", w); o.put("h", h); o.put("paperWhite", paperWhite); o.put("updated", updated)
        val a = JSONArray(); for (l in layers) a.put(l.toJson()); o.put("layers", a)
        activeLayer?.let { o.put("activeLayer", it) }
        return o
    }
    companion object {
        fun fromJson(o: JSONObject): DrawItem {
            val it = DrawItem(
                id = o.optString("id", UUID.randomUUID().toString()),
                name = o.optString("name", ""),
                isFolder = o.optBoolean("isFolder", false),
                parent = if (o.has("parent")) o.optString("parent") else null,
                w = o.optInt("w", 0), h = o.optInt("h", 0),
                paperWhite = o.optBoolean("paperWhite", true),
                updated = o.optLong("updated", System.currentTimeMillis()))
            val a = o.optJSONArray("layers")
            if (a != null) for (i in 0 until a.length()) it.layers.add(DrawLayerMeta.fromJson(a.getJSONObject(i)))
            it.activeLayer = if (o.has("activeLayer")) o.optString("activeLayer") else null
            return it
        }
    }
}

object DrawPresets {
    val list: List<Triple<String, Int, Int>> = listOf(
        Triple("HD (Quality)", 1080, 2340), Triple("1:1 (2K)", 2048, 2048), Triple("3:4 (2K)", 1536, 2048),
        Triple("9:16 (2K)", 1080, 1920), Triple("X Header", 1500, 500), Triple("Chat Stamp", 370, 320),
        Triple("Vertical", 690, 4096), Triple("Postcard (JP) 300 dpi", 1181, 1748), Triple("A4 150 dpi", 1240, 1754))
    const val maxSide = 4096
    const val maxPixels = 8_400_000
    fun valid(w: Int, h: Int): Boolean =
        w >= 16 && h >= 16 && w <= maxSide && h <= maxSide && w.toLong() * h.toLong() <= maxPixels
}

object DrawStore {
    private var cache: List<DrawItem>? = null
    private val lock = Object()

    fun root(): File {
        val d = File(Paths.appContext.filesDir, "Drawings")
        if (!d.exists()) d.mkdirs()
        return d
    }
    fun dir(artId: String): File {
        val d = File(root(), artId)
        if (!d.exists()) d.mkdirs()
        return d
    }
    fun layerFile(artId: String, layerId: String): File = File(dir(artId), "$layerId.png")
    fun thumbFile(artId: String): File = File(dir(artId), "thumb.png")

    // MARK: index

    fun all(): List<DrawItem> {
        synchronized(lock) {
            cache?.let { return it }
            val url = File(root(), "index.json")
            val items = ArrayList<DrawItem>()
            try {
                val txt = url.readText()
                val a = JSONArray(txt)
                for (i in 0 until a.length()) items.add(DrawItem.fromJson(a.getJSONObject(i)))
            } catch (_: Exception) {}
            cache = items
            return items
        }
    }
    private fun write(items: List<DrawItem>) {
        synchronized(lock) { cache = items }
        val url = File(root(), "index.json")
        try {
            val a = JSONArray()
            for (it in items) a.put(it.toJson())
            val tmp = File(url.parentFile, url.name + ".tmp")
            tmp.writeText(a.toString())
            if (!tmp.renameTo(url)) { url.delete(); tmp.copyTo(url, overwrite = true); tmp.delete() }
        } catch (_: Exception) {}
    }

    fun items(parent: String?): List<DrawItem> =
        all().filter { it.parent == parent }.sortedWith { a, b ->
            if (a.isFolder != b.isFolder) { if (a.isFolder) -1 else 1 }
            else b.updated.compareTo(a.updated)
        }

    fun item(id: String): DrawItem? = all().firstOrNull { it.id == id }

    fun upsert(it: DrawItem) {
        val a = ArrayList(all())
        val i = a.indexOfFirst { x -> x.id == it.id }
        if (i >= 0) a[i] = it else a.add(it)
        write(a)
    }

    fun makeFolder(name: String, parent: String?): DrawItem {
        val f = DrawItem(name = name, isFolder = true, parent = parent)
        upsert(f)
        return f
    }

    /** Finds (or creates) a root-level gallery folder by name. */
    fun folder(named: String): DrawItem {
        all().firstOrNull { it.isFolder && it.parent == null && it.name == named }?.let { return it }
        return makeFolder(named, null)
    }

    fun newArtwork(name: String, w: Int, h: Int, parent: String?, paperWhite: Boolean = true): DrawItem {
        val it = DrawItem(name = name, isFolder = false, parent = parent)
        it.w = w; it.h = h; it.paperWhite = paperWhite
        val l = DrawLayerMeta(name = "Layer 1")
        it.layers = mutableListOf(l)
        it.activeLayer = l.id
        upsert(it)
        return it
    }

    fun rename(id: String, name: String) {
        val it = item(id) ?: return
        it.name = name; it.updated = System.currentTimeMillis(); upsert(it)
    }

    fun move(id: String, to: String?) {
        val it = item(id) ?: return
        if (it.id == to) return
        // never move a folder into itself or one of its own descendants
        var p = to
        while (p != null) { if (p == id) return; p = item(p)?.parent }
        it.parent = to; upsert(it)
    }

    fun delete(id: String) {
        val a = ArrayList(all())
        fun kill(i: String) {
            for (c in a.filter { it.parent == i }) kill(c.id)
            File(root(), i).deleteRecursively()
            a.removeAll { it.id == i }
        }
        kill(id)
        write(a)
    }

    fun duplicate(id: String) {
        val it = item(id) ?: return
        if (it.isFolder) return
        val old = it.id
        it.id = UUID.randomUUID().toString()
        it.name += " copy"
        it.updated = System.currentTimeMillis()
        for (i in it.layers.indices) {
            val oldL = it.layers[i].id
            it.layers[i].id = UUID.randomUUID().toString()
            if (it.activeLayer == oldL) it.activeLayer = it.layers[i].id
            for (j in it.layers.indices) if (it.layers[j].parent == oldL) it.layers[j].parent = it.layers[i].id
            val src = layerFile(old, oldL)
            if (src.exists()) try { src.copyTo(layerFile(it.id, it.layers[i].id)) } catch (_: Exception) {}
        }
        try { thumbFile(old).copyTo(thumbFile(it.id)) } catch (_: Exception) {}
        upsert(it)
    }

    fun count(parent: String?): Int = all().count { it.parent == parent }
    fun totalArtworks(): Int = all().count { !it.isFolder }

    fun path(id: String?): List<DrawItem> {
        val out = ArrayList<DrawItem>()
        var p = id
        while (p != null) {
            val it = item(p) ?: break
            out.add(0, it); p = it.parent
        }
        return out
    }
}

// MARK: - Import from the Anime Decomposer ----------------------------------------------

object DrawImport {
    /** Creates (or reuses) the "Anime Decomposition" gallery folder and drops the layers into a
     *  new artwork inside it, keeping the auto-groups as layer folders. */
    fun fromDecomposed(r: DecomposeResult, name: String): DrawItem {
        val folder = DrawStore.folder("Anime Decomposition")
        val art = DrawStore.newArtwork(name, r.width, r.height, folder.id, paperWhite = false)
        val groupId = HashMap<String, String>()
        val ordered = r.layers.withIndex().sortedWith { a, b ->
            val ka = a.value.order * 1000000 + a.index
            val kb = b.value.order * 1000000 + b.index
            ka.compareTo(kb)
        }
        val metas = ArrayList<DrawLayerMeta>()
        for ((_, l) in ordered) {
            var parent: String? = null
            if (l.group.isNotEmpty()) {
                val g = groupId[l.group]
                if (g != null) parent = g
                else {
                    val gm = DrawLayerMeta(name = l.group, isFolder = true)
                    groupId[l.group] = gm.id
                    metas.add(gm)
                    parent = gm.id
                }
            }
            val m = DrawLayerMeta(name = l.name)
            m.visible = l.visible
            m.parent = parent
            val full = AnimeDecomposer.fullCanvas(l, r.width, r.height)
            val img = AnimeDecomposer.image(full, r.width, r.height)
            if (img != null) try {
                DrawStore.layerFile(art.id, m.id).outputStream().use { img.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } catch (_: Exception) {}
            metas.add(m)
        }
        // folders are only organisers; keep each folder directly before its children
        val arranged = ArrayList<DrawLayerMeta>()
        for (m in metas.filter { it.isFolder }) {
            arranged.add(m)
            arranged.addAll(metas.filter { it.parent == m.id })
        }
        arranged.addAll(metas.filter { !it.isFolder && it.parent == null })
        art.layers = arranged
        art.activeLayer = arranged.lastOrNull { !it.isFolder }?.id
        art.updated = System.currentTimeMillis()
        DrawStore.upsert(art)
        return art
    }

    /** Photo / file → new artwork whose single layer is the picture. */
    fun fromImage(img: Bitmap, name: String, parent: String?, paperWhite: Boolean = true): DrawItem? {
        var w = img.width; var h = img.height
        val maxS = DrawPresets.maxSide.toFloat()
        var scale = min(1f, maxS / max(w, h).toFloat())
        if (w.toFloat() * h * scale * scale > DrawPresets.maxPixels) {
            scale = sqrt(DrawPresets.maxPixels.toFloat() / (w * h))
        }
        w = max(16, (w * scale).toInt()); h = max(16, (h * scale).toInt())
        val art = DrawStore.newArtwork(name, w, h, parent, paperWhite)
        try {
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            c.drawBitmap(img, null, android.graphics.RectF(0f, 0f, w.toFloat(), h.toFloat()), p)
            val id = art.layers.firstOrNull()?.id
            if (id != null) DrawStore.layerFile(art.id, id).outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) {}
        return art
    }
}
