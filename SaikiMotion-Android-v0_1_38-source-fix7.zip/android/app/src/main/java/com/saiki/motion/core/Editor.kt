package com.saiki.motion.core

// Port of Sources/Core/Editor.swift
object Editor {
    var project: Project = Project(name = "Untitled")
    var sceneIndex: Int = 0
    var time: Float = 0f
    var xray = false
    var exporting = false
    private val emptyScene = Scene("Scene 1")

    var scene: Scene
        get() = if (sceneIndex in project.scenes.indices) project.scenes[sceneIndex] else (project.scenes.firstOrNull() ?: emptyScene)
        set(v) {
            if (sceneIndex in project.scenes.indices) project.scenes[sceneIndex] = v
            else if (project.scenes.isNotEmpty()) project.scenes[0] = v
            else { project.scenes = mutableListOf(v); sceneIndex = 0 }
        }
}

/** EditorViewController.expressionDoc twin (HelpDocs "Expression reference"); full text in the App wave. */
val Editor.expressionDocFallback: String
    get() = "Expressions: combine tracks with + - * /, use t (seconds), markers by name, sin/cos/abs/min/max/pow/sqrt/random. Example: x * (1 + 0.2 * sin(t * 2 * PI))."

