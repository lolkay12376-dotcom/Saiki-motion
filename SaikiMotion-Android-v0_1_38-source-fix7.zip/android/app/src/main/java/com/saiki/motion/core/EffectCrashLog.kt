package com.saiki.motion.core

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Port of Sources/Support/EffectCrashLog.swift — finds which effect crashed / froze the app and keeps a
// readable log. Before an effect is compiled or used for the first time it is written to a small
// "in flight" file; removed once that work finished fine. If the app dies the file survives; on the
// next launch recover() turns it into a log in <root>/EffectCrashLogs/<effect id>/ and marks the
// effect broken, so it stays switched off (passthrough) instead of crashing the app again.
object EffectCrashLog {
    private val lock = Object()
    private val inflight = HashMap<String, HashMap<String, String>>()
    private val verified = HashSet<String>()
    private var recovered = false

    fun rootDir(): File = File(Paths.root, "EffectCrashLogs")
    private val flightFile: File get() = File(rootDir(), ".inflight.json")
    private val brokenFile: File get() = File(rootDir(), ".broken.json")

    // MARK: broken list
    private var brokenCache: HashSet<String>? = null

    fun isBroken(id: String): Boolean {
        synchronized(lock) {
            if (brokenCache == null) { resetOnce(); brokenCache = loadBroken() }
            return brokenCache!!.contains(id)
        }
    }

    fun brokenSet(): Set<String> {
        synchronized(lock) { resetOnce(); return loadBroken() }
    }

    /** Effects switched off by the old thumbnail deadlock were false positives: re-enable once per build. */
    private fun resetOnce() {
        val k = "fxBrokenReset"; val v = "b${AppInfo.build}"
        if (Prefs.getString(k, null) == v) return
        Prefs.setString(k, v)
        brokenFile.delete()
        brokenCache = null
    }

    private fun loadBroken(): HashSet<String> {
        return try {
            val a = org.json.JSONArray(brokenFile.readText())
            val out = HashSet<String>()
            for (i in 0 until a.length()) out.add(a.getString(i))
            out
        } catch (_: Exception) { HashSet() }
    }

    fun setBroken(id: String, on: Boolean) {
        synchronized(lock) {
            val b = loadBroken()
            if (on) b.add(id) else b.remove(id)
            rootDir().mkdirs()
            brokenCache = b
            try { brokenFile.writeText(org.json.JSONArray(b).toString()) } catch (_: Exception) {}
        }
    }

    // MARK: in-flight tracking (cheap: only the first use of each effect is tracked)

    /** Returns false if this effect already ran fine this session (nothing to track). */
    fun begin(id: String, name: String, stage: String, detail: String = ""): Boolean {
        synchronized(lock) {
            if (verified.contains(id) && stage == "first render") return false
            val e = HashMap<String, String>()
            e["id"] = id; e["name"] = name; e["stage"] = stage; e["detail"] = detail
            e["time"] = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date())
            e["t0"] = System.currentTimeMillis().toString()
            inflight["$id|$stage"] = e
            writeFlight()
            return true
        }
    }

    fun end(id: String, stage: String) {
        synchronized(lock) {
            inflight.remove("$id|$stage")
            if (stage == "first render") verified.add(id)
            writeFlight()
        }
    }

    private fun writeFlight() {
        try {
            rootDir().mkdirs()
            if (inflight.isEmpty()) { flightFile.delete(); return }
            flightFile.writeText(org.json.JSONArray().apply { for (v in inflight.values) put(org.json.JSONObject(v as Map<*, *>)) }.toString())
        } catch (_: Exception) {}
    }

    // MARK: logs

    private fun deviceInfo(): String {
        val mem = try {
            val mi = android.app.ActivityManager.MemoryInfo()
            val am = Paths.appContext.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            am.getMemoryInfo(mi)
            mi.totalMem / (1024L * 1024L)
        } catch (_: Exception) { 0L }
        return "App ${AppInfo.version}  |  ${android.os.Build.MODEL} Android ${android.os.Build.VERSION.RELEASE}  |  RAM $mem MB"
    }

    fun writeLog(id: String, name: String, kind: String, stage: String, detail: String, markBroken: Boolean): File? {
        val dir = File(rootDir(), id.replace("/", "_"))
        dir.mkdirs()
        val f = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US)
        val url = File(dir, "${f.format(Date())}_$kind.log")
        var t = "EFFECT ${kind.uppercase()}\n==============================\n"
        t += "Effect: ${if (name.isEmpty()) id else name} ($id)\nWhat happened: $kind\nWhile: $stage\n"
        t += "When: ${SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date())}\n${deviceInfo()}\n"
        if (detail.isNotEmpty()) t += "\nDetails:\n$detail\n"
        if (markBroken) t += "\nThis effect was switched off (passthrough) so the app keeps working. Re-enable it in Settings > Crash > Effect crash logs.\n"
        try { url.writeText(t) } catch (_: Exception) { return null }
        if (markBroken) setBroken(id, true)
        return url
    }

    /** A shader / compile problem that did not kill the app. */
    fun logError(id: String, msg: String, name: String = "") {
        writeLog(id, name, "error", "shader compile", msg, markBroken = false)
    }

    /** Run once at launch: anything still "in flight" means the last run died while using that effect. */
    fun recover() {
        synchronized(lock) {
            if (recovered) return
            recovered = true
        }
        val arr = try { org.json.JSONArray(flightFile.readText()) } catch (_: Exception) { return }
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            writeLog(e.optString("id", "unknown"), e.optString("name", ""), "crash-or-freeze", e.optString("stage", "?"),
                "The app stopped while this effect was being ${e.optString("stage", "used")} (started ${e.optString("time", "?")}).\n" + e.optString("detail", ""),
                markBroken = true)
        }
        flightFile.delete()
    }

    /** Called by the freeze watchdog right before it aborts the app. */
    fun noteFreeze(detail: String) {
        val items: List<HashMap<String, String>>
        synchronized(lock) {
            items = inflight.values.toList()
            inflight.clear()
        }
        for (e in items) {
            writeLog(e["id"] ?: "unknown", e["name"] ?: "", "freeze", e["stage"] ?: "?",
                detail + "\n" + (e["detail"] ?: ""), markBroken = true)
        }
        flightFile.delete()
    }

    /** Called every ~2 s by the watchdog while the main thread is silent: an effect that has been in flight
     *  for `secs` is logged and switched off NOW, before the user has to force-quit the frozen app. */
    fun noteStallIfAny(secs: Double) {
        val stuck: List<HashMap<String, String>>
        synchronized(lock) {
            val now = System.currentTimeMillis()
            val s = inflight.filter {
                now - (it.value["t0"]?.toDoubleOrNull() ?: now.toDouble()) > secs * 1000 && it.value["stage"] != "quick test"
            }
            for (k in s.keys) inflight.remove(k)
            if (s.isNotEmpty()) writeFlight()
            stuck = s.values.toList()
        }
        for (e in stuck) {
            writeLog(e["id"] ?: "unknown", e["name"] ?: "", "freeze", e["stage"] ?: "?",
                "The app stopped responding for more than ${secs.toInt()} s while this effect was being ${e["stage"] ?: "used"}.\n" + (e["detail"] ?: ""),
                markBroken = true)
        }
    }

    fun count(): Int = rootDir().listFiles()?.count { it.isDirectory } ?: 0
}
