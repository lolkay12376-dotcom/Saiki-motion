package com.saiki.motion.core

import org.json.JSONArray
import org.json.JSONObject

/** AureaPlugin.swift FxPass. */
class FxPass(var code: String, var target: String?, var scale: Float, var inputs: Map<String, String>)

/** Port of Sources/Effects/EffectDef.swift. kind 1 = single instance per layer (bare param keys). */
class EffectDef(
    val id: String, var name: String = "", var desc: String = "", var category: String = "Custom",
    var kind: Int = 0, var props: MutableList<PropDef> = ArrayList(), var colors: MutableList<ColorParam> = ArrayList(),
    var inputs: MutableList<String> = ArrayList(), var previewAnim: String = "swipe",
    var builtin: Boolean = false, var bundled: Boolean = false, var source: String? = null, var glsl: String = ""
) {
    /** iOS-only native Metal source. Kept for effect.json round trip; Android always compiles `glsl` (shared source). */
    var msl: String? = null
    /** Multi-pass .aureaplugin effect: the passes run in order, the last writes the result. */
    var passes: MutableList<FxPass> = ArrayList()
    var renderScale: Float = 1f
    var sharedPassProgram = false

    val confinesToAlpha: Boolean
        get() {
            if (id == "contour" || id == "lightleak" || id == "lightsweep") return true
            return category == "Color" || category == "Stylize" || category == "Generate" || category == "Keying"
        }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id); o.put("name", name); o.put("description", desc)
        o.put("category", category); o.putL("kind", kind.toLong()); o.put("preview", previewAnim)
        val pa = JSONArray()
        for (p in props) {
            val po = JSONObject().put("name", p.key).put("label", p.label)
            po.putD("min", p.min.toDouble()); po.putD("max", p.max.toDouble()); po.putD("def", p.def.toDouble()); po.putL("dec", p.dec.toLong())
            p.options?.let { opts -> val oa = JSONArray(); for (s in opts) oa.put(s); po.put("options", oa) }
            if (p.inf) { po.put("infinite", true); po.putD("span", p.span.toDouble()) }
            pa.put(po)
        }
        o.put("params", pa)
        val ca = JSONArray()
        for (c in colors) ca.put(JSONObject().put("name", c.key).put("label", c.label).put("def", String.format(java.util.Locale.US, "#%08X", c.def)))
        o.put("colors", ca)
        val ia = JSONArray(); for (i in inputs) ia.put(i); o.put("inputs", ia)
        o.put("code", glsl)
        msl?.let { if (it.isNotEmpty()) o.put("msl", it) }
        return o
    }

    companion object {
        /** EffectDef.fromJson (effect.json / SDK folders). `id` falls back to a slug of the name. */
        fun fromJson(o: JSONObject, source: String?): EffectDef? {
            val name = o.optS("name").trim { it == ' ' || it == '\t' }
            if (name.isEmpty()) return null
            var id = o.optS("id").trim { it == ' ' || it == '\t' }
            if (id.isEmpty()) {
                id = name.lowercase().map { c -> if (c.isLetterOrDigit()) c else '_' }.joinToString("")
                id = id.trim('_')
            }
            val d = EffectDef(id, name, o.optS("description"), o.optS("category", "Custom"), o.optI("kind"), source = source, glsl = o.optS("code"))
            val m = o.optS("msl"); if (m.isNotEmpty()) d.msl = m
            o.optJSONArray("params")?.let { pa ->
                for (i in 0 until pa.length()) {
                    val po = pa.optJSONObject(i) ?: continue
                    val key = po.optS("name").trim { it == ' ' || it == '\t' }
                    if (key.isEmpty()) continue
                    var label = po.optS("label"); if (label.isEmpty()) label = key
                    var opts: MutableList<String>? = null
                    po.optJSONArray("options")?.let { oa -> opts = ArrayList(); for (j in 0 until oa.length()) opts!!.add(oa.optS(j)) }
                    d.props.add(PropDef(key, label, po.optF("min"), po.optF("max", 1f), po.optF("def"), po.optI("dec", 2), opts, po.optB("infinite"), po.optF("span", 180f)))
                }
            }
            o.optJSONArray("colors")?.let { ca ->
                for (i in 0 until ca.length()) {
                    val co = ca.optJSONObject(i) ?: continue
                    val key = co.optS("name").trim { it == ' ' || it == '\t' }
                    if (key.isEmpty()) continue
                    var label = co.optS("label"); if (label.isEmpty()) label = key
                    d.colors.add(ColorParam(key, label, parseColor(co.optS("def", "#FFFFFFFF"))))
                }
            }
            o.optJSONArray("inputs")?.let { ia ->
                for (i in 0 until ia.length()) { val nm = ia.optS(i).trim { it == ' ' || it == '\t' }; if (nm.isNotEmpty()) d.inputs.add(nm) }
            }
            val pv = o.optS("preview"); if (pv.isNotEmpty()) d.previewAnim = pv
            return d
        }

        /** "#AARRGGBB" / "#RRGGBB" -> ARGB Int (the SDK's colour spelling). */
        fun parseColor(s: String): Int {
            var t = s.trim { it == ' ' || it == '\t' }
            if (t.startsWith("#")) t = t.substring(1)
            val u = t.toLongOrNull(16) ?: return 0xFFFFFFFF.toInt()
            if (t.length == 6) return (0xFF000000L or u).toInt()
            if (t.length == 8) return u.toInt()
            return 0xFFFFFFFF.toInt()
        }
    }
}
