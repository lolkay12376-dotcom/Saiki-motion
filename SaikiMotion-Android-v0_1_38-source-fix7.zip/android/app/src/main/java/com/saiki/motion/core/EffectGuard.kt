package com.saiki.motion.core

import com.saiki.motion.render.NativeRenderer
import java.util.concurrent.Executors

// Port of Sources/Support/EffectGuard.swift — quick safety test of an effect before it may touch the
// live preview. On Android the effect compiles asynchronously through the fx runtime (fxPrepare/
// fxStatus); a compile failure (fxError) or a cost that would be too slow at preview size switch
// the effect off (passthrough), write a log in EffectCrashLogs and notify.
object EffectGuard {
    const val doneNote = "EffectGuardDone"
    @JvmField var onDone: ((String?) -> Unit)? = null     // replaces NotificationCenter (main thread)
    private val lock = Object()
    private val state = HashMap<String, Int>()        // 1 testing, 2 ok, 3 bad
    private val q = Executors.newSingleThreadExecutor { r -> Thread(r, "fx.guard") }

    private fun key(d: EffectDef): String = d.id + "#" + d.glsl.hashCode() + "#" + d.props.joinToString(",") { it.key }

    /** True when the effect passed its test. Starts the test (and returns false) the first time. */
    fun cleared(d: EffectDef): Boolean {
        if (d.passes.isNotEmpty() || d.kind == 1) return true     // plugins / single-instance effects have their own path
        val k = key(d)
        val st: Int
        synchronized(lock) {
            st = state[k] ?: 0
            if (st == 0) state[k] = 1
        }
        if (st == 2) return true
        if (st == 0) start(d, k)
        return false
    }

    /// Export must never skip an effect just because its quick test has not finished yet
    /// (that produced frames with the effect missing). Waits (bounded) for the verdict.
    fun clearedWaiting(d: EffectDef, timeout: Double = 10.0): Boolean {
        if (cleared(d)) return true
        val end = System.currentTimeMillis() + (timeout * 1000).toLong()
        while (System.currentTimeMillis() < end) {
            val st: Int
            synchronized(lock) { st = state[key(d)] ?: 0 }
            if (st == 2) return true
            if (st == 3) return false
            try { Thread.sleep(20) } catch (_: InterruptedException) { return false }
        }
        return false
    }

    private fun finish(d: EffectDef, k: String, ok: Boolean, kind: String, why: String) {
        synchronized(lock) {
            if (state[k] != 1) return            // already decided (timeout vs. late result)
            state[k] = if (ok) 2 else 3
        }
        var msg: String? = null
        if (!ok) {
            EffectCrashLog.writeLog(d.id, d.name, kind, "quick test", why, markBroken = true)
            msg = "${d.name} was switched off: $kind. See Settings > Crash > Effect crash logs."
        }
        android.os.Handler(android.os.Looper.getMainLooper()).post { onDone?.invoke(msg) }
    }

    private fun start(d: EffectDef, k: String) {
        EffectCrashLog.begin(d.id, d.name, "quick test")
        q.execute {
            // the test thread may wedge (driver hang): the main app must not wait for it.
            val timeout = Thread {
                try { Thread.sleep(5000) } catch (_: InterruptedException) { return@Thread }
                finish(d, k, false, "hang", "The quick test did not finish within 5 seconds.")
            }
            timeout.isDaemon = true
            timeout.start()
            val r = test(d)
            timeout.interrupt()
            EffectCrashLog.end(d.id, "quick test")
            finish(d, k, r.first, r.second, r.third)
        }
    }

    /** (ok, kind, why). Compile path goes through the async fx runtime; a not-yet-ready shader counts as ok=false with the pending status. */
    private fun test(d: EffectDef): Triple<Boolean, String, String> {
        // prepare + wait up to 4s for the async compile (the 5s hang timeout still governs)
        NativeRenderer.fxPrepare(FxGlsl.key(d), FxGlsl.vulkanSource(d), d.name)
        val t0 = System.currentTimeMillis()
        var st = NativeRenderer.fxStatus(FxGlsl.key(d))
        while (st == 0 && System.currentTimeMillis() - t0 < 4000) {
            try { Thread.sleep(50) } catch (_: InterruptedException) { return Triple(true, "", "") }
            st = NativeRenderer.fxStatus(FxGlsl.key(d))
        }
        if (st == 2) return Triple(false, "shader-compile-error", "The shader does not compile on this device:\n" + NativeRenderer.fxError(FxGlsl.key(d)))
        if (st != 1) return Triple(true, "", "")     // cannot test here: let it through
        return Triple(true, "", "")                  // cost measurement needs a live frame; the runtime passthrough covers it
    }
}
