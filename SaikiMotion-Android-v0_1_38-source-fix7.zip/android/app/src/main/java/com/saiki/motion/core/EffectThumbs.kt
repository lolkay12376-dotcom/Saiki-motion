package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import com.saiki.motion.render.SceneRendererN
import java.io.File
import kotlin.math.abs
import kotlin.math.max

// Port of Sources/Effects/EffectThumbs.swift — before/after thumbnails for the effect browser.
// Renders every effect in the catalog against generated sample images offscreen, then hands
// Bitmaps to `cache`. `__orig:<id>` holds the untouched sample; `<id>` the processed result.
object EffectThumbs {
    /** Thread-safe image store (UI reads it while the background queue writes it). */
    class Store {
        private val d = HashMap<String, Bitmap>()
        private val l = Object()
        operator fun get(k: String): Bitmap? = synchronized(l) { d[k] }
        operator fun set(k: String, v: Bitmap?) = synchronized(l) { if (v != null) d[k] = v }
        val keys: List<String> get() = synchronized(l) { d.keys.toList() }
        fun remove(k: String) = synchronized(l) { d.remove(k) }
        fun removeAll() = synchronized(l) { d.clear() }
    }

    val cache = Store()
    @JvmField var lastError = ""

    private val queue = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "saiki.thumbs") }
    private var generating = false
    private val waiters = ArrayList<() -> Unit>()
    private val cacheMutex = Object()

    fun origKey(id: String): String = "__orig:$id"

    /** Deterministic hash (String.hashCode changes every launch on some runtimes; keep it stable). */
    fun stable(s: String): Int {
        var h = 5381
        for (u in s) h = (h * 33 + u.code) and 0x7fffffff
        return h
    }

    // Bundled sample photos (shared/resources/img; iOS Resources/img).
    private val bundledSamples = listOf(
        Pair("fx_woman", "jpg"), Pair("fx_mountain", "jpg"), Pair("fx_ramen", "jpg"),
        Pair("fx_apple", "png"), Pair("fx_greenscreen", "jpg"),
        Pair("fx_girl", "jpg"), Pair("fx_forest", "jpg"), Pair("anime_portrait", "jpg"),
        Pair("fx_skyscraper", "jpg"), Pair("fx_am_girl", "jpg"), Pair("fx_capcut", "jpeg"), Pair("fx_nodevideo", "jpg"))
    // indices: 0 woman, 1 cows-in-field, 2 ramen, 3 empty (particles),
    //          4 green-screen anime girl, 5 girl, 6 forest, 7 anime portrait, 8 skyscraper

    /** Which sample photo suits an effect (same rules as iOS). */
    fun sampleIndex(def: EffectDef): Int {
        if (def.category == "Node Video") return 11
        if (capcutFxIds.contains(def.id)) return 10
        if (amFxIds.contains(def.id)) return 9
        if (skyscraperFxIds.contains(def.id)) return 8
        val key = (def.id + " " + def.name + " " + def.desc).lowercase()
        val cat = def.category.lowercase()
        val h = stable(def.id)
        fun has(w: List<String>) = w.any { key.contains(it) }
        if (cat == "keying" || has(listOf("chroma", "key", "matte", "mask", "green"))) return if (h % 2 == 0) 4 else 7
        if (has(listOf("particle", "emitter", "snow", "rain", "confetti", "sparks")) || cat == "generate") return 3
        if (has(listOf("vhs", "crt", "scan", "grain", "film", "overlay", "glitch", "noise", "tv"))
            || cat == "glitch and motion" || cat == "light and glow") return 1
        if (cat == "color" || has(listOf("color", "grade", "lut", "hue", "tone", "curve"))) return if (h % 2 == 0) 5 else 6
        val rest = listOf(0, 2, 7, 1)
        return rest[h % rest.size]
    }

    fun sampleIndex(id: String): Int {
        val d = Registry.byId[id]
        if (d != null) return sampleIndex(d)
        return stable(id) % sampleCount
    }

    val sampleCount: Int get() = bundledSamples.size
    private val imageLock = Object()

    private fun bundled(i: Int): Bitmap? {
        if (i < 0 || i >= bundledSamples.size) return null
        val (name, ext) = bundledSamples[i]
        val src = try {
            Paths.appContext.assets.open("img/$name.$ext").use { android.graphics.BitmapFactory.decodeStream(it) }
        } catch (_: Exception) { null } ?: return null
        // center-crop to a 256 square once: small uploads, small memory
        val n = 256
        val sc = max(n.toFloat() / src.width, n.toFloat() / src.height)
        val w = src.width * sc; val h = src.height * sc
        val out = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(src, null, android.graphics.RectF((n - w) / 2, (n - h) / 2, (n + w) / 2, (n + h) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    // MARK: disk cache (thumbs are rendered once per build, then just loaded)

    private val diskDir: File? by lazy {
        val d = File(Paths.appContext.cacheDir, "fxthumbs3-${AppInfo.build}")
        d.mkdirs()
        d
    }

    private fun diskName(id: String, orig: Boolean): String {
        val safe = id.map { if (it.isLetterOrDigit()) it.toString() else "_" }.joinToString("")
        return (if (orig) "o_" else "a_") + safe + ".jpg"
    }

    /** Thumbnails baked into the app (shared/resources/thumbs). */
    private fun loadBaked(id: String): Pair<Bitmap, Bitmap>? {
        return try {
            val a = Paths.appContext.assets.open("thumbs/${diskName(id, false)}").use { android.graphics.BitmapFactory.decodeStream(it) }
            val b = Paths.appContext.assets.open("thumbs/${diskName(id, true)}").use { android.graphics.BitmapFactory.decodeStream(it) }
            if (a != null && b != null) Pair(b, a) else null
        } catch (_: Exception) { null }
    }

    private fun loadFromDisk(id: String): Pair<Bitmap, Bitmap>? {
        val d = diskDir ?: return null
        val a = try { android.graphics.BitmapFactory.decodeFile(File(d, diskName(id, false)).absolutePath) } catch (_: Exception) { null } ?: return null
        val b = try { android.graphics.BitmapFactory.decodeFile(File(d, diskName(id, true)).absolutePath) } catch (_: Exception) { null } ?: return null
        return Pair(b, a)
    }

    private fun saveToDisk(id: String, before: Bitmap?, after: Bitmap?) {
        val d = diskDir ?: return
        val b = before ?: return; val a = after ?: return
        try {
            File(d, diskName(id, true)).outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            File(d, diskName(id, false)).outputStream().use { a.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        } catch (_: Exception) {}
    }

    /** shaders that failed to compile count as "done" so the browser doesn't re-run generation forever. */
    fun ready(id: String): Boolean = cache[id] != null || Registry.errors[id] != null

    /** The raw sample image for an effect id (same variant the generation pass used). */
    fun raw(id: String): Bitmap? = sample(sampleIndex(id).toString())

    /** Renders every built-in effect fresh and writes before/after JPGs to <root>/ThumbExport. */
    fun exportBaked(done: (File?, Int) -> Unit) {
        val x = File(Paths.root, "ThumbExport")
        x.deleteRecursively(); x.mkdirs()
        generate {}   // let any running pass finish first (waiters run in order)
        val busy = synchronized(cacheMutex) { generating }
        val start = {
            queue.execute {
                exportDir = x
                runGeneration()
                exportDir = null
                val n = (x.listFiles()?.size ?: 0) / 2
                android.os.Handler(android.os.Looper.getMainLooper()).post { done(if (n > 0) x else null, n) }
            }
        }
        if (busy) generate { start() } else start()
    }

    /** Editor spelling: (vc, preview, done). */
    fun generate(vc: Any?, preview: Any?, done: () -> Unit) = generate(done)

    /** One generation run at a time. Callers that arrive while it runs are queued. */
    fun generate(done: () -> Unit) {
        synchronized(cacheMutex) {
            waiters.add(done)
            if (generating) return
            generating = true
        }
        queue.execute {
            runGeneration()
            val w: List<() -> Unit>
            synchronized(cacheMutex) { w = waiters.toList(); waiters.clear(); generating = false }
            android.os.Handler(android.os.Looper.getMainLooper()).post { w.forEach { it() } }
        }
    }

    /** Renders the whole catalog (skips ids already cached). */
    private var exportDir: File? = null

    private fun runGeneration() {
        // The Vulkan core must be recording; on Android the generation runs inside a sync frame.
        if (!SceneRendererN.begin()) { lastError = "GL unavailable"; return }
        val size = 256
        val target = MetalTarget(SceneRendererN.targetCreate(size, size, false), size, size, false)   // untouched sample (effect INPUT)
        val outTarget = MetalTarget(SceneRendererN.targetCreate(size, size, false), size, size, false) // processed result
        // sample textures
        val sampleTex = ArrayList<Long>()
        for (i in 0 until sampleCount) {
            val t = SceneRendererN.texCreate(256, 256, SceneRendererN.bitmapRgba(sample(i.toString())))
            sampleTex.add(if (t != 0L) t else (sampleTex.firstOrNull() ?: 0L))
        }
        val first = sampleTex.firstOrNull()
        if (first == null || first == 0L) { lastError = "sample upload failed"; return }

        // snapshot the catalog: a concurrent reload must not mutate the array mid-iteration
        val defs = Registry.order.toList()
        for (def in defs) {
            val key = def.id
            val exporting = exportDir != null
            if (exporting && !(def.builtin || def.bundled)) continue
            if (!exporting && cache[key] != null) continue
            if (!exporting) {
                val baked = loadBaked(key) ?: loadFromDisk(key)
                if (baked != null) {
                    synchronized(cacheMutex) {
                        cache[origKey(key)] = baked.first
                        cache[key] = baked.second
                    }
                    continue
                }
            }
            // pass-through defs (remap, particles, transform) show the raw sample
            val passThrough = def.kind == 1 || (def.glsl.contains("return src(uv);") && def.props.isEmpty())
            if (passThrough && def.id != "tile") {
                if (exporting) continue
                synchronized(cacheMutex) {
                    cache[key] = sample(sampleIndex(key).toString())
                    cache[origKey(def.id)] = sample(sampleIndex(key).toString())
                }
                continue
            }
            val fallback = sample(sampleIndex(key).toString())
            if (EffectCrashLog.isBroken(def.id)) {
                if (exporting) continue
                cache[origKey(key)] = fallback; cache[key] = fallback
                continue
            }
            EffectCrashLog.begin(def.id, def.name, "thumbnail")
            // compile check first (fxPrepare is async on Android): skip until ready
            if (!FxGlsl.prepare(def)) {
                EffectCrashLog.end(def.id, "thumbnail")
                cache[origKey(key)] = fallback; cache[key] = fallback
                continue
            }
            val which = minOf(sampleIndex(def), sampleTex.size - 1)
            val inTex = sampleTex[which]

            // 1 — draw the sample into the target (quad pass, identity transform)
            val u = QuadU()
            u.abcd(1f, 0f, 0f, 1f); u.t(0f, 0f); u.quad(2f, 2f); u.aspect = 1f; u.flipY = 1f
            SceneRendererN.quadPass("quad.frag", "fs.vert", false, target.handle, true, u.data, inTex, null, null, 4)
            val before = SceneRendererN.readTarget(target.handle)

            // 2 — apply the effect with default parameter values (fx pass src=target -> outTarget)
            val props = FloatArray(def.props.size) { def.props[it].def }
            val cols = ArrayList<FloatArray>()
            for (cp in def.colors) {
                val d = cp.def
                cols.add(floatArrayOf(((d ushr 16) and 0xFF) / 255f, ((d ushr 8) and 0xFF) / 255f, (d and 0xFF) / 255f, ((d ushr 24) and 0xFF) / 255f))
            }
            val step = FxStepData(def, props, cols)
            val ok = SceneRendererN.fxPass(step.key, target.handle, outTarget.handle, 1.7f)
            val after = if (ok) SceneRendererN.readTarget(outTarget.handle) else null

            synchronized(cacheMutex) {
                if (before != null) cache[origKey(def.id)] = before
                if (after != null) cache[def.id] = after
            }
            val x = exportDir
            if (x != null) {
                try {
                    if (before != null) File(x, diskName(def.id, true)).outputStream().use { before.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                    if (after != null) File(x, diskName(def.id, false)).outputStream().use { after.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                } catch (_: Exception) {}
            } else saveToDisk(def.id, before, after)
            EffectCrashLog.end(def.id, "thumbnail")
            try { Thread.sleep(25) } catch (_: InterruptedException) {}   // leave GPU gaps so the editor preview never starves
        }
        for (t in sampleTex) if (t != 0L) SceneRendererN.texFree(t)
        SceneRendererN.finish()
    }

    // MARK: - sample images
    // Deterministic "photos" so every install shows the same cards.

    private val sampleImages = HashMap<String, Bitmap>()

    fun sample(variant: String): Bitmap {
        synchronized(imageLock) {
            sampleImages[variant]?.let { return it }
            val i = variant.toIntOrNull()
            if (i != null) {
                val b = bundled(i)
                if (b != null) { sampleImages[variant] = b; return b }
            }
            val n = 320
            val img = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
            val c = Canvas(img)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val v = (variant.lastOrNull()?.digitToIntOrNull() ?: 0) % 3
            if (v == 0) {
                // dusk hills
                p.shader = LinearGradient(0f, 0f, 0f, n.toFloat(), Color.rgb(255, 158, 89), Color.rgb(59, 41, 107), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, n.toFloat(), n.toFloat(), p)
                p.shader = null
                p.color = Color.rgb(255, 230, 153)
                c.drawOval(android.graphics.RectF(n * 0.62f, n * 0.22f, n * 0.62f + 46, n * 0.22f + 46), p)
                p.color = Color.rgb(31, 26, 51)
                val path = android.graphics.Path()
                path.moveTo(0f, n * 0.72f)
                path.lineTo(n * 0.35f, n * 0.5f)
                path.lineTo(n * 0.62f, n * 0.76f)
                path.lineTo(n.toFloat(), n * 0.6f)
                path.lineTo(n.toFloat(), n.toFloat())
                path.lineTo(0f, n.toFloat())
                path.close()
                c.drawPath(path, p)
                p.color = (0x59 shl 24) or Color.rgb(0, 0, 0)      // 0.35 black
                c.drawRect(0f, n * 0.86f, n.toFloat(), n.toFloat(), p)
            } else if (v == 1) {
                // still life blocks
                p.shader = LinearGradient(0f, 0f, n.toFloat(), n.toFloat(), Color.rgb(26, 31, 41), Color.rgb(61, 71, 87), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, n.toFloat(), n.toFloat(), p)
                p.shader = null
                val cols = listOf(Color.rgb(242, 77, 82), Color.rgb(250, 191, 51), Color.rgb(64, 166, 230), Color.rgb(102, 217, 140))
                val rects = listOf(
                    android.graphics.RectF(30f, 60f, 140f, 170f),
                    android.graphics.RectF(160f, 40f, 250f, 180f),
                    android.graphics.RectF(80f, 170f, 240f, 270f),
                    android.graphics.RectF(210f, 180f, 280f, 250f))
                for ((i, rc) in rects.withIndex()) { p.color = cols[i % cols.size]; c.drawRect(rc, p) }
            } else {
                // portrait gradient + bright window + skin tones
                p.shader = LinearGradient(0f, 0f, n.toFloat(), n.toFloat(), Color.rgb(217, 199, 184), Color.rgb(89, 77, 71), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, n.toFloat(), n.toFloat(), p)
                p.shader = null
                p.color = (0xF2 shl 24) or Color.rgb(255, 255, 255)
                c.drawRect(n * 0.66f, 24f, n * 0.66f + 74, 24f + 96, p)
                p.color = Color.rgb(184, 128, 102)
                c.drawOval(android.graphics.RectF(n * 0.3f, n * 0.34f, n * 0.3f + 120, n * 0.34f + 150), p)
                p.color = Color.rgb(51, 41, 36)
                c.drawOval(android.graphics.RectF(n * 0.3f + 18, n * 0.34f + 52, n * 0.3f + 44, n * 0.34f + 68), p)
                c.drawOval(android.graphics.RectF(n * 0.3f + 76, n * 0.34f + 52, n * 0.3f + 102, n * 0.34f + 68), p)
            }
            sampleImages[variant] = img
            return img
        }
    }

    /** Sample image by any hashable seed (stable within one run). */
    fun sampleAt(seed: Int): Bitmap = sample((abs(seed) % sampleCount).toString())

    /** Drops cached thumbs (effect edited / deleted). */
    fun invalidate() {
        synchronized(cacheMutex) { cache.removeAll() }
        val d = diskDir ?: return
        d.listFiles()?.forEach { it.delete() }
    }

    // The three thumbnail id sets are declared by the Builtins files that own them
    // (BuiltinsCapCut.kt / BuiltinsAM.kt / BuiltinsSapphire4.kt — same ids as the Swift).
    private val capcutFxIds: Set<String> = com.saiki.motion.core.capcutFxIds
    private val amFxIds: Set<String> = com.saiki.motion.core.amFxIds
    private val skyscraperFxIds: Set<String> = com.saiki.motion.core.skyscraperFxIds
}
