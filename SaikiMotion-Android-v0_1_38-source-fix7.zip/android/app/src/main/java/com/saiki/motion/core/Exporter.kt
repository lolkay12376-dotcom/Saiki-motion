package com.saiki.motion.core

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

// Port of Sources/Render/Exporter.swift — offscreen render to MP4.
// Renders every frame through the same SceneRenderer the preview uses (full quality, deterministic
// video sampling), writes H.264 via MediaCodec + MediaMuxer, then muxes the audio layers on top.
// Output lands in <filesDir>/SaikiMotion/exports.
class RenderSettings {
    var scale: Float = 1f          // canvas resolution multiplier
    var fps: Int = 30
    var draft = false              // quarter-res fast pass
    var withAudio = true
    var bitrateMbps: Float = 0f    // 0 = automatic
    var exportProjectFile = false
}

object Exporter {
    class Result {
        var url: File? = null
        var error: String? = null
        var frames = 0
    }

    /** Renders `project`'s current scene to an .mp4. Blocking — call off main. */
    fun export(project: Project, scene: Scene, settings: RenderSettings): Result {
        val res = Result()
        Paths.ensure()
        val outDir = File(Paths.root, "exports")
        outDir.mkdirs()
        val name = "${alnum(project.name)}-${nowMs()}.mp4"
        val outURL = File(outDir, name)
        outURL.delete()

        val w = max(16, (project.w * settings.scale).toInt() and 1.inv())   // even for H.264
        val h = max(16, (project.h * settings.scale).toInt() and 1.inv())
        val fps = settings.fps
        val duration = scene.duration

        val renderer = SceneRenderer.shared
        if (renderer == null) { res.error = "Could not create the render context."; return res }
        renderer.quality = if (settings.draft) 4 else 1
        renderer.isExport = true
        SceneRenderer.isExporting = true
        Editor.exporting = true
        try {
            // pre-rendered groups: make sure their frames exist at export size
            preRenderAll(renderer, project, scene)

            // audio: every visible audio layer AND every video layer that carries sound
            val audioSegs = ArrayList<AudioSeg>()
            if (settings.withAudio) {
                for (l in scene.layers) {
                    if ((l.type != LayerType.AUDIO && l.type != LayerType.VIDEO) || !l.visible) continue
                    val p = l.imagePath ?: continue
                    var u = File(p)
                    val fxu = AudioFxProc.renderSync(p, l.afxChainAt(l.start), l.afxBake())
                    if (fxu != null) u = fxu
                    if (l.type == LayerType.VIDEO && !hasAudioTrack(u.absolutePath)) continue
                    var curve = ArrayList<Pair<Float, Float>>()      // volume sampled along the layer so keyframes are heard in the export
                    var tt = l.start
                    while (tt < l.end) { curve.add(Pair(tt, max(0f, min(1f, l.p("volume", tt))))); tt += 0.05f }
                    curve.add(Pair(l.end, max(0f, min(1f, l.p("volume", l.end)))))
                    audioSegs.add(AudioSeg(u, l.start, l.srcOffset, l.end, curve))
                }
            }

            val mime = "video/avc"
            val fmt = MediaFormat.createVideoFormat(mime, w, h).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                val br = if (settings.bitrateMbps > 0f) (settings.bitrateMbps * 1_000_000).toInt()
                         else max(2_000_000, (w * h * fps) / 12)     // automatic like AVAssetWriter's defaults
                setInteger(MediaFormat.KEY_BIT_RATE, br)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            }
            val codec = try { MediaCodec.createEncoderByType(mime) } catch (_: Exception) { res.error = "Could not create the encoder."; return res }
            var muxer: MediaMuxer? = null
            var track = -1
            try {
                codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val surface = codec.createInputSurface()
                codec.start()
                muxer = try { MediaMuxer(outURL.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4) } catch (_: Exception) { res.error = "Could not create the movie file."; return res }
            val mx = muxer!!

                val frames = (duration * fps).toInt()
                var frameIdx = 0
                val timeInc = 1.0 / fps

                // Present each rendered frame into the encoder's input surface.
                val info = MediaCodec.BufferInfo()
                var muxStarted = false
                while (frameIdx < frames) {
                    val t = (frameIdx * timeInc).toFloat()
                    if (!renderer.renderFrame(project, scene, t)) { /* eligibility failed: keep going with the last frame */ }
                    val bmp = renderer.snapshotFrame()
                    if (bmp != null) {
                        val canvas = surface.lockCanvas(android.graphics.Rect(0, 0, w, h))
                        canvas.drawBitmap(bmp, null, android.graphics.RectF(0f, 0f, w.toFloat(), h.toFloat()), android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                        surface.unlockCanvasAndPost(canvas)
                        frameIdx++
                        ExporterProgress.add()
                    } else break

                    // drain the encoder
                    var drain = true
                    while (drain) {
                        val idx = codec.dequeueOutputBuffer(info, 10_000)
                        if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) { drain = false }
                        else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            if (!muxStarted) { track = mx.addTrack(codec.outputFormat); mx.start(); muxStarted = true }
                        } else if (idx >= 0) {
                            val ob = codec.getOutputBuffer(idx)
                            if (ob != null && info.size > 0 && muxStarted) {
                                mx.writeSampleData(track, ob, info)
                            }
                            codec.releaseOutputBuffer(idx, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) drain = false
                        }
                    }
                }
                codec.signalEndOfInputStream()
                var draining = true
                while (draining) {
                    val idx = codec.dequeueOutputBuffer(info, 100_000)
                    if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) draining = false
                    else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (!muxStarted) { track = mx.addTrack(codec.outputFormat); mx.start(); muxStarted = true }
                    } else if (idx >= 0) {
                        val ob = codec.getOutputBuffer(idx)
                        if (ob != null && info.size > 0 && muxStarted) muxer!!.writeSampleData(track, ob, info)
                        codec.releaseOutputBuffer(idx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) draining = false
                    }
                }
                res.frames = frameIdx
                if (muxStarted) muxer.stop()
            } finally {
                try { codec.stop() } catch (_: Exception) {}
                codec.release()
                try { muxer?.release() } catch (_: Exception) {}
                Editor.exporting = false
            }

            // audio mux pass
            if (res.error == null && audioSegs.isNotEmpty()) {
                val muxed = muxAudio(outURL, audioSegs, duration)
                if (muxed != null) {
                    outURL.delete()
                    res.url = muxed
                    return res
                }
                // mux failed → ship the silent video
            }
            res.url = outURL
            return res
        } finally {
            SceneRenderer.isExporting = false
            Editor.exporting = false
        }
    }

    private class AudioSeg(val url: File, val start: Float, val offset: Float, val end: Float, val vol: List<Pair<Float, Float>>)   // sampled [(t, vol)] curve

    /** == Exporter.preRenderAll: bake every pre-rendered group at export size. */
    private fun preRenderAll(renderer: SceneRendererInstance, project: Project, scene: Scene) {
        if (!PreRender.enabled) return
        for (g in PreRender.groups(scene)) {
            val sig = PreRender.signature(g, project, scene)
            PreRender.purgeStale(project.id.toString(), g.id, sig)
            while (true) {
                val idx = PreRender.nextMissing(g, project, scene, renderer.width, renderer.height, PreRender.span(g, scene).first) ?: break
                if (!preRenderFrame(renderer, g, idx, project, scene)) break
            }
        }
    }

    /** == SceneRenderer.preRenderFrame: renders frame idx live and stores it. */
    private fun preRenderFrame(renderer: SceneRendererInstance, g: Layer, idx: Int, project: Project, scene: Scene): Boolean {
        val savedCam = SceneRenderer.editCam
        SceneRenderer.editCam = null
        Xf.bakingPlane = true; Xf.bakeRoot = g.id
        try {
            val time = max(0f, idx / max(1, project.fps).toFloat())
            if (!renderer.renderFrame(project, scene, time)) return false
            val bmp = renderer.snapshotFrame() ?: return false
            val px = IntArray(bmp.width * bmp.height)
            bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            val rgba = ByteArray(px.size * 4)
            for (i in px.indices) {
                val c = px[i]
                rgba[i * 4] = ((c shr 16) and 0xFF).toByte(); rgba[i * 4 + 1] = ((c shr 8) and 0xFF).toByte()
                rgba[i * 4 + 2] = (c and 0xFF).toByte(); rgba[i * 4 + 3] = ((c ushr 24) and 0xFF).toByte()
            }
            PreRender.store(project.id.toString(), g.id, PreRender.signature(g, project, scene), bmp.width, bmp.height, idx, rgba)
            return true
        } finally {
            Xf.bakingPlane = false; Xf.bakeRoot = -1
            SceneRenderer.editCam = savedCam
        }
    }

    private fun hasAudioTrack(path: String): Boolean {
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(path)
            (0 until ex.trackCount).any { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
        } catch (_: Exception) { false } finally { ex.release() }
    }

    /** Composes the rendered video + the audio segments into a final .mp4 (AVMutableComposition twin). */
    private fun muxAudio(video: File, segs: List<AudioSeg>, duration: Float): File? {
        return try {
            val out = File(video.parentFile, "mux-${video.name}")
            out.delete()
            val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            // video pass-through
            val vex = MediaExtractor()
            vex.setDataSource(video.absolutePath)
            var vTrack = -1
            for (i in 0 until vex.trackCount) {
                val f = vex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) { vTrack = i; break }
            }
            if (vTrack < 0) { vex.release(); muxer.release(); return null }
            vex.selectTrack(vTrack)
            val vFmt = vex.getTrackFormat(vTrack)
            val vOut = muxer.addTrack(vFmt)
            // audio segments (decoded WAV -> AAC re-encode so every source format fits)
            val auds = ArrayList<Triple<Int, File, Float>>()   // mux track, decoded wav (volume baked in), 1
            for (seg in segs) {
                val wav = decodeSegToWav(seg, duration) ?: continue
                val aTrack = muxer.addTrack(MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 44100, 2).apply {
                    setInteger(MediaFormat.KEY_BIT_RATE, 192000)
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                })
                auds.add(Triple(aTrack, wav, 1f))   // volume ramp baked into the wav at decode time
                if (auds.size > 4) break       // muxer audio track limit safety
            }
            muxer.start()
            val buf = ByteBuffer.allocate(1 shl 16)
            val info = MediaCodec.BufferInfo()
            while (true) {
                info.offset = 0
                info.size = vex.readSampleData(buf, 0)
                if (info.size < 0) break
                info.presentationTimeUs = vex.sampleTime
                info.flags = vex.sampleFlags
                muxer.writeSampleData(vOut, buf, info)
                vex.advance()
            }
            vex.release()
            for ((track, wav, vol) in auds) {
                encodeWavInto(wav, muxer, track, vol)
            }
            muxer.stop()
            muxer.release()
            out
        } catch (_: Exception) { null }
    }

    /** Decode the wanted range of a media file's audio into a stereo WAV at native rate. */
    private fun decodeSegToWav(seg: AudioSeg, duration: Float): File? {
        val reader = AndroidAudioReader.open(seg.url.absolutePath) ?: return null
        try {
            val sr = reader.sampleRate.toInt()
            val tmp = File.createTempFile("seg", ".wav", Paths.appContext.cacheDir)
            val wav = Wav16Writer(tmp, reader.sampleRate)
            val startUs = (max(0f, seg.offset) * 1_000_000).toLong()
            val wantSec = max(0f, min(duration - seg.start, seg.end - seg.start))
            reader.seekToUs(startUs)
            val bufL = FloatArray(8192); val bufR = FloatArray(8192)
            var got = 0.0
            while (got < wantSec) {
                val n = reader.read(bufL, bufR, 8192)
                if (n <= 0) break
                // piecewise-linear volume ramp between the 0.05s samples (iOS setVolumeRamp twin)
                var vol = seg.vol.lastOrNull()?.second ?: 1f
                if (seg.vol.isNotEmpty()) {
                    val tSec = got + seg.start.toDouble()
                    val c = seg.vol
                    var i = 0
                    while (i < c.size - 2 && c[i + 1].first.toDouble() < tSec) i++
                    val a = c[i]; val b = c[i + 1]
                    val span = (b.first - a.first).toDouble()
                    val v = if (span <= 0.0) b.second.toDouble() else (a.second + (b.second - a.second) * ((tSec - a.first) / span).toFloat())
                    vol = v.toFloat()
                }
                if (vol != 1f) for (i in 0 until n) { bufL[i] *= vol; bufR[i] *= vol }
                wav.write(bufL, bufR, n)
                got += n.toDouble() / sr
            }
            wav.close()
            return tmp
        } catch (_: Exception) { return null } finally { reader.close() }
    }

    /** AAC-encode a WAV into the open muxer. */
    private fun encodeWavInto(wav: File, muxer: MediaMuxer, track: Int, vol: Float) {
        try {
            val reader = AndroidAudioReader.open(wav.absolutePath) ?: return
            val sr = reader.sampleRate.toInt()
            val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            val fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sr, 2).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, 192000)
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            }
            codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
            val info = MediaCodec.BufferInfo()
            val bufL = FloatArray(4096); val bufR = FloatArray(4096)
            var pts = 0L
            var eos = false
            while (true) {
                val inIdx = codec.dequeueInputBuffer(10_000)
                if (inIdx >= 0) {
                    val ib = codec.getInputBuffer(inIdx)!!
                    ib.clear()
                    val n = reader.read(bufL, bufR, 4096)
                    if (n <= 0) {
                        codec.queueInputBuffer(inIdx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        eos = true
                    } else {
                        // interleave 16-bit stereo
                        for (i in 0 until n) {
                            ib.putShort((min(1f, max(-1f, bufL[i])) * 32767f).toInt().toShort())
                            ib.putShort((min(1f, max(-1f, bufR[i])) * 32767f).toInt().toShort())
                        }
                        codec.queueInputBuffer(inIdx, 0, n * 4, pts, 0)
                        pts += n * 1_000_000L / sr
                    }
                }
                var outIdx = codec.dequeueOutputBuffer(info, 10_000)
                while (outIdx >= 0) {
                    val ob = codec.getOutputBuffer(outIdx)
                    if (ob != null && info.size > 0) {
                        info.presentationTimeUs = pts - info.presentationTimeUs + info.presentationTimeUs   // keep codec pts
                        muxer.writeSampleData(track, ob, info)
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    outIdx = codec.dequeueOutputBuffer(info, 0)
                }
                if (eos && outIdx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    // one more drain chance then bail
                    val last = codec.dequeueOutputBuffer(info, 100_000)
                    if (last < 0) return
                }
            }
        } catch (_: Exception) {
        } finally {
            // reader/codec released by loop exit
        }
    }

    private fun alnum(s: String): String =
        String(s.map { c -> if (c.isLetterOrDigit() && c.code < 128) c else '_' }.toCharArray())
}

/** Export progress (UI overlay reads it). */
object ExporterProgress {
    @Volatile var total = 0
    @Volatile var done = 0
    fun reset(totalFrames: Int) { total = totalFrames; done = 0 }
    fun add() { done++ }
    val fraction: Float get() = if (total > 0) done.toFloat() / total else 0f
}
