package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * FbxImport.swift — binary/ascii .fbx -> .glb converter (+ ".skel"/".noskel" and baked ".anim" sidecars).
 * Line-for-line port. UIImage -> Bitmap (BitmapFactory), CGContext pixel copies -> Bitmap scaling + premultiply helpers.
 * UIImage decodes EXIF-oriented and pngData() bakes that in (FbxImport.swift:430,447-458); the Bitmap twins apply the EXIF
 * orientation on decode (oriented() below: android.media.ExifInterface + Matrix).
 */
object FbxImport {
    @JvmStatic var lastError = ""

    sealed class PV {
        class I(val v: Long) : PV()
        class D(val v: Double) : PV()
        class S(val v: String) : PV()
        class Raw(val v: ByteArray) : PV()
        class AD(val v: DoubleArray) : PV()
        class AI(val v: LongArray) : PV()
    }
    class N {
        var name = ""; val p = ArrayList<PV>(); val c = ArrayList<N>()
        fun child(n: String): N? = c.firstOrNull { it.name == n }
        fun kids(n: String): List<N> = c.filter { it.name == n }
        val id: Long get() { val f = p.firstOrNull(); return if (f is PV.I) f.v else 0L }
        val str: String get() { for (q in p) if (q is PV.S) return q.v; return "" }
        val doubles: DoubleArray get() {
            for (q in p) { if (q is PV.AD) return q.v; if (q is PV.AI) return DoubleArray(q.v.size) { q.v[it].toDouble() } }
            return DoubleArray(0)
        }
        val ints: LongArray get() {
            for (q in p) { if (q is PV.AI) return q.v; if (q is PV.AD) return LongArray(q.v.size) { q.v[it].toLong() } }
            return LongArray(0)
        }
        fun num(i: Int): Double {
            if (i >= p.size) return 0.0
            val q = p[i]
            return when (q) { is PV.I -> q.v.toDouble(); is PV.D -> q.v; else -> 0.0 }
        }
    }


    // MARK: parse
    fun parse(b: ByteArray): List<N>? {
        if (!(b.size > 27 && String(b, 0, 20, Charsets.UTF_8) == "Kaydara FBX Binary")) return null
        fun by(i: Int) = b[i].toInt() and 0xFF
        val ver = by(23) or (by(24) shl 8) or (by(25) shl 16) or (by(26) shl 24)
        val wide = ver >= 7500
        var pos = 27
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        fun u32(o: Int): Long = if (o + 4 <= b.size) (by(o).toLong()) or (by(o + 1).toLong() shl 8) or (by(o + 2).toLong() shl 16) or (by(o + 3).toLong() shl 24) else 0L
        fun u64(o: Int): Long = u32(o) or (u32(o + 4) shl 32)

        fun readNode(): N? {
            val hdr = if (wide) 25 else 13
            if (pos + hdr > b.size) return null
            val end = if (wide) u64(pos) else u32(pos)
            val np = if (wide) u64(pos + 8) else u32(pos + 4)
            val nameLen = by(pos + (if (wide) 24 else 12))
            if (end == 0L) { pos += hdr; return null }
            pos += hdr
            if (!(pos + nameLen <= b.size && end <= b.size)) return null
            val n = N()
            n.name = String(b, pos, nameLen, Charsets.UTF_8)
            pos += nameLen
            var pi = 0L
            while (pi < np) {
                pi++
                if (pos >= b.size) break
                val t = by(pos); pos += 1
                when (t) {
                    0x59 -> { n.p.add(PV.I(bb.getShort(pos).toLong())); pos += 2 }
                    0x43 -> { n.p.add(PV.I(by(pos).toLong())); pos += 1 }
                    0x49 -> { n.p.add(PV.I(u32(pos).toInt().toLong())); pos += 4 }
                    0x46 -> { n.p.add(PV.D(bb.getFloat(pos).toDouble())); pos += 4 }
                    0x44 -> { n.p.add(PV.D(bb.getDouble(pos))); pos += 8 }
                    0x4C -> { n.p.add(PV.I(bb.getLong(pos))); pos += 8 }
                    0x53, 0x52 -> {
                        val l = u32(pos); pos += 4
                        val e2 = min(b.size.toLong(), pos + l).toInt()
                        val seg = b.copyOfRange(pos, e2); pos = (pos + l).toInt()
                        if (t == 0x53) {
                            var s = String(seg, Charsets.UTF_8)
                            val r = s.indexOf("\u0000\u0001")
                            if (r >= 0) s = s.substring(0, r)
                            n.p.add(PV.S(s))
                        } else n.p.add(PV.Raw(seg))
                    }
                    0x66, 0x64, 0x6C, 0x69, 0x62 -> {
                        val cnt = u32(pos); val enc = u32(pos + 4); val clen = u32(pos + 8); pos += 12
                        val es = if (t == 0x66 || t == 0x69) 4 else (if (t == 0x62) 1 else 8)
                        val e2 = min(b.size.toLong(), pos + clen).toInt()
                        var raw = b.copyOfRange(pos, e2); pos = (pos + clen).toInt()
                        if (enc == 1L) raw = VdbVolume.inflateZlib(raw)
                        if (raw.size.toLong() < cnt * es) { n.p.add(PV.AD(DoubleArray(0))) }
                        else {
                            val r = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
                            val c = cnt.toInt()
                            when (t) {
                                0x66 -> n.p.add(PV.AD(DoubleArray(c) { r.getFloat(it * 4).toDouble() }))
                                0x64 -> n.p.add(PV.AD(DoubleArray(c) { r.getDouble(it * 8) }))
                                0x6C -> n.p.add(PV.AI(LongArray(c) { r.getLong(it * 8) }))
                                0x69 -> n.p.add(PV.AI(LongArray(c) { r.getInt(it * 4).toLong() }))
                                else -> n.p.add(PV.AI(LongArray(c) { (raw[it].toInt() and 0xFF).toLong() }))
                            }
                        }
                    }
                    else -> return n
                }
            }
            while (pos < end) {
                val c = readNode()
                if (c == null) { if (pos < end && pos + hdr <= b.size && (if (wide) u64(pos) else u32(pos)) == 0L) pos += hdr; break }
                n.c.add(c)
            }
            pos = end.toInt()
            return n
        }
        val out = ArrayList<N>()
        while (pos + 13 < b.size) { val n = readNode() ?: break; out.add(n) }
        return out
    }

    // MARK: ASCII FBX
    fun parseAscii(b: ByteArray): List<N> {
        var i = 0
        val n = b.size
        fun by(k: Int) = b[k].toInt() and 0xFF
        fun ws(lines: Boolean = true) {
            while (i < n) {
                val c = by(i)
                if (c == 32 || c == 9 || c == 13 || (lines && c == 10)) i += 1
                else if (c == 59 && lines) { while (i < n && by(i) != 10) i += 1 }      // ; comment
                else break
            }
        }
        fun number(tok: String): PV? {
            val l = tok.toLongOrNull(); if (l != null) return PV.I(l)
            val d = tok.toDoubleOrNull(); if (d != null) return PV.D(d)
            return null
        }
        fun nodes(): ArrayList<N> {
            val out = ArrayList<N>()
            while (true) {
                ws()
                if (i >= n) return out
                if (by(i) == 125) { i += 1; return out }          // }
                var s0 = i
                while (i < n && by(i) != 58 && by(i) != 10 && by(i) != 123) i += 1       // name up to ':'
                if (!(i < n && by(i) == 58)) { i += 1; continue }
                val node = N(); node.name = String(b, s0, i - s0, Charsets.UTF_8).trim { it == ' ' || it == '\t' || Character.getType(it) == Character.SPACE_SEPARATOR.toInt() }
                i += 1
                var hasBlock = false
                while (true) {
                    ws(false)
                    if (i >= n) break
                    val c = by(i)
                    if (c == 10) break
                    if (c == 44) { i += 1; continue }
                    if (c == 123) { i += 1; hasBlock = true; break }
                    if (c == 42) {                                  // *N { a: ... }
                        i += 1; while (i < n && by(i) >= 48 && by(i) <= 57) i += 1
                        ws()
                        if (!(i < n && by(i) == 123)) continue
                        i += 1; ws()
                        if (i + 1 < n && by(i) == 97 && by(i + 1) == 58) i += 2          // a:
                        val vals = ArrayList<Double>()
                        while (i < n && by(i) != 125) {
                            ws()
                            s0 = i
                            while (i < n && by(i) != 44 && by(i) != 125 && by(i) != 32 && by(i) != 10 && by(i) != 13 && by(i) != 9) i += 1
                            if (i > s0) { val d = String(b, s0, i - s0, Charsets.UTF_8).toDoubleOrNull(); if (d != null) vals.add(d) }
                            ws(); if (i < n && by(i) == 44) i += 1
                        }
                        if (i < n) i += 1
                        node.p.add(PV.AD(vals.toDoubleArray())); continue
                    }
                    if (c == 34) {                                   // "string"
                        i += 1; s0 = i
                        while (i < n && by(i) != 34) i += 1
                        var str = String(b, s0, min(i, n) - s0, Charsets.UTF_8)
                        if (i < n) i += 1
                        if (node.name == "Content") {
                            val d = try { Base64.decode(str.filter { it.isLetterOrDigit() && it.code < 128 || it == '+' || it == '/' || it == '=' }, Base64.DEFAULT) } catch (_: Exception) { null }
                            if (d != null) { node.p.add(PV.Raw(d)); continue }
                        }
                        val r = str.indexOf("::")
                        if (r >= 0 && node.p.size == 1) str = str.substring(r + 2)       // "Model::Cube" -> "Cube"
                        node.p.add(PV.S(str)); continue
                    }
                    s0 = i
                    while (i < n && by(i) != 44 && by(i) != 10 && by(i) != 13 && by(i) != 123 && by(i) != 32) i += 1
                    val tok = String(b, s0, i - s0, Charsets.UTF_8)
                    if (i == s0) { i += 1; continue }
                    node.p.add(number(tok) ?: PV.S(tok))
                }
                if (hasBlock) { node.c.addAll(nodes()) }
                out.add(node)
            }
        }
        return nodes()
    }

    // MARK: helpers
    fun props(n: N?): Map<String, List<PV>> {
        val d = HashMap<String, List<PV>>()
        for (p in n?.child("Properties70")?.kids("P") ?: emptyList()) {
            val k = p.p.firstOrNull()
            if (k is PV.S) d[k.v] = p.p.drop(4)
        }
        return d
    }
    fun vec(pr: Map<String, List<PV>>, k: String, def: DoubleArray): DoubleArray {
        val v = pr[k] ?: return def
        val o = ArrayList<Double>()
        for (x in v) { if (x is PV.D) o.add(x.v) else if (x is PV.I) o.add(x.v.toDouble()) }
        return if (o.size >= def.size) o.toDoubleArray() else def
    }
    private fun mc(a: FloatArray) = M4(a)
    fun rotM(d: DoubleArray): M4 {
        fun rx(a: Float): M4 { val c = cos(a); val s = sin(a); return mc(floatArrayOf(1f, 0f, 0f, 0f, 0f, c, s, 0f, 0f, -s, c, 0f, 0f, 0f, 0f, 1f)) }
        fun ry(a: Float): M4 { val c = cos(a); val s = sin(a); return mc(floatArrayOf(c, 0f, -s, 0f, 0f, 1f, 0f, 0f, s, 0f, c, 0f, 0f, 0f, 0f, 1f)) }
        fun rz(a: Float): M4 { val c = cos(a); val s = sin(a); return mc(floatArrayOf(c, s, 0f, 0f, -s, c, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)) }
        val k = Math.PI.toFloat() / 180f
        return rz(d[2].toFloat() * k) * ry(d[1].toFloat() * k) * rx(d[0].toFloat() * k)
    }

    class Mat {
        var base = floatArrayOf(0.8f, 0.8f, 0.8f); var alpha = 1f; var metal = 0f; var rough = 0.8f; var emis = floatArrayOf(0f, 0f, 0f)
        val tex = HashMap<String, Long>()     // slot -> texture object id
    }

    private class FL { var a = FloatArray(256); var n = 0
        fun add(v: Float) { if (n == a.size) a = a.copyOf(n * 2); a[n++] = v }
        fun arr(): FloatArray = a.copyOf(n) }
    private class IL { var a = IntArray(256); var n = 0
        fun add(v: Int) { if (n == a.size) a = a.copyOf(n * 2); a[n++] = v }
        fun arr(): IntArray = a.copyOf(n) }
    private class Bk { val cp = IL(); val lp = FL(); val ln = FL(); val uv = FL() }
    private class Curve(val t: DoubleArray, val v: DoubleArray)
    private class Skin(val infl: Array<ArrayList<Pair<Int, Float>>>, val bones: List<Long>, val bindM: List<M4>)
    private class PInfo(val mid: Long, val bk: Bk, val skin: Skin?)
    private class Layer { var vals = DoubleArray(0); var idx = LongArray(0); var byPoly = false; var direct = true; var all = false }

    private fun deletingPathExtension(p: String): String {
        val slash = p.lastIndexOf('/')
        val name = p.substring(slash + 1)
        val dot = name.lastIndexOf('.')
        return if (dot > 0) p.substring(0, slash + 1 + dot) else p
    }
    /** BitmapFactory.decodeFile + EXIF orientation baked in (UIImage semantics). */
    private fun decodeOrientedFile(path: String): Bitmap? =
        oriented(BitmapFactory.decodeFile(path)) { try { android.media.ExifInterface(path) } catch (_: Exception) { null } }

    /** Applies the EXIF orientation matrix so pixels match UIImage/CGImage (which always carry it baked). */
    private fun oriented(bmp: Bitmap?, exif: () -> android.media.ExifInterface?): Bitmap? {
        if (bmp == null) return null
        val o = try {
            exif()?.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL)
                ?: android.media.ExifInterface.ORIENTATION_NORMAL
        } catch (_: Exception) { android.media.ExifInterface.ORIENTATION_NORMAL }
        val m = android.graphics.Matrix()
        when (o) {
            android.media.ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            android.media.ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            android.media.ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            android.media.ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            android.media.ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            android.media.ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            android.media.ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return bmp
        }
        return try { Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true) } catch (_: Exception) { bmp }
    }

    private fun png(bmp: Bitmap): ByteArray? {
        val o = ByteArrayOutputStream()
        return if (bmp.compress(Bitmap.CompressFormat.PNG, 100, o)) o.toByteArray() else null
    }
    /** CGContext RGBA (premultipliedLast) copy of img scaled to w x h. */
    private fun pixels(img: Bitmap, w: Int, h: Int): ByteArray? {
        if (w <= 0 || h <= 0) return null
        val sc = if (img.width == w && img.height == h) img else Bitmap.createScaledBitmap(img, w, h, true)
        val px = IntArray(w * h); sc.getPixels(px, 0, w, 0, 0, w, h)
        val d = ByteArray(w * h * 4) { 255.toByte() }
        for (i in 0 until w * h) {
            val p = px[i]; val a = (p ushr 24) and 0xFF
            val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val bl = p and 0xFF
            d[i * 4] = ((r * a + 127) / 255).toByte(); d[i * 4 + 1] = ((g * a + 127) / 255).toByte()
            d[i * 4 + 2] = ((bl * a + 127) / 255).toByte(); d[i * 4 + 3] = a.toByte()
        }
        return d
    }
    /** RGBA premultiplied -> PNG bytes (un-premultiplied, like CGImage -> pngData). */
    private fun pngFromPixels(d: ByteArray, w: Int, h: Int): ByteArray? {
        val px = IntArray(w * h)
        for (i in 0 until w * h) {
            val a = d[i * 4 + 3].toInt() and 0xFF
            var r = d[i * 4].toInt() and 0xFF; var g = d[i * 4 + 1].toInt() and 0xFF; var bl = d[i * 4 + 2].toInt() and 0xFF
            if (a == 0) { r = 0; g = 0; bl = 0 } else if (a < 255) { r = min(255, (r * 255 + a / 2) / a); g = min(255, (g * 255 + a / 2) / a); bl = min(255, (bl * 255 + a / 2) / a) }
            px[i] = (a shl 24) or (r shl 16) or (g shl 8) or bl
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPremultiplied(false)
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return png(bmp)
    }
    private fun fbytes(a: FloatArray): ByteArray { val bb = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (v in a) bb.putFloat(v); return bb.array() }
    private fun ibytes(a: IntArray): ByteArray { val bb = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (v in a) bb.putInt(v); return bb.array() }
    private fun farr(v: FloatArray) = JSONArray().also { a -> for (x in v) a.put(x) }
    private fun farr(v: Float, w: Float) = farr(floatArrayOf(v, w))   // was: farr(vararg Float) — same JVM signature as FloatArray
    private fun farr(v: Float, w: Float, x: Float) = farr(floatArrayOf(v, w, x))
    private fun farr(v: Float, w: Float, x: Float, y: Float) = farr(floatArrayOf(v, w, x, y))
    private fun mat4(d: DoubleArray?): M4 {
        if (d == null || d.size < 16) return M4.identity()
        return M4(FloatArray(16) { d[it].toFloat() })
    }

    // MARK: convert
    /** Returns the .glb written beside the .fbx (cached by modification date), or null with lastError set. */
    fun convert(path: String): String? {
        lastError = ""
        val stem = deletingPathExtension(path)
        val out = "${stem}_fbx.glb"
        val pf = File(path); val of = File(out)
        if (pf.exists() && of.exists() && of.lastModified() > pf.lastModified() &&
            (File("$out.skel").exists() || File("$out.noskel").exists())) return out
        val bytes = try { pf.readBytes() } catch (_: Exception) { null }
        if (bytes == null) { lastError = "Cannot read the FBX file"; return null }
        val isBin = bytes.size > 20 && String(bytes, 0, 18, Charsets.UTF_8) == "Kaydara FBX Binary"
        val rootsOpt: List<N>? = try { if (isBin) parse(bytes) else parseAscii(bytes) } catch (_: Exception) { null }
        if (rootsOpt == null || rootsOpt.none { it.name == "Objects" }) { lastError = "Not a readable FBX file"; return null }
        val roots: List<N> = rootsOpt
        try { File("$out.anim").delete() } catch (_: Exception) {}
        val objects = roots.firstOrNull { it.name == "Objects" }
        if (objects == null) { lastError = "FBX has no objects"; return null }
        val dir = pf.parent ?: ""
        val stemName = stem.substringAfterLast('/')

        val geoms = HashMap<Long, N>(); val models = HashMap<Long, N>(); val mats = HashMap<Long, N>(); val texs = HashMap<Long, N>(); val vids = HashMap<Long, N>()
        val cnodes = HashMap<Long, N>(); val curvesRaw = HashMap<Long, N>(); val deformers = HashMap<Long, N>()
        for (o in objects.c) {
            when (o.name) {
                "Geometry" -> if (o.p.size > 2) { val q = o.p[2]; if (q is PV.S && q.v == "Mesh") geoms[o.id] = o }
                "Model" -> models[o.id] = o
                "Material" -> mats[o.id] = o
                "Texture" -> texs[o.id] = o
                "Video" -> vids[o.id] = o
                "AnimationCurveNode" -> cnodes[o.id] = o
                "AnimationCurve" -> curvesRaw[o.id] = o
                "Deformer" -> deformers[o.id] = o
            }
        }
        // connections
        val parentOf = HashMap<Long, Long>()
        val modelGeom = HashMap<Long, Long>(); val modelMats = HashMap<Long, ArrayList<Long>>()
        val matTex = HashMap<Long, ArrayList<Pair<String, Long>>>(); val texVid = HashMap<Long, Long>()
        val geomSkin = HashMap<Long, Long>(); val skinClusters = HashMap<Long, ArrayList<Long>>(); val clusterBone = HashMap<Long, Long>()
        val cnModel = HashMap<Long, Pair<Long, String>>(); val cnCurves = HashMap<Long, ArrayList<Pair<String, Long>>>()
        for (c in roots.firstOrNull { it.name == "Connections" }?.c ?: emptyList()) {
            if (c.name != "C") continue
            val kq = c.p.firstOrNull()
            if (kq !is PV.S || c.p.size < 3) continue
            val kind = kq.v
            val ch = c.num(1).toLong(); val pa = c.num(2).toLong()
            var prop = ""
            if (c.p.size > 3) { val q = c.p[3]; if (q is PV.S) prop = q.v }
            if (kind == "OO") {
                if (models[ch] != null && (models[pa] != null || pa == 0L)) parentOf[ch] = pa
                else if (geoms[ch] != null && models[pa] != null) modelGeom[pa] = ch
                else if (mats[ch] != null && models[pa] != null) modelMats.getOrPut(pa) { ArrayList() }.add(ch)
                else if (vids[ch] != null && texs[pa] != null) texVid[pa] = ch
                else if (deformers[ch] != null && geoms[pa] != null) geomSkin[pa] = ch
                else if (deformers[ch] != null && deformers[pa] != null) skinClusters.getOrPut(pa) { ArrayList() }.add(ch)
                else if (models[ch] != null && deformers[pa] != null) clusterBone[pa] = ch
            } else if (kind == "OP") {
                if (texs[ch] != null && mats[pa] != null) matTex.getOrPut(pa) { ArrayList() }.add(Pair(prop, ch))
                else if (curvesRaw[ch] != null && cnodes[pa] != null) cnCurves.getOrPut(pa) { ArrayList() }.add(Pair(prop, ch))
                else if (cnodes[ch] != null && models[pa] != null) cnModel[ch] = Pair(pa, prop)
            }
        }
        // global settings: up axis
        val gs = props(roots.firstOrNull { it.name == "GlobalSettings" })
        val upAxis = vec(gs, "UpAxis", doubleArrayOf(1.0))[0].toInt()
        val fix: M4 = if (upAxis == 2) mc(floatArrayOf(1f, 0f, 0f, 0f, 0f, 0f, -1f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f)) else M4.identity()

        // animation curves (Lcl Translation / Rotation / Scaling), times in seconds
        val anim = HashMap<Long, HashMap<String, Array<Curve?>>>()
        var tMin = Double.POSITIVE_INFINITY; var tMax = 0.0
        val curveKeys = mapOf("d|X" to 0, "d|Y" to 1, "d|Z" to 2)
        for ((cn, mp) in cnModel) {
            val arr = arrayOfNulls<Curve>(3)
            for ((prop, cid) in cnCurves[cn] ?: ArrayList()) {
                val k = curveKeys[prop] ?: continue
                val c = curvesRaw[cid] ?: continue
                val times = (c.child("KeyTime")?.ints ?: LongArray(0)).let { a -> DoubleArray(a.size) { a[it].toDouble() / 46186158000.0 } }
                val vals = c.child("KeyValueFloat")?.doubles ?: DoubleArray(0)
                val cnt = min(times.size, vals.size); if (cnt == 0) continue
                arr[k] = Curve(times.copyOfRange(0, cnt), vals.copyOfRange(0, cnt))
                tMin = min(tMin, times[0]); tMax = max(tMax, times[cnt - 1])
            }
            anim.getOrPut(mp.first) { HashMap() }[mp.second] = arr
        }
        val animated = anim.isNotEmpty() && tMax > tMin + 1e-6
        fun sample(c: Curve, t: Double): Double {
            if (t <= c.t[0]) return c.v[0]
            if (t >= c.t[c.t.size - 1]) return c.v[c.v.size - 1]
            var lo = 0; var hi = c.t.size - 1
            while (hi - lo > 1) { val m = (lo + hi) / 2; if (c.t[m] <= t) lo = m else hi = m }
            val f = (t - c.t[lo]) / max(c.t[hi] - c.t[lo], 1e-12)
            return c.v[lo] + (c.v[hi] - c.v[lo]) * f
        }
        val modelProps = HashMap<Long, Map<String, List<PV>>>()
        for ((id, m) in models) modelProps[id] = props(m)
        /** World matrices at time t (seconds; null = static values). Roots get the up-axis fix. */
        fun makeWorld(t: Double?): (Long) -> M4 {
            val cache = HashMap<Long, M4>()
            fun trs(id: Long, key: String, base: DoubleArray): DoubleArray {
                val arr = if (t != null) anim[id]?.get(key) else null
                if (t == null || arr == null) return base
                val o = base.copyOf()
                for (i in 0 until 3) { val c = arr[i]; if (c != null) o[i] = sample(c, t) }
                return o
            }
            fun w(id: Long, depth: Int): M4 {
                cache[id]?.let { return it }
                val pr = modelProps[id]
                if (pr == null || depth >= 64) return M4.identity()
                val tt = trs(id, "Lcl Translation", vec(pr, "Lcl Translation", doubleArrayOf(0.0, 0.0, 0.0)))
                val r = trs(id, "Lcl Rotation", vec(pr, "Lcl Rotation", doubleArrayOf(0.0, 0.0, 0.0)))
                val s = trs(id, "Lcl Scaling", vec(pr, "Lcl Scaling", doubleArrayOf(1.0, 1.0, 1.0)))
                val pre = vec(pr, "PreRotation", doubleArrayOf(0.0, 0.0, 0.0))
                val T = M4.identity(); T.setCol(3, V4(tt[0].toFloat(), tt[1].toFloat(), tt[2].toFloat(), 1f))
                val S = M4.identity(); S.m[0] = s[0].toFloat(); S.m[5] = s[1].toFloat(); S.m[10] = s[2].toFloat()
                val local = T * rotM(pre) * rotM(r) * S
                val par = parentOf[id] ?: 0L
                val res = (if (par != 0L) w(par, depth + 1) else fix) * local
                cache[id] = res
                return res
            }
            return { w(it, 0) }
        }
        // skins: per control point up to 4 (cluster, weight); bind = inverse(TransformLink) * Transform
        val skins = HashMap<Long, Skin>()
        for ((gid, sid) in geomSkin) {
            val bones = ArrayList<Long>(); val bindM = ArrayList<M4>()
            val infl = Array((geoms[gid]?.child("Vertices")?.doubles?.size ?: 0) / 3) { ArrayList<Pair<Int, Float>>() }
            for (cid in skinClusters[sid] ?: ArrayList()) {
                val cl = deformers[cid] ?: continue
                val bone = clusterBone[cid] ?: continue
                val ci = bones.size; bones.add(bone)
                bindM.add(mat4(cl.child("TransformLink")?.doubles).inverse() * mat4(cl.child("Transform")?.doubles))
                val idx = cl.child("Indexes")?.ints ?: LongArray(0); val wts = cl.child("Weights")?.doubles ?: DoubleArray(0)
                for ((i, v) in idx.withIndex()) if (i < wts.size && v >= 0 && v.toInt() < infl.size) infl[v.toInt()].add(Pair(ci, wts[i].toFloat()))
            }
            for (i in infl.indices) if (infl[i].size > 4) { val s = infl[i].sortedByDescending { it.second }.take(4); infl[i] = ArrayList(s) }
            if (bones.isNotEmpty()) skins[gid] = Skin(infl, bones, bindM)
        }
        val tStart: Double? = if (animated) tMin else null
        val world0 = makeWorld(tStart)

        // materials
        fun readMat(n: N): Mat {
            val m = Mat(); val pr = props(n)
            fun f(k: String, d: Double): Double = vec(pr, k, doubleArrayOf(d))[0]
            var df = 1.0
            for (k in listOf("DiffuseColor", "BaseColor", "base_color", "Maya|baseColor", "Maya|base_color")) if (pr[k] != null) {
                val v = vec(pr, k, doubleArrayOf(0.8, 0.8, 0.8)); m.base = floatArrayOf(v[0].toFloat(), v[1].toFloat(), v[2].toFloat()); break
            }
            for (k in listOf("DiffuseFactor", "Maya|base", "BaseColorFactor")) if (pr[k] != null) { df = f(k, 1.0); break }
            m.base = FloatArray(3) { m.base[it] * df.toFloat() }
            if (pr["TransparencyFactor"] != null) m.alpha = (1 - f("TransparencyFactor", 0.0)).toFloat()
            else if (pr["Opacity"] != null) m.alpha = f("Opacity", 1.0).toFloat()
            if (pr["TransparentColor"] != null && pr["TransparencyFactor"] == null && m.alpha >= 1) {
                val v = vec(pr, "TransparentColor", doubleArrayOf(0.0, 0.0, 0.0)); m.alpha = (1 - (v[0] + v[1] + v[2]) / 3).toFloat()
            }
            if (m.alpha < 0.001f) m.alpha = 1f       // exporters that write 100 % transparency by mistake
            val ec = vec(pr, "EmissiveColor", doubleArrayOf(0.0, 0.0, 0.0)); val ef = if (pr["EmissiveFactor"] != null) f("EmissiveFactor", 1.0) else 1.0
            m.emis = floatArrayOf((ec[0] * ef).toFloat(), (ec[1] * ef).toFloat(), (ec[2] * ef).toFloat())
            for (k in listOf("Metallic", "Maya|metalness", "metallic", "ReflectionFactor")) if (pr[k] != null) { m.metal = min(max(f(k, 0.0), 0.0), 1.0).toFloat(); break }
            var gotR = false
            for (k in listOf("Roughness", "Maya|roughness", "roughness")) if (pr[k] != null) { m.rough = min(max(f(k, 0.8), 0.0), 1.0).toFloat(); gotR = true; break }
            if (!gotR) {
                val sh = pr["ShininessExponent"] ?: pr["Shininess"]
                val e = sh?.lastOrNull()
                if (e is PV.D) m.rough = min(max(sqrt(2.0 / (e.v + 2.0)), 0.05), 1.0).toFloat()
            }
            return m
        }
        fun slot(p: String): String? {
            val l = p.lowercase(java.util.Locale.ROOT)
            if (l.contains("specular")) return null
            if (l.contains("normal") || l.contains("bump")) return "normal"
            if (l.contains("emis") || l.contains("glow")) return "emis"
            if (l.contains("rough") || l.contains("shininess") || l.contains("glossi")) return "rough"
            if (l.contains("metal") || l.contains("reflectionfactor")) return "metal"
            if (l.contains("occlusion") || l.endsWith("ao") || l.contains("|ao")) return "ao"
            if (l.contains("opacity") || l.contains("transparen")) return "opacity"
            if (l.contains("diffuse") || l.contains("base") || l.contains("color")) return "base"
            return null
        }
        // textures -> image data
        val imgCache = HashMap<Long, Bitmap>()
        fun image(tid: Long): Bitmap? {
            imgCache[tid]?.let { return it }
            val t = texs[tid] ?: return null
            var img: Bitmap? = null
            val vid = texVid[tid]?.let { vids[it] }
            if (vid != null) {
                val cn = vid.child("Content"); val r0 = cn?.p?.firstOrNull()
                if (r0 is PV.Raw && r0.v.size > 16) img = oriented(BitmapFactory.decodeByteArray(r0.v, 0, r0.v.size)) { try { android.media.ExifInterface(java.io.ByteArrayInputStream(r0.v)) } catch (_: Exception) { null } }
            }
            if (img == null) {
                val names = ArrayList<String>()
                for (k in listOf("RelativeFilename", "FileName")) { val n = t.child(k)?.str; if (n != null && n.isNotEmpty()) names.add(n) }
                if (vid != null) for (k in listOf("RelativeFilename", "FileName")) { val n = vid.child(k)?.str; if (n != null && n.isNotEmpty()) names.add(n) }
                val all = File(dir).list()?.toList() ?: emptyList()
                for (n in names) {
                    val leaf = n.replace("\\", "/").substringAfterLast('/').lowercase(java.util.Locale.ROOT)
                    val f = all.firstOrNull { it.lowercase(java.util.Locale.ROOT) == leaf || it.lowercase(java.util.Locale.ROOT) == (stemName + "_tex_" + leaf).lowercase(java.util.Locale.ROOT) }
                    if (f != null) { img = decodeOrientedFile("$dir/$f"); if (img != null) break }
                }
            }
            if (img != null) imgCache[tid] = img
            return img
        }

        // GLB assembly
        val bin = ByteArrayOutputStream()
        val views = JSONArray(); val accs = JSONArray(); val images = JSONArray(); val textures = JSONArray()
        fun addView(bytes: ByteArray, target: Int? = null): Int {
            while (bin.size() % 4 != 0) bin.write(0)
            val v = JSONObject(); v.put("buffer", 0); v.put("byteOffset", bin.size()); v.put("byteLength", bytes.size)
            if (target != null) v.put("target", target)
            bin.write(bytes); views.put(v); return views.length() - 1
        }
        val texIndexForData = HashMap<ByteBuffer, Int>()
        fun addTexture(data: ByteArray): Int {
            val key = ByteBuffer.wrap(data)
            texIndexForData[key]?.let { return it }
            val v = addView(data)
            images.put(JSONObject().put("bufferView", v).put("mimeType", "image/png"))
            textures.put(JSONObject().put("source", images.length() - 1)); texIndexForData[key] = textures.length() - 1
            return textures.length() - 1
        }
        // PBR maps that travelled beside the model (zip from Blender etc.): "<stem>_tex_<file>" or "<stem>*" image files
        fun discover(matName: String, single: Boolean): HashMap<String, Bitmap> {
            val outm = HashMap<String, Bitmap>()
            val all = File(dir).list() ?: return outm
            val exts = setOf("png", "jpg", "jpeg", "tif", "tiff", "bmp")
            val sl = stemName.lowercase(java.util.Locale.ROOT); val mn = matName.lowercase(java.util.Locale.ROOT)
            for (f in all.sorted()) {
                val l = f.lowercase(java.util.Locale.ROOT)
                if (!(exts.contains(l.substringAfterLast('.', "")) && l.startsWith(sl))) continue
                if (!single && (mn.isEmpty() || !l.contains(mn))) continue
                val nm = deletingPathExtension(l)
                var k: String? = null
                if (nm.contains("metallicroughness") || nm.endsWith("_orm") || nm.endsWith("_mr") || nm.endsWith("_arm")) k = "orm"
                else if (nm.contains("normal") || nm.endsWith("_nrm") || nm.endsWith("_nor") || nm.endsWith("_n")) k = "normal"
                else if (nm.contains("rough") || nm.contains("glossi")) k = "rough"
                else if (nm.contains("metal")) k = "metal"
                else if (nm.contains("occlusion") || nm.endsWith("_ao") || nm.contains("ambient")) k = "ao"
                else if (nm.contains("emis") || nm.contains("glow")) k = "emis"
                else if (nm.contains("opacity") || nm.contains("alpha") || nm.contains("transp")) k = "opacity"
                else if (nm.contains("basecolor") || nm.contains("base_color") || nm.contains("albedo") || nm.contains("diffuse") || nm.endsWith("_color") || nm.endsWith("_col") || nm.endsWith("_base")) k = "base"
                if (k != null && outm[k] == null) { val im = decodeOrientedFile("$dir/$f"); if (im != null) outm[k] = im }
            }
            return outm
        }
        val matJson = JSONArray(); val matIndex = HashMap<Long, Int>()
        fun glMat(id: Long): Int {
            matIndex[id]?.let { return it }
            val m = if (id == 0L) Mat() else readMat(mats[id]!!)
            val pbr = JSONObject(); pbr.put("baseColorFactor", farr(m.base[0], m.base[1], m.base[2], m.alpha)); pbr.put("metallicFactor", m.metal); pbr.put("roughnessFactor", m.rough)
            val j = JSONObject(); j.put("doubleSided", true)
            val imgs = HashMap<String, Bitmap>()
            for ((p, t) in matTex[id] ?: ArrayList()) { val k = slot(p); if (k != null && imgs[k] == null) { val im = image(t); if (im != null) imgs[k] = im } }
            for ((k, v) in discover(if (id == 0L) "" else mats[id]!!.str, mats.size <= 1)) if (imgs[k] == null) imgs[k] = v
            val baseImg = imgs["base"]
            if (baseImg != null) {
                var imgOut = baseImg
                val oi = imgs["opacity"]
                if (oi != null) {         // separate opacity map -> base alpha
                    val w = min(2048, baseImg.width); val h = min(2048, baseImg.height)
                    val a = pixels(baseImg, w, h); val b = pixels(oi, w, h)
                    if (a != null && b != null) {
                        for (i in 0 until w * h) a[i * 4 + 3] = b[i * 4]
                        val d = pngFromPixels(a, w, h); val u = d?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                        if (u != null) imgOut = u
                    }
                    j.put("alphaMode", "BLEND")
                }
                val d = png(imgOut)
                if (d != null) { pbr.put("baseColorTexture", JSONObject().put("index", addTexture(d))); pbr.put("baseColorFactor", farr(1f, 1f, 1f, m.alpha)) }
            }
            val orm = imgs["orm"]
            val ormData = if (orm != null && imgs["rough"] == null && imgs["metal"] == null) png(orm) else null
            if (orm != null && ormData != null) {
                pbr.put("metallicRoughnessTexture", JSONObject().put("index", addTexture(ormData))); pbr.put("roughnessFactor", 1); pbr.put("metallicFactor", 1)
                if (imgs["ao"] == null) imgs["ao"] = orm
            } else if (imgs["rough"] != null || imgs["metal"] != null) {
                val rI = imgs["rough"]; val mI = imgs["metal"]
                val ref = rI ?: mI!!
                val w = min(2048, ref.width); val h = min(2048, ref.height)
                val d = ByteArray(w * h * 4) { 255.toByte() }
                val rp = rI?.let { pixels(it, w, h) }; val mp = mI?.let { pixels(it, w, h) }
                for (i in 0 until w * h) {
                    d[i * 4] = 255.toByte()
                    d[i * 4 + 1] = rp?.get(i * 4) ?: (min(max(m.rough, 0f), 1f) * 255f).toInt().toByte()
                    d[i * 4 + 2] = mp?.get(i * 4) ?: (min(max(m.metal, 0f), 1f) * 255f).toInt().toByte()
                }
                val data = pngFromPixels(d, w, h)
                if (data != null) { pbr.put("metallicRoughnessTexture", JSONObject().put("index", addTexture(data))); pbr.put("roughnessFactor", 1); pbr.put("metallicFactor", 1) }
            }
            val nI = imgs["normal"]; val nD = nI?.let { png(it) }
            if (nD != null) j.put("normalTexture", JSONObject().put("index", addTexture(nD)))
            val eI = imgs["emis"]; val eD = eI?.let { png(it) }
            if (eD != null) { j.put("emissiveTexture", JSONObject().put("index", addTexture(eD))); j.put("emissiveFactor", farr(1f, 1f, 1f)) }
            else if (!(m.emis[0] == 0f && m.emis[1] == 0f && m.emis[2] == 0f)) j.put("emissiveFactor", farr(m.emis))
            val aI = imgs["ao"]; val aD = aI?.let { png(it) }
            if (aD != null) j.put("occlusionTexture", JSONObject().put("index", addTexture(aD)))
            if (m.alpha < 0.999f) j.put("alphaMode", "BLEND")
            j.put("pbrMetallicRoughness", pbr)
            matJson.put(j); matIndex[id] = matJson.length() - 1
            return matJson.length() - 1
        }

        fun m3inv(M: M4): Array<V3> {       // columns of inverse(m3(M)).transpose
            val c0 = V3(M.m[0], M.m[1], M.m[2]); val c1 = V3(M.m[4], M.m[5], M.m[6]); val c2 = V3(M.m[8], M.m[9], M.m[10])
            val det = dot(c0, cross(c1, c2))
            return arrayOf(cross(c1, c2) / det, cross(c2, c0) / det, cross(c0, c1) / det)
        }
        /** World-space positions + normals of one primitive at a given pose (rigid or skinned). */
        fun posed(b: Bk, mid: Long, skin: Skin?, W: (Long) -> M4): Pair<FloatArray, FloatArray> {
            val n = b.cp.n
            val P = FloatArray(n * 3); val Nn = FloatArray(n * 3)
            val Wm = W(mid); val NM = m3inv(Wm)
            val bm = ArrayList<M4>()
            if (skin != null) for ((i, bone) in skin.bones.withIndex()) bm.add(W(bone) * skin.bindM[i])
            val cpB = arrayOfNulls<M4>(skin?.infl?.size ?: 0)
            for (k in 0 until n) {
                val p = V4(b.lp.a[k * 3], b.lp.a[k * 3 + 1], b.lp.a[k * 3 + 2], 1f); val nl = V3(b.ln.a[k * 3], b.ln.a[k * 3 + 1], b.ln.a[k * 3 + 2])
                var M: M4? = null
                if (skin != null) {
                    val ci = b.cp.a[k]
                    if (ci < cpB.size) {
                        val cc = cpB[ci]
                        if (cc != null) M = cc
                        else {
                            val inf = skin.infl[ci]
                            var tw = 0f; val acc = FloatArray(16)
                            for ((c, w) in inf) { val s = bm[c].m; for (q in 0 until 16) acc[q] += w * s[q]; tw += w }
                            if (tw > 1e-6f) { val s = 1f / tw; for (q in 0 until 16) acc[q] = s * acc[q]; val am = M4(acc); cpB[ci] = am; M = am }
                        }
                    }
                }
                val wp: V4; val nw: V3
                if (M != null) { wp = M * p; nw = V3(M.m[0], M.m[1], M.m[2]) * nl.x + V3(M.m[4], M.m[5], M.m[6]) * nl.y + V3(M.m[8], M.m[9], M.m[10]) * nl.z }
                else { wp = Wm * p; nw = NM[0] * nl.x + NM[1] * nl.y + NM[2] * nl.z }
                val nn = if (length(nw) > 1e-9f) normalize(nw) else V3(0f, 1f, 0f)
                P[k * 3] = wp.x; P[k * 3 + 1] = wp.y; P[k * 3 + 2] = wp.z
                Nn[k * 3] = nn.x; Nn[k * 3 + 1] = nn.y; Nn[k * 3 + 2] = nn.z
            }
            return Pair(P, Nn)
        }
        val infos = ArrayList<PInfo>()
        val prims = JSONArray()
        for (mid in models.keys.sorted()) {
            val gid = modelGeom[mid] ?: continue
            val g = geoms[gid] ?: continue
            val verts = g.child("Vertices")?.doubles ?: DoubleArray(0); val pvi = g.child("PolygonVertexIndex")?.ints ?: LongArray(0)
            if (verts.size < 9 || pvi.size < 3) continue
            fun layer(nm: String, vk: String, ik: String): Layer? {
                val e = g.child(nm) ?: return null
                val L = Layer(); L.vals = e.child(vk)?.doubles ?: DoubleArray(0); L.idx = e.child(ik)?.ints ?: LongArray(0)
                val mp = e.child("MappingInformationType")?.str ?: ""; val rf = e.child("ReferenceInformationType")?.str ?: "Direct"
                L.byPoly = mp == "ByPolygonVertex"; L.all = mp == "AllSame"; L.direct = rf == "Direct"
                return L
            }
            val nL = layer("LayerElementNormal", "Normals", "NormalsIndex"); val uL = layer("LayerElementUV", "UV", "UVIndex")
            val mL = layer("LayerElementMaterial", "Materials", "Materials")
            val me = g.child("LayerElementMaterial")
            if (me != null && mL != null) { mL.idx = me.child("Materials")?.ints ?: LongArray(0); mL.all = (me.child("MappingInformationType")?.str ?: "") == "AllSame" }
            val mlist = modelMats[mid] ?: ArrayList()
            val bySlot = HashMap<Int, Bk>()
            var polyNo = 0
            fun lookup(L: Layer?, comps: Int, vi: Int, pv: Int): FloatArray? {
                if (L == null) return null
                var k = if (L.byPoly) pv else (if (L.all) 0 else vi)
                if (!L.direct) { if (k >= L.idx.size) return null; k = L.idx[k].toInt() }
                if (!(k >= 0 && (k + 1) * comps <= L.vals.size)) return null
                return FloatArray(comps) { L.vals[k * comps + it].toFloat() }
            }
            fun emit(cv: IntArray, cpv: IntArray, cn: Int, pn: Int) {
                var sl = 0
                if (mL != null) sl = if (mL.all) (mL.idx.firstOrNull() ?: 0L).toInt() else (if (pn < mL.idx.size) mL.idx[pn].toInt() else 0)
                // Swift returns without storing the polygon when a corner is out of range (struct copy), so validate first
                if (cn >= 3) for (q in 0 until cn) { if (!(cv[q] >= 0 && cv[q] * 3 + 2 < verts.size)) return }
                val b = bySlot.getOrPut(sl) { Bk() }
                for (t in 1 until cn - 1) {
                    val cs = intArrayOf(0, t, t + 1)
                    val lps = ArrayList<V3>()
                    for (c in cs) { val vi = cv[c]; lps.add(V3(verts[vi * 3].toFloat(), verts[vi * 3 + 1].toFloat(), verts[vi * 3 + 2].toFloat())) }
                    val fn = cross(lps[1] - lps[0], lps[2] - lps[0])
                    val fnn = if (length(fn) > 1e-12f) normalize(fn) else V3(0f, 1f, 0f)
                    for ((k, c) in cs.withIndex()) {
                        b.cp.add(cv[c]); b.lp.add(lps[k].x); b.lp.add(lps[k].y); b.lp.add(lps[k].z)
                        val nv = lookup(nL, 3, cv[c], cpv[c])
                        if (nv != null) { b.ln.add(nv[0]); b.ln.add(nv[1]); b.ln.add(nv[2]) } else { b.ln.add(fnn.x); b.ln.add(fnn.y); b.ln.add(fnn.z) }
                        val u = lookup(uL, 2, cv[c], cpv[c])
                        if (u != null) { b.uv.add(u[0]); b.uv.add(1 - u[1]) } else { b.uv.add(0f); b.uv.add(0f) }
                    }
                }
            }
            val cvl = IL(); val cpl = IL()
            for ((k, raw) in pvi.withIndex()) {
                val end = raw < 0; val vi = (if (end) raw.inv() else raw).toInt()
                cvl.add(vi); cpl.add(k)
                if (end) { emit(cvl.a, cpl.a, cvl.n, polyNo); cvl.n = 0; cpl.n = 0; polyNo += 1 }
            }
            for (sl in bySlot.keys.sorted()) {
                val b = bySlot[sl]!!
                if (b.cp.n == 0) continue
                val (pos, nor) = posed(b, mid, skins[gid], world0)
                val mn = floatArrayOf(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                val mx = floatArrayOf(Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY)
                var k = 0; while (k + 2 < pos.size) { for (c in 0 until 3) { mn[c] = min(mn[c], pos[k + c]); mx[c] = max(mx[c], pos[k + c]) }; k += 3 }
                val uvA = b.uv.arr()
                val vP = addView(fbytes(pos), 34962); val vN = addView(fbytes(nor), 34962); val vU = addView(fbytes(uvA), 34962)
                val vI = addView(ibytes(IntArray(b.cp.n) { it }), 34963)
                accs.put(JSONObject().put("bufferView", vP).put("componentType", 5126).put("count", pos.size / 3).put("type", "VEC3").put("min", farr(mn)).put("max", farr(mx))); val aP = accs.length() - 1
                accs.put(JSONObject().put("bufferView", vN).put("componentType", 5126).put("count", nor.size / 3).put("type", "VEC3")); val aN = accs.length() - 1
                accs.put(JSONObject().put("bufferView", vU).put("componentType", 5126).put("count", uvA.size / 2).put("type", "VEC2")); val aU = accs.length() - 1
                accs.put(JSONObject().put("bufferView", vI).put("componentType", 5125).put("count", b.cp.n).put("type", "SCALAR")); val aI = accs.length() - 1
                prims.put(JSONObject().put("attributes", JSONObject().put("POSITION", aP).put("NORMAL", aN).put("TEXCOORD_0", aU)).put("indices", aI).put("mode", 4)
                    .put("material", glMat(if (sl >= 0 && sl < mlist.size) mlist[sl] else 0L)))
                infos.add(PInfo(mid, b, skins[gid]))
            }
        }
        if (prims.length() == 0) { lastError = "FBX has no mesh geometry"; return null }
        var js: ByteArray
        try {
            val root = JSONObject()
            root.put("asset", JSONObject().put("version", "2.0").put("generator", "SaikiMotion FBX Import"))
            root.put("scene", 0); root.put("scenes", JSONArray().put(JSONObject().put("nodes", JSONArray().put(0)))); root.put("nodes", JSONArray().put(JSONObject().put("mesh", 0)))
            root.put("meshes", JSONArray().put(JSONObject().put("primitives", prims))); root.put("materials", matJson)
            root.put("buffers", JSONArray().put(JSONObject().put("byteLength", bin.size()))); root.put("bufferViews", views); root.put("accessors", accs)
            if (images.length() > 0) { root.put("images", images); root.put("textures", textures) }
            js = root.toString().toByteArray(Charsets.UTF_8)
        } catch (_: Exception) { lastError = "FBX conversion failed"; return null }
        if (js.size % 4 != 0) js += ByteArray(4 - js.size % 4) { 0x20 }
        while (bin.size() % 4 != 0) bin.write(0)
        val binB = bin.toByteArray()
        val glb = ByteBuffer.allocate(12 + 8 + js.size + 8 + binB.size).order(ByteOrder.LITTLE_ENDIAN)
        glb.putInt(0x46546C67); glb.putInt(2); glb.putInt(12 + 8 + js.size + 8 + binB.size)
        glb.putInt(js.size); glb.putInt(0x4E4F534A); glb.put(js)
        glb.putInt(binB.size); glb.putInt(0x004E4942); glb.put(binB)
        try { File(out).writeBytes(glb.array()) } catch (_: Exception) { lastError = "Cannot write converted FBX"; return null }
        // skeleton + skin weights sidecar for Pose mode (static models; animated ones are baked frame by frame instead)
        try { File("$out.skel").delete(); File("$out.noskel").delete() } catch (_: Exception) {}
        var wroteSkel = false
        if (!animated && skins.isNotEmpty()) {
            val boneIds = ArrayList<Long>(); val seenB = HashSet<Long>()
            fun addBone(id: Long) { if (models[id] != null && !seenB.contains(id)) { seenB.add(id); boneIds.add(id) } }
            for (gk in skins.keys.sorted()) for (b in skins[gk]!!.bones) addBone(b)
            for (id in models.keys.sorted()) { val mo = models[id]!!; if (mo.p.size > 2) { val ty = mo.p[2]; if (ty is PV.S && ty.v == "LimbNode") addBone(id) } }
            val idxOf = HashMap<Long, Int>()
            for ((i, id) in boneIds.withIndex()) idxOf[id] = i
            fun boneParent(id: Long): Int {
                var a = parentOf[id] ?: 0L; var g = 0
                while (a != 0L && g < 64) { idxOf[a]?.let { return it }; a = parentOf[a] ?: 0L; g += 1 }
                return -1
            }
            val skel = Skeleton3D()
            val binds = ArrayList<M4>()
            for (id in boneIds) binds.add(world0(id))
            for ((i, id) in boneIds.withIndex()) {
                val pi = boneParent(id)
                var nm = models[id]?.str ?: "bone$i"
                val z = nm.indexOf('\u0000'); if (z >= 0) nm = nm.substring(0, z)
                if (nm.startsWith("Model::")) nm = nm.substring(7)
                if (nm.isEmpty()) nm = "bone$i"
                val rest = if (pi >= 0) binds[pi].inverse() * binds[i] else binds[i]
                skel.bones.add(Bone3D(nm, pi, binds[i], rest))
            }
            val J = ArrayList<ShortArray>(); val Wt = ArrayList<FloatArray>()
            for (inf in infos) {
                val n = inf.bk.cp.n
                val j = ShortArray(n * 4); val w = FloatArray(n * 4)
                val sn = inf.skin
                if (sn != null) {
                    for (k in 0 until n) {
                        val ci = inf.bk.cp.a[k]
                        if (!(ci >= 0 && ci < sn.infl.size)) continue
                        var sum = 0f
                        val list = sn.infl[ci]
                        for (slot in 0 until min(4, list.size)) {
                            val c = list[slot].first
                            val bi = if (c >= 0 && c < sn.bones.size) idxOf[sn.bones[c]] else null
                            if (bi != null) { j[k * 4 + slot] = min(bi, 65535).toShort(); w[k * 4 + slot] = list[slot].second; sum += list[slot].second }
                        }
                        if (sum > 1e-6f) for (q in 0 until 4) w[k * 4 + q] /= sum
                    }
                }
                J.add(j); Wt.add(w)
            }
            if (skel.bones.isNotEmpty()) { Skeleton3D.write(skel, J, Wt, "$out.skel"); wroteSkel = true }
        }
        if (!wroteSkel) { try { File("$out.noskel").writeBytes(ByteArray(0)) } catch (_: Exception) {} }
        if (animated) {
            // bake every frame (skinning + node animation) into the "<model>.glb.anim" sidecar GlbModel already plays back
            val tm = vec(gs, "TimeMode", doubleArrayOf(6.0))[0]
            val tmi = tm.toInt()
            var fps: Double = when (tmi) { 11 -> 24.0; 6 -> 30.0; 10 -> 25.0; 3 -> 60.0; 1 -> 120.0; 5 -> 48.0; 4 -> 50.0; 13 -> 23.976
                else -> if (tmi == 14) max(vec(gs, "CustomFrameRate", doubleArrayOf(30.0))[0], 1.0) else 30.0 }
            val dur = tMax - tMin
            val corners = infos.fold(0) { a, i -> a + i.bk.cp.n }
            var nf = max(2, Math.ceil(dur * fps).toInt() + 1)
            val maxF = max(2, 150_000_000 / max(corners * 24, 1))
            if (nf > maxF) { nf = maxF; fps = (nf - 1).toDouble() / dur }
            try {
                FileOutputStream("$out.anim").buffered().use { side ->
                    fun le(v: Int) { side.write(v and 0xFF); side.write((v ushr 8) and 0xFF); side.write((v ushr 16) and 0xFF); side.write((v ushr 24) and 0xFF) }
                    le(0x41424153); le(nf); le(java.lang.Float.floatToRawIntBits(fps.toFloat())); le(infos.size)
                    for (i in infos) le(i.bk.cp.n)
                    for (f in 0 until nf) {
                        val Wf = makeWorld(tMin + dur * f.toDouble() / (nf - 1).toDouble())
                        for (i in infos) {
                            val (P, Nn) = posed(i.bk, i.mid, i.skin, Wf)
                            side.write(fbytes(P)); side.write(fbytes(Nn))
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        return out
    }
}
