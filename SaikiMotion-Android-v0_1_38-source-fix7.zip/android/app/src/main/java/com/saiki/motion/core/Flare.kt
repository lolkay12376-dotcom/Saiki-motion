package com.saiki.motion.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

// Port of Sources/Model/Flare.swift (model + presets). FlareThumbs (Flare.swift:684) is ported in core/FlareThumbs.kt
// (elementPreviews / generate / render — the additive dark-card thumbnails).

class V2(var x: Float, var y: Float)   // SIMD2<Float>

/** A procedural iris: a polygon / star / flower described by a handful of knobs. */
class IrisDef(var name: String = "Iris", var sides: Int = 6, var round: Float = 0f, var star: Float = 0f, var curve: Float = 0f,
              var thick: Float = 1f, var soft: Float = 0.15f, var grad: Float = 0.3f, var chroma: Float = 0f) {
    var cat = "Polygons"

    constructor(e: FlareEl) : this("Iris", e.sides, e.round, e.star, e.curve, e.thick, e.soft, e.grad, e.chroma)

    /** Radius (vertex = 1) of the shape at angle `a` (radians, 0 = up). Mirrors irisR() in GLSL. */
    fun radius(a: Float): Float {
        val n = max(3, sides).toFloat()
        val seg = 2 * Math.PI.toFloat() / n
        var t = a % seg; if (t < 0) t += seg
        val hs = seg * 0.5f
        val phi = abs(t - hs)
        val cosH = cos(hs); val sinH = sin(hs)
        val inner = cosH + (0.12f - cosH) * star
        val den = cos(phi) * sinH - sin(phi) * (cosH - inner)
        var r = inner * sinH / max(den, 0.0001f)
        val u = phi / hs
        r *= 1 + curve * 0.25f * (1 - u * u)
        val rc = (inner + 1) * 0.5f
        return r + (rc - r) * round
    }

    fun apply(e: FlareEl) {
        e.sides = sides; e.round = round; e.star = star; e.curve = curve
        e.thick = thick; e.soft = soft; e.grad = grad; e.chroma = chroma
    }

    fun toJson(): JSONObject = JSONObject().put("name", name).putL("sides", sides.toLong()).putF("round", round)
        .putF("star", star).putF("curve", curve).putF("thick", thick)
        .putF("soft", soft).putF("grad", grad).putF("chroma", chroma)

    companion object {
        fun fromJson(o: JSONObject): IrisDef = IrisDef(o.optS("name", "Iris"), o.optI("sides", 6), round = o.optF("round", 0f),
            star = o.optF("star", 0f), curve = o.optF("curve", 0f), thick = o.optF("thick", 1f),
            soft = o.optF("soft", 0.15f), grad = o.optF("grad", 0.3f), chroma = o.optF("chroma", 0f))

        fun builtin(): List<IrisDef> {
            fun c(cat: String, d: IrisDef): IrisDef { d.cat = cat; return d }
            return listOf(
            c("Polygons", IrisDef("Triangle", 3, soft = 0.1f)),
            c("Polygons", IrisDef("Square", 4, soft = 0.1f)),
            c("Polygons", IrisDef("Pentagon", 5, soft = 0.12f)),
            c("Polygons", IrisDef("Hexagon", 6)),
            c("Polygons", IrisDef("Heptagon", 7, soft = 0.12f)),
            c("Polygons", IrisDef("Octagon", 8)),
            c("Polygons", IrisDef("Circle", 8, round = 1f, soft = 0.08f)),
            c("Cinematic", IrisDef("Soft hex", 6, round = 0.55f, soft = 0.3f, grad = 0.5f)),
            c("Cinematic", IrisDef("Camera 7", 7, round = 0.15f, curve = 0.9f, soft = 0.1f, grad = 0.5f)),
            c("Cinematic", IrisDef("Aperture 9", 9, curve = -0.8f, soft = 0.08f, grad = 0.4f)),
            c("Cinematic", IrisDef("Cine 5", 5, round = 0.25f, curve = 0.6f, soft = 0.14f, grad = 0.65f)),
            c("Cinematic", IrisDef("Cine 8", 8, round = 0.35f, curve = 0.9f, soft = 0.12f, grad = 0.7f, chroma = 0.25f)),
            c("Cinematic", IrisDef("Vintage 6", 6, round = 0.5f, soft = 0.35f, grad = 0.75f, chroma = 0.35f)),
            c("Cinematic", IrisDef("Bokeh disc", 9, round = 1f, soft = 0.22f, grad = 0.85f)),
            c("Cinematic", IrisDef("Bokeh rim", 12, round = 1f, soft = 0.18f, grad = 0.95f, chroma = 0.2f)),
            c("Cinematic", IrisDef("Lens rim", 7, round = 0.4f, curve = 0.6f, thick = 0.3f, soft = 0.14f, grad = 0.8f, chroma = 0.6f)),
            c("Hollow", IrisDef("Hollow hex", 6, thick = 0.18f, soft = 0.1f, grad = 0f)),
            c("Hollow", IrisDef("Hollow ring", 12, round = 1f, thick = 0.12f, soft = 0.08f, grad = 0f)),
            c("Hollow", IrisDef("Thin ring", 12, round = 1f, thick = 0.06f, soft = 0.06f, grad = 0f)),
            c("Hollow", IrisDef("Onion ring", 12, round = 1f, thick = 0.22f, soft = 0.2f, grad = 0.6f, chroma = 0.3f)),
            c("Hollow", IrisDef("Hollow tri", 3, round = 0.15f, thick = 0.2f, soft = 0.1f, grad = 0.2f)),
            c("Stars", IrisDef("Star 5", 5, star = 0.6f, soft = 0.08f)),
            c("Stars", IrisDef("Star 6", 6, star = 0.75f, soft = 0.06f)),
            c("Stars", IrisDef("Sparkle 4", 4, star = 0.88f, soft = 0.05f)),
            c("Stars", IrisDef("Flower 8", 8, round = 0.3f, star = 0.35f, curve = 1f, soft = 0.1f)),
            c("Stars", IrisDef("Spiky 12", 12, star = 0.8f, soft = 0.05f)),
            c("Stars", IrisDef("Starburst", 8, star = 0.92f, soft = 0.04f)),
            c("Crystal", IrisDef("Crystal", 6, star = 0.3f, curve = -0.4f, thick = 0.45f, soft = 0.06f, grad = 0.7f, chroma = 0.5f)),
            c("Crystal", IrisDef("Prism", 3, round = 0.2f, thick = 0.35f, soft = 0.1f, grad = 0.6f, chroma = 0.9f)),
            c("Crystal", IrisDef("Gem 10", 10, star = 0.15f, curve = 0.3f, soft = 0.1f, grad = 0.6f)),
            c("Crystal", IrisDef("Diamond", 4, curve = -0.3f, thick = 0.4f, soft = 0.06f, grad = 0.7f, chroma = 0.6f)),
            c("Crystal", IrisDef("Shard", 3, star = 0.4f, soft = 0.05f, grad = 0.8f, chroma = 0.7f)),
            )
        }

        /** A random but pleasant iris (the "Surprise me" button). */
        fun random(): IrisDef {
            val d = IrisDef("Random", Random.nextInt(3, 13))
            fun fr(a: Float, b: Float) = a + Random.nextFloat() * (b - a)
            d.round = if (Random.nextBoolean()) fr(0f, 0.7f) else 0f
            d.star = if (Random.nextInt(0, 3) == 0) fr(0.2f, 0.85f) else 0f
            d.curve = fr(-1f, 1f) * (if (Random.nextBoolean()) 1f else 0.3f)
            d.thick = if (Random.nextBoolean()) 1f else fr(0.12f, 0.6f)
            d.soft = fr(0.04f, 0.4f)
            d.grad = fr(0f, 0.8f)
            d.chroma = if (Random.nextInt(0, 3) == 0) fr(0.3f, 1f) else 0f
            return d
        }

        var user: MutableList<IrisDef> = mutableListOf()
        fun userFile(): File = File(Projects.root, "irises.json")

        fun loadUser() {
            user = mutableListOf()
            val a = readDictionary(userFile())?.optJSONArray("irises") ?: return
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { val d = fromJson(it); d.cat = "My irises"; user.add(d) }
        }

        fun saveUser() {
            val a = JSONArray(); for (d in user) a.put(d.toJson())
            writeAtomic(userFile(), JSONObject().put("irises", a).toPretty(4))
        }
    }
}

/** JObj.readDictionary: a file into a JSONObject (null when missing/broken). */
fun readDictionary(f: File): JSONObject? = try { JSONObject(f.readText()) } catch (_: Exception) { null }
private fun writeAtomic(f: File, text: String) { try { val tmp = File(f.path + ".tmp"); tmp.writeText(text); tmp.renameTo(f) } catch (_: Exception) {} }

private fun colorJson(c: Int): Double = (c.toLong() and 0xFFFFFFFFL).toDouble()
private fun jsonColor(o: JSONObject, k: String, def: Double): Int = o.optDouble(k, def).toLong().coerceIn(0L, 0xFFFFFFFFL).toInt()

/** One lens in a multi-lens stack (element type 16): its own aperture shape, size, brightness, tint, offset and turn. */
class LensDef {
    var kind = 4
    var size = 1f
    var bright = 1f
    var offset = 0f
    var rot = 0f
    var color: Int = 0xFFFFFFFFL.toInt()

    fun toJson(): JSONObject = JSONObject().putL("kind", kind.toLong()).putF("size", size).putF("bright", bright)
        .putF("offset", offset).putF("rot", rot).put("color", colorJson(color))

    fun copy(): LensDef { val d = LensDef(); d.kind = kind; d.size = size; d.bright = bright; d.offset = offset; d.rot = rot; d.color = color; return d }

    companion object {
        val KINDS = listOf("Circle", "Triangle", "Square", "Pentagon", "Hexagon", "Heptagon", "Octagon", "Nonagon",
            "Curved blades", "Anamorphic oval", "Cat-eye", "Star 5", "Star 6", "Flower",
            "Ring", "Hollow hexagon", "Crescent", "Diamond")

        fun fromJson(o: JSONObject): LensDef {
            val d = LensDef()
            d.kind = o.optI("kind", 4); d.size = o.optF("size", 1f); d.bright = o.optF("bright", 1f)
            d.offset = o.optF("offset", 0f); d.rot = o.optF("rot", 0f)
            d.color = jsonColor(o, "color", 4294967295.0)
            return d
        }

        /** A realistic default stack: coated glass ghosts of different shapes, each a little smaller and tinted. */
        fun defaultStack(): MutableList<LensDef> {
            val tints = longArrayOf(0xFFFFFFFFL, 0xFFBFD8FFL, 0xFFFFD2A0L, 0xFFC8FFD8L, 0xFFE4C8FFL, 0xFFFFE8B8L)
            val kinds = intArrayOf(4, 0, 5, 4, 0, 6)
            return MutableList(6) { i ->
                val d = LensDef(); d.kind = kinds[i]; d.size = 1 - 0.09f * i.toFloat()
                d.bright = 1 - 0.08f * i.toFloat(); d.color = tints[i].toInt(); d.rot = i.toFloat() * 11
                d
            }
        }
    }
}

class FlareEl(var type: Int = 0) {
    var enabled = true
    var pos = 1f                  // along the axis
    var size = 0.5f
    var stretch = 1f
    var rot = 0f
    var bright = 1f
    var soft = 0.5f
    var thick = 0.3f
    var sides = 6
    var rays = 8
    var chroma = 0f
    var follow = false
    var round = 0f
    var star = 0f
    var curve = 0f
    var grad = 0.3f
    var noise = 0f                // random ray length / shimmer amount
    var spin = 0f                 // turns per screen of light travel
    var spread = 0.32f            // multi iris: gap between copies along the axis
    var off = 0f                  // off-axis shift (screen heights, perpendicular to the axis)
    var gain = 0.6f               // multi lens: how much brighter the light gets where several lenses overlap
    var lenses = mutableListOf<LensDef>()    // lens stack (type 16)
    var color: Int = 0xFFFFFFFFL.toInt()

    fun label(): String = if (type in TYPES.indices) TYPES[type] else "Element"
    val isIris: Boolean get() = type == 1 || type == 5 || type == 13 || type == 14

    fun copy(): FlareEl {
        val e = FlareEl(type)
        e.enabled = enabled; e.pos = pos; e.size = size; e.stretch = stretch; e.rot = rot
        e.bright = bright; e.soft = soft; e.thick = thick; e.sides = sides; e.rays = rays
        e.chroma = chroma; e.follow = follow; e.color = color
        e.round = round; e.star = star; e.curve = curve; e.grad = grad; e.noise = noise; e.spin = spin
        e.spread = spread; e.off = off; e.gain = gain
        e.lenses = lenses.map { it.copy() }.toMutableList()   // Swift array of structs = value copies
        return e
    }

    fun toJson(): JSONObject {
        val la = JSONArray(); for (l in lenses) la.put(l.toJson())
        return JSONObject().putL("type", type.toLong()).put("enabled", enabled).putF("pos", pos)
            .putF("size", size).putF("stretch", stretch).putF("rot", rot)
            .putF("bright", bright).putF("soft", soft).putF("thick", thick)
            .putL("sides", sides.toLong()).putL("rays", rays.toLong()).putF("chroma", chroma)
            .put("follow", follow).put("color", colorJson(color))
            .putF("round", round).putF("star", star).putF("curve", curve)
            .putF("grad", grad).putF("noise", noise).putF("spin", spin)
            .putF("spread", spread).putF("gain", gain).putF("off", off)
            .put("lenses", la)
    }

    companion object {
        // indices 0...6 are the original types (saved projects), 7+ are new
        val TYPES = listOf("Glow", "Polygon", "Line", "Rays", "Ring", "Ring polygon", "Dot",
            "Glint", "Hoop", "Streak", "Spike ball", "Rainbow", "Shimmer", "Iris", "Multi iris", "Arc", "Lens stack")
        const val MAX = 16

        fun fromJson(o: JSONObject): FlareEl {
            val e = FlareEl(o.optI("type", 0))
            e.enabled = o.optB("enabled", true)
            e.pos = o.optF("pos", 1f); e.size = o.optF("size", 0.5f)
            e.stretch = o.optF("stretch", 1f); e.rot = o.optF("rot", 0f)
            e.bright = o.optF("bright", 1f); e.soft = o.optF("soft", 0.5f)
            e.thick = o.optF("thick", 0.3f); e.sides = o.optI("sides", 6)
            e.rays = o.optI("rays", 8); e.chroma = o.optF("chroma", 0f)
            e.follow = o.optB("follow", false)
            e.round = o.optF("round", 0f); e.star = o.optF("star", 0f); e.curve = o.optF("curve", 0f)
            e.grad = o.optF("grad", 0.3f); e.noise = o.optF("noise", 0f); e.spin = o.optF("spin", 0f)
            e.spread = o.optF("spread", 0.32f); e.gain = o.optF("gain", 0.6f); e.off = o.optF("off", 0f)
            o.optJSONArray("lenses")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { e.lenses.add(LensDef.fromJson(it)) } }
            e.color = jsonColor(o, "color", 0.0)
            return e
        }

        /** Sensible starting values for a freshly added element of `type`. */
        fun make(type: Int): FlareEl {
            val e = FlareEl(type)
            when (type) {
                0 -> { e.pos = 0f; e.size = 0.5f; e.soft = 0.7f; e.bright = 1.2f }
                1, 5 -> { e.size = 0.3f; e.thick = 0.45f; e.soft = 0.15f }
                2 -> { e.size = 1.2f; e.stretch = 10f; e.thick = 0.04f; e.pos = 0f }
                3 -> { e.size = 0.9f; e.pos = 0f; e.rays = 12 }
                4 -> { e.size = 0.5f; e.thick = 0.06f; e.soft = 0.3f }
                6 -> { e.size = 0.05f; e.soft = 0.3f }
                7 -> { e.pos = 0f; e.size = 1.1f; e.rays = 8; e.soft = 0.6f; e.noise = 0.3f; e.bright = 0.9f }
                8 -> { e.pos = 1f; e.size = 0.8f; e.thick = 0.12f; e.chroma = 0.6f; e.bright = 0.7f }
                9 -> { e.pos = 0f; e.size = 1.8f; e.stretch = 3f; e.thick = 0.15f; e.soft = 0.5f; e.bright = 1f }
                10 -> { e.pos = 0f; e.size = 0.9f; e.rays = 18; e.noise = 0.8f; e.soft = 0.6f; e.bright = 1f }
                11 -> { e.pos = 1.2f; e.size = 0.9f; e.thick = 0.5f; e.chroma = 0.8f; e.bright = 0.5f }
                12 -> { e.pos = 0f; e.size = 0.7f; e.rays = 14; e.noise = 0.5f; e.bright = 0.8f }
                13 -> { e.size = 0.3f; e.sides = 7; e.round = 0.15f; e.curve = 0.8f; e.thick = 1f; e.soft = 0.12f; e.grad = 0.5f }
                14 -> { e.pos = 0.45f; e.size = 0.2f; e.rays = 5; e.spread = 0.32f; e.sides = 6; e.round = 0.1f; e.curve = 0.5f
                    e.thick = 1f; e.soft = 0.12f; e.grad = 0.65f; e.chroma = 0.5f; e.noise = 0.5f; e.bright = 0.55f; e.follow = true }
                15 -> { e.pos = 1.3f; e.size = 1.0f; e.thick = 0.12f; e.soft = 0.5f; e.spread = 0.3f; e.chroma = 0.7f; e.bright = 0.5f }
                16 -> { e.pos = 0.4f; e.size = 0.2f; e.spread = 0.3f; e.rays = 6; e.soft = 0.14f; e.grad = 0.6f; e.chroma = 0.35f
                    e.thick = 1f; e.bright = 0.55f; e.follow = true; e.gain = 0.8f; e.lenses = LensDef.defaultStack() }
                else -> {}
            }
            return e
        }
    }
}

class Flare {
    var name = "Flare"
    var tint: Int = 0xFFFFFFFFL.toInt()
    var depthScale = 0.6f
    var edgeFade = 0.5f
    var flicker = 0f
    var speed = 1f
    var rayAmt = 0.6f      // overall strength of every ray / spike / starburst
    var realism = 1f       // 0 = flat graphic look, 1 = optical (soft PSF tails, dispersion, dust, filmic roll-off)
    var veil = 0.3f        // veiling glare haze around the light
    var dust = 0.25f       // dirt / micro-scratches on the glass
    var occlusion = 1f     // how strongly 3D objects in front of the light hide the flare
    var occlSoft = 0.5f    // softness of that cut (light has a size)
    var els = mutableListOf<FlareEl>()
    var anchor: V2? = null   // where the light should sit (0..1 of the frame) when this preset is loaded

    fun copy(): Flare {
        val f = Flare()
        f.name = name; f.tint = tint; f.depthScale = depthScale; f.edgeFade = edgeFade
        f.flicker = flicker; f.speed = speed; f.rayAmt = rayAmt
        f.anchor = anchor?.let { V2(it.x, it.y) }; f.realism = realism; f.veil = veil; f.dust = dust; f.occlusion = occlusion; f.occlSoft = occlSoft
        for (e in els) f.els.add(e.copy())
        return f
    }

    /** Signature for thumbnail caching. */
    fun sig(): String {
        val sb = StringBuilder(name + "|")
        for (e in els) sb.append("${e.type},${e.pos},${e.size},${e.color.toLong() and 0xFFFFFFFFL},${if (e.enabled) 1 else 0},${e.sides},${e.thick},${e.stretch},${e.rays},${e.star},${e.round},${e.spread},${e.chroma},${e.bright};")
        return sb.toString() + "|" + (tint.toLong() and 0xFFFFFFFFL) + "|${realism},${veil},${dust}"
    }

    fun toJson(): JSONObject {
        val o = JSONObject().put("name", name).put("tint", colorJson(tint))
            .putF("depthScale", depthScale).putF("edgeFade", edgeFade)
            .putF("flicker", flicker).putF("speed", speed).putF("rayAmt", rayAmt)
            .putF("ax", anchor?.x ?: -1f).putF("ay", anchor?.y ?: -1f).putF("realism", realism).putF("veil", veil).putF("dust", dust)
            .putF("occlusion", occlusion).putF("occlSoft", occlSoft)
        val a = JSONArray()
        for (e in els) a.put(e.toJson())
        o.put("els", a)
        return o
    }

    companion object {
        /** <Documents>/SaikiMotion/flares.json presets */
        var user: MutableList<Flare> = mutableListOf()

        fun fromJson(o: JSONObject): Flare {
            val f = Flare()
            f.name = o.optS("name", "Flare")
            f.tint = jsonColor(o, "tint", 0.0)
            f.depthScale = o.optF("depthScale", 0.6f)
            f.edgeFade = o.optF("edgeFade", 0.5f)
            f.flicker = o.optF("flicker", 0f); f.speed = o.optF("speed", 1f); f.rayAmt = o.optF("rayAmt", 0.6f)
            if (o.optF("ax", -1f) >= 0) f.anchor = V2(o.optF("ax", 0.3f), o.optF("ay", 0.3f))
            f.realism = o.optF("realism", 1f); f.veil = o.optF("veil", 0.3f); f.dust = o.optF("dust", 0.25f)
            f.occlusion = o.optF("occlusion", 1f); f.occlSoft = o.optF("occlSoft", 0.5f)
            o.optJSONArray("els")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { f.els.add(FlareEl.fromJson(it)) } }
            return f
        }

        private fun argb(v: Long): Int = v.toInt()

        fun deflt(): Flare {
            val f = Flare()
            f.name = "Custom"
            val glow = FlareEl.make(0); glow.size = 0.55f; glow.bright = 1.4f
            val streak = FlareEl.make(9); streak.size = 1.6f; streak.stretch = 4f; streak.thick = 0.1f; streak.bright = 0.8f
            val hoop = FlareEl.make(8); hoop.pos = 1f; hoop.size = 0.9f
            f.els = mutableListOf(glow, streak, hoop)
            return f
        }

        /** Generated from Flare.swift:builtin() by a line-for-line translation (26 presets, 205 elements). */
        fun builtin(): List<Flare> {
            val out = ArrayList<Flare>()
            fun make(name: String, tint: Long, build: (Flare) -> Unit) { val f = Flare(); f.name = name; f.tint = argb(tint); build(f); out.add(f) }
            fun el(f: Flare, t: Int, cfg: (FlareEl) -> Unit) { val e = FlareEl.make(t); cfg(e); f.els.add(e) }

        // ===== Reference presets (recreated from the five reference photos; load them with the light at the same spot) =====
        make("Ref Blue Star Chain", 0xFFFFFFFFL) { f ->
            f.anchor = V2(0.300f, 0.300f)
            el(f, 0) { it.pos = 0f; it.size = 0.6f; it.soft = 1f; it.bright = 0.32f; it.color = argb(0xFF2F5FFFL) }
            el(f, 0) { it.pos = 0f; it.size = 0.2f; it.soft = 0.7f; it.bright = 0.8f; it.color = argb(0xFF8FB8FFL) }
            el(f, 0) { it.pos = 0f; it.size = 0.07f; it.soft = 0.4f; it.bright = 2.4f; it.color = argb(0xFFEAF3FFL) }
            el(f, 7) { it.pos = 0f; it.size = 1.3f; it.rays = 8; it.noise = 0.35f; it.soft = 0.1f; it.bright = 1.0f; it.color = argb(0xFFB5D0FFL) }
            el(f, 9) { it.pos = 0f; it.size = 3.4f; it.stretch = 1.7f; it.thick = 0.025f; it.soft = 0.45f; it.bright = 0.9f; it.color = argb(0xFF3566FFL) }
            el(f, 8) { it.pos = -0.3f; it.size = 0.2f; it.thick = 0.25f; it.chroma = 1f; it.bright = 0.22f; it.soft = 0.6f }
            el(f, 14) { it.pos = 0.6f; it.size = 0.035f; it.rays = 8; it.spread = 0.24f; it.sides = 12; it.round = 1f; it.thick = 0.35f; it.soft = 0.45f; it.noise = 0.3f; it.chroma = 0.6f; it.bright = 0.5f; it.gain = 0.3f; it.color = argb(0xFFAFC8FFL) }
            el(f, 13) { it.pos = 2.0f; it.size = 0.2f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.55f; it.grad = 0.85f; it.chroma = 0.3f; it.bright = 0.26f; it.color = argb(0xFF3F6FD0L) }
            el(f, 6) { it.pos = 2.0f; it.size = 0.035f; it.soft = 0.5f; it.bright = 2.0f; it.color = argb(0xFFD0E8FFL) }
        }
        make("Ref Green Anamorphic", 0xFFFFFFFFL) { f ->
            f.anchor = V2(0.270f, 0.330f)
            el(f, 0) { it.pos = 0f; it.size = 0.55f; it.soft = 1f; it.bright = 0.3f; it.color = argb(0xFF6FD04AL) }
            el(f, 0) { it.pos = 0f; it.size = 0.16f; it.soft = 0.7f; it.bright = 0.9f; it.color = argb(0xFFB8FF6AL) }
            el(f, 0) { it.pos = 0f; it.size = 0.06f; it.soft = 0.4f; it.bright = 2.4f; it.color = argb(0xFFF2FFD0L) }
            el(f, 7) { it.pos = 0f; it.size = 1.4f; it.rays = 10; it.noise = 0.5f; it.soft = 0.2f; it.bright = 1.0f; it.color = argb(0xFFA8F060L) }
            el(f, 9) { it.pos = 0f; it.size = 3.6f; it.stretch = 1.6f; it.thick = 0.02f; it.soft = 0.4f; it.bright = 1.0f; it.color = argb(0xFF3C8CFFL) }
            el(f, 9) { it.pos = 0.874f; it.off = -0.134f; it.size = 3.6f; it.stretch = 1.6f; it.thick = 0.008f; it.soft = 0.3f; it.bright = 0.7f; it.color = argb(0xFFFFF0A8L) }
            el(f, 9) { it.pos = 1.566f; it.off = 0.047f; it.size = 3.0f; it.stretch = 1.6f; it.thick = 0.01f; it.soft = 0.3f; it.bright = 0.35f; it.color = argb(0xFF4C8CFFL) }
            el(f, 14) { it.pos = 0.35f; it.size = 0.04f; it.rays = 7; it.spread = 0.24f; it.sides = 12; it.round = 1f; it.thick = 0.4f; it.soft = 0.45f; it.noise = 0.3f; it.chroma = 0.5f; it.bright = 0.45f; it.gain = 0.3f; it.color = argb(0xFFA6E8A0L) }
            el(f, 13) { it.pos = 1.95f; it.size = 0.5f; it.sides = 12; it.round = 1f; it.thick = 0.45f; it.soft = 0.7f; it.grad = 0.9f; it.bright = 0.22f; it.color = argb(0xFF3FA868L) }
            el(f, 13) { it.pos = 1.95f; it.size = 0.17f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.8f; it.grad = 0.5f; it.bright = 0.28f; it.color = argb(0xFF7A4CC8L) }
            el(f, 8) { it.pos = 1.95f; it.size = 0.84f; it.thick = 0.1f; it.soft = 0.8f; it.chroma = 0.5f; it.bright = 0.14f; it.color = argb(0xFF30905AL) }
            el(f, 6) { it.pos = 1.418f; it.off = 0.075f; it.size = 0.035f; it.soft = 0.4f; it.bright = 2.2f; it.color = argb(0xFF4CA8FFL) }
            el(f, 6) { it.pos = 2.502f; it.off = 0.002f; it.size = 0.04f; it.soft = 0.4f; it.bright = 2.2f; it.color = argb(0xFF7FFFE8L) }
            el(f, 9) { it.pos = 2.496f; it.off = -0.005f; it.size = 0.3f; it.stretch = 4f; it.thick = 0.06f; it.soft = 0.6f; it.bright = 0.8f; it.color = argb(0xFF4CE0FFL) }
        }
        make("Ref Blue Streak Bars", 0xFFFFFFFFL) { f ->
            f.anchor = V2(0.250f, 0.300f)
            el(f, 0) { it.pos = 0f; it.size = 0.5f; it.soft = 1f; it.bright = 0.3f; it.color = argb(0xFF2F5FFFL) }
            el(f, 0) { it.pos = 0f; it.size = 0.16f; it.soft = 0.7f; it.bright = 0.9f; it.color = argb(0xFF6FA8FFL) }
            el(f, 0) { it.pos = 0f; it.size = 0.06f; it.soft = 0.4f; it.bright = 2.4f; it.color = argb(0xFFEAF3FFL) }
            el(f, 7) { it.pos = 0f; it.size = 1.1f; it.rays = 8; it.noise = 0.35f; it.soft = 0.15f; it.bright = 0.95f; it.color = argb(0xFF7AB0FFL) }
            el(f, 9) { it.pos = 0f; it.size = 2.3f; it.stretch = 1f; it.thick = 0.02f; it.soft = 0.5f; it.bright = 1.2f; it.color = argb(0xFF2E6CFFL) }
            el(f, 2) { it.pos = 1.71f; it.off = -0.227f; it.size = 0.65f; it.stretch = 1f; it.thick = 0.07f; it.soft = 0.4f; it.bright = 0.9f; it.color = argb(0xFF1E3FB8L) }
            el(f, 2) { it.pos = 1.344f; it.off = -0.147f; it.size = 0.3f; it.stretch = 1f; it.thick = 0.1f; it.soft = 0.5f; it.bright = 0.5f; it.color = argb(0xFF4A78E8L) }
            el(f, 9) { it.pos = 0.934f; it.off = 0.102f; it.size = 1.2f; it.stretch = 1f; it.thick = 0.012f; it.soft = 0.5f; it.bright = 0.45f; it.color = argb(0xFF2E6CFFL) }
            el(f, 4) { it.pos = 2.158f; it.off = -0.046f; it.size = 0.3f; it.thick = 0.05f; it.soft = 0.5f; it.chroma = 1f; it.bright = 0.22f; it.color = argb(0xFF3FB0B0L) }
        }
        make("Ref Magenta Ring", 0xFFFFFFFFL) { f ->
            f.anchor = V2(0.350f, 0.330f)
            el(f, 0) { it.pos = 0f; it.size = 1.2f; it.soft = 1f; it.bright = 0.45f; it.color = argb(0xFF8A2A9AL) }
            el(f, 0) { it.pos = 0f; it.size = 0.35f; it.soft = 0.8f; it.bright = 1.1f; it.color = argb(0xFFF070C8L) }
            el(f, 0) { it.pos = 0f; it.size = 0.1f; it.soft = 0.4f; it.bright = 2.5f; it.color = argb(0xFFFFE6F8L) }
            el(f, 4) { it.pos = 0f; it.size = 0.58f; it.thick = 0.03f; it.soft = 0.35f; it.chroma = 0.3f; it.bright = 0.75f; it.color = argb(0xFFE0508AL) }
            el(f, 7) { it.pos = 0f; it.size = 0.55f; it.rays = 24; it.noise = 0.8f; it.soft = 0.8f; it.bright = 0.35f; it.color = argb(0xFFE8A0E0L) }
            el(f, 13) { it.pos = 1.718f; it.off = -0.074f; it.size = 0.06f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.4f; it.grad = 0.8f; it.bright = 0.45f; it.color = argb(0xFFD070D8L) }
            el(f, 13) { it.pos = 2.654f; it.off = -0.073f; it.size = 0.085f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.4f; it.grad = 0.8f; it.bright = 0.35f; it.color = argb(0xFF8A70E8L) }
            el(f, 4) { it.pos = 3.383f; it.off = -0.042f; it.size = 0.38f; it.thick = 0.05f; it.soft = 0.5f; it.chroma = 0.4f; it.bright = 0.3f; it.color = argb(0xFF6A7AE8L) }
            el(f, 13) { it.pos = 3.383f; it.off = -0.042f; it.size = 0.19f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.8f; it.grad = 0.7f; it.bright = 0.12f; it.color = argb(0xFF6A7AE8L) }
            el(f, 13) { it.pos = -0.868f; it.off = 0.033f; it.size = 0.077f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.5f; it.grad = 0.7f; it.bright = 0.3f; it.color = argb(0xFFC07AE0L) }
        }
        make("Ref Warm Bokeh Star", 0xFFFFFFFFL) { f ->
            f.anchor = V2(0.750f, 0.360f)
            el(f, 0) { it.pos = 0f; it.size = 0.75f; it.soft = 1f; it.bright = 0.4f; it.color = argb(0xFFFFD8A0L) }
            el(f, 0) { it.pos = 0f; it.size = 0.2f; it.soft = 0.8f; it.bright = 1.0f; it.color = argb(0xFFFFF0D8L) }
            el(f, 0) { it.pos = 0f; it.size = 0.07f; it.soft = 0.4f; it.bright = 3.0f; it.color = argb(0xFFFFFFFFL) }
            el(f, 7) { it.pos = 0f; it.size = 1.9f; it.rays = 8; it.noise = 0.15f; it.soft = 0.08f; it.bright = 1.2f; it.color = argb(0xFFFFE8C8L) }
            el(f, 7) { it.pos = 0f; it.size = 2.6f; it.rays = 2; it.soft = 0.05f; it.bright = 1.0f; it.rot = 90f; it.color = argb(0xFFFFE8C8L) }
            el(f, 9) { it.pos = 0f; it.size = 2.4f; it.stretch = 1.2f; it.thick = 0.012f; it.soft = 0.3f; it.bright = 1.1f; it.color = argb(0xFFFFF0D8L) }
            el(f, 14) { it.pos = 0.348f; it.size = 0.008f; it.rays = 8; it.spread = 0.146f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.2f; it.noise = 0f; it.chroma = 0f; it.bright = 0.9f; it.gain = 0f; it.color = argb(0xFFFFFFFFL) }
            el(f, 13) { it.pos = 0.567f; it.off = -0.011f; it.size = 0.133f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.12f; it.grad = 0.75f; it.bright = 0.3f; it.color = argb(0xFFC08850L) }
            el(f, 13) { it.pos = 1.152f; it.off = 0.012f; it.size = 0.17f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.12f; it.grad = 0.75f; it.bright = 0.3f; it.color = argb(0xFFC08850L) }
            el(f, 13) { it.pos = 1.711f; it.off = -0.022f; it.size = 0.17f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.12f; it.grad = 0.75f; it.bright = 0.3f; it.color = argb(0xFFC08850L) }
            el(f, 13) { it.pos = 1.97f; it.off = -0.015f; it.size = 0.05f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.15f; it.grad = 0.6f; it.bright = 0.4f; it.color = argb(0xFFC08850L) }
            el(f, 13) { it.pos = 1.518f; it.off = 0.003f; it.size = 0.07f; it.sides = 12; it.round = 1f; it.thick = 0.35f; it.soft = 0.3f; it.grad = 0.6f; it.bright = 0.3f; it.color = argb(0xFF6FC0B8L) }
            el(f, 13) { it.pos = 2.488f; it.off = -0.012f; it.size = 0.06f; it.sides = 12; it.round = 1f; it.thick = 1f; it.soft = 0.2f; it.grad = 0.7f; it.bright = 0.4f; it.color = argb(0xFF5878E0L) }
            el(f, 7) { it.pos = 1.284f; it.off = -0.006f; it.size = 0.14f; it.rays = 4; it.soft = 0.2f; it.bright = 1.3f; it.color = argb(0xFFFFE0A0L) }
            el(f, 7) { it.pos = 1.026f; it.off = -0.038f; it.size = 0.12f; it.rays = 4; it.soft = 0.2f; it.bright = 1.2f; it.color = argb(0xFFFFE0A0L) }
        }
        make("Ref Orange Hex Bokeh", 0xFFFFFFFFL) { f ->
            f.anchor = V2(0.290f, 0.490f)
            el(f, 0) { it.pos = 0f; it.size = 0.7f; it.soft = 1f; it.bright = 0.4f; it.color = argb(0xFFFF8A2AL) }
            el(f, 0) { it.pos = 0f; it.size = 0.2f; it.soft = 0.8f; it.bright = 1.0f; it.color = argb(0xFFFFB45AL) }
            el(f, 0) { it.pos = 0f; it.size = 0.07f; it.soft = 0.4f; it.bright = 2.4f; it.color = argb(0xFFFFF4DCL) }
            el(f, 7) { it.pos = 0f; it.size = 1.3f; it.rays = 6; it.noise = 0.5f; it.soft = 0.15f; it.bright = 1.1f; it.color = argb(0xFFFFB050L) }
            el(f, 9) { it.pos = 0.55f; it.size = 1.3f; it.stretch = 1.9f; it.thick = 0.08f; it.soft = 0.8f; it.bright = 1.0f; it.rot = -4.5f; it.color = argb(0xFFFF9A30L) }
            el(f, 7) { it.pos = 0f; it.size = 1.5f; it.rays = 2; it.soft = 0.06f; it.bright = 0.9f; it.rot = 90f; it.color = argb(0xFFFF9A40L) }
            el(f, 9) { it.pos = 0.5f; it.size = 1.4f; it.stretch = 1.6f; it.thick = 0.012f; it.soft = 0.5f; it.bright = 0.3f; it.rot = 3f; it.color = argb(0xFFFF9030L) }
            el(f, 13) { it.pos = 1.225f; it.off = 0.15f; it.size = 0.2f; it.sides = 6; it.rot = 30f; it.round = 0.02f; it.thick = 1f; it.soft = 0.35f; it.grad = 0.9f; it.bright = 0.2f; it.color = argb(0xFFFFA030L) }
            el(f, 13) { it.pos = 1.744f; it.off = 0.218f; it.size = 0.23f; it.sides = 6; it.rot = 30f; it.round = 0.02f; it.thick = 1f; it.soft = 0.35f; it.grad = 0.9f; it.bright = 0.2f; it.color = argb(0xFFFFA030L) }
            el(f, 13) { it.pos = 2.425f; it.off = 0.211f; it.size = 0.2f; it.sides = 6; it.rot = 30f; it.round = 0.02f; it.thick = 1f; it.soft = 0.35f; it.grad = 0.9f; it.bright = 0.18f; it.color = argb(0xFFFFA030L) }
            el(f, 13) { it.pos = -1.017f; it.off = -0.24f; it.size = 0.27f; it.sides = 6; it.rot = 30f; it.round = 0.02f; it.thick = 1f; it.soft = 0.4f; it.grad = 0.8f; it.bright = 0.1f; it.color = argb(0xFFFFA030L) }
            el(f, 6) { it.pos = 2.005f; it.off = 0.27f; it.size = 0.045f; it.soft = 0.3f; it.bright = 2.0f; it.color = argb(0xFFFFC060L) }
            el(f, 6) { it.pos = 2.202f; it.off = 0.288f; it.size = 0.025f; it.soft = 0.3f; it.bright = 1.2f; it.color = argb(0xFFFFB050L) }
            el(f, 6) { it.pos = 0.937f; it.off = 0.124f; it.size = 0.03f; it.soft = 0.3f; it.bright = 1.0f; it.color = argb(0xFFFFB050L) }
            el(f, 6) { it.pos = 1.443f; it.off = 0.196f; it.size = 0.03f; it.soft = 0.3f; it.bright = 1.0f; it.color = argb(0xFFFFB050L) }
        }
        // ===== Cinematic reference presets (built from the four reference flares) =====
        make("Cine Orange Burst", 0xFFFFFFFFL) { f ->
            el(f, 0) { it.size = 0.95f; it.bright = 0.45f; it.soft = 1f; it.color = argb(0xFFFF8A2AL) } // big warm halo
            el(f, 0) { it.size = 0.34f; it.bright = 1.0f; it.soft = 0.8f; it.color = argb(0xFFFFB45AL) } // inner glow
            el(f, 0) { it.size = 0.09f; it.bright = 2.2f; it.soft = 0.4f; it.color = argb(0xFFFFF4DCL) } // hot core
            el(f, 7) { it.size = 0.8f; it.rays = 18; it.noise = 0.7f; it.soft = 0.15f; it.bright = 1.1f; it.color = argb(0xFFFFB060L) } // fine starburst
            el(f, 9) { it.size = 2.6f; it.stretch = 1.5f; it.thick = 0.04f; it.soft = 0.35f; it.bright = 1.3f; it.color = argb(0xFFFF8A3AL) } // horizontal streak
            el(f, 4) { it.pos = 0f; it.size = 0.56f; it.thick = 0.025f; it.soft = 0.5f; it.bright = 0.35f; it.color = argb(0xFFFF9A50L) } // thin halo ring
            el(f, 15) { it.pos = -0.7f; it.size = 0.3f; it.thick = 0.5f; it.soft = 0.7f; it.spread = 0.3f; it.bright = 0.4f; it.color = argb(0xFFFFA050L); it.rot = 20f } // crescent
            el(f, 14) { it.pos = 1.5f; it.size = 0.07f; it.rays = 5; it.spread = 0.14f; it.sides = 6; it.round = 0.15f; it.soft = 0.12f; it.grad = 0.7f; it.noise = 0.5f; it.chroma = 0.25f; it.color = argb(0xFFFFA050L); it.bright = 0.6f } // hex bokeh chain
            el(f, 0) { it.pos = 2.6f; it.size = 0.2f; it.soft = 0.9f; it.bright = 0.35f; it.color = argb(0xFFFF9A40L) } // ghost fill
            el(f, 11) { it.pos = 2.6f; it.size = 0.36f; it.thick = 0.35f; it.chroma = 1f; it.bright = 0.55f } // chromatic rim ghost
            el(f, 0) { it.pos = 2.95f; it.size = 0.045f; it.stretch = 3f; it.rot = -35f; it.bright = 1f; it.color = argb(0xFFFFA040L) } // small elongated ghost
            el(f, 14) { it.pos = 0.12f; it.size = 0.008f; it.rays = 8; it.spread = 0.09f; it.round = 1f; it.sides = 8; it.soft = 0.3f; it.grad = 0f; it.noise = 0.9f; it.bright = 0.9f; it.color = argb(0xFFFFC890L) } // dust sparkles
        }
        make("Cine Golden Anamorphic", 0xFFFFFFFFL) { f ->
            el(f, 0) { it.size = 0.8f; it.bright = 0.5f; it.soft = 1f; it.color = argb(0xFFFFC070L) }
            el(f, 0) { it.size = 0.2f; it.bright = 1.4f; it.soft = 0.7f; it.color = argb(0xFFFFE6B0L) }
            el(f, 0) { it.size = 0.07f; it.bright = 2.6f; it.soft = 0.4f; it.color = argb(0xFFFFFFFFL) }
            el(f, 7) { it.size = 1.7f; it.rays = 8; it.noise = 0.65f; it.soft = 0.12f; it.bright = 1.2f; it.color = argb(0xFFFFE0A0L) } // long star rays
            el(f, 9) { it.size = 3.0f; it.stretch = 1.4f; it.thick = 0.02f; it.soft = 0.3f; it.bright = 1.6f; it.color = argb(0xFFFFE2A8L) } // streak line 1
            el(f, 9) { it.size = 2.4f; it.stretch = 1.4f; it.thick = 0.04f; it.soft = 0.4f; it.rot = 0.35f; it.bright = 0.8f; it.color = argb(0xFFFFB860L) } // streak line 2
            el(f, 9) { it.size = 2.0f; it.stretch = 1.4f; it.thick = 0.03f; it.soft = 0.5f; it.rot = -0.3f; it.bright = 0.6f; it.color = argb(0xFFFFA040L) } // streak line 3
            el(f, 4) { it.pos = 0.05f; it.size = 0.62f; it.thick = 0.02f; it.soft = 0.55f; it.bright = 0.55f; it.color = argb(0xFFFF9040L); it.chroma = 0.3f } // big thin ring
            el(f, 13) { it.pos = -0.35f; it.size = 0.13f; it.sides = 12; it.round = 1f; it.thick = 0.14f; it.soft = 0.35f; it.grad = 0.9f; it.bright = 0.5f; it.color = argb(0xFFFFC890L); it.chroma = 0.3f } // rim disc
            el(f, 14) { it.pos = 0.85f; it.size = 0.09f; it.rays = 5; it.spread = 0.2f; it.sides = 12; it.round = 1f; it.soft = 0.4f; it.grad = 0.8f; it.noise = 0.55f; it.bright = 0.45f; it.color = argb(0xFFFFB868L) } // disc chain
            el(f, 0) { it.pos = 1.9f; it.size = 0.03f; it.bright = 1.6f; it.soft = 0.5f; it.color = argb(0xFFFFB060L) }
            el(f, 8) { it.pos = 2.2f; it.size = 0.62f; it.thick = 0.04f; it.soft = 0.8f; it.bright = 0.2f; it.color = argb(0xFFFF9A40L) }
            el(f, 15) { it.pos = 1.6f; it.size = 0.9f; it.thick = 0.03f; it.soft = 0.7f; it.spread = 0.3f; it.bright = 0.3f; it.color = argb(0xFFFFA850L); it.rot = 150f }
        }
        make("Cine Blue Anamorphic", 0xFFFFFFFFL) { f ->
            el(f, 0) { it.size = 0.6f; it.bright = 0.45f; it.soft = 1f; it.color = argb(0xFF2F6BFFL) }
            el(f, 0) { it.size = 0.16f; it.bright = 1.7f; it.soft = 0.6f; it.color = argb(0xFF8FD0FFL) }
            el(f, 0) { it.size = 0.06f; it.bright = 2.6f; it.soft = 0.4f; it.color = argb(0xFFEAF6FFL) }
            el(f, 7) { it.size = 0.45f; it.rays = 4; it.noise = 0.3f; it.soft = 0.3f; it.bright = 0.6f; it.color = argb(0xFF7FC0FFL) }
            el(f, 9) { it.size = 3.4f; it.stretch = 1.2f; it.thick = 0.06f; it.soft = 0.35f; it.bright = 1.5f; it.color = argb(0xFF4FC8FFL) } // cyan band
            el(f, 9) { it.size = 2.8f; it.stretch = 1.2f; it.thick = 0.04f; it.soft = 0.5f; it.rot = 0.25f; it.bright = 0.9f; it.color = argb(0xFF3FE0C0L) } // teal band
            el(f, 9) { it.size = 2.2f; it.stretch = 1.2f; it.thick = 0.03f; it.soft = 0.5f; it.rot = -0.3f; it.bright = 0.9f; it.color = argb(0xFF9A6BFFL) } // purple band
            el(f, 9) { it.size = 3.0f; it.stretch = 1.2f; it.thick = 0.25f; it.soft = 0.8f; it.bright = 0.5f; it.color = argb(0xFF2F6BFFL) } // wide blue wash
            el(f, 0) { it.pos = 2.0f; it.size = 0.03f; it.bright = 1.8f; it.soft = 0.5f; it.color = argb(0xFF3FA8FFL) }
            el(f, 13) { it.pos = 1.7f; it.size = 0.07f; it.sides = 10; it.round = 1f; it.soft = 0.85f; it.grad = 0.3f; it.bright = 0.3f; it.color = argb(0xFF2F6BFFL) }
            el(f, 13) { it.pos = 2.35f; it.size = 0.05f; it.sides = 10; it.round = 1f; it.soft = 0.85f; it.grad = 0.3f; it.bright = 0.25f; it.color = argb(0xFF4F9CFFL) }
            el(f, 14) { it.pos = 1.2f; it.size = 0.006f; it.rays = 6; it.spread = 0.1f; it.round = 1f; it.sides = 8; it.soft = 0.3f; it.grad = 0f; it.noise = 0.8f; it.bright = 0.7f; it.color = argb(0xFF7FC8FFL) }
        }
        make("Cine Starburst Prism", 0xFFFFFFFFL) { f ->
            el(f, 0) { it.size = 0.38f; it.bright = 0.4f; it.soft = 1f; it.color = argb(0xFFFFE8C8L) }
            el(f, 0) { it.size = 0.1f; it.bright = 2.2f; it.soft = 0.4f; it.color = argb(0xFFFFFFFFL) }
            el(f, 7) { it.size = 1.0f; it.rays = 10; it.noise = 0.55f; it.soft = 0.12f; it.bright = 1.2f; it.color = argb(0xFFFFEBD0L) }
            el(f, 7) { it.size = 1.7f; it.rays = 6; it.noise = 0.8f; it.soft = 0.05f; it.bright = 0.6f; it.color = argb(0xFFFFF4E0L); it.rot = 18f }
            el(f, 13) { it.pos = 0.45f; it.size = 0.12f; it.sides = 6; it.round = 0.1f; it.soft = 0.2f; it.grad = 0.6f; it.chroma = 0.4f; it.bright = 0.45f; it.color = argb(0xFFC8E090L); it.follow = true } // hex ghost
            el(f, 13) { it.pos = -1.0f; it.size = 0.065f; it.sides = 4; it.round = 0.4f; it.stretch = 0.55f; it.soft = 0.25f; it.grad = 0.5f; it.bright = 0.65f; it.color = argb(0xFFFF6A80L) } // pink ghost
            el(f, 0) { it.pos = -0.9f; it.size = 0.09f; it.stretch = 4f; it.rot = -40f; it.soft = 0.6f; it.bright = 0.5f; it.color = argb(0xFFD8E860L) } // yellow-green streak
            el(f, 13) { it.pos = 2.1f; it.size = 0.1f; it.sides = 4; it.star = 0.85f; it.chroma = 1f; it.soft = 0.1f; it.grad = 0.6f; it.bright = 0.8f; it.color = argb(0xFF70FF90L); it.follow = true } // prism star
            el(f, 7) { it.pos = 2.1f; it.size = 0.3f; it.rays = 4; it.soft = 0.2f; it.bright = 0.5f; it.color = argb(0xFF70FFB0L) }
            el(f, 15) { it.pos = 2.3f; it.size = 0.58f; it.thick = 0.1f; it.soft = 0.5f; it.spread = 0.35f; it.chroma = 0.9f; it.bright = 0.6f; it.color = argb(0xFF70E070L); it.rot = -30f } // green arc
            el(f, 15) { it.pos = 2.3f; it.size = 0.5f; it.thick = 0.08f; it.soft = 0.5f; it.spread = 0.25f; it.chroma = 0.7f; it.bright = 0.4f; it.color = argb(0xFFFFA040L); it.rot = 10f } // orange arc
            el(f, 13) { it.pos = 1.95f; it.size = 0.035f; it.sides = 3; it.chroma = 1f; it.soft = 0.2f; it.grad = 0.4f; it.bright = 0.6f; it.color = argb(0xFF8080FFL) }
        }
        make("Hot Star", 0xFFFFF3DCL) { f ->
            el(f, 0) { it.size = 1.9f; it.bright = 0.28f; it.soft = 1f }
            el(f, 0) { it.size = 0.62f; it.bright = 1.6f; it.soft = 0.8f }
            el(f, 0) { it.size = 0.14f; it.bright = 1.8f; it.soft = 0.3f }
            el(f, 7) { it.size = 1.3f; it.rays = 8; it.noise = 0.4f; it.bright = 1.0f }
            el(f, 9) { it.size = 2.4f; it.stretch = 3f; it.thick = 0.06f; it.bright = 0.6f; it.color = argb(0xFFFFE3B8L) }
            el(f, 8) { it.pos = 1f; it.size = 1.0f; it.thick = 0.1f; it.chroma = 0.7f; it.bright = 0.5f }
            el(f, 14) { it.pos = 0.5f; it.size = 0.13f; it.rays = 5; it.spread = 0.3f; it.chroma = 0.5f; it.color = argb(0xFFFFD9A0L); it.bright = 0.6f }
            el(f, 11) { it.pos = 1.3f; it.size = 1.0f; it.thick = 0.3f; it.chroma = 0.8f; it.bright = 0.22f }
        }
        make("Cinema Anamorphic", 0xFFB8DCFFL) { f ->
            el(f, 0) { it.size = 1.2f; it.bright = 0.35f; it.soft = 1f; it.color = argb(0xFF4F8CFFL) }
            el(f, 9) { it.size = 3.2f; it.stretch = 5f; it.thick = 0.05f; it.soft = 0.4f; it.bright = 1.7f; it.color = argb(0xFF9CD0FFL) }
            el(f, 9) { it.size = 1.6f; it.stretch = 3f; it.thick = 0.18f; it.soft = 0.8f; it.bright = 0.5f; it.color = argb(0xFF4F9CFFL) }
            el(f, 0) { it.size = 0.3f; it.bright = 1.5f; it.soft = 0.6f }
            el(f, 14) { it.pos = 0.6f; it.size = 0.2f; it.rays = 6; it.spread = 0.28f; it.stretch = 0.45f; it.grad = 0.7f; it.chroma = 0.4f; it.color = argb(0xFF80C8FFL); it.bright = 0.5f }
            el(f, 8) { it.pos = 0.8f; it.size = 0.5f; it.thick = 0.2f; it.chroma = 0.5f; it.bright = 0.35f; it.color = argb(0xFF7EC8FFL) }
            el(f, 6) { it.pos = 1.3f; it.size = 0.06f; it.bright = 0.8f; it.color = argb(0xFFFFB070L) }
        }
        make("Lens Ghosts", 0xFFFFFFFFL) { f ->
            el(f, 0) { it.size = 0.4f; it.bright = 1.4f; it.soft = 0.7f }
            el(f, 7) { it.size = 0.9f; it.rays = 6; it.bright = 0.8f }
            el(f, 14) { it.pos = 0.35f; it.size = 0.16f; it.rays = 7; it.spread = 0.3f; it.chroma = 0.8f; it.bright = 0.5f }
            el(f, 14) { it.pos = 0.5f; it.size = 0.3f; it.rays = 3; it.spread = 0.55f; it.thick = 0.25f; it.chroma = 0.5f; it.color = argb(0xFF8FC8FFL); it.bright = 0.45f }
            el(f, 8) { it.pos = 1f; it.size = 1.2f; it.thick = 0.1f; it.chroma = 1f; it.bright = 0.5f }
        }
        make("Sun Glare", 0xFFFFEBC0L) { f ->
            el(f, 0) { it.size = 1.3f; it.bright = 1.0f; it.soft = 1.0f }
            el(f, 0) { it.size = 0.35f; it.bright = 1.8f; it.soft = 0.5f }
            el(f, 10) { it.size = 1.2f; it.rays = 22; it.noise = 0.9f; it.bright = 1.1f }
            el(f, 11) { it.pos = 0.9f; it.size = 1.1f; it.thick = 0.45f; it.chroma = 0.7f; it.bright = 0.35f }
            el(f, 14) { it.pos = 0.5f; it.size = 0.18f; it.sides = 8; it.rays = 6; it.spread = 0.3f; it.chroma = 0.6f; it.color = argb(0xFFFFD090L); it.bright = 0.5f }
        }
        make("Neon Spike", 0xFFFFFFFFL) { f ->
            el(f, 0) { it.size = 0.35f; it.bright = 1.6f; it.color = argb(0xFFFF4FD8L) }
            el(f, 10) { it.size = 1.1f; it.rays = 14; it.noise = 0.7f; it.color = argb(0xFFFF6FE0L); it.bright = 1.2f }
            el(f, 12) { it.size = 0.9f; it.rays = 12; it.noise = 0.6f; it.color = argb(0xFF4FE0FFL); it.bright = 0.9f }
            el(f, 9) { it.size = 2.0f; it.stretch = 3f; it.thick = 0.05f; it.color = argb(0xFF6FE8FFL); it.bright = 1.0f }
            el(f, 14) { it.pos = 0.7f; it.size = 0.15f; it.sides = 4; it.rays = 4; it.spread = 0.4f; it.chroma = 0f; it.color = argb(0xFFFF6FE0L); it.bright = 0.5f }
            el(f, 8) { it.pos = 1.1f; it.size = 0.7f; it.thick = 0.1f; it.color = argb(0xFFFF6FE0L); it.bright = 0.6f }
        }
        make("Crystal", 0xFFE8F4FFL) { f ->
            el(f, 0) { it.size = 0.45f; it.bright = 1.5f; it.soft = 0.7f }
            el(f, 7) { it.size = 1.0f; it.rays = 4; it.soft = 0.8f; it.bright = 1.2f }
            el(f, 14) { it.pos = 0.5f; it.size = 0.18f; it.sides = 6; it.star = 0.5f; it.rays = 5; it.spread = 0.3f; it.chroma = 0.7f; it.grad = 0.8f; it.bright = 0.6f }
            el(f, 13) { it.pos = 1.7f; it.size = 0.15f; it.sides = 4; it.star = 0.85f; it.bright = 0.9f; it.follow = true }
        }
        make("Golden Hour", 0xFFFFD9A0L) { f ->
            el(f, 0) { it.size = 2.2f; it.bright = 0.4f; it.soft = 1f; it.color = argb(0xFFFF9A40L) }
            el(f, 0) { it.size = 0.7f; it.bright = 1.5f; it.soft = 0.8f }
            el(f, 9) { it.size = 2.6f; it.stretch = 4f; it.thick = 0.07f; it.bright = 0.9f; it.color = argb(0xFFFFC070L) }
            el(f, 12) { it.size = 0.8f; it.rays = 10; it.noise = 0.4f; it.bright = 0.5f }
            el(f, 14) { it.pos = 0.5f; it.size = 0.22f; it.rays = 6; it.spread = 0.3f; it.round = 0.5f; it.soft = 0.3f; it.grad = 0.8f; it.chroma = 0.3f; it.color = argb(0xFFFFB060L); it.bright = 0.5f }
            el(f, 11) { it.pos = 1.2f; it.size = 1.2f; it.thick = 0.35f; it.chroma = 0.5f; it.bright = 0.2f }
        }
        make("Teal and Orange", 0xFFFFFFFFL) { f ->
            el(f, 0) { it.size = 0.8f; it.bright = 1.2f; it.soft = 0.9f; it.color = argb(0xFFFFA050L) }
            el(f, 0) { it.size = 0.2f; it.bright = 1.6f; it.soft = 0.4f }
            el(f, 9) { it.size = 3.0f; it.stretch = 4.5f; it.thick = 0.05f; it.bright = 1.2f; it.color = argb(0xFF35D4C8L) }
            el(f, 7) { it.size = 1.0f; it.rays = 6; it.bright = 0.6f; it.color = argb(0xFFFFC890L) }
            el(f, 14) { it.pos = 0.55f; it.size = 0.2f; it.rays = 5; it.spread = 0.34f; it.stretch = 0.6f; it.grad = 0.7f; it.chroma = 0.2f; it.color = argb(0xFF35D4C8L); it.bright = 0.5f }
            el(f, 8) { it.pos = 1.1f; it.size = 0.8f; it.thick = 0.12f; it.bright = 0.5f; it.color = argb(0xFFFFA050L) }
        }
        make("Blockbuster Hero", 0xFFFFFFFFL) { f ->
            el(f, 0) { it.size = 1.4f; it.bright = 0.6f; it.soft = 1f; it.color = argb(0xFFBFD8FFL) }
            el(f, 0) { it.size = 0.5f; it.bright = 1.8f; it.soft = 0.6f }
            el(f, 7) { it.size = 1.8f; it.rays = 8; it.noise = 0.5f; it.bright = 1.1f }
            el(f, 9) { it.size = 3.4f; it.stretch = 5f; it.thick = 0.05f; it.bright = 1.5f; it.color = argb(0xFFD8E8FFL) }
            el(f, 14) { it.pos = 0.45f; it.size = 0.16f; it.rays = 7; it.spread = 0.27f; it.chroma = 0.6f; it.bright = 0.55f }
            el(f, 14) { it.pos = 1.4f; it.size = 0.3f; it.rays = 3; it.spread = 0.3f; it.thick = 0.3f; it.chroma = 0.5f; it.color = argb(0xFFA8CCFFL); it.bright = 0.4f }
            el(f, 11) { it.pos = 1.0f; it.size = 1.5f; it.thick = 0.4f; it.chroma = 0.9f; it.bright = 0.25f }
        }
        make("Vintage Anamorphic", 0xFFFFE6B0L) { f ->
            el(f, 0) { it.size = 0.9f; it.bright = 1.0f; it.soft = 1f; it.color = argb(0xFFFFB050L) }
            el(f, 9) { it.size = 3.0f; it.stretch = 4f; it.thick = 0.12f; it.soft = 0.7f; it.bright = 1.0f; it.color = argb(0xFFFFC060L) }
            el(f, 14) { it.pos = 0.6f; it.size = 0.28f; it.rays = 5; it.spread = 0.36f; it.round = 1f; it.soft = 0.3f; it.grad = 0.9f; it.noise = 0.6f; it.chroma = 0.3f; it.color = argb(0xFFFFB868L); it.bright = 0.45f }
            el(f, 12) { it.size = 0.7f; it.rays = 12; it.noise = 0.6f; it.bright = 0.5f }
            el(f, 8) { it.pos = 1f; it.size = 1.0f; it.thick = 0.15f; it.chroma = 0.6f; it.bright = 0.4f }
        }
        make("Deep Space", 0xFFD8D0FFL) { f ->
            el(f, 0) { it.size = 1.5f; it.bright = 0.5f; it.soft = 1f; it.color = argb(0xFF7A5CFFL) }
            el(f, 0) { it.size = 0.3f; it.bright = 1.7f; it.soft = 0.5f }
            el(f, 10) { it.size = 1.4f; it.rays = 16; it.noise = 0.8f; it.bright = 0.9f; it.color = argb(0xFFB8A8FFL) }
            el(f, 9) { it.size = 2.4f; it.stretch = 4f; it.thick = 0.05f; it.bright = 1.0f; it.color = argb(0xFF8FA8FFL) }
            el(f, 14) { it.pos = 0.6f; it.size = 0.14f; it.sides = 5; it.star = 0.5f; it.rays = 6; it.spread = 0.3f; it.chroma = 0.9f; it.bright = 0.5f }
            el(f, 11) { it.pos = 1.3f; it.size = 1.3f; it.thick = 0.5f; it.chroma = 1f; it.bright = 0.25f }
        }
        make("Cine Multi Iris", 0xFFFFF4E0L) { f ->
            el(f, 0) { it.size = 0.5f; it.bright = 1.5f; it.soft = 0.7f }
            el(f, 9) { it.size = 2.2f; it.stretch = 4f; it.thick = 0.06f; it.bright = 0.9f }
            el(f, 14) { it.pos = 0.3f; it.size = 0.12f; it.rays = 8; it.spread = 0.22f; it.chroma = 0.7f; it.bright = 0.55f }
            el(f, 14) { it.pos = 0.5f; it.size = 0.26f; it.rays = 4; it.spread = 0.45f; it.thick = 0.3f; it.curve = 0.8f; it.chroma = 0.5f; it.color = argb(0xFFA8D0FFL); it.bright = 0.45f }
            el(f, 14) { it.pos = 0.9f; it.size = 0.18f; it.sides = 8; it.rays = 5; it.spread = 0.3f; it.round = 0.4f; it.grad = 0.9f; it.color = argb(0xFFFFC890L); it.bright = 0.4f }
            el(f, 8) { it.pos = 1f; it.size = 1.1f; it.thick = 0.1f; it.chroma = 0.8f; it.bright = 0.4f }
        }
        make("Classic", 0xFFFFFFFFL) { f ->
            el(f, 0) { it.size = 0.5f; it.bright = 1.5f; it.soft = 0.6f }
            el(f, 4) { it.pos = 1f; it.size = 0.8f; it.thick = 0.06f; it.bright = 0.6f }
            el(f, 13) { it.pos = 1.6f; it.size = 0.28f; it.sides = 6; it.thick = 0.5f; it.bright = 0.8f }
            el(f, 6) { it.pos = 0.6f; it.size = 0.1f }
        }
        make("Sunbeam", 0xFFFFE9B0L) { f ->
            el(f, 0) { it.size = 0.7f; it.bright = 1.8f; it.soft = 0.4f }
            el(f, 9) { it.size = 1.8f; it.stretch = 5f; it.thick = 0.06f; it.bright = 1.2f }
            el(f, 7) { it.size = 1.1f; it.rays = 6; it.bright = 0.9f }
        }
        make("Rainbow ring", 0xFFFFFFFFL) { f ->
            el(f, 0) { it.size = 0.3f; it.bright = 1.3f }
            el(f, 11) { it.pos = 1f; it.size = 1.1f; it.thick = 0.6f; it.chroma = 1f; it.bright = 0.8f }
        }
        make("Sci-fi", 0xFFB0FFE9L) { f ->
            el(f, 0) { it.size = 0.42f; it.bright = 1.6f; it.soft = 0.8f }
            el(f, 13) { it.pos = 1f; it.size = 0.5f; it.sides = 6; it.thick = 0.5f; it.follow = true }
            el(f, 13) { it.pos = 1.4f; it.size = 0.3f; it.sides = 6; it.thick = 1f; it.follow = true }
            el(f, 7) { it.size = 0.9f; it.rays = 4; it.soft = 0.8f }
        }
            return out
        }

        // -- user presets on disk --
        fun userFile(): File = File(Projects.root, "flares.json")

        fun loadUser() {
            user = mutableListOf()
            val o = readDictionary(userFile()) ?: return
            o.optJSONArray("flares")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { user.add(fromJson(it)) } }
        }

        fun saveUser() {
            val a = JSONArray(); for (f in user) a.put(f.toJson())
            writeAtomic(userFile(), JSONObject().put("flares", a).toPretty(4))
        }

        /** FlareThumbs.elementPreviews(): one single-element flare per element type. */
        fun elementPreviews(): List<Flare> = FlareEl.TYPES.indices.map { t ->
            val f = Flare(); f.name = FlareEl.TYPES[t]
            val e = FlareEl.make(t); e.pos = if (t == 14) 0.5f else 1f; e.follow = false
            if (t == 2 || t == 9) e.size = min(e.size, 1.0f)
            f.els = mutableListOf(e)
            f
        }
    }
}
