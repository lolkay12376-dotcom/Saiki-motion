package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.UIGraphicsImageRenderer
import com.saiki.motion.uikit.UIImage
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

// Port of Sources/Model/Flare.swift:684 FlareThumbs — CPU-drawn flare thumbnails for the browser.
object FlareThumbs {
    val cache = HashMap<String, Bitmap>()

    /** One single-element flare per element type (the Add-element browser thumbnails). */
    fun elementPreviews(): List<Flare> =
        FlareEl.TYPES.indices.map { t ->
            val f = Flare()
            f.name = FlareEl.TYPES[t]
            val e = FlareEl.make(t)
            e.pos = if (t == 14) 0.5f else 1f
            e.follow = false
            if (t == 2 || t == 9) e.size = min(e.size, 1.0f)
            f.els = mutableListOf(e)
            f
        }

    private val pending = HashSet<String>()   // main-thread only
    private val queue = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "flare.thumbs") }

    fun generate(flares: List<Flare>, done: () -> Unit) {
        val todo = ArrayList<Pair<String, Flare>>()
        for (f in flares) {
            val key = f.sig()
            if (cache.containsKey(key) || pending.contains(key)) continue
            pending.add(key)
            todo.add(Pair(key, f.copy()))
        }
        if (todo.isEmpty()) return
        queue.execute {
            for ((key, f) in todo) {
                val img = render(f)
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    cache[key] = img
                    pending.remove(key)
                }
            }
            android.os.Handler(android.os.Looper.getMainLooper()).post(done)
        }
    }

    private fun glow(c: CGContext, r: CGFloat, col: Int, a: CGFloat, power: CGFloat = 1f) {
        val stops = floatArrayOf(0f, 0.25f, 0.6f, 1f)
        val alphas = floatArrayOf(1f, 0.45f, 0.1f, 0f).map { v -> (v.toDouble().pow(power.toDouble()).toFloat()) * a }
        val colors = IntArray(alphas.size) { i -> ((alphas[i] * 255).toInt().coerceIn(0, 255) shl 24) or (col and 0xFFFFFF) }
        val shader = RadialGradient(0f, 0f, max(1f, r), colors, stops, Shader.TileMode.CLAMP)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.shader = shader }
        c.canvas.drawCircle(0f, 0f, max(1f, r), p)
    }

    fun irisPath(d: IrisDef, r: CGFloat): Path {
        val p = Path()
        val n = 120
        for (i in 0..n) {
            val a = i.toFloat() / n.toFloat() * 2f * Math.PI.toFloat()
            val rr = d.radius(a) * r
            val x = sin(a) * rr; val y = -cos(a) * rr
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        return p
    }

    /** Simple linear RGB mix used for tinting flare elements. */
    private fun mixed(c1: Int, c2: Int, t: CGFloat): Int {
        fun ch(a: Int, b: Int, shift: Int): Int {
            val x = (a shr shift) and 0xFF; val y = (b shr shift) and 0xFF
            return (x + (y - x) * t).toInt().coerceIn(0, 255)
        }
        return (0xFF shl 24) or (ch(c1, c2, 16) shl 16) or (ch(c1, c2, 8) shl 8) or ch(c1, c2, 0)
    }

    private fun render(f: Flare): Bitmap {
        val w = 112; val h = 64
        val r = UIGraphicsImageRenderer(w * 2, h * 2)
        return r.image { c ->
            c.scaleBy(2f, 2f)
            c.setFillColor(0xFF08080C.toInt())
            c.fill(CGRect(0f, 0f, w.toFloat(), h.toFloat()))
            val cx0 = w * 0.2f
            val cx1 = w * 0.8f
            val cy = h / 2f
            val tint = f.tint
            c.paint.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.ADD)

            for (e in f.els) {
                if (!e.enabled) continue
                val ex = cx0 + (cx1 - cx0) * (e.pos / 2f)
                val es = e.size * h * 0.5f
                val col = mixed(tint or 0xFF000000.toInt(), e.color, 0.65f)
                val br = (e.bright * 0.8f).coerceIn(0f, 1.2f)
                c.saveGState()
                c.translateBy(ex, cy)
                c.rotate(e.rot * Math.PI.toFloat() / 180f)
                when (e.type) {
                    14 -> {
                        val n = e.rays.toFloat().coerceIn(2f, 8f).toInt()
                        for (k in 0 until n) {
                            val kk = k.toFloat()
                            c.saveGState()
                            c.translateBy(kk * e.spread * (cx1 - cx0) / 2, 0f)
                            val d = IrisDef(e); d.round = e.round
                            val path = irisPath(d, es * (1f - 0.06f * kk))
                            val hue = android.graphics.Color.HSVToColor(floatArrayOf(((0.08f + kk * 0.17f) % 1f) * 360f, 0.65f * e.chroma, 1f))
                            val cc = mixed(col, hue, e.chroma * 0.8f)
                            c.setAlpha(min(1f, br * 0.9f / (1f + 0.12f * kk)))
                            if (d.thick >= 0.95f) { c.addPath(path); c.setFillColor(((0.55f * 255).toInt() shl 24) or (cc and 0xFFFFFF)); c.fillPath() }
                            c.addPath(path); c.setStrokeColor(cc)
                            c.setLineWidth(max(1.2f, es * min(d.thick, 0.5f) * 0.5f)); c.strokePath()
                            c.restoreGState()
                        }
                    }
                    0, 12 -> glow(c, es * 1.1f, col, min(1f, br), power = 0.8f)
                    1, 5, 13 -> {
                        val d = IrisDef(e)
                        if (e.type != 13) { d.star = 0f; d.round = 0f; d.curve = 0f }
                        val path = irisPath(d, es)
                        c.setAlpha(min(1f, br * 0.9f))
                        if (d.thick >= 0.95f) { c.addPath(path); c.setFillColor(((0.55f * 255).toInt() shl 24) or (col and 0xFFFFFF)); c.fillPath() }
                        c.addPath(path); c.setStrokeColor(col)
                        c.setLineWidth(max(1.2f, es * min(d.thick, 0.5f) * 0.5f)); c.strokePath()
                    }
                    2, 9 -> {
                        c.saveGState()
                        c.scaleBy(max(2f, e.stretch) * 1.2f, max(0.08f, e.thick) * 0.9f)
                        glow(c, es * 0.9f, col, min(1f, br), power = 0.9f)
                        c.restoreGState()
                    }
                    3, 7, 10 -> {
                        val n = if (e.rays > 3f) e.rays else 3f.toInt()
                        c.setStrokeColor(((min(1f, br) * 255).toInt() shl 24) or (col and 0xFFFFFF))
                        c.setLineWidth(if (e.type == 3) max(1f, es * 0.06f) else 0.8f)
                        c.beginPath()
                        for (i in 0 until n) {
                            val a = i.toFloat() / n.toFloat() * 2f * Math.PI.toFloat()
                            val len = es * (if (e.type == 3) 1f else (1f - e.noise * ((i * 37) % 10).toFloat() / 14f))
                            c.move(CGPoint(0f, 0f))
                            c.addLine(CGPoint(cos(a) * len, sin(a) * len))
                        }
                        c.strokePath()
                        glow(c, es * 0.35f, col, min(1f, br) * 0.7f)
                    }
                    4, 8 -> {
                        c.setStrokeColor(((min(1f, br) * 255).toInt() shl 24) or (col and 0xFFFFFF))
                        c.setLineWidth(max(1.2f, es * e.thick * 0.5f))
                        c.strokeEllipse(CGRect(-es * 0.5f, -es * 0.5f, es, es))
                    }
                    11 -> {
                        val cols = intArrayOf(0xFFFF0000.toInt(), 0xFFFFA500.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(), 0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFF800080.toInt())
                        for ((i, rc) in cols.withIndex()) {
                            c.setStrokeColor(((min(1f, br) * 255).toInt() shl 24) or (rc and 0xFFFFFF))
                            c.setLineWidth(max(1f, es * 0.05f))
                            val rr = es * (0.62f + 0.38f * i.toFloat() / 6f)
                            c.strokeEllipse(CGRect(-rr, -rr, rr * 2, rr * 2))
                        }
                    }
                    15 -> {
                        c.setStrokeColor(((min(1f, br) * 255).toInt() shl 24) or (col and 0xFFFFFF))
                        c.setLineWidth(max(1.2f, es * e.thick * 0.5f))
                        val hs = e.spread * Math.PI.toFloat()
                        val p = Path().apply { arcTo(android.graphics.RectF(-es * 0.5f, -es * 0.5f, es * 0.5f, es * 0.5f), -hs * 180f / Math.PI.toFloat(), hs * 2 * 180f / Math.PI.toFloat()) }
                        c.addPath(p); c.strokePath()
                    }
                    else -> {
                        c.setFillColor(col)
                        c.fillEllipse(CGRect(-es * 0.5f, -es * 0.5f, es, es))
                    }
                }
                c.restoreGState()
            }
        }.bitmap
    }
}
