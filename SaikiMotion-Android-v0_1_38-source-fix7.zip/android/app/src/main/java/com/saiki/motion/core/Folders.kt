package com.saiki.motion.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.UUID

// Port of Sources/Model/Folders.swift — project folders (folders.json beside the projects).
class ProjectFolder(var id: String, var name: String)

object Folders {
    private val fileURL: File get() = File(Paths.root, "folders.json")
    private class State(val folders: MutableList<ProjectFolder>, val assign: MutableMap<String, String>)
    private var cache: State? = null

    private fun load(): State {
        cache?.let { return it }
        val out = State(mutableListOf(), LinkedHashMap())
        try {
            val o = JSONObject(fileURL.readText(Charsets.UTF_8))
            o.optJSONArray("folders")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { f ->
                if (f.has("id") && f.has("name")) out.folders.add(ProjectFolder(f.getString("id"), f.getString("name"))) } }
            o.optJSONObject("assign")?.let { m -> for (k in m.keys()) out.assign[k] = m.optString(k, "") }
        } catch (_: Exception) {}
        cache = out
        return out
    }

    private fun save(v: State) {
        cache = v
        val o = JSONObject()
        o.put("folders", JSONArray().also { a -> for (f in v.folders) a.put(JSONObject().put("id", f.id).put("name", f.name)) })
        o.put("assign", JSONObject().also { m -> for ((k, x) in v.assign) m.put(k, x) })
        try {
            Paths.root.mkdirs()
            val tmp = File(Paths.root, "folders.json.tmp"); tmp.writeText(o.toCompact(), Charsets.UTF_8)
            tmp.renameTo(fileURL)
        } catch (_: Exception) {}
    }

    val all: List<ProjectFolder> get() = load().folders
    fun folderOf(projectId: String): String? = load().assign[projectId]
    fun name(id: String): String = load().folders.firstOrNull { it.id == id }?.name ?: "Folder"
    fun count(id: String): Int = load().assign.values.count { it == id }

    fun create(name: String): ProjectFolder {
        val v = load()
        val f = ProjectFolder(UUID.randomUUID().toString().uppercase(Locale.US), name)
        v.folders.add(f); save(v)
        return f
    }
    fun rename(id: String, name: String) { val v = load(); v.folders.firstOrNull { it.id == id }?.name = name; save(v) }
    /** Deleting a folder never deletes projects — they go back to the main list. */
    fun delete(id: String) {
        val v = load()
        v.folders.removeAll { it.id == id }
        val keep = LinkedHashMap<String, String>(); for ((k, x) in v.assign) if (x != id) keep[k] = x
        save(State(v.folders, keep))
    }
    fun move(projectId: String, toFolder: String?) { val v = load(); if (toFolder != null) v.assign[projectId] = toFolder else v.assign.remove(projectId); save(v) }
}
