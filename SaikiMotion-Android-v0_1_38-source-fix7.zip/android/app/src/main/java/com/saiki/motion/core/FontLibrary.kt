package com.saiki.motion.core

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipInputStream

// Port of Sources/Support/FontLibrary.swift (MiniZip -> java.util.zip; CGFont names -> sfnt 'name' table reader).
// Layout: <Paths.root>/Fonts/<files> + library.json {folders:[{id,name}], fonts:[{id,name,file,folder?}]}

class FontFolder(var id: String, var name: String)
class FontRecord(var id: String, var name: String, var file: String, var folder: String?)

object MiniZip {
    class Entry(val name: String, val data: ByteArray)

    /** Every file whose lower-cased name passes `accept` (stored + deflate, < 80 MB each like iOS). */
    fun read(input: java.io.InputStream, accept: (String) -> Boolean): List<Entry> {
        val out = ArrayList<Entry>()
        try {
            ZipInputStream(input).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    if (e.isDirectory || !accept(e.name.lowercase(Locale.ROOT))) continue
                    val bo = ByteArrayOutputStream(); val buf = ByteArray(1 shl 16); var total = 0L; var ok = true
                    while (true) { val r = z.read(buf); if (r <= 0) break; total += r; if (total >= 80_000_000L) { ok = false; break }; bo.write(buf, 0, r) }
                    if (ok) out.add(Entry(e.name, bo.toByteArray()))
                }
            }
        } catch (_: Exception) {}
        return out
    }
}

object FontLibrary {
    private val folders_ = mutableListOf<FontFolder>()
    private val fonts_ = mutableListOf<FontRecord>()
    private var loaded = false

    val folders: List<FontFolder> get() { ensure(); return folders_ }
    val fonts: List<FontRecord> get() { ensure(); return fonts_ }

    val dir: File get() { val u = File(Paths.root, "Fonts"); u.mkdirs(); return u }
    private val indexFile: File get() = File(dir, "library.json")

    @Synchronized private fun ensure() {
        if (loaded) return; loaded = true
        try {
            val o = JSONObject(indexFile.readText())
            o.optJSONArray("folders")?.let { a -> for (i in 0 until a.length()) { val f = a.getJSONObject(i); folders_.add(FontFolder(f.getString("id"), f.getString("name"))) } }
            o.optJSONArray("fonts")?.let { a -> for (i in 0 until a.length()) { val f = a.getJSONObject(i); fonts_.add(FontRecord(f.getString("id"), f.getString("name"), f.getString("file"), if (f.has("folder") && !f.isNull("folder")) f.getString("folder") else null)) } }
        } catch (_: Exception) { folders_.clear(); fonts_.clear() }   // iOS: any decode failure -> empty FontIndex
    }

    private fun save() {
        val o = JSONObject()
        val fa = JSONArray(); for (f in folders_) fa.put(JSONObject().put("id", f.id).put("name", f.name))
        val na = JSONArray(); for (f in fonts_) { val j = JSONObject().put("id", f.id).put("name", f.name).put("file", f.file); if (f.folder != null) j.put("folder", f.folder); na.put(j) }
        o.put("folders", fa); o.put("fonts", na)
        try { val tmp = File(dir, "library.json.tmp"); tmp.writeText(o.toString()); tmp.renameTo(indexFile) } catch (_: Exception) {}
    }

    fun path(f: FontRecord): String = File(dir, f.file).path
    fun fonts(folder: String?): List<FontRecord> { ensure(); return fonts_.filter { it.folder == folder }.sortedBy { it.name.lowercase(Locale.ROOT) } }
    fun count(folder: String): Int { ensure(); return fonts_.count { it.folder == folder } }

    /** A stored path whose container moved still resolves by file name. */
    fun resolve(path: String): String {
        if (File(path).exists()) return path
        val alt = File(dir, File(path).name).path
        return if (File(alt).exists()) alt else path
    }

    // folders
    fun addFolder(name: String): FontFolder { ensure(); val f = FontFolder(UUID.randomUUID().toString().uppercase(Locale.US), name); folders_.add(f); save(); return f }
    fun renameFolder(id: String, name: String) { ensure(); folders_.firstOrNull { it.id == id }?.let { it.name = name; save() } }
    /** Deleting a folder keeps its fonts (they move back to the top level). */
    fun deleteFolder(id: String) { ensure(); folders_.removeAll { it.id == id }; for (f in fonts_) if (f.folder == id) f.folder = null; save() }
    fun move(fontId: String, folder: String?) { ensure(); fonts_.firstOrNull { it.id == fontId }?.let { it.folder = folder; save() } }
    fun rename(fontId: String, name: String) { ensure(); fonts_.firstOrNull { it.id == fontId }?.let { it.name = name; save() } }
    fun delete(fontId: String) {
        ensure(); val i = fonts_.indexOfFirst { it.id == fontId }; if (i < 0) return
        try { File(dir, fonts_[i].file).delete() } catch (_: Exception) {}
        fonts_.removeAt(i); save()
    }

    private fun isFont(n: String) = n.endsWith(".ttf") || n.endsWith(".otf")

    /** Adds font files and/or zip packs (content:// or file:// Uris). A zip with several fonts gets its own folder. Returns how many fonts were added. */
    fun importURLs(uris: List<Uri>, folder: String?): Int {
        ensure(); var added = 0
        val cr = Paths.appContext.contentResolver
        for (url in uris) {
            val name = Paths.displayName(url)
            val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (ext == "zip") {
                val entries = try { cr.openInputStream(url)?.use { MiniZip.read(it) { n -> isFont(n) && !n.contains("__macosx") && !n.substringAfterLast('/').startsWith("._") } } } catch (_: Exception) { null } ?: continue
                if (entries.isEmpty()) continue
                var target = folder
                if (entries.size > 1) target = addFolder(name.substringBeforeLast('.', name)).id
                for (e in entries) if (add(e.data, e.name.substringAfterLast('/'), target)) added++
            } else if (ext == "ttf" || ext == "otf") {
                val d = try { cr.openInputStream(url)?.use { it.readBytes() } } catch (_: Exception) { null }
                if (d != null && add(d, name, folder)) added++
            }
        }
        save()
        return added
    }

    private fun add(data: ByteArray, filename: String, folder: String?): Boolean {
        val nm = SfntNames.read(data) ?: return false      // iOS: CGFont(provider) fails for non-fonts
        val ps = nm.first ?: filename
        if (fonts_.any { it.name == ps && it.folder == folder }) return false
        val id = UUID.randomUUID().toString().uppercase(Locale.US)
        val file = id.take(8) + "_" + filename
        try { File(dir, file).writeBytes(data) } catch (_: Exception) { return false }
        fonts_.add(FontRecord(id, nm.second ?: ps, file, folder))
        return true
    }
}

/** Minimal sfnt 'name' reader: returns (PostScript name [id 6], full name [id 4]) or null when data is not an sfnt font. */
object SfntNames {
    private fun u16(d: ByteArray, o: Int) = ((d[o].toInt() and 0xFF) shl 8) or (d[o + 1].toInt() and 0xFF)
    private fun u32(d: ByteArray, o: Int) = (u16(d, o).toLong() shl 16) or u16(d, o + 2).toLong()
    fun read(d: ByteArray): Pair<String?, String?>? {
        try {
            if (d.size < 12) return null
            var off = 0
            val tag = String(d, 0, 4, Charsets.ISO_8859_1)
            if (tag == "ttcf") off = u32(d, 12).toInt()
            else if (!(u32(d, 0) == 0x00010000L || tag == "OTTO" || tag == "true" || tag == "typ1")) return null
            val n = u16(d, off + 4)
            var nameOff = -1
            for (i in 0 until n) { val r = off + 12 + i * 16; if (String(d, r, 4, Charsets.ISO_8859_1) == "name") { nameOff = u32(d, r + 8).toInt(); break } }
            if (nameOff < 0) return Pair(null, null)
            val count = u16(d, nameOff + 2); val strOff = nameOff + u16(d, nameOff + 4)
            fun find(id: Int): String? {
                var best: String? = null; var rank = -1
                for (i in 0 until count) {
                    val r = nameOff + 6 + i * 12
                    if (u16(d, r + 6) != id) continue
                    val plat = u16(d, r); val len = u16(d, r + 8); val so = strOff + u16(d, r + 10)
                    if (so + len > d.size) continue
                    val rk = if (plat == 3) 3 else if (plat == 0) 2 else if (plat == 1) 1 else 0
                    if (rk <= rank || rk == 0) continue
                    best = if (plat == 1) String(d, so, len, Charsets.ISO_8859_1) else String(d, so, len, Charsets.UTF_16BE); rank = rk
                }
                return best
            }
            return Pair(find(6), find(4))
        } catch (_: Exception) { return null }
    }
}
