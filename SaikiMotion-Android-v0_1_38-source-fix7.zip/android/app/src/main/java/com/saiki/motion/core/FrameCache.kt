package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// Port of Sources/Render/FrameCache.swift — rendered-frame cache for live playback.
// While the timeline plays, every live-rendered frame is also written as a JPEG into
// <cache>/SaikiMotion/frames/<projectId>/. Second pass shows cached frames instead of
// re-running the pipeline. Any edit bumps `version`; older frames are purged lazily.
object FrameCache {
    /** Bumped by every edit. Starts from the clock so earlier-launch frames can never be shown. */
    @JvmField var version: Int = (System.currentTimeMillis() / 1000L).toInt() and 0x3FFFFFFF
    @JvmField var playing = false       // playback reads from / fills the cache
    @JvmField var scrubbing = false     // dragging the timeline also reads cached frames (smooth scrub)
    /** Live render cache on/off (Scene setup → Live render cache, Home → Extras). */
    var enabled: Boolean
        get() = Prefs.getBool("liveCache", true)
        set(v) { Prefs.setBool("liveCache", v) }
    const val fps: Float = 30f

    @JvmField var suspended = false                     // memory warning → stop rendering ahead
    @JvmField var liveBytes: Long = 0                   // written this session (approx.)
    const val maxLiveBytes: Long = 700L * 1_048_576L
    val liveFull: Boolean get() = liveBytes >= maxLiveBytes
    private val cachedIdx = HashSet<Int>()
    private var cachedVer = -1
    private var cachedKey = ""
    private var runs = ArrayList<Pair<Float, Float>>()
    private var runsDirty = true

    private val queue = Executors.newSingleThreadExecutor { r -> Thread(r, "saiki.framecache") }
    private val lock = Object()
    private val pending = HashSet<String>()
    private val purged = HashMap<String, Int>()

    val root: File get() = File(Paths.cache, "frames")

    fun bump() { version = version + 1 }

    private fun frameIndex(t: Float): Int = (max(0f, t) * fps).roundToInt()

    private fun name(w: Int, h: Int, q: Int, t: Float): String = "${version}_${q}_${w}x${h}_${frameIndex(t)}.jpg"

    private fun url(pid: String, n: String): File = File(File(root, pid), n)

    private fun syncSet(key: String) {      // call with `lock` held
        if (cachedVer != version || cachedKey != key) {
            cachedVer = version; cachedKey = key
            cachedIdx.clear(); runs = ArrayList(); runsDirty = true
        }
    }

    private fun mark(idx: Int, key: String) {
        synchronized(lock) { syncSet(key); cachedIdx.add(idx); runsDirty = true }
    }

    private fun unmark(idx: Int, key: String) {
        synchronized(lock) { syncSet(key); cachedIdx.remove(idx); runsDirty = true }
    }

    fun lookup(pid: String, w: Int, h: Int, q: Int, t: Float): Bitmap? {
        val u = url(pid, name(w, h, q, t))
        val key = "${pid}_${w}x${h}_$q"
        if (!u.exists()) { unmark(frameIndex(t), key); return null }
        mark(frameIndex(t), key)
        return try { BitmapFactory.decodeFile(u.absolutePath) } catch (_: Exception) { null }
    }

    /** First frame at or after `t` (wrapping round) that is not cached yet; null when all cached. */
    fun nextUncached(t: Float, duration: Float, pid: String, w: Int, h: Int, q: Int): Float? {
        val key = "${pid}_${w}x${h}_$q"
        val total = max(1, (duration * fps).toInt())
        val start = min(total, frameIndex(t))
        val set = synchronized(lock) { syncSet(key); cachedIdx.toHashSet() }
        for (k in 0..total) {
            val i = (start + k) % (total + 1)
            if (set.contains(i)) continue
            val tt = i / fps
            if (has(pid, w, h, q, tt)) { mark(i, key); continue }
            return tt
        }
        return null
    }

    /** Cached time ranges (seconds) for the timeline's green bar. */
    fun cachedRuns(): List<Pair<Float, Float>> {
        synchronized(lock) {
            if (cachedVer != version) { cachedVer = version; cachedIdx.clear(); runs = ArrayList(); runsDirty = false; return emptyList() }
            if (runsDirty) {
                val out = ArrayList<Pair<Float, Float>>()
                var a = -1; var b = -1
                for (i in cachedIdx.sorted()) {
                    if (a < 0) { a = i; b = i }
                    else if (i == b + 1) b = i
                    else { out.add(Pair(a / fps, (b + 1) / fps)); a = i; b = i }
                }
                if (a >= 0) out.add(Pair(a / fps, (b + 1) / fps))
                runs = out
                runsDirty = false
            }
            return runs
        }
    }

    fun has(pid: String, w: Int, h: Int, q: Int, t: Float): Boolean = url(pid, name(w, h, q, t)).exists()

    fun store(pid: String, w: Int, h: Int, q: Int, t: Float, img: Bitmap) {
        val n = name(w, h, q, t)
        val key = "$pid/$n"
        mark(frameIndex(t), "${pid}_${w}x${h}_$q")
        synchronized(lock) {
            if (pending.contains(key)) return
            pending.add(key)
        }
        val ver = version
        queue.execute {
            try {
                val dir = File(root, pid)
                dir.mkdirs()
                if (purged[pid] != ver) {
                    purged[pid] = ver
                    liveBytes = 0
                    val prefix = "${ver}_"
                    dir.listFiles()?.forEach { f -> if (!f.name.startsWith(prefix)) f.delete() }
                }
                val bos = java.io.ByteArrayOutputStream()
                img.compress(Bitmap.CompressFormat.JPEG, 82, bos)
                val d = bos.toByteArray()
                val tmp = File(dir, "$n.tmp")
                tmp.writeBytes(d)
                tmp.renameTo(File(dir, n))
                liveBytes += d.size
            } catch (_: Exception) {
            } finally {
                synchronized(lock) { pending.remove(key) }
            }
        }
    }

    // MARK: size + clearing (Home → Extras)

    fun totalBytes(): Long {
        var total = 0L
        Paths.cache.walkTopDown().forEach { f -> if (f.isFile) total += f.length() }
        return total
    }

    fun sizeText(): String {
        val b = totalBytes().toDouble()
        if (b >= 1_073_741_824) return String.format(java.util.Locale.US, "%.2f GB", b / 1_073_741_824)
        return String.format(java.util.Locale.US, "%.1f MB", b / 1_048_576)
    }

    /** Deletes every cached frame and thumbnail. Projects and media are untouched. */
    fun clearAll() {
        PreRender.clearAll()
        synchronized(lock) {
            pending.clear(); purged.clear()
            cachedIdx.clear(); runs = ArrayList(); runsDirty = true; liveBytes = 0
        }
        Paths.cache.listFiles()?.forEach { it.deleteRecursively() }
        Paths.appContext.cacheDir.listFiles()?.forEach { if (it.name.startsWith("fxthumbs")) it.deleteRecursively() }
        EffectThumbs.cache.removeAll()
        version = version + 1
    }
}

/** UserDefaults-backed preferences (shared). */
object Prefs {
    private val sp by lazy { Paths.appContext.getSharedPreferences("saiki", android.content.Context.MODE_PRIVATE) }
    fun getBool(key: String, def: Boolean): Boolean = sp.getBoolean(key, def)
    fun setBool(key: String, v: Boolean) { sp.edit().putBoolean(key, v).apply() }
    fun getInt(key: String, def: Int): Int = sp.getInt(key, def)
    fun setInt(key: String, v: Int) { sp.edit().putInt(key, v).apply() }
    fun getString(key: String, def: String?): String? = sp.getString(key, def)
    fun setString(key: String, v: String?) { sp.edit().putString(key, v).apply() }
    fun removeObject(key: String) { sp.edit().remove(key).apply() }
}
