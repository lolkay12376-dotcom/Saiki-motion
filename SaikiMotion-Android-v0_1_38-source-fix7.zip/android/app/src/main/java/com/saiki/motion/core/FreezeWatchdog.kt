package com.saiki.motion.core

import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

// Port of Sources/Support/FreezeWatchdog.swift — round 15/19 design, corrected.
//  * Liveness = the heartbeat VALUE CHANGES (a wedged thread can still answer pokes while its
//    run loop never turns).
//  * A freeze is declared ONLY when the heartbeat stopped AND unsaved work is in flight.
//  * When a real freeze is confirmed: write the report, then abort.
object FreezeWatchdog {
    private const val checkInterval = 2.0
    private const val stuckChecksNeeded = 10       // ~20 s truly stuck (heavy renders + first shader compile can block for seconds)
    private val lock = Object()
    private var thread: Thread? = null
    private val main = Handler(Looper.getMainLooper())

    // Written only on the main thread; read by the watchdog thread.
    @Volatile private var heartbeat = 0L
    @Volatile private var dirty = false                // unsaved work in flight

    // Guarded operations: main thread may legitimately go quiet.
    private var guarded = 0
    private var guardLabel = ""
    @Volatile private var inBackground = false
    private var pong = 0L

    /** Start the watchdog. Call once after CrashLog.install(). */
    fun start() {
        synchronized(lock) {
            if (thread != null) return            // idempotent
            val t = Thread(::run, "freeze-watchdog")
            thread = t
            t.start()
        }
    }

    // MARK: main-thread API

    /** Call from the render/frame path and from every edit. Cheap. */
    fun beat() { heartbeat += 1 }

    /** Unsaved work exists (set by the editor's markDirty()). */
    fun setDirty(on: Boolean) { dirty = on }

    /** Wrap a long main-thread-quiet operation: VDB import, export, share. */
    fun <T> runGuarded(label: String, body: () -> T): T {
        synchronized(lock) { guarded += 1; if (guardLabel.isEmpty()) guardLabel = label }
        try {
            return body()
        } finally {
            synchronized(lock) { guarded -= 1; if (guarded <= 0) { guarded = 0; guardLabel = "" } }
        }
    }

    fun onAppBackground() { inBackground = true }
    fun onAppForeground() { inBackground = false }

    // MARK: watchdog thread

    private fun run() {
        var lastPong = 0L
        var stuck = 0
        while (true) {
            main.post { synchronized(lock) { pong += 1 } }
            try { Thread.sleep((checkInterval * 1000).toLong()) } catch (_: InterruptedException) { return }

            val (p, busy, lbl) = synchronized(lock) { Triple(pong, guarded > 0, guardLabel) }
            val bg = inBackground

            if (p == lastPong && !bg && !busy) EffectCrashLog.noteStallIfAny(4.0)
            if (p != lastPong || bg) {
                stuck = 0
            } else if (dirty) {
                stuck += 1
                // long guarded work (VDB import, share) gets a much longer leash
                val needed = if (busy) 30 else stuckChecksNeeded
                if (stuck >= needed) {
                    val detail = "main thread unresponsive for ${stuck * checkInterval.toInt()}s with unsaved work" +
                                 (if (busy) " (in $lbl)" else "")
                    EffectCrashLog.noteFreeze(detail)
                    CrashLog.note("freeze")
                    // write the report then abort (a wedged app freezes the whole phone UI: a clean kill is better)
                    Runtime.getRuntime().exit(1)
                }
            } else {
                stuck = 0
            }
            lastPong = p
        }
    }
}
