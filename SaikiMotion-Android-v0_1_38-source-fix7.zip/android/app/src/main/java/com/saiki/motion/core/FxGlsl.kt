package com.saiki.motion.core

import java.util.regex.Pattern

/**
 * Effect shader source. `Gl.effectShaderSource` is a line-for-line port of Sources/Render/Gl.swift:367 (the GLSL ES prelude, kept in ONE place);
 * `FxGlsl.vulkanSource` is the Android twin of MetalEffects.translate: it keeps that source and only adapts the container
 * (uniforms -> std140 UBO members, texture2D -> fetch with the same V flip as MetalEffects.fetch, main -> outColor).
 */
object Gl {
    val reservedUniformNames: Set<String> = setOf(
        "mix", "step", "length", "min", "max", "abs", "sin", "cos", "tan", "exp", "log", "pow", "sqrt",
        "floor", "fract", "mod", "sign", "clamp", "dot", "cross", "normalize", "distance", "reflect",
        "refract", "smoothstep", "radians", "degrees", "ceil", "asin", "acos", "atan", "exp2", "log2",
        "inversesqrt", "round", "trunc", "luma", "hash11", "hash21", "vnoise", "fbm", "rot", "hsv2rgb",
        "rgb2hsv", "unpremul", "src", "srcW", "in0", "in1", "effect", "main", "texture2D", "float", "int",
        "vec2", "vec3", "vec4", "mat2", "mat3", "mat4", "if", "for", "while", "return", "uv", "gl_FragColor")
    fun uniformName(key: String): String = if (reservedUniformNames.contains(key)) "u_$key" else key

    private const val HEADER = """precision highp float;
varying vec2 vUv;
uniform sampler2D uTex;
uniform sampler2D uIn0;
uniform sampler2D uIn1;
uniform vec2 uRes;
uniform float uTime;
uniform float uHas0;
uniform float uHas1;
uniform vec2 uLC;
uniform vec2 uLX;
uniform vec2 uLY;

"""
    private const val PRELUDE = """float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }
float hash11(float p) { p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash21(vec2 p) { vec3 q = fract(vec3(p.xyx) * 0.1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
float vnoise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);   // quintic: no visible grid creases
    return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), u.x),
               mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), u.x), u.y);
}
float fbm(vec2 p) {
    float v = 0.0; float a = 0.5;
    for (int i = 0; i < 4; i++) { v += a * vnoise(p); p = p * 2.03; a *= 0.5; }
    return v;
}
vec2 rot(vec2 p, float a) { float c = cos(a); float s = sin(a); return vec2(c * p.x - s * p.y, s * p.x + c * p.y); }
vec3 hsv2rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}
vec3 rgb2hsv(vec3 c) {
    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
    float d = q.x - min(q.w, q.y);
    float e = 1.0e-10;
    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec4 unpremul(vec4 c) { if (c.a <= 0.0) { return vec4(0.0); } return vec4(c.rgb / c.a, c.a); }
vec4 src(vec2 uv) { return texture2D(uTex, clamp(uv, 0.0, 1.0)); }
vec4 srcW(vec2 uv, float pad) { return texture2D(uTex, clamp(uv, pad, 1.0 - pad)); }
vec4 in0(vec2 uv) { return texture2D(uIn0, clamp(uv, 0.0, 1.0)) * uHas0; }
vec4 in1(vec2 uv) { return texture2D(uIn1, clamp(uv, 0.0, 1.0)) * uHas1; }

vec4 effect(vec2 uv) {
"""

    /** Returns the full GLSL ES source and the 1-based line where the user's code begins. */
    fun effectShaderSource(d: EffectDef): Pair<String, Int> {
        if (d.passes.isNotEmpty()) return Pair("precision highp float;\nvarying vec2 vUv;\nuniform sampler2D uTex;\nvoid main() { gl_FragColor = texture2D(uTex, vUv); }\n", 0)
        val sb = StringBuilder(HEADER)
        for (p in d.props) sb.append("uniform float ${uniformName(p.key)};\n")
        for (c in d.colors) sb.append("uniform vec4 ${uniformName(c.key)};\n")
        sb.append(PRELUDE)
        val offset = sb.toString().split("\n").size
        var body = d.glsl
        for (k in d.props.map { it.key } + d.colors.map { it.key }) {
            if (reservedUniformNames.contains(k) && k != "uv") {
                // bare uses of the name (not calls like mix(...)) refer to the uniform
                val re = Pattern.compile("(?<![A-Za-z0-9_.])" + Pattern.quote(k) + "(?![A-Za-z0-9_])(?!\\s*\\()")
                body = re.matcher(body).replaceAll("u_" + k)
            }
        }
        sb.append(body)
        if (!body.endsWith("\n")) sb.append("\n")
        if (d.confinesToAlpha) {
            // premultiplied textures: colour with alpha 0 still ADDS light when composited, so colour / stylize / generate / keying effects must never write outside the layer's opaque pixels
            sb.append("}\n\nvoid main() {\n    vec4 o = effect(vUv);\n    float sa = texture2D(uTex, vUv).a;\n    o.a = min(o.a, sa);\n    o.rgb = clamp(o.rgb, 0.0, 1.0);\n    o.rgb = min(o.rgb, vec3(o.a));\n    gl_FragColor = o;\n}\n")
        } else sb.append("}\n\nvoid main() { gl_FragColor = effect(vUv); }\n")
        return Pair(sb.toString(), offset)
    }
}

object FxGlsl {
    /** Starts the background compile for `d` (idempotent). True when the GLSL was produced. */
    fun prepare(d: EffectDef): Boolean {
        val src = vulkanSource(d)
        if (src.isEmpty()) return false
        com.saiki.motion.render.NativeRenderer.fxPrepare(key(d), src, d.name)
        return true
    }

    /** == MetalEffects.apply: one pass src -> out; false = not ready (passthrough, never a blank frame). */
    fun apply(step: FxStepData, src: MetalTarget, out: MetalTarget, time: Float,
              rect: Triple<FloatArray, FloatArray, FloatArray>? = null): Boolean {
        val d = step.def
        // Quick test first; never run an untested/broken shader live (SceneRenderer.swift applyEffects).
        // Export must never skip an effect just because its quick test has not finished yet.
        if (EffectCrashLog.isBroken(d.id)) return false
        if (d.passes.isEmpty() && d.kind != 1) {
            val ok = if (SceneRenderer.isExporting) EffectGuard.clearedWaiting(d) else EffectGuard.cleared(d)
            if (!ok) return false
        }
        prepare(step.def)
        val st = com.saiki.motion.render.NativeRenderer.fxStatus(key(step.def))
        if (st != 1) return false
        return com.saiki.motion.render.SceneRendererN.fxPass(key(step.def), src.handle, out.handle, time)
    }

    /** Names that are legal GLSL ES 1.00 but keywords/reserved in GLSL 450, plus our own container names (renamed with an `m_` prefix everywhere). */
    private val reserved450: Set<String> = setOf(
        "sample", "patch", "buffer", "shared", "coherent", "restrict", "readonly", "writeonly", "subroutine", "precise",
        "centroid", "noperspective", "smooth", "flat", "layout", "fetch", "uTex", "uIn0", "uIn1", "uRes", "uTime", "uHas0", "uHas1",
        "uLC", "uLX", "uLY", "uPad", "outColor")

    /** Layout of the props UBO (binding 4): props as consecutive floats, then each colour as 4 floats starting on a 16-byte boundary. */
    fun propBuffer(props: FloatArray, colors: List<FloatArray>): FloatArray {
        val n = (props.size + 3) / 4 * 4
        val out = FloatArray(maxOf(n + colors.size * 4, 4))
        System.arraycopy(props, 0, out, 0, props.size)
        for ((i, c) in colors.withIndex()) System.arraycopy(c, 0, out, n + i * 4, 4)
        return out
    }

    /** Twin of MetalEffects.translate: fragment-only GLSL 450 for the Vulkan effect pass. Bindings: tex b0..b2, FxC UBO b3 (== FxCommon), props UBO b4. */
    fun vulkanSource(d: EffectDef): String {
        val glsl = Gl.effectShaderSource(d).first
        var tail = glsl
        tail.indexOf("float luma(").let { if (it >= 0) tail = tail.substring(it) }       // drop header uniforms
        tail.lastIndexOf("void main()").let { if (it >= 0) tail = tail.substring(0, it) }
        fun member(key: String): String { val n = Gl.uniformName(key); return if (reserved450.contains(n)) "m_$n" else n }
        val toRename = (d.props.map { Gl.uniformName(it.key) } + d.colors.map { Gl.uniformName(it.key) }).filter { reserved450.contains(it) } + reserved450.filter { it != "fetch" && it != "outColor" && !it.startsWith("u") }
        for (n in toRename.toSet())
            tail = Pattern.compile("(?<![A-Za-z0-9_.])" + Pattern.quote(n) + "(?![A-Za-z0-9_])").matcher(tail).replaceAll("m_$n")
        tail = tail.replace("texture2D(", "fetch(")
        val sb = StringBuilder("#version 450\n")
        sb.append("layout(location = 0) in vec2 vUv;\nlayout(location = 0) out vec4 outColor;\n")
        sb.append("layout(set = 0, binding = 0) uniform sampler2D uTex;\nlayout(set = 0, binding = 1) uniform sampler2D uIn0;\nlayout(set = 0, binding = 2) uniform sampler2D uIn1;\n")
        sb.append("layout(std140, set = 0, binding = 3) uniform FxC { vec2 uRes; vec2 uLC; vec2 uLX; vec2 uLY; float uTime; float uHas0; float uHas1; float uPad; };\n")
        if (d.props.isNotEmpty() || d.colors.isNotEmpty()) {
            sb.append("layout(std140, set = 0, binding = 4) uniform FxP {\n")
            for (p in d.props) sb.append("    float ${member(p.key)};\n")
            for (c in d.colors) sb.append("    vec4 ${member(c.key)};\n")
            sb.append("};\n")
        }
        sb.append("vec4 fetch(sampler2D t, vec2 uv) { return texture(t, vec2(uv.x, 1.0 - uv.y)); }   // == MetalEffects FxCtx.fetch\n")
        sb.append(tail)
        sb.append("void main() {\n    vec4 o = effect(vUv);\n")
        if (d.confinesToAlpha) sb.append("    float sa = fetch(uTex, vUv).a;\n    o.a = min(o.a, sa);\n    o.rgb = clamp(o.rgb, 0.0, 1.0);\n    o.rgb = min(o.rgb, vec3(o.a));\n")
        sb.append("    outColor = o;\n}\n")
        return sb.toString()
    }

    /** MetalEffects.key: effect id + hash of everything that changes the compiled shader. */
    fun key(d: EffectDef): String {
        var h = d.glsl.hashCode()
        h = h * 31 + d.props.joinToString(",") { it.key }.hashCode()
        h = h * 31 + d.colors.joinToString(",") { it.key }.hashCode()
        h = h * 31 + (if (d.confinesToAlpha) 1 else 0)
        return d.id + "#" + Integer.toHexString(h)
    }
}

