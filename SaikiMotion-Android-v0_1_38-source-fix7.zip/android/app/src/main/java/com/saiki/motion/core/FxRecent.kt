package com.saiki.motion.core

import org.json.JSONArray

// Port of Sources/App/Editor/EditorEffects.swift:940-949 — recently used effects
// (most recent first), kept across launches. UserDefaults.standard.stringArray ->
// Prefs StringSet stored as a JSON array under the same key "fx.recent".

object FxRecent {
    private const val key = "fx.recent"

    val ids: List<String>
        get() {
            val s = Prefs.getString(key, null) ?: return emptyList()
            val a = try { JSONArray(s) } catch (_: Exception) { return emptyList() }
            return (0 until a.length()).mapNotNull { i -> a.optS(i) }.filter { it.isNotEmpty() }
        }

    fun push(id: String) {
        val a = ArrayList<String>()
        a.add(id)
        for (x in ids) if (x != id) a.add(x)
        val keep = a.take(12)
        val j = JSONArray()
        for (x in keep) j.put(x)
        Prefs.setString(key, j.toString())
    }
}
