package com.saiki.motion.core

/** MetalEffects.Step (MetalEffects.swift:23). The native twin is FxStep in cpp/vk_core.h; in0/in1 textures are bound renderer-side from inRef0/inRef1. */
class FxStepData(val def: EffectDef, val props: FloatArray, val colors: List<FloatArray>) {
    var inRef0: Int? = null     // layer ids picked for the effect's layer inputs (resolved by the scene renderer)
    var inRef1: Int? = null
    var in0: Long = 0L          // resolved input textures (native Tex*)
    var in1: Long = 0L
    /** FxStep.colors layout: 4 floats per colour, def order. */
    fun colorsFlat(): FloatArray { val o = FloatArray(colors.size * 4); for ((i, c) in colors.withIndex()) System.arraycopy(c, 0, o, i * 4, 4); return o }
    val key: String get() = FxGlsl.key(def)
}

/** Port of MetalSceneRenderer.swift:1039-1090 (paramValue / colorComp / effectSteps): the data half of the effect chain. */
object FxSteps {
    private fun paramValue(l: Layer, key: String, def: Float, time: Float): Float {
        val tr = l.props[key]
        if (tr != null) return tr.evalExpr(l.editTime(key, time), time, if (tr.exprActive()) Editor.scene.markersByName() else emptyMap())
        return def
    }

    private fun colorComp(l: Layer, key: String, def: Float, time: Float): Float {
        val tr = l.props[key]
        if (tr != null) return tr.eval(l.editTime(key, time))
        return def
    }

    /** `twixFrameB` renders frame B of the interpolated pair as a native Tex* (the renderer's twixSampler); null outside the scene renderer. */
    fun effectSteps(l: Layer, time: Float, twixFrameB: ((Layer, String, TwixSource) -> Long)? = null): List<FxStepData> {
        val out = ArrayList<FxStepData>()
        for (item in l.fxChain()) {
            val owner = item.owner; val entry = item.entry
            if (owner.fxOff.contains(entry)) continue
            val d = Registry.get(entry) ?: continue
            val single = d.kind == 1
            val props = FloatArray(d.props.size)
            for ((i, pd) in d.props.withIndex()) {
                val key = if (single) pd.key else entry + "__" + pd.key
                props[i] = paramValue(owner, key, pd.def, time)
            }
            val cols = ArrayList<FloatArray>()
            for (cp in d.colors) {
                val base = if (single) cp.key else entry + "__" + cp.key
                val c = cp.def
                val r = colorComp(owner, base + "_r", ((c ushr 16) and 0xFF) / 255f, time)
                val g = colorComp(owner, base + "_g", ((c ushr 8) and 0xFF) / 255f, time)
                val b = colorComp(owner, base + "_b", (c and 0xFF) / 255f, time)
                val a = colorComp(owner, base + "_a", ((c ushr 24) and 0xFF) / 255f, time)
                cols.add(floatArrayOf(r, g, b, a))
            }
            val step = FxStepData(d, props, cols)
            // MetalSceneRenderer.swift:1091 twixtor: in1 = frame B of the interpolated pair, twFrac = the in-between position
            if (d.id == "twixtor" && owner === l && l.type == LayerType.VIDEO && twixFrameB != null) {
                val path = l.imagePath
                val tw = l.twixSource(time)
                if (path != null && tw != null) {
                    step.in1 = twixFrameB.invoke(l, path, tw)
                    val fi = d.props.indexOfFirst { it.key == "twFrac" }
                    if (fi in step.props.indices) step.props[fi] = tw.frac
                }
            }
            // MetalSceneRenderer.swift:1095 mblooks: the .cube LUT strip goes to in1 and lkLutSize gets the cube size (LookLut.shared)
            if (d.id == "mblooks") {
                val lutName = l.pbrMaps["lut:" + entry]
                if (lutName != null) {
                    val lut = LookLut.shared.texture(lutName)
                    if (lut != null) {
                        step.in1 = lut.first
                        val li = d.props.indexOfFirst { it.key == "lkLutSize" }
                        if (li in step.props.indices) step.props[li] = lut.second.toFloat()
                    }
                }
            }
            for ((slot, nm) in d.inputs.withIndex()) {
                if (slot >= 2) break
                val rid = l.inputs["$entry:$nm"]
                if (slot == 0) step.inRef0 = rid else step.inRef1 = rid
            }
            out.add(step)
        }
        return out
    }
}
