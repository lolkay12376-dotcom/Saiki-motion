package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.zip.ZipFile
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Port of Sources/Render/GlbModel.swift: .glb / .gltf / .obj loader (CPU only, like the Metal path with GlbModel.cpuOnly = true).
 * Vertices are 12 floats: pos(3) normal(3) uv(2) colour(4). Texture ids are synthetic keys into cpuImages.
 * PARITY-NOTE(GlbModel.swift:1216-1408): the legacy GL draw()/vertexSource/fragmentSource path is not ported — Android renders
 * models through Vulkan (NativeModel.modelPass + the shared/shaders/glsl/model.vert|model.frag|model_rt.frag twins of those sources).
 */
class GlbModel {
    class Prim {
        var count = 0
        var mode = GL_TRIANGLES
        var color = floatArrayOf(1f, 1f, 1f, 1f)
        var emissive = floatArrayOf(0f, 0f, 0f)
        var metal = 0f
        var rough = 0.8f
        var texBase = 0
        var texMR = 0
        var texEm = 0
        var texOcc = 0
        var texNormal = 0       // tangent-space normal map
        var blend = false
        var cutoff = -1f
        var unlit = 0f
        var collider = false    // PlyImport collider mesh: depth-only occluder unless shown
        var slot = -1           // index of the source mesh (animation sidecar order)
        var verts = FloatArray(0)
        var cpuIdx = IntArray(0)
        var jnt = ShortArray(0)   // 4 bone indices per vertex
        var wgt = FloatArray(0)   // 4 weights per vertex
        var indexIs16 = true
    }

    var prims = mutableListOf<Prim>()
    var skeleton: Skeleton3D? = null

    // MARK: animation (Alembic sidecar "<model>.glb.anim")
    private class AbcAnim private constructor(val data: ByteBuffer, val frames: Int, val fps: Float, val counts: IntArray, val base: Int, val frameBytes: Int, val slotOffset: IntArray) {
        companion object {
            fun open(path: String): AbcAnim? {
                val d = try { File(path).readBytes() } catch (_: Exception) { return null }
                if (d.size < 16) return null
                val b = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
                fun u32(o: Int): Long = b.getInt(o).toLong() and 0xFFFFFFFFL
                if (u32(0) != 0x41424153L) return null
                val nf = u32(4); val nm = u32(12)
                if (!(nf > 1 && nm > 0 && nm < 4096 && d.size >= 16 + nm * 4)) return null
                val c = IntArray(nm.toInt()); val so = IntArray(nm.toInt()); var fb = 0L
                for (i in 0 until nm.toInt()) { val n = u32(16 + i * 4); c[i] = n.toInt(); so[i] = fb.toInt(); fb += n * 24 }
                val bs = 16 + nm.toInt() * 4
                if (!(fb > 0 && bs + fb * nf <= d.size)) return null
                val f = b.getFloat(8)
                return AbcAnim(b, nf.toInt(), if (f.isFinite() && f > 0.5f && f < 1000f) f else 24f, c, bs, fb.toInt(), so)
            }
        }
    }

    private var anim: AbcAnim? = null
    private var poseOn = false
    private val poseBase = HashMap<Int, FloatArray>()

    /** Poses the model from the layer's bone tracks ("bn<i>rx..."), runs physics and re-skins the CPU vertices. */
    fun applyPose(l: Layer, t: Float) {
        val sk = skeleton ?: return
        if (anim != null) return
        val hasTracks = l.props.keys.any { Skeleton3D.boneKey(it) != null }
        val physOn = (sk.phys?.active ?: false) && l.p("bnphoff", t) < 0.5f
        sk.physicsOn = physOn
        if (!(hasTracks || physOn)) {
            if (poseOn) { restorePoseBase(); poseOn = false; animVersion += 1 }
            sk.loadPose(l, t)
            return
        }
        val changed = sk.loadPose(l, t)
        val moved = sk.stepPhysics(t, 0f)
        if (!(changed || moved || (!poseOn && sk.poseSig != ""))) return
        val mats = sk.skinMatrices()
        for (i in prims.indices) {
            val p = prims[i]
            if (p.jnt.isNotEmpty() && p.verts.size == p.jnt.size * 3) {
                if (poseBase[i] == null) poseBase[i] = p.verts
                val base = poseBase[i] ?: continue
                p.verts = Skeleton3D.skinVerts(base, p.jnt, p.wgt, mats)
            }
        }
        poseOn = true
        animVersion += 1
    }

    private fun restorePoseBase() { for ((i, b) in poseBase) if (i < prims.size) prims[i].verts = b }

    private var animFrame = -1
    /** Bumped every time the CPU vertices were re-posed (the renderer re-uploads when it changes). */
    var animVersion = 0
    val isAnimated: Boolean get() = anim != null || poseOn

    /** Poses the model for `t` seconds from the layer start (loops). Cheap when the frame is unchanged. */
    fun setAnimTime(t: Float) {
        val a = anim ?: return
        val f = floor(max(0f, t) * a.fps).toInt() % a.frames
        if (f == animFrame) return
        animFrame = f
        animVersion += 1
        for (p in prims) {
            if (!(p.slot >= 0 && p.slot < a.counts.size)) continue
            val n = a.counts[p.slot]
            if (p.verts.size != n * 12) continue
            val off = a.base + f * a.frameBytes + a.slotOffset[p.slot]
            for (k in 0 until n) for (c in 0 until 3) {
                p.verts[k * 12 + c] = a.data.getFloat(off + (k * 3 + c) * 4)
                p.verts[k * 12 + 3 + c] = a.data.getFloat(off + n * 12 + (k * 3 + c) * 4)
            }
        }
    }

    /** normalization: [scale, offX, offY, offZ]. The offsets are the RAW (unscaled) centre offset. */
    var normalize = floatArrayOf(1f, 0f, 0f, 0f)
    var baseY = 0f          // lowest point after normalising (<= 0)

    class CpuImage(val img: Bitmap, val clamp: Boolean)

    private class Bounds {
        val mn = floatArrayOf(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE)
        val mx = floatArrayOf(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
        val valid: Boolean get() = mn[0] <= mx[0]
        fun add(x: Float, y: Float, z: Float) {
            if (x < mn[0]) mn[0] = x; if (x > mx[0]) mx[0] = x
            if (y < mn[1]) mn[1] = y; if (y > mx[1]) mx[1] = y
            if (z < mn[2]) mn[2] = z; if (z > mx[2]) mx[2] = z
        }
    }

    private fun finishNormalize(b: Bounds) {
        val cx = (b.mn[0] + b.mx[0]) / 2; val cy = (b.mn[1] + b.mx[1]) / 2; val cz = (b.mn[2] + b.mx[2]) / 2
        val span = max(b.mx[0] - b.mn[0], max(b.mx[1] - b.mn[1], b.mx[2] - b.mn[2]))
        val s = if (span > 0.0001f) 1.4f / span else 1f
        normalize = floatArrayOf(s, -cx, -cy, -cz)
        baseY = (b.mn[1] - cy) * s
    }

    /** Validates the sidecar against the loaded prims and widens the framing to cover every frame. */
    private fun attach(a: AbcAnim): Boolean {
        for (pr in prims) if (!(pr.slot >= 0 && pr.slot < a.counts.size && pr.verts.size == a.counts[pr.slot] * 12)) return false
        val b = Bounds()
        val step = max(1, a.frames / 48)
        var f = 0
        while (f < a.frames) {
            for (pr in prims) {
                val n = a.counts[pr.slot]
                val off = a.base + f * a.frameBytes + a.slotOffset[pr.slot]
                for (k in 0 until n) b.add(a.data.getFloat(off + k * 12), a.data.getFloat(off + k * 12 + 4), a.data.getFloat(off + k * 12 + 8))
            }
            f += step
        }
        if (b.valid) finishNormalize(b)
        anim = a
        return true
    }

    /** .abc carries no pixels: pick up the images that came in the same zip ("<stem>_tex_*") and bind them by name. */
    private fun applyAbcTextures(dir: String, stem: String) {
        val prefix = stem + "_tex_"
        val all = File(dir).list() ?: return
        val imgExt = setOf("png", "jpg", "jpeg", "webp", "heic", "tga", "bmp", "tif", "tiff")
        val imgs = all.filter { it.startsWith(prefix) || (imgExt.contains(it.substringAfterLast('.', "").lowercase(Locale.ROOT)) && it.substringBeforeLast('.').lowercase(Locale.ROOT).startsWith(stem.lowercase(Locale.ROOT))) }.sorted()
        if (imgs.isEmpty()) return
        fun has(n: String, keys: List<String>) = keys.any { n.lowercase(Locale.ROOT).contains(it) }
        val other = listOf("normal", "nrm", "bump", "height", "disp", "_n.")
        val color = ArrayList<String>(); var mr: String? = null; var em: String? = null; var occ: String? = null
        for (n in imgs) {
            if (has(n, other)) continue
            if (has(n, listOf("rough", "metal", "orm", "_mr"))) mr = mr ?: n
            else if (has(n, listOf("emis", "glow"))) em = em ?: n
            else if (has(n, listOf("occ", "_ao"))) occ = occ ?: n
            else color.add(n)
        }
        fun load(n: String): Int = uploadFile("$dir/$n")
        val cache = HashMap<String, Int>()
        for (p in prims) {
            if (p.texBase != 0) continue
            val n: String? = if (color.size == prims.size) color[min(max(p.slot, 0), color.size - 1)] else color.firstOrNull()
            if (n != null) {
                if (cache[n] == null) cache[n] = load(n)
                val t = cache[n]
                if (t != null && t != 0) { p.texBase = t; p.color = floatArrayOf(1f, 1f, 1f, 1f); p.metal = 0f; p.rough = 0.8f }
            }
            if (n == null) continue
            if (mr != null && p.texMR == 0) { if (cache[mr] == null) cache[mr] = load(mr); p.texMR = cache[mr] ?: 0; p.metal = 1f; p.rough = 1f }
            if (em != null && p.texEm == 0) { if (cache[em] == null) cache[em] = load(em); p.texEm = cache[em] ?: 0; p.emissive = floatArrayOf(1f, 1f, 1f) }
            if (occ != null && p.texOcc == 0) { if (cache[occ] == null) cache[occ] = load(occ); p.texOcc = cache[occ] ?: 0 }
        }
    }

    // MARK: - glTF document

    private class Doc(val json: JSONObject, bin: ByteArray?, val dir: String) {
        val buffers = ArrayList<ByteArray>()
        val accessors: JSONArray = json.optJSONArray("accessors") ?: JSONArray()
        val views: JSONArray = json.optJSONArray("bufferViews") ?: JSONArray()
        val texCache = HashMap<String, Int>()

        init {
            val bs = json.optJSONArray("buffers")
            if (bs != null) {
                for (i in 0 until bs.length()) {
                    val uri = bs.optJSONObject(i)?.optString("uri", "") ?: ""
                    if (uri.isEmpty()) buffers.add(if (i == 0) (bin ?: ByteArray(0)) else ByteArray(0))
                    else buffers.add(loadURI(uri, dir) ?: ByteArray(0))
                }
            } else buffers.add(bin ?: ByteArray(0))
        }

        fun comps(t: String): Int = when (t) { "SCALAR" -> 1; "VEC2" -> 2; "VEC3" -> 3; "VEC4" -> 4; "MAT2" -> 4; "MAT3" -> 9; "MAT4" -> 16; else -> 0 }
        fun csize(ct: Int): Int = when (ct) { 5120, 5121 -> 1; 5122, 5123 -> 2; else -> 4 }

        fun read(b: ByteBuffer, o: Int, ct: Int, norm: Boolean): Float = when (ct) {
            5120 -> { val v = b.get(o).toInt(); if (norm) max(v.toFloat() / 127, -1f) else v.toFloat() }
            5121 -> { val v = b.get(o).toInt() and 0xFF; if (norm) v.toFloat() / 255 else v.toFloat() }
            5122 -> { val v = b.getShort(o).toInt(); if (norm) max(v.toFloat() / 32767, -1f) else v.toFloat() }
            5123 -> { val v = b.getShort(o).toInt() and 0xFFFF; if (norm) v.toFloat() / 65535 else v.toFloat() }
            5125 -> (b.getInt(o).toLong() and 0xFFFFFFFFL).toFloat()
            else -> b.getFloat(o)
        }

        /** Float view of any accessor (normalized types are mapped to 0…1 / -1…1). Triple(data, n, comps). */
        fun floats(idx: Int): Triple<FloatArray, Int, Int>? {
            if (!(idx >= 0 && idx < accessors.length())) return null
            val a = accessors.optJSONObject(idx) ?: return null
            val n = a.optInt("count"); val c = comps(a.optString("type", ""))
            val ct = a.optInt("componentType", 5126); val norm = a.optBoolean("normalized")
            if (!(n > 0 && c > 0)) return null
            val out = FloatArray(n * c)
            val csz = csize(ct)
            val bv = a.optInt("bufferView", -1)
            if (bv >= 0 && bv < views.length()) {
                val v = views.optJSONObject(bv)
                if (v != null) {
                    val bi = v.optInt("buffer")
                    if (!(bi >= 0 && bi < buffers.size)) return null
                    val esz = csz * c
                    val stride = max(v.optInt("byteStride"), esz)
                    val off = v.optInt("byteOffset") + a.optInt("byteOffset")
                    val raw = buffers[bi]; val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until n) {
                        val eo = off + i * stride
                        if (eo < 0 || eo + esz > raw.size) break
                        for (k in 0 until c) out[i * c + k] = read(bb, eo + k * csz, ct, norm)
                    }
                }
            }
            return Triple(out, n, c)
        }

        fun ints(idx: Int): IntArray? {
            if (!(idx >= 0 && idx < accessors.length())) return null
            val a = accessors.optJSONObject(idx) ?: return null
            val n = a.optInt("count"); val ct = a.optInt("componentType", 5123)
            val v = views.optJSONObject(a.optInt("bufferView", -1)) ?: return null
            if (n <= 0) return null
            val bi = v.optInt("buffer")
            if (!(bi >= 0 && bi < buffers.size)) return null
            val csz = csize(ct)
            val stride = max(v.optInt("byteStride"), csz)
            val off = v.optInt("byteOffset") + a.optInt("byteOffset")
            val out = IntArray(n)
            val raw = buffers[bi]; val bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until n) {
                val eo = off + i * stride
                if (eo < 0 || eo + csz > raw.size) break
                out[i] = when (ct) { 5121 -> bb.get(eo).toInt() and 0xFF; 5123 -> bb.getShort(eo).toInt() and 0xFFFF; else -> bb.getInt(eo) }
            }
            return out
        }

        /** Texture id for a glTF textureInfo ({index}); 0 when absent / undecodable. */
        fun texture(info: JSONObject?): Int {
            if (info == null || !info.has("index")) return 0
            val ti = info.optInt("index", -1)
            val texs = json.optJSONArray("textures") ?: return 0
            if (!(ti >= 0 && ti < texs.length())) return 0
            val t = texs.optJSONObject(ti) ?: return 0
            val src = t.optInt("source", -1)
            val imgs = json.optJSONArray("images") ?: return 0
            if (!(src >= 0 && src < imgs.length())) return 0
            val im = imgs.optJSONObject(src) ?: return 0
            var clamp = false
            val sams = json.optJSONArray("samplers"); val si = t.optInt("sampler", -1)
            if (sams != null && si >= 0 && si < sams.length()) { val s = sams.optJSONObject(si); if (s != null && s.optInt("wrapS", 10497) == 33071) clamp = true }
            val key = "$src|$clamp"
            texCache[key]?.let { return it }
            var data: ByteArray? = null
            val uri = im.optString("uri", "")
            if (uri.isNotEmpty()) data = loadURI(uri, dir)
            else {
                val v = views.optJSONObject(im.optInt("bufferView", -1))
                if (v != null) {
                    val bi = v.optInt("buffer")
                    if (bi >= 0 && bi < buffers.size) {
                        val off = v.optInt("byteOffset"); val len = v.optInt("byteLength"); val b = buffers[bi]
                        if (off >= 0 && len > 0 && off + len <= b.size) data = b.copyOfRange(off, off + len)
                    }
                }
            }
            val img = data?.let { try { BitmapFactory.decodeByteArray(it, 0, it.size) } catch (_: Exception) { null } }
            if (img == null) { texCache[key] = 0; return 0 }
            val tex = uploadImage(img, clamp)
            texCache[key] = tex
            return tex
        }
    }

    companion object {
        const val GL_POINTS = 0
        const val GL_TRIANGLES = 4

        /** Why the last load failed (for toasts / logs). */
        @Volatile var lastError = ""
        val cpuImages = HashMap<Int, CpuImage>()
        private var cpuImageId = 0
        private fun uploadImage(img: Bitmap, clamp: Boolean): Int = synchronized(cpuImages) { cpuImageId += 1; cpuImages[cpuImageId] = CpuImage(img, clamp); cpuImageId }
        private fun uploadFile(path: String): Int {
            val img = try { BitmapFactory.decodeFile(path) } catch (_: Exception) { null } ?: return 0
            return uploadImage(img, false)
        }

        private fun loadURI(uri: String, dir: String): ByteArray? {
            if (uri.startsWith("data:")) {
                val comma = uri.indexOf(','); if (comma < 0) return null
                val payload = uri.substring(comma + 1)
                return if (uri.substring(0, comma).contains(";base64")) try { Base64.decode(payload, Base64.DEFAULT) } catch (_: Exception) { null }
                else Uri.decode(payload).toByteArray(Charsets.UTF_8)
            }
            val rel = Uri.decode(uri)
            return try { File(dir, rel).readBytes() } catch (_: Exception) { null }
        }

        // MARK: - public entry points

        fun load(path: String): GlbModel? {
            lastError = ""
            var p = path
            val low = p.lowercase(Locale.ROOT)
            if (low.endsWith(".abc")) p = transcodeAbc(p) ?: p
            if (low.endsWith(".pmx") || low.endsWith(".mmd")) {
                val g = MmdImport.convert(p)
                if (g == null) { lastError = MmdImport.lastError; return null }
                p = g
            }
            if (low.endsWith(".fbx")) {
                val g = FbxImport.convert(p)
                if (g == null) { lastError = FbxImport.lastError; return null }
                p = g
            }
            val data = try { File(p).readBytes() } catch (_: Exception) { null }
            if (data == null || data.size <= 4) { lastError = "Cannot read the model file"; return null }
            val dir = File(p).parent ?: ""
            val ext = p.substringAfterLast('.', "").lowercase(Locale.ROOT)
            val isGlb = data.size >= 4 && data[0] == 0x67.toByte() && data[1] == 0x6C.toByte() && data[2] == 0x54.toByte() && data[3] == 0x46.toByte()
            if (!isGlb && (ext == "obj" || looksLikeObj(data))) {
                val m = parseObj(data)
                if (m == null && lastError.isEmpty()) lastError = "OBJ has no faces"
                return m
            }
            val sc = splitContainer(data)
            if (sc == null) { if (lastError.isEmpty()) lastError = "Not a valid .glb / .gltf / .obj file"; return null }
            val (json, bin) = sc
            unsupportedExtension(json)?.let { lastError = it; return null }
            val animPath = "$p.anim"
            val fromAbc = ext == "glb" && File(animPath).exists()
            val m = parseGltf(json, bin, dir)
            if (m != null && m.skeleton == null && !(fromAbc && !isMmdGlb(json))) {
                val side = Skeleton3D.read("$p.skel")          // PMX / FBX bones written by the importers
                if (side != null) {
                    m.skeleton = side.first
                    for (pr in m.prims) { val sl = pr.slot; if (sl >= 0 && sl < side.second.size) { pr.jnt = side.second[sl]; pr.wgt = side.third[sl] } }
                }
            }
            if (m == null && lastError.isEmpty()) lastError = "No drawable geometry found"
            if (m != null && (fromAbc || isAbcGlb(json))) {
                m.applyAbcTextures(dir, File(p).name.substringBeforeLast('.'))
                if (fromAbc) AbcAnim.open(animPath)?.let { m.attach(it) }
            }
            return m
        }

        private fun isMmdGlb(json: JSONObject) = json.optJSONObject("asset")?.optString("generator", "") == "SaikiMotion MMD Import"
        private fun isAbcGlb(json: JSONObject) = json.optJSONObject("asset")?.optString("generator", "") == "SaikiMotion ABC Import"

        /** A model that arrives zipped (header "PK"): pulls the first model out of the archive next to it; null when not a zip / no model. */
        fun unwrapZip(path: String): String? {
            val f = File(path)
            if (!f.exists() || f.length() <= 64) return null
            val head = try { f.inputStream().use { s -> ByteArray(4).also { s.read(it) } } } catch (_: Exception) { return null }
            if (!(head[0] == 0x50.toByte() && head[1] == 0x4B.toByte() && head[2] == 3.toByte() && head[3] == 4.toByte())) return null
            MmdImport.unzipAll(path)?.let { return it }     // MMD archive: unpack with folders (textures / .vmd)
            val zf = try { ZipFile(f) } catch (_: Exception) { return null }
            zf.use {
                val stem = f.name.substringBeforeLast('.')
                val dirPath = f.parent ?: ""
                val imgExt = setOf("png", "jpg", "jpeg", "tif", "tiff", "bmp")
                val entries = zf.entries().toList()
                for (e in entries) {      // pass 0: textures bundled with the model -> "<stem>_tex_<n>" beside it
                    val name = e.name
                    if (imgExt.contains(name.substringAfterLast('.', "").lowercase(Locale.ROOT)) && !name.startsWith("__MACOSX")) {
                        try {
                            val raw = zf.getInputStream(e).use { it.readBytes() }
                            if (raw.isNotEmpty()) File(dirPath, stem + "_tex_" + name.substringAfterLast('/')).writeBytes(raw)
                        } catch (_: Exception) {}
                    }
                }
                val ok = setOf("glb", "gltf", "obj", "fbx", "abc", "vdb", "pmx", "mmd", "vrm", "ply", "spz", "zip")   // "zip": a zip inside a zip (unwrapped again below)
                for (e in entries) {
                    val name = e.name; val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (ok.contains(ext) && !name.startsWith("__MACOSX")) {
                        val out = try { zf.getInputStream(e).use { it.readBytes() } } catch (_: Exception) { return null }
                        if (out.isEmpty()) return null
                        var dst = File(dirPath, "$stem.$ext")
                        if (ext == "zip") dst = File(dirPath, "${stem}_inner.zip")
                        return try {
                            dst.writeBytes(out)
                            if (ext == "zip") {          // nested archive: unwrap it too
                                val inner = unwrapZip(dst.path)
                                dst.delete()
                                inner
                            } else dst.path
                        } catch (_: Exception) { null }
                    }
                }
            }
            return null
        }

        /** Cheap check used right after import. null = looks fine, otherwise a message for the user. */
        fun preflight(path: String): String? {
            lastError = ""
            val ext = path.substringAfterLast('.', "").lowercase(Locale.ROOT)
            if (ext == "vdb" || ext == "abc" || ext == "fbx" || ext == "pmx" || ext == "mmd" || ext == "ply" || ext == "spz") return null
            val data = try { File(path).readBytes() } catch (_: Exception) { null }
            if (data == null || data.size <= 4) return "Could not read the file"
            if (ext == "obj" || looksLikeObj(data)) return null
            val sc = splitContainer(data)
            if (sc == null) {
                val hd = data.take(4).joinToString("") { String.format("%02X", it) }
                return "Not a readable model (" + (if (lastError.isEmpty()) "unknown format" else lastError) + ", header " + hd + ", " + data.size + " bytes)"
            }
            return unsupportedExtension(sc.first)
        }

        /** Runs the native Ogawa decoder (saiki_abc_to_glb via JNI); returns the new .glb path. */
        fun transcodeAbc(path: String): String? {
            val glb = try { NativeAbc.abcToGlb(path) } catch (_: UnsatisfiedLinkError) { null } ?: return null
            return if (File(glb).exists()) glb else null
        }

        fun validate(path: String): String {
            if (path.lowercase(Locale.ROOT).endsWith(".abc")) { val glb = transcodeAbc(path); if (glb != null) return glb }
            if (path.lowercase(Locale.ROOT).let { it.endsWith(".pmx") || it.endsWith(".mmd") }) { val glb = MmdImport.convert(path); if (glb != null) return glb }
            if (path.lowercase(Locale.ROOT).endsWith(".fbx")) { val glb = FbxImport.convert(path); if (glb != null) return glb }
            return path
        }

        /** Camera position (world) recovered from a view-projection matrix; (0,0,3) if it is singular. */
        fun eye(fromVP: FloatArray): FloatArray {
            if (fromVP.size != 16) return floatArrayOf(0f, 0f, 3f)
            val inv = M4(fromVP.copyOf()).inverse()
            val v = inv.col(2)            // clip-space point (0,0,z,0) is the eye itself
            if (!(v.x.isFinite() && v.y.isFinite() && v.z.isFinite() && v.w.isFinite()) || kotlin.math.abs(v.w) < 1e-9f) return floatArrayOf(0f, 0f, 3f)
            return floatArrayOf(v.x / v.w, v.y / v.w, v.z / v.w)
        }

        // MARK: - container

        private fun u32(b: ByteArray, o: Int): Long = ((b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24))

        private fun looksLikeObj(data: ByteArray): Boolean {
            val n = min(data.size, 2048)
            if (n <= 2) return false
            val s = String(data, 0, n, Charsets.UTF_8)
            var seenV = false
            for (line in s.split('\n', '\r').filter { it.isNotEmpty() }.take(200)) {
                val t = line.trim(' ', '\t')
                if (t.startsWith("{")) return false
                if (t.startsWith("v ") || t.startsWith("v\t") || t.startsWith("f ")) seenV = true
            }
            return seenV
        }

        private fun parseJson(text: String): JSONObject? = try { JSONObject(text) } catch (e: Exception) { lastError = "glTF JSON error: " + (e.message ?: ""); null }

        /** Splits a .glb (chunks) or a .gltf (plain JSON) into (json, embedded BIN chunk). */
        private fun splitContainer(bytes: ByteArray): Pair<JSONObject, ByteArray?>? {
            if (bytes.size <= 12) return null
            if (bytes[0] == 0x67.toByte() && bytes[1] == 0x6C.toByte() && bytes[2] == 0x54.toByte() && bytes[3] == 0x46.toByte()) {
                var off = 12
                var jsonObj: JSONObject? = null; var bin: ByteArray? = null
                while (off + 8 <= bytes.size) {
                    val len = u32(bytes, off); val type = u32(bytes, off + 4)
                    val start = off + 8
                    var end = min(start.toLong() + len, bytes.size.toLong()).toInt()
                    if (type == 0x4E4F534AL && jsonObj == null) {
                        while (end > start && (bytes[end - 1].toInt() == 0 || bytes[end - 1].toInt() == 0x20)) end -= 1
                        jsonObj = parseJson(String(bytes, start, end - start, Charsets.UTF_8))
                    } else if (type == 0x004E4942L && bin == null) bin = bytes.copyOfRange(start, end)
                    off = start + (((len + 3) and 3L.inv()).toInt())
                }
                val j = jsonObj
                if (j == null) { if (lastError.isEmpty()) lastError = "GLB has no readable JSON chunk (${bytes.size} bytes)"; return null }
                return Pair(j, bin)
            }
            val t = String(bytes, Charsets.UTF_8).trim { it.isWhitespace() || it == '\uFEFF' }
            if (!t.startsWith("{")) return null
            val j = parseJson(t) ?: return null
            return Pair(j, null)
        }

        private fun unsupportedExtension(json: JSONObject): String? {
            val req = json.optJSONArray("extensionsRequired") ?: return null
            for (i in 0 until req.length()) {
                val e = req.optString(i, "")
                if (e == "KHR_draco_mesh_compression") return "This model uses Draco compression. Re-export it without Draco (e.g. glTF-Transform: gltf-transform copy in.glb out.glb, or Blender export with compression off)."
                if (e == "EXT_meshopt_compression" || e == "KHR_meshopt_compression") return "This model uses Meshopt compression. Re-export it without compression (glTF-Transform: gltf-transform copy in.glb out.glb)."
            }
            return null
        }

        // MARK: - math

        private fun mmul(a: FloatArray, b: FloatArray): FloatArray {
            val r = FloatArray(16)
            for (c in 0 until 4) for (row in 0 until 4) { var s = 0f; for (k in 0 until 4) s += a[k * 4 + row] * b[c * 4 + k]; r[c * 4 + row] = s }
            return r
        }

        private val ident = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)

        private fun nodeMatrix(n: JSONObject): FloatArray {
            val m = n.optJSONArray("matrix")
            if (m != null && m.length() == 16) return FloatArray(16) { m.optF(it, 0f) }
            var t = floatArrayOf(0f, 0f, 0f); var q = floatArrayOf(0f, 0f, 0f, 1f); var s = floatArrayOf(1f, 1f, 1f)
            n.optJSONArray("translation")?.let { if (it.length() >= 3) t = floatArrayOf(it.optF(0, 0f), it.optF(1, 0f), it.optF(2, 0f)) }
            n.optJSONArray("rotation")?.let { if (it.length() >= 4) q = floatArrayOf(it.optF(0, 0f), it.optF(1, 0f), it.optF(2, 0f), it.optF(3, 0f)) }
            n.optJSONArray("scale")?.let { if (it.length() >= 3) s = floatArrayOf(it.optF(0, 0f), it.optF(1, 0f), it.optF(2, 0f)) }
            val x = q[0]; val y = q[1]; val z = q[2]; val w = q[3]
            val xx = x * x; val yy = y * y; val zz = z * z
            val xy = x * y; val xz = x * z; val yz = y * z; val wx = w * x; val wy = w * y; val wz = w * z
            return floatArrayOf(
                (1 - 2 * (yy + zz)) * s[0], 2 * (xy + wz) * s[0], 2 * (xz - wy) * s[0], 0f,
                2 * (xy - wz) * s[1], (1 - 2 * (xx + zz)) * s[1], 2 * (yz + wx) * s[1], 0f,
                2 * (xz + wy) * s[2], 2 * (yz - wx) * s[2], (1 - 2 * (xx + yy)) * s[2], 0f,
                t[0], t[1], t[2], 1f)
        }

        /** Joint nodes of every glTF / VRM skin -> one skeleton. Returns it plus, per skin, joint index -> bone index, and node -> bone. */
        private fun gltfSkeleton(json: JSONObject): Triple<Skeleton3D, List<IntArray>, Map<Int, Int>>? {
            val skins = json.optJSONArray("skins"); val nodes = json.optJSONArray("nodes")
            if (skins == null || skins.length() == 0 || nodes == null || nodes.length() == 0) return null
            val nn = nodes.length()
            val parentOf = IntArray(nn) { -1 }
            for (i in 0 until nn) nodes.optJSONObject(i)?.optJSONArray("children")?.let { ch -> for (k in 0 until ch.length()) { val c = ch.optInt(k); if (c >= 0 && c < nn) parentOf[c] = i } }
            fun toM(a: FloatArray) = M4(a.copyOf())
            val worldMemo = HashMap<Int, M4>()
            fun nodeWorld(i: Int, depth: Int): M4 {
                worldMemo[i]?.let { return it }
                val local = toM(nodeMatrix(nodes.optJSONObject(i) ?: JSONObject()))
                val m = if (parentOf[i] >= 0 && depth < 128) nodeWorld(parentOf[i], depth + 1) * local else local
                worldMemo[i] = m
                return m
            }
            val jointNodes = HashSet<Int>(); val skinJ = ArrayList<IntArray>()
            for (si in 0 until skins.length()) {
                val js = ArrayList<Int>()
                skins.optJSONObject(si)?.optJSONArray("joints")?.let { ja -> for (k in 0 until ja.length()) { val n = ja.optInt(k); if (n >= 0 && n < nn) jointNodes.add(n); js.add(n) } }
                skinJ.add(js.toIntArray())
            }
            if (jointNodes.isEmpty() || jointNodes.size >= 5000) return null
            // VRM spring bone nodes / collider nodes that are not skin joints get a bone too (appended)
            val extra = Physics3D.springNodes(json, nn) { n ->
                nodes.optJSONObject(n)?.optJSONArray("children")?.let { a -> (0 until a.length()).map { a.optInt(it, -1) } } ?: emptyList()
            }.subtract(jointNodes)
            val order = jointNodes.sorted() + (if (extra.size < 4000) extra.sorted() else emptyList())
            val boneOf = HashMap<Int, Int>(); for ((b, n) in order.withIndex()) boneOf[n] = b
            val sk = Skeleton3D()
            val bindMs = order.map { nodeWorld(it, 0) }
            for ((b, n) in order.withIndex()) {
                var pb = -1; var a = parentOf[n]; var guardN = 0
                while (a >= 0 && guardN < 128) { val x = boneOf[a]; if (x != null) { pb = x; break }; a = parentOf[a]; guardN += 1 }
                val rest = if (pb >= 0) bindMs[pb].inverse() * bindMs[b] else bindMs[b]
                val name = nodes.optJSONObject(n)?.optString("name", "") ?: "bone$b"
                sk.bones.add(Bone3D(if (name.isEmpty()) "bone$b" else name, pb, bindMs[b], rest))
            }
            return Triple(sk, skinJ.map { js -> IntArray(js.size) { boneOf[js[it]] ?: 0 } }, boneOf)
        }

        // MARK: - glTF

        private fun parseGltf(json: JSONObject, bin: ByteArray?, dir: String): GlbModel? {
            val meshes = json.optJSONArray("meshes")
            if (meshes == null || meshes.length() == 0) { lastError = "The file contains no meshes"; return null }
            val doc = Doc(json, bin, dir)
            val m = GlbModel()
            val bounds = Bounds()

            val instMesh = ArrayList<Int>(); val instW = ArrayList<FloatArray>(); val instSkin = ArrayList<Int>()
            val gs = gltfSkeleton(json)
            if (gs != null) { m.skeleton = gs.first; gs.first.phys = Physics3D.parseVrm(json, gs.third, gs.first) }
            val nodes = json.optJSONArray("nodes")
            if (nodes != null && nodes.length() > 0) {
                val roots = ArrayList<Int>()
                val scenes = json.optJSONArray("scenes")
                if (scenes != null && scenes.length() > 0) {
                    val si = min(max(json.optInt("scene", 0), 0), scenes.length() - 1)
                    scenes.optJSONObject(si)?.optJSONArray("nodes")?.let { sn -> for (i in 0 until sn.length()) roots.add(sn.optInt(i)) }
                }
                if (roots.isEmpty()) {
                    val isChild = HashSet<Int>()
                    for (i in 0 until nodes.length()) nodes.optJSONObject(i)?.optJSONArray("children")?.let { ch -> for (k in 0 until ch.length()) isChild.add(ch.optInt(k)) }
                    for (i in 0 until nodes.length()) if (!isChild.contains(i)) roots.add(i)
                }
                fun walk(ni: Int, parent: FloatArray, depth: Int) {
                    if (!(depth < 64 && ni >= 0 && ni < nodes.length() && instMesh.size < 4000)) return
                    val node = nodes.optJSONObject(ni) ?: return
                    val w = mmul(parent, nodeMatrix(node))
                    if (node.has("mesh")) { instMesh.add(node.optInt("mesh")); instW.add(w); instSkin.add(node.optInt("skin", -1)) }
                    node.optJSONArray("children")?.let { ch -> for (k in 0 until ch.length()) walk(ch.optInt(k), w, depth + 1) }
                }
                for (r in roots) walk(r, ident, 0)
            }
            if (instMesh.isEmpty()) for (i in 0 until meshes.length()) { instMesh.add(i); instW.add(ident); instSkin.add(-1) }

            for (ii in instMesh.indices) {
                val mi = instMesh[ii]; val w = instW[ii]
                if (!(mi >= 0 && mi < meshes.length())) continue
                val mesh = meshes.optJSONObject(mi) ?: continue
                val primsJ = mesh.optJSONArray("primitives") ?: continue
                val a0 = floatArrayOf(w[0], w[1], w[2]); val a1 = floatArrayOf(w[4], w[5], w[6]); val a2 = floatArrayOf(w[8], w[9], w[10])
                fun cr(a: FloatArray, b: FloatArray) = floatArrayOf(a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
                val c0 = cr(a1, a2); val c1 = cr(a2, a0); val c2 = cr(a0, a1)
                val det = a0[0] * c0[0] + a0[1] * c0[1] + a0[2] * c0[2]
                val sgn = if (det < 0) -1f else 1f
                val identity = w.contentEquals(ident)

                for (pi in 0 until primsJ.length()) {
                    val pj = primsJ.optJSONObject(pi) ?: continue
                    val attrs = pj.optJSONObject("attributes") ?: continue
                    val mode = pj.optInt("mode", 4)
                    if (!(mode == 0 || mode == 4 || mode == 5 || mode == 6)) continue
                    val pos = doc.floats(attrs.optInt("POSITION", -1)) ?: continue
                    if (pos.third != 3) continue
                    val n = pos.second
                    val P = pos.first

                    var idx: IntArray = (if (pj.has("indices")) doc.ints(pj.optInt("indices", -1)) else null) ?: IntArray(n) { it }
                    if (mode != 0) idx = triangles(idx, mode)
                    if (idx.isEmpty()) continue
                    if (idx.any { it < 0 || it >= n }) idx = IntArray(idx.size) { val x = idx[it]; if (x < 0 || x >= n) n - 1 else x }

                    var N: FloatArray
                    if (mode != 0) {
                        val nn = doc.floats(attrs.optInt("NORMAL", -1))
                        N = if (nn != null && nn.third == 3 && nn.second == n) nn.first else genNormals(P, idx)
                    } else { N = FloatArray(n * 3); for (i in 0 until n) N[i * 3 + 1] = 1f }
                    var U = FloatArray(n * 2)
                    doc.floats(attrs.optInt("TEXCOORD_0", -1))?.let { if (it.third == 2 && it.second == n) U = it.first }
                    val C = FloatArray(n * 4) { 1f }
                    var hasVC = false
                    val cc = doc.floats(attrs.optInt("COLOR_0", -1))
                    if (cc != null && cc.second == n && (cc.third == 3 || cc.third == 4)) {
                        hasVC = true
                        for (i in 0 until n) {
                            C[i * 4] = cc.first[i * cc.third]; C[i * 4 + 1] = cc.first[i * cc.third + 1]; C[i * 4 + 2] = cc.first[i * cc.third + 2]
                            C[i * 4 + 3] = if (cc.third == 4) cc.first[i * 4 + 3] else 1f
                        }
                    }

                    if (!identity) {
                        for (i in 0 until n) {
                            val x = P[i * 3]; val y = P[i * 3 + 1]; val z = P[i * 3 + 2]
                            P[i * 3] = w[0] * x + w[4] * y + w[8] * z + w[12]
                            P[i * 3 + 1] = w[1] * x + w[5] * y + w[9] * z + w[13]
                            P[i * 3 + 2] = w[2] * x + w[6] * y + w[10] * z + w[14]
                            val nx = N[i * 3]; val ny = N[i * 3 + 1]; val nz = N[i * 3 + 2]
                            var rx = (c0[0] * nx + c1[0] * ny + c2[0] * nz) * sgn
                            var ry = (c0[1] * nx + c1[1] * ny + c2[1] * nz) * sgn
                            var rz = (c0[2] * nx + c1[2] * ny + c2[2] * nz) * sgn
                            val l = sqrt(rx * rx + ry * ry + rz * rz)
                            if (l > 1e-8f) { rx /= l; ry /= l; rz /= l } else { rx = 0f; ry = 1f; rz = 0f }
                            N[i * 3] = rx; N[i * 3 + 1] = ry; N[i * 3 + 2] = rz
                        }
                        if (det < 0 && mode != 0) {      // mirrored: keep front faces front
                            var t = 0
                            while (t + 2 < idx.size) { val x = idx[t + 1]; idx[t + 1] = idx[t + 2]; idx[t + 2] = x; t += 3 }
                        }
                    }

                    val prim = makePrim(P, N, U, C, idx, if (mode == 0) GL_POINTS else GL_TRIANGLES, bounds)
                    if (mode != 0 && gs != null && ii < instSkin.size && instSkin[ii] >= 0 && instSkin[ii] < gs.second.size) {
                        val jj = doc.floats(attrs.optInt("JOINTS_0", -1)); val ww = doc.floats(attrs.optInt("WEIGHTS_0", -1))
                        if (jj != null && jj.third == 4 && jj.second == n && ww != null && ww.third == 4 && ww.second == n) {
                            val map = gs.second[instSkin[ii]]
                            val J = ShortArray(n * 4); val W = ww.first.copyOf()
                            for (k in 0 until n * 4) { val ji = jj.first[k].toInt(); J[k] = if (ji >= 0 && ji < map.size) max(0, map[ji]).toShort() else 0 }
                            for (v in 0 until n) {
                                val sum = W[v * 4] + W[v * 4 + 1] + W[v * 4 + 2] + W[v * 4 + 3]
                                if (sum > 1e-6f) for (k in 0 until 4) W[v * 4 + k] /= sum
                            }
                            prim.jnt = J; prim.wgt = W
                        }
                    }

                    // material
                    val mat = pj.optInt("material", -1)
                    val mats = json.optJSONArray("materials")
                    val mj = if (mats != null && mat >= 0 && mat < mats.length()) mats.optJSONObject(mat) else null
                    if (mj != null) applyMaterial(mj, doc, prim)
                    else {
                        prim.color = floatArrayOf(1f, 1f, 1f, 1f)
                        prim.metal = 0f; prim.rough = 0.8f
                        if (hasVC) prim.unlit = 1f else prim.color = floatArrayOf(0.78f, 0.8f, 0.86f, 1f)
                    }
                    prim.collider = mesh.optString("name", "") == "SaikiCollider"      // PlyImport.colliderName
                    prim.slot = m.prims.size
                    m.prims.add(prim)
                }
            }

            if (m.prims.isEmpty() || !bounds.valid) { lastError = "The model has no triangle / point geometry"; return null }
            m.prims = m.prims.sortedBy { if (it.blend) 1 else 0 }.toMutableList()
            m.finishNormalize(bounds)
            return m
        }

        private fun applyMaterial(mj: JSONObject, doc: Doc, prim: Prim) {
            val pbr = mj.optJSONObject("pbrMetallicRoughness")
            var base = floatArrayOf(1f, 1f, 1f, 1f)
            pbr?.optJSONArray("baseColorFactor")?.let { bc -> if (bc.length() >= 3) base = floatArrayOf(bc.optF(0, 0f), bc.optF(1, 0f), bc.optF(2, 0f), if (bc.length() > 3) bc.optF(3, 0f) else 1f) }
            prim.metal = pbr?.optF("metallicFactor", 1f) ?: 1f
            prim.rough = pbr?.optF("roughnessFactor", 1f) ?: 1f
            prim.texBase = doc.texture(pbr?.optJSONObject("baseColorTexture"))
            prim.texMR = doc.texture(pbr?.optJSONObject("metallicRoughnessTexture"))

            val ext = mj.optJSONObject("extensions")
            val sg = ext?.optJSONObject("KHR_materials_pbrSpecularGlossiness")
            if (sg != null && (pbr == null || prim.texBase == 0)) {
                sg.optJSONArray("diffuseFactor")?.let { df -> if (df.length() >= 3) base = floatArrayOf(df.optF(0, 0f), df.optF(1, 0f), df.optF(2, 0f), if (df.length() > 3) df.optF(3, 0f) else 1f) }
                val dt = doc.texture(sg.optJSONObject("diffuseTexture"))
                if (dt != 0) prim.texBase = dt
                prim.metal = 0f
                prim.rough = 1 - min(max(sg.optF("glossinessFactor", 1f), 0f), 1f)
            }
            prim.color = base

            var em = floatArrayOf(0f, 0f, 0f)
            mj.optJSONArray("emissiveFactor")?.let { e -> if (e.length() >= 3) em = floatArrayOf(e.optF(0, 0f), e.optF(1, 0f), e.optF(2, 0f)) }
            ext?.optJSONObject("KHR_materials_emissive_strength")?.let { es -> val s = es.optF("emissiveStrength", 1f); em = FloatArray(3) { em[it] * s } }
            prim.emissive = em
            prim.texEm = doc.texture(mj.optJSONObject("emissiveTexture"))
            prim.texOcc = doc.texture(mj.optJSONObject("occlusionTexture"))
            prim.texNormal = doc.texture(mj.optJSONObject("normalTexture"))
            if (prim.texEm != 0 && em[0] == 0f && em[1] == 0f && em[2] == 0f) prim.emissive = floatArrayOf(1f, 1f, 1f)

            when (mj.optString("alphaMode", "OPAQUE")) {
                "MASK" -> prim.cutoff = mj.optF("alphaCutoff", 0.5f)
                "BLEND" -> prim.blend = true
            }
            if (ext?.has("KHR_materials_unlit") == true) prim.unlit = 1f
        }

        // MARK: - OBJ

        private data class Key(val v: Int, val t: Int, val n: Int)

        private fun parseObj(data: ByteArray): GlbModel? {
            val text = String(data, Charsets.UTF_8)
            val vp = ArrayList<Float>(); val vcol = ArrayList<Float>(); val vt = ArrayList<Float>(); val vn = ArrayList<Float>()
            var anyColor = false
            val map = HashMap<Key, Int>()
            val P = ArrayList<Float>(); var N = ArrayList<Float>(); val U = ArrayList<Float>(); val C = ArrayList<Float>()
            val idx = ArrayList<Int>()
            var hasN = false

            fun resolve(s: String, count: Int): Int { val i = s.toIntOrNull() ?: return -1; return if (i > 0) i - 1 else if (i < 0) count + i else -1 }

            for (line in text.lineSequence()) {
                val parts = line.split(' ', '\t').filter { it.isNotEmpty() }
                val head = parts.firstOrNull() ?: continue
                when (head) {
                    "v" -> {
                        if (parts.size < 4) continue
                        val x = parts[1].toFloatOrNull() ?: continue; val y = parts[2].toFloatOrNull() ?: continue; val z = parts[3].toFloatOrNull() ?: continue
                        vp.add(x); vp.add(y); vp.add(z)
                        val r = if (parts.size >= 7) parts[4].toFloatOrNull() else null
                        val g = if (parts.size >= 7) parts[5].toFloatOrNull() else null
                        val b = if (parts.size >= 7) parts[6].toFloatOrNull() else null
                        if (r != null && g != null && b != null) { vcol.add(r); vcol.add(g); vcol.add(b); anyColor = true }
                        else { vcol.add(1f); vcol.add(1f); vcol.add(1f) }
                    }
                    "vn" -> if (parts.size >= 4) {
                        val x = parts[1].toFloatOrNull(); val y = parts[2].toFloatOrNull(); val z = parts[3].toFloatOrNull()
                        if (x != null && y != null && z != null) { vn.add(x); vn.add(y); vn.add(z) }
                    }
                    "vt" -> if (parts.size >= 3) {
                        val u = parts[1].toFloatOrNull(); val v = parts[2].toFloatOrNull()
                        if (u != null && v != null) { vt.add(u); vt.add(1 - v) }
                    }
                    "f" -> {
                        val corner = ArrayList<Int>()
                        for (tok in parts.drop(1)) {
                            val f = tok.split('/')
                            val vi = resolve(f[0], vp.size / 3)
                            if (!(vi >= 0 && vi < vp.size / 3)) continue
                            val ti = if (f.size > 1) resolve(f[1], vt.size / 2) else -1
                            val ni = if (f.size > 2) resolve(f[2], vn.size / 3) else -1
                            val key = Key(vi, ti, ni)
                            map[key]?.let { corner.add(it); continue }
                            val id = P.size / 3
                            map[key] = id
                            P.add(vp[vi * 3]); P.add(vp[vi * 3 + 1]); P.add(vp[vi * 3 + 2])
                            if (ni >= 0 && ni < vn.size / 3) { N.add(vn[ni * 3]); N.add(vn[ni * 3 + 1]); N.add(vn[ni * 3 + 2]); hasN = true }
                            else { N.add(0f); N.add(0f); N.add(0f) }
                            if (ti >= 0 && ti < vt.size / 2) { U.add(vt[ti * 2]); U.add(vt[ti * 2 + 1]) } else { U.add(0f); U.add(0f) }
                            C.add(vcol[vi * 3]); C.add(vcol[vi * 3 + 1]); C.add(vcol[vi * 3 + 2]); C.add(1f)
                            corner.add(id)
                        }
                        if (corner.size >= 3) for (k in 1 until corner.size - 1) { idx.add(corner[0]); idx.add(corner[k]); idx.add(corner[k + 1]) }
                    }
                }
            }
            if (idx.isEmpty() || P.isEmpty()) { lastError = "OBJ has no faces"; return null }
            val Pa = P.toFloatArray(); val ia = idx.toIntArray()
            var Na = N.toFloatArray()
            if (!hasN) Na = genNormals(Pa, ia)
            else {
                val fresh = genNormals(Pa, ia)
                for (i in 0 until Na.size / 3) if (Na[i * 3] == 0f && Na[i * 3 + 1] == 0f && Na[i * 3 + 2] == 0f) { Na[i * 3] = fresh[i * 3]; Na[i * 3 + 1] = fresh[i * 3 + 1]; Na[i * 3 + 2] = fresh[i * 3 + 2] }
            }
            val bounds = Bounds()
            val prim = makePrim(Pa, Na, U.toFloatArray(), C.toFloatArray(), ia, GL_TRIANGLES, bounds)
            prim.color = if (anyColor) floatArrayOf(1f, 1f, 1f, 1f) else floatArrayOf(0.78f, 0.8f, 0.86f, 1f)
            prim.metal = 0f; prim.rough = 0.8f
            prim.unlit = if (anyColor) 1f else 0f
            val m = GlbModel()
            m.prims = mutableListOf(prim)
            m.finishNormalize(bounds)
            return m
        }

        // MARK: - geometry helpers

        private fun triangles(idx: IntArray, mode: Int): IntArray {
            when (mode) {
                5 -> {
                    if (idx.size < 3) return IntArray(0)
                    val out = ArrayList<Int>((idx.size - 2) * 3)
                    for (i in 0 until idx.size - 2) {
                        if (i % 2 == 0) { out.add(idx[i]); out.add(idx[i + 1]); out.add(idx[i + 2]) }
                        else { out.add(idx[i + 1]); out.add(idx[i]); out.add(idx[i + 2]) }
                    }
                    return out.toIntArray()
                }
                6 -> {
                    if (idx.size < 3) return IntArray(0)
                    val out = ArrayList<Int>()
                    for (i in 1 until idx.size - 1) { out.add(idx[0]); out.add(idx[i]); out.add(idx[i + 1]) }
                    return out.toIntArray()
                }
                else -> return idx.copyOf(idx.size / 3 * 3)
            }
        }

        private fun genNormals(p: FloatArray, idx: IntArray): FloatArray {
            val n = FloatArray(p.size)
            var i = 0
            while (i + 2 < idx.size) {
                val a = idx[i] * 3; val b = idx[i + 1] * 3; val c = idx[i + 2] * 3
                if (a + 2 < p.size && b + 2 < p.size && c + 2 < p.size) {
                    val ux = p[b] - p[a]; val uy = p[b + 1] - p[a + 1]; val uz = p[b + 2] - p[a + 2]
                    val vx = p[c] - p[a]; val vy = p[c + 1] - p[a + 1]; val vz = p[c + 2] - p[a + 2]
                    val nx = uy * vz - uz * vy; val ny = uz * vx - ux * vz; val nz = ux * vy - uy * vx
                    n[a] += nx; n[a + 1] += ny; n[a + 2] += nz
                    n[b] += nx; n[b + 1] += ny; n[b + 2] += nz
                    n[c] += nx; n[c + 1] += ny; n[c + 2] += nz
                }
                i += 3
            }
            var v = 0
            while (v + 2 < n.size) {
                val l = sqrt(n[v] * n[v] + n[v + 1] * n[v + 1] + n[v + 2] * n[v + 2])
                if (l > 1e-12f) { n[v] /= l; n[v + 1] /= l; n[v + 2] /= l } else { n[v] = 0f; n[v + 1] = 1f; n[v + 2] = 0f }
                v += 3
            }
            return n
        }

        /** Interleaves pos(3) normal(3) uv(2) colour(4); vertices and indices stay on the CPU. */
        private fun makePrim(P: FloatArray, N: FloatArray, U: FloatArray, C: FloatArray, idx: IntArray, mode: Int, bounds: Bounds): Prim {
            val n = P.size / 3
            val verts = FloatArray(n * 12)
            for (i in 0 until n) {
                val x = P[i * 3]; val y = P[i * 3 + 1]; val z = P[i * 3 + 2]
                if (x.isFinite() && y.isFinite() && z.isFinite()) bounds.add(x, y, z)
                val o = i * 12
                verts[o] = x; verts[o + 1] = y; verts[o + 2] = z
                verts[o + 3] = N[i * 3]; verts[o + 4] = N[i * 3 + 1]; verts[o + 5] = N[i * 3 + 2]
                verts[o + 6] = U[i * 2]; verts[o + 7] = U[i * 2 + 1]
                verts[o + 8] = C[i * 4]; verts[o + 9] = C[i * 4 + 1]; verts[o + 10] = C[i * 4 + 2]; verts[o + 11] = C[i * 4 + 3]
            }
            val p = Prim()
            p.count = idx.size; p.mode = mode; p.verts = verts; p.cpuIdx = idx; p.indexIs16 = n <= 65535
            return p
        }
    }
}
