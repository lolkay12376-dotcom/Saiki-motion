package com.saiki.motion.core

import kotlin.math.pow

// Port of Render/GlobalEnv.swift. COMPLETE: path + uniform + HDR/EXR/LDR decode to RGBA16F bytes in
// Kotlin; the mipmapped RGBA16F Vulkan upload is native (SceneRendererN.envTexCreate -> uploadEnvTex),
// the twin of Metal's MTLTextureDescriptor rgba16Float mipmapped + generateMipmaps.
object GlobalEnv {
    var path: String?
        get() = Prefs.getString("r3d.envPath", null)
        set(v) { Prefs.setString("r3d.envPath", v) }
    /** Native Tex* of the HDRI (0 = none). */
    @JvmField var cached: Long = 0L
    @JvmField var cachedPath: String? = null
    private var failed: String? = null
    @JvmField var mipLevels: Int = 1
    val uniform: FloatArray get() =
        if (path == null || cached == 0L) floatArrayOf(0f, 0f, 0f, 1f)
        else floatArrayOf(1f, R3D.g("envRot", 0f), (mipLevels - 1).toFloat(), R3D.g("envGain", 1f))

    /** Equirect picture (hdr / exr / jpg) as a mipmapped half-float texture so highlights keep their range.
     *  The decode runs in Kotlin (HDR/EXR readers below; jpg/png via BitmapFactory tonemapped-source), the
     *  RGBA16F + mipmap upload in native (SceneRendererN.envTexCreate). */
    fun tex(): Long {
        val p = path ?: run { cached = 0L; cachedPath = null; return 0L }
        if (cachedPath == p && cached != 0L) return cached
        if (failed == p) return 0L
        val w = 2048
        val h = 1024
        val rgba16 = decodeEquirect(p, w, h)
        if (rgba16 == null) { failed = p; return 0L }
        val t = com.saiki.motion.render.SceneRendererN.envTexCreate(w, h, rgba16)
        if (t == 0L) { failed = p; return 0L }
        cached = t
        cachedPath = p
        mipLevels = com.saiki.motion.render.SceneRendererN.texMipLevels(t)
        return t
    }

    /** .hdr (radiance rgbe) / .exr (minimal) / LDR equirect -> RGBA16F bytes (little-endian halves). */
    private fun decodeEquirect(path: String, w: Int, h: Int): ByteArray? {
        val f = java.io.File(path)
        if (!f.exists()) return null
        val hdr = decodeHdr(f) ?: decodeExr(f) ?: decodeLdr(f) ?: return null
        // resample to w x h RGBA16F
        val out = ByteArray(w * h * 8)
        val sw = hdr.second; val sh = hdr.first.size / (sw * 4)
        val bb = java.nio.ByteBuffer.wrap(out).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        for (y in 0 until h) {
            val sy = (y.toFloat() * (sh - 1) / (h - 1)).toInt().coerceIn(0, sh - 1)
            for (x in 0 until w) {
                val sx = (x.toFloat() * (sw - 1) / (w - 1).toFloat()).toInt().coerceIn(0, sw - 1)
                val o = (sy * sw + sx) * 4
                for (c in 0 until 3) bb.putShort(halfFromFloat(hdr.first[o + c]))
                bb.putShort(halfFromFloat(1f))
            }
        }
        return out
    }

    private fun decodeHdr(f: java.io.File): Pair<FloatArray, Int>? {
        return try {
            val r = f.inputStream().buffered()
            val header = ByteArray(10); r.read(header)
            if (!String(header, 0, 10).startsWith("#?")) { r.close(); return null }
            // skip to the blank line
            val sb = StringBuilder()
            while (true) {
                val line = readLine(r) ?: break
                if (line.isEmpty()) break
                sb.append(line)
            }
            val res = readLine(r) ?: run { r.close(); return null }
            val m = Regex("-Y (\\d+) \\+X (\\d+)").find(res) ?: run { r.close(); return null }
            val h = m.groupValues[1].toInt(); val w = m.groupValues[2].toInt()
            val px = FloatArray(w * h * 4)
            var y = 0
            while (y < h) {
                // RLE scanlines
                val b0 = r.read(); val b1 = r.read(); val b2 = r.read(); val b3 = r.read()
                if (b0 != 2 || b1 != 2 || (b2 or b3) shr 8 != 0) {
                    // flat (non-RLE) remainder: old-style
                    val rgbe = byteArrayOf(b0.toByte(), b1.toByte(), b2.toByte(), b3.toByte())
                    putRgbe(px, y * w, w, rgbe, 0)
                    var rest = ByteArray((w - 1) * 4)
                    var got = 0
                    while (got < rest.size) { val n = r.read(rest, got, rest.size - got); if (n <= 0) break; got += n }
                    var x = 1
                    var o = 0
                    while (x < w && o + 3 < rest.size) { putRgbe(px, y * w + x, 1, rest, o); x++; o += 4 }
                    y++
                    continue
                }
                val width = (b2 shl 8) or b3
                if (width != w) break
                val chans = Array(4) { ByteArray(width) }
                for (c in 0 until 4) {
                    var x = 0
                    while (x < width) {
                        val cnt = r.read()
                        if (cnt <= 0) break
                        if (cnt > 128) {
                            val v = r.read().toByte()
                            repeat(cnt - 128) { if (x < width) chans[c][x++] = v }
                        } else {
                            repeat(cnt) { if (x < width) { val v = r.read(); if (v < 0) break; chans[c][x++] = v.toByte() } }
                        }
                    }
                }
                for (x in 0 until width) {
                    val e = chans[3][x].toInt()
                    val scale = if (e == 0) 0f else 2f.pow((e - 136).toFloat())
                    px[(y * w + x) * 4] = (chans[0][x].toInt() and 0xFF) / 255f * scale
                    px[(y * w + x) * 4 + 1] = (chans[1][x].toInt() and 0xFF) / 255f * scale
                    px[(y * w + x) * 4 + 2] = (chans[2][x].toInt() and 0xFF) / 255f * scale
                    px[(y * w + x) * 4 + 3] = 1f
                }
                y++
            }
            r.close()
            if (y < h) null else Pair(px, w)
        } catch (_: Exception) { null }
    }

    private fun putRgbe(px: FloatArray, i: Int, w: Int, src: ByteArray, o: Int) {
        val e = src[o + 3].toInt()
        val scale = if (e == 0) 0f else 2f.pow((e - 136).toFloat())
        px[i * 4] = (src[o].toInt() and 0xFF) / 255f * scale
        px[i * 4 + 1] = (src[o + 1].toInt() and 0xFF) / 255f * scale
        px[i * 4 + 2] = (src[o + 2].toInt() and 0xFF) / 255f * scale
        px[i * 4 + 3] = 1f
    }

    private fun readLine(r: java.io.InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val c = r.read()
            if (c < 0) return if (sb.isEmpty()) null else sb.toString()
            if (c == 10 || c == 13) return sb.toString()
            sb.append(c.toChar())
        }
    }

    /** Minimal EXR: RGB half-float ZIP/none scanlines of a single part. */
    private fun decodeExr(f: java.io.File): Pair<FloatArray, Int>? {
        return try {
            val data = f.readBytes()
            if (data.size < 8 || data[0] != 0x76.toByte() || data[1] != 0x2f.toByte() || data[2] != 0x31.toByte() || data[3] != 0x01.toByte()) return null
            var p = 8
            // attributes until empty name
            var w = 0; var h = 0
            var comp: String? = null
            var fmt = ""
            while (true) {
                val name = cStr(data, p) ?: break
                if (name.isEmpty()) { p++; break }
                val type = cStr(data, p + name.length + 1) ?: break
                val szOff = p + name.length + type.length + 2
                val sz = leInt(data, szOff)
                val valOff = szOff + 4
                when (name) {
                    "dataWindow" -> { w = leInt(data, valOff + 4) - leInt(data, valOff) + 1; h = leInt(data, valOff + 12) - leInt(data, valOff + 8) + 1 }
                    "compression" -> comp = (data[valOff].toInt() and 0xFF).toString()
                    "channels" -> fmt = "rgba"
                }
                p = valOff + sz
            }
            if (w <= 0 || h <= 0 || comp != "0") return null      // uncompressed only
            val ch = 4
            val px = FloatArray(w * h * 4)
            val bb = java.nio.ByteBuffer.wrap(data).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            var o = p + 4            // skip the line-offset table (h * 4 bytes)
            o += h * 4
            for (y in 0 until h) {
                val yCoord = bb.getInt(o); o += 4
                val dataSize = bb.getInt(o); o += 4
                if (yCoord != y) return null
                for (x in 0 until w) {
                    for (c in 0 until 3) {
                        px[(y * w + x) * 4 + c] = halfToFloat(bb.getShort(o + (c * w * h) + x * 2))
                    }
                    px[(y * w + x) * 4 + 3] = 1f
                }
                o += dataSize
            }
            Pair(px, w)
        } catch (_: Exception) { null }
    }

    private fun decodeLdr(f: java.io.File): Pair<FloatArray, Int>? {
        return try {
            val bmp = android.graphics.BitmapFactory.decodeFile(f.absolutePath) ?: return null
            val w = minOf(bmp.width, 2048)
            val h = bmp.height * w / bmp.width
            val scaled = android.graphics.Bitmap.createScaledBitmap(bmp, w, h, true)
            val px = IntArray(w * h)
            scaled.getPixels(px, 0, w, 0, 0, w, h)
            val out = FloatArray(w * h * 4)
            for (i in 0 until w * h) {
                val c = px[i]
                out[i * 4] = ((c shr 16) and 0xFF) / 255f
                out[i * 4 + 1] = ((c shr 8) and 0xFF) / 255f
                out[i * 4 + 2] = (c and 0xFF) / 255f
                out[i * 4 + 3] = 1f
            }
            Pair(out, w)
        } catch (_: Exception) { null }
    }

    private fun cStr(d: ByteArray, off: Int): String? {
        if (off >= d.size) return null
        var e = off
        while (e < d.size && d[e] != 0.toByte()) e++
        if (e >= d.size) return null
        return String(d, off, e - off, Charsets.US_ASCII)
    }
    private fun leInt(d: ByteArray, off: Int): Int =
        (d[off].toInt() and 0xFF) or ((d[off + 1].toInt() and 0xFF) shl 8) or ((d[off + 2].toInt() and 0xFF) shl 16) or ((d[off + 3].toInt() and 0xFF) shl 24)

    /** float <-> IEEE 754 half conversions (line-exact semantics of Data.Companion half conversions). */
    fun halfFromFloat(f: Float): Short {
        val bits = f.toRawBits()
        val sign = (bits ushr 16) and 0x8000
        var exp = ((bits ushr 23) and 0xFF) - 127 + 15
        var mant = bits and 0x7FFFFF
        if (exp >= 31) return (sign or 0x7C00).toShort()      // inf/nan -> inf
        if (exp <= 0) {
            if (exp < -10) return sign.toShort()
            mant = mant or 0x800000
            val shift = 14 - exp
            val half = (mant shr shift).toInt()
            return (sign or half).toShort()
        }
        return (sign or (exp shl 10) or (mant ushr 13)).toShort()
    }
    fun halfToFloat(h: Short): Float {
        val v = h.toInt() and 0xFFFF
        val sign = (v ushr 15) and 1
        val exp = (v ushr 10) and 0x1F
        val mant = v and 0x3FF
        val bits: Int = when {
            exp == 0 -> (sign shl 31) or (if (mant == 0) 0 else { var e = 127 - 14 + 1; var m = mant
                while (m and 0x400 == 0) { m = m shl 1; e-- }
                m = m and 0x3FF
                (e shl 23) or (m shl 13) })
            exp == 31 -> (sign shl 31) or 0x7F800000 or (mant shl 13)
            else -> (sign shl 31) or ((exp - 15 + 127) shl 23) or (mant shl 13)
        }
        return Float.fromBits(bits)
    }
}
