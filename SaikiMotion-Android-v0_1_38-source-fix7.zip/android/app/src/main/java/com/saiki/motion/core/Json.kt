package com.saiki.motion.core

import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.util.Locale

// Port of Sources/Core/Json.swift (writer + opt helpers). Parsing uses org.json (insertion-ordered on Android).
// org.json optDouble() defaults to NaN and put(Double.NaN) THROWS -> every helper here takes explicit defaults / guards NaN.

object JSONWriter {
    /** iOS JSONWriter.numberToString: integral doubles without decimals, else shortest round-trip, non-finite -> null. */
    fun numberToString(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "null"
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return String.format(Locale.US, "%.0f", d)
        var s = swiftDesc(d)
        if (s.endsWith(".0")) s = s.dropLast(2)
        return s
    }

    /** Swift `"\(d)"` for Double (Ryu shortest round-trip): plain for 1e-4 <= |d| < 1e16, else d.ddde[+-]XX — 1e-4 -> "0.0001", 1e-5 -> "1e-05", 1e16 -> "1e+16". Verified same digits as Swift inside and outside the range. */
    fun swiftDesc(d: Double): String {
        if (d == 0.0) return if (1.0 / d < 0) "-0.0" else "0.0"
        val bd = BigDecimal(java.lang.Double.toString(d))
        val a = Math.abs(d)
        if (a >= 1e-4 && a < 1e16) {
            val p = bd.toPlainString()
            return if (p.contains('.')) p else "$p.0"
        }
        val neg = d < 0
        val digits = bd.unscaledValue().abs().toString().trimEnd('0').ifEmpty { "0" }
        val exp = bd.precision() - bd.scale() - 1
        val mant = if (digits.length == 1) digits else digits[0] + "." + digits.substring(1)
        val es = (if (exp < 0) "-" else "+") + String.format(Locale.US, "%02d", Math.abs(exp))
        return (if (neg) "-" else "") + mant + "e" + es
    }

    /** Swift `"\(f)"` for Float (used by Layer.xset): shortest round-trip digits — identical to Swift (0.1 -> "0.1"); outside 1e-4..1e16 Swift prints the same d.ddde[+-]XX form (Float 1e-45 -> "1e-45", 3.4e38 -> "3.4e+38"). */
    fun swiftDescF(f: Float): String {
        if (f == 0f) return if (1f / f < 0) "-0.0" else "0.0"
        if (f.isNaN()) return "nan"
        if (f.isInfinite()) return if (f < 0) "-inf" else "inf"
        val bd = BigDecimal(java.lang.Float.toString(f))
        val a = Math.abs(f)
        if (a >= 1e-4f && a < 1e16f) { val p = bd.toPlainString(); return if (p.contains('.')) p else "$p.0" }
        val digits = bd.unscaledValue().abs().toString().trimEnd('0').ifEmpty { "0" }
        val exp = bd.precision() - bd.scale() - 1
        val mant = if (digits.length == 1) digits else digits[0] + "." + digits.substring(1)
        return (if (f < 0) "-" else "") + mant + "e" + (if (exp < 0) "-" else "+") + String.format(Locale.US, "%02d", Math.abs(exp))
    }

    fun escape(s: String): String {
        val out = StringBuilder("\"")
        for (ch in s) {
            when (ch) {
                '"' -> out.append("\\\"")
                '\\' -> out.append("\\\\")
                '\n' -> out.append("\\n")
                '\r' -> out.append("\\r")
                '\t' -> out.append("\\t")
                '\b' -> out.append("\\b")
                '\u000C' -> out.append("\\f")
                else -> if (ch.code < 0x20) out.append(String.format(Locale.US, "\\u%04x", ch.code)) else out.append(ch)
            }
        }
        return out.append('"').toString()
    }

    fun scalar(v: Any?): String = when (v) {
        null, JSONObject.NULL -> "null"
        is String -> escape(v)
        is Boolean -> if (v) "true" else "false"
        is Double -> numberToString(v)
        is Float -> numberToString(v.toDouble())
        is Long -> v.toString()
        is Int -> v.toString()
        is Number -> numberToString(v.toDouble())
        else -> escape(v.toString())
    }

    fun write(v: Any?): String = when (v) {
        is JSONObject -> v.toCompact()
        is JSONArray -> v.toCompact()
        else -> scalar(v)
    }
}

/** Compact writer identical to iOS JObj.toString() (org.json's own toString would escape "/"). */
fun JSONObject.toCompact(): String {
    val sb = StringBuilder("{")
    var first = true
    val it = keys()
    while (it.hasNext()) {
        val k = it.next()
        if (!first) sb.append(',')
        first = false
        sb.append(JSONWriter.escape(k)).append(':').append(JSONWriter.write(opt(k)))
    }
    return sb.append('}').toString()
}

fun JSONArray.toCompact(): String {
    val sb = StringBuilder("[")
    for (i in 0 until length()) { if (i > 0) sb.append(','); sb.append(JSONWriter.write(opt(i))) }
    return sb.append(']').toString()
}

// ---- opt helpers with iOS defaults (JObj.optX) ----
fun JSONObject.optF(k: String, d: Float = 0f): Float = optDouble(k, d.toDouble()).toFloat()
fun JSONObject.optI(k: String, d: Int = 0): Int = optInt(k, d)
fun JSONObject.optB(k: String, d: Boolean = false): Boolean = optBoolean(k, d)
fun JSONObject.optS(k: String, d: String = ""): String {
    val v = opt(k)
    return when {
        v == null || v === JSONObject.NULL -> d
        v is String -> v
        v is Number -> JSONWriter.scalar(v)
        else -> d
    }
}
fun JSONArray.optF(i: Int, d: Float = 0f): Float = optDouble(i, d.toDouble()).toFloat()
fun JSONArray.optI(i: Int, d: Int = 0): Int = optInt(i, d)
fun JSONArray.optS(i: Int, d: String = ""): String {
    val v = opt(i)
    return when { v == null || v === JSONObject.NULL -> d; v is String -> v; v is Number -> JSONWriter.scalar(v); else -> d }
}

// ---- NaN-safe puts (iOS writer prints null for non-finite) ----
fun JSONObject.putF(k: String, v: Float): JSONObject = putD(k, v.toDouble())
fun JSONObject.putD(k: String, v: Double): JSONObject { put(k, if (v.isNaN() || v.isInfinite()) JSONObject.NULL else v); return this }
fun JSONObject.putL(k: String, v: Long): JSONObject { put(k, v); return this }
fun JSONArray.putF(v: Float): JSONArray { put(if (v.isNaN() || v.isInfinite()) JSONObject.NULL else v.toDouble()); return this }

// ---- colour <-> JSON (Double(UInt32(bitPattern:)) / Int32(bitPattern: UInt32(clamping: Int64(d)))) ----
fun colorToJson(c: Int): Double = (c.toLong() and 0xFFFFFFFFL).toDouble()
fun JSONObject.optColor(k: String): Int = optDouble(k, 0.0).toLong().coerceIn(0L, 0xFFFFFFFFL).toInt()

/** Swift Float(String): rejects whitespace and Java's f/d suffixes. */
fun parseSwiftFloat(s: String): Float? {
    if (s.isEmpty() || s.last().let { it == 'f' || it == 'F' || it == 'd' || it == 'D' } || s.first().isWhitespace() || s.last().isWhitespace()) return null
    if (s.contains("0x") || s.contains("0X")) return null
    return s.toFloatOrNull()
}

/** Lenient parse (nil on failure) like JObj.parse. */
fun parseJson(text: String): JSONObject? = try { JSONObject(text.trimStart('\uFEFF')) } catch (e: Exception) { null }

/** iOS JObj.toString(indent) / JArr.toString(indent) (Json.swift:128, :291): 4-space pretty writer, no "/" escaping. */
fun JSONObject.toPretty(indent: Int = 0): String {
    if (length() == 0) return "{}"
    val pad = " ".repeat(indent); val pad2 = " ".repeat(indent + 4)
    val sb = StringBuilder("{\n")
    val ks = ArrayList<String>(); val it = keys(); while (it.hasNext()) ks.add(it.next())
    for ((i, k) in ks.withIndex()) {
        val v = opt(k)
        val body = when (v) { is JSONObject -> v.toPretty(indent + 4); is JSONArray -> v.toPretty(indent + 4); else -> JSONWriter.scalar(v) }
        sb.append(pad2).append(JSONWriter.escape(k)).append(':').append(body).append(if (i < ks.size - 1) ",\n" else "\n")
    }
    return sb.append(pad).append('}').toString()
}

fun JSONArray.toPretty(indent: Int = 0): String {
    if (length() == 0) return "[]"
    val pad = " ".repeat(indent); val pad2 = " ".repeat(indent + 4)
    val sb = StringBuilder("[\n")
    for (i in 0 until length()) {
        val e = opt(i)
        val body = when (e) { is JSONObject -> e.toPretty(indent + 4); is JSONArray -> e.toPretty(indent + 4); else -> JSONWriter.scalar(e) }
        sb.append(pad2).append(body).append(if (i < length() - 1) ",\n" else "\n")
    }
    return sb.append(pad).append(']').toString()
}
