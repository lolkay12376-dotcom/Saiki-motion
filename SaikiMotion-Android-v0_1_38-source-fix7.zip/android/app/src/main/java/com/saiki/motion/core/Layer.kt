package com.saiki.motion.core

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max

// Port of Sources/Model/Layer.swift. Same JSON keys, defaults, ordering. Colors are Int (Int32(bitPattern:)).
// Flare/Puppet/Rig/Warp/AudioFxItem are lossless raw-JSON holders (Placeholders.kt) until their slices.

enum class LayerType { SHAPE, TEXT, IMAGE, VIDEO, CAMERA, NULL, MODEL, PARTICLES, GROUP, ADJUST, AUDIO, FLARE }

enum class ShapeKind {
    RECT, ROUND, CIRCLE, TRIANGLE, STAR, DIAMOND, HEXAGON, PENTAGON, OCTAGON, ARROW, CHEVRON, PLUS, HEART, RING, ELLIPSE, PATH;
    val title: String get() = name.substring(0, 1) + name.substring(1).lowercase()
    val glKind: Float get() = when (this) {
        RECT -> 0f; ROUND -> 1f; CIRCLE -> 2f; TRIANGLE -> 3f; STAR -> 4f; DIAMOND -> 5f; HEXAGON -> 6f; PENTAGON -> 7f
        OCTAGON -> 8f; ARROW -> 9f; CHEVRON -> 10f; PLUS -> 11f; HEART -> 12f; RING -> 13f; ELLIPSE -> 14f; PATH -> 15f
    }
    val usesRound: Boolean get() = this !in listOf(CIRCLE, TRIANGLE, STAR, HEART, RING, ELLIPSE, RECT)
    val usesThick: Boolean get() = this in listOf(ARROW, PLUS, RING)
    companion object {
        val allKinds = listOf(RECT, ROUND, CIRCLE, ELLIPSE, TRIANGLE, DIAMOND, PENTAGON, HEXAGON, OCTAGON, STAR, ARROW, CHEVRON, PLUS, HEART, RING)
    }
}

private fun uid6(): String = UUID.randomUUID().toString().take(6).lowercase()

// ------------------------------------------------------------------ TextAnim
class TextFx(var kind: Int) {
    var v: MutableList<Float> = PARAMS[kind].map { it.def }.toMutableList()
    var id = uid6()
    fun name() = if (kind in KINDS.indices) KINDS[kind] else "Effect"
    fun copy(): TextFx { val f = TextFx(kind); f.v = v.toMutableList(); f.id = id; return f }
    fun toJson(): JSONObject {
        val a = JSONArray(); for (x in v) a.putF(x)
        val o = JSONObject(); o.putL("kind", kind.toLong()); o.put("v", a); o.put("id", id); return o
    }

    class P(val label: String, val lo: Float, val hi: Float, val def: Float, val dec: Int)
    companion object {
        val KINDS = listOf("Transform", "Wiggle", "3D", "Tracking", "Skew")
        val PARAMS: List<List<P>> = listOf(
            listOf(P("Move X from", -2f, 2f, 0f, 2), P("Move Y from", -2f, 2f, 0.3f, 2), P("Scale from", 0f, 4f, 1f, 2),
                P("Rotate from (deg)", -720f, 720f, 0f, 0), P("Opacity from", 0f, 1f, 0f, 2)),
            listOf(P("Wiggle X", 0f, 1f, 0.03f, 3), P("Wiggle Y", 0f, 1f, 0.03f, 3), P("Wiggle rotate (deg)", 0f, 90f, 8f, 1),
                P("Wiggle scale", 0f, 1f, 0f, 2), P("Speed (Hz)", 0f, 20f, 4f, 1), P("Letter offset", 0f, 3f, 0.5f, 2)),
            listOf(P("Rotate X (deg)", -360f, 360f, 90f, 0), P("Rotate Y (deg)", -360f, 360f, 0f, 0), P("Perspective", 0f, 1f, 0.3f, 2)),
            listOf(P("Tracking from (em)", -1f, 3f, 1f, 2)),
            listOf(P("Skew X (deg)", -80f, 80f, 25f, 0), P("Skew Y (deg)", -80f, 80f, 0f, 0)))
        fun fromJson(o: JSONObject): TextFx {
            val k = clamp(o.optI("kind"), 0, KINDS.size - 1)
            val f = TextFx(k)
            val fid = o.optS("id"); if (fid.isNotEmpty()) f.id = fid
            o.optJSONArray("v")?.let { a -> for (i in 0 until minOf(a.length(), f.v.size)) f.v[i] = a.optDouble(i, 0.0).toFloat() }
            return f
        }
    }
}

class TextAnim(var type: Int, var mode: Int = 0) {
    var start = 0f
    var dur = 0.5f
    var stagger = 0.04f
    var distance = 0.15f
    var scaleFrom = 0.6f
    var rotFrom = 0f
    var speed = 1f
    var ease = 0
    var curve = Key(0f, 0f, Ease.EASE_IN_OUT)
    var fade = true
    var fx = mutableListOf<TextFx>()
    var id = uid6()

    fun name() = if (type in TYPES.indices) TYPES[type] else "Animation"
    fun copy(): TextAnim {
        val a = TextAnim(type, mode)
        a.start = start; a.dur = dur; a.stagger = stagger; a.distance = distance
        a.scaleFrom = scaleFrom; a.rotFrom = rotFrom; a.speed = speed; a.ease = ease
        a.curve = curve.copy(); a.fade = fade
        a.fx = fx.map { it.copy() }.toMutableList(); a.id = id
        return a
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.putL("type", type.toLong()); o.putL("mode", mode.toLong()); o.putF("start", start)
        o.putF("dur", dur); o.putF("stagger", stagger); o.putF("distance", distance)
        o.putF("scaleFrom", scaleFrom); o.putF("rotFrom", rotFrom); o.putF("speed", speed)
        o.putL("ease", ease.toLong()); o.put("curve", curve.toJson()); o.put("fade", fade)
        o.put("id", id); o.put("fx", JSONArray().also { a -> for (f in fx) a.put(f.toJson()) })
        return o
    }

    companion object {
        val TYPES = listOf("Slide up in", "Slide down in", "Fade in", "Scale in", "Typewriter", "Pop in", "Rotate in",
            "Slide up out", "Fade out", "Slide down out", "Bounce in", "Outline draw", "Custom")
        fun fromJson(o: JSONObject): TextAnim {
            val a = TextAnim(o.optI("type"), o.optI("mode"))
            a.start = o.optF("start"); a.dur = max(0.05f, o.optF("dur", 0.5f))
            a.stagger = o.optF("stagger", 0.04f); a.distance = o.optF("distance", 0.15f)
            a.scaleFrom = o.optF("scaleFrom", 0.6f); a.rotFrom = o.optF("rotFrom")
            a.speed = o.optF("speed", 1f); a.ease = o.optI("ease")
            o.optJSONObject("curve")?.let { a.curve = Key.fromJson(it) }
            a.fade = o.optB("fade", true)
            val aid = o.optS("id"); if (aid.isNotEmpty()) a.id = aid
            o.optJSONArray("fx")?.let { fa -> for (i in 0 until fa.length()) fa.optJSONObject(i)?.let { a.fx.add(TextFx.fromJson(it)) } }
            return a
        }
    }
}

// ------------------------------------------------------------------ Layer
class Layer(var id: Int, var name: String, var type: LayerType) {
    // identity + timing
    var parentId = -1
    var lockRot = false; var lockScale = false; var lockMove = false
    var visible = true
    var start = 0f
    var end = 5f
    var srcDur = 0f
    var srcOffset = 0f
    var blend = 0
    var mask = 0
    var clipIds = mutableListOf<Int>()
    var clipInv = false

    // content
    var text = ""
    var imagePath: String? = null
    var shape = ShapeKind.RECT
    var vpath = VPath()
    var flare: Flare? = null

    // text style
    var color: Int = 0xFFFFFFFF.toInt()
    var color2: Int = 0xFF7A7A84.toInt()
    var font = "sans-serif"
    var fontPath: String? = null
    var bold = false
    var italic = false
    var underline = false
    var strike = false
    var align = 1
    var caps = 0
    var spacing = 0f
    var strokeW = 0f
    var strokeColor: Int = 0xFF000000.toInt()
    var strokePos = 0
    var strokeJoin = 0
    var stroke2W = 0f
    var stroke2Color: Int = 0xFF000000.toInt()
    var borderW = 0f
    var borderColor: Int = 0xFFFFFFFF.toInt()
    var borderFill: Int = 0
    var gradMode = 0
    var gradX1 = 0f; var gradY1 = 0.6f; var gradX2 = 0f; var gradY2 = -0.6f
    var borderPad = 0f
    var borderDash = false
    var shadowOn = false
    var shadowColor: Int = 0xFF000000.toInt()
    var anims = mutableListOf<TextAnim>()

    // 3d / fx
    var is3d = false
    var mblur = false
    var precomp = true
    var prerender = false
    var mbStutter = false
    var mbRgb = false
    var m3Env = true; var m3Metal = true; var m3Ao = true; var occlude = true
    var m3View = 0
    var vdbTint: Int = 0xFFFFFFFF.toInt()
    var tgraph = ""
    var pbrMaps = LinkedHashMap<String, String>()
    var x3s = ""
    var vdbDens = 1f
    var rtOn = false
    var rtInt = 1f
    var rtRad = 0.5f
    var vdbBright = 1f
    var vdbEnv = false
    var vdbEnvPath: String? = null
    var vdbSurround = false
    var afx = mutableListOf<AudioFxItem>()
    var fx = mutableListOf<String>()
    var fxOff = LinkedHashSet<String>()
    var inputs = LinkedHashMap<String, Int>()
    var props = HashMap<String, Track>()
    var puppet: Puppet? = null
    var rig: Rig? = null
    var rigOff = HashMap<String, Float>()
    var warpOff = HashMap<String, Float>()
    var deformer = 0
    var warp: Warp? = null

    init {
        props["x"] = Track(0f); props["y"] = Track(0f); props["z"] = Track(0f)
        props["scale"] = Track(1f); props["scaleX"] = Track(1f); props["scaleY"] = Track(1f)
        props["rotX"] = Track(0f); props["rotY"] = Track(0f); props["rotZ"] = Track(0f)
        props["anchorX"] = Track(50f); props["anchorY"] = Track(50f); props["anchorZ"] = Track(0f)
        props["opacity"] = Track(1f)
    }

    fun xf(k: String, d: Float): Float {
        for (kv in x3s.split(';')) {
            if (kv.isEmpty()) continue
            val p = kv.split('=').filter { it.isNotEmpty() }
            if (p.size == 2 && p[0] == k) return parseSwiftFloat(p[1]) ?: d
        }
        return d
    }

    fun xset(k: String, v: Float) {
        val out = x3s.split(';').filter { it.isNotEmpty() && !it.startsWith("$k=") }.toMutableList()
        out.add("$k=" + JSONWriter.swiftDescF(v)); x3s = out.joinToString(";")
    }

    class ChainItem(val owner: Layer, val entry: String)

    /** Own effects, then Squeeze effects of ancestors that tick "Affect parent hierarchy". */
    fun fxChain(): List<ChainItem> {
        val out = fx.map { ChainItem(this, it) }.toMutableList()
        var cur = this; var hops = 0
        val all = Editor.scene.layers
        while (cur.parentId >= 0 && hops < 64) {
            val par = all.firstOrNull { it.id == cur.parentId } ?: break
            hops++; cur = par
            if (par.type == LayerType.GROUP && par.precomp) continue
            for (e in par.fx) {
                if (par.fxOff.contains(e) || Registry.get(e)?.id != "squeeze") continue
                val h = par.props[e + "__sqHier"]
                if (h != null && h.eval(Editor.time) > 0.5f) out.add(ChainItem(par, e))
            }
        }
        return out
    }

    fun shiftKeys(dt: Float) { if (dt == 0f) return; for ((_, tr) in props) for (k in tr.keys) k.t += dt }

    fun track(key: String): Track {
        props[key]?.let { return it }
        val t = Track(Registry.propDef(key)?.def ?: 0f)
        props[key] = t
        return t
    }

    fun p(key: String, t: Float): Float {
        val tr = props[key]
        val base: Float = if (tr != null)
            tr.evalExpr(editTime(key, t), t, if (tr.exprActive()) Editor.scene.markersByName() else emptyMap())
        else defaults[key] ?: (Registry.propDef(key)?.def ?: 0f)
        return if (rigOff.isEmpty()) base else base + (rigOff[key] ?: 0f)
    }

    fun editTime(key: String, t: Float): Float = t   // iOS returns t on every path (remap handled by callers)

    fun pkey(entry: String, pd: PropDef): String = if ((Registry.get(entry)?.kind ?: 0) == 1) pd.key else entry + "__" + pd.key
    fun ckey(entry: String, cp: ColorParam): String = if ((Registry.get(entry)?.kind ?: 0) == 1) cp.key else entry + "__" + cp.key

    fun isRenderable(): Boolean = when (type) {
        LayerType.SHAPE, LayerType.TEXT, LayerType.IMAGE, LayerType.VIDEO, LayerType.MODEL, LayerType.FLARE, LayerType.PARTICLES -> true
        else -> false
    }

    fun speedAt(t: Float): Float {
        val rt = props["remapT"]
        if (rt != null && rt.keys.isNotEmpty()) {
            val a = rt.eval(max(t - 0.05f, 0f)); val b = rt.eval(t + 0.05f)
            val d = b - a
            if (abs(d) > 0.0001f) return clamp(0.1f * d, -10f, 10f) / 0.1f
        }
        return props["remapSpeed"]?.eval(t) ?: 1f
    }

    val isLight: Boolean get() = type == LayerType.NULL && xf("isLight", 0f) > 0.5f

    // ------------------------------------------------------------ serialization
    fun toJson(canonical: Boolean = false): JSONObject {
        val o = JSONObject()
        o.putL("id", id.toLong()); o.put("name", name); o.put("type", type.name)
        o.putL("parentId", parentId.toLong()); o.put("visible", visible)
        if (lockRot) o.put("lockRot", true)
        if (lockScale) o.put("lockScale", true)
        if (lockMove) o.put("lockMove", true)
        o.putF("start", start); o.putF("end", end)
        o.putF("srcDur", srcDur); o.putF("srcOffset", srcOffset)
        o.putL("blend", blend.toLong()); o.putL("mask", mask.toLong())
        o.put("clip", JSONArray().also { a -> for (i in clipIds) a.put(i.toLong()) }); o.put("clipInv", clipInv)
        o.put("text", text); o.put("imagePath", imagePath ?: "")
        o.put("shape", shape.name)
        if (shape == ShapeKind.PATH) {
            val a = JSONArray()
            for (q in vpath.pts) for (v in floatArrayOf(q.x, q.y, q.ix, q.iy, q.ox, q.oy)) a.putF(v)
            o.put("vpath", a); o.put("vclosed", vpath.closed)
        }
        flare?.let { o.put("flare", it.toJson()) }
        o.putD("color", colorToJson(color)); o.putD("color2", colorToJson(color2))
        o.put("font", font); o.put("fontPath", fontPath ?: "")
        o.put("bold", bold); o.put("italic", italic); o.put("underline", underline); o.put("strike", strike)
        o.putL("align", align.toLong()); o.putL("caps", caps.toLong()); o.putF("spacing", spacing)
        o.putF("strokeW", strokeW); o.putD("strokeColor", colorToJson(strokeColor))
        o.putL("strokePos", strokePos.toLong()); o.putL("strokeJoin", strokeJoin.toLong())
        o.putF("stroke2W", stroke2W); o.putD("stroke2Color", colorToJson(stroke2Color))
        o.putF("borderW", borderW); o.putD("borderColor", colorToJson(borderColor))
        o.putD("borderFill", colorToJson(borderFill))
        o.putD("gradMode", gradMode.toDouble()); o.putF("gradX1", gradX1); o.putF("gradY1", gradY1)
        o.putF("gradX2", gradX2); o.putF("gradY2", gradY2)
        o.putF("borderPad", borderPad); o.put("borderDash", borderDash)
        o.put("shadowOn", shadowOn); o.putD("shadowColor", colorToJson(shadowColor))
        o.put("anims", JSONArray().also { aa -> for (a in anims) aa.put(a.toJson()) })
        o.put("precomp", precomp)
        if (prerender) o.put("prerender", true)
        o.put("is3d", is3d); o.put("mblur", mblur); o.put("mbStutter", mbStutter); o.put("mbRgb", mbRgb)
        o.put("m3Env", m3Env); o.put("m3Metal", m3Metal); o.put("m3Ao", m3Ao); o.put("occlude", occlude)
        o.putL("m3View", m3View.toLong()); o.putF("vdbDens", vdbDens); o.putF("vdbBright", vdbBright)
        o.put("rtOn", rtOn); o.putF("rtInt", rtInt); o.putF("rtRad", rtRad); o.put("vdbEnv", vdbEnv); o.put("vdbSurround", vdbSurround)
        o.put("vdbEnvPath", vdbEnvPath ?: ""); o.putD("vdbTint", colorToJson(vdbTint)); o.put("x3s", x3s)
        o.put("pbrMaps", pbrMaps.entries.joinToString("\u0001") { it.key + "\u0002" + it.value }); o.put("tgraph", tgraph)
        o.put("fx", JSONArray().also { a -> for (e in fx) a.put(e) })
        o.put("fxOff", JSONArray().also { a -> for (e in fxOff) a.put(e) })
        if (afx.isNotEmpty()) o.put("afx", JSONArray().also { a -> for (x in afx) a.put(x.toJson()) })
        val io = JSONObject()
        for ((k, v) in inputs.entries.sortedBy { it.key }) io.putL(k, v.toLong())
        o.put("inputs", io)
        val po = JSONObject()
        // sorted so identical layers always serialise identically
        for ((k, tr) in props.entries.sortedBy { it.key }) {
            if (canonical && tr.keys.isEmpty() && !tr.exprOn && tr.base == (Registry.propDef(k)?.def ?: 0f)) continue
            po.put(k, tr.toJson())
        }
        o.put("props", po)
        puppet?.let { o.put("puppet", it.toJson()) }
        rig?.let { o.put("rig", it.toJson()) }
        if (deformer != 0) o.putL("deformer", deformer.toLong())
        warp?.let { o.put("warp", it.toJson()) }
        return o
    }

    companion object {
        fun isDescendant(a: Layer, b: Layer, all: List<Layer>): Boolean {
            var cur = a
            while (true) {
                if (cur === b) return true
                if (cur.parentId < 0) return false
                cur = all.firstOrNull { it.id == cur.parentId } ?: return false
            }
        }

        fun fromJson(o: JSONObject): Layer {
            val l = Layer(o.optI("id"), o.optS("name", "Layer"),
                runCatching { LayerType.valueOf(o.optS("type", "SHAPE")) }.getOrDefault(LayerType.SHAPE))
            l.parentId = o.optI("parentId", -1)
            l.lockRot = o.optB("lockRot", false); l.lockScale = o.optB("lockScale", false); l.lockMove = o.optB("lockMove", false)
            l.visible = o.optB("visible", true)
            l.start = o.optF("start")
            l.end = o.optF("end", 5f)
            l.srcDur = o.optF("srcDur")
            l.srcOffset = o.optF("srcOffset")
            l.blend = o.optI("blend")
            l.mask = o.optI("mask")
            o.optJSONArray("vpath")?.let { va ->
                l.vpath.closed = o.optB("vclosed", false)
                val pts = mutableListOf<VPt>()
                var i = 0
                while (i < va.length() - 5) {
                    pts.add(VPt(va.optF(i), va.optF(i + 1), va.optF(i + 2), va.optF(i + 3), va.optF(i + 4), va.optF(i + 5)))
                    i += 6
                }
                l.vpath.pts = pts
            }
            o.optJSONArray("clip")?.let { ca -> l.clipIds = (0 until ca.length()).map { ca.optI(it) }.toMutableList() }
            l.clipInv = o.optB("clipInv", false)
            l.text = o.optS("text")
            val ip = o.optS("imagePath")
            l.imagePath = if (ip.isEmpty()) null else ip
            l.shape = runCatching { ShapeKind.valueOf(o.optS("shape", "RECT")) }.getOrDefault(ShapeKind.RECT)
            o.optJSONObject("flare")?.let { l.flare = Flare.fromJson(it) }
            l.color = o.optColor("color"); l.color2 = o.optColor("color2")
            l.font = o.optS("font", "sans-serif")
            val fp = o.optS("fontPath")
            l.fontPath = if (fp.isEmpty()) null else fp
            l.bold = o.optB("bold"); l.italic = o.optB("italic")
            l.underline = o.optB("underline"); l.strike = o.optB("strike")
            l.align = o.optI("align", 1); l.caps = o.optI("caps")
            l.spacing = o.optF("spacing")
            l.strokeW = o.optF("strokeW")
            l.strokeColor = o.optColor("strokeColor")
            l.strokePos = o.optI("strokePos"); l.strokeJoin = o.optI("strokeJoin")
            l.stroke2W = o.optF("stroke2W")
            l.stroke2Color = o.optColor("stroke2Color")
            l.borderW = o.optF("borderW")
            l.borderColor = o.optColor("borderColor")
            l.borderFill = o.optColor("borderFill")
            l.gradMode = o.optDouble("gradMode", 0.0).toInt()
            if (o.has("gradX1")) { l.gradX1 = o.optF("gradX1"); l.gradY1 = o.optF("gradY1"); l.gradX2 = o.optF("gradX2"); l.gradY2 = o.optF("gradY2") }
            l.borderPad = o.optF("borderPad")
            l.borderDash = o.optB("borderDash")
            l.shadowOn = o.optB("shadowOn")
            l.shadowColor = o.optColor("shadowColor")
            o.optJSONArray("anims")?.let { aa -> for (i in 0 until aa.length()) aa.optJSONObject(i)?.let { l.anims.add(TextAnim.fromJson(it)) } }
            l.is3d = o.optB("is3d"); l.mblur = o.optB("mblur"); l.precomp = o.optB("precomp", true)
            l.prerender = o.optB("prerender")
            l.mbStutter = o.optB("mbStutter"); l.mbRgb = o.optB("mbRgb")
            l.m3Env = o.optB("m3Env", true); l.m3Metal = o.optB("m3Metal", true); l.m3Ao = o.optB("m3Ao", true)
            l.occlude = o.optB("occlude", true); l.m3View = o.optI("m3View", 0); l.vdbDens = o.optF("vdbDens", 1f); l.vdbBright = o.optF("vdbBright", 1f)
            l.rtOn = o.optB("rtOn", false); l.rtInt = o.optF("rtInt", 1f); l.rtRad = o.optF("rtRad", 0.5f)
            l.vdbEnv = o.optB("vdbEnv", false); l.vdbSurround = o.optB("vdbSurround", false)
            val vep = o.optS("vdbEnvPath", ""); l.vdbEnvPath = if (vep.isEmpty()) null else vep
            l.x3s = o.optS("x3s", "")
            for (kv in o.optS("pbrMaps", "").split('\u0001')) {
                if (kv.isEmpty()) continue
                val p = kv.split('\u0002', limit = 2).filter { it.isNotEmpty() }   // Swift split(maxSplits:1) omits empty parts
                if (p.size == 2) l.pbrMaps[p[0]] = p[1]
            }
            l.tgraph = o.optS("tgraph", "")
            if (o.has("vdbTint")) l.vdbTint = o.optColor("vdbTint")
            o.optJSONArray("fx")?.let { fa -> for (i in 0 until fa.length()) l.fx.add(fa.optS(i)) }
            o.optJSONArray("afx")?.let { aa -> for (i in 0 until aa.length()) aa.optJSONObject(i)?.let { l.afx.add(AudioFxItem.fromJson(it)) } }
            o.optJSONArray("fxOff")?.let { fo -> for (i in 0 until fo.length()) l.fxOff.add(fo.optS(i)) }
            o.optJSONObject("inputs")?.let { io -> for (k in io.keys()) l.inputs[k] = io.optInt(k, 0) }
            o.optJSONObject("props")?.let { po ->
                for (k in po.keys()) po.optJSONObject(k)?.let { to -> val tr = Track(); tr.load(to); l.props[k] = tr }
            }
            o.optJSONObject("puppet")?.let { l.puppet = Puppet.fromJson(it) }
            o.optJSONObject("rig")?.let { l.rig = Rig.fromJson(it) }
            l.deformer = o.optI("deformer", 0)
            o.optJSONObject("warp")?.let { l.warp = Warp.fromJson(it) }
            return l
        }

        val defaults: Map<String, Float> = mapOf(
            "x" to 0f, "y" to 0f, "z" to 0f,
            "scale" to 1f, "scaleX" to 1f, "scaleY" to 1f, "scaleZ" to 1f,
            "rotX" to 0f, "rotY" to 0f, "rotZ" to 0f,
            "anchorX" to 50f, "anchorY" to 50f, "anchorZ" to 0f, "opacity" to 1f,
            "volume" to 1f, "fov" to 55f,
            "mbSamples" to 8f, "mbAmount" to 1f,
            "remapSpeed" to 1f, "remapInterp" to 0f,
            "shapeRound" to 0.12f, "shapeThick" to 0.3f)
    }
}

/** Global 3D render settings (UserDefaults "r3d.<k>") -> SharedPreferences. */
object R3D {
    private fun sp() = Paths.appContext.getSharedPreferences("saiki_defaults", android.content.Context.MODE_PRIVATE)
    fun g(k: String, d: Float): Float { val s = sp(); return if (!s.contains("r3d.$k")) d else s.getFloat("r3d.$k", d) }
    fun set(k: String, v: Float) { sp().edit().putFloat("r3d.$k", v).apply() }
}
