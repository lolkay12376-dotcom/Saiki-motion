package com.saiki.motion.core

import kotlin.math.*

// Port of Render/Lights.swift (buffer / tint / direction). Unbuilt/unverified.
object Lights {
    val types = listOf("Point", "Sun", "Spot")
    const val maxLights = 8

    private fun raw(kelvin: Float): FloatArray {
        val t = max(1000f, min(kelvin, 15000f)) / 100f
        val r: Float = if (t <= 66f) 255f else 329.698727446f * (t - 60f).toDouble().pow(-0.1332047592).toFloat()
        val g: Float = if (t <= 66f) 99.4708025861f * ln(t.toDouble()).toFloat() - 161.1195681661f else 288.1221695283f * (t - 60f).toDouble().pow(-0.0755148492).toFloat()
        val b: Float = if (t >= 66f) 255f else if (t <= 19f) 0f else 138.5177312231f * ln((t - 10f).toDouble()).toFloat() - 305.0447927307f
        return floatArrayOf(min(max(r, 0f), 255f) / 255f, min(max(g, 0f), 255f) / 255f, min(max(b, 0f), 255f) / 255f)
    }
    /** Black-body colour, normalised so 6500 K is neutral white. */
    fun kelvin(k: Float): FloatArray { val c = raw(k); val w = raw(6500f); return floatArrayOf(c[0] / max(w[0], 1e-3f), c[1] / max(w[1], 1e-3f), c[2] / max(w[2], 1e-3f)) }
    fun tint(L: Layer): FloatArray {
        val c = L.vdbTint; val tc = kelvin(L.xf("lightTemp", 6500f))
        return floatArrayOf(((c ushr 16) and 255) / 255f * tc[0], ((c ushr 8) and 255) / 255f * tc[1], (c and 255) / 255f * tc[2])
    }
    fun infinite(L: Layer): Boolean = L.xf("lightInf", 1f) > 0.5f
    fun direction(l: Layer): FloatArray {
        val p = l.xf("lightPitch", -60f) * Math.PI.toFloat() / 180f; val y = l.xf("lightYaw", 30f) * Math.PI.toFloat() / 180f
        val x = cos(p) * sin(y); val yy = sin(p); val z = -cos(p) * cos(y)
        val n = sqrt(x * x + yy * yy + z * z)
        return floatArrayOf(x / n, yy / n, z / n)
    }
    fun stop(L: Layer, key: String, def: Float): FloatArray {
        val c = max(0f, min(L.xf(key, def), 16777215f)).toLong().toInt()
        val tc = kelvin(L.xf("lightTemp", 6500f)); val k = L.xf("lightInt", 1f)
        return floatArrayOf(((c ushr 16) and 255) / 255f * tc[0] * k, ((c ushr 8) and 255) / 255f * tc[1] * k, (c and 255) / 255f * tc[2] * k)
    }

    /** Up to 8 lights, 8 float4 each (layout documented in Lights.swift). Returns (flat 64*4 floats, count). */
    fun buffer(time: Float): Pair<FloatArray, Int> {
        val out = FloatArray(maxLights * 8 * 4); var n = 0
        fun set(slot: Int, a: Float, b: Float, c: Float, d: Float) { val o = (n * 8 + slot) * 4; out[o] = a; out[o + 1] = b; out[o + 2] = c; out[o + 3] = d }
        for (L in Editor.scene.layers) {
            if (!(L.isLight && L.visible && time >= L.start && time <= L.end && n < maxLights)) continue
            val lt = L.editTime("x", time); val c = L.vdbTint; val k = L.xf("lightInt", 1f)
            val tc = kelvin(L.xf("lightTemp", 6500f))
            val cr = ((c ushr 16) and 255) / 255f * tc[0] * k; val cg = ((c ushr 8) and 255) / 255f * tc[1] * k; val cb = (c and 255) / 255f * tc[2] * k
            val type = L.xf("lightType", 0f).toInt().toFloat()
            val outer = max(5f, min(L.xf("lightCone", 45f), 89f)) * Math.PI.toFloat() / 180f
            val soft = max(0f, min(L.xf("lightSoft", 0.3f), 1f)); val inner = outer * (1 - soft)
            val d = direction(L)
            set(0, L.p("x", lt), L.p("y", lt), Xf.worldZ(L, time), type)
            set(1, cr, cg, cb, if (infinite(L)) -1f else max(L.xf("lightRange", 0f), 0f))
            set(2, d[0], d[1], d[2], cos(outer))
            set(3, cos(inner), L.xf("lightDiff", 1f), L.xf("lightSpec", 1f), 1f)
            val nc = max(1, min(L.xf("lightCols", 1f).toInt(), 3))
            val c2 = stop(L, "lightC2", 4033535f); val c3 = stop(L, "lightC3", 16731040f)
            set(4, c2[0], c2[1], c2[2], nc.toFloat()); set(5, c3[0], c3[1], c3[2], 0f)
            set(6, L.xf("lightGradMode", 0f), max(L.xf("lightGradSpan", 4f), 0.05f), max(L.xf("lightRad", 0.5f), 0f) * max(L.xf("lightShadowSoft", 1f), 0f), 0f)
            n++
        }
        return Pair(out, n)
    }
}
