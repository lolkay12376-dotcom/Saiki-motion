package com.saiki.motion.core

import com.saiki.motion.render.SceneRendererN
import java.io.File
import kotlin.math.max
import kotlin.math.min

// Port of Sources/Effects/LookLut.swift — .cube 3D LUT store for the MB Looks effect.
// Imported files live in <filesDir>/SaikiMotion/Luts (Paths.root/Luts; iOS Documents/Luts).
// A LUT parses into an RGBA8 "strip" texture (size*size wide, size tall; x = blue*size + red, row = size-1-green).
class LookLut private constructor() {
    private val cache = HashMap<String, Pair<Long, Int>>()
    private val lock = Object()

    companion object {
        val shared = LookLut()

        val dir: File
            get() = File(Paths.root, "Luts").apply { mkdirs() }

        /** (size, RGBA8 strip bytes) of a .cube text; null when it is not a valid 3D cube. */
        fun parse(txt: String): Pair<Int, ByteArray>? {
            var n = 0
            val vals = ArrayList<Float>()
            var dmin = 0f; var dmax = 1f
            for (sub in txt.split('\n', '\r')) {
                val line = sub.trim()
                if (line.isEmpty() || line.startsWith("#")) continue
                val p = line.split(' ', '\t').filter { it.isNotEmpty() }
                val a = p.getOrNull(0)?.toFloatOrNull()
                val b = p.getOrNull(1)?.toFloatOrNull()
                val c = p.getOrNull(2)?.toFloatOrNull()
                if (p.size >= 3 && a != null && b != null && c != null) {
                    vals.add(a); vals.add(b); vals.add(c); continue
                }
                when (p.getOrNull(0)) {
                    "LUT_3D_SIZE" -> p.getOrNull(1)?.toIntOrNull()?.let { n = it }
                    "LUT_1D_SIZE" -> return null
                    "DOMAIN_MIN" -> p.getOrNull(1)?.toFloatOrNull()?.let { dmin = it }
                    "DOMAIN_MAX" -> p.getOrNull(1)?.toFloatOrNull()?.let { dmax = it }
                }
            }
            if (n < 2 || n > 65 || vals.size < n * n * n * 3) return null
            val px = ByteArray(n * n * n * 4) { 255.toByte() }
            val span = max(dmax - dmin, 0.0001f)
            for (i in 0 until n * n * n) {
                val r = i % n; val g = (i / n) % n; val b = i / (n * n)
                val o = ((n - 1 - g) * n * n + b * n + r) * 4
                for (k in 0 until 3) {
                    val v = (vals[i * 3 + k] - dmin) / span
                    px[o + k] = max(0, min(255, (v * 255 + 0.5f).toInt())).toByte()
                }
            }
            return Pair(n, px)
        }
    }

    /** Names of every imported .cube file. */
    fun names(): List<String> =
        dir.listFiles()?.filter { it.name.lowercase().endsWith(".cube") }?.map { it.name }?.sorted() ?: emptyList()

    /** Copies a picked .cube into the Luts dir. Returns the stored name, or null when not a valid 3D cube. */
    fun importFile(src: File, displayName: String?): String? {
        val txt = try { src.readText() } catch (_: Exception) { return null }
        if (parse(txt) == null) return null
        var name = displayName ?: src.name
        if (!name.lowercase().endsWith(".cube")) name += ".cube"
        val dst = File(dir, name)
        try { dst.writeText(txt) } catch (_: Exception) { return null }
        synchronized(lock) { cache.remove(name) }
        return name
    }

    /** The strip texture of an imported LUT (cached) and its cube size. */
    fun texture(name: String): Pair<Long, Int>? {
        synchronized(lock) {
            cache[name]?.let { return it }
            val txt = try { File(dir, name).readText() } catch (_: Exception) { return null }
            val r = parse(txt) ?: return null
            val n = r.first
            // Vulkan strip: rows flipped for the negative-height viewport (y-up), like the GL lutTexture.
            val rowB = n * n * 4
            val data = ByteArray(r.second.size)
            for (row in 0 until n) {
                System.arraycopy(r.second, (n - 1 - row) * rowB, data, row * rowB, rowB)
            }
            val tex = SceneRendererN.texCreate(n * n, n, data)
            if (tex == 0L) return null
            cache[name] = tex to n
            return tex to n
        }
    }
}
