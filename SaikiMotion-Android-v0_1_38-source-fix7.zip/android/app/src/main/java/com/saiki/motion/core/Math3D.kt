package com.saiki.motion.core

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

// Minimal simd replacement for the 3D slices: SIMD3<Float>, SIMD4<Float>, simd_quatf, simd_float4x4 (column-major).

class V3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: V3) = V3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: V3) = V3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = V3(x * s, y * s, z * s)
    operator fun div(s: Float) = V3(x / s, y / s, z / s)
    operator fun unaryMinus() = V3(-x, -y, -z)
    companion object { val ZERO = V3(0f, 0f, 0f) }
}
fun dot(a: V3, b: V3): Float = a.x * b.x + a.y * b.y + a.z * b.z
fun cross(a: V3, b: V3): V3 = V3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x)
fun length(a: V3): Float = sqrt(dot(a, a))
fun normalize(a: V3): V3 = a / length(a)

class V4(val x: Float, val y: Float, val z: Float, val w: Float) {
    operator fun plus(o: V4) = V4(x + o.x, y + o.y, z + o.z, w + o.w)
    operator fun minus(o: V4) = V4(x - o.x, y - o.y, z - o.z, w - o.w)
    operator fun times(s: Float) = V4(x * s, y * s, z * s, w * s)
    fun xyz() = V3(x, y, z)
    operator fun get(i: Int): Float = when (i) { 0 -> x; 1 -> y; 2 -> z; else -> w }
}

class Quat(val x: Float, val y: Float, val z: Float, val w: Float) {
    operator fun times(o: Quat) = Quat(
        w * o.x + x * o.w + y * o.z - z * o.y,
        w * o.y - x * o.z + y * o.w + z * o.x,
        w * o.z + x * o.y - y * o.x + z * o.w,
        w * o.w - x * o.x - y * o.y - z * o.z)
    fun inverse(): Quat { val l2 = x * x + y * y + z * z + w * w; return Quat(-x / l2, -y / l2, -z / l2, w / l2) }
    fun normalized(): Quat { val l = sqrt(x * x + y * y + z * z + w * w); return Quat(x / l, y / l, z / l, w / l) }
    /** Rotates a vector. */
    fun act(v: V3): V3 {
        val q = V3(x, y, z)
        val t = cross(q, v) * 2f
        return v + t * w + cross(q, t)
    }
    companion object {
        val IDENTITY get() = Quat(0f, 0f, 0f, 1f)
        /** simd_quatf(angle:axis:) */
        fun angleAxis(angle: Float, axis: V3): Quat { val a = normalize(axis); val s = sin(angle * 0.5f); return Quat(a.x * s, a.y * s, a.z * s, cos(angle * 0.5f)) }
        /** simd_quatf(from:to:) for unit vectors. */
        fun fromTo(a: V3, b: V3): Quat {
            val d = dot(a, b)
            if (d > 0.999999f) return IDENTITY
            if (d < -0.999999f) {
                var ax = cross(V3(1f, 0f, 0f), a)
                if (length(ax) < 1e-4f) ax = cross(V3(0f, 1f, 0f), a)
                val n = normalize(ax); return Quat(n.x, n.y, n.z, 0f)
            }
            val c = cross(a, b)
            return Quat(c.x, c.y, c.z, 1 + d).normalized()
        }
        /** simd_quatf(simd_float3x3(columns: (c0, c1, c2))) */
        fun fromColumns(c0: V3, c1: V3, c2: V3): Quat {
            val m00 = c0.x; val m10 = c0.y; val m20 = c0.z
            val m01 = c1.x; val m11 = c1.y; val m21 = c1.z
            val m02 = c2.x; val m12 = c2.y; val m22 = c2.z
            val tr = m00 + m11 + m22
            return if (tr > 0f) {
                val s = sqrt(tr + 1f) * 2f
                Quat((m21 - m12) / s, (m02 - m20) / s, (m10 - m01) / s, 0.25f * s)
            } else if (m00 > m11 && m00 > m22) {
                val s = sqrt(1f + m00 - m11 - m22) * 2f
                Quat(0.25f * s, (m01 + m10) / s, (m02 + m20) / s, (m21 - m12) / s)
            } else if (m11 > m22) {
                val s = sqrt(1f + m11 - m00 - m22) * 2f
                Quat((m01 + m10) / s, 0.25f * s, (m12 + m21) / s, (m02 - m20) / s)
            } else {
                val s = sqrt(1f + m22 - m00 - m11) * 2f
                Quat((m02 + m20) / s, (m12 + m21) / s, 0.25f * s, (m10 - m01) / s)
            }
        }
    }
}

/** simd_float4x4, column-major: m[c * 4 + r]. */
class M4(val m: FloatArray = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)) {
    fun col(c: Int) = V4(m[c * 4], m[c * 4 + 1], m[c * 4 + 2], m[c * 4 + 3])
    fun setCol(c: Int, v: V4) { m[c * 4] = v.x; m[c * 4 + 1] = v.y; m[c * 4 + 2] = v.z; m[c * 4 + 3] = v.w }
    fun copy() = M4(m.copyOf())

    operator fun times(o: M4): M4 {
        val r = FloatArray(16)
        for (c in 0 until 4) for (row in 0 until 4) {
            var s = 0f
            for (k in 0 until 4) s += m[k * 4 + row] * o.m[c * 4 + k]
            r[c * 4 + row] = s
        }
        return M4(r)
    }
    operator fun times(v: V4): V4 {
        val o = FloatArray(4)
        for (row in 0 until 4) o[row] = m[row] * v.x + m[4 + row] * v.y + m[8 + row] * v.z + m[12 + row] * v.w
        return V4(o[0], o[1], o[2], o[3])
    }

    fun inverse(): M4 {
        val a = m; val inv = FloatArray(16)
        inv[0] = a[5] * a[10] * a[15] - a[5] * a[11] * a[14] - a[9] * a[6] * a[15] + a[9] * a[7] * a[14] + a[13] * a[6] * a[11] - a[13] * a[7] * a[10]
        inv[4] = -a[4] * a[10] * a[15] + a[4] * a[11] * a[14] + a[8] * a[6] * a[15] - a[8] * a[7] * a[14] - a[12] * a[6] * a[11] + a[12] * a[7] * a[10]
        inv[8] = a[4] * a[9] * a[15] - a[4] * a[11] * a[13] - a[8] * a[5] * a[15] + a[8] * a[7] * a[13] + a[12] * a[5] * a[11] - a[12] * a[7] * a[9]
        inv[12] = -a[4] * a[9] * a[14] + a[4] * a[10] * a[13] + a[8] * a[5] * a[14] - a[8] * a[6] * a[13] - a[12] * a[5] * a[10] + a[12] * a[6] * a[9]
        inv[1] = -a[1] * a[10] * a[15] + a[1] * a[11] * a[14] + a[9] * a[2] * a[15] - a[9] * a[3] * a[14] - a[13] * a[2] * a[11] + a[13] * a[3] * a[10]
        inv[5] = a[0] * a[10] * a[15] - a[0] * a[11] * a[14] - a[8] * a[2] * a[15] + a[8] * a[3] * a[14] + a[12] * a[2] * a[11] - a[12] * a[3] * a[10]
        inv[9] = -a[0] * a[9] * a[15] + a[0] * a[11] * a[13] + a[8] * a[1] * a[15] - a[8] * a[3] * a[13] - a[12] * a[1] * a[11] + a[12] * a[3] * a[9]
        inv[13] = a[0] * a[9] * a[14] - a[0] * a[10] * a[13] - a[8] * a[1] * a[14] + a[8] * a[2] * a[13] + a[12] * a[1] * a[10] - a[12] * a[2] * a[9]
        inv[2] = a[1] * a[6] * a[15] - a[1] * a[7] * a[14] - a[5] * a[2] * a[15] + a[5] * a[3] * a[14] + a[13] * a[2] * a[7] - a[13] * a[3] * a[6]
        inv[6] = -a[0] * a[6] * a[15] + a[0] * a[7] * a[14] + a[4] * a[2] * a[15] - a[4] * a[3] * a[14] - a[12] * a[2] * a[7] + a[12] * a[3] * a[6]
        inv[10] = a[0] * a[5] * a[15] - a[0] * a[7] * a[13] - a[4] * a[1] * a[15] + a[4] * a[3] * a[13] + a[12] * a[1] * a[7] - a[12] * a[3] * a[5]
        inv[14] = -a[0] * a[5] * a[14] + a[0] * a[6] * a[13] + a[4] * a[1] * a[14] - a[4] * a[2] * a[13] - a[12] * a[1] * a[6] + a[12] * a[2] * a[5]
        inv[3] = -a[1] * a[6] * a[11] + a[1] * a[7] * a[10] + a[5] * a[2] * a[11] - a[5] * a[3] * a[10] - a[9] * a[2] * a[7] + a[9] * a[3] * a[6]
        inv[7] = a[0] * a[6] * a[11] - a[0] * a[7] * a[10] - a[4] * a[2] * a[11] + a[4] * a[3] * a[10] + a[8] * a[2] * a[7] - a[8] * a[3] * a[6]
        inv[11] = -a[0] * a[5] * a[11] + a[0] * a[7] * a[9] + a[4] * a[1] * a[11] - a[4] * a[3] * a[9] - a[8] * a[1] * a[7] + a[8] * a[3] * a[5]
        inv[15] = a[0] * a[5] * a[10] - a[0] * a[6] * a[9] - a[4] * a[1] * a[10] + a[4] * a[2] * a[9] + a[8] * a[1] * a[6] - a[8] * a[2] * a[5]
        val det = a[0] * inv[0] + a[1] * inv[4] + a[2] * inv[8] + a[3] * inv[12]
        val id = 1f / det
        for (i in 0 until 16) inv[i] *= id
        return M4(inv)
    }

    companion object {
        fun identity() = M4()
        /** simd_float4x4(simd_quatf) (unit quaternion). */
        fun fromQuat(q: Quat): M4 {
            val x = q.x; val y = q.y; val z = q.z; val w = q.w
            val r = M4()
            r.setCol(0, V4(1 - 2 * (y * y + z * z), 2 * (x * y + z * w), 2 * (x * z - y * w), 0f))
            r.setCol(1, V4(2 * (x * y - z * w), 1 - 2 * (x * x + z * z), 2 * (y * z + x * w), 0f))
            r.setCol(2, V4(2 * (x * z + y * w), 2 * (y * z - x * w), 1 - 2 * (x * x + y * y), 0f))
            return r
        }
    }
}
