package com.saiki.motion.core

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

// Port of Render/MetalCamera.swift (MetalCam). Column-major 4x4 as FloatArray(16), identical maths.

object MetalCam {
    private const val PI = Math.PI.toFloat()

    fun vp(l: Layer, time: Float, width: Int, height: Int): FloatArray? {
        val ar = width.toFloat() / max(height, 1).toFloat()
        val e = SceneRenderer.editCam
        if (e != null) return lookAt(e[0], ar, e[1], e[2], e[3], e[4] * PI / 180f, e[5] * PI / 180f, 0f)
        val cam = Xf.camera(l) ?: return null
        return vpCamera(cam, time, width, height)
    }

    /** vp(camera:time:width:height:) */
    fun vpCamera(cam: Layer, time: Float, width: Int, height: Int): FloatArray {
        val ar = width.toFloat() / max(height, 1).toFloat()
        val ct = cam.editTime("x", time)
        var fov = cam.p("fov", ct)
        if (!fov.isFinite() || fov < 10f) fov = 55f
        fov = min(fov, 150f)
        val neutral = 1f / tan(fov * PI / 360f)
        val ex = cam.p("x", ct); val ey = cam.p("y", ct); val ez = cam.p("z", ct) + neutral
        val rx = cam.p("rotX", ct) * PI / 180f
        val ry = cam.p("rotY", ct) * PI / 180f
        val rz = cam.p("rotZ", ct) * PI / 180f
        if (cam.parentId >= 0) {
            val w = parentedWorld(cam, ct, ex, ey, ez, rx, ry, rz)
            if (w != null) return viewProj(fov, ar, w)
        }
        return lookAt(fov, ar, ex, ey, ez, rx, ry, rz)
    }

    private fun parentedWorld(cam: Layer, t: Float, ex: Float, ey: Float, ez: Float, rx: Float, ry: Float, rz: Float): FloatArray? {
        val chain = ArrayList<Layer>()
        var cur = cam
        while (cur.parentId >= 0 && chain.size < 16) {
            val pid = cur.parentId
            val par = Editor.scene.layers.firstOrNull { it.id == pid } ?: break
            if (Xf.isFlatScope(par)) break      // a flat group is a 2D pre-comp: it doesn't move its camera
            chain.add(par); cur = par
        }
        if (chain.isEmpty()) return null
        var w = mul(rotY(ry), mul(rotX(rx), rotZ(rz)))
        w[12] = ex; w[13] = ey; w[14] = ez
        for (par in chain) {
            val pt = par.editTime("x", t)
            var s = par.p("scale", pt)
            if (!s.isFinite() || s < 1e-4f) s = 1f
            val m = mul(rotZ(par.p("rotZ", pt) * PI / 180f),
                mul(rotX(par.p("rotX", pt) * PI / 180f), rotY(par.p("rotY", pt) * PI / 180f)))
            for (i in 0 until 3) { m[i] *= s; m[4 + i] *= s; m[8 + i] *= s }
            m[12] = par.p("x", pt); m[13] = par.p("y", pt); m[14] = par.p("z", pt)
            w = mul(m, w)
        }
        return w
    }

    private fun viewProj(fovDeg: Float, ar: Float, w: FloatArray): FloatArray {
        val r = w.copyOf()
        for (c in 0 until 3) {
            val l = max(sqrt(w[c * 4] * w[c * 4] + w[c * 4 + 1] * w[c * 4 + 1] + w[c * 4 + 2] * w[c * 4 + 2]), 1e-6f)
            r[c * 4] /= l; r[c * 4 + 1] /= l; r[c * 4 + 2] /= l
        }
        val v = ident()
        for (rr in 0 until 3) for (c in 0 until 3) v[c * 4 + rr] = r[rr * 4 + c]      // transpose
        for (rr in 0 until 3) v[12 + rr] = -(v[rr] * w[12] + v[4 + rr] * w[13] + v[8 + rr] * w[14])
        val f = 1f / tan(fovDeg * PI / 360f)
        val near = 0.05f; val far = 10000f
        val nf = 1f / (near - far)
        val p = ident()
        p[0] = f / ar; p[5] = f; p[10] = (far + near) * nf; p[11] = -1f; p[14] = 2f * far * near * nf; p[15] = 0f
        return mul(p, v)
    }

    /** Set by the 3D editor while it renders volumes with its orbit camera. */
    @JvmField var vpOverride: FloatArray? = null

    fun vpForModel(l: Layer, fov: Float, time: Float, width: Int, height: Int): FloatArray {
        vpOverride?.let { return it }
        vp(l, time, width, height)?.let { return it }
        val ar = width.toFloat() / max(height, 1).toFloat()
        return lookAt(fov, ar, 0f, 0f, 3f, 0f, 0f, 0f)
    }

    fun modelMatrix(l: Layer, time: Float, norm: FloatArray): FloatArray {
        val lt = l.editTime("x", time)
        val s = l.p("scale", lt)
        val x = l.p("x", lt); val y = l.p("y", lt)
        val z = Xf.worldZ(l, time)
        val rx = l.p("rotX", lt) * PI / 180f
        val ry = l.p("rotY", lt) * PI / 180f
        val rz = l.p("rotZ", lt) * PI / 180f
        val sc = s * norm[0]
        val sz = l.p("scaleZ", lt)
        var m = ident()
        m = mul(rotY(ry), m)
        m = mul(rotX(rx), m)
        m = mul(rotZ(rz), m)
        m = mul(m, floatArrayOf(sc, 0f, 0f, 0f, 0f, sc, 0f, 0f, 0f, 0f, sc * sz, 0f, 0f, 0f, 0f, 1f))   // R · S so the depth scale follows the model
        val ox = norm[1]; val oy = norm[2]; val oz = norm[3]
        m[12] = x + m[0] * ox + m[4] * oy + m[8] * oz
        m[13] = y + m[1] * ox + m[5] * oy + m[9] * oz
        m[14] = z + m[2] * ox + m[6] * oy + m[10] * oz
        val pz = l.p("anchorZ", lt) / 100f / max(norm[0], 1e-6f)        // 3D anchor: pivot moved along local Z
        m[12] -= m[8] * pz; m[13] -= m[9] * pz; m[14] -= m[10] * pz
        return m
    }

    fun lookAtEye(fovDeg: Float, ar: Float, ex: Float, ey: Float, ez: Float, rx: Float, ry: Float, rz: Float): FloatArray {
        var v = ident()
        v = mul(rotY(-ry), v); v = mul(rotX(-rx), v); v = mul(rotZ(-rz), v)
        val tx = -(v[0] * ex + v[4] * ey + v[8] * ez)
        val ty = -(v[1] * ex + v[5] * ey + v[9] * ez)
        val tz = -(v[2] * ex + v[6] * ey + v[10] * ez)
        return lookAt(fovDeg, ar, -tx, -ty, -tz, rx, ry, rz)
    }

    fun lookAt(fovDeg: Float, ar: Float, ex: Float, ey: Float, ez: Float, rx: Float, ry: Float, rz: Float): FloatArray {
        val f = 1f / tan(fovDeg * PI / 360f)
        val near = 0.05f; val far = 10000f
        val nf = 1f / (near - far)
        val p = ident()
        p[0] = f / ar
        p[5] = f
        p[10] = (far + near) * nf
        p[11] = -1f
        p[14] = 2f * far * near * nf
        p[15] = 0f
        var v = ident()
        v = mul(rotY(-ry), v)
        v = mul(rotX(-rx), v)
        v = mul(rotZ(-rz), v)
        v[12] = -ex; v[13] = -ey; v[14] = -ez
        return mul(p, v)
    }

    private fun ident() = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
    private fun rotX(a: Float): FloatArray { val c = cos(a); val s = sin(a); return floatArrayOf(1f, 0f, 0f, 0f, 0f, c, s, 0f, 0f, -s, c, 0f, 0f, 0f, 0f, 1f) }
    private fun rotY(a: Float): FloatArray { val c = cos(a); val s = sin(a); return floatArrayOf(c, 0f, -s, 0f, 0f, 1f, 0f, 0f, s, 0f, c, 0f, 0f, 0f, 0f, 1f) }
    private fun rotZ(a: Float): FloatArray { val c = cos(a); val s = sin(a); return floatArrayOf(c, s, 0f, 0f, -s, c, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f) }
    /** a * b (column-major). */
    private fun mul(a: FloatArray, b: FloatArray): FloatArray {
        val o = FloatArray(16)
        for (c in 0 until 4) for (r in 0 until 4) {
            var s = 0f
            for (k in 0 until 4) s += a[k * 4 + r] * b[c * 4 + k]
            o[c * 4 + r] = s
        }
        return o
    }
}
