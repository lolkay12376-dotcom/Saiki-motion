package com.saiki.motion.core

import com.saiki.motion.render.SceneRendererN
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

// Port of Sources/Render/MetalFlare.swift MetalFlareRenderer. Shader: shared/shaders/glsl/flare.frag
// (dep b0, FlareArr b1 112 vec4, FlareLens b2 256 vec4, FlareU b8 6 vec4).
object MetalFlareRenderer {
    private var halfT: MetalTarget? = null
    private var dummyDepthH = 0L

    val ready: Boolean get() = SceneRendererN.pipelineReady("flare.frag")

    fun trimMemory() { halfT?.let { SceneRendererN.targetFree(it.handle) }; halfT = null }

    private fun projectPoint(vp: FloatArray, x: Float, y: Float, z: Float): Triple<Float, Float, Float> {
        val cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12]
        val cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13]
        val cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
        return Triple(cx / max(abs(cw), 0.0001f), cy / max(abs(cw), 0.0001f), cw)
    }

    private fun rgb(c: Int): FloatArray =
        floatArrayOf(((c ushr 16) and 0xFF) / 255f, ((c ushr 8) and 0xFF) / 255f, (c and 0xFF) / 255f, 1f)

    /** Draws flare layer `l` into `a` (the caller has cleared it). depth = native DepthTex* or 0. */
    fun draw(l: Layer, time: Float, fov: Float, isExport: Boolean, depth: Long, a: MetalTarget) {
        if (!ready) return
        val f = l.flare ?: return
        val tw = a.width; val th = a.height
        val ar = tw.toFloat() / max(th, 1).toFloat()
        val lt = l.editTime("x", time)
        var wx = l.p("x", lt); var wy = l.p("y", lt)
        var visible = 1f
        var sizeMul = 1f
        var lightZ = 1f
        var occlOK = false
        if (l.is3d) {
            // real 3D light: projected through the camera; grows/shrinks with distance, hidden behind it
            val z = Xf.worldZ(l, time)
            val vp = MetalCam.vpForModel(l, fov, time, tw, th)
            if (vp.size != 16) return
            val (nx, ny, pw) = projectPoint(vp, wx, wy, z)
            val cz = vp[2] * wx + vp[6] * wy + vp[10] * z + vp[14]
            lightZ = (cz / max(abs(pw), 0.0001f)) * 0.5f + 0.5f
            occlOK = pw > 0.01f
            val pw0 = projectPoint(vp, 0f, 0f, 0f).third
            if (pw <= 0.01f) visible = 0f
            sizeMul = 1 + (min(max(pw0 / max(pw, 0.01f), 0.15f), 6f) - 1f) * f.depthScale
            wx = nx * ar; wy = ny
        } else if (l.parentId >= 0) {
            val m = Xf.matrix(l, time)
            wx = m[4]; wy = m[5]
        }
        val lightX = wx / ar / 2 + 0.5f       // 0..1 across the canvas
        val lightY = 0.5f - wy / 2
        val intensity = l.p("fIntensity", lt) * visible
        val axis = l.p("fAxis", lt)
        if (intensity <= 0.0005f) return          // invisible (behind the camera / zero): skip the heavy shader
        val n = min(f.els.size, min(FlareEl.MAX, 16))
        // FlareU (6 vec4)
        val u = FloatArray(24)
        u[0] = lightX; u[1] = lightY; u[2] = intensity; u[3] = axis
        u[4] = sizeMul; u[5] = f.edgeFade; u[6] = ar; u[7] = n.toFloat()
        u[8] = time; u[9] = f.flicker; u[10] = f.speed; u[11] = f.rayAmt
        System.arraycopy(rgb(f.tint), 0, u, 12, 4)
        u[16] = f.realism; u[17] = f.veil; u[18] = f.dust; u[19] = f.occlusion
        val useDepth = l.is3d && occlOK && depth != 0L
        u[20] = f.occlSoft; u[21] = lightZ; u[22] = if (useDepth) 1f else 0f; u[23] = 0f
        // element array (112 vec4)
        val arr = FloatArray(112 * 4)
        for (i in 0 until 16) {
            if (i >= n) { arr[i * 4] = -1f; continue }
            val e = f.els[i]
            fun slot(base: Int, off: Int, v: Float) { arr[(base + i) * 4 + off] = v }
            slot(0, 0, if (e.enabled) e.type.toFloat() else -1f); slot(0, 1, e.pos); slot(0, 2, e.size); slot(0, 3, e.rot)
            slot(16, 0, e.bright); slot(16, 1, e.soft); slot(16, 2, e.thick); slot(16, 3, max(e.stretch, 0.05f))
            slot(32, 0, e.sides.toFloat()); slot(32, 1, e.rays.toFloat()); slot(32, 2, e.chroma); slot(32, 3, if (e.follow) 1f else 0f)
            slot(48, 0, e.round); slot(48, 1, e.star); slot(48, 2, e.curve); slot(48, 3, e.grad)
            slot(64, 0, e.noise); slot(64, 1, e.spin); slot(64, 2, i * 7.31f + 1.7f); slot(64, 3, e.spread)
            System.arraycopy(rgb(e.color), 0, arr, (80 + i) * 4, 4)
            slot(96, 0, e.gain); slot(96, 1, e.off)
        }
        // per-lens data for lens stacks: 16 elements x 8 lenses x 2 float4 (256 vec4)
        val lensArr = FloatArray(256 * 4)
        for (i in 0 until n) {
            if (f.els[i].type != 16) continue
            val ls = if (f.els[i].lenses.isEmpty()) LensDef.defaultStack() else f.els[i].lenses
            for (k in 0 until min(8, ls.size)) {
                val d = ls[k]; val c = rgb(d.color)
                lensArr[(i * 8 + k) * 8 + 0] = d.kind.toFloat()
                lensArr[(i * 8 + k) * 8 + 1] = d.size
                lensArr[(i * 8 + k) * 8 + 2] = d.bright
                lensArr[(i * 8 + k) * 8 + 3] = d.offset
                System.arraycopy(c, 0, lensArr, (i * 8 + k) * 8 + 4, 4)
                lensArr[(i * 8 + k) * 8 + 7] = d.rot
            }
        }
        val depthH = if (useDepth) depth else {
            if (dummyDepthH == 0L) dummyDepthH = SceneRendererN.depthCreate1()
            dummyDepthH
        }
        fun run(tgt: MetalTarget) {
            SceneRendererN.flarePass(tgt.handle, u, arr, lensArr, depthH)
        }
        if (!isExport && tw >= 64) {
            // Preview: flares are smooth light, so shade them at half resolution and upsample.
            val ht = halfT
            if (ht == null || ht.width != tw / 2 || ht.height != th / 2) {
                ht?.let { SceneRendererN.targetFree(it.handle) }
                halfT = MetalTarget(SceneRendererN.targetCreate(tw / 2, th / 2, false), tw / 2, th / 2, false)
            }
            val ft = halfT
            if (ft != null) {
                run(ft)
                SceneRendererN.blit(SceneRendererN.targetTex(ft.handle), a.handle)
                return
            }
        }
        run(a)
    }
}
