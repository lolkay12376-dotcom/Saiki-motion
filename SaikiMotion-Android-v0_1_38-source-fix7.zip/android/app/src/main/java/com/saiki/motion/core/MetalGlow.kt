package com.saiki.motion.core

import com.saiki.motion.render.SceneRendererN

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

// Port of Sources/Render/MetalGlow.swift (Deep Glow). The GLSL twins are shared/shaders/glsl/glow*.frag
// (glowExtract/glowDown/glowBlur/glowScale/glowUp/glowFinal); the pass encoding runs through
// SceneRendererN.encodeGlowPass which binds UBO b8 + textures b0/b1 like encodeFx.
object MetalGlow {
    const val N = 9

    /** Raw Deep Glow parameters (same meaning as the GL effect's props). */
    class Params {
        var radius: Float = 0.12f; var intensity: Float = 1f; var threshold: Float = 0.3f; var knee: Float = 0.5f
        var falloff: Float = 0.5f; var tintAmt: Float = 0f; var tintHue: Float = 0.08f; var chroma: Float = 0f; var glowOnly: Float = 0f
        /** >1 when the glow input was blurred (motion blur / blur effects dim the bright pass). */
        var blurComp: Float = 1f
        /** On-screen scale of the layer (<1 when pushed back along Z): the glow shrinks with it instead of fading. */
        var zScale: Float = 1f
    }

    private var levelsH = LongArray(N)
    private var tmpH = LongArray(N)
    private var blurH = LongArray(N)
    private var sizeW = 0
    private var sizeH = 0

    val ready: Boolean get() = SceneRendererN.pipelineReady("glowFinal.frag")

    fun trimMemory() {
        for (i in 0 until N) {
            if (levelsH[i] != 0L) SceneRendererN.targetFree(levelsH[i])
            if (tmpH[i] != 0L) SceneRendererN.targetFree(tmpH[i])
            if (blurH[i] != 0L) SceneRendererN.targetFree(blurH[i])
            levelsH[i] = 0L; tmpH[i] = 0L; blurH[i] = 0L
        }
        sizeW = 0; sizeH = 0
    }

    private fun ensure(w: Int, h: Int) {
        if (sizeW == w && sizeH == h && levelsH[0] != 0L) return
        trimMemory()
        for (k in 0 until N) {
            val div = 4 shl k
            val lw = max(2, w / div); val lh = max(2, h / div)
            levelsH[k] = SceneRendererN.targetCreate(lw, lh, true)
            tmpH[k] = SceneRendererN.targetCreate(lw, lh, true)
            blurH[k] = SceneRendererN.targetCreate(lw, lh, true)
        }
        sizeW = w; sizeH = h
    }

    /** Runs Deep Glow: src -> out. Returns false (nothing useful written) when a shader is missing. */
    fun apply(p: Params, src: MetalTarget, out: MetalTarget): Boolean {
        if (!ready) return false
        ensure(out.width, out.height)
        val comp = p.blurComp
        val radius = max(0f, p.radius)
        val intensity = max(0f, p.intensity)
        val thr = min(max(p.threshold, 0f), 0.999f) / comp
        val knee = min(max(p.knee, 0f), 1f)
        val falloff = min(max(p.falloff, 0f), 1f)
        val tintAmt = min(max(p.tintAmt, 0f), 1f)
        val chromaAb = min(max(p.chroma, 0f), 1f)

        // 1) bright pass -> level 0 (half res)
        if (!SceneRendererN.encodeGlowPass("glowExtract.frag", levelsH[0], src.tex, 0L,
                floatArrayOf(1f / out.width, 1f / out.height, thr, knee))) return false

        // level weights follow the radius continuously (log-space gaussian)
        val zs = min(p.zScale, 1.5f)
        val sigmaPx = max(radius * zs, 0.0005f) * out.height * 0.5f
        val pos = min(max((ln(max(sigmaPx, 1f) / 8f) / ln(2f)), 0f), (N - 1).toFloat())
        val w = FloatArray(N)
        for (k in 0 until N) {
            val dk = k - pos
            val sg = 0.55f + falloff * 1.6f
            w[k] = exp(-dk * dk / (2f * sg * sg))
        }
        // energy-normalised level weights (sum = 1)
        var wMax = 0.0001f
        for (k in 0 until N) wMax = max(wMax, w[k])
        for (k in 0 until N) w[k] = w[k] / wMax
        for (k in 1 until N) if (w[k] <= 0.04f) w[k] = 0f
        var wSum = 0f
        for (k in 0 until N) wSum += w[k]
        for (k in 0 until N) w[k] /= max(wSum, 0.0001f)
        var top = 0
        for (k in 0 until N) if (w[k] > 0f) top = k

        // 2) downsample chain
        if (top >= 1) {
            for (k in 1..top) {
                SceneRendererN.encodeGlowPass("glowDown.frag", levelsH[k], SceneRendererN.targetTex(levelsH[k - 1]), 0L,
                    floatArrayOf(1f / SceneRendererN.targetW(levelsH[k - 1]), 1f / SceneRendererN.targetH(levelsH[k - 1])))
            }
        }

        // 3) separable Gaussian on every used level
        for (k in 0..top) {
            if (w[k] > 0f || k == 0) {
                val lw = SceneRendererN.targetW(levelsH[k]); val lh = SceneRendererN.targetH(levelsH[k])
                SceneRendererN.encodeGlowPass("glowBlur.frag", tmpH[k], SceneRendererN.targetTex(levelsH[k]), 0L,
                    floatArrayOf(1f / lw, 0f))
                SceneRendererN.encodeGlowPass("glowBlur.frag", blurH[k], SceneRendererN.targetTex(tmpH[k]), 0L,
                    floatArrayOf(0f, 1f / lh))
            }
        }

        // 4) accumulate from the deepest used level up (results go into tmp[k])
        var acc = -1
        for (k in top downTo 0) {
            if (w[k] > 0f || k == 0) {
                val wk = w[k]
                if (acc < 0) {
                    SceneRendererN.encodeGlowPass("glowScale.frag", tmpH[k], SceneRendererN.targetTex(blurH[k]), 0L,
                        floatArrayOf(wk))
                } else {
                    SceneRendererN.encodeGlowPass("glowUp.frag", tmpH[k], SceneRendererN.targetTex(blurH[k]), SceneRendererN.targetTex(tmpH[acc]),
                        floatArrayOf(wk))
                }
                acc = k
            }
        }

        // 5) final composite
        val hue = p.tintHue - kotlin.math.floor(p.tintHue)
        val tint = hsbToRgb(hue)
        val gain = intensity * 0.55f * (1f + (comp - 1f) * 0.3f) * (1f + max(0f, 1f / max(zs, 0.05f) - 1f) * 0.15f)
        val fu = floatArrayOf(tint[0], tint[1], tint[2], 1f, gain, chromaAb, p.glowOnly, tintAmt,
            out.width.toFloat(), out.height.toFloat(), 0f, 0f)
        return SceneRendererN.encodeGlowFinal(out.handle, src.tex, SceneRendererN.targetTex(tmpH[max(acc, 0)]), fu)
    }

    /** UIColor(hue:saturation:1:brightness:1) -> rgb. */
    private fun hsbToRgb(h: Float): FloatArray {
        val hsv = floatArrayOf((h * 360f) % 360f, 1f, 1f)
        val c = android.graphics.Color.HSVToColor(hsv)
        return floatArrayOf(((c shr 16) and 0xFF) / 255f, ((c shr 8) and 0xFF) / 255f, (c and 0xFF) / 255f)
    }
}
