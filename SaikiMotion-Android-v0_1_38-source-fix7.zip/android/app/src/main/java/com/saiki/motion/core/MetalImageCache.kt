package com.saiki.motion.core

import android.graphics.BitmapFactory
import com.saiki.motion.render.SceneRendererN
import kotlin.math.max

// Port of Sources/Render/MetalScene.swift:290 MetalImageCache — image-layer textures in a byte-budgeted LRU.
// Decoding: BitmapFactory (UIImage(contentsOfFile:)); upload: SceneRendererN.texCreateCapped (MetalImageUpload).
object MetalImageCache {
    private val tex = HashMap<String, Long>()
    private val bytes = HashMap<String, Int>()
    private val order = ArrayList<String>()     // least recently used first
    private var total = 0
    private var side = 0
    const val budget = 360 * 1_048_576

    fun totalBytes(): Int = total

    fun texture(path: String, quality: Int): Long {
        val s = max(384, 1536 / max(1, quality))
        if (s != side) { flush(); side = s }
        tex[path]?.let {
            if (order.lastOrNull() != path) {
                order.remove(path)
                order.add(path)
            }
            return it
        }
        val img = try { BitmapFactory.decodeFile(path) } catch (_: Exception) { null } ?: return 0L
        val t = SceneRendererN.texCreateCapped(img.width, img.height, img, s)
        if (t == 0L) return 0L
        // decoded-size accounting like MetalImageUpload.bytes (w*h*4 with mips)
        var b = 0
        var w = img.width.coerceAtMost(s); var h = img.height.coerceAtMost(s)
        while (w >= 1 && h >= 1) { b += w * h * 4; w /= 2; h /= 2 }
        tex[path] = t
        bytes[path] = b
        total += b
        order.add(path)
        while (total > budget && order.size > 1) {
            val old = order.removeAt(0)
            tex.remove(old)?.let { SceneRendererN.texFree(it) }
            total -= bytes.remove(old) ?: 0
        }
        return t
    }

    fun flush() {
        for (t in tex.values) SceneRendererN.texFree(t)
        tex.clear(); bytes.clear(); order.clear(); total = 0
    }
}
