package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.util.IdentityHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// Port of Render/MetalModel.swift, CPU side (slice 7k): MetalModel prim table, Splat decode, subdivide, loadModel cache,
// point-map collider push-out, ptSurface, scatterWorld/scatterMatrices.
// MetalModel.swift:11-935 MetalModelSL shader sources: shared/shaders/msl/MetalModelSL.source.msl with GLSL twins in
//   shared/shaders/glsl/model.vert|model.frag|model_rt.frag — NativeModel.pso builds the pipelines from those.
// MetalModel.swift:1017-1035,1138-1180,1204-1420,1580-1666 MetalModelRenderer GPU part: ported in MetalModelDraw.kt through
//   NativeModel (pso/modelPass, depthEnsure/depthCopy, buildAccel + VK_KHR_ray_query, draw, occludePlane).
// MetalModel.swift:986-1015 makeTexture mip chain + GPU upload == NativeModel.texCreate (cpp uploadTextureMips); CpuTex holds the
//   already-scaled premultiplied RGBA8 pixels and uploads lazily (MetalModelDraw.gpuTex).
// MetalModel.swift:1573 setVBuf == Prim.vbuf (native Buf*), filled by MetalModelDraw.vbufs.

/** CPU stand-in for an MTLTexture: premultiplied RGBA8, top row first, already scaled to <= 2048. */
class CpuTex(val w: Int, val h: Int, val rgba: ByteArray) {
    /** Native Tex* (cpp/jni_model.cpp texCreate), uploaded lazily by MetalModelRenderer.gpu(); 0 = not uploaded. */
    @JvmField var gpu: Long = 0L
}

class MetalModel private constructor(val src: GlbModel) {
    class P(
        var count: Int, var idx32: Boolean, var points: Boolean, var srcIndex: Int,
        var tex: Array<CpuTex?>,           // base, metal-rough, emissive, occlusion
        var clamp: BooleanArray,
        var norm: CpuTex? = null           // the material's own normal map
    ) {
        @JvmField var vbuf: Long = 0L      // native Buf* (setVBuf)
        @JvmField var ibuf: Long = 0L
    }

    /** native Accel* (ray query), built lazily by MetalModelRenderer.draw; rebuilt every frame for animated models. */
    @JvmField var accel: Long = 0L

    var splat: Splat? = null
    val prims = ArrayList<P>()

    companion object {
        /** MetalModel.init?(src): null when there is nothing drawable. */
        fun create(src: GlbModel): MetalModel? {
            val m = MetalModel(src)
            val texById = HashMap<Int, CpuTex>()
            val used = ArrayList<Int>()
            fun tex(id: Int): Pair<CpuTex?, Boolean> {
                if (id == 0) return Pair(null, false)
                val e = synchronized(GlbModel.cpuImages) { GlbModel.cpuImages[id] } ?: return Pair(null, false)
                used.add(id)
                texById[id]?.let { return Pair(it, e.clamp) }
                val t = makeTexture(e.img) ?: return Pair(null, e.clamp)
                texById[id] = t
                return Pair(t, e.clamp)
            }
            for ((si, sp) in src.prims.withIndex()) {
                if (sp.verts.isEmpty() || sp.cpuIdx.isEmpty()) continue
                val idx32 = !sp.indexIs16
                val t0 = tex(sp.texBase); val t1 = tex(sp.texMR); val t2 = tex(sp.texEm); val t3 = tex(sp.texOcc); val tn = tex(sp.texNormal)
                m.prims.add(P(sp.cpuIdx.size, idx32, sp.mode == GlbModel.GL_POINTS, si,
                    arrayOf(t0.first, t1.first, t2.first, t3.first), booleanArrayOf(t0.second, t1.second, t2.second, t3.second), tn.first))
            }
            synchronized(GlbModel.cpuImages) { for (id in used) GlbModel.cpuImages.remove(id) }   // CPU copies are no longer needed
            if (m.prims.isEmpty()) return null
            return m
        }

        /** RGBA8 premultiplied pixels scaled so the long side is <= 2048 (CGContext .copy draw). Bitmap substitute: scale/premultiply differ slightly. */
        fun makeTexture(image: Bitmap): CpuTex? {
            if (image.width <= 0 || image.height <= 0) return null
            val sc = min(1.0, 2048.0 / max(image.width, image.height).toDouble())
            val w = max(1, (image.width.toDouble() * sc).toInt()); val h = max(1, (image.height.toDouble() * sc).toInt())
            val bmp = if (w == image.width && h == image.height) image else Bitmap.createScaledBitmap(image, w, h, true)
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)      // straight ARGB
            val out = ByteArray(w * h * 4)
            for (i in 0 until w * h) {
                val c = px[i]; val a = (c ushr 24) and 255
                val r = (c ushr 16) and 255; val g = (c ushr 8) and 255; val b = c and 255
                out[i * 4] = ((r * a + 127) / 255).toByte(); out[i * 4 + 1] = ((g * a + 127) / 255).toByte()
                out[i * 4 + 2] = ((b * a + 127) / 255).toByte(); out[i * 4 + 3] = a.toByte()
            }
            return CpuTex(w, h, out)
        }
    }
}

/** Terrain splat extras of a model .glb (MetalModel.swift:1668). tex = 7..10 diffuse, 11..14 normal+ao, 15..18 height/rough/metal, 19..20 weights. */
class Splat {
    var tex: List<CpuTex?> = emptyList()
    val tile = floatArrayOf(1f, 1f, 1f, 1f)
    val str = floatArrayOf(1f, 1f, 1f, 1f)
    var count = 0

    companion object {
        /** `dummy` = the 1x1 white fallback (renderer.dummy; GPU handle lands with the GPU part). */
        fun load(path: String, dummy: CpuTex?): Splat? {
            val f = File(path)
            if (!f.exists() || f.length() <= 28) return null
            val data = try { f.readBytes() } catch (_: Exception) { return null }
            fun u32(o: Int): Int = (data[o].toInt() and 255) or ((data[o + 1].toInt() and 255) shl 8) or ((data[o + 2].toInt() and 255) shl 16) or ((data[o + 3].toInt() and 255) shl 24)
            val jl = u32(12)
            if (jl < 0 || 20 + jl > data.size) return null
            val j = try { JSONObject(String(data, 20, jl, Charsets.UTF_8)) } catch (_: Exception) { return null }
            val sp = j.optJSONObject("asset")?.optJSONObject("extras")?.optJSONObject("splat") ?: return null
            val views = j.optJSONArray("bufferViews") ?: return null
            val layers = sp.optJSONArray("layers") ?: return null
            val bin = 20 + jl + 8
            fun img(i: Any?): CpuTex? {
                val ii = (i as? Int) ?: return null
                if (ii >= views.length()) return null
                val v = views.optJSONObject(ii) ?: return null
                if (!v.has("byteOffset") || !v.has("byteLength")) return null
                val o = v.optInt("byteOffset", 0); val l = v.optInt("byteLength", 0)
                if (bin + o + l > data.size) return null
                val bm = BitmapFactory.decodeByteArray(data, bin + o, l) ?: return null
                return MetalModel.makeTexture(bm)
            }
            val r = Splat()
            val d = ArrayList<CpuTex?>(); val n = ArrayList<CpuTex?>(); val h = ArrayList<CpuTex?>()
            for (k in 0 until 4) {
                if (k < layers.length()) {
                    val ly = layers.optJSONObject(k) ?: JSONObject()
                    d.add(img(if (ly.has("d")) ly.optInt("d", -1) else null) ?: dummy)
                    n.add(img(if (ly.has("n")) ly.optInt("n", -1) else null) ?: dummy)
                    h.add(img(if (ly.has("r")) ly.optInt("r", -1) else null) ?: dummy)
                    r.tile[k] = if (ly.has("tile")) ly.optDouble("tile", 1.0).toFloat() else 1f
                    r.str[k] = if (ly.has("str")) ly.optDouble("str", 1.0).toFloat() else 1f
                } else { d.add(dummy); n.add(dummy); h.add(dummy) }
            }
            r.count = min(4, layers.length())
            r.tex = d + n + h + listOf(img(if (sp.has("w0")) sp.optInt("w0", -1) else null) ?: dummy, img(if (sp.has("w1")) sp.optInt("w1", -1) else null) ?: dummy)
            return if (r.count > 0) r else null
        }
    }
}

class MetalModelRenderer {
    private val cache = HashMap<String, MetalModel>()
    private val failed = HashSet<String>()
    internal val mapTex = HashMap<String, CpuTex>()                // imported PBR maps by file path
    internal var dummy: CpuTex? = CpuTex(1, 1, byteArrayOf(-1, -1, -1, -1))    // 1x1 white (renderer.dummy)
    /** Cleared at frame start and per motion-blur sample: the next model draw clears the depth buffer. */
    var depthDirty = true
    @JvmField internal var depthH: Long = 0L          // native DepthTex*
    @JvmField internal var depthCopyH: Long = 0L      // native DepthTex* (water depth snapshot, == depthCopyTex)
    /** Dynamic vertex buffers replaced by a newer frame; freed two frame boundaries later (MetalModel.swift:1273 keeps them until the command buffer completes). */
    @JvmField internal val retiredVbufs = ArrayList<Long>()
    @JvmField internal val retiredVbufsOld = ArrayList<Long>()

    companion object {
        @JvmField val evictMapPaths = HashSet<String>()
        @JvmStatic fun evictMaps(path: String) { evictMapPaths.add(path) }
        /** Paths whose texture files changed: dropped from the cache on the next load. */
        @JvmField val evict = HashSet<String>()
        /** "" when ray tracing is ready, else why it is not (MetalModel.swift:1024). Set by rtReady() (MetalModelDraw.kt) from the VK_KHR_ray_query probe. */
        @JvmField var rtStatus = ""

        /** Midpoint subdivision (1 triangle -> 4) of an interleaved 12-float vertex list. */
        @JvmStatic fun subdivide(verts: FloatArray, idx: IntArray, level: Int, maxTris: Int = 1_400_000): Pair<FloatArray, IntArray> {
            var v = verts.copyOf(verts.size + 0); var vn = verts.size
            var ix = idx
            for (lv in 0 until level) {
                if (ix.size / 3 * 4 > maxTris) break
                val mid = HashMap<Long, Int>()
                val out = IntArray(ix.size / 3 * 12 + 0); var on = 0
                val cur = ix
                fun midpoint(a: Int, b: Int): Int {
                    val key = if (a < b) (a.toLong() shl 32 or b.toLong()) else (b.toLong() shl 32 or a.toLong())
                    mid[key]?.let { return it }
                    val n = vn / 12; val ia = a * 12; val ib = b * 12
                    val nv = FloatArray(12)
                    for (k in 0 until 12) nv[k] = (v[ia + k] + v[ib + k]) * 0.5f
                    val nl = sqrt(nv[3] * nv[3] + nv[4] * nv[4] + nv[5] * nv[5])
                    if (nl > 1e-6f) { nv[3] /= nl; nv[4] /= nl; nv[5] /= nl }
                    if (vn + 12 > v.size) v = v.copyOf(max(v.size * 2, vn + 12))
                    System.arraycopy(nv, 0, v, vn, 12); vn += 12
                    mid[key] = n
                    return n
                }
                var t = 0
                while (t + 2 < cur.size) {
                    val a = cur[t]; val b = cur[t + 1]; val c = cur[t + 2]
                    val ab = midpoint(a, b); val bc = midpoint(b, c); val ca = midpoint(c, a)
                    val o = intArrayOf(a, ab, ca, ab, b, bc, ca, bc, c, ab, bc, ca)
                    System.arraycopy(o, 0, out, on, 12); on += 12
                    t += 3
                }
                ix = if (on == out.size) out else out.copyOf(on)
            }
            return Pair(if (vn == v.size) v else v.copyOf(vn), ix)
        }
    }

    fun mapTexture(path: String): CpuTex? {
        if (evictMapPaths.remove(path)) mapTex.remove(path)
        mapTex[path]?.let { return it }
        val bm = BitmapFactory.decodeFile(path) ?: return null
        val t = MetalModel.makeTexture(bm) ?: return null
        mapTex[path] = t
        return t
    }

    /** The shared depth buffer when a model has drawn since the last clear (volume occlusion): native DepthTex*, else 0. */
    fun occlusionDepth(): Long = if (depthDirty) 0L else depthH

    fun trimMemory() { for (m in cache.values) if (m != null && m.accel != 0L) { NativeModel.accelFree(m.accel); m.accel = 0L }; if (depthH != 0L) { NativeModel.depthFree(depthH); depthH = 0L }; if (depthCopyH != 0L) { NativeModel.depthFree(depthCopyH); depthCopyH = 0L }; cache.clear(); mapTex.clear(); subCache.values.forEach { NativeModel.bufFree(it.first); NativeModel.bufFree(it.second) }; subCache.clear(); colTris.clear(); ptSampleCache.clear(); for (h in retiredVbufs) NativeModel.bufFree(h); retiredVbufs.clear(); for (h in retiredVbufsOld) NativeModel.bufFree(h); retiredVbufsOld.clear() }
    internal val subCache = HashMap<String, Triple<Long, Long, Int>>()   // subdivided meshes for displacement: native vb Buf*, ib Buf*, index count

    fun loadModel(path: String): MetalModel? {
        if (evict.remove(path)) { cache.remove(path)?.let { if (it.accel != 0L) { NativeModel.accelFree(it.accel); it.accel = 0L } }; failed.remove(path) }
        cache[path]?.let { return it }
        if (failed.contains(path)) return null
        val p = GlbModel.validate(path)
        val g = GlbModel.load(p)
        val m = if (g != null) MetalModel.create(g) else null
        if (m == null) { failed.add(path); return null }
        m.splat = Splat.load(p, dummy)
        cache[path] = m
        cache[p] = m
        return m
    }

    // MARK: physical collision with point-map colliders (position-based sphere push-out, same in preview and export)

    private val colTris = HashMap<String, FloatArray>()          // 3 vertices (xyz) per triangle, collider local space
    private fun colliderTris(path: String, m: MetalModel): FloatArray {
        colTris[path]?.let { return it }
        var t = FloatArray(0); var n = 0
        for (sp in m.src.prims) {
            if (!sp.collider) continue
            var k = 0
            while (k < sp.cpuIdx.size - 2) {
                for (j in 0 until 3) {
                    val o = sp.cpuIdx[k + j] * 12
                    if (n + 3 > t.size) t = t.copyOf(max(t.size * 2, 768))
                    t[n] = sp.verts[o]; t[n + 1] = sp.verts[o + 1]; t[n + 2] = sp.verts[o + 2]; n += 3
                }
                k += 3
            }
        }
        val r = if (n == t.size) t else t.copyOf(n)
        colTris[path] = r
        return r
    }

    private fun closest(p: V3, a: V3, b: V3, c: V3): V3 {
        val ab = b - a; val ac = c - a; val ap = p - a
        val d1 = dot(ab, ap); val d2 = dot(ac, ap); if (d1 <= 0f && d2 <= 0f) return a
        val bp = p - b; val d3 = dot(ab, bp); val d4 = dot(ac, bp); if (d3 >= 0f && d4 <= d3) return b
        val vc = d1 * d4 - d3 * d2; if (vc <= 0f && d1 >= 0f && d3 <= 0f) return a + ab * (d1 / (d1 - d3))
        val cp = p - c; val d5 = dot(ab, cp); val d6 = dot(ac, cp); if (d6 >= 0f && d5 <= d6) return c
        val vb = d5 * d2 - d1 * d6; if (vb <= 0f && d2 >= 0f && d6 <= 0f) return a + ac * (d2 / (d2 - d6))
        val va = d3 * d6 - d5 * d4; if (va <= 0f && (d4 - d3) >= 0f && (d5 - d6) >= 0f) return b + (c - b) * ((d4 - d3) / ((d4 - d3) + (d5 - d6)))
        val den = 1f / (va + vb + vc); return a + ab * (vb * den) + ac * (vc * den)
    }

    /** Pushes a model layer out of every visible point-map collider (the model is treated as a sphere around its centre). */
    fun collidePush(mm: FloatArray, l: Layer, time: Float) {
        for (c in Editor.scene.layers) {
            if (c === l || c.type != LayerType.MODEL || !c.visible || time < c.start || time > c.end) continue
            val cp = c.imagePath ?: continue
            if (!PlyImport.isPointMap(cp) || c.xf("colPhys", 1f) <= 0.5f || !PlyImport.hasCollider(cp)) continue
            val cm = loadModel(cp) ?: continue
            val tris = colliderTris(cp, cm)
            if (tris.isEmpty()) continue
            val cmm = MetalCam.modelMatrix(c, time, cm.src.normalize)
            if (cmm.size != 16) continue
            val M = M4(cmm.copyOf())
            val inv = M.inverse()
            val sObj = max(1e-4f, sqrt(mm[0] * mm[0] + mm[1] * mm[1] + mm[2] * mm[2]))
            val sCol = max(1e-4f, sqrt(cmm[0] * cmm[0] + cmm[1] * cmm[1] + cmm[2] * cmm[2]))
            val rW = sObj * 0.5f * c.xf("colRadius", 0.5f) * 2f; val rL = rW / sCol
            var pwx = mm[12]; var pwy = mm[13]; var pwz = mm[14]
            for (pass in 0 until 3) {                                   // a few passes settle corners
                val pl4 = inv * V4(pwx, pwy, pwz, 1f); val pl = V3(pl4.x, pl4.y, pl4.z)
                var best = Float.MAX_VALUE; var bq = pl
                var k = 0
                while (k + 8 < tris.size) {
                    val a = V3(tris[k], tris[k + 1], tris[k + 2]); val b = V3(tris[k + 3], tris[k + 4], tris[k + 5]); val d = V3(tris[k + 6], tris[k + 7], tris[k + 8]); k += 9
                    if (min(a.x, min(b.x, d.x)) > pl.x + rL || max(a.x, max(b.x, d.x)) < pl.x - rL ||
                        min(a.y, min(b.y, d.y)) > pl.y + rL || max(a.y, max(b.y, d.y)) < pl.y - rL ||
                        min(a.z, min(b.z, d.z)) > pl.z + rL || max(a.z, max(b.z, d.z)) < pl.z - rL) continue
                    val q = closest(pl, a, b, d); val dd = length(pl - q)
                    if (dd < best) { best = dd; bq = q }
                }
                if (!(best < rL)) break
                var n = pl - bq
                n = if (best < 1e-6f) V3(0f, 1f, 0f) else n / best
                val push = n * (rL - best)
                val w = M * V4(push.x, push.y, push.z, 0f)
                pwx += w.x; pwy += w.y; pwz += w.z
            }
            mm[12] = pwx; mm[13] = pwy; mm[14] = pwz
        }
    }

    private val ptSampleCache = IdentityHashMap<GlbModel, List<V3>>()
    /** Particular "Model" emitter: ~4000 area-weighted surface samples of a MODEL layer (0 = first model), as offsets from particle layer `pl`. */
    fun ptSurface(pl: Layer, targetId: Int, time: Float): List<V3> {
        val layers = Editor.scene.layers
        val tl = (if (targetId > 0) layers.firstOrNull { it.id == targetId && it.type == LayerType.MODEL }
                  else layers.firstOrNull { it.type == LayerType.MODEL && it.visible }) ?: return emptyList()
        val tp = tl.imagePath ?: return emptyList()
        if (tp.lowercase().endsWith(".vdb")) return emptyList()
        val t0 = loadModel(tp) ?: return emptyList()
        val mm = MetalCam.modelMatrix(tl, time, t0.src.normalize)
        if (mm.size != 16) return emptyList()
        val M = M4(mm.copyOf())
        var local: List<V3> = ptSampleCache[t0.src] ?: emptyList()
        if (local.isEmpty()) {
            val tris = Scatter.tris(t0.src)
            if (tris.isEmpty()) return emptyList()
            val cum = FloatArray(tris.size); var tot = 0f
            for ((i, t) in tris.withIndex()) { tot += length(cross(t.b - t.a, t.c - t.a)) * 0.5f; cum[i] = tot }
            var s = 2463534242L.toInt()
            fun rnd(): Float { s = s xor (s shl 13); s = s xor (s ushr 17); s = s xor (s shl 5); return (s and 0xFFFFFF).toFloat() / 16777216f }
            val acc = ArrayList<V3>(4096)
            for (i in 0 until 4096) {
                val r = rnd() * tot
                var lo = 0; var hi = cum.size - 1
                while (lo < hi) { val mid = (lo + hi) / 2; if (cum[mid] < r) lo = mid + 1 else hi = mid }
                val t = tris[lo]; var u = rnd(); var v = rnd()
                if (u + v > 1f) { u = 1f - u; v = 1f - v }
                acc.add(t.a + (t.b - t.a) * u + (t.c - t.a) * v)
            }
            local = acc
            if (ptSampleCache.size > 6) ptSampleCache.clear()
            ptSampleCache[t0.src] = local
        }
        val lt = pl.editTime("x", time)
        val ox = pl.p("x", lt); val oy = pl.p("y", lt); val oz = Xf.worldZ(pl, time)
        return local.map { val w = M * V4(it.x, it.y, it.z, 1f); V3(w.x - ox, w.y - oy, w.z - oz) }
    }

    /** Scatter: raw world instance matrices for layer `l` (no model normalisation), or null = not scattering. */
    fun scatterWorld(l: Layer, time: Float): List<M4>? {
        if (l.xf("scOn", 0f) <= 0.5f) return null
        val tid = l.xf("scTarget", -1f).toInt()
        val tris: List<Scatter.Tri>; val tm: M4; var tl: Layer = l
        if (tid == -2 || tid == -3) {
            tris = Scatter.ground(l.xf("scGroundSize", 10f), l.xf("scGroundY", 0f)); tm = M4.identity()
        } else {
            if (tid == l.id) return null
            val t = Editor.scene.layers.firstOrNull { it.id == tid } ?: return null
            tl = t
            if (tl.type == LayerType.MODEL) {
                val tp = tl.imagePath ?: return null
                if (tp.lowercase().endsWith(".vdb")) return null
                val t0 = loadModel(tp) ?: return null
                val mm = MetalCam.modelMatrix(tl, time, t0.src.normalize)
                if (mm.size != 16) return null
                tris = Scatter.tris(t0.src); tm = M4(mm.copyOf())
            } else {
                val (w, h) = Xf.quadSize(tl)
                val mm = MetalCam.modelMatrix(tl, time, floatArrayOf(1f, 0f, 0f, 0f))
                if (mm.size != 16) return null
                tris = Scatter.quad(w, h); tm = M4(mm.copyOf())
            }
        }
        return Scatter.instances(l, tl, tris, tm, time)
    }

    /** Scatter: instance matrices (already including this model's normalisation), or null = draw normally. */
    fun scatterMatrices(l: Layer, model: MetalModel, time: Float, w: Int, h: Int): List<M4>? {
        var inst: List<M4> = scatterWorld(l, time) ?: return null
        val n = model.src.normalize
        val N = M4(floatArrayOf(n[0], 0f, 0f, 0f, 0f, n[0], 0f, 0f, 0f, 0f, n[0], 0f, 0f, 0f, 0f, 1f))
        N.setCol(3, V4(n[0] * n[1], n[0] * n[2] - model.src.baseY * l.xf("scSit", 1f), n[0] * n[3], 1f))   // S(n0) · T(offset); base rests on the surface
        inst = inst.map { it * N }
        // cull instances outside the view (big saving with thousands of trees / rocks)
        if (inst.size > 12) {
            val vp = MetalCam.vpForModel(l, Editor.scene.fov, time, w, h)
            if (vp.size == 16) {
                inst = inst.filter { m ->
                    val p = m.col(3)
                    val cw = vp[3] * p.x + vp[7] * p.y + vp[11] * p.z + vp[15]
                    if (cw <= 0.01f) return@filter false
                    val cx = vp[0] * p.x + vp[4] * p.y + vp[8] * p.z + vp[12]; val cy = vp[1] * p.x + vp[5] * p.y + vp[9] * p.z + vp[13]
                    val c1 = m.col(1)
                    val r = max(sqrt(c1.x * c1.x + c1.y * c1.y + c1.z * c1.z), 0.05f) * 1.6f * abs(vp[0])   // generous radius
                    abs(cx) < cw * 1.4f + r && abs(cy) < cw * 1.4f + r
                }
            }
            if (inst.size > 1500) inst = inst.subList(0, 1500).toList()
        }
        if (l.xf("scKeep", 0f) > 0.5f) inst = inst + M4(MetalCam.modelMatrix(l, time, model.src.normalize))
        return inst
    }
}
