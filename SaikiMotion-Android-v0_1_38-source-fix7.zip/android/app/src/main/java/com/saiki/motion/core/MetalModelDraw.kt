package com.saiki.motion.core

import kotlin.math.*

// Port of MetalModel.swift:1204-1420 MetalModelRenderer.draw (plain models), slice 7m. Unbuilt/unverified.
// 7n done (points, subCache, splat). 7o-a done (water depth snapshot, waterUnder pass, occludePlane). 7o-b done (RT accel + ray-query pipeline).
// Collider depth bias (4, 4) done via meta[3i+2] -> vkCmdSetDepthBias (MetalModel.swift:1401); aniso4 material samplers done (Samp::Aniso4Mip*).

private const val UF = 46 * 4   // ModelU floats (46 vec4, order == model.vert binding 32)
// vec4 slots of ModelU
private const val VP0 = 0; private const val M0 = 4; private const val COLOR = 8; private const val EMIS = 9; private const val EYE = 10; private const val PRM = 11
private const val HAS = 12; private const val OPT = 13; private const val XTRA = 14; private const val LP0 = 15; private const val LC0 = 18; private const val PG = 21
private const val WA = 22; private const val WB = 23; private const val WC = 24; private const val WD = 25; private const val WE = 26; private const val WF = 27
private const val WG = 28; private const val WH = 29; private const val WI = 30; private const val WJ = 31; private const val WK = 32; private const val WL = 33
private const val ENVP = 34; private const val SP0 = 35; private const val PM = 38; private const val PN = 39; private const val PT = 40; private const val XR = 41
private const val PQ = 42; private const val PR = 43; private const val PNM = 44; private const val PTC = 45

/** CpuTex -> native Tex* (lazy). */
internal fun gpuTex(t: CpuTex?): Long { if (t == null) return 0L; if (t.gpu == 0L) t.gpu = NativeModel.texCreate(t.w, t.h, t.rgba); return t.gpu }

private var rtProbed = false
/** == MetalModelRenderer.init: rtStatus + `rtLib != nil`. */
private fun rtReady(): Boolean {
    val ok = NativeModel.rtSupported()
    if (!rtProbed) { rtProbed = true; MetalModelRenderer.rtStatus = if (ok) "" else "This device's GPU has no hardware ray tracing (needs VK_KHR_ray_query)." }
    return ok
}

/** MetalModelRenderer.setVBuf / the per-frame vertex buffer: Buf* from the interleaved 12-float vertices. */
internal fun MetalModelRenderer.vbufs(model: MetalModel, animated: Boolean): LongArray {
    // Replaced dynamic buffers are retired two generations before bufFree (kFrames is 2): by then the frame that used them
    // has been submitted and its fence waited on. iOS keeps the old MTLBuffer alive until its command buffer completes (MetalModel.swift:1273).
    if (retiredVbufsOld.isNotEmpty()) { for (h in retiredVbufsOld) NativeModel.bufFree(h); retiredVbufsOld.clear() }
    if (retiredVbufs.isNotEmpty()) { retiredVbufsOld.addAll(retiredVbufs); retiredVbufs.clear() }
    val out = LongArray(model.prims.size)
    for ((i, p) in model.prims.withIndex()) {
        if (p.srcIndex >= model.src.prims.size) continue
        val sp = model.src.prims[p.srcIndex]
        val dyn = animated && sp.slot >= 0
        if (p.vbuf == 0L || dyn) {
            val nb = NativeModel.bufFloat(sp.verts)
            if (dyn && p.vbuf != 0L) retiredVbufs.add(p.vbuf)
            p.vbuf = nb
        }
        out[i] = p.vbuf
    }
    return out
}

fun MetalModelRenderer.draw(l: Layer, time: Float, fov: Float, into: MetalTarget, sceneTex: MetalTarget? = null) {
    val path = l.imagePath ?: return
    val model = loadModel(path) ?: return
    val dummyTex = dummy ?: return
    val dh = NativeModel.depthEnsure(depthH, into.width, into.height)
    if (dh == 0L) return
    if (dh != depthH) depthDirty = true
    depthH = dh
    model.src.setAnimTime(max(0f, time - l.start))
    model.src.applyPose(l, time)
    val vp = MetalCam.vpForModel(l, fov, time, into.width, into.height)
    val mm = MetalCam.modelMatrix(l, time, model.src.normalize)
    if (mm.size == 16 && !PlyImport.isPointMap(l.imagePath)) collidePush(mm, l, time)
    if (vp.size != 16 || mm.size != 16) return
    val eye = GlbModel.eye(vp)
    val isWater = l.xf("water", 0f) > 0.5f
    val dummyH = gpuTex(dummyTex)
    if (isWater && depthDirty) {
        // Water alone in the scene: clear the depth to "far" and take the same path as when a model is under it.
        NativeModel.modelPass(into.handle, depthH, true, 0, LongArray(0), LongArray(0), LongArray(0), IntArray(0), FloatArray(0), LongArray(0), BooleanArray(0), LongArray(0),
            LongArray(21) { dummyH }, 0L, FloatArray(256), FloatArray(0), 0L, FloatArray(0))
        depthDirty = false
    }
    // snapshot of the depth every earlier layer wrote: the water reads it to know how deep each thing below it is
    var depthSrc = 0L; var hasDepth = 0f
    if (isWater && sceneTex != null && !depthDirty) {
        val c = NativeModel.depthEnsure(depthCopyH, into.width, into.height)
        if (c != 0L) { depthCopyH = c; if (NativeModel.depthCopy(depthH, c)) { depthSrc = c; hasDepth = 1f } }
    }

    val b = FloatArray(UF)
    fun v4(s: Int, x: Float, y: Float, z: Float, w: Float) { val o = s * 4; b[o] = x; b[o + 1] = y; b[o + 2] = z; b[o + 3] = w }
    for (k in 0 until 4) v4(VP0 + k, vp[k * 4], vp[k * 4 + 1], vp[k * 4 + 2], vp[k * 4 + 3])
    for (k in 0 until 4) v4(M0 + k, mm[k * 4], mm[k * 4 + 1], mm[k * 4 + 2], mm[k * 4 + 3])
    val xrayNow = Editor.xray && !Editor.exporting
    v4(XR, if (xrayNow) 1f else 0f, 2f, 0.12f, 0f)
    v4(EYE, eye[0], eye[1], eye[2], l.xf("light", 1f) * R3D.g("light", 1f))
    var nl = 0
    for (L in Editor.scene.layers) {
        if (!(L.isLight && L.xf("lightType", 0f) < 0.5f && L.visible && time >= L.start && time <= L.end && nl < 3)) continue
        val lt = L.editTime("x", time); val c = L.vdbTint; val k = L.xf("lightInt", 1f)
        v4(LP0 + nl, L.p("x", lt), L.p("y", lt), Xf.worldZ(L, time), 0f)
        v4(LC0 + nl, ((c ushr 16) and 255) / 255f * k, ((c ushr 8) and 255) / 255f * k, (c and 255) / 255f * k, 1f)
        nl++
    }
    val lightBuf = Lights.buffer(time)
    b[PR * 4 + 3] = lightBuf.second.toFloat()
    v4(OPT, if (l.m3Env) 1f else 0f, if (l.m3Metal) 1f else 0f, l.m3View.toFloat(), if (l.m3Ao) 1f else 0f)
    GlobalEnv.tex()      // MetalModel.swift:1255 `_ = GlobalEnv.tex(core)`: lazily (re)creates the HDRI + mipLevels before reading the uniform
    GlobalEnv.uniform.let { v4(ENVP, it[0], it[1], it[2], it[3]) }
    model.splat?.let { sp -> v4(SP0, 1f, sp.count.toFloat(), 0f, 0f); v4(SP0 + 1, sp.tile[0], sp.tile[1], sp.tile[2], sp.tile[3]); v4(SP0 + 2, sp.str[0], sp.str[1], sp.str[2], sp.str[3]) }

    val animated = model.src.isAnimated
    val vbs = vbufs(model, animated)

    var rtI = if (l.rtOn) l.rtInt else 0f
    var rtR = l.rtRad
    Xf.camera(l)?.let { if (it.rtOn) { rtI = max(rtI, it.rtInt); rtR = it.rtRad } }
    if (R3D.g("rtAll", 0f) > 0.5f) rtI = max(rtI, R3D.g("rtMul", 1f))
    v4(XTRA, l.xf("exposure", 1f) * R3D.g("exposure", 1f), min(rtI * l.xf("rtAo", 1f), 1f), min(rtI * l.xf("rtShadow", 1f), 1f), l.xf("pbrNorm", 0f))
    val pgOn = l.xf("pgOn", 0f) > 0.5f
    val sRatio = if (pgOn) max(l.p("scale", time) / max(l.xf("pgRef", 1f), 1e-4f), 1e-3f) else 1f
    v4(PG, if (pgOn) 1f else 0f, min(l.xf("pbrPom", 0f), 0.06f), sRatio, sRatio)
    v4(WA, l.xf("water", 0f), time, l.xf("wAmp", 0.03f), l.xf("wFreq", 6f))
    v4(WB, l.xf("wSpeed", 1f), l.xf("wFoam", 0.5f), l.xf("wDepth", 0.5f), l.xf("wChop", 0.5f))
    v4(WC, l.xf("wClar", 0.6f), l.xf("wTurb", 0.15f), l.xf("wRefr", 0.5f), l.xf("wSss", 0.5f))
    v4(WD, l.xf("wGlint", 1f), l.xf("wDetail", 0.6f), l.xf("wDir", 30f) * PI.toFloat() / 180f, l.xf("wSeabed", 0.7f))
    v4(WE, l.xf("wVar", 0.7f), l.xf("wSwell", 0.8f), l.xf("wSwellLen", 0.15f), l.xf("wCaps", 0.5f))
    v4(WF, mm[13], if (l.xf("wRefl", 0f) > 0.5f) 1f else 0f, hasDepth, if (l.xf("wRays", 0f) > 0.5f) 1f else 0f)
    v4(WG, l.xf("wRayStr", 1f), l.xf("wRayLen", 1f), l.xf("wRayWid", 1f), l.xf("wRaySpd", 1f))
    fun wrgb(k: String, d: Long): FloatArray { val c = l.xf(k, d.toFloat()).toLong().toInt(); return floatArrayOf(((c ushr 16) and 255) / 255f, ((c ushr 8) and 255) / 255f, (c and 255) / 255f) }
    val wCust = l.xf("wColOn", 0f) > 0.5f
    val w0 = wrgb("wCol0", 0x2FD0C8); val w1 = wrgb("wCol1", 0x1E7FD0); val w2 = wrgb("wCol2", 0x08285A)
    v4(WI, w0[0], w0[1], w0[2], if (wCust) 1f else 0f)
    v4(WJ, w1[0], w1[1], w1[2], if (l.xf("wColN", 3f) > 2.5f) 3f else 2f)
    v4(WK, w2[0], w2[1], w2[2], l.xf("wGrad", 0f))
    v4(WL, max(l.xf("wGradScale", 1f), 0.05f), 0f, 0f, 0f)
    if (l.xf("wColl", 0f) > 0.5f) v4(WH, if (l.xf("wCollRock", 1f) > 0.5f) 1f else 0f, if (l.xf("wCollShore", 1f) > 0.5f) 1f else 0f, l.xf("wFoamW", 0.4f), 0f) else v4(WH, 0f, 0f, 0.4f, 0f)

    // imported PBR maps
    val pbrTex = HashMap<String, CpuTex>()
    if (!isWater) for ((k, pth) in l.pbrMaps) mapTexture(pth)?.let { pbrTex[k] = it }
    val pbrOn = pbrTex.isNotEmpty()
    var subLevel = 0
    if (pbrOn) {
        val tile = max(l.xf("pbrTile", 1f), 0.01f)
        val hasH = pbrTex["height"] != null
        v4(PM, if (pbrTex["normal"] != null) 1f else 0f, if (pbrTex["rough"] != null) 1f else 0f, if (pbrTex["metal"] != null) 1f else 0f, if (hasH) 1f else 0f)
        v4(PN, if (pbrTex["opacity"] != null) 1f else 0f, l.xf("pbrNStr", 1f), if (l.xf("pbrFlip", 0f) > 0.5f) -1f else 1f, if (hasH) l.xf("pbrDisp", 0.05f) else 0f)
        v4(PT, tile, tile, if (hasH) l.xf("pbrPar", 0.03f) else 0f, l.xf("pbrMid", 0.5f))
        v4(PQ, l.xf("pbrRough", 1f), l.xf("pbrMetal", 1f), l.xf("pbrEm", 1f), 1f)
        b[PR * 4] = l.xf("pbrCoat", 0f); b[PR * 4 + 1] = l.xf("pbrCoatR", 0.1f); b[PR * 4 + 2] = l.xf("pbrAo", 1f)
        if (hasH && l.xf("pbrDisp", 0.05f) != 0f) subLevel = max(0, min(4, Math.round(l.xf("pbrSub", 2f))))
    }
    // ray tracing (MetalModel.swift:1310): acceleration structure over the model's own triangles; animated models rebuild every frame
    var accel = 0L
    if (rtI > 0.001f && rtReady()) {
        if (animated || model.accel == 0L) {
            if (model.accel != 0L) NativeModel.accelFree(model.accel)
            model.accel = buildAccel(model, vbs)
        }
        accel = model.accel
    }
    val invM = M4(mm.copyOf()).inverse().m
    val rtu = FloatArray(20)
    rtu[0] = min(rtI, 1f); rtu[1] = rtR; rtu[2] = max(l.xf("rtSoft", 0.04f), 0f); rtu[3] = max(l.xf("rtSamples", 8f), 1f)
    System.arraycopy(invM, 0, rtu, 4, 16)

    val instMs: List<M4> = scatterMatrices(l, model, time, into.width, into.height) ?: listOf(M4(mm.copyOf()))
    // point map: colliders first (depth only)
    fun isCol(i: Int) = model.prims[i].srcIndex < model.src.prims.size && model.src.prims[model.prims[i].srcIndex].collider
    val colFirst = model.prims.indices.filter { isCol(it) }
    val primOrder = colFirst + model.prims.indices.filter { !isCol(it) }
    val ptSize = max(0.5f, l.xf("ptSize", 3f)) * into.height.toFloat() / 720f
    val ptDensity = min(1f, max(0.005f, l.xf("ptDensity", 1f)))
    val colOcc = l.xf("colOcc", 1f) > 0.5f; val colShow = l.xf("colShow", 0f) > 0.5f

    val dPso = ArrayList<Long>(); val dVb = ArrayList<Long>(); val dIb = ArrayList<Long>(); val dMeta = ArrayList<Int>()
    val dUbo = ArrayList<FloatArray>(); val dTex = ArrayList<Long>(); val dClamp = ArrayList<Boolean>(); val dOwn = ArrayList<Long>()
    for (i in primOrder) {
        val p = model.prims[i]
        if (p.srcIndex >= model.src.prims.size) continue
        val sp = model.src.prims[p.srcIndex]
        val depthOnlyCol = sp.collider && !colShow
        if (sp.collider && !colOcc && !colShow) continue
        val blendNow = sp.blend || xrayNow
        val depthWrite = !(blendNow && !isWater && !depthOnlyCol)
        // rtPS ?? pso(...): the RT fragment (never for depth-only colliders); every pipeline of an RT pass shares the RT set layout
        var ps = if (accel != 0L && !depthOnlyCol) NativeModel.pso("model_rt.frag", into.handle, blendNow, false, depthWrite, p.points, true) else 0L
        if (ps == 0L) ps = NativeModel.pso("model.frag", into.handle, blendNow, depthOnlyCol, depthWrite, p.points, accel != 0L)
        if (ps == 0L) continue
        val vb = vbs[i]; if (vb == 0L) continue
        if (p.ibuf == 0L) { val ib = model.src.prims[p.srcIndex].cpuIdx; p.ibuf = NativeModel.bufIdx(ib, !p.idx32) }
        if (p.ibuf == 0L) continue
        val u = b.copyOf()
        v4v(u, COLOR, sp.color[0], sp.color[1], sp.color[2], sp.color[3])
        v4v(u, EMIS, sp.emissive[0], sp.emissive[1], sp.emissive[2], l.xf("env", 1f) * R3D.g("env", 1f))
        v4v(u, PRM, sp.metal, sp.rough, sp.cutoff, sp.unlit)
        val ptex = arrayOf(p.tex[0], p.tex[1], p.tex[2], p.tex[3]); val pclamp = p.clamp.copyOf()
        if (pbrOn) {
            pbrTex["albedo"]?.let { ptex[0] = it; pclamp[0] = false }
            pbrTex["emissive"]?.let { ptex[2] = it; pclamp[2] = false }
            pbrTex["ao"]?.let { ptex[3] = it; pclamp[3] = false }
        }
        v4v(u, HAS, if (ptex[0] != null) 1f else 0f, if (ptex[1] != null) 1f else 0f, if (ptex[2] != null) 1f else 0f, if (ptex[3] != null) 1f else 0f)
        val ownNormal = !isWater && !pbrOn && p.norm != null
        v4v(u, PNM, if (ownNormal) 1f else 0f, l.xf("pbrNStr", 1f), if (l.xf("pbrFlip", 0f) > 0.5f) -1f else 1f, 0f)
        var useVb = vb; var useIb = p.ibuf; var useCount = p.count; var use32 = p.idx32
        if (p.points) {   // density (points are pre-shuffled: a prefix is a uniform subset) + size + animation
            useCount = max(1, (p.count.toFloat() * ptDensity).toInt())
            v4v(u, PTC, ptSize, l.xf("ptAnim", 0f), l.xf("ptAmt", 1f), time * l.xf("ptSpeed", 1f))
        }
        if (subLevel > 0 && !p.points && !animated && accel == 0L) {
            val ip = l.imagePath
            if (ip != null) {
                val key = "$ip#${p.srcIndex}#$subLevel"
                if (subCache[key] == null) {
                    val (v2, i2) = MetalModelRenderer.subdivide(sp.verts, sp.cpuIdx, subLevel)
                    val vb2 = NativeModel.bufFloat(v2); val ib2 = NativeModel.bufIdx(i2, false)
                    if (vb2 != 0L && ib2 != 0L) subCache[key] = Triple(vb2, ib2, i2.size)
                }
                subCache[key]?.let { useVb = it.first; useIb = it.second; useCount = it.third; use32 = true }
            }
        }
        for (im in instMs) {     // only the matrices change per instance
            val ui = u.copyOf()
            for (k in 0 until 16) ui[M0 * 4 + k] = im.m[k]
            dPso.add(ps); dVb.add(useVb); dIb.add(useIb); dMeta.add(if (use32) 1 else 0); dMeta.add(useCount); dMeta.add(if (depthOnlyCol) 1 else 0)   // meta[3i+2]: collider depth bias 4/4/0 (MetalModel.swift:1401)
            dUbo.add(ui)
            for (k in 0 until 4) { dTex.add(gpuTex(ptex[k]).let { if (it == 0L) dummyH else it }); dClamp.add(pclamp[k]) }
            dOwn.add(if (ownNormal) gpuTex(p.norm) else 0L)
        }
    }
    val n = dPso.size
    val ubo = FloatArray(n * UF); for (i in 0 until n) System.arraycopy(dUbo[i], 0, ubo, i * UF, UF)
    val sh = LongArray(21) { dummyH }
    sh[0] = sceneTex?.tex ?: dummyH
    sh[1] = if (GlobalEnv.cached != 0L) GlobalEnv.cached else dummyH
    model.splat?.tex?.let { st -> for (k in 0 until min(14, st.size)) st[k]?.let { sh[2 + k] = gpuTex(it) } }
    for ((k, key) in listOf("normal", "rough", "metal", "height", "opacity").withIndex()) pbrTex[key]?.let { sh[16 + k] = gpuTex(it) }
    // camera below the surface (any camera, also the editing one): the whole picture is seen through the water
    var under = FloatArray(0)
    if (isWater && eye[1] < mm[13]) {
        under = FloatArray(UF + 16); System.arraycopy(b, 0, under, 0, UF)
        model.src.prims.firstOrNull()?.let { sp0 -> v4v(under, COLOR, sp0.color[0], sp0.color[1], sp0.color[2], sp0.color[3]) }
        System.arraycopy(M4(vp.copyOf()).inverse().m, 0, under, UF, 16)
    }
    val clear = depthDirty
    depthDirty = false
    NativeModel.modelPass(into.handle, depthH, clear, n, dPso.toLongArray(), dVb.toLongArray(), dIb.toLongArray(), dMeta.toIntArray(), ubo, dTex.toLongArray(),
        dClamp.toBooleanArray(), dOwn.toLongArray(), sh, depthSrc, lightBuf.first, under, accel, rtu)
}

/** MetalModelRenderer.buildAccel: every non-point primitive with >= 1 triangle (vertex Buf* + index Buf*). 0 when there is nothing to trace. */
private fun MetalModelRenderer.buildAccel(model: MetalModel, vbs: LongArray): Long {
    val vb = ArrayList<Long>(); val ib = ArrayList<Long>(); val meta = ArrayList<Int>()
    for ((i, p) in model.prims.withIndex()) {
        if (p.points || i >= vbs.size || p.count < 3 || vbs[i] == 0L || p.srcIndex >= model.src.prims.size) continue
        if (p.ibuf == 0L) p.ibuf = NativeModel.bufIdx(model.src.prims[p.srcIndex].cpuIdx, !p.idx32)
        if (p.ibuf == 0L) continue
        vb.add(vbs[i]); ib.add(p.ibuf); meta.add(if (p.idx32) 1 else 0); meta.add(p.count / 3)
    }
    if (vb.isEmpty()) return 0L
    return NativeModel.accelBuild(vb.toLongArray(), ib.toLongArray(), meta.toIntArray(), vb.size)
}

private fun v4v(a: FloatArray, s: Int, x: Float, y: Float, z: Float, w: Float) { val o = s * 4; a[o] = x; a[o + 1] = y; a[o + 2] = z; a[o + 3] = w }

/** MetalModelRenderer.occludePlane: 3D media plane vs models. Cuts `src` by the model depth into `dst`, then writes the plane's own depth. */
fun MetalModelRenderer.occludePlane(l: Layer, time: Float, src: MetalTarget, dst: MetalTarget): Boolean {
    if (dst.handle == src.handle || dst.width != src.width || dst.height != src.height) return false
    val dh = NativeModel.depthEnsure(depthH, src.width, src.height)
    if (dh == 0L) return false
    if (dh != depthH) depthDirty = true
    depthH = dh
    val vp = MetalCam.vpForModel(l, Editor.scene.fov, time, src.width, src.height)
    if (vp.size != 16) return false
    val lt = l.editTime("x", time)
    val d2r = PI.toFloat() / 180f
    // n = Rz * Rx * Ry * (0,0,1)
    val ry = l.p("rotY", lt) * d2r; val rx = l.p("rotX", lt) * d2r; val rz = l.p("rotZ", lt) * d2r
    var nx = sin(ry); var ny = 0f; var nz = cos(ry)
    run { val y = ny * cos(rx) - nz * sin(rx); val z = ny * sin(rx) + nz * cos(rx); ny = y; nz = z }
    run { val x = nx * cos(rz) - ny * sin(rz); val y = nx * sin(rz) + ny * cos(rz); nx = x; ny = y }
    val u = FloatArray(44)
    System.arraycopy(M4(vp.copyOf()).inverse().m, 0, u, 0, 16); System.arraycopy(vp, 0, u, 16, 16)
    u[32] = l.p("x", lt); u[33] = l.p("y", lt); u[34] = Xf.worldZ(l, time); u[35] = 1f
    u[36] = nx; u[37] = ny; u[38] = nz
    u[40] = if (depthDirty) 0f else 1f
    val ok = NativeModel.planeOcclude(src.handle, dst.handle, depthH, depthDirty, u)
    depthDirty = false
    return ok
}
