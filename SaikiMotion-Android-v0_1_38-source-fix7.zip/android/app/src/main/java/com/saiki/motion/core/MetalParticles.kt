package com.saiki.motion.core

import com.saiki.motion.render.SceneRendererN
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// Port of Sources/Render/MetalParticles.swift MetalParticleRenderer. Shaders: shared/shaders/glsl/particle.vert/.frag
// (PtU b0, pts SSBO b1 12 floats/vertex, grad[16] b2, atlas b0 + bump b1 in the fragment stage).
// The simulation, 3D projection, depth sort and occluder rectangles are the same code as GL.
object MetalParticlesRenderer {
    /** While set, particle simulation uses this time (camera/layer keep the blur sub-time), so particles
     *  stay crisp under motion blur instead of averaging to nothing. Same meaning as GL particleSimTime. */
    @JvmField var simTime: Float? = null

    private val readyGate get() = SceneRendererN.pipelineReady("particle.frag")
    val ready: Boolean get() = readyGate
    private val texCache = HashMap<String, Long>()
    private var dummyTex = 0L

    private fun dummyTexture(): Long {
        if (dummyTex != 0L) return dummyTex
        dummyTex = SceneRendererN.texCreate(1, 1, byteArrayOf(-1, -1, -1, -1))
        return dummyTex
    }

    /** 512x512 premultiplied RGBA sprite sheet (built-in shapes, petals, imported image / video flipbook). */
    private fun spriteTexture(s: PtSpriteSet): Long {
        texCache[s.key]?.let { return it }
        val t = SceneRendererN.texCreate(s.bmp.width, s.bmp.height, s.rgba())
        if (t == 0L) return dummyTexture()
        if (texCache.size > 24) texCache.clear()
        texCache[s.key] = t
        return t
    }

    /** Height map for the bump shading: the imported one (ptBumpId), or the bundled maple-leaf map for the Maple Leaf. */
    private fun bumpTexture(g: (String) -> Float): Long {
        val id = Math.round(g("ptBumpId")).toInt()
        val key = if (id > 0) "bump$id" else "bumpleaf"
        texCache[key]?.let { return it }
        var im: android.graphics.Bitmap? = null
        if (id > 0) im = PtImages.load(id)?.first
        else if (Math.round(g("ptSprite")) == 10) {
            im = try { Paths.appContext.assets.open("img/pt_leaf_bump.png").use { android.graphics.BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }
        }
        val img = im ?: return dummyTexture()
        val w = 512
        val scaled = android.graphics.Bitmap.createScaledBitmap(img, w, w, true)
        val t = SceneRendererN.texCreate(w, w, SceneRendererN.bitmapRgba(scaled))
        if (t == 0L) return dummyTexture()
        if (texCache.size > 24) texCache.clear()
        texCache[key] = t
        return t
    }

    private fun projectPoint(vp: FloatArray, x: Float, y: Float, z: Float): Triple<Float, Float, Float> {
        val cx = vp[0] * x + vp[4] * y + vp[8] * z + vp[12]
        val cy = vp[1] * x + vp[5] * y + vp[9] * z + vp[13]
        val cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
        return Triple(cx / max(abs(cw), 0.0001f), cy / max(abs(cw), 0.0001f), cw)
    }

    private fun colorComp(l: Layer, key: String, def: Float, time: Float): Float {
        val tr = l.props[key]
        if (tr != null) return tr.eval(l.editTime(key, time))
        return def
    }

    private fun clamp01(v: Float): Float = min(max(v, 0f), 1f)

    /** Draws the particle field of `l` over `target`'s current content (the caller has cleared / drawn the source). */
    fun draw(l: Layer, time: Float, fov: Float, into: MetalTarget) {
        if (!ready) return
        val n = if (Xf.isParticular(l)) PtGroup.count({ l.p(it, l.editTime("x", time)) }) else 1
        for (gi in 0 until n) drawGroup(l, gi, time, fov, into)
    }

    private class Pt(var x: Float, var y: Float, var z: Float, var size: Float, var life: Float, var soft: Float,
                     var alpha: Float, var w: Float, var rot: Float, var vari: Float, var cr: Float, var cg: Float, var cb: Float)

    private fun drawGroup(l: Layer, gi: Int, time: Float, fov: Float, target: MetalTarget) {
        val pre = PtGroup.pre(gi)
        val ar = target.width.toFloat() / max(target.height, 1).toFloat()
        val lt = l.editTime("x", time)
        val isStr = Xf.isStrands(l)
        val isPtc = Xf.isParticular(l)
        val field = if (isPtc) ParticularSim.field({ l.p(pre + it, lt) }, simTime ?: time)
        else if (isStr) StrandsSim.field(l, lt, simTime ?: time)
        else ParticlesSim.field(count = l.p("pCount", lt).toInt(), spread = l.p("pSpread", lt),
                                speed = l.p("pSpeed", lt), gravity = l.p("pGravity", lt),
                                life = l.p("pLife", lt), seed = l.p("pSeed", lt),
                                dirX = l.p("pDirX", lt), dirY = l.p("pDirY", lt), t = simTime ?: time, ar = ar,
                                posX = l.p("pPosX", lt), posY = l.p("pPosY", lt), posZ = l.p("pPosZ", lt),
                                radX = l.p("pRadX", lt), radY = l.p("pRadY", lt), radZ = l.p("pRadZ", lt),
                                dirZ = l.p("pDirZ", lt), resist = l.p("pResist", lt),
                                wobble = l.p("pWobble", lt), sizeVar = l.p("pSizeVar", lt),
                                sizeEnd = l.p("pSizeEnd", lt), dof = l.p("pDof", lt),
                                focus = l.p("pFocus", lt),
                                burst = l.p("pBurst", lt), burstForce = l.p("pBurstForce", lt),
                                edge = l.p("pSoftEdge", lt))
        val m = Xf.matrix(l, time)
        val scene = Editor.scene
        val hasCam = MetalCam.vp(l, time, target.width, target.height) != null
        val vp = MetalCam.vpForModel(l, fov, time, target.width, target.height)
        if (vp.size != 16 || m.size < 6) return
        val use3D = hasCam || l.is3d
        val occlude = l.p(if (isPtc) "ptOcclude" else if (isStr) "stOcclude" else "pOcclude", lt) >= 0.5f
        // Occlude: particles behind a 3D layer / model are hidden by it.
        val blockers = ArrayList<FloatArray>()   // minX, minY, maxX, maxY, z
        if (occlude) {
            for (o in scene.layers) {
                if (o === l || !o.visible) continue
                if (time < o.start - 0.001f || time > o.end + 0.001f) continue
                if (!(o.is3d || o.type == LayerType.MODEL) || !o.isRenderable() || o.type == LayerType.PARTICLES || Xf.isParticles(o)) continue
                val ot = o.editTime("x", time)
                val sc = o.p("scale", ot)
                val (qw, qh) = Xf.quadSize(o)
                val hw = qw * sc * 0.5f; val hh = qh * sc * 0.5f
                val ox = o.p("x", ot); val oy = o.p("y", ot); val oz = Xf.worldZ(o, time)
                var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE
                var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
                var ok = true
                for ((sx, sy) in listOf(Pair(-hw, -hh), Pair(hw, -hh), Pair(hw, hh), Pair(-hw, hh))) {
                    val (px, py, pw) = projectPoint(vp, ox + sx, oy + sy, oz)
                    if (pw <= 0.01f) { ok = false; break }
                    minX = min(minX, px); maxX = max(maxX, px)
                    minY = min(minY, py); maxY = max(maxY, py)
                }
                if (ok) blockers.add(floatArrayOf(minX, minY, maxX, maxY, oz))
            }
        }
        val list = ArrayList<Pt>(field.size)
        val layerZ = Xf.worldZ(l, time)
        val pd = Math.PI.toFloat() / 180f
        val prx = l.p("rotX", lt) * pd; val pry = -l.p("rotY", lt) * pd
        val pcx = cos(prx); val psx = sin(prx); val pcy = cos(pry); val psy = sin(pry)
        val pRot = prx != 0f || pry != 0f
        for (q0 in field) {
            val q = q0
            var qx = q.x; var qy = q.y; var qz = q.z
            if (pRot) {
                val x1 = qx * pcy + qz * psy; val z1 = -qx * psy + qz * pcy
                val y2 = qy * pcx - z1 * psx; val z2 = qy * psx + z1 * pcx
                qx = x1; qy = y2; qz = z2
            }
            qz += layerZ
            var wx = m[0] * qx + m[2] * qy + m[4]
            var wy = m[1] * qx + m[3] * qy + m[5]
            var sz = q.size
            var w = 1f
            if (use3D) {
                val (sx, sy, pw) = projectPoint(vp, wx, wy, qz)
                if (pw <= 0.05f) continue
                w = pw
                if (occlude) {
                    var hidden = false
                    for (b in blockers) {
                        if (qz < b[4] - 0.001f && sx >= b[0] && sx <= b[2] && sy >= b[1] && sy <= b[3]) { hidden = true; break }
                    }
                    if (hidden) continue
                }
            } else {
                val pf = 1f / max(0.2f, 1 - qz / 3)
                wx *= pf; wy *= pf; sz *= pf
                w = 1f / pf
            }
            list.add(Pt(wx, wy, qz, sz, q.life, q.soft, q.alpha, w, q.rot, q.vari, q.cr, q.cg, q.cb))
        }
        if (list.isEmpty()) return
        if (use3D) list.sortByDescending { it.w }   // far -> near
        // PtU (11 vec4): vp0..3, a, b, colA, colB, c, d, e
        val u = FloatArray(44)
        System.arraycopy(vp, 0, u, 0, 16)
        u[16] = ar; u[17] = if (use3D) 0f else 1f
        u[18] = l.p(if (isPtc) pre + "ptSize" else if (isStr) "stSize" else "pSize", lt)
        u[19] = target.height * 0.5f
        u[20] = l.p(if (isPtc) pre + "ptOpacity" else if (isStr) "stOpacity" else "pOpacity", lt) * clamp01(l.p("opacity", lt))
        u[21] = if (isPtc) ParticularSim.fades({ l.p(pre + it, lt) }).first else max(0.001f, l.p(if (isStr) "stFadeIn" else "pFadeIn", lt))
        u[22] = if (isPtc) ParticularSim.fades({ l.p(pre + it, lt) }).second else max(0.001f, l.p(if (isStr) "stFadeOut" else "pFadeOut", lt))
        u[23] = 0f
        fun pcv(slot: Int, k: String, def: Int) {
            u[slot] = colorComp(l, k + "_r", ((def ushr 16) and 0xFF) / 255f, time)
            u[slot + 1] = colorComp(l, k + "_g", ((def ushr 8) and 0xFF) / 255f, time)
            u[slot + 2] = colorComp(l, k + "_b", (def and 0xFF) / 255f, time)
            u[slot + 3] = 1f
        }
        pcv(24, if (isPtc) pre + "ptColA" else if (isStr) "stColA" else "pColA", if (isPtc) ParticularSim.defA else if (isStr) 0xFFFFC857.toInt() else 0xFFFFFFFF.toInt())
        pcv(28, if (isPtc) pre + "ptColB" else if (isStr) "stColB" else "pColB", if (isPtc) ParticularSim.defB else if (isStr) 0xFF4FC3F7.toInt() else 0xFFFFFFFF.toInt())
        // Particular extras: sprite sheet, life gradient, per-particle (image) colour.
        var sprite: PtSpriteSet? = null
        var bumpH = 0L
        var gradLut: Array<FloatArray> = Array(16) { floatArrayOf(1f, 1f, 1f, 1f) }
        if (isPtc) {
            val g: (String) -> Float = { l.p(pre + it, lt) }
            sprite = PtSprites.set(g)
            val gr = PtGradient.active(g)
            if (gr != null) { gradLut = PtGradient.lut(gr); u[35] = 1f }
            val emT = Math.round(g("ptEmType")).toInt()
            u[32] = if (emT == 13 || emT == 14) g("ptImgColor") else (if (g("ptVolume") > 0.001f) 1f else 0f)
            u[33] = if (g("ptSpriteAnim") >= 0.5f) 1f else 0f
            u[34] = if (g("ptGrBy") >= 0.5f) 1f else 0f
            val sp = sprite
            if (sp != null) { u[28 + 8] = sp.cells.toFloat(); u[29 + 8] = sp.grid.toFloat(); u[30 + 8] = g("ptSpriteTint"); u[31 + 8] = 1f }
            if (sprite != null && g("ptBump") > 0.001f) bumpH = bumpTexture(g)
            val glow = g("ptGlow")
            u[23] = glow
            u[40] = if (bumpH != 0L) g("ptBump") else 0f
            u[41] = if (sprite != null) g("ptTumble") else 0f
            u[42] = g("ptVolLight") * Math.PI.toFloat() / 180f
            u[43] = if (glow > 0.001f) 1 + g("ptGlowSize") else 1f
        }
        val pts = FloatArray(list.size * 12)
        var o = 0
        for (q in list) {
            pts[o++] = q.x; pts[o++] = q.y; pts[o++] = q.z
            pts[o++] = q.size; pts[o++] = q.life; pts[o++] = q.soft; pts[o++] = q.alpha
            pts[o++] = q.rot; pts[o++] = q.vari; pts[o++] = q.cr; pts[o++] = q.cg; pts[o++] = q.cb
        }
        val gradFlat = FloatArray(64)
        for ((i, c) in gradLut.withIndex()) System.arraycopy(c, 0, gradFlat, i * 4, 4)
        val atlasTex = sprite?.let { spriteTexture(it) } ?: dummyTexture()
        SceneRendererN.particlePass(target.handle, u, pts, gradFlat, atlasTex, if (bumpH != 0L) bumpH else dummyTexture())
    }
}
