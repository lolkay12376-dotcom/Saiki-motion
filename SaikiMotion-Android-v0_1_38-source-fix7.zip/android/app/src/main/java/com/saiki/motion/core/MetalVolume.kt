package com.saiki.motion.core

import android.graphics.BitmapFactory
import com.saiki.motion.render.SceneRendererN
import kotlin.math.*

// Port of MetalVolume.swift MetalVolumeRenderer (slice 7p). Shader = shared/shaders/glsl/vdb.frag, pass in cpp/jni_model.cpp volumePass. Unbuilt/unverified.

class MetalVolumeRenderer {
    private val atlas = HashMap<String, Long>()     // path -> native Tex* (2048x1024, density in R)
    private val envs = HashMap<String, Long>()
    private var dummyTex = 0L                        // 1x1 (0,0,0,255)

    private fun dummy(): Long {
        if (dummyTex == 0L) dummyTex = NativeModel.texCreatePlain(1, 1, byteArrayOf(0, 0, 0, 255.toByte()))
        return dummyTex
    }

    /** MetalVolume.swift:189 `ready` (lib + dummyTex + dummyDepth): Vulkan twin = the compiled vdb.frag pipeline; the dummy textures are created lazily on first draw. */
    val ready: Boolean get() = SceneRendererN.pipelineReady("vdb.frag")

    fun trimMemory() { atlas.values.forEach { NativeModel.texFree(it) }; atlas.clear(); envs.values.forEach { NativeModel.texFree(it) }; envs.clear() }

    companion object {
        @JvmStatic fun inv4(m: FloatArray): FloatArray {
            val inv = FloatArray(16)
            inv[0] = m[5]*m[10]*m[15] - m[5]*m[11]*m[14] - m[9]*m[6]*m[15] + m[9]*m[7]*m[14] + m[13]*m[6]*m[11] - m[13]*m[7]*m[10]
            inv[4] = -m[4]*m[10]*m[15] + m[4]*m[11]*m[14] + m[8]*m[6]*m[15] - m[8]*m[7]*m[14] - m[12]*m[6]*m[11] + m[12]*m[7]*m[10]
            inv[8] = m[4]*m[9]*m[15] - m[4]*m[11]*m[13] - m[8]*m[5]*m[15] + m[8]*m[7]*m[13] + m[12]*m[5]*m[11] - m[12]*m[7]*m[9]
            inv[12] = -m[4]*m[9]*m[14] + m[4]*m[10]*m[13] + m[8]*m[5]*m[14] - m[8]*m[6]*m[13] - m[12]*m[5]*m[10] + m[12]*m[6]*m[9]
            inv[1] = -m[1]*m[10]*m[15] + m[1]*m[11]*m[14] + m[9]*m[2]*m[15] - m[9]*m[3]*m[14] - m[13]*m[2]*m[11] + m[13]*m[3]*m[10]
            inv[5] = m[0]*m[10]*m[15] - m[0]*m[11]*m[14] - m[8]*m[2]*m[15] + m[8]*m[3]*m[14] + m[12]*m[2]*m[11] - m[12]*m[3]*m[10]
            inv[9] = -m[0]*m[9]*m[15] + m[0]*m[11]*m[13] + m[8]*m[1]*m[15] - m[8]*m[3]*m[13] - m[12]*m[1]*m[11] + m[12]*m[3]*m[9]
            inv[13] = m[0]*m[9]*m[14] - m[0]*m[10]*m[13] - m[8]*m[1]*m[14] + m[8]*m[2]*m[13] + m[12]*m[1]*m[10] - m[12]*m[2]*m[9]
            inv[2] = m[1]*m[6]*m[15] - m[1]*m[7]*m[14] - m[5]*m[2]*m[15] + m[5]*m[3]*m[14] + m[13]*m[2]*m[7] - m[13]*m[3]*m[6]
            inv[6] = -m[0]*m[6]*m[15] + m[0]*m[7]*m[14] + m[4]*m[2]*m[15] - m[4]*m[3]*m[14] - m[12]*m[2]*m[7] + m[12]*m[3]*m[6]
            inv[10] = m[0]*m[5]*m[15] - m[0]*m[7]*m[13] - m[4]*m[1]*m[15] + m[4]*m[3]*m[13] + m[12]*m[1]*m[7] - m[12]*m[3]*m[5]
            inv[14] = -m[0]*m[5]*m[14] + m[0]*m[6]*m[13] + m[4]*m[1]*m[14] - m[4]*m[2]*m[13] - m[12]*m[1]*m[6] + m[12]*m[2]*m[5]
            inv[3] = -m[1]*m[6]*m[11] + m[1]*m[7]*m[10] + m[5]*m[2]*m[11] - m[5]*m[3]*m[10] - m[9]*m[2]*m[7] + m[9]*m[3]*m[6]
            inv[7] = m[0]*m[6]*m[11] - m[0]*m[7]*m[10] - m[4]*m[2]*m[11] + m[4]*m[3]*m[10] + m[8]*m[2]*m[7] - m[8]*m[3]*m[6]
            inv[11] = -m[0]*m[5]*m[11] + m[0]*m[7]*m[9] + m[4]*m[1]*m[11] - m[4]*m[3]*m[9] - m[8]*m[1]*m[7] + m[8]*m[3]*m[5]
            inv[15] = m[0]*m[5]*m[10] - m[0]*m[6]*m[9] - m[4]*m[1]*m[10] + m[4]*m[2]*m[9] + m[8]*m[1]*m[6] - m[8]*m[2]*m[5]
            val det = m[0]*inv[0] + m[1]*inv[4] + m[2]*inv[8] + m[3]*inv[12]
            if (abs(det) < 1e-12f) return floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
            return FloatArray(16) { inv[it] / det }
        }

        private fun mul4(a: FloatArray, b: FloatArray): FloatArray {
            val o = FloatArray(16)
            for (c in 0 until 4) for (r in 0 until 4) {
                var s = 0f
                for (k in 0 until 4) s += a[k * 4 + r] * b[c * 4 + k]
                o[c * 4 + r] = s
            }
            return o
        }
    }

    /** Density lattice -> 128^3 volume packed as a 16x8 atlas of 128x128 slices (same packing as GL). iOS r8Unorm; here RGBA8 with the value in R (the shader reads .r). */
    private fun atlasTexture(path: String, vol: VdbVolume): Long {
        atlas[path]?.let { return it }
        val g = vol.grids.firstOrNull() ?: return 0L
        if (g.nx <= 0 || g.ny <= 0 || g.nz <= 0) return 0L
        val n = 128
        var mx = 0.000001f
        for (v in g.data) if (v.isFinite()) mx = max(mx, v)
        val px = ByteArray(2048 * 1024 * 4)
        for (z in 0 until n) for (y in 0 until n) for (x in 0 until n) {
            val d = vol.density(x * g.nx / n, y * g.ny / n, z * g.nz / n)
            val v = if (d.isFinite()) min(max(d / mx, 0f), 1f) else 0f
            val o = ((z / 16 * 128 + y) * 2048 + (z % 16) * 128 + x) * 4
            val b = (sqrt(v) * 255f).toInt().toByte()
            px[o] = b; px[o + 1] = b; px[o + 2] = b; px[o + 3] = 255.toByte()
        }
        val t = NativeModel.texCreatePlain(2048, 1024, px)
        if (t != 0L) atlas[path] = t
        return t
    }

    /** Environment picture as an equirect texture (same loader as GL: max 1024 side, MetalModel.makeTexture). */
    private fun environmentTexture(path: String): Long {
        envs[path]?.let { return it }
        val bm = BitmapFactory.decodeFile(path) ?: return 0L
        val ct = MetalModel.makeTexture(bm) ?: return 0L
        val h = NativeModel.texCreate(ct.w, ct.h, ct.rgba)
        if (h != 0L) envs[path] = h
        return h
    }

    /**
     * Ray-marches volume layer `l` into `into` (the caller has cleared it unless accumulate). `depth` = MetalModelRenderer.occlusionDepth() (native DepthTex*, 0 = none),
     * `sceneTex` = the scene so far (for "surroundings" light).
     */
    fun draw(l: Layer, path: String, time: Float, fov: Float, into: MetalTarget, sceneTex: MetalTarget, depth: Long,
             mmOverride: FloatArray? = null, accumulate: Boolean = false) {
        val vol = VdbVolume.load(path) ?: return
        val tex = atlasTexture(path, vol); if (tex == 0L) return
        val vp = MetalCam.vpForModel(l, fov, time, into.width, into.height)
        val mm = mmOverride ?: MetalCam.modelMatrix(l, time, floatArrayOf(1f, 0f, 0f, 0f))
        if (vp.size != 16 || mm.size != 16) return
        val mvp = mul4(vp, mm)
        val inv = inv4(mvp)

        val u = FloatArray(92)   // VolU: 23 float4
        fun v4(s: Int, x: Float, y: Float, z: Float, w: Float) { val o = s * 4; u[o] = x; u[o + 1] = y; u[o + 2] = z; u[o + 3] = w }
        for (k in 0 until 4) v4(k, inv[k * 4], inv[k * 4 + 1], inv[k * 4 + 2], inv[k * 4 + 3])
        for (k in 0 until 4) v4(4 + k, mvp[k * 4], mvp[k * 4 + 1], mvp[k * 4 + 2], mvp[k * 4 + 3])
        val b0 = vol.bounds.first; val b1 = vol.bounds.second; val b2 = vol.bounds.third
        v4(8, max(b0, 0.05f) * 2, max(b1, 0.05f) * 2, max(b2, 0.05f) * 2, l.xf("vdbOpacity", 1f))
        var envTex = 0L
        if (l.vdbEnv) {
            val ep = l.vdbEnvPath ?: (if (l.xf("cloud", 0f) > 0.5f) GlobalEnv.path else null)
            if (!ep.isNullOrEmpty()) envTex = environmentTexture(ep)
        }
        val envOn = if (envTex != 0L) 1f else 0f
        val surOn = if (l.vdbEnv && l.vdbSurround) 1f else 0f
        v4(10, l.vdbDens * R3D.g("vdbDens", 1f), l.vdbBright * R3D.g("vdbBright", 1f), envOn, surOn)
        val c = l.vdbTint
        v4(9, ((c ushr 16) and 255) / 255f, ((c ushr 8) and 255) / 255f, (c and 255) / 255f, 1f)
        v4(11, if (depth != 0L) 1f else 0f, l.xf("vdbShadow", 1f), l.xf("vdbSteps", 56f) * R3D.g("vdbQuality", 1f), max(l.xf("vdbContrast", 1f), 0.1f))

        // light balls (3D Null layers flagged isLight): converted into this volume's local space
        val invM = inv4(mm)
        fun rgb(c: Int) = floatArrayOf(((c ushr 16) and 255) / 255f, ((c ushr 8) and 255) / 255f, (c and 255) / 255f)
        var nl = 0
        for (L in Editor.scene.layers) {
            if (!(L.isLight && L.visible && time >= L.start && time <= L.end && nl < 3)) continue
            val lt = L.editTime("x", time)
            var wx = L.p("x", lt); var wy = L.p("y", lt); var wz = Xf.worldZ(L, time)
            val isSun = L.xf("lightType", 0f).toInt() == 1
            if (isSun) { val d = Lights.direction(L); wx = -d[0] * 4000; wy = -d[1] * 4000; wz = -d[2] * 4000 }
            val px = invM[0] * wx + invM[4] * wy + invM[8] * wz + invM[12]
            val py = invM[1] * wx + invM[5] * wy + invM[9] * wz + invM[13]
            val pz = invM[2] * wx + invM[6] * wy + invM[10] * wz + invM[14]
            val sx = sqrt(invM[0] * invM[0] + invM[1] * invM[1] + invM[2] * invM[2])
            val inf = isSun || Lights.infinite(L)
            v4(12 + nl, px, py, pz, if (inf) 1e5f * sx else max(L.xf("lightRad", 0.5f) * sx, 0.01f))
            val t = Lights.tint(L); val k = L.xf("lightInt", 1f) * (if (inf) 0.1f else 1f)      // infinite lights are not distance-faded: keep clouds / smoke from blowing out to white
            v4(15 + nl, t[0] * k, t[1] * k, t[2] * k, 0f)
            val ac = rgb(L.xf("atmCol", 0x6688FF.toFloat()).toLong().toInt()); val am = L.xf("atmAmt", 0.3f)
            v4(18 + nl, ac[0] * am, ac[1] * am, ac[2] * am, 0f)
            nl++
        }
        v4(21, nl.toFloat(), if (l.xf("cloud", 0f) > 0.5f) 1f else 0f, if (l.xf("mist", 0f) > 0.5f) 1f else 0f, 0f)
        val ec = l.xf("cEdgeOut", 16777215f).toLong().toInt()
        v4(22, ((ec ushr 16) and 255) / 255f, ((ec ushr 8) and 255) / 255f, (ec and 255) / 255f, l.xf("cEdge", 0f))

        // only shade pixels inside the box's screen bounds (GL scissor; Metal's origin is top-left)
        val hb = floatArrayOf(max(b0, 0.05f), max(b1, 0.05f), max(b2, 0.05f))
        var x0 = Float.MAX_VALUE; var y0 = x0; var x1 = -x0; var y1 = -x0
        var ok = true
        for (i in 0 until 8) {
            if (!ok) break
            val x = (if (i and 1 == 0) -1 else 1) * hb[0]; val y = (if (i and 2 == 0) -1 else 1) * hb[1]; val z = (if (i and 4 == 0) -1 else 1) * hb[2]
            val w = mvp[3] * x + mvp[7] * y + mvp[11] * z + mvp[15]
            if (w < 0.05f) { ok = false; continue }
            val px = (mvp[0] * x + mvp[4] * y + mvp[8] * z + mvp[12]) / w
            val py = (mvp[1] * x + mvp[5] * y + mvp[9] * z + mvp[13]) / w
            x0 = min(x0, px); x1 = max(x1, px); y0 = min(y0, py); y1 = max(y1, py)
        }
        var scissor = IntArray(0)
        if (ok) {
            val W = into.width.toFloat(); val H = into.height.toFloat()
            val fx0 = (x0 * 0.5f + 0.5f) * W; val fx1 = (x1 * 0.5f + 0.5f) * W
            val fy0 = (y0 * 0.5f + 0.5f) * H; val fy1 = (y1 * 0.5f + 0.5f) * H
            if (!fx0.isFinite() || !fx1.isFinite() || !fy0.isFinite() || !fy1.isFinite()) return
            val sx = max(0, fx0.toInt() - 3); val sy = max(0, fy0.toInt() - 3)
            val ex = min(into.width, fx1.toInt() + 3); val ey = min(into.height, fy1.toInt() + 3)
            if (ex <= sx || ey <= sy) return
            scissor = intArrayOf(sx, into.height - ey, ex - sx, ey - sy)
        }
        val d = dummy(); if (d == 0L) return
        NativeModel.volumePass(into.handle, accumulate, u, tex, depth, if (envTex != 0L) envTex else d, sceneTex.tex, scissor)
    }
}
