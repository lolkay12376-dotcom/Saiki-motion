package com.saiki.motion.core

import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Port of Sources/Render/MistGen.swift — procedural ground mist / mist / valley fog / haze volumes.
 * Spec file text: "SAIKIMIST kind seed height fall cover scale detail warp edge stretch dir"
 */
object MistGen {
    @JvmField val kinds = listOf("Ground mist", "Mist bank", "Valley fog", "Haze")

    private fun hash(x: Int, y: Int, z: Int, s: Int): Float {
        var h = x * 374761393 + y * 668265263 + z * 1274126177 + s * 362437
        h = (h xor (h ushr 13)) * 1274126177; h = h xor (h ushr 16)
        return (h and 0xFFFFFF).toFloat() / 0xFFFFFF.toFloat()
    }
    private fun noise(x: Float, y: Float, z: Float, s: Int): Float {
        val xi = floor(x).toInt(); val yi = floor(y).toInt(); val zi = floor(z).toInt()
        val fx = x - xi.toFloat(); val fy = y - yi.toFloat(); val fz = z - zi.toFloat()
        val u = fx * fx * (3 - 2 * fx); val v = fy * fy * (3 - 2 * fy); val w = fz * fz * (3 - 2 * fz)
        fun h(a: Int, b: Int, c: Int): Float = hash(xi + a, yi + b, zi + c, s)
        val x00 = h(0, 0, 0) + (h(1, 0, 0) - h(0, 0, 0)) * u; val x10 = h(0, 1, 0) + (h(1, 1, 0) - h(0, 1, 0)) * u
        val x01 = h(0, 0, 1) + (h(1, 0, 1) - h(0, 0, 1)) * u; val x11 = h(0, 1, 1) + (h(1, 1, 1) - h(0, 1, 1)) * u
        val y0 = x00 + (x10 - x00) * v; val y1 = x01 + (x11 - x01) * v
        return y0 + (y1 - y0) * w
    }
    private fun fbm(x: Float, y: Float, z: Float, s: Int): Float {
        var a = 0.5f; var f = 1f; var r = 0f
        for (i in 0 until 4) { r += a * noise(x * f, y * f, z * f, s); f *= 2.03f; a *= 0.5f }
        return r / 0.9375f
    }
    private fun sstep(a: Float, b: Float, x: Float): Float {
        val t = min(max((x - a) / max(b - a, 1e-4f), 0f), 1f); return t * t * (3 - 2 * t)
    }

    @JvmStatic fun make(spec: String): VdbVolume {
        val p = spec.split(' ').filter { it.isNotEmpty() }.drop(1).map { parseSwiftFloat(it) ?: 0f }
        fun a(i: Int, d: Float): Float = if (i < p.size) p[i] else d
        val kind = a(0, 0f).toInt(); val seed = a(1, 1f).toInt()
        val height = max(a(2, 0.3f), 0.04f); val fall = a(3, 2.5f); val cover = a(4, 0.6f); val scale = max(a(5, 1f), 0.2f)
        val detail = a(6, 0.5f); val warp = a(7, 0.4f); val edge = max(a(8, 0.25f), 0.03f); val stretch = a(9, 0.3f); val dir = a(10, 0f) * Math.PI.toFloat() / 180
        val nx = 128; val ny = 40; val nz = 128
        val g = VdbVolume.Grid(); g.nx = nx; g.ny = ny; g.nz = nz; g.voxelSize = 1f
        val data = FloatArray(nx * ny * nz)
        val cd = cos(dir); val sd = sin(dir); val sx = 1 - 0.75f * min(max(stretch, 0f), 1f)
        // per-column work (warp offsets, edge fade, valley pooling) is done once, not per voxel
        val colX = FloatArray(nx * nz); val colZ = FloatArray(nx * nz); val colF = FloatArray(nx * nz); val colP = FloatArray(nx * nz)
        for (z in 0 until nz) for (x in 0 until nx) {
            val fx = x.toFloat() / (nx - 1).toFloat(); val fz = z.toFloat() / (nz - 1).toFloat()
            val wx = (fbm(fx * 2.2f * scale, 3.1f, fz * 2.2f * scale, seed + 7) - 0.5f) * warp * 1.6f
            val wz = (fbm(fx * 2.2f * scale, 9.7f, fz * 2.2f * scale, seed + 13) - 0.5f) * warp * 1.6f
            val fade = sstep(0f, edge, min(fx, 1 - fx)) * sstep(0f, edge, min(fz, 1 - fz))
            val pool = if (kind == 2) 0.35f + 1.3f * fbm(fx * 1.3f * scale, 5.5f, fz * 1.3f * scale, seed + 21) else 1f
            val k = x + nx * z
            colX[k] = wx; colZ[k] = wz; colF[k] = fade; colP[k] = pool
        }
        java.util.stream.IntStream.range(0, nz).parallel().forEach { z ->
            val fz = z.toFloat() / (nz - 1).toFloat()
            for (y in 0 until ny) {
                val fy = y.toFloat() / (ny - 1).toFloat()
                for (x in 0 until nx) {
                    val fx = x.toFloat() / (nx - 1).toFloat()
                    val ci = x + nx * z
                    val cx = colX[ci]; val cy = colZ[ci]; val cz = colF[ci]; val cw = colP[ci]
                    if (cz <= 0.001f) continue
                    val v = fy / (height * cw)
                    if (v >= 1) continue
                    val prof: Float = when (kind) {
                        1 -> sstep(0f, 0.18f, v) * (1 - sstep(0.55f, 1f, v))                  // floating bank, soft top and bottom
                        3 -> (1 - v * v) * 0.8f                                               // haze: gentle, almost uniform
                        else -> exp(-v * fall) * (1 - sstep(0.6f, 1f, v))                     // hugs the ground, thins upward
                    }
                    val rx = (fx - 0.5f + cx) * cd - (fz - 0.5f + cy) * sd; val rz = (fx - 0.5f + cx) * sd + (fz - 0.5f + cy) * cd
                    val u = rx * 3.4f * scale * sx + 40; val w = rz * 3.4f * scale + 40
                    var n = fbm(u, fy * 2.5f * scale + seed.toFloat(), w, seed)
                    n += (noise(u * 5, fy * 7, w * 5, seed + 3) - 0.5f) * detail * 0.55f          // fine wisps
                    n += (noise(u * 11, fy * 14, w * 11, seed + 5) - 0.5f) * detail * 0.25f
                    val t = 1 - min(max(cover, 0f), 1f)
                    val d = sstep(t - 0.18f, t + 0.3f, n)
                    data[x + nx * (y + ny * z)] = d * prof * cz * (if (kind == 3) 0.6f else 1f)
                }
            }
        }
        g.data = data
        val vol = VdbVolume(); vol.grids = listOf(g)
        vol.bounds = Triple(1f, 0.3f, 1f)
        return vol
    }
}

/** Mist settings live on the layer (x3s keys): shape keys rebuild the volume (debounced), look keys are live. */
object MistSettings {
    @JvmField val shapeKeys = listOf("mHeight", "mFall", "mCover", "mScale", "mDetail", "mWarp", "mEdge", "mStretch", "mDir")
    /** height, fall, cover, scale, detail, warp, edge, stretch, dir */
    @JvmField val defaults: Map<Int, FloatArray> = mapOf(
        0 to floatArrayOf(0.22f, 3.0f, 0.62f, 1.0f, 0.6f, 0.5f, 0.25f, 0.35f, 20f),
        1 to floatArrayOf(0.55f, 2.0f, 0.55f, 0.9f, 0.5f, 0.45f, 0.25f, 0.3f, 0f),
        2 to floatArrayOf(0.45f, 2.5f, 0.7f, 0.7f, 0.45f, 0.6f, 0.2f, 0.2f, 0f),
        3 to floatArrayOf(0.9f, 1.0f, 0.8f, 0.5f, 0.25f, 0.3f, 0.3f, 0.1f, 0f))
    @JvmField val looks = listOf("Neutral", "Cool morning", "Warm sunrise", "Swamp", "Dusk")

    /** Swift "\(Float)" description: shortest repr, no exponent for ordinary magnitudes. */
    private fun fs(v: Float): String = JSONWriter.swiftDescF(v)

    @JvmStatic fun writeFile(l: Layer): String? {
        val kind = l.xf("mKind", 0f).toInt()
        var s = "SAIKIMIST $kind ${l.xf("mSeed", 1f).toInt()}"
        for ((i, k) in shapeKeys.withIndex()) s += " " + fs(l.xf(k, defaults[kind]?.get(i) ?: 0.5f))
        return ProjectIO.writeDataIntoSandbox(s.toByteArray(Charsets.UTF_8), "mist_${nowMs()}.vdb")
    }

    @JvmStatic fun setup(l: Layer, kind: Int) {
        l.xset("mist", 1f); l.xset("mKind", kind.toFloat()); l.xset("mSeed", (nowMs() % 9973).toFloat())
        for ((i, k) in shapeKeys.withIndex()) l.xset(k, defaults[kind]!![i])
        applyLook(l, 0)
        l.vdbDens = if (kind == 3) 0.6f else 1.4f; l.vdbEnv = true; l.vdbSurround = true
        l.xset("vdbSteps", 48f); l.xset("vdbShadow", 0.6f); l.xset("vdbContrast", 0.8f)
    }

    @JvmStatic fun applyLook(l: Layer, i: Int) {
        val t = listOf(0xFFE6EAEE.toInt() to 1.0f, 0xFFC8D8EC.toInt() to 1.0f, 0xFFFFD8B0.toInt() to 1.3f, 0xFFB4C89A.toInt() to 0.85f, 0xFFB09CD0.toInt() to 0.8f)
        l.vdbTint = t[i].first; l.vdbBright = t[i].second
    }

    private val pool = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "mist-rebuild").also { it.isDaemon = true } }
    private var work: ScheduledFuture<*>? = null
    private val main = android.os.Handler(android.os.Looper.getMainLooper())

    /** New shape after the slider settles: build off the main thread, then swap the file in. */
    @JvmStatic @Synchronized fun rebuildSoon(l: Layer, done: () -> Unit) {
        work?.cancel(false)
        work = pool.schedule({
            val p = writeFile(l)
            if (p != null) {
                VdbVolume.load(p)
                main.post {
                    val old = l.imagePath
                    l.imagePath = p
                    if (old != null) { VdbVolume.evict(old); try { File(old).delete() } catch (_: Exception) {} }
                    done()
                }
            }
        }, 300, TimeUnit.MILLISECONDS)
    }
}
