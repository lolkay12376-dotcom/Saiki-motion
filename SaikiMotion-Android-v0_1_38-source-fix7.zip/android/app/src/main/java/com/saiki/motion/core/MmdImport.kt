package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.CodingErrorAction
import java.util.Locale
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * MmdImport.swift — MikuMikuDance import (.pmx / .mmd model + .vmd motion) -> GLB (+ ".anim" baked sidecar). Line-for-line port.
 * UIImage/ImageIO/CGContext -> Bitmap/BitmapFactory (pixel copies = scale + premultiply, like FbxImport).
 * PARITY-NOTE(MmdImport.swift:480,542): simd_slerp / simd_quatf are re-implemented as shortest-arc slerp in Float; rounding and
 * quaternion sign can differ from simd by ULPs (the represented rotation is the same).
 * bakeVmd streams the ".anim" to disk where iOS builds it in memory first — the written bytes are identical.
 */
object MmdImport {
    @JvmStatic var lastError = ""

    // MARK: binary reader
    private class R(val b: ByteArray) {
        var p = 0
        fun u8(): Int { val v = if (p < b.size) (b[p].toInt() and 0xFF) else 0; p += 1; return v }
        fun u16(): Int { val v = u8(); return v or (u8() shl 8) }
        fun i32(): Int { val lo = u16(); return lo or (u16() shl 16) }
        fun f(): Float = java.lang.Float.intBitsToFloat(i32())
        fun v3(): V3 { val x = f(); val y = f(); val z = f(); return V3(x, y, z) }
        fun idx(size: Int, signed: Boolean = true): Int = when (size) {
            1 -> { val v = u8(); if (signed) v.toByte().toInt() else v }
            2 -> { val v = u16(); if (signed) v.toShort().toInt() else v }
            else -> i32()
        }
        fun bytes(n: Int): ByteArray {
            val e = min(b.size, p + max(n, 0)); val s = min(p, e); p = e
            return b.copyOfRange(s, e)
        }
    }

    private class Link(val idx: Int, val has: Boolean, val lo: V3, val hi: V3)
    private class Bone {
        var name = ""; var pos = V3.ZERO; var parent = -1; var layer = 0; var flags = 0
        var inhParent = -1; var inhInfl = 0f
        var ikTarget = -1; var ikLoop = 0; var ikLimit = 0f; val ikLinks = ArrayList<Link>()
    }
    private class Vtx { var p = V3.ZERO; var n = V3(0f, 1f, 0f); var u = 0f; var v = 0f; var bi = IntArray(0); var bw = FloatArray(0) }
    private class Mat {
        var name = ""; var diff = floatArrayOf(1f, 1f, 1f, 1f); var spec = V3.ZERO; var power = 5f
        var amb = V3.ZERO; var flags = 0; var tex = -1; var sphere = -1; var sphereMode = 0; var count = 0
    }
    private class Prim { val gv = ArrayList<Int>(); val idx = ArrayList<Int>() }

    private fun strict(b: ByteArray, cs: String): String? = try {
        java.nio.charset.Charset.forName(cs).newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(b)).toString()
    } catch (_: Exception) { null }

    private fun clamp01(v: Float) = min(max(v, 0f), 1f)
    private fun farr(vararg v: Float) = JSONArray().also { a -> for (x in v) a.put(x) }
    private fun lastComp(p: String) = p.substringAfterLast('/')
    private fun delExt(p: String): String {
        val n = lastComp(p); val i = n.lastIndexOf('.')
        return if (i <= 0) p else p.substring(0, p.length - (n.length - i))
    }
    private fun pathExt(p: String): String { val n = lastComp(p); val i = n.lastIndexOf('.'); return if (i <= 0) "" else n.substring(i + 1) }

    private fun png(b: Bitmap): ByteArray? = try { val o = ByteArrayOutputStream(); if (b.compress(Bitmap.CompressFormat.PNG, 100, o)) o.toByteArray() else null } catch (_: Exception) { null }

    /** RGBA premultiplied pixels scaled to w x h (CGContext draw). */
    private fun pixels(img: Bitmap, w: Int, h: Int): ByteArray {
        val s = if (img.width == w && img.height == h) img else Bitmap.createScaledBitmap(img, w, h, true)
        val px = IntArray(w * h); s.getPixels(px, 0, w, 0, 0, w, h)
        val d = ByteArray(w * h * 4)
        for (i in 0 until w * h) {
            val p = px[i]; val a = (p ushr 24) and 0xFF
            val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val bl = p and 0xFF
            d[i * 4] = ((r * a + 127) / 255).toByte(); d[i * 4 + 1] = ((g * a + 127) / 255).toByte()
            d[i * 4 + 2] = ((bl * a + 127) / 255).toByte(); d[i * 4 + 3] = a.toByte()
        }
        return d
    }
    private fun pngFromPixels(d: ByteArray, w: Int, h: Int): ByteArray? {
        val px = IntArray(w * h)
        for (i in 0 until w * h) {
            val a = d[i * 4 + 3].toInt() and 0xFF
            var r = d[i * 4].toInt() and 0xFF; var g = d[i * 4 + 1].toInt() and 0xFF; var bl = d[i * 4 + 2].toInt() and 0xFF
            if (a == 0) { r = 0; g = 0; bl = 0 } else if (a < 255) { r = min(255, (r * 255 + a / 2) / a); g = min(255, (g * 255 + a / 2) / a); bl = min(255, (bl * 255 + a / 2) / a) }
            px[i] = (a shl 24) or (r shl 16) or (g shl 8) or bl
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPremultiplied(false); bmp.setPixels(px, 0, w, 0, 0, w, h)
        return png(bmp)
    }


    private fun T(v: V3): M4 { val m = M4.identity(); m.setCol(3, V4(v.x, v.y, v.z, 1f)); return m }
    private fun qdot(a: Quat, b: Quat) = a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w
    private fun slerp(a: Quat, b0: Quat, t: Float): Quat {
        var b = b0; var d = qdot(a, b)
        if (d < 0f) { b = Quat(-b.x, -b.y, -b.z, -b.w); d = -d }
        if (d > 0.9995f) return Quat(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.z + (b.z - a.z) * t, a.w + (b.w - a.w) * t).normalized()
        val th = acos(d); val s = sin(th); val wa = sin((1 - t) * th) / s; val wb = sin(t * th) / s
        return Quat(a.x * wa + b.x * wb, a.y * wa + b.y * wb, a.z * wa + b.z * wb, a.w * wa + b.w * wb)
    }

    /** Returns the .glb written beside the model (cached by modification date), or null with lastError set. */
    @JvmStatic fun convert(path: String, vmd: String? = null): String? {
        lastError = ""
        val stem = delExt(path)
        val vtag = vmd?.let { v ->
            "_" + delExt(lastComp(v)).map { c -> if (c.code < 128 && (c in 'a'..'z' || c in 'A'..'Z' || c in '0'..'9')) c else 'x' }.take(24).joinToString("")
        } ?: ""
        val out = stem + "_mmd" + vtag + ".glb"
        val dir = File(path).parent ?: ""
        val vmdPath = vmd ?: findVmd(stem, dir)
        fun mod(p: String?): Long? = p?.let { val f = File(it); if (f.exists()) f.lastModified() else null }
        run {
            val o = mod(out); val a = mod(path)
            if (Skeleton3D.sidecarVersion("$out.skel") >= 2 && o != null && a != null && o > a && (mod(vmdPath)?.let { o > it } ?: true)) return out
        }
        val data = try { File(path).readBytes() } catch (_: Exception) { null }
        if (data == null || data.size <= 100) { lastError = "Cannot read the MMD file"; return null }
        val r = R(data)
        if (!r.bytes(4).contentEquals("PMX ".toByteArray(Charsets.UTF_8))) {
            lastError = "Only PMX models are supported (PMD: convert it to PMX in PMX Editor)"; return null
        }
        r.f()
        val gn = r.u8()
        val g = IntArray(8) { 1 }
        for (i in 0 until gn) { val v = r.u8(); if (i < 8) g[i] = v }
        val utf8 = g[0] == 1; val uvAdd = g[1]; val vS = g[2]; val tS = g[3]; val mS = g[4]; val bS = g[5]
        fun text(r: R): String {
            val n = r.i32(); if (!(n > 0 && n < 1_000_000)) return ""
            return strict(r.bytes(n), if (utf8) "UTF-8" else "UTF-16LE") ?: ""
        }
        for (i in 0 until 4) text(r)

        val vc = r.i32()
        if (!(vc > 0 && vc < 3_000_000)) {
            val sz = File(path).length()
            lastError = if (vc == 0 && sz < 4096) "This .pmx is an empty placeholder (a texture pack, not a model). Import the actual character .pmx or its zip." else "PMX has no vertices"
            return null
        }
        val vs = ArrayList<Vtx>(vc)
        for (i in 0 until vc) {
            val v = Vtx()
            v.p = r.v3(); v.n = r.v3(); v.u = r.f(); v.v = r.f()
            for (k in 0 until uvAdd * 4) r.f()
            when (r.u8()) {
                0 -> { v.bi = intArrayOf(r.idx(bS)); v.bw = floatArrayOf(1f) }
                1 -> { val a = r.idx(bS); val b = r.idx(bS); val w = r.f(); v.bi = intArrayOf(a, b); v.bw = floatArrayOf(w, 1 - w) }
                2, 4 -> { val a = r.idx(bS); val b = r.idx(bS); val c = r.idx(bS); val d = r.idx(bS)
                    v.bi = intArrayOf(a, b, c, d); val w0 = r.f(); val w1 = r.f(); val w2 = r.f(); val w3 = r.f(); v.bw = floatArrayOf(w0, w1, w2, w3) }
                3 -> { val a = r.idx(bS); val b = r.idx(bS); val w = r.f(); v.bi = intArrayOf(a, b); v.bw = floatArrayOf(w, 1 - w)
                    r.v3(); r.v3(); r.v3() }
                else -> { lastError = "Unsupported PMX vertex weights"; return null }
            }
            r.f()
            vs.add(v)
        }
        val ic = r.i32()
        if (!(ic >= 3 && ic < 30_000_000)) { lastError = "PMX has no faces"; return null }
        val faces = IntArray(ic)
        for (i in 0 until ic) faces[i] = r.idx(vS, signed = false)
        val texNames = ArrayList<String>()
        run { val n = r.i32(); for (i in 0 until n) texNames.add(text(r)) }
        val mats = ArrayList<Mat>()
        run {
            val n = r.i32()
            for (i in 0 until n) {
                val m = Mat()
                m.name = text(r); text(r)
                val d0 = r.f(); val d1 = r.f(); val d2 = r.f(); val d3 = r.f(); m.diff = floatArrayOf(d0, d1, d2, d3)
                m.spec = r.v3(); m.power = r.f(); m.amb = r.v3()
                m.flags = r.u8()
                for (k in 0 until 5) r.f()
                m.tex = r.idx(tS); m.sphere = r.idx(tS); m.sphereMode = r.u8()
                if (r.u8() == 0) r.idx(tS) else r.u8()
                text(r)
                m.count = r.i32()
                mats.add(m)
            }
        }
        val bones = ArrayList<Bone>()
        run {
            val n = r.i32()
            for (i in 0 until n) {
                val b = Bone()
                b.name = text(r); text(r)
                b.pos = r.v3(); b.parent = r.idx(bS); b.layer = r.i32(); b.flags = r.u16()
                if (b.flags and 1 != 0) r.idx(bS) else r.v3()
                if (b.flags and 0x300 != 0) { b.inhParent = r.idx(bS); b.inhInfl = r.f() }
                if (b.flags and 0x400 != 0) r.v3()
                if (b.flags and 0x800 != 0) { r.v3(); r.v3() }
                if (b.flags and 0x2000 != 0) r.i32()
                if (b.flags and 0x20 != 0) {
                    b.ikTarget = r.idx(bS); b.ikLoop = r.i32(); b.ikLimit = r.f()
                    val ln = max(0, min(r.i32(), 64))
                    for (k in 0 until ln) {
                        val li = r.idx(bS); val has = r.u8() != 0
                        var lo = V3.ZERO; var hi = V3.ZERO
                        if (has) { lo = r.v3(); hi = r.v3() }
                        b.ikLinks.add(Link(li, has, lo, hi))
                    }
                }
                bones.add(b)
            }
        }
        if (r.p > r.b.size) { lastError = "PMX file is truncated"; return null }

        // morphs and display frames are skipped; rigid bodies + joints feed the physics (hair, skirts, ribbons)
        var rbodies = ArrayList<PmxBody>(); var rjoints = ArrayList<PmxJoint>()
        run {
            val mrS = g[6]; val rbS = g[7]
            var ok = true
            val nmo = r.i32()
            if (nmo < 0 || nmo > 200_000) ok = false
            var mi = 0
            while (ok && mi < nmo) {
                mi += 1
                text(r); text(r); r.u8()
                val type = r.u8(); val cnt = r.i32()
                if (cnt < 0 || cnt > 10_000_000 || r.p > r.b.size) { ok = false; break }
                for (k in 0 until cnt) {
                    when (type) {
                        0, 9 -> { r.idx(mrS); r.f() }
                        1 -> { r.idx(vS, signed = false); r.v3() }
                        2 -> { r.idx(bS); r.v3(); for (q in 0 until 4) r.f() }
                        3, 4, 5, 6, 7 -> { r.idx(vS, signed = false); for (q in 0 until 4) r.f() }
                        8 -> { r.idx(mS); r.u8(); for (q in 0 until 28) r.f() }
                        10 -> { r.idx(rbS); r.u8(); r.v3(); r.v3() }
                        else -> ok = false
                    }
                    if (!ok) break
                }
                if (r.p > r.b.size) ok = false
            }
            if (ok) {
                val nfr = r.i32()
                if (nfr < 0 || nfr > 100_000) ok = false
                var fi = 0
                while (ok && fi < nfr) {
                    fi += 1
                    text(r); text(r); r.u8()
                    val c = r.i32()
                    if (c < 0 || c > 1_000_000 || r.p > r.b.size) { ok = false; break }
                    for (k in 0 until c) { if (r.u8() == 0) r.idx(bS) else r.idx(mrS) }
                }
            }
            if (ok) {
                val nrb = r.i32()
                if (nrb < 0 || nrb > 100_000) ok = false
                var bi = 0
                while (ok && bi < nrb) {
                    bi += 1
                    text(r); text(r)
                    val bone = r.idx(bS); val grp = r.u8(); val mask = r.u16(); val shape = r.u8()
                    val size = r.v3(); val p = r.v3(); val re = r.v3()
                    val mass = r.f(); val ld = r.f(); val ad = r.f(); val rep = r.f(); val fr = r.f(); val mode = r.u8()
                    // PMX is left-handed: z is flipped like the vertices, so the x / y rotation angles change sign
                    val q = Quat.angleAxis(-re.y, V3(0f, 1f, 0f)) * Quat.angleAxis(-re.x, V3(1f, 0f, 0f)) * Quat.angleAxis(re.z, V3(0f, 0f, 1f))
                    rbodies.add(PmxBody(if (bone >= 0 && bone < bones.size) bone else -1, min(max(grp, 0), 15), mask, shape,
                        size, V3(p.x, p.y, -p.z), q, mass, ld, ad, rep, fr, mode))
                    if (r.p > r.b.size) ok = false
                }
            }
            if (ok) {
                val njt = r.i32()
                if (njt < 0 || njt > 200_000) ok = false
                var ji = 0
                while (ok && ji < njt) {
                    ji += 1
                    text(r); text(r); r.u8()
                    val a = r.idx(rbS); val b = r.idx(rbS)
                    val p = r.v3(); r.v3()
                    val ml = r.v3(); val mh = r.v3(); val rl = r.v3(); val rh = r.v3(); val sm = r.v3(); val sr = r.v3()
                    rjoints.add(PmxJoint(a, b, V3(p.x, p.y, -p.z), ml, mh, rl, rh, sm, sr))
                    if (r.p > r.b.size) ok = false
                }
            }
            if (!ok || r.p > r.b.size) { rbodies = ArrayList(); rjoints = ArrayList() }
        }

        // folder index for textures / PBR maps
        val files = HashMap<String, String>()                 // lowercased relative path & file name -> path
        val dirF = File(dir)
        if (dirF.isDirectory) {
            for (f in dirF.walkTopDown()) {
                if (f == dirF) continue
                val rel = f.relativeTo(dirF).path.replace('\\', '/')
                val full = "$dir/$rel"
                files[rel.lowercase(Locale.ROOT)] = full
                val bn = lastComp(rel).lowercase(Locale.ROOT)
                files[bn] = files[bn] ?: full
            }
        }
        fun resolve(name: String): String? {
            val n = name.replace("\\", "/")
            if (File("$dir/$n").exists()) return "$dir/$n"
            return files[n.lowercase(Locale.ROOT)] ?: files[lastComp(n).lowercase(Locale.ROOT)]
        }
        fun loadImage(p: String): Bitmap? = BitmapFactory.decodeFile(p)
        fun sibling(basePath: String, suffixes: List<String>): Bitmap? {
            val d = File(basePath).parent ?: ""
            val st = delExt(lastComp(basePath)).lowercase(Locale.ROOT)
            for (s in suffixes) for (e in listOf("png", "jpg", "jpeg", "tga", "bmp")) {
                val k = "$st$s.$e"
                val f = files[k] ?: files[lastComp(d).lowercase(Locale.ROOT) + "/" + k]
                if (f != null) { val im = loadImage(f); if (im != null) return im }
            }
            return null
        }

        // GLB assembly
        val bin = ByteArrayOutputStream()
        val views = JSONArray(); val accs = JSONArray(); val images = JSONArray(); val textures = JSONArray()
        fun addView(bytes: ByteArray, target: Int? = null): Int {
            while (bin.size() % 4 != 0) bin.write(0)
            val v = JSONObject().put("buffer", 0).put("byteOffset", bin.size()).put("byteLength", bytes.size)
            if (target != null) v.put("target", target)
            bin.write(bytes); views.put(v); return views.length() - 1
        }
        fun fb(a: FloatArray): ByteArray { val bb = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (v in a) bb.putFloat(v); return bb.array() }
        val texCache = HashMap<ByteBuffer, Int>()
        fun addTex(d: ByteArray): Int {
            val key = ByteBuffer.wrap(d)
            texCache[key]?.let { return it }
            val v = addView(d)
            images.put(JSONObject().put("bufferView", v).put("mimeType", "image/png")); textures.put(JSONObject().put("source", images.length() - 1))
            texCache[key] = textures.length() - 1; return textures.length() - 1
        }
        val matJson = JSONArray()
        fun glMat(m: Mat): JSONObject {
            val pbr = JSONObject()
            val j = JSONObject().put("doubleSided", true)
            val a = clamp01(m.diff[3])
            val specL = (m.spec.x + m.spec.y + m.spec.z) / 3
            var rough = min(max(1 - (min(m.power, 120f) / 120) * min(specL * 1.5f, 1f) * 0.9f, 0.3f), 0.95f)
            var metal = if (m.sphere >= 0 && m.sphereMode >= 2) 0.25f else 0f
            var base: Bitmap? = null; var basePath = ""
            if (m.tex >= 0 && m.tex < texNames.size) { val p = resolve(texNames[m.tex]); if (p != null) { base = loadImage(p); basePath = p } }
            pbr.put("baseColorFactor", farr(m.diff[0], m.diff[1], m.diff[2], a))
            val bd = base?.let { png(it) }
            if (base != null && bd != null) {
                pbr.put("baseColorTexture", JSONObject().put("index", addTex(bd))); pbr.put("baseColorFactor", farr(m.diff[0], m.diff[1], m.diff[2], a))
                j.put("alphaMode", if (a < 0.999f) "BLEND" else "MASK"); j.put("alphaCutoff", 0.5)
            } else if (a < 0.999f) j.put("alphaMode", "BLEND")
            if (basePath.isNotEmpty() && base != null) {
                val w = min(2048, max(1, base.width)); val h = min(2048, max(1, base.height))
                sibling(basePath, listOf("_normal", "_n", "_nrm", "_nor"))?.let { n -> png(n)?.let { d -> j.put("normalTexture", JSONObject().put("index", addTex(d))) } }
                sibling(basePath, listOf("_emissive", "_emit", "_e", "_emission"))?.let { e -> png(e)?.let { d -> j.put("emissiveTexture", JSONObject().put("index", addTex(d))); j.put("emissiveFactor", farr(1f, 1f, 1f)) } }
                val orm = sibling(basePath, listOf("_orm", "_rma"))
                val ao = sibling(basePath, listOf("_ao", "_occlusion", "_occ"))
                val ri = sibling(basePath, listOf("_roughness", "_rough", "_r")); val mi = sibling(basePath, listOf("_metallic", "_metal", "_m"))
                val od = orm?.let { png(it) }
                if (orm != null && od != null) {
                    pbr.put("metallicRoughnessTexture", JSONObject().put("index", addTex(od))); rough = 1f; metal = 1f
                    j.put("occlusionTexture", JSONObject().put("index", addTex(od)))
                } else if (ri != null || mi != null) {
                    val d = ByteArray(w * h * 4) { 255.toByte() }
                    val rp = ri?.let { pixels(it, w, h) }; val mp = mi?.let { pixels(it, w, h) }
                    for (i in 0 until w * h) {
                        d[i * 4] = 255.toByte()
                        d[i * 4 + 1] = rp?.get(i * 4) ?: (rough * 255).toInt().toByte()
                        d[i * 4 + 2] = mp?.get(i * 4) ?: (metal * 255).toInt().toByte()
                    }
                    val data2 = pngFromPixels(d, w, h)
                    if (data2 != null) { pbr.put("metallicRoughnessTexture", JSONObject().put("index", addTex(data2))); rough = 1f; metal = 1f }
                }
                if (!j.has("occlusionTexture") && ao != null) { png(ao)?.let { d -> j.put("occlusionTexture", JSONObject().put("index", addTex(d))) } }
            }
            pbr.put("roughnessFactor", rough); pbr.put("metallicFactor", metal)
            j.put("pbrMetallicRoughness", pbr)
            return j
        }

        // primitives: one per material, own vertex subset (so the baked animation indexes them directly)
        val prims = JSONArray(); val pinfo = ArrayList<Prim>()
        var fi = 0
        for (m in mats) {
            val n = min(m.count, faces.size - fi)
            if (n < 3) { fi += max(m.count, 0); continue }
            val remap = HashMap<Int, Int>(); val pr = Prim()
            for (k in 0 until n) {
                val v = min(faces[fi + k], vs.size - 1)
                val l0 = remap[v]
                if (l0 != null) pr.idx.add(l0) else { val l = pr.gv.size; remap[v] = l; pr.gv.add(v); pr.idx.add(l) }
            }
            fi += m.count
            val pos = FloatArray(pr.gv.size * 3); val nor = FloatArray(pr.gv.size * 3); val uv = FloatArray(pr.gv.size * 2)
            val mn = floatArrayOf(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
            val mx = floatArrayOf(Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY)
            for ((k, v) in pr.gv.withIndex()) {
                val q = vs[v]; val P = floatArrayOf(q.p.x, q.p.y, -q.p.z)
                for (c in 0 until 3) pos[k * 3 + c] = P[c]
                nor[k * 3] = q.n.x; nor[k * 3 + 1] = q.n.y; nor[k * 3 + 2] = -q.n.z
                uv[k * 2] = q.u; uv[k * 2 + 1] = q.v
                for (c in 0 until 3) { mn[c] = min(mn[c], P[c]); mx[c] = max(mx[c], P[c]) }
            }
            val vP = addView(fb(pos), 34962); val vN = addView(fb(nor), 34962); val vU = addView(fb(uv), 34962)
            val ib = ByteBuffer.allocate(pr.idx.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (x in pr.idx) ib.putInt(x)
            val vI = addView(ib.array(), 34963)
            accs.put(JSONObject().put("bufferView", vP).put("componentType", 5126).put("count", pr.gv.size).put("type", "VEC3").put("min", farr(mn[0], mn[1], mn[2])).put("max", farr(mx[0], mx[1], mx[2]))); val aP = accs.length() - 1
            accs.put(JSONObject().put("bufferView", vN).put("componentType", 5126).put("count", pr.gv.size).put("type", "VEC3")); val aN = accs.length() - 1
            accs.put(JSONObject().put("bufferView", vU).put("componentType", 5126).put("count", pr.gv.size).put("type", "VEC2")); val aU = accs.length() - 1
            accs.put(JSONObject().put("bufferView", vI).put("componentType", 5125).put("count", pr.idx.size).put("type", "SCALAR")); val aI = accs.length() - 1
            matJson.put(glMat(m))
            prims.put(JSONObject().put("attributes", JSONObject().put("POSITION", aP).put("NORMAL", aN).put("TEXCOORD_0", aU)).put("indices", aI).put("mode", 4).put("material", matJson.length() - 1))
            pinfo.add(pr)
        }
        if (prims.length() == 0) { lastError = "PMX has no drawable faces"; return null }
        var js: ByteArray
        try {
            val root = JSONObject()
            root.put("asset", JSONObject().put("version", "2.0").put("generator", "SaikiMotion MMD Import"))
            root.put("scene", 0); root.put("scenes", JSONArray().put(JSONObject().put("nodes", JSONArray().put(0)))); root.put("nodes", JSONArray().put(JSONObject().put("mesh", 0)))
            root.put("meshes", JSONArray().put(JSONObject().put("primitives", prims))); root.put("materials", matJson)
            root.put("buffers", JSONArray().put(JSONObject().put("byteLength", bin.size()))); root.put("bufferViews", views); root.put("accessors", accs)
            if (images.length() > 0) { root.put("images", images); root.put("textures", textures) }
            js = root.toString().toByteArray(Charsets.UTF_8)
        } catch (_: Exception) { lastError = "MMD conversion failed"; return null }
        if (js.size % 4 != 0) js += ByteArray(4 - js.size % 4) { 0x20 }
        while (bin.size() % 4 != 0) bin.write(0)
        val binB = bin.toByteArray()
        val glb = ByteBuffer.allocate(12 + 8 + js.size + 8 + binB.size).order(ByteOrder.LITTLE_ENDIAN)
        glb.putInt(0x46546C67); glb.putInt(2); glb.putInt(12 + 8 + js.size + 8 + binB.size)
        glb.putInt(js.size); glb.putInt(0x4E4F534A); glb.put(js)
        glb.putInt(binB.size); glb.putInt(0x004E4942); glb.put(binB)
        try { File(out).writeBytes(glb.array()) } catch (_: Exception) { lastError = "Cannot write converted MMD"; return null }
        try { File("$out.anim").delete() } catch (_: Exception) {}

        // skeleton + skin weights sidecar for Pose mode (z is flipped exactly like the vertices)
        run {
            val sk = Skeleton3D()
            for (b in bones) {
                val wp = V3(b.pos.x, b.pos.y, -b.pos.z)
                var rel = wp
                if (b.parent >= 0 && b.parent < bones.size) { val pp = bones[b.parent].pos; rel = wp - V3(pp.x, pp.y, -pp.z) }
                sk.bones.add(Bone3D(b.name, if (b.parent >= 0 && b.parent < bones.size) b.parent else -1, T(wp), T(rel)))
            }
            if (rbodies.isNotEmpty()) {
                val ph = Physics3D()
                ph.bodies = rbodies.toMutableList(); ph.joints = rjoints.toMutableList()
                for (bd in rbodies) if (bd.mode != 0 && bd.bone >= 0) sk.bones[bd.bone].physics = true
                if (ph.active) sk.phys = ph
            }
            val J = ArrayList<ShortArray>(); val W = ArrayList<FloatArray>()
            for (pr in pinfo) {
                val j = ShortArray(pr.gv.size * 4); val w = FloatArray(pr.gv.size * 4)
                for ((k, v) in pr.gv.withIndex()) {
                    val q = vs[v]; var sum = 0f
                    for (s in 0 until min(4, q.bi.size)) if (q.bi[s] >= 0 && q.bi[s] < bones.size) { j[k * 4 + s] = q.bi[s].toShort(); w[k * 4 + s] = q.bw[s]; sum += q.bw[s] }
                    if (sum > 1e-6f) for (s in 0 until 4) w[k * 4 + s] /= sum
                }
                J.add(j); W.add(w)
            }
            if (sk.bones.isNotEmpty()) Skeleton3D.write(sk, J, W, "$out.skel")
        }

        if (vmdPath != null) {
            val vd = try { File(vmdPath).readBytes() } catch (_: Exception) { null }
            if (vd != null) bakeVmd(vd, bones, vs, pinfo.map { it.gv }, "$out.anim")
        }
        return out
    }

    /** Standalone .vmd: bakes the motion onto the PMX model that `modelGlb` (a converted *_mmd*.glb) came from.
     *  Returns the new .glb (new path, so cached models are never stale), or null with lastError set. */
    @JvmStatic fun applyVmd(vmd: String, modelGlb: String): String? {
        lastError = ""
        val name = lastComp(modelGlb)
        val ri = name.indexOf("_mmd")
        if (ri < 0) { lastError = "Select an imported MMD (.pmx) model first, then import the .vmd"; return null }
        val dir = File(modelGlb).parent ?: ""; val stem = name.substring(0, ri)
        for (e in listOf("pmx", "mmd", "PMX", "MMD")) {
            val p = "$dir/$stem.$e"
            if (File(p).exists()) return convert(p, vmd)
        }
        lastError = "The original .pmx of this model is missing — re-import the model, then the .vmd"; return null
    }

    // MARK: VMD animation
    private class Key(val f: Long, val pos: V3, val rot: Quat, val c: ByteArray)

    private fun findVmd(stem: String, dir: String): String? {
        if (File("$stem.vmd").exists()) return "$stem.vmd"
        val all = File(dir).list()?.toList() ?: emptyList()
        return all.filter { it.lowercase(Locale.ROOT).endsWith(".vmd") }.sorted().firstOrNull()?.let { "$dir/$it" }
    }

    private fun bez(c: ByteArray, k: Int, t: Float): Float {     // k: 0 X, 1 Y, 2 Z, 3 rotation
        if (c.size < 16) return t
        fun cv(i: Int) = (c[i].toInt() and 0xFF).toFloat()
        val x1 = cv(k) / 127; val y1 = cv(4 + k) / 127; val x2 = cv(8 + k) / 127; val y2 = cv(12 + k) / 127
        if (abs(x1 - y1) < 0.001f && abs(x2 - y2) < 0.001f) return t
        var lo = 0f; var hi = 1f; var s = t
        for (i in 0 until 14) {
            s = (lo + hi) / 2
            val x = 3 * (1 - s) * (1 - s) * s * x1 + 3 * (1 - s) * s * s * x2 + s * s * s
            if (x < t) lo = s else hi = s
        }
        return 3 * (1 - s) * (1 - s) * s * y1 + 3 * (1 - s) * s * s * y2 + s * s * s
    }

    private fun bakeVmd(b: ByteArray, bones: List<Bone>, verts: List<Vtx>, prims: List<List<Int>>, out: String) {
        if (b.size <= 54) return
        val r = R(b); r.p = 50
        val n = r.i32().toLong() and 0xFFFFFFFFL
        if (!(n > 0 && 54 + n * 111 <= b.size)) return
        val byName = HashMap<String, Int>()
        for ((i, bn) in bones.withIndex()) if (byName[bn.name] == null) byName[bn.name] = i
        val keys = Array(bones.size) { ArrayList<Key>() }
        var last = 0L
        for (i in 0 until n.toInt()) {
            var raw = r.bytes(15); val z = raw.indexOf(0); if (z >= 0) raw = raw.copyOfRange(0, z)
            val name = strict(raw, "Shift_JIS") ?: ""
            val f = r.i32().toLong() and 0xFFFFFFFFL
            val p = r.v3(); val qx = r.f(); val qy = r.f(); val qz = r.f(); val qw = r.f()
            val c = r.bytes(64)
            val bi = byName[name]
            if (bi != null) { keys[bi].add(Key(f, p, Quat(qx, qy, qz, qw).normalized(), c)); last = max(last, f) }
        }
        for (k in keys) k.sortBy { it.f }
        if (last <= 0) return
        val fps = 30f
        val total = prims.sumOf { it.size }
        var nfL = last + 1
        val maxF = max(2L, 200_000_000L / max(total * 24, 1))
        var step = 1L; if (nfL > maxF) { step = (nfL + maxF - 1) / maxF; nfL = (nfL + step - 1) / step }
        if (nfL <= 1) return
        val nf = nfL.toInt()

        val nb = bones.size
        val order = (0 until nb).sortedWith(compareBy<Int>({ bones[it].layer }, { it }))
        val own = Array(nb) { Quat.IDENTITY }
        val eff = own.copyOf(); val vp = Array(nb) { V3.ZERO }; val etr = vp.copyOf()
        val world = Array(nb) { M4.identity() }
        val done = BooleanArray(nb)
        fun restOff(i: Int): V3 = bones[i].pos - (if (bones[i].parent >= 0 && bones[i].parent < nb) bones[bones[i].parent].pos else V3.ZERO)
        fun w(i: Int, d: Int = 0): M4 {
            if (done[i] || d > 64) return world[i]
            val loc = T(restOff(i) + etr[i]) * M4.fromQuat(eff[i])
            val p = bones[i].parent
            world[i] = if (p >= 0 && p < nb) w(p, d + 1) * loc else loc
            done[i] = true; return world[i]
        }
        fun inherit(i: Int) {
            val bn = bones[i]
            eff[i] = own[i]; etr[i] = vp[i]
            if (!(bn.inhParent >= 0 && bn.inhParent < nb)) return
            if (bn.flags and 0x100 != 0) {
                val q = slerp(Quat.IDENTITY, eff[bn.inhParent], bn.inhInfl)
                eff[i] = (own[i] * q).normalized()
            }
            if (bn.flags and 0x200 != 0) etr[i] = vp[i] + etr[bn.inhParent] * bn.inhInfl
        }
        fun solveIK(ik: Int) {
            val bn = bones[ik]
            if (!(bn.ikTarget >= 0 && bn.ikTarget < nb && bn.ikLinks.isNotEmpty())) return
            val tgt = bn.ikTarget
            val tc = w(ik).col(3)
            val target = V3(tc.x, tc.y, tc.z)
            val chain = ArrayList<Int>(); var c = tgt             // effector -> top link
            val top = bn.ikLinks.last().idx
            for (k in 0 until 64) { chain.add(c); if (c == top) break; c = bones[c].parent; if (c < 0) break }
            val path = chain.reversed()
            val accX = FloatArray(bn.ikLinks.size)
            for (it0 in 0 until max(1, min(bn.ikLoop, 24))) {
                for ((li, link) in bn.ikLinks.withIndex()) {
                    if (!(link.idx >= 0 && link.idx < nb)) continue
                    val lb = link.idx
                    val M = w(lb); val inv = M.inverse()
                    val ew = w(tgt).col(3)
                    val e4 = inv * ew
                    val le = normalize(V3(e4.x, e4.y, e4.z))
                    val t4 = inv * V4(target.x, target.y, target.z, 1f)
                    val lt = normalize(V3(t4.x, t4.y, t4.z))
                    val dt = min(1f, max(-1f, dot(le, lt)))
                    var ang = acos(dt)
                    if (ang < 1e-5f || !ang.isFinite()) continue
                    ang = min(ang, if (bn.ikLimit > 0) bn.ikLimit else ang)
                    var axis = cross(le, lt)
                    if (length(axis) < 1e-8f) continue
                    axis = normalize(axis)
                    val dq: Quat
                    if (link.has && link.lo.y == 0f && link.hi.y == 0f && link.lo.z == 0f && link.hi.z == 0f) {       // knee-like: X axis only
                        val s = if (axis.x >= 0) 1f else -1f
                        val nx = min(max(accX[li] + s * ang, link.lo.x), link.hi.x)
                        val d = nx - accX[li]; accX[li] = nx
                        dq = Quat.angleAxis(d, V3(1f, 0f, 0f))
                    } else {
                        dq = Quat.angleAxis(ang, axis)
                    }
                    own[lb] = (own[lb] * dq).normalized()
                    inherit(lb)
                    for (p in path) done[p] = false
                    for (p in path) w(p)
                }
            }
        }

        val os = try { BufferedOutputStream(FileOutputStream(out), 1 shl 16) } catch (_: Exception) { return }
        try {
            val hd = ByteBuffer.allocate(16 + prims.size * 4).order(ByteOrder.LITTLE_ENDIAN)
            hd.putInt(0x41424153); hd.putInt(nf); hd.putFloat(fps / step.toFloat()); hd.putInt(prims.size)
            for (p in prims) hd.putInt(p.size)
            os.write(hd.array())

            for (fr in 0 until nf) {
                val f = fr.toLong() * step
                for (i in 0 until nb) {
                    val ks = keys[i]
                    if (ks.isEmpty()) { own[i] = Quat.IDENTITY; vp[i] = V3.ZERO; continue }
                    var k1 = ks.size - 1
                    val ix = ks.indexOfFirst { it.f > f }; if (ix >= 0) k1 = ix
                    val a = ks[max(0, if (ks[k1].f > f) k1 - 1 else k1)]; val bk = ks[k1]
                    if (bk.f <= f || a.f == bk.f) { own[i] = bk.rot; vp[i] = bk.pos; if (bk.f > f) { own[i] = a.rot; vp[i] = a.pos } }
                    else {
                        val t = (f - a.f).toFloat() / (bk.f - a.f).toFloat()
                        own[i] = slerp(a.rot, bk.rot, bez(bk.c, 3, t))
                        vp[i] = V3(a.pos.x + (bk.pos.x - a.pos.x) * bez(bk.c, 0, t),
                                   a.pos.y + (bk.pos.y - a.pos.y) * bez(bk.c, 1, t),
                                   a.pos.z + (bk.pos.z - a.pos.z) * bez(bk.c, 2, t))
                    }
                }
                for (i in 0 until nb) done[i] = false
                for (i in order) {
                    inherit(i)
                    done[i] = false
                    if (bones[i].ikTarget >= 0) { w(i); solveIK(i) }
                }
                for (i in order) inherit(i)
                for (i in 0 until nb) done[i] = false
                for (i in 0 until nb) w(i)
                val skin = Array(nb) { world[it] * T(-bones[it].pos) }
                for (gv in prims) {
                    val bb = ByteBuffer.allocate(gv.size * 24).order(ByteOrder.LITTLE_ENDIAN)
                    val P = FloatArray(gv.size * 3); val N = FloatArray(gv.size * 3)
                    var o = 0
                    for (v in gv) {
                        val q = verts[v]
                        var px = 0f; var py = 0f; var pz = 0f; var nx = 0f; var ny = 0f; var nz = 0f
                        for ((k, bi) in q.bi.withIndex()) if (bi >= 0 && bi < nb) {
                            val m = skin[bi]; val wgt = q.bw[k]
                            val pp = m * V4(q.p.x, q.p.y, q.p.z, 1f); val nr = m * V4(q.n.x, q.n.y, q.n.z, 0f)
                            px += pp.x * wgt; py += pp.y * wgt; pz += pp.z * wgt; nx += nr.x * wgt; ny += nr.y * wgt; nz += nr.z * wgt
                        }
                        if (q.bi.isEmpty()) { px = q.p.x; py = q.p.y; pz = q.p.z; nx = q.n.x; ny = q.n.y; nz = q.n.z }
                        val l = max(length(V3(nx, ny, nz)), 1e-6f)
                        P[o] = px; P[o + 1] = py; P[o + 2] = -pz; N[o] = nx / l; N[o + 1] = ny / l; N[o + 2] = -nz / l
                        o += 3
                    }
                    for (x in P) bb.putFloat(x); for (x in N) bb.putFloat(x)
                    os.write(bb.array())
                }
            }
            os.close()
        } catch (_: Exception) { try { os.close() } catch (_: Exception) {}; try { File(out).delete() } catch (_: Exception) {} }
    }

    // MARK: zip with folders (textures keep their relative paths)

    /** If the archive holds a .pmx / .mmd, unpacks the whole archive (folders kept) and returns the model path. */
    @JvmStatic fun unzipAll(path: String): String? {
        val b = try { File(path).readBytes() } catch (_: Exception) { return null }
        if (b.size <= 22) return null
        fun r16(o: Int): Int = if (o >= 0 && o + 2 <= b.size) (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) else 0
        fun r32(o: Int): Int = r16(o) or (r16(o + 2) shl 16)
        var e = b.size - 22
        while (e >= 0 && r32(e) != 0x06054b50) e -= 1
        if (e < 0) return null
        var n = r16(e + 10); var p = r32(e + 16)
        class Ent(val name: String, val method: Int, val cs: Int, val lo: Int)
        val entries = ArrayList<Ent>()
        while (n > 0 && p + 46 <= b.size && r32(p) == 0x02014b50) {
            val method = r16(p + 10); val cs = r32(p + 20); val nl = r16(p + 28); val el = r16(p + 30); val cl = r16(p + 32); val lo = r32(p + 42)
            val nm = b.copyOfRange(p + 46, min(b.size, p + 46 + nl))
            var name = strict(nm, "UTF-8") ?: strict(nm, "Shift_JIS") ?: String(nm, Charsets.UTF_8)
            name = name.replace("\\", "/")      // Windows zips use backslashes
            entries.add(Ent(name, method, cs, lo)); n -= 1; p += 46 + nl + el + cl
        }
        val model = entries.filter { pathExt(it.name).lowercase(Locale.ROOT) in setOf("pmx", "mmd") && !it.name.startsWith("__MACOSX") && !lastComp(it.name).startsWith("._") }
            .maxByOrNull { it.cs } ?: return null   // biggest model wins
        val root = delExt(path) + "_mmd"
        var result: String? = null
        for (en in entries) {
            val name = en.name
            if (name.endsWith("/") || name.startsWith("__MACOSX") || name.contains("..")) continue
            if (en.lo + 30 > b.size) continue
            val ds = en.lo + 30 + r16(en.lo + 26) + r16(en.lo + 28)
            if (ds + en.cs > b.size || ds < 0 || en.cs < 0) continue
            val raw = b.copyOfRange(ds, ds + en.cs)
            val data = if (en.method == 0) raw else if (en.method == 8) VdbVolume.inflate(raw) else ByteArray(0)
            if (data.isEmpty()) continue
            val dst = "$root/$name"
            try { File(dst).parentFile?.mkdirs(); File(dst).writeBytes(data) } catch (_: Exception) {}
            if (name == model.name) result = dst
        }
        return result
    }
}
