package com.saiki.motion.core

/** JNI entry to saiki_abc_to_glb (native/bridge.c + abc2glb.c, reused unchanged from iOS). */
object NativeAbc {
    init { System.loadLibrary("saiki") }
    external fun abcToGlb(path: String): String?
}
