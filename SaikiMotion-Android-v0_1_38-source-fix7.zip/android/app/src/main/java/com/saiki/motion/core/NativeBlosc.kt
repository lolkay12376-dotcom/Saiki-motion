package com.saiki.motion.core

/** JNI entry to c-blosc blosc_decompress (native/blosc, reused unchanged from iOS). Always returns a destSize array (zeros on failure, like iOS). */
object NativeBlosc {
    init { System.loadLibrary("saiki") }
    external fun decompress(src: ByteArray, destSize: Int): ByteArray
}
