package com.saiki.motion.core

// JNI surface of cpp/jni_model.cpp (slice 7m). Handles are native pointers (0 = none). Unbuilt/unverified.
object NativeModel {
    init { System.loadLibrary("saiki") }
    @JvmStatic external fun bufFloat(a: FloatArray): Long
    @JvmStatic external fun bufIdx(a: IntArray, is16: Boolean): Long
    @JvmStatic external fun bufFree(h: Long)
    @JvmStatic external fun texCreate(w: Int, h: Int, rgba: ByteArray): Long
    @JvmStatic external fun texFree(h: Long)
    @JvmStatic external fun texCreatePlain(w: Int, h: Int, rgba: ByteArray): Long   // no mips
    @JvmStatic external fun volumePass(target: Long, accumulate: Boolean, ubo: FloatArray, tex: Long, depth: Long, env: Long, scene: Long, scissor: IntArray): Boolean
    @JvmStatic external fun depthEnsure(prev: Long, w: Int, h: Int): Long
    @JvmStatic external fun depthFree(h: Long)
    @JvmStatic external fun targetCreate(w: Int, h: Int, half: Boolean): Long
    @JvmStatic external fun targetTex(h: Long): Long
    @JvmStatic external fun targetFree(h: Long)
    @JvmStatic external fun pso(frag: String, target: Long, blend: Boolean, depthOnly: Boolean, depthWrite: Boolean, points: Boolean, rtLayout: Boolean): Long
    /** == MTLDevice.supportsRaytracing (ray query + acceleration structure + buffer device address enabled). */
    @JvmStatic external fun rtSupported(): Boolean
    /** == MetalModelRenderer.buildAccel: meta[2i] = idx32, meta[2i+1] = triangle count. 0 = failed. */
    @JvmStatic external fun accelBuild(vb: LongArray, ib: LongArray, meta: IntArray, n: Int): Long
    @JvmStatic external fun accelFree(h: Long)
    @JvmStatic external fun modelPass(target: Long, depth: Long, clearDepth: Boolean, n: Int,
        pso: LongArray, vb: LongArray, ib: LongArray, meta: IntArray, ubo: FloatArray, tex: LongArray, clamp: BooleanArray, own: LongArray,
        sh: LongArray, depthSrc: Long, lights: FloatArray, under: FloatArray, accel: Long, rtu: FloatArray): Boolean
    @JvmStatic external fun depthCopy(src: Long, dst: Long): Boolean
    @JvmStatic external fun planeOcclude(src: Long, dst: Long, depth: Long, clearDepth: Boolean, ubo: FloatArray): Boolean
}

/** == MetalTarget (Metal/MetalCore): native Target* handle. SceneRendererN.targetCreate owns creation and pooling; the model renderer only draws into it. */
class MetalTarget(val handle: Long, val width: Int, val height: Int, val half: Boolean) {
    val tex: Long get() = NativeModel.targetTex(handle)
}
