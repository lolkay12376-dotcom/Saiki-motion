package com.saiki.motion.core

// Port of Sources/App/Editor/EditorPbr.swift:11-30 — the PBRMaps enum (keys + guessKey).
// The buildPbr panel itself is part of the EditorViewController port (app/ package).

object PBRMaps {
    val keys: List<Pair<String, String>> = listOf(
        "albedo" to "Base colour", "normal" to "Normal", "rough" to "Roughness", "metal" to "Metallic",
        "ao" to "Ambient occlusion", "height" to "Height / displacement", "emissive" to "Emissive", "opacity" to "Opacity")

    /** Maps a file name such as "brick_diff_2k.jpg" or "Rock_Normal_GL.png" to a slot ("" = unknown). */
    fun guessKey(file: String): String {
        val n = file.lowercase()
        fun has(a: List<String>): Boolean = a.any { n.contains(it) }
        if (has(listOf("normal", "_nor", "-nor", "_nrm", "norm"))) return "normal"
        if (has(listOf("rough"))) return "rough"
        if (has(listOf("metal", "_met", "metalness"))) return "metal"
        if (has(listOf("_ao", "-ao", "ambient", "occlusion", "_occ"))) return "ao"
        if (has(listOf("height", "displ", "_disp", "_dsp", "bump"))) return "height"
        if (has(listOf("emiss", "emit", "_glow"))) return "emissive"
        if (has(listOf("opacity", "alpha", "_mask", "transparen"))) return "opacity"
        if (has(listOf("albedo", "diff", "basecolor", "base_color", "base-color", "color", "colour", "_col", "_alb"))) return "albedo"
        return ""
    }
}
