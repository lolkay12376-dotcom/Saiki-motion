@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.core

import java.io.ByteArrayOutputStream

// Port of Sources/Tools/PSDWriter.swift — minimal layered Photoshop (.psd) writer.
//
// 8-bit RGB + alpha, one cropped raster layer per DecomposedLayer, PackBits
// (RLE) compressed so transparent layers stay small. Opens in Photoshop,
// Krita, GIMP, Procreate, Clip Studio, Affinity…

object PSDWriter {

    private fun be16(d: ByteArrayOutputStream, v: Int) {
        d.write((v shr 8) and 0xFF); d.write(v and 0xFF)
    }

    private fun be32(d: ByteArrayOutputStream, v: Int) {
        d.write((v shr 24) and 0xFF); d.write((v shr 16) and 0xFF)
        d.write((v shr 8) and 0xFF); d.write(v and 0xFF)
    }

    /// PackBits one scanline.
    private fun packBits(row: ByteArray, out: ByteArrayOutputStream) {
        val n = row.size
        var i = 0
        while (i < n) {
            var run = 1
            while (i + run < n && run < 128 && row[i + run] == row[i]) run += 1
            if (run >= 2) {
                out.write((1 - run) and 0xFF)
                out.write(row[i].toInt() and 0xFF)
                i += run
            } else {
                var j = i + 1
                while (j < n && (j - i) < 128) {
                    if (j + 1 < n && row[j] == row[j + 1]) break
                    j += 1
                }
                out.write(j - i - 1)
                for (t in i until j) out.write(row[t].toInt() and 0xFF)
                i = j
            }
        }
    }

    private class Rle(val counts: IntArray, val bytes: ByteArray)

    /// RLE-compress one channel plane of an RGBA buffer: (row byte counts, packed bytes).
    private fun rle(rgba: ByteArray, w: Int, h: Int, channel: Int): Rle {
        val counts = IntArray(h)
        val bytes = ByteArrayOutputStream()
        val row = ByteArray(w)
        for (y in 0 until h) {
            for (x in 0 until w) row[x] = rgba[(y * w + x) * 4 + channel]
            val packed = ByteArrayOutputStream()
            packBits(row, packed)
            counts[y] = packed.size()
            packed.writeTo(bytes)
        }
        return Rle(counts, bytes.toByteArray())
    }

    private fun asciiName(s: String): ByteArray {
        val out = ByteArrayOutputStream()
        for (u in s) if (u.code >= 32 && u.code < 127) out.write(u.code)
        if (out.size() == 0) "Layer".toByteArray().forEach { out.write(it.toInt()) }
        val all = out.toByteArray()
        return all.copyOf(minOf(31, all.size))
    }

    /// `composite` is the full-canvas merged RGBA preview (un-premultiplied).
    fun write(width: Int, height: Int, layers: List<DecomposedLayer>, composite: ByteArray): ByteArray {
        val d = ByteArrayOutputStream()

        // header
        "8BPS".toByteArray().forEach { d.write(it.toInt()) }
        be16(d, 1)
        repeat(6) { d.write(0) }
        be16(d, 4)                       // R G B + transparency
        be32(d, height)
        be32(d, width)
        be16(d, 8)                       // bits / channel
        be16(d, 3)                       // RGB
        be32(d, 0)                       // colour mode data
        be32(d, 0)                       // image resources

        // layer records + channel data (layers go bottom → top, same as our order)
        val records = ByteArrayOutputStream()
        val channelData = ByteArrayOutputStream()
        val channelIds = intArrayOf(0, 1, 2, -1)    // R, G, B, alpha
        var written = 0
        for (layer in layers) if (layer.w > 0 && layer.h > 0) {
            written += 1
            be32(records, layer.y)                    // top
            be32(records, layer.x)                    // left
            be32(records, layer.y + layer.h)          // bottom
            be32(records, layer.x + layer.w)          // right
            be16(records, 4)
            val planes = ArrayList<ByteArray>()
            for (ci in channelIds.indices) {
                val cid = channelIds[ci]
                val chan = if (ci == 3) 3 else ci
                val r = rle(layer.rgba, layer.w, layer.h, chan)
                val plane = ByteArrayOutputStream()
                be16(plane, 1)                        // RLE
                for (c in r.counts) be16(plane, c)
                r.bytes.forEach { plane.write(it.toInt()) }
                planes.add(plane.toByteArray())
                be16(records, cid)
                be32(records, plane.size())
            }
            "8BIM".toByteArray().forEach { records.write(it.toInt()) }
            "norm".toByteArray().forEach { records.write(it.toInt()) }
            records.write(255)                        // opacity
            records.write(0)                          // clipping
            records.write(if (layer.visible) 0 else 2)  // flags (bit 1 = hidden)
            records.write(0)                          // filler

            val name = asciiName(layer.name)
            val pascal = ByteArrayOutputStream()
            pascal.write(name.size)
            name.forEach { pascal.write(it.toInt()) }
            while (pascal.size() % 4 != 0) pascal.write(0)
            be32(records, 4 + 4 + pascal.size())      // extra data length
            be32(records, 0)                          // layer mask
            be32(records, 0)                          // blending ranges
            pascal.toByteArray().forEach { records.write(it.toInt()) }

            for (p in planes) p.forEach { channelData.write(it.toInt()) }
        }

        val info = ByteArrayOutputStream()
        be16(info, -written)                          // negative: merged image has transparency
        records.toByteArray().forEach { info.write(it.toInt()) }
        channelData.toByteArray().forEach { info.write(it.toInt()) }
        if (info.size() % 2 != 0) info.write(0)

        val section = ByteArrayOutputStream()
        be32(section, info.size())
        info.toByteArray().forEach { section.write(it.toInt()) }
        be32(section, 0)                              // global layer mask info
        be32(d, section.size())
        section.toByteArray().forEach { d.write(it.toInt()) }

        // merged image (RLE, planar R G B A)
        be16(d, 1)
        val planesData = ByteArrayOutputStream()
        val counts = ByteArrayOutputStream()
        for (ch in 0 until 4) {
            val r = rle(composite, width, height, ch)
            for (c in r.counts) be16(counts, c)
            r.bytes.forEach { planesData.write(it.toInt()) }
        }
        counts.toByteArray().forEach { d.write(it.toInt()) }
        planesData.toByteArray().forEach { d.write(it.toInt()) }
        return d.toByteArray()
    }
}
