package com.saiki.motion.core

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// Port of Sources/Render/Particles.swift — deterministic particle field (pure function of seed + time).

class Particle(
    @JvmField var x: Float, @JvmField var y: Float, @JvmField var z: Float,
    @JvmField var size: Float,    // relative size multiplier
    @JvmField var life: Float,    // 0 fresh -> 1 dead
    @JvmField var soft: Float,    // 0 hard dot .. 1 fully blurred (depth of field)
    @JvmField var alpha: Float = 1f,   // per-particle opacity multiplier (Particular custom graph)
    @JvmField var rot: Float = 0f,     // sprite rotation (radians)
    @JvmField var vari: Float = 0f,    // 0..1 sprite variant seed
    @JvmField var cr: Float = 1f,      // per-particle colour (image / video emitters)
    @JvmField var cg: Float = 1f,
    @JvmField var cb: Float = 1f)

object ParticlesSim {

    @JvmStatic fun field(count: Int, spread: Float, speed: Float, gravity: Float,
                         life: Float, seed: Float, dirX: Float, dirY: Float,
                         t: Float, ar: Float,
                         posX: Float = 0f, posY: Float = 0f, posZ: Float = 0f,
                         radX: Float = 0.5f, radY: Float = 0.5f, radZ: Float = 0f,
                         dirZ: Float = 0f, resist: Float = 0f, wobble: Float = 0f,
                         sizeVar: Float = 0.7f, sizeEnd: Float = 1f,
                         dof: Float = 0f, focus: Float = 0f,
                         burst: Float = 0f, burstForce: Float = 0.5f, edge: Float = 0.6f): List<Particle> {
        val n = max(1, min(count, 6000))
        val out = ArrayList<Particle>(n)
        val time = max(0f, t)
        val lf = max(life, 0.05f)
        for (i in 0 until n) {
            val fi = i.toFloat()
            val h0 = hash(seed * 131.0f + fi)
            val h1 = hash(seed * 977.0f + fi * 7.0f)
            val h2 = hash(seed * 3313.0f + fi * 13.0f)
            val h3 = hash(seed * 6151.0f + fi * 29.0f)
            val h4 = hash(seed * 17.0f + fi * 3.0f)
            val h5 = hash(seed * 4001.0f + fi * 19.0f)
            val h6 = hash(seed * 811.0f + fi * 23.0f)

            var age = time - h0 * lf
            age %= lf
            if (age < 0) age += lf
            val p = age / lf

            // producer: a box/ellipsoid volume (Radius X/Y/Z); soft emitter edge blends the flat box with a bell curve
            val vol = 1f
            val e = min(max(edge, 0f), 1f)
            fun bell(a: Float, b: Float, c: Float): Float = ((a + b + c) / 3 * 2 - 1) * 1.5f
            val sx = (h1 * 2 - 1) * (1 - e) + bell(h1, hash(seed * 53.0f + fi * 37.0f), hash(seed * 59.0f + fi * 41.0f)) * e
            val sy = (h2 * 2 - 1) * (1 - e) + bell(h2, hash(seed * 61.0f + fi * 43.0f), hash(seed * 67.0f + fi * 47.0f)) * e
            val sz3 = (h5 * 2 - 1) * (1 - e) + bell(h5, hash(seed * 71.0f + fi * 53.0f), hash(seed * 73.0f + fi * 59.0f)) * e
            val bx = sx * radX * vol + posX
            val by = sy * radY * vol + posY
            val bz = sz3 * radZ * vol + posZ

            // physics: direction + velocity variance, resistance, gravity, wobble
            var vx = (dirX + (h3 - 0.5f) * spread * 0.6f) * speed
            var vy = (dirY + (h4 - 0.5f) * spread * 0.6f) * speed
            var vz = (dirZ + (h6 - 0.5f) * spread * 0.6f) * speed
            if (burst > 0.001f) {
                // random direction on a sphere, random strength -> endless radial explosion
                val ang = h3 * 6.2831853f
                val zc = h6 * 2 - 1
                val rr = sqrt(1 - zc * zc)
                val mag = burstForce * (0.35f + 0.65f * h4)
                vx += ((rr * cos(ang)) * mag - vx) * burst
                vy += ((rr * sin(ang)) * mag - vy) * burst
                vz += ((zc * 0.6f) * mag - vz) * burst
            }
            var travel = age
            if (resist > 0.001f) {
                val k = resist * 4
                travel = (1 - exp(-k * age)) / k
            }
            var x = bx + vx * travel
            var y = by + vy * travel + gravity * travel * travel * 0.5f
            val z = bz + vz * travel
            if (wobble > 0.001f) {
                x += sin(age * 1.7f + h3 * 6.283f) * wobble * 0.15f
                y += cos(age * 1.3f + h4 * 6.283f) * wobble * 0.15f
            }

            // many tiny particles, a few big ones (like a star-dust field)
            val base = (1 - sizeVar) + sizeVar * (0.2f + 1.8f * h2 * h2 * h2 * 2.2f)
            val sz = base * (1 + (sizeEnd - 1) * p)
            val soft = min(1f, max(0f, abs(z - focus) * dof * 0.8f))
            out.add(Particle(x, y, z, sz, p, soft))
        }
        return out
    }

    /** PCG-style hash: UInt32 wrap-around arithmetic on Int, n % 100000 on the unsigned value. */
    private fun hash(x: Float): Float {
        var n = (x * 8192.0f).toLong().toInt()
        n = n * 747796405 + (2891336453L.toInt())
        n = ((n ushr ((n ushr 28) + 4)) xor n) * 277803737
        n = (n ushr 22) xor n
        return ((n.toLong() and 0xFFFFFFFFL) % 100000L).toFloat() / 100000f
    }
}
