package com.saiki.motion.core

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

// Port of Sources/Render/Particular.swift — 3D particle emitter. Pure function of (params, time):
// scrubbing, caching and export match. Positions are layer-local 3D (x/y world units, z depth);
// the particle renderer projects them with the comp camera.
object PtCurve {
    const val cap = 12
    val defaults = mapOf(
        "Op" to listOf(Pair(0f, 0f), Pair(0.2f, 1f), Pair(0.8f, 1f), Pair(1f, 0f)),
        "Sz" to listOf(Pair(0f, 0.5f), Pair(1f, 0.5f)),
        "Sp" to listOf(Pair(0f, 0.5f), Pair(1f, 0.5f)))

    fun read(g: (String) -> Float, id: String): List<Pair<Float, Float>> {
        val n = min(cap, max(0, Math.round(g("ptCv${id}N"))))
        return (0 until n).map { Pair(g("ptCv${id}X$it"), g("ptCv${id}Y$it")) }.sortedBy { it.first }
    }

    fun active(g: (String) -> Float, id: String): List<Pair<Float, Float>>? {
        if (g("ptCv${id}On") < 0.5f) return null
        val p = read(g, id)
        return if (p.size >= 2) p else null
    }

    fun eval(p: List<Pair<Float, Float>>, x: Float): Float {
        if (p.isEmpty()) return 1f
        val f = p.first(); val l = p.last()
        if (x <= f.first) return f.second
        if (x >= l.first) return l.second
        for (i in 1 until p.size) {
            if (x <= p[i].first) {
                val a = p[i - 1]; val b = p[i]; val d = max(b.first - a.first, 0.0001f)
                return a.second + (b.second - a.second) * (x - a.first) / d
            }
        }
        return l.second
    }

    fun write(l: Layer, id: String, p: List<Pair<Float, Float>>, pre: String = "") {
        l.track(pre + "ptCv${id}N").base = p.size.toFloat()
        for ((i, q) in p.withIndex()) {
            if (i >= cap) break
            l.track(pre + "ptCv${id}X$i").base = q.first
            l.track(pre + "ptCv${id}Y$i").base = q.second
        }
    }

    val allKeys: List<String>
        get() = listOf("Op", "Sz", "Sp").flatMap { id -> listOf("On", "N").map { "ptCv$id$it" } + (0 until cap).flatMap { listOf("ptCv${id}X$it", "ptCv${id}Y$it") } }
}

/** Surface samples of the 3D model a "Model" emitter sits on (particle-layer-local space), filled by the scene renderer each frame. */
object PtModelSource {
    private val pts = HashMap<Int, List<V3>>()
    private val lock = Object()
    fun set(id: Int, p: List<V3>) { synchronized(lock) { pts[id] = p } }
    fun get(id: Int): List<V3> = synchronized(lock) { pts[id] ?: emptyList() }
}

object ParticularSim {
    val emitterNames = listOf("Point", "Box", "Sphere", "Grid", "Disc", "Ring", "Line", "Cone", "Cylinder", "Torus", "Helix", "Plane", "Shell", "Image", "Video", "Ring XY", "Disc XY", "Model", "Path")
    val motionNames = listOf("Default", "Bidirectional", "Directional", "Disc", "Inward", "Tangent", "Outward")
    val behaviorNames = listOf("Continuous", "Explode", "Dissolve")
    const val defA: Int = 0xFFFFE08A.toInt()
    const val defB: Int = 0xFFFF5A1F.toInt()

    /** Fade in / fade out used by the renderers (a custom opacity graph replaces the fade ramps). */
    fun fades(g: (String) -> Float): Pair<Float, Float> {
        if (PtCurve.active(g, "Op") != null) return Pair(0.001f, 0.001f)
        return Pair(max(0.001f, g("ptFadeIn")), max(0.001f, g("ptFadeOut")))
    }

    /** Divergence-free curl noise (two octaves of an analytic sine potential). */
    private fun curl(x: Float, y: Float, z: Float, t: Float): Triple<Float, Float, Float> {
        fun oct(x: Float, y: Float, z: Float, t: Float): Triple<Float, Float, Float> {
            val a = cos(x * 1.2f + y * 0.6f + t * 1.1f + 3.1f)
            val b = cos(z * 1.1f + x * 0.8f + t * 0.7f + 1.7f)
            val c = cos(y * 1.3f + z * 0.7f + t * 0.9f)
            return Triple(0.6f * a - 1.1f * b, 0.7f * c - 1.2f * a, 0.8f * b - 1.3f * c)
        }
        val o1 = oct(x, y, z, t)
        val o2 = oct(x * 2.1f + 5.2f, y * 2.1f + 1.3f, z * 2.1f + 9.1f, t * 1.3f)
        return Triple(o1.first + 0.5f * o2.first, o1.second + 0.5f * o2.second, o1.third + 0.5f * o2.third)
    }

    /** Trail copies / spacing. Motion blur (when no trails are set) re-uses the copies as shutter samples. */
    fun trailCfg(g: (String) -> Float): Triple<Int, Float, Boolean> {
        val mb = g("ptMBlur")
        if (mb > 0.001f && g("ptTrail") < 0.5f) {
            val n = max(3, min(10, Math.round(g("ptMBSamples"))))
            return Triple(n - 1, max(0.004f, mb * 0.1f), true)
        }
        return Triple(max(0, min(10, Math.round(g("ptTrail")))), max(0.02f, g("ptTrailLen")), false)
    }

    fun total(g: (String) -> Float): Int {
        val trail = trailCfg(g).first
        return max(1, min((g("ptRate") * max(g("ptLife"), 0.1f)).toInt(), 6000 / (1 + trail))) * (1 + trail)
    }

    fun field(g: (String) -> Float, t: Float, step: Int = 1): List<Particle> {
        val life = max(g("ptLife"), 0.1f)
        val (trail, trailLen, mbOn) = trailCfg(g)
        val copies = 1 + trail
        val vol = g("ptVolume")
        val la = g("ptVolLight") * Math.PI.toFloat() / 180f
        var lx = cos(la) * 0.8f; var ly = sin(la) * 0.8f; var lz = 0.6f
        val ll = max(sqrt(lx * lx + ly * ly + lz * lz), 0.0001f); lx /= ll; ly /= ll; lz /= ll
        val pathLUT: List<V3> = if (Math.round(g("ptEmType")) == 18) PtPath.lut(g) else emptyList()
        val pathMode = Math.round(g("ptPathMode")).toInt(); val pathFlow = g("ptPathFlow"); val pathSpeed = g("ptPathSpeed")
        fun pp(u: Float): V3 {
            val f = (u - floor(u)) * (pathLUT.size - 1).toFloat(); val i = min(pathLUT.size - 2, f.toInt()); val tt = f - i
            val a = pathLUT[i]; val b = pathLUT[i + 1]
            return V3(a.x + (b.x - a.x) * tt, a.y + (b.y - a.y) * tt, a.z + (b.z - a.z) * tt)
        }
        val modelPts: List<V3> = if (Math.round(g("ptEmType")) == 18 - 1) PtModelSource.get(Math.round(g("ptModelLayer")).toInt()) else emptyList()
        val n = max(1, min((g("ptRate") * life).toInt(), 6000 / copies))
        val seed = g("ptSeed")
        val em = Math.round(g("ptEmType")).toInt(); val mo = Math.round(g("ptMotion")).toInt()
        val behavior = Math.round(g("ptBehavior")).toInt()
        val explode = behavior == 1; val dissolve = behavior == 2
        val sx = g("ptSizeX"); val sy = g("ptSizeY"); val sz = g("ptSizeZ")        // radius per axis
        val px = g("ptPosX"); val py = g("ptPosY"); val pz = g("ptPosZ")
        val vel = g("ptVel"); val vr = g("ptVelRand"); val spread = g("ptSpread"); val lr = g("ptLifeRand")
        var ax = g("ptDirX"); var ay = g("ptDirY"); var az = g("ptDirZ")
        val al = max(sqrt(ax * ax + ay * ay + az * az), 0.0001f)
        ax /= al; ay /= al; az /= al
        val grav = g("ptGravity"); val wx = g("ptWindX"); val wy = g("ptWindY"); val wz = g("ptWindZ")
        val air = g("ptAir"); val turb = g("ptTurb"); val tf = max(g("ptTurbFreq"), 0.05f); val tsp = g("ptTurbSpeed")
        val swirl = g("ptSwirl"); val swPull = g("ptSwirlPull")
        val att = g("ptAttract"); val atx = g("ptAttX") - px; val aty = g("ptAttY") - py; val atz = g("ptAttZ") - pz
        val floorOn = g("ptFloorOn") >= 0.5f; val floorY = g("ptFloorY"); val bounce = g("ptBounce")
        val szr = g("ptSizeRand"); val s0 = g("ptSizeStart"); val s1 = g("ptSizeEnd")
        val softB = g("ptSoft"); val dof = g("ptDof"); val focus = g("ptFocus")
        val curlK = g("ptCurl"); val curlS = max(g("ptCurlScale"), 0.05f); val curlSp = g("ptCurlSpeed")
        val waveA = g("ptWaveAmp"); val waveF = g("ptWaveFreq"); val waveSp = g("ptWaveSpeed"); val waveFlow = g("ptWaveFlow")
        val flut = g("ptFlutter"); val flutF = max(g("ptFlutterFreq"), 0.1f)
        val spin = g("ptSpin"); val spinR = g("ptSpinRand"); val scat = g("ptScatter"); val quant = g("ptQuant")
        val twk = g("ptTwinkle"); val twkR = g("ptTwinkleRate")
        val shAmp = g("ptShockAmp"); val shSpd = g("ptShockSpeed"); val shW = max(g("ptShockWidth"), 0.01f); val shPer = g("ptShockPeriod"); val shGlow = g("ptShockGlow")
        val dStart = g("ptDissStart"); val dDur = max(g("ptDissDur"), 0.05f); val dSweep = g("ptDissSweep")
        val imgId = Math.round(g("ptEmImgId")).toInt(); val imgFps = max(g("ptEmFps"), 0.1f)
        val fin = fades(g).first
        val cells = max(2, Math.round(g("ptGridN")))
        val cells3 = cells * cells * cells
        fun gf(k: Int): Float = k.toFloat() / (cells - 1).toFloat() - 0.5f
        val opC = PtCurve.active(g, "Op"); val szC = PtCurve.active(g, "Sz"); val spC = PtCurve.active(g, "Sp")
        val spCum: FloatArray = if (spC == null) FloatArray(0) else {
            val r = FloatArray(33); r[0] = 0f
            for (k in 1..32) r[k] = r[k - 1] + (PtCurve.eval(spC, (k - 1) / 32f) + PtCurve.eval(spC, k / 32f)) / 32f
            r
        }
        val imgFrames = if (em == 13 || em == 14) PtImages.frameCount(imgId) else 0
        val out = ArrayList<Particle>(n * copies / max(step, 1) + 1)
        var pixCache = arrayOfNulls<List<PtPix>>(max(imgFrames, 1))
        val time = max(0f, t)
        val TAU = 6.2831853f
        var i = 0
        while (i < n) {
            val fi = i.toFloat()
            val h0 = hash(seed * 131 + fi); val h1 = hash(seed * 977 + fi * 7); val h2 = hash(seed * 3313 + fi * 13)
            val h3 = hash(seed * 6151 + fi * 29); val h4 = hash(seed * 17 + fi * 3); val h5 = hash(seed * 4001 + fi * 19)
            val h6 = hash(seed * 811 + fi * 23); val h7 = hash(seed * 523 + fi * 31); val h8 = hash(seed * 7919 + fi * 37)
            val lf = max(0.05f, life * (1 - lr * h6 * 0.8f))
            var age0 = if (explode) time else time - h0 * lf
            age0 %= lf
            if (age0 < 0) age0 += lf

            var bx = 0f; var by = 0f; var bz = 0f
            var pjx = 0f; var pjy = 0f; var pjz = 0f
            var pr = 1f; var pg = 1f; var pb = 1f
            when (em) {
                1 -> { bx = (h1 * 2 - 1) * sx; by = (h2 * 2 - 1) * sy; bz = (h5 * 2 - 1) * sz }
                2 -> {
                    val u = h2 * 2 - 1; val a = h1 * TAU; val r = Math.cbrt(h5.toDouble()).toFloat(); val rr = sqrt(1 - u * u)
                    bx = rr * cos(a) * r * sx; by = rr * sin(a) * r * sy; bz = u * r * sz
                }
                3 -> {
                    val c = i % cells3
                    bx = gf(c % cells) * 2 * sx; by = gf((c / cells) % cells) * 2 * sy; bz = gf(c / (cells * cells)) * 2 * sz
                }
                4 -> { val a = h1 * TAU; val r = sqrt(h5); bx = cos(a) * r * sx; bz = sin(a) * r * sz; by = (h2 * 2 - 1) * sy * 0.1f }
                5 -> { val a = h1 * TAU; bx = cos(a) * sx; bz = sin(a) * sz; by = (h2 * 2 - 1) * sy * 0.1f }
                6 -> { bx = (h1 * 2 - 1) * sx }
                7 -> { val hh = h2; val a = h1 * TAU; val r = sqrt(h5) * hh; bx = cos(a) * r * sx; bz = sin(a) * r * sz; by = (hh * 2 - 1) * sy }
                8 -> { val a = h1 * TAU; val r = sqrt(h5); bx = cos(a) * r * sx; bz = sin(a) * r * sz; by = (h2 * 2 - 1) * sy }
                9 -> { val a = h1 * TAU; val b = h2 * TAU; val k = sx + sy * cos(b); bx = k * cos(a); bz = k * sin(a); by = sy * sin(b) }
                10 -> { val a = h2 * TAU * 3; bx = cos(a) * sx; bz = sin(a) * sz; by = (h2 * 2 - 1) * sy }
                11 -> { bx = (h1 * 2 - 1) * sx; by = (h2 * 2 - 1) * sy; bz = (h5 * 2 - 1) * sz * 0.05f }
                12 -> { val u = h2 * 2 - 1; val a = h1 * TAU; val rr = sqrt(1 - u * u); bx = rr * cos(a) * sx; by = rr * sin(a) * sy; bz = u * sz }
                13, 14 -> {
                    var pix: List<PtPix> = emptyList()
                    if (imgFrames > 0) {
                        val fr = if (em == 14) floor(max(0f, if (dissolve) time else time - age0) * imgFps).toInt() % imgFrames else 0
                        if (pixCache[fr] == null) pixCache[fr] = PtImages.points(imgId, fr)
                        pix = pixCache[fr] ?: emptyList()
                    }
                    if (pix.isEmpty()) {
                        bx = (h1 * 2 - 1) * sx; by = (h2 * 2 - 1) * sy; bz = (h5 * 2 - 1) * sz * 0.05f
                    } else {
                        val q = pix[min(pix.size - 1, (h1 * pix.size).toInt())]
                        bx = q.x * 2 * sx; by = q.y * 2 * sy; bz = (h5 * 2 - 1) * sz * 0.05f
                        pr = q.r; pg = q.g; pb = q.b
                    }
                }
                15 -> { val a = h1 * TAU; bx = cos(a) * sx; by = sin(a) * sy; bz = (h5 * 2 - 1) * sz * 0.02f }
                16 -> { val a = h1 * TAU; val r = sqrt(h5); bx = cos(a) * r * sx; by = sin(a) * r * sy; bz = (h2 * 2 - 1) * sz * 0.02f }
                18 -> {   // path: spawn along the drawn curve (or at a travelling head), jittered by the radius
                    pjx = (h2 * 2 - 1) * sx; pjy = (h5 * 2 - 1) * sx; pjz = (h3 * 2 - 1) * sx
                    if (pathLUT.isEmpty()) { bx = (h1 * 2 - 1) * sx * 4; by = (h2 * 2 - 1) * sy; bz = (h5 * 2 - 1) * sz }
                    else {
                        val u0 = if (pathMode == 1) (time - age0) * pathSpeed else h1
                        val q = pp(u0)
                        bx = q.x + pjx; by = q.y + pjy; bz = q.z + pjz
                    }
                }
                17 -> {
                    if (modelPts.isEmpty()) {
                        bx = (h1 * 2 - 1) * sx; by = (h2 * 2 - 1) * sy; bz = (h5 * 2 - 1) * sz
                    } else {
                        val q = modelPts[min(modelPts.size - 1, (h1 * modelPts.size).toInt())]
                        bx = q.x + (h2 * 2 - 1) * 0.008f; by = q.y + (h5 * 2 - 1) * 0.008f; bz = q.z + (h3 * 2 - 1) * 0.008f
                    }
                }
                else -> {   // Point (0): radius X/Y/Z now sizes a soft ellipsoid around the position
                    val u = h2 * 2 - 1; val a = h1 * TAU; val r = Math.cbrt(h5.toDouble()).toFloat(); val rr = sqrt(1 - u * u)
                    bx = rr * cos(a) * r * sx; by = rr * sin(a) * r * sy; bz = u * r * sz
                }
            }
            // Volumetric shading: lit side towards the light, self-shadowed core / underside (multiplies the sprite colour).
            if (vol > 0.001f && em != 13 && em != 14) {
                val nx = bx / max(sx, 0.001f); val ny = by / max(sy, 0.001f); val nz = bz / max(sz, 0.001f)
                val nl = max(sqrt(nx * nx + ny * ny + nz * nz), 0.0001f)
                val lit = min(1f, max(0f, 0.5f + 0.5f * (nx * lx + ny * ly + nz * lz) / nl))
                val rim = min(1f, nl)
                val s = max(0.05f, 1 - vol * (0.7f * (1 - lit) + 0.3f * (1 - rim) * (1 - lit * 0.5f)))
                pr = s; pg = s * (0.96f + 0.04f * lit); pb = s * (0.88f + 0.12f * lit)
            }

            val u = h3 * 2 - 1; val a = h4 * TAU; val rr = sqrt(1 - u * u)
            val rx = rr * cos(a); val ry = rr * sin(a); val rz = u
            var vx = rx; var vy = ry; var vz = rz
            when (mo) {
                1 -> { val s: Float = if (h0 < 0.5f) -1f else 1f; vx = ax * s + rx * spread; vy = ay * s + ry * spread; vz = az * s + rz * spread }
                2 -> { vx = ax + rx * spread; vy = ay + ry * spread; vz = az + rz * spread }
                3 -> { val d = rx * ax + ry * ay + rz * az; vx = rx - d * ax; vy = ry - d * ay; vz = rz - d * az }
                4, 6 -> {
                    val l = max(sqrt(bx * bx + by * by + bz * bz), 0.0001f); val s: Float = if (mo == 4) -1f else 1f
                    vx = s * bx / l + rx * spread * 0.3f; vy = s * by / l + ry * spread * 0.3f; vz = s * bz / l + rz * spread * 0.3f
                }
                5 -> {
                    val l = max(sqrt(bx * bx + bz * bz), 0.0001f)
                    vx = -bz / l + rx * spread * 0.3f; vy = ry * spread * 0.3f; vz = bx / l + rz * spread * 0.3f
                }
                else -> {}
            }
            val spd = vel * (1 - vr * h7) * (if (quant > 0.0001f) 0.5f + hash(floor(bx / quant) * 13.7f + seed) else 1f)
            val birthT = time - age0

            // Position at a given age (pure function of age + the per-particle constants above).
            fun place(age: Float): FloatArray {
                val p = age / lf
                var travel = age
                if (spC != null) {
                    val f = min(max(p, 0f), 1f) * 32; val k = min(31, f.toInt())
                    travel = lf * (spCum[k] + (spCum[k + 1] - spCum[k]) * (f - k))
                } else if (air > 0.001f) { val k = air * 4; travel = (1 - exp(-k * age)) / k }
                var pbx = bx; var pby = by; var pbz = bz
                if (em == 18 && pathMode == 0 && pathLUT.isNotEmpty() && abs(pathFlow) > 0.0001f) {   // particles travel along the path
                    val q = pp(h1 + age * pathFlow)
                    pbx = q.x + pjx; pby = q.y + pjy; pbz = q.z + pjz
                }
                var x = pbx + vx * spd * travel + 0.5f * wx * age * age
                var y = pby + vy * spd * travel + 0.5f * (wy - grav) * age * age
                var z = pbz + vz * spd * travel + 0.5f * wz * age * age
                if (turb > 0.001f) {
                    val ph = age * 0.9f * tsp + h1 * TAU
                    x += sin(y * tf * 3 + ph) * turb * 0.15f
                    y += sin(z * tf * 3 + ph * 1.3f + 1.7f) * turb * 0.15f
                    z += sin(x * tf * 3 + ph * 0.7f + 3.1f) * turb * 0.15f
                }
                if (curlK > 0.001f && age > 0f) {
                    val K = 6; val dt = age / K
                    var qx = 0f; var qy = 0f; var qz = 0f
                    for (k in 0 until K) {
                        val tt = k * dt
                        val sx0 = (bx + vx * spd * tt + qx) * curlS
                        val sy0 = (by + vy * spd * tt + qy) * curlS
                        val sz0 = (bz + vz * spd * tt + qz) * curlS
                        val c = curl(sx0, sy0, sz0, (birthT + tt) * curlSp)
                        val kk = curlK * dt * 0.6f
                        qx += c.first * kk; qy += c.second * kk; qz += c.third * kk
                    }
                    x += qx; y += qy; z += qz
                }
                if (waveA > 0.001f || abs(waveFlow) > 0.001f) {
                    val wt = birthT + age
                    y += waveA * sin(waveF * x + waveSp * wt) * cos(waveF * 0.8f * z + waveSp * 0.7f * wt + 1.3f)
                    x += waveFlow * age
                }
                if (flut > 0.001f) {
                    val fph = h1 * TAU
                    x += sin(age * flutF + fph) * flut * 0.18f * (0.4f + 0.6f * h2)
                    z += cos(age * flutF * 0.8f + fph * 1.3f) * flut * 0.18f * (0.4f + 0.6f * h5)
                    y += sin(age * flutF * 1.7f + fph) * flut * 0.03f
                }
                var boost = 0f
                if (shAmp > 0.001f) {                                  // expanding shockwave front pushes particles radially
                    val r0 = max(sqrt(bx * bx + by * by + bz * bz), 0.0001f)
                    val wt = if (shPer > 0.01f) (birthT + age) % shPer else (birthT + age)
                    val d = (r0 - shSpd * wt) / shW; val gs = exp(-d * d)
                    x += bx / r0 * shAmp * gs; y += by / r0 * shAmp * gs; z += bz / r0 * shAmp * gs
                    boost = gs
                }
                if (scat > 0.001f && age > 0f) {
                    val sc = scat * age.pow(1.3f) * 0.5f
                    x += rx * sc; y += ry * sc; z += rz * sc
                }
                if (abs(swirl) > 0.001f || swPull > 0.001f) {          // spiral around the emitter's Y axis
                    val ang = swirl * age; val ca = cos(ang); val sa = sin(ang); val k = 1 - swPull * p
                    val nx = (x * ca - z * sa) * k; val nz = (x * sa + z * ca) * k
                    x = nx; z = nz
                }
                if (att > 0.001f) {                                    // attractor point pulls particles in over their life
                    val m = min(1f, att * p)
                    x += (atx - x) * m; y += (aty - y) * m; z += (atz - z) * m
                }
                if (quant > 0.0001f) {
                    x = (floor(x / quant) + 0.5f) * quant; z = (floor(z / quant) + 0.5f) * quant
                    y = (floor(y / (quant * 1.3f)) + 0.5f) * quant * 1.3f
                }
                x += px; y += py; z += pz
                if (floorOn && y < floorY) y = floorY + (floorY - y) * bounce
                return floatArrayOf(x, y, z, boost)
            }

            // Dissolve: hold at the emitter shape, then release each particle at its own moment.
            var mainAge = age0
            var held = false
            if (dissolve) {
                val sweep = min(1f, max(0f, bx / max(sx, 0.0001f) * 0.5f + 0.5f))
                val thr = h6 * (1 - dSweep) + sweep * dSweep
                mainAge = time - (dStart + thr * dDur)
                if (mainAge < 0) { held = true; mainAge = 0f }
                else if (mainAge >= lf) { i += max(step, 1); continue }
            }
            for (c in 0 until copies) {
                if (held && c > 0) break
                val age = mainAge - c * trailLen / max(trail, 1).toFloat()
                if (age < 0f && !held) continue
                val p0 = max(0f, age) / lf
                val p = if (dissolve) min(1f, fin + p0 * (1 - fin)) else p0
                val pos = place(max(0f, age))
                val tf2 = if (mbOn) (if (c == 0) 1f else 0.55f * (1 - c.toFloat() / copies) + 0.1f) else 1 - c.toFloat() / copies
                val base = (1 - szr) + szr * h2 * 1.8f
                val size = base * (if (szC != null) PtCurve.eval(szC, p) * 2 else s0 + (s1 - s0) * p) * (if (mbOn) 1f else 1 - 0.5f * c / copies) * (1 + pos[3] * shGlow)
                val soft = min(1f, max(0f, softB + abs(pos[2] - focus) * dof * 0.8f))
                var alpha = (if (opC != null) PtCurve.eval(opC, p) else 1f) * tf2
                if (twk > 0.001f) alpha *= 1 - twk * (0.5f + 0.5f * sin(max(0f, age) * max(twkR, 0.1f) * TAU + h5 * TAU))
                out.add(Particle(pos[0], pos[1], pos[2], size, p, soft, alpha,
                    h4 * TAU * spinR + spin * max(0f, age) * (0.6f + 0.8f * h6), h8, pr, pg, pb))
            }
            i += max(step, 1)
        }
        return out
    }

    private fun hash(x: Float): Float {
        var n: Long = ((x * 8192.0).toLong()) * 747796405L + 2891336453L
        n = ((n ushr ((n ushr 28) + 4).toInt()) xor n) * 277803737L
        n = (n ushr 22) xor n
        return ((n % 100000L).toFloat()) / 100000f
    }
}
