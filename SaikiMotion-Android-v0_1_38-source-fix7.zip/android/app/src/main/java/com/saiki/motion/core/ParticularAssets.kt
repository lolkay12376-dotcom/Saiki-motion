package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// Port of Sources/Render/ParticularAssets.swift (PtPath, PtGradient, PtImages, PtParams, PtSprites)
// + Render/Particular.swift pieces already in Particular.kt. Bitmap drawing replaces CGImage/UIGraphicsImageRenderer
// with identical geometry (512x512 sheets, same cells/grid, same keyBlack maths).

class PtStop(val p: Float, val r: Float, val g: Float, val b: Float, val a: Float) {
    companion object {
        fun from(c: Int, p: Float) = PtStop(p,
            ((c ushr 16) and 0xFF) / 255f, ((c ushr 8) and 0xFF) / 255f, (c and 0xFF) / 255f, ((c ushr 24) and 0xFF) / 255f)
    }
}

class PtPix(val x: Float, val y: Float, val r: Float, val g: Float, val b: Float)

object PtPath {
    const val cap = 24
    val allKeys: List<String> get() = listOf("ptPathN") + (0 until cap).flatMap { listOf("ptPathX$it", "ptPathY$it", "ptPathZ$it") }

    fun read(g: (String) -> Float): List<V3> {
        val n = min(cap, max(0, Math.round(g("ptPathN"))))
        return (0 until n).map { V3(g("ptPathX$it"), g("ptPathY$it"), g("ptPathZ$it")) }
    }

    fun params(pts: List<V3>, closed: Boolean = false): Map<String, Float> {
        val d = HashMap<String, Float>()
        d["ptPathN"] = min(cap, pts.size).toFloat()
        d["ptPathClosed"] = if (closed) 1f else 0f
        for ((i, p) in pts.take(cap).withIndex()) {
            d["ptPathX$i"] = p.x; d["ptPathY$i"] = p.y; d["ptPathZ$i"] = p.z
        }
        return d
    }

    fun write(l: Layer, pts: List<V3>, pre: String = "") {
        for ((k, v) in params(pts)) if (k != "ptPathClosed") l.track(pre + k).base = v
    }

    /** n points evenly spaced by arc length along the polyline. */
    fun resample(pts: List<V3>, n: Int): List<V3> {
        if (pts.size < 2 || n < 2) return pts
        val cum = ArrayList<Float>(pts.size)
        cum.add(0f)
        for (i in 1 until pts.size) {
            val d = pts[i] - pts[i - 1]
            cum.add(cum[i - 1] + sqrt(d.x * d.x + d.y * d.y + d.z * d.z))
        }
        val total = cum[cum.size - 1]
        if (total <= 1e-6f) return List(n) { pts[0] }
        val out = ArrayList<V3>(n); var j = 1
        for (k in 0 until n) {
            val t = total * k / (n - 1).toFloat()
            while (j < cum.size - 1 && cum[j] < t) j++
            val seg = max(cum[j] - cum[j - 1], 1e-6f); val f = min(1f, max(0f, (t - cum[j - 1]) / seg))
            val a = pts[j - 1]; val b = pts[j]
            out.add(V3(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f, a.z + (b.z - a.z) * f))
        }
        return out
    }

    /** Smooth (Catmull-Rom) path as 128 evenly spaced samples; empty when fewer than 2 points. */
    fun lut(g: (String) -> Float): List<V3> {
        val c = read(g); val n = c.size
        if (n < 2) return emptyList()
        val closed = g("ptPathClosed") >= 0.5f
        fun at(i: Int): V3 = if (closed) c[((i % n) + n) % n] else c[min(n - 1, max(0, i))]
        val dense = ArrayList<V3>()
        for (i in 0 until (if (closed) n else n - 1)) {
            val p0 = at(i - 1); val p1 = at(i); val p2 = at(i + 1); val p3 = at(i + 2)
            for (s in 0 until 12) {
                val t = s / 12f; val t2 = t * t; val t3 = t2 * t
                val a = V3(p1.x * 2f, p1.y * 2f, p1.z * 2f)
                val b = V3((p2.x - p0.x) * t, (p2.y - p0.y) * t, (p2.z - p0.z) * t)
                val c0 = V3(p0.x * 2f - p1.x * 5f + p2.x * 4f - p3.x, p0.y * 2f - p1.y * 5f + p2.y * 4f - p3.y, p0.z * 2f - p1.z * 5f + p2.z * 4f - p3.z)
                val cc = V3(c0.x * t2, c0.y * t2, c0.z * t2)
                val d0 = V3(p1.x * 3f - p0.x - p2.x * 3f + p3.x, p1.y * 3f - p0.y - p2.y * 3f + p3.y, p1.z * 3f - p0.z - p2.z * 3f + p3.z)
                val dd = V3(d0.x * t3, d0.y * t3, d0.z * t3)
                dense.add(V3((a.x + b.x + cc.x + dd.x) * 0.5f, (a.y + b.y + cc.y + dd.y) * 0.5f, (a.z + b.z + cc.z + dd.z) * 0.5f))
            }
        }
        dense.add(if (closed) c[0] else c[n - 1])
        return resample(dense, 128)
    }
}

object PtGradient {
    const val cap = 8
    fun read(g: (String) -> Float): List<PtStop> {
        val n = min(cap, max(0, Math.round(g("ptGrN"))))
        return (0 until n).map { PtStop(g("ptGrP$it"), g("ptGrR$it"), g("ptGrG$it"), g("ptGrB$it"), g("ptGrA$it")) }.sortedBy { it.p }
    }
    fun active(g: (String) -> Float): List<PtStop>? {
        if (g("ptGrOn") < 0.5f) return null
        val s = read(g)
        return if (s.size >= 2) s else null
    }
    fun params(s: List<PtStop>, on: Boolean = true): Map<String, Float> {
        val d = HashMap<String, Float>()
        d["ptGrOn"] = if (on) 1f else 0f
        d["ptGrN"] = min(cap, s.size).toFloat()
        for ((i, q) in s.withIndex()) {
            if (i >= cap) break
            d["ptGrP$i"] = q.p; d["ptGrR$i"] = q.r; d["ptGrG$i"] = q.g; d["ptGrB$i"] = q.b; d["ptGrA$i"] = q.a
        }
        return d
    }
    fun write(l: Layer, s: List<PtStop>, pre: String = "") {
        for ((k, v) in params(s, true)) l.track(pre + k).base = v
    }
    val allKeys: List<String>
        get() = listOf("ptGrOn", "ptGrN", "ptGrBy") + (0 until cap).flatMap { listOf("ptGrP$it", "ptGrR$it", "ptGrG$it", "ptGrB$it", "ptGrA$it") }

    fun evenly(colors: IntArray): List<PtStop> =
        colors.mapIndexed { i, c -> PtStop.from(c, if (colors.size > 1) i.toFloat() / (colors.size - 1) else 0f) }

    /** eval returns [r,g,b,a]. */
    fun eval(s: List<PtStop>, x: Float): FloatArray {
        if (s.isEmpty()) return floatArrayOf(1f, 1f, 1f, 1f)
        val f = s.first(); val l = s.last()
        fun v(q: PtStop) = floatArrayOf(q.r, q.g, q.b, q.a)
        if (x <= f.p) return v(f)
        if (x >= l.p) return v(l)
        for (i in 1 until s.size) {
            if (x <= s[i].p) {
                val a = s[i - 1]; val b = s[i]; val t = (x - a.p) / max(b.p - a.p, 0.0001f)
                return floatArrayOf(a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t, a.a + (b.a - a.a) * t)
            }
        }
        return v(l)
    }

    /** 16 samples for the shader (flat r,g,b,a * 16 * 4). */
    fun lut(s: List<PtStop>?): Array<FloatArray> =
        if (s == null) Array(16) { floatArrayOf(1f, 1f, 1f, 1f) }
        else Array(16) { eval(s, it / 15f) }

    val presets: List<Pair<String, IntArray>> = listOf(
        "Fire" to intArrayOf(0xFFFFF2B0.toInt(), 0xFFFFB020.toInt(), 0xFFFF4A00.toInt(), 0xFF8A0F00.toInt(), 0x00300000),
        "Ember" to intArrayOf(0xFFFFE08A.toInt(), 0xFFFF7A1F.toInt(), 0xFFC62800.toInt(), 0x00400000),
        "Lava" to intArrayOf(0xFFFFFF9A.toInt(), 0xFFFF8800.toInt(), 0xFFC1121F.toInt(), 0xFF3A0000.toInt()),
        "Sparks" to intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFE27A.toInt(), 0xFFFF7A1F.toInt(), 0x00FF3B00),
        "Thermal" to intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFFF00.toInt(), 0xFFFF6A00.toInt(), 0xFFFF0000.toInt(), 0xFF400000.toInt()),
        "Gold" to intArrayOf(0xFFFFF4C2.toInt(), 0xFFFFD34D.toInt(), 0xFFD18A00.toInt(), 0xFF6B3E00.toInt()),
        "Glisten" to intArrayOf(0xFFFFF8E0.toInt(), 0xFFF2D49A.toInt(), 0xFFC9A063.toInt(), 0x00706040),
        "Ice" to intArrayOf(0xFFFFFFFF.toInt(), 0xFFA8E6FF.toInt(), 0xFF38BDF8.toInt(), 0x001E3A8A),
        "Ocean" to intArrayOf(0xFFB8F3FF.toInt(), 0xFF22A6D9.toInt(), 0xFF0B4F8A.toInt(), 0xFF031B3D.toInt()),
        "Aurora" to intArrayOf(0xFF7CFFB2.toInt(), 0xFF2BD9C8.toInt(), 0xFF5B6CFF.toInt(), 0xFFB05BFF.toInt()),
        "Sunset" to intArrayOf(0xFFFFD27A.toInt(), 0xFFFF7A59.toInt(), 0xFFD6336C.toInt(), 0xFF5B2A86.toInt()),
        "Neon" to intArrayOf(0xFFFF2BD6.toInt(), 0xFF8A2BFF.toInt(), 0xFF2BFFE0.toInt()),
        "Plasma" to intArrayOf(0xFFFFFFFF.toInt(), 0xFFFF6AD5.toInt(), 0xFF7C3AED.toInt(), 0xFF1D1B6B.toInt()),
        "Galaxy" to intArrayOf(0xFFFFFFFF.toInt(), 0xFFA8B8FF.toInt(), 0xFF6A4CFF.toInt(), 0xFF2A0F6B.toInt()),
        "Twilight" to intArrayOf(0xFFFFC4A3.toInt(), 0xFFB05BFF.toInt(), 0xFF1D1B6B.toInt()),
        "Rose" to intArrayOf(0xFFFF8FA3.toInt(), 0xFFE01E37.toInt(), 0xFF8A0A22.toInt()),
        "Blood" to intArrayOf(0xFFFF5A5A.toInt(), 0xFFB00020.toInt(), 0xFF3A0008.toInt()),
        "Sakura" to intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD6E4.toInt(), 0xFFFF9FC0.toInt()),
        "Candy" to intArrayOf(0xFFFF8AD8.toInt(), 0xFFFFE66D.toInt(), 0xFF6DE6FF.toInt()),
        "Rainbow" to intArrayOf(0xFFFF3B3B.toInt(), 0xFFFFB020.toInt(), 0xFFFFF04A.toInt(), 0xFF3BE06B.toInt(), 0xFF3B9BFF.toInt(), 0xFF9B4BFF.toInt()),
        "Matrix" to intArrayOf(0xFF00561F.toInt(), 0xFF00E050.toInt(), 0xFFB8FFC8.toInt(), 0xFFFFFFFF.toInt()),
        "Toxic" to intArrayOf(0xFFEFFF8A.toInt(), 0xFF9BE000.toInt(), 0xFF2F7A00.toInt()),
        "Forest" to intArrayOf(0xFFD9FF9A.toInt(), 0xFF4DBB4A.toInt(), 0xFF14532D.toInt()),
        "Mint" to intArrayOf(0xFFEFFFF8.toInt(), 0xFF86F5CF.toInt(), 0xFF1BB894.toInt()),
        "Smoke" to intArrayOf(0xFFFFFFFF.toInt(), 0xFF9A9AA6.toInt(), 0x003A3A44),
        "Steel" to intArrayOf(0xFFFFFFFF.toInt(), 0xFFB7C4D6.toInt(), 0xFF5E6E85.toInt()),
        "White Fade" to intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0x00FFFFFF),
        "Cyan Fade" to intArrayOf(0xFFFFFFFF.toInt(), 0xFF38BDF8.toInt(), 0x000B4F8A))
}

// MARK: - Parameter access

object PtParams {
    /** Default of any Particular parameter (registry default, birth/death colour defaults, else 0). */
    fun def(key: String): Float {
        val k = PtGroup.strip(key)
        Registry.propDef(k)?.let { return it.def }
        for ((n, c) in listOf(Pair("ptColA", ParticularSim.defA), Pair("ptColB", ParticularSim.defB))) {
            if (k.startsWith(n + "_")) {
                return when (k.last()) {
                    'a' -> ((c ushr 24) and 0xFF) / 255f
                    'r' -> ((c ushr 16) and 0xFF) / 255f
                    'g' -> ((c ushr 8) and 0xFF) / 255f
                    else -> (c and 0xFF) / 255f
                }
            }
        }
        return 0f
    }
    fun reader(d: Map<String, Float>): (String) -> Float = { d[it] ?: def(it) }
    fun colorKeys(n: String): List<String> = listOf("_r", "_g", "_b", "_a").map { n + it }
    /** ParticularAssets.swift:106 PtParams.color — 0xAARRGGBB -> 4 Float tracks. */
    fun color(n: String, c: Int): Map<String, Float> = mapOf(
        n + "_a" to ((c ushr 24) and 0xFF) / 255f,
        n + "_r" to ((c ushr 16) and 0xFF) / 255f,
        n + "_g" to ((c ushr 8) and 0xFF) / 255f,
        n + "_b" to (c and 0xFF) / 255f)
    /** Every key a preset can carry. */
    val allKeys: List<String>
        get() {
            var base = ArrayList<String>()
            Registry.get("particular")?.let { d -> base.addAll(d.props.map { it.key }) }
            base.addAll(colorKeys("ptColA")); base.addAll(colorKeys("ptColB"))
            base.addAll(PtCurve.allKeys); base.addAll(PtGradient.allKeys); base.addAll(PtPath.allKeys)
            return base
        }
}

// MARK: - Imported images / videos (sprite sheets and emitter shapes)

object PtImages {
    const val size = 512
    private val cache = HashMap<Int, Pair<Bitmap, Int>>()
    private val pts = HashMap<String, List<PtPix>>()
    private val lock = Object()

    val dir: File get() = File(Paths.root, "ParticleSprites").apply { mkdirs() }
    fun grid(cells: Int): Int = if (cells <= 1) 1 else (if (cells <= 4) 2 else 4)

    private fun file(id: Int): Pair<File, Int>? {
        if (id <= 0) return null
        val fs = dir.listFiles() ?: return null
        for (f in fs) {
            if (f.name.startsWith("${id}_") && f.extension == "png") {
                val c = f.nameWithoutExtension.split("_").lastOrNull()?.toIntOrNull() ?: 1
                return Pair(f, c)
            }
        }
        return null
    }

    fun load(id: Int): Pair<Bitmap, Int>? {
        synchronized(lock) {
            cache[id]?.let { return it }
            val (u, c) = file(id) ?: return null
            val im = try { BitmapFactory.decodeFile(u.absolutePath) } catch (_: Exception) { null } ?: return null
            cache[id] = im to c
            return im to c
        }
    }

    fun frameCount(id: Int): Int = load(id)?.second ?: 0
    fun data(id: Int): Pair<ByteArray, Int>? {
        val (u, c) = file(id) ?: return null
        return try { Pair(u.readBytes(), c) } catch (_: Exception) { null }
    }

    private fun newId(): Int {
        var id = (1000..16_000_000).random()
        while (file(id) != null) id = (1000..16_000_000).random()
        return id
    }

    private fun fit(w: Int, h: Int, r: RectF): RectF {
        val s = min(r.width() / w, r.height() / h)
        val bw = w * s; val bh = h * s
        return RectF(r.centerX() - bw / 2, r.centerY() - bh / 2, r.centerX() + bw / 2, r.centerY() + bh / 2)
    }

    private fun sheet(frames: List<Bitmap>): Bitmap {
        val g = grid(frames.size); val cs = (size / g).toFloat()
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        for ((i, im) in frames.withIndex()) {
            val cell = RectF((i % g) * cs, (i / g) * cs, (i % g) * cs + cs, (i / g) * cs + cs)
            cell.inset(1f, 1f)
            val d = fit(im.width, im.height, cell)
            c.drawBitmap(im, null, d, Paint(Paint.FILTER_BITMAP_FLAG))
        }
        return out
    }

    fun add(frames: List<Bitmap>): Int? {
        if (frames.isEmpty()) return null
        val id = newId()
        val u = File(dir, "${id}_${if (frames.size <= 1) 1 else 16}.png")
        try {
            val png = sheet(frames)
            u.outputStream().use { png.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) { return null }
        return id
    }

    /** Photo on a black background -> transparent background (alpha from brightness). */
    fun keyBlack(im: Bitmap): Bitmap {
        val s = min(1.0, 1024.0 / max(im.width, im.height).toDouble()).toFloat()
        val w = max(1, (im.width * s).toInt()); val h = max(1, (im.height * s).toInt())
        val px = IntArray(w * h)
        val scaled = Bitmap.createScaledBitmap(im, w, h, true)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        val out = IntArray(w * h)
        for (i in 0 until w * h) {
            val c = px[i]
            val r = ((c shr 16) and 0xFF).toFloat(); val g = ((c shr 8) and 0xFF).toFloat(); val b = (c and 0xFF).toFloat()
            val a = min(1f, max(0f, (max(r, max(g, b)) / 255f - 0.05f) / 0.1f))
            out[i] = (((a * 255).toInt()) shl 24) or ((((r * a).toInt()) and 0xFF) shl 16) or ((((g * a).toInt()) and 0xFF) shl 8) or (((b * a).toInt()) and 0xFF)
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }

    fun addImage(image: Bitmap): Int? = add(listOf(image))

    fun addData(data: ByteArray, cells: Int): Int? {
        val id = newId()
        val u = File(dir, "${id}_${if (cells <= 1) 1 else 16}.png")
        return try { u.writeBytes(data); id } catch (_: Exception) { null }
    }

    /** 16 evenly spaced frames of a video into a flipbook (MediaMetadataRetriever replaces AVAssetImageGenerator). */
    fun addVideo(path: String, done: (Int?) -> Unit) {
        Thread {
            val r = android.media.MediaMetadataRetriever()
            val frames = ArrayList<Bitmap>()
            try {
                r.setDataSource(path)
                val dur = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                for (i in 0 until 16) {
                    val us = dur * 1000L * i / 16L
                    val f = r.getFrameAtTime(us, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                    frames.add(f)
                }
            } catch (_: Exception) {
            } finally { try { r.release() } catch (_: Exception) {} }
            done(if (frames.isEmpty()) null else add(frames))
        }.start()
    }

    /** Emitter shape pixels: sampled from cell 0 (grid rescaled to a max side like the iOS `cs`). */
    fun points(id: Int, frame: Int): List<PtPix> {
        val (im, cells) = load(id) ?: return emptyList()
        val key = "$id/$frame"
        synchronized(lock) { pts[key]?.let { return it } }
        val g = grid(cells)
        val cs = 48
        val out = ArrayList<PtPix>()
        val srcCell = if (cells > 1 && frame < cells) frame else 0
        val cw = im.width / g; val chh = im.height / g
        val cell = Bitmap.createBitmap(im, (srcCell % g) * cw, (srcCell / g) * chh, cw, chh)
        val small = Bitmap.createScaledBitmap(cell, cs, cs, true)
        val px = IntArray(cs * cs)
        small.getPixels(px, 0, cs, 0, 0, cs, cs)
        for (yy in 0 until cs) for (xx in 0 until cs) {
            val c = px[yy * cs + xx]
            val a = ((c ushr 24) and 0xFF) / 255f
            if (a < 0.35f) continue
            val r = min(1f, ((c shr 16) and 0xFF) / 255f)
            val gg = min(1f, ((c shr 8) and 0xFF) / 255f)
            val b = min(1f, (c and 0xFF) / 255f)
            out.add(PtPix((xx + 0.5f) / cs - 0.5f, 0.5f - (yy + 0.5f) / cs, r, gg, b))
        }
        synchronized(lock) { pts[key] = out }
        return out
    }
}

// MARK: - Sprites

class PtSpriteSet(val cells: Int, val grid: Int, val key: String, val bmp: Bitmap) {
    fun rgba(): ByteArray {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val out = ByteArray(w * h * 4)
        for (i in 0 until w * h) {
            val c = px[i]
            out[i * 4] = ((c shr 16) and 0xFF).toByte(); out[i * 4 + 1] = ((c shr 8) and 0xFF).toByte()
            out[i * 4 + 2] = (c and 0xFF).toByte(); out[i * 4 + 3] = ((c ushr 24) and 0xFF).toByte()
        }
        return out
    }
}

object PtSprites {
    val names = listOf("Dot", "Square", "Star", "Glyph", "Petal", "Bokeh", "Custom", "Pink Petal", "Cloud", "Leaf", "Maple Leaf")
    private val cache = HashMap<String, PtSpriteSet>()
    private val lock = Object()

    /** g reads the layer's Particular props; returns null for kind 0 (plain dot). */
    fun set(g: (String) -> Float): PtSpriteSet? {
        val kind = Math.round(g("ptSprite")).toInt()
        if (kind <= 0) return null
        val customId = Math.round(g("ptSpriteImg")).toInt()
        val key = if (kind == 6) "c$customId" else "k$kind"
        synchronized(lock) { cache[key]?.let { return it } }
        var atlas: Bitmap? = null
        var cells = 1
        when (kind) {
            1 -> {   // Square
                atlas = render { c -> run { } }
                atlas = render { c ->
                    val p = Paint(Paint.ANTI_ALIAS_FLAG); p.color = Color.WHITE
                    c.drawRoundRect(RectF(96f, 96f, 416f, 416f), 30f, 30f, p)
                }
            }
            2 -> {   // Star: radial core + two crossed quad petals
                atlas = render { c ->
                    val p = Paint(Paint.ANTI_ALIAS_FLAG)
                    p.shader = RadialGradient(256f, 256f, 70f, Color.WHITE, Color.TRANSPARENT, Shader.TileMode.CLAMP)
                    c.drawCircle(256f, 256f, 70f, p)
                    p.shader = null; p.color = Color.WHITE
                    for ((w, h) in listOf(Pair(480f, 26f), Pair(26f, 480f))) {
                        val path = Path()
                        path.moveTo(256f - w / 2, 256f)
                        path.quadTo(256f - 14f, 256f - 14f, 256f, 256f - h / 2)
                        path.quadTo(256f + 14f, 256f - 14f, 256f + w / 2, 256f)
                        path.quadTo(256f + 14f, 256f + 14f, 256f, 256f + h / 2)
                        path.quadTo(256f - 14f, 256f + 14f, 256f - w / 2, 256f)
                        path.close()
                        c.drawPath(path, p)
                    }
                }
            }
            3 -> {   // Glyph: 16-cell flipbook of glyph shapes
                cells = 16
                atlas = renderGlyphs()
            }
            4, 8 -> {   // Petal / Pink Petal: bundle assets
                atlas = assetBmp(if (kind == 4) "pt_petal" else "pt_petal2", 1)
            }
            5 -> {   // Bokeh: soft radial
                atlas = render { c ->
                    val p = Paint(Paint.ANTI_ALIAS_FLAG)
                    p.shader = RadialGradient(256f, 256f, 240f, intArrayOf(Color.WHITE, Color.WHITE, Color.TRANSPARENT), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
                    c.drawCircle(256f, 256f, 240f, p)
                }
            }
            6 -> {   // Custom: imported sheet
                val (im, c) = PtImages.load(customId) ?: return null
                atlas = im; cells = c
            }
            9 -> {   // Cloud
                atlas = assetBmp("pt_cloud", 1)
            }
            10 -> {  // Leaf
                atlas = assetBmp("pt_leaf_bump", 1)
            }
            11 -> {  // Maple Leaf
                atlas = assetBmp("pt_leaf2", 1)
            }
        }
        val a = atlas ?: return null
        val s = PtSpriteSet(cells, PtImages.grid(cells), key, a)
        synchronized(lock) { if (cache.size > 24) cache.clear(); cache[key] = s }
        return s
    }

    private fun render(draw: (Canvas) -> Unit): Bitmap {
        val b = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        draw(c)
        return b
    }

    private fun assetBmp(name: String, expected: Int): Bitmap? {
        // bundle images live in shared/resources/img (iOS Resources/img)
        return try {
            Paths.appContext.assets.open("img/$name.png").use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) { null }
    }

    /** Glyph flipbook (iOS draws 16 glyph shapes; Android draws the same 16 letter shapes). */
    private fun renderGlyphs(): Bitmap {
        val glyphs = listOf("✦", "✧", "✶", "✷", "✸", "✹", "❋", "❊", "❉", "❈", "✺", "✷", "✶", "✧", "✦", "★")
        val b = Bitmap.createBitmap(512, 512, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 96f; textAlign = Paint.Align.CENTER }
        for (i in glyphs.indices) {
            val cs = 128f
            c.drawText(glyphs[i], (i % 4) * cs + cs / 2, (i / 4) * cs + cs / 2 + 34f, p)
        }
        return b
    }
}
