package com.saiki.motion.core

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

// Port of Sources/Model/Physics3D.swift: secondary motion on top of the pose (VRM spring bones, PMX rigid bodies + joints).
// All values are in model space (the skeleton's own space), so layer moves do not feed the simulation.

class SpringJoint(var bone: Int, var tailLocal: V3, var stiffness: Float, var drag: Float, var gravity: Float,
                  var gravityDir: V3, var radius: Float, var groups: List<Int>)

class PhysCollider(var bone: Int, var offset: V3, var tail: V3?, var radius: Float, var inside: Boolean = false)

class PmxBody(var bone: Int, var group: Int, var mask: Int, var shape: Int, var size: V3, var pos: V3, var rot: Quat,
              var mass: Float, var linDamp: Float, var angDamp: Float, var repulsion: Float, var friction: Float, var mode: Int)

class PmxJoint(var a: Int, var b: Int, var pos: V3, var moveLo: V3, var moveHi: V3, var rotLo: V3, var rotHi: V3, var springMove: V3, var springRot: V3)

class Physics3D {
    var springs = mutableListOf<SpringJoint>()
    var colliders = mutableListOf<PhysCollider>()
    var groups = mutableListOf<List<Int>>()
    var bodies = mutableListOf<PmxBody>()
    var joints = mutableListOf<PmxJoint>()
    var gravityUnits = 98f         // PMX gravity in model units per second squared (1 unit ~ 8 cm)
    var lastT: Float? = null
    /** Inputs set by the viewport every frame. */
    var worldXf = M4.identity()      // model space -> world
    var windWorld = V3.ZERO          // world-space wind acceleration
    var groundY: Float? = null       // world-space floor (collision)
    var disturb = false              // the pose was edited this frame
    private var prevXf: M4? = null
    private var awake = 0f           // seconds of simulation left after the last disturbance
    private var windLocal = V3.ZERO
    private var invXf = M4.identity()
    private var xfScale = 1f

    val active: Boolean get() = springs.isNotEmpty() || bodies.any { it.mode != 0 && it.bone >= 0 }

    // derived / state
    private var acc = 0f
    private var prepared = false
    private var springOf = IntArray(0)
    private var cur = arrayOf<V3>(); private var prv = arrayOf<V3>()
    private var springInit = BooleanArray(0)
    private var dyn = mutableListOf<Int>(); private var kin = mutableListOf<Int>()
    private var bodiesOf = Array(0) { mutableListOf<Int>() }
    private var childDriven = IntArray(0)
    private var bodyOff = arrayOf<V3>()
    private var pp = arrayOf<V3>(); private var pq = arrayOf<V3>()
    private var tgt = arrayOf<V3>(); private var kAxis = arrayOf<V3>()
    private var ks = FloatArray(0); private var prad = FloatArray(0); private var krad = FloatArray(0); private var khalf = FloatArray(0); private var invM = FloatArray(0)
    private var axisLocal = arrayOf<V3>()
    private var jRest = FloatArray(0)
    private var pInit = false

    // MARK: setup
    private fun prepare(sk: Skeleton3D) {
        val n = sk.bones.size
        springOf = IntArray(n) { -1 }
        for ((k, s) in springs.withIndex()) if (s.bone >= 0 && s.bone < n) springOf[s.bone] = k
        cur = Array(springs.size) { V3.ZERO }; prv = Array(springs.size) { V3.ZERO }
        springInit = BooleanArray(springs.size)

        val nb = bodies.size
        bodiesOf = Array(n) { mutableListOf<Int>() }
        dyn = mutableListOf(); kin = mutableListOf()
        bodyOff = Array(nb) { V3.ZERO }
        tgt = Array(nb) { V3.ZERO }; kAxis = Array(nb) { V3.ZERO }; axisLocal = Array(nb) { V3.ZERO }; pp = Array(nb) { V3.ZERO }; pq = Array(nb) { V3.ZERO }
        ks = FloatArray(nb); prad = FloatArray(nb); krad = FloatArray(nb); khalf = FloatArray(nb); invM = FloatArray(nb)
        for ((k, b) in bodies.withIndex()) {
            val valid = b.bone >= 0 && b.bone < n
            bodyOff[k] = if (valid) b.pos - pos(sk.bones[b.bone].bindWorld) else b.pos
            if (b.mode != 0 && valid) { dyn.add(k); bodiesOf[b.bone].add(k) } else kin.add(k)
            // collision shape
            val s = b.size
            when (b.shape) {
                0 -> { krad[k] = s.x; khalf[k] = 0f; axisLocal[k] = V3(0f, 1f, 0f); prad[k] = s.x }
                2 -> { krad[k] = s.x; khalf[k] = max(s.y, 0f) * 0.5f; axisLocal[k] = V3(0f, 1f, 0f); prad[k] = s.x }
                else -> {                                   // box (half extents): capsule along the longest side
                    val m = max(s.x, max(s.y, s.z))
                    val ax = if (m == s.x) V3(1f, 0f, 0f) else if (m == s.y) V3(0f, 1f, 0f) else V3(0f, 0f, 1f)
                    val others = listOf(s.x, s.y, s.z).sorted()
                    krad[k] = others[0]; khalf[k] = max(m - others[0], 0f); axisLocal[k] = ax; prad[k] = others[0]
                }
            }
            invM[k] = 1 / min(max(b.mass, 0.05f), 20f)
        }
        // rest pull per dynamic body: stronger for "physics + bone alignment" and for stiff joints
        val sum = FloatArray(nb); val cnt = FloatArray(nb)
        for (j in joints) {
            val rotSum = abs(j.springRot.x) + abs(j.springRot.y) + abs(j.springRot.z)
            val moveSum = abs(j.springMove.x) + abs(j.springMove.y) + abs(j.springMove.z)
            val st = (rotSum + moveSum) / 6
            for (k in intArrayOf(j.a, j.b)) if (k >= 0 && k < nb) { sum[k] += st; cnt[k] += 1f }
        }
        for (k in 0 until nb) {
            var v = if (bodies[k].mode == 2) 0.3f else 0.02f
            if (cnt[k] > 0) v += min(sum[k] / cnt[k] / 300, 1f) * 0.2f
            ks[k] = min(v, 0.5f)
        }
        jRest = FloatArray(joints.size) { ji ->
            val j = joints[ji]
            if (!(j.a >= 0 && j.a < nb && j.b >= 0 && j.b < nb)) 0f else length(bodies[j.a].pos - bodies[j.b].pos)
        }
        childDriven = IntArray(n) { -1 }
        for ((i, b) in sk.bones.withIndex()) if (b.parent >= 0 && b.parent < n && b.parent != i && bodiesOf[i].isNotEmpty() && childDriven[b.parent] < 0) childDriven[b.parent] = i
        prepared = true
    }

    // MARK: solve
    /** Final world matrices (pose + physics) for time `t`. */
    fun solve(sk: Skeleton3D, t: Float, wall: Float): Array<M4> {
        var reset = false
        if (!prepared || springOf.size != sk.bones.size) { prepare(sk); reset = true }
        var dt = 0f
        var wake = disturb; disturb = false
        val lt = lastT
        if (lt != null) {
            val d = t - lt
            if (abs(d) <= 1e-5f) dt = 0f                              // paused: nothing moves on its own
            else if (d > 0 && d <= 0.25f) { dt = d; wake = true }
            else reset = true
        } else reset = true
        lastT = t
        invXf = worldXf.inverse()
        xfScale = max(length(V3(worldXf.col(0).x, worldXf.col(0).y, worldXf.col(0).z)), 1e-6f)
        val px = prevXf
        if (px != null && !reset && pInit) {
            val D = invXf * px                                       // old model space -> new model space (the world stays put = inertia)
            var dev = 0f
            val idm = M4.identity()
            for (c in 0 until 4) { val e = D.col(c) - idm.col(c); dev += abs(e.x) + abs(e.y) + abs(e.z) }
            if (dev > 1e-6f) {
                wake = true
                fun xp(p: V3): V3 = (D * V4(p.x, p.y, p.z, 1f)).xyz()
                for (i in cur.indices) { cur[i] = xp(cur[i]); prv[i] = xp(prv[i]) }
                for (k in pp.indices) { pp[k] = xp(pp[k]); pq[k] = xp(pq[k]) }
            }
        }
        prevXf = worldXf.copy()
        windLocal = (invXf * V4(windWorld.x, windWorld.y, windWorld.z, 0f)).xyz()
        if (length(windLocal) > 1e-6f) wake = true
        if (wake) awake = 1.5f
        if (dt == 0f && awake > 0) dt = min(max(wall, 0f), 0.05f)    // let it settle after a disturbance, then sleep
        awake = max(0f, awake - max(wall, 0f))
        if (reset) { acc = 0f; for (i in springInit.indices) springInit[i] = false; pInit = false }
        val pw = sk.poseWorld()
        if (!pInit) { initParticles(sk, pw); pInit = true }
        acc += dt
        var steps = 0
        while (acc >= SUB - 1e-5f && steps < 8) { pass(sk, pw, true); acc -= SUB; steps += 1 }
        if (steps >= 8) acc = 0f
        return pass(sk, pw, false)
    }

    private fun pass(sk: Skeleton3D, pw: Array<M4>, integrate: Boolean): Array<M4> {
        val n = sk.bones.size
        val fw = Array(n) { M4.identity() }
        if (integrate) stepParticles(sk, pw)
        for (i in sk.order()) {
            val b = sk.bones[i]
            val hasP = b.parent >= 0 && b.parent < n && b.parent != i
            val pm = if (hasP) fw[b.parent] else M4.identity()
            val M = pm * Skeleton3D.local(b)
            if (springOf[i] >= 0) { fw[i] = spring(springOf[i], M, pw, integrate); continue }
            if (bodiesOf[i].isNotEmpty()) {
                var dq = Quat.IDENTITY
                if (hasP) dq = rotQ(pm) * rotQ(pw[b.parent]).inverse()
                fw[i] = driven(i, M, dq, pw)
                continue
            }
            fw[i] = M
        }
        return fw
    }

    // MARK: VRM spring bones
    private fun spring(si: Int, M: M4, pw: Array<M4>, integrate: Boolean): M4 {
        val s = springs[si]
        val head = pos(M)
        val tailRest = (M * V4(s.tailLocal.x, s.tailLocal.y, s.tailLocal.z, 1f)).xyz()
        val len = max(length(tailRest - head), 1e-5f)
        if (!springInit[si]) { cur[si] = tailRest; prv[si] = tailRest; springInit[si] = true }
        if (integrate) {
            val h = SUB
            val dir = (tailRest - head) / len
            val inertia = (cur[si] - prv[si]) * (1 - min(max(s.drag, 0f), 1f))
            var next = cur[si] + inertia + dir * (s.stiffness * h) + s.gravityDir * (s.gravity * h) + windLocal * (h * h)
            next = head + norm(next - head, dir) * len
            for (gi in s.groups) {
                if (!(gi >= 0 && gi < groups.size)) continue
                for (ci in groups[gi]) {
                    if (!(ci >= 0 && ci < colliders.size)) continue
                    val c = colliders[ci]
                    if (!(c.bone >= 0 && c.bone < pw.size)) continue
                    val W = pw[c.bone]
                    val a = (W * V4(c.offset.x, c.offset.y, c.offset.z, 1f)).xyz()
                    var cp = a
                    val ct = c.tail
                    if (ct != null) cp = closest(next, a, (W * V4(ct.x, ct.y, ct.z, 1f)).xyz())
                    val d = next - cp; val dist = length(d)
                    if (c.inside) {
                        val r = max(c.radius - s.radius, 0f)
                        if (dist > r) next = cp + (if (dist > 1e-9f) d / dist else V3(0f, r, 0f)) * r
                    } else {
                        val r = c.radius + s.radius
                        if (dist < r) next = cp + (if (dist > 1e-9f) d / dist else V3(0f, 1f, 0f)) * r
                    }
                }
            }
            val gy = groundY
            if (gy != null) {                                       // floor collision (world space)
                val wp = worldXf * V4(next.x, next.y, next.z, 1f)
                val r = s.radius * xfScale
                if (wp.y < gy + r) { next = (invXf * V4(wp.x, gy + r, wp.z, wp.w)).xyz() }
            }
            next = head + norm(next - head, dir) * len
            prv[si] = cur[si]; cur[si] = next
        }
        val inv = M.inverse()
        val ln = (inv * V4(cur[si].x, cur[si].y, cur[si].z, 1f)).xyz()
        val a = norm(s.tailLocal); val b = norm(ln, a)
        val q = Quat.fromTo(a, b)
        return M * M4.fromQuat(q)
    }

    // MARK: PMX rigid bodies
    private fun target(k: Int, sk: Skeleton3D, pw: Array<M4>): V3 {
        val b = bodies[k]
        if (!(b.bone >= 0 && b.bone < pw.size)) return b.pos
        return pos(pw[b.bone]) + rotQ(pw[b.bone]).act(bodyOff[k])
    }

    private fun initParticles(sk: Skeleton3D, pw: Array<M4>) {
        for (k in bodies.indices) { tgt[k] = target(k, sk, pw); pp[k] = tgt[k]; pq[k] = tgt[k] }
    }

    private fun stepParticles(sk: Skeleton3D, pw: Array<M4>) {
        if (dyn.isEmpty()) return
        val h = SUB; val nb = bodies.size
        for (k in 0 until nb) {
            tgt[k] = target(k, sk, pw)
            val b = bodies[k]
            kAxis[k] = if (b.bone >= 0 && b.bone < pw.size) rotQ(pw[b.bone]).act(b.rot.act(axisLocal[k])) else b.rot.act(axisLocal[k])
        }
        val hh = h * h
        val g = V3(0f, -gravityUnits * hh, 0f) + windLocal * (hh * gravityUnits / 9.8f)
        for (k in dyn) {
            val b = bodies[k]
            val damp = Math.pow(max(1 - min(max(b.linDamp, 0f), 0.99f), 0.01f).toDouble(), h.toDouble()).toFloat()
            val v = (pp[k] - pq[k]) * damp
            var np = pp[k] + v + g
            np = np + (tgt[k] - np) * ks[k]
            pq[k] = pp[k]; pp[k] = np
        }
        fun isDyn(k: Int): Boolean = bodies[k].mode != 0 && bodies[k].bone >= 0 && bodies[k].bone < pw.size
        fun position(k: Int): V3 = if (isDyn(k)) pp[k] else tgt[k]
        for (iter in 0 until 6) {
            for ((ji, j) in joints.withIndex()) {
                if (!(j.a >= 0 && j.a < nb && j.b >= 0 && j.b < nb && ji < jRest.size && jRest[ji] > 1e-7f)) continue
                val da = isDyn(j.a); val db = isDyn(j.b)
                if (!da && !db) continue
                val d = position(j.b) - position(j.a); val dist = length(d)
                if (!(dist > 1e-7f)) continue
                val diff = (dist - jRest[ji]) / dist
                val wa = if (da) invM[j.a] else 0f; val wb = if (db) invM[j.b] else 0f
                val ws = wa + wb
                if (da) pp[j.a] = pp[j.a] + d * diff * (wa / ws)
                if (db) pp[j.b] = pp[j.b] - d * diff * (wb / ws)
            }
            for (k in dyn) {
                for (c in kin) {
                    if (bodies[k].mask and (1 shl min(max(bodies[c].group, 0), 15)) == 0) continue
                    if (bodies[c].mask and (1 shl min(max(bodies[k].group, 0), 15)) == 0) continue
                    val rr = prad[k] + krad[c]
                    var cp = tgt[c]
                    if (khalf[c] > 0) cp = closest(pp[k], tgt[c] - kAxis[c] * khalf[c], tgt[c] + kAxis[c] * khalf[c])
                    val d = pp[k] - cp; val dist = length(d)
                    if (dist < rr) pp[k] = cp + (if (dist > 1e-7f) d / dist else V3(0f, 1f, 0f)) * rr
                }
                val gy = groundY
                if (gy != null) {
                    val wp = worldXf * V4(pp[k].x, pp[k].y, pp[k].z, 1f)
                    val r = prad[k] * xfScale
                    if (wp.y < gy + r) pp[k] = (invXf * V4(wp.x, gy + r, wp.z, wp.w)).xyz()
                }
            }
        }
    }

    private fun drivenPos(i: Int, pw: Array<M4>): V3? {
        val kl = bodiesOf[i]
        if (kl.isEmpty()) return null
        val q = rotQ(pw[i])
        var s = V3.ZERO
        for (k in kl) s = s + (pp[k] - q.act(bodyOff[k]))
        return s / kl.size.toFloat()
    }

    /** World matrix of a bone driven by rigid bodies: position from the particles, orientation toward the driven child (or inheriting the parent's physics rotation). */
    private fun driven(i: Int, M: M4, dq: Quat, pw: Array<M4>): M4 {
        val P = drivenPos(i, pw) ?: return M
        val rp = rotQ(pw[i])
        var q = dq
        val c = childDriven[i]
        if (c >= 0) {
            val Pc = drivenPos(c, pw)
            if (Pc != null) {
                val dp = pos(pw[c]) - pos(pw[i]); val dn = Pc - P
                if (length(dp) > 1e-6f && length(dn) > 1e-6f) q = Quat.fromTo(normalize(dp), normalize(dn))
            }
        }
        val m = M4.fromQuat((q * rp).normalized())
        m.setCol(3, V4(P.x, P.y, P.z, 1f))
        return m
    }

    companion object {
        const val SUB: Float = 1.0f / 60.0f

        // MARK: helpers
        private fun pos(m: M4): V3 = V3(m.m[12], m.m[13], m.m[14])
        private fun norm(v: V3, d: V3 = V3(0f, 1f, 0f)): V3 { val l = length(v); return if (l > 1e-9f) v / l else d }
        /** Rotation of a matrix (scale removed). */
        fun rotQ(m: M4): Quat {
            val x = norm(m.col(0).xyz(), V3(1f, 0f, 0f))
            var y = m.col(1).xyz(); y = norm(y - x * dot(y, x), V3(0f, 1f, 0f))
            val z = cross(x, y)
            return Quat.fromColumns(x, y, z)
        }
        private fun closest(p: V3, a: V3, b: V3): V3 {
            val ab = b - a; val l2 = dot(ab, ab)
            if (l2 < 1e-12f) return a
            return a + ab * min(max(dot(p - a, ab) / l2, 0f), 1f)
        }
        private fun norm3(v: V3): V3 = norm(v, V3(0f, -1f, 0f))

        // MARK: VRM import
        /** Glb nodes that need a bone for the spring simulation (spring joints, their descendants for VRM 0.x, collider nodes). */
        fun springNodes(json: JSONObject, count: Int, children: (Int) -> List<Int>): Set<Int> {
            val out = HashSet<Int>()
            fun add(n: Int) { if (n >= 0 && n < count) out.add(n) }
            val ext = json.optJSONObject("extensions")
            val sb = ext?.optJSONObject("VRMC_springBone")
            if (sb != null) {
                sb.optJSONArray("colliders")?.let { cs -> for (i in 0 until cs.length()) add(cs.optJSONObject(i)?.optInt("node", -1) ?: -1) }
                sb.optJSONArray("springs")?.let { ss ->
                    for (i in 0 until ss.length()) {
                        val js = ss.optJSONObject(i)?.optJSONArray("joints") ?: continue
                        for (k in 0 until js.length()) add(js.optJSONObject(k)?.optInt("node", -1) ?: -1)
                    }
                }
            } else {
                val sa = ext?.optJSONObject("VRM")?.optJSONObject("secondaryAnimation")
                if (sa != null) {
                    sa.optJSONArray("colliderGroups")?.let { cg -> for (i in 0 until cg.length()) add(cg.optJSONObject(i)?.optInt("node", -1) ?: -1) }
                    sa.optJSONArray("boneGroups")?.let { bg ->
                        for (i in 0 until bg.length()) {
                            val bs = bg.optJSONObject(i)?.optJSONArray("bones") ?: continue
                            for (k in 0 until bs.length()) {
                                val stack = arrayListOf(bs.optI(k, -1)); var guardN = 0
                                while (true) {
                                    val n = stack.removeLastOrNull() ?: break
                                    if (guardN >= 5000) break
                                    guardN += 1
                                    if (n < 0 || n >= count || out.contains(n)) continue
                                    out.add(n); stack.addAll(children(n))
                                }
                            }
                        }
                    }
                }
            }
            return out
        }

        /** Spring bones of a VRM file. `boneOf` maps glb node -> bone index. */
        fun parseVrm(json: JSONObject, boneOf: Map<Int, Int>, sk: Skeleton3D): Physics3D? {
            val ph = Physics3D()
            val ext = json.optJSONObject("extensions")
            fun arr3(a: JSONArray?, d: V3): V3 {
                if (a == null || a.length() < 3) return d
                return V3(a.optF(0, 0f), a.optF(1, 0f), a.optF(2, 0f))
            }
            fun obj3(o: JSONObject?, d: V3, flipZ: Boolean): V3 {
                if (o == null) return d
                val z = o.optF("z", d.z)
                return V3(o.optF("x", d.x), o.optF("y", d.y), if (flipZ) -z else z)
            }
            fun tail(bone: Int, next: Int): V3 { val t = sk.bones[bone].bindWorld.inverse() * sk.bones[next].bindWorld.col(3); return V3(t.x, t.y, t.z) }
            fun children(b: Int): List<Int> = sk.bones.indices.filter { sk.bones[it].parent == b && it != b }
            fun virtualTail(b: Int): V3 {
                val rl = sk.bones[b].restLocal.col(3)
                val d = V3(rl.x, rl.y, rl.z)
                return if (length(d) > 1e-6f) normalize(d) * 0.07f else V3(0f, 0.07f, 0f)
            }

            val sb = ext?.optJSONObject("VRMC_springBone")
            if (sb != null) {
                val colMap = ArrayList<Int>()
                sb.optJSONArray("colliders")?.let { cs ->
                    for (i in 0 until cs.length()) {
                        val c = cs.optJSONObject(i)
                        val bi = if (c != null) boneOf[c.optInt("node", -1)] else null
                        val sh = c?.optJSONObject("shape")
                        if (c == null || bi == null || sh == null) { colMap.add(-1); continue }
                        val col = PhysCollider(bi, V3.ZERO, null, 0f, false)
                        val sp = sh.optJSONObject("sphere"); val cap = sh.optJSONObject("capsule")
                        if (sp != null) { col.offset = arr3(sp.optJSONArray("offset"), V3.ZERO); col.radius = sp.optF("radius", 0f) }
                        else if (cap != null) { col.offset = arr3(cap.optJSONArray("offset"), V3.ZERO); col.radius = cap.optF("radius", 0f); col.tail = arr3(cap.optJSONArray("tail"), V3.ZERO) }
                        else { colMap.add(-1); continue }
                        ph.colliders.add(col); colMap.add(ph.colliders.size - 1)
                    }
                }
                sb.optJSONArray("colliderGroups")?.let { gs ->
                    for (i in 0 until gs.length()) {
                        val list = ArrayList<Int>()
                        gs.optJSONObject(i)?.optJSONArray("colliders")?.let { ca ->
                            for (k in 0 until ca.length()) { val ci = ca.optI(k, -1); if (ci >= 0 && ci < colMap.size && colMap[ci] >= 0) list.add(colMap[ci]) }
                        }
                        ph.groups.add(list)
                    }
                }
                sb.optJSONArray("springs")?.let { ss ->
                    for (i in 0 until ss.length()) {
                        val sp = ss.optJSONObject(i) ?: continue
                        val js = sp.optJSONArray("joints") ?: continue
                        if (js.length() < 1) continue
                        val gl = ArrayList<Int>()
                        sp.optJSONArray("colliderGroups")?.let { ga -> for (k in 0 until ga.length()) gl.add(ga.optI(k, -1)) }
                        for (k in 0 until js.length()) {
                            val j = js.optJSONObject(k) ?: continue
                            val b = boneOf[j.optInt("node", -1)] ?: continue
                            sk.bones[b].physics = true
                            if (!(k + 1 < js.length())) continue
                            val nb = boneOf[js.optJSONObject(k + 1)?.optInt("node", -1) ?: -1] ?: continue
                            if (nb == b) continue
                            ph.springs.add(SpringJoint(b, tail(b, nb), j.optF("stiffness", 1f), j.optF("dragForce", 0.5f), j.optF("gravityPower", 0f),
                                norm3(arr3(j.optJSONArray("gravityDir"), V3(0f, -1f, 0f))), j.optF("hitRadius", 0f), gl))
                        }
                    }
                }
            } else {
                val sa = ext?.optJSONObject("VRM")?.optJSONObject("secondaryAnimation")
                if (sa != null) {
                    sa.optJSONArray("colliderGroups")?.let { cg ->
                        for (i in 0 until cg.length()) {
                            val list = ArrayList<Int>()
                            val g = cg.optJSONObject(i)
                            val bi = if (g != null) boneOf[g.optInt("node", -1)] else null
                            val ca = g?.optJSONArray("colliders")
                            if (g != null && bi != null && ca != null) {
                                for (k in 0 until ca.length()) {
                                    val c = ca.optJSONObject(k) ?: continue
                                    ph.colliders.add(PhysCollider(bi, obj3(c.optJSONObject("offset"), V3.ZERO, true), null, c.optF("radius", 0f), false))
                                    list.add(ph.colliders.size - 1)
                                }
                            }
                            ph.groups.add(list)
                        }
                    }
                    sa.optJSONArray("boneGroups")?.let { bg ->
                        for (i in 0 until bg.length()) {
                            val g = bg.optJSONObject(i) ?: continue
                            val roots = g.optJSONArray("bones") ?: continue
                            val stiff = if (g.has("stiffiness")) g.optF("stiffiness", 1f) else g.optF("stiffness", 1f)
                            val drag = g.optF("dragForce", 0.4f); val gp = g.optF("gravityPower", 0f); val hit = g.optF("hitRadius", 0.02f)
                            val gd = norm3(obj3(g.optJSONObject("gravityDir"), V3(0f, -1f, 0f), true))
                            val gl = ArrayList<Int>()
                            g.optJSONArray("colliderGroups")?.let { ga -> for (k in 0 until ga.length()) gl.add(ga.optI(k, -1)) }
                            val done = HashSet<Int>()
                            fun visit(b: Int, depth: Int) {
                                if (!(depth < 256 && !done.contains(b))) return
                                done.add(b)
                                sk.bones[b].physics = true
                                val ch = children(b)
                                val t = if (ch.isNotEmpty()) tail(b, ch.first()) else virtualTail(b)
                                ph.springs.add(SpringJoint(b, t, stiff, drag, gp, gd, hit, gl))
                                for (c in ch) visit(c, depth + 1)
                            }
                            for (k in 0 until roots.length()) { val b = boneOf[roots.optI(k, -1)]; if (b != null) visit(b, 0) }
                        }
                    }
                }
            }
            return if (ph.springs.isEmpty()) null else ph
        }
    }
}
