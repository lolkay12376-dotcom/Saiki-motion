package com.saiki.motion.core

import org.json.JSONObject

// Lossless raw-JSON holders for Layer members whose iOS classes belong to later slices.
// open -> save keeps every field byte-for-byte (iOS would normalise defaults on load; accepted until the real port).
// Flare: real port in Flare.kt.   (Puppet: real port in Puppet.kt)
// Rig/Warp: real port in Rig.kt. AudioFxItem: real port in AudioFx.kt.
