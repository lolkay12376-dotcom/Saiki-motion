package com.saiki.motion.core

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * PlyImport.swift — .ply / .spz point maps (+ optional collider mesh) -> .glb.
 * Line-for-line port. Idx arrays hold UInt32 bit patterns in Int (compare with Integer.compareUnsigned).
 */
object PlyImport {
    @JvmStatic var lastError = ""
    private var sawSplat = false
    const val balanced = 600_000
    const val low = 150_000
    const val fullCap = 3_000_000
    const val maxPoints = balanced
    const val colliderName = "SaikiCollider"

    class Cloud(var pos: FloatArray = FloatArray(0), var col: FloatArray = FloatArray(0))      // xyz*n, rgba*n
    class Mesh(var pos: FloatArray = FloatArray(0), var idx: IntArray = IntArray(0))
    class Loaded(val cloud: Cloud, val mesh: Mesh?, val splat: Boolean) { val count: Int get() = cloud.pos.size / 3 }

    private class FB { var a = FloatArray(1024); var n = 0
        fun add(v: Float) { if (n == a.size) a = a.copyOf(n * 2); a[n++] = v }
        fun arr(): FloatArray = a.copyOf(n) }
    private class IB { var a = IntArray(1024); var n = 0
        fun add(v: Int) { if (n == a.size) a = a.copyOf(n * 2); a[n++] = v }
        fun arr(): IntArray = a.copyOf(n) }
    private class CB { val pos = FB(); val col = FB(); fun cloud() = Cloud(pos.arr(), col.arr()) }

    /** Layer path -> is a converted point map? */
    fun isPointMap(path: String?): Boolean = (path ?: "").contains("_ply") && (path ?: "").endsWith(".glb")

    // MARK: entry points

    /** Step 1: parse the file (no thinning yet) so the UI can ask about quality when it is big. */
    fun load(path: String): Loaded? {
        lastError = ""
        val data = try { File(path).readBytes() } catch (_: Exception) { null }
        if (data == null || data.size <= 16) { lastError = "Could not read the file"; return null }
        val ext = path.substringAfterLast('.', "").lowercase(java.util.Locale.ROOT)
        sawSplat = false
        val cloud: Cloud; var mesh: Mesh? = null
        if (ext == "spz" || (data[0] == 0x1f.toByte() && data[1] == 0x8b.toByte())) {
            cloud = parseSpz(data) ?: return null
            sawSplat = true
        } else {
            val r = parsePly(data) ?: return null
            cloud = r.first; mesh = r.second
        }
        if (cloud.pos.size < 3) { lastError = if (lastError.isEmpty()) "No points found in this file" else lastError; return null }
        return Loaded(cloud, mesh, sawSplat)
    }

    /** Step 2: thin to `limit` points and write the .glb (a mesh inside the PLY becomes the collider). */
    fun finish(ld: Loaded, path: String, limit: Int): String? {
        val cloud = Cloud(ld.cloud.pos, ld.cloud.col)
        shuffleAndCap(cloud, limit)
        val stem = deletingPathExtension(path)
        try { savePoints(cloud, stem + "_pts.bin") } catch (_: Exception) {}
        if (ld.splat) { try { File(stem + "_flip.flag").writeBytes(ByteArray(0)) } catch (_: Exception) {} }
        else { try { File(stem + "_flip.flag").delete() } catch (_: Exception) {} }
        return writeGlb(cloud, ld.mesh, stem)
    }

    fun convert(path: String, limit: Int = balanced): String? {
        val ld = load(path) ?: return null
        return finish(ld, path, limit)
    }

    /** Properties tab: attach a collider mesh (.ply with faces, or .obj) to an imported point map. Returns the NEW .glb path. */
    fun attachCollider(colliderFile: String, toPointMap: String): String? {
        val glb = toPointMap
        lastError = ""
        val data = try { File(colliderFile).readBytes() } catch (_: Exception) { null }
        if (data == null) { lastError = "Could not read the collider file"; return null }
        val ext = colliderFile.substringAfterLast('.', "").lowercase(java.util.Locale.ROOT)
        var mesh: Mesh? = null
        if (ext == "obj") mesh = parseObj(data)
        else { val r = parsePly(data, meshOnly = true); if (r != null) mesh = r.second }
        val fm = mesh
        if (fm != null && File(baseStem(glb) + "_flip.flag").exists()) {      // same Y-down frame as the splat
            for (i in 0 until fm.pos.size / 3) { fm.pos[i * 3 + 1] = -fm.pos[i * 3 + 1]; fm.pos[i * 3 + 2] = -fm.pos[i * 3 + 2] }
            mesh = fm
        }
        val m = mesh
        if (m == null || m.idx.isEmpty()) { lastError = if (lastError.isEmpty()) "No faces found: the collider needs a triangle mesh" else lastError; return null }
        val stem = baseStem(glb)
        val cloud = loadPoints(stem + "_pts.bin")
        if (cloud == null) { lastError = "Point data missing, re-import the point map"; return null }
        return writeGlb(cloud, m, stem)
    }

    /** Removes the collider (rebuilds the GLB with points only). */
    fun removeCollider(fromPointMap: String): String? {
        val stem = baseStem(fromPointMap)
        val cloud = loadPoints(stem + "_pts.bin") ?: return null
        return writeGlb(cloud, null, stem)
    }

    fun hasCollider(glb: String): Boolean = File(baseStem(glb) + "_col.flag").exists() && glbHasCollider(glb)
    private fun glbHasCollider(glb: String): Boolean {
        return try {
            File(glb).inputStream().use { s ->
                val buf = ByteArray(4096); val n = s.read(buf).coerceAtLeast(0)
                val key = colliderName.toByteArray(Charsets.UTF_8)
                var found = false
                var i = 0
                while (i + key.size <= n) {
                    var k = 0
                    while (k < key.size && buf[i + k] == key[k]) k++
                    if (k == key.size) { found = true; break }
                    i++
                }
                found
            }
        } catch (_: Exception) { false }
    }
    fun pointCount(glb: String): Int {
        val f = File(baseStem(glb) + "_pts.bin")
        if (!f.exists()) return 0
        return max(0, (f.length().toInt() - 4) / 28)
    }

    // MARK: stem / sidecar helpers

    /** NSString.deletingPathExtension */
    private fun deletingPathExtension(p: String): String {
        val slash = p.lastIndexOf('/')
        val name = p.substring(slash + 1)
        val dot = name.lastIndexOf('.')
        return if (dot > 0) p.substring(0, slash + 1 + dot) else p
    }
    private fun baseStem(glb: String): String {
        var s = deletingPathExtension(glb)
        val r = s.lastIndexOf("_ply")
        if (r >= 0) s = s.substring(0, r)
        return s
    }
    private fun savePoints(c: Cloud, path: String) {
        val n = c.pos.size / 3
        val bb = ByteBuffer.allocate(4 + n * 28).order(ByteOrder.LITTLE_ENDIAN)
        bb.putInt(n)
        for (i in 0 until n) {
            bb.putFloat(c.pos[i * 3]); bb.putFloat(c.pos[i * 3 + 1]); bb.putFloat(c.pos[i * 3 + 2])
            bb.putFloat(c.col[i * 4]); bb.putFloat(c.col[i * 4 + 1]); bb.putFloat(c.col[i * 4 + 2]); bb.putFloat(c.col[i * 4 + 3])
        }
        File(path).writeBytes(bb.array())
    }
    private fun loadPoints(path: String): Cloud? {
        val d = try { File(path).readBytes() } catch (_: Exception) { null }
        if (d == null || d.size < 4) return null
        val bb = ByteBuffer.wrap(d).order(ByteOrder.LITTLE_ENDIAN)
        val n = bb.getInt(0).toLong() and 0xFFFFFFFFL
        if (d.size.toLong() < 4 + n * 28) return null
        val ni = n.toInt()
        val c = Cloud(FloatArray(ni * 3), FloatArray(ni * 4))
        for (i in 0 until ni) {
            val o = 4 + i * 28
            for (k in 0 until 3) c.pos[i * 3 + k] = bb.getFloat(o + k * 4)
            for (k in 3 until 7) c.col[i * 4 + k - 3] = bb.getFloat(o + k * 4)
        }
        return c
    }

    private fun shuffleAndCap(c: Cloud, limit: Int) {
        val n = c.pos.size / 3
        val order = IntArray(n) { it }
        val rng = SplitMix(0x5A1C1uL)
        var i = n - 1
        while (i > 0) {
            val j = (rng.next() % (i + 1).toULong()).toInt()
            val t = order[i]; order[i] = order[j]; order[j] = t
            i--
        }
        val m = min(n, max(1000, limit))
        val p = FloatArray(m * 3); val q = FloatArray(m * 4)
        for (k in 0 until m) {
            val ii = order[k]
            p[k * 3] = c.pos[ii * 3]; p[k * 3 + 1] = c.pos[ii * 3 + 1]; p[k * 3 + 2] = c.pos[ii * 3 + 2]
            q[k * 4] = c.col[ii * 4]; q[k * 4 + 1] = c.col[ii * 4 + 1]; q[k * 4 + 2] = c.col[ii * 4 + 2]; q[k * 4 + 3] = c.col[ii * 4 + 3]
        }
        c.pos = p; c.col = q
    }
    private class SplitMix(var s: ULong) {
        fun next(): ULong {
            s += 0x9E3779B97F4A7C15uL
            var z = s
            z = (z xor (z shr 30)) * 0xBF58476D1CE4E5B9uL
            z = (z xor (z shr 27)) * 0x94D049BB133111EBuL
            return z xor (z shr 31)
        }
    }

    // MARK: PLY

    private enum class T(val size: Int) { I8(1), U8(1), I16(2), U16(2), I32(4), U32(4), F32(4), F64(8);
        companion object {
            fun from(s: String): T? = when (s) {
                "char", "int8" -> I8; "uchar", "uint8" -> U8; "short", "int16" -> I16
                "ushort", "uint16" -> U16; "int", "int32" -> I32; "uint", "uint32" -> U32
                "float", "float32" -> F32; "double", "float64" -> F64; else -> null }
        }
    }
    private class Prop(val name: String, val t: T, val listCount: T? = null)
    private class Elem(val name: String, val count: Int) { val props = ArrayList<Prop>() }

    private fun words(s: String): List<String> = s.split(' ').filter { it.isNotEmpty() }

    private fun parsePly(b: ByteArray, meshOnly: Boolean = false): Pair<Cloud, Mesh?>? {
        // header
        val hEnd = findHeaderEnd(b)
        if (hEnd == null) { lastError = "Not a valid PLY file"; return null }
        val header = String(b, 0, hEnd.first, Charsets.UTF_8)
        var fmt = "ascii"; val elems = ArrayList<Elem>()
        for (raw in header.split('\n', '\r')) {
            if (raw.isEmpty()) continue
            val w = words(raw)
            val k = w.firstOrNull() ?: continue
            if (k == "format" && w.size > 1) fmt = w[1]
            else if (k == "element" && w.size > 2) elems.add(Elem(w[1], w[2].toIntOrNull() ?: 0))
            else if (k == "property" && elems.isNotEmpty()) {
                val ct = if (w.size >= 5 && w[1] == "list") T.from(w[2]) else null
                val it2 = if (w.size >= 5 && w[1] == "list") T.from(w[3]) else null
                if (w.size >= 5 && w[1] == "list" && ct != null && it2 != null) elems[elems.size - 1].props.add(Prop(w[4], it2, ct))
                else if (w.size >= 3) { val t = T.from(w[1]); if (t != null) elems[elems.size - 1].props.add(Prop(w[2], t)) }
            }
        }
        if (elems.none { it.name == "vertex" }) { lastError = "PLY has no vertices"; return null }
        val big = fmt == "binary_big_endian"
        val cloud = CB(); val mesh = IB()
        var pos = hEnd.second

        if (fmt == "ascii") {
            val body = String(b, pos, b.size - pos, Charsets.UTF_8)
            val lines = body.splitToSequence('\n', '\r').filter { it.isNotEmpty() }.iterator()
            for (e in elems) {
                for (n in 0 until e.count) {
                    if (!lines.hasNext()) break
                    val ln = lines.next()
                    val tok = words(ln)
                    if (e.name == "vertex") readVertexASCII(e, tok, cloud)
                    else if (e.name == "face") {
                        val f = e.props.indexOfFirst { it.listCount != null }
                        if (f >= 0) {
                            var t = 0
                            for ((pi, p) in e.props.withIndex()) {
                                if (p.listCount != null) {
                                    val c = (tok.getOrNull(t) ?: "0").toIntOrNull() ?: 0; t += 1
                                    if (pi == f) {
                                        val v = ArrayList<Int>()
                                        for (k in 0 until c) v.add(parseU32(tok.getOrNull(t + k) ?: "0"))
                                        fan(v, mesh)
                                    }
                                    t += c
                                } else t += 1
                            }
                        }
                    }
                }
            }
        } else {
            val bb = ByteBuffer.wrap(b).order(if (big) ByteOrder.BIG_ENDIAN else ByteOrder.LITTLE_ENDIAN)
            for (e in elems) {
                val fixed = e.props.none { it.listCount != null }
                val stride = e.props.fold(0) { a, p -> a + p.t.size }
                if (e.name == "vertex") {
                    if (!fixed) { lastError = "Unsupported vertex layout"; return null }
                    if (pos.toLong() + stride.toLong() * e.count > b.size) { lastError = "PLY file is truncated"; return null }
                    readVertexBinary(e, bb, pos, stride, cloud)
                    pos += stride * e.count
                } else if (e.name == "face") {
                    for (n in 0 until e.count) {
                        for (p in e.props) {
                            val ct = p.listCount
                            if (ct != null) {
                                if (pos + ct.size > b.size) break
                                val c = rd(bb, pos, ct).toInt(); pos += ct.size
                                val v = ArrayList<Int>()
                                for (k in 0 until c) { if (pos + p.t.size > b.size) break; v.add(max(0f, rd(bb, pos, p.t)).toDouble().toLong().toInt()); pos += p.t.size }
                                if (p.name == "vertex_indices" || p.name == "vertex_index") fan(v, mesh)
                            } else pos += p.t.size
                        }
                    }
                } else if (fixed) pos += stride * e.count
                else break      // unknown list element: stop, vertices/faces are already read
            }
        }
        val cl = cloud.cloud()
        if (!meshOnly && cl.pos.isEmpty()) { lastError = "PLY has no vertices"; return null }
        // mesh vertices = the vertex element positions
        var m = Mesh(FloatArray(0), mesh.arr())
        if (m.idx.isNotEmpty()) {
            m.pos = cl.pos
            val n = cl.pos.size / 3
            if (m.idx.any { Integer.compareUnsigned(it, n) >= 0 }) m = Mesh()
        }
        return Pair(cl, if (m.idx.isEmpty()) null else m)
    }

    /** Swift UInt32(String) ?? 0 */
    private fun parseU32(s: String): Int {
        val v = s.toLongOrNull() ?: return 0
        return if (v in 0..0xFFFFFFFFL) v.toInt() else 0
    }

    private fun fan(v: List<Int>, m: IB) {
        if (v.size < 3) return
        for (i in 1 until v.size - 1) { m.add(v[0]); m.add(v[i]); m.add(v[i + 1]) }
    }
    /** returns (text end, data start) */
    private fun findHeaderEnd(b: ByteArray): Pair<Int, Int>? {
        val key = "end_header".toByteArray(Charsets.UTF_8)
        if (b.size <= 12) return null
        var i = 0
        while (i + key.size < min(b.size, 65536)) {
            if (b[i] == key[0]) {
                var k = 0
                while (k < key.size && b[i + k] == key[k]) k++
                if (k == key.size) {
                    var j = i + key.size
                    if (j < b.size && b[j].toInt() == 13) j += 1
                    if (j < b.size && b[j].toInt() == 10) j += 1
                    return Pair(i, j)
                }
            }
            i += 1
        }
        return null
    }
    private fun rd(b: ByteBuffer, o: Int, t: T): Float = when (t) {
        T.I8 -> b.get(o).toFloat()
        T.U8 -> (b.get(o).toInt() and 0xFF).toFloat()
        T.I16 -> b.getShort(o).toFloat()
        T.U16 -> (b.getShort(o).toInt() and 0xFFFF).toFloat()
        T.I32 -> b.getInt(o).toFloat()
        T.U32 -> (b.getInt(o).toLong() and 0xFFFFFFFFL).toFloat()
        T.F32 -> b.getFloat(o)
        T.F64 -> b.getDouble(o).toFloat()
    }

    private class VMap { var x = -1; var y = -1; var z = -1; var r = -1; var g = -1; var b = -1; var a = -1
        var dc0 = -1; var dc1 = -1; var dc2 = -1; var op = -1; var intColor = false }
    private fun map(e: Elem): VMap {
        val m = VMap()
        for ((i, p) in e.props.withIndex()) {
            when (p.name) {
                "x" -> m.x = i; "y" -> m.y = i; "z" -> m.z = i
                "red", "r", "diffuse_red" -> { m.r = i; m.intColor = p.t != T.F32 && p.t != T.F64 }
                "green", "g", "diffuse_green" -> m.g = i
                "blue", "b", "diffuse_blue" -> m.b = i
                "alpha" -> m.a = i
                "f_dc_0" -> m.dc0 = i; "f_dc_1" -> m.dc1 = i; "f_dc_2" -> m.dc2 = i
                "opacity" -> m.op = i
            }
        }
        return m
    }
    /** Appends one point. `v` gives property i's value. */
    private inline fun addPoint(m: VMap, v: (Int) -> Float, c: CB) {
        if (!(m.x >= 0 && m.y >= 0 && m.z >= 0)) return
        val x = v(m.x); var y = v(m.y); var z = v(m.z)
        var r = 0.85f; var g = 0.87f; var bl = 0.92f; var al = 1f
        val splat = m.dc0 >= 0 && m.dc1 >= 0 && m.dc2 >= 0
        if (splat) {
            val k = 0.28209479f
            r = min(1f, max(0f, 0.5f + k * v(m.dc0))); g = min(1f, max(0f, 0.5f + k * v(m.dc1))); bl = min(1f, max(0f, 0.5f + k * v(m.dc2)))
            if (m.op >= 0) { al = 1f / (1f + exp(-v(m.op))); if (al < 0.06f) return }      // drop near-transparent splats
            y = -y; z = -z; sawSplat = true                                                // 3DGS is Y-down
        } else if (m.r >= 0 && m.g >= 0 && m.b >= 0) {
            val s = if (m.intColor) 1f / 255f else 1f
            r = v(m.r) * s; g = v(m.g) * s; bl = v(m.b) * s
        }
        if (!(x.isFinite() && y.isFinite() && z.isFinite())) return
        c.pos.add(x); c.pos.add(y); c.pos.add(z)
        c.col.add(r); c.col.add(g); c.col.add(bl); c.col.add(al)
    }
    private fun readVertexBinary(e: Elem, b: ByteBuffer, start: Int, stride: Int, c: CB) {
        val m = map(e)
        val offs = IntArray(e.props.size); var o = 0
        for ((i, p) in e.props.withIndex()) { offs[i] = o; o += p.t.size }
        for (i in 0 until e.count) {
            val base = start + i * stride
            addPoint(m, { rd(b, base + offs[it], e.props[it].t) }, c)
        }
    }
    private fun readVertexASCII(e: Elem, tok: List<String>, c: CB) {
        val m = map(e)
        addPoint(m, { (tok.getOrNull(it) ?: "0").toFloatOrNull() ?: 0f }, c)
    }

    // MARK: OBJ (collider only)

    private fun parseObj(data: ByteArray): Mesh? {
        val s = String(data, Charsets.UTF_8)
        val pos = FB(); val idx = IB()
        for (ln in s.split('\n', '\r')) {
            if (ln.isEmpty()) continue
            val w = words(ln)
            if (w.firstOrNull() == "v" && w.size >= 4) { for (k in 1..3) pos.add(w[k].toFloatOrNull() ?: 0f) }
            else if (w.firstOrNull() == "f" && w.size >= 4) {
                val n = pos.n / 3
                val v = ArrayList<Int>()
                for (t in w.drop(1)) {
                    var i = t.split('/').firstOrNull()?.toIntOrNull() ?: continue
                    if (i < 0) i = n + i + 1
                    if (i >= 1 && i <= n) v.add(i - 1)
                }
                fan(v, idx)
            }
        }
        return if (idx.n == 0) null else Mesh(pos.arr(), idx.arr())
    }

    // MARK: SPZ (gzip'd, Niantic format v1-v3)


    private fun parseSpz(gz: ByteArray): Cloud? {
        var raw = gz
        fun u8(i: Int) = gz[i].toInt() and 0xFF
        if (gz.size > 18 && u8(0) == 0x1f && u8(1) == 0x8b) {
            var off = 10
            val flg = u8(3)
            if (flg and 4 != 0 && off + 2 <= gz.size) off += 2 + u8(off) + (u8(off + 1) shl 8)
            if (flg and 8 != 0) { while (off < gz.size && u8(off) != 0) off++; off++ }
            if (flg and 16 != 0) { while (off < gz.size && u8(off) != 0) off++; off++ }
            if (flg and 2 != 0) off += 2
            if (!(off < gz.size - 8)) { lastError = "Invalid .spz file"; return null }
            raw = VdbVolume.inflate(gz.copyOfRange(off, gz.size - 8))
        }
        if (raw.size <= 16) { lastError = "Could not decompress this .spz file"; return null }
        fun r8(i: Int) = raw[i].toInt() and 0xFF
        fun u32(o: Int): Long = (r8(o).toLong()) or (r8(o + 1).toLong() shl 8) or (r8(o + 2).toLong() shl 16) or (r8(o + 3).toLong() shl 24)
        if (u32(0) != 0x5053474eL) { lastError = "Not an .spz file (bad header)"; return null }
        val ver = u32(4).toInt(); val n = u32(8).toInt(); val frac = r8(13)
        if (!(n > 0 && n < 40_000_000 && ver in 1..3)) { lastError = "Unsupported .spz version"; return null }
        val posBytes = if (ver == 1) 6 else 9
        if (raw.size.toLong() < 16L + n.toLong() * (posBytes + 4)) { lastError = "The .spz file is truncated"; return null }
        val pO = 16; val aO = pO + n * posBytes; val cO = aO + n
        val c = CB()
        val sc = (1 shl frac).toFloat()
        fun half(lo: Int, hi: Int): Float {
            val h = lo or (hi shl 8)
            val s = if (h and 0x8000 != 0) -1f else 1f
            val e = (h shr 10) and 31; val f = (h and 1023).toFloat()
            if (e == 0) return s * f * 5.9604645e-8f
            if (e == 31) return 0f
            return s * (1 + f / 1024) * 2.0.pow((e - 15).toDouble()).toFloat()
        }
        val p = FloatArray(3)
        for (i in 0 until n) {
            for (k in 0 until 3) {
                if (ver == 1) { val o = pO + i * 6 + k * 2; p[k] = half(r8(o), r8(o + 1)) }
                else {
                    val o = pO + i * 9 + k * 3
                    var v = r8(o) or (r8(o + 1) shl 8) or (r8(o + 2) shl 16)
                    if (v and 0x800000 != 0) v = v or 0xFFFFFF.inv()
                    p[k] = v.toFloat() / sc
                }
            }
            val al = r8(aO + i).toFloat() / 255f
            if (al < 0.06f) continue
            val kk = 0.28209479f
            fun cc(k: Int): Float = min(1f, max(0f, 0.5f + kk * ((r8(cO + i * 3 + k).toFloat() / 255f - 0.5f) / 0.15f)))
            c.pos.add(p[0]); c.pos.add(-p[1]); c.pos.add(-p[2])
            c.col.add(cc(0)); c.col.add(cc(1)); c.col.add(cc(2)); c.col.add(al)
        }
        return c.cloud()
    }

    // MARK: GLB writer

    private fun writeGlb(cloud: Cloud, mesh: Mesh?, stem: String): String? {
        val n = cloud.pos.size / 3
        if (n <= 0) return null
        val bin = java.io.ByteArrayOutputStream()
        fun pad() { while (bin.size() % 4 != 0) bin.write(0) }
        fun addBytes(bytes: ByteArray): IntArray { pad(); val o = bin.size(); bin.write(bytes); return intArrayOf(o, bytes.size) }
        fun addF(a: FloatArray): IntArray { val bb = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (v in a) bb.putFloat(v); return addBytes(bb.array()) }
        fun addI(a: IntArray): IntArray { val bb = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (v in a) bb.putInt(v); return addBytes(bb.array()) }
        fun bounds(p: FloatArray): Pair<FloatArray, FloatArray> {
            val lo = FloatArray(3) { Float.MAX_VALUE }; val hi = FloatArray(3) { -Float.MAX_VALUE }
            for (i in 0 until p.size / 3) for (k in 0 until 3) { lo[k] = min(lo[k], p[i * 3 + k]); hi[k] = max(hi[k], p[i * 3 + k]) }
            return Pair(lo, hi)
        }
        val views = ArrayList<String>(); val accs = ArrayList<String>()
        fun view(r: IntArray, target: Int): Int {
            views.add("{\"buffer\":0,\"byteOffset\":${r[0]},\"byteLength\":${r[1]},\"target\":$target}"); return views.size - 1
        }
        fun acc(v: Int, ct: Int, count: Int, type: String, extra: String = ""): Int {
            accs.add("{\"bufferView\":$v,\"componentType\":$ct,\"count\":$count,\"type\":\"$type\"$extra}"); return accs.size - 1
        }
        fun arr(a: FloatArray): String = "[" + a.joinToString(",") { it.toString() } + "]"

        val (lo, hi) = bounds(cloud.pos)
        val aP = acc(view(addF(cloud.pos), 34962), 5126, n, "VEC3", ",\"min\":${arr(lo)},\"max\":${arr(hi)}")
        val aC = acc(view(addF(cloud.col), 34962), 5126, n, "VEC4")
        val meshes = arrayListOf("{\"name\":\"SaikiPoints\",\"primitives\":[{\"attributes\":{\"POSITION\":$aP,\"COLOR_0\":$aC},\"mode\":0}]}")
        val nodes = arrayListOf("{\"mesh\":0}"); var sceneNodes = "0"
        var materials = ""
        if (mesh != null && mesh.idx.isNotEmpty()) {
            val mp = mesh.pos
            val (l2, h2) = bounds(mp)
            val vP = acc(view(addF(mp), 34962), 5126, mp.size / 3, "VEC3", ",\"min\":${arr(l2)},\"max\":${arr(h2)}")
            val vI = acc(view(addI(mesh.idx), 34963), 5125, mesh.idx.size, "SCALAR")
            meshes.add("{\"name\":\"$colliderName\",\"primitives\":[{\"attributes\":{\"POSITION\":$vP},\"indices\":$vI,\"material\":0,\"mode\":4}]}")
            nodes.add("{\"mesh\":1}"); sceneNodes = "0,1"
            materials = ",\"materials\":[{\"name\":\"collider\",\"alphaMode\":\"BLEND\",\"pbrMetallicRoughness\":{\"baseColorFactor\":[0.35,0.75,1,0.28],\"metallicFactor\":0,\"roughnessFactor\":1}}]"
            try { File(stem + "_col.flag").writeBytes(ByteArray(0)) } catch (_: Exception) {}
        } else {
            try { File(stem + "_col.flag").delete() } catch (_: Exception) {}
        }
        pad()
        val json = "{\"asset\":{\"version\":\"2.0\",\"generator\":\"SaikiMotion PlyImport\"},\"scene\":0,\"scenes\":[{\"nodes\":[$sceneNodes]}],\"nodes\":[${nodes.joinToString(",")}],\"meshes\":[${meshes.joinToString(",")}]$materials,\"buffers\":[{\"byteLength\":${bin.size()}}],\"bufferViews\":[${views.joinToString(",")}],\"accessors\":[${accs.joinToString(",")}]}"
        var jd = json.toByteArray(Charsets.UTF_8)
        if (jd.size % 4 != 0) { val pd = ByteArray(4 - jd.size % 4) { 0x20 }; jd += pd }
        val binB = bin.toByteArray()
        val out = ByteBuffer.allocate(12 + 8 + jd.size + 8 + binB.size).order(ByteOrder.LITTLE_ENDIAN)
        out.putInt(0x46546C67); out.putInt(2); out.putInt(12 + 8 + jd.size + 8 + binB.size)
        out.putInt(jd.size); out.putInt(0x4E4F534A); out.put(jd)
        out.putInt(binB.size); out.putInt(0x004E4942); out.put(binB)
        val dest = stem + "_ply" + (System.currentTimeMillis() % 100_000_000L) + ".glb"
        try { File(dest).writeBytes(out.array()) } catch (_: Exception) { lastError = "Could not write the converted model"; return null }
        return dest
    }
}
