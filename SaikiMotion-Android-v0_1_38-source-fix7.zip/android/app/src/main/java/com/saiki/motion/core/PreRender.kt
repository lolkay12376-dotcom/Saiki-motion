package com.saiki.motion.core

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipFile
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// Port of Sources/Render/PreRender.swift — per-group frame cache ("Pre-render", like After Effects' precomp cache).
// Frames: <root>/SaikiMotion/Pre-rendered/<project>/<group>/<sig>_<w>x<h>_<idx>.pre, LZ4-compressed RGBA.
// iOS NSData lz4 has no Android equivalent: .pre files use zlib deflate via java.util.zip with a 1-byte
// marker (0x01 = zlib) so files stay portable; legacy raw frames are rejected (raw.count check).
object PreRender {
    /** Global switch (default on). Off → every group renders live and nothing is baked. */
    var enabled: Boolean
        get() = Prefs.getBool("preRender", true)
        set(v) { Prefs.setBool("preRender", v); FrameCache.bump() }

    /** Lives in Documents/SaikiMotion/Pre-rendered (not Caches): the OS empties caches when closed. */
    val root: File get() = File(Paths.root, "Pre-rendered")

    private val lock = Object()
    private val sigMemo = HashMap<String, Pair<Int, String>>()   // "pid/gid" → (FrameCache.version, sig)
    private val baseIdx = HashMap<String, Int>()                 // "pid/gid" → absolute frame index of the group's first frame
    private val haveMemo = HashMap<String, HashSet<Int>>()       // dir+sig+size → baked frame indices
    private val purgedSig = HashMap<String, String>()

    // MARK: groups + signature

    /** Every layer under `g` (children, grand-children…). */
    fun descendants(g: Layer, scene: Scene): List<Layer> {
        val out = ArrayList<Layer>()
        val queue = ArrayList<Int>(); queue.add(g.id)
        val seen = HashSet<Int>(); seen.add(g.id)
        while (queue.isNotEmpty()) {
            val id = queue.removeAt(queue.size - 1)
            for (l in scene.layers) if (l.parentId == id && !seen.contains(l.id)) { seen.add(l.id); out.add(l); queue.add(l.id) }
        }
        return out
    }

    /** Pre-rendered groups of a scene (visible, flagged). */
    fun groups(scene: Scene): List<Layer> {
        if (!enabled) return emptyList()
        return scene.layers.filter { it.type == LayerType.GROUP && it.prerender }
    }

    /** Where the group's picture really starts / ends on the timeline (children's span is the anchor). */
    fun span(g: Layer, scene: Scene): Pair<Float, Float> {
        val d = descendants(g, scene)
        if (d.isEmpty()) return Pair(g.start, g.end)
        return Pair(d.minOf { it.start }, d.maxOf { it.end })
    }

    fun signature(g: Layer, project: Project, scene: Scene): String {
        val key = project.id + "/" + g.id
        val (anchor, spanEnd) = span(g, scene)
        synchronized(lock) {
            baseIdx[key] = frameIndex(anchor, project.fps)    // refreshed even on a memo hit: moving a group must not re-bake
            val m = sigMemo[key]
            if (m != null && m.first == FrameCache.version) return m.second
        }

        var parts = "v4|${project.w}x${project.h}@${project.fps}|${scene.fov}|"   // v3: mask-group bake fix — older bakes are discarded
        val used = ArrayList<Layer>()
        used.add(g); used.addAll(descendants(g, scene))
        val inside = HashSet<Layer>(used)
        var hasExternal = false
        // (cameras are not part of the bake: the group is a flat plane the camera looks at)
        for (l in used.toList()) {                             // effect inputs pull in other layers
            for (rid in l.inputs.values) {
                val r = scene.layers.firstOrNull { it.id == rid } ?: continue
                if (!used.contains(r)) { used.add(r); hasExternal = true }
            }
        }
        for (l in used) {
            var js: String
            if (l === g) {
                // The bake holds only what is INSIDE the group (children + mask + motion-blur settings).
                js = "G|mask=${l.mask}|mb=${l.mblur}|stut=${l.mbStutter}|rgb=${l.mbRgb}|pre=${l.precomp}|"
                js += "t=${((spanEnd - anchor) * 1000).roundToInt()}|"
                for (k in listOf("mbAmount", "mbSamples")) {
                    val tr = l.props[k]
                    if (tr != null) js += "$k=${tr.toJson().toString()}|"
                }
                l.rig?.let { js += it.toJson().toString() }
            } else {
                // times are stored relative to the group's start, so sliding the group along the
                // timeline (start/end/keyframes all shift together) keeps the same fingerprint
                val jo = l.toJson(canonical = true)
                jo.remove("name")                               // renaming a layer must not re-bake
                // layers outside the group stay where they are: their times are absolute
                if (inside.contains(l)) shiftTimes(jo, anchor)
                js = jo.toString()
            }
            // sandbox paths change between launches / reinstalls: only the file name matters
            val ip = l.imagePath
            if (!ip.isNullOrEmpty()) js = js.replace(ip, ip.substringAfterLast('/'))
            js = js.replace(Paths.root.path, "")
            js = Regex("/[0-9A-Fa-f-]{36}/").replace(js, "/")
            parts += js + "\n"
        }
        if (hasExternal) parts += "gs=$anchor|"     // only then does the group's position change its picture
        parts += scene.markerNames.entries.sortedBy { it.key }.joinToString(",") { "${it.key}=${it.value}" }

        var h = -0x40e2d2071e8f9b5bL                // 0xcbf29ce484222325 as signed ULong
        for (b in parts.encodeToByteArray()) { h = ((h xor b.toLong().toULong().toLong()) * 0x100000001b3L) }
        val sig = java.lang.Long.toUnsignedString(h, 16)
        synchronized(lock) {
            baseIdx[key] = frameIndex(anchor, project.fps)
            sigMemo[key] = Pair(FrameCache.version, sig)
        }
        return sig
    }

    private fun shiftTimes(o: JSONObject, dt: Float) {
        fun q(v: Double): Double = (v * 1000).let { kotlin.math.round(it) } / 1000
        for (k in listOf("start", "end")) o.opt(k)?.let { if (it is Number) o.put(k, q(it.toDouble() - dt)) }
        // keyframes live in props AND in puppet / rig / text animators: walk everything for `keys: [{t: …}]`
        fun walk(v: Any?) {
            when (v) {
                is JSONObject -> {
                    (v.opt("keys") as? JSONArray)?.let { ks ->
                        for (i in 0 until ks.length()) {
                            val ko = ks.opt(i) as? JSONObject ?: continue
                            val t = ko.opt("t")
                            if (t is Number) ko.put("t", q(t.toDouble() - dt))
                        }
                    }
                    for (k in v.keys()) if (k != "keys") walk(v.opt(k))
                }
                is JSONArray -> for (i in 0 until v.length()) walk(v.opt(i))
            }
        }
        walk(o.opt("props"))
    }

    /** Frame index relative to the group's first frame (what is stored on disk). */
    private fun rel(pid: String, gid: Int, idx: Int): Int =
        synchronized(lock) { idx - (baseIdx["$pid/$gid"] ?: 0) }

    // MARK: frame grid

    fun frameIndex(t: Float, fps: Int): Int = (max(0f, t) * max(1, fps).toFloat()).roundToInt()

    /** First…last frame index a group is on screen. */
    fun range(g: Layer, project: Project, scene: Scene): IntRange {
        val (s0, e0) = span(g, scene)
        val a = frameIndex(s0, project.fps)
        val n = frameIndex(max(0f, min(e0, scene.duration) - s0), project.fps)
        return a..(a + max(0, n))
    }

    // MARK: files

    private fun dir(pid: String, gid: Int): File = File(File(root, pid), gid.toString())

    private fun name(sig: String, w: Int, h: Int, idx: Int): String = "${sig}_${w}x${h}_$idx.pre"

    private fun memoKey(pid: String, gid: Int, sig: String, w: Int, h: Int): String = "$pid/$gid/$sig/${w}x$h"

    private fun have(pid: String, gid: Int, sig: String, w: Int, h: Int): Set<Int> {
        val k = memoKey(pid, gid, sig, w, h)
        synchronized(lock) { haveMemo[k]?.let { return it } }
        val s = HashSet<Int>()
        val prefix = "${sig}_${w}x${h}_"
        dir(pid, gid).listFiles()?.forEach { f ->
            if (f.name.startsWith(prefix) && f.name.endsWith(".pre")) {
                f.name.dropLast(4).drop(prefix.length).toIntOrNull()?.let { s.add(it) }
            }
        }
        synchronized(lock) { haveMemo[k] = s }
        return s
    }

    fun has(pid: String, gid: Int, sig: String, w: Int, h: Int, idx: Int): Boolean =
        have(pid, gid, sig, w, h).contains(rel(pid, gid, idx))

    /** Next frame (from `t` on, wrapping) of the group that is not baked yet; null when complete. */
    fun nextMissing(g: Layer, project: Project, scene: Scene, w: Int, h: Int, t: Float): Int? {
        val sig = signature(g, project, scene)
        val b = -rel(project.id, g.id, 0)
        val got = have(project.id, g.id, sig, w, h).map { it + b }.toHashSet()   // → absolute
        val r = range(g, project, scene)
        if (got.size >= (r.last - r.first + 1) && r.all { got.contains(it) }) return null
        val start = min(max(frameIndex(t, project.fps), r.first), r.last)
        for (i in start..r.last) if (!got.contains(i)) return i
        for (i in r.first until start) if (!got.contains(i)) return i
        return null
    }

    /** (baked, total) frames for the group at this size. */
    fun progress(g: Layer, project: Project, scene: Scene, w: Int, h: Int): Pair<Int, Int> {
        val sig = signature(g, project, scene)
        val b = -rel(project.id, g.id, 0)
        val got = have(project.id, g.id, sig, w, h).map { it + b }.toHashSet()
        val r = range(g, project, scene)
        return Pair(r.count { got.contains(it) }, r.last - r.first + 1)
    }

    fun load(pid: String, gid: Int, sig: String, w: Int, h: Int, idx: Int): ByteArray? {
        if (!has(pid, gid, sig, w, h, idx)) return null
        val u = File(dir(pid, gid), name(sig, w, h, rel(pid, gid, idx)))
        return try {
            val packed = u.readBytes()
            val raw = inflate(packed)
            if (raw == null || raw.size != w * h * 4) null else raw
        } catch (_: Exception) { null }
    }

    fun store(pid: String, gid: Int, sig: String, w: Int, h: Int, idx: Int, rgba: ByteArray) {
        val d = dir(pid, gid)
        d.mkdirs()
        val packed = deflate(rgba) ?: return
        val ri = rel(pid, gid, idx)
        val u = File(d, name(sig, w, h, ri))
        try { u.writeBytes(packed) } catch (_: Exception) { return }
        val k = memoKey(pid, gid, sig, w, h)
        synchronized(lock) { haveMemo.getOrPut(k) { HashSet() }.add(ri) }
    }

    /** zlib container (marker byte 0x01 + raw zlib stream). */
    private fun deflate(raw: ByteArray): ByteArray? = try {
        val bos = java.io.ByteArrayOutputStream()
        bos.write(1)   // marker: 0x01 = zlib
        java.util.zip.DeflaterOutputStream(bos, java.util.zip.Deflater(java.util.zip.Deflater.BEST_SPEED, true)).use { it.write(raw) }
        bos.toByteArray()
    } catch (_: Exception) { null }

    private fun inflate(packed: ByteArray): ByteArray? {
        if (packed.isEmpty() || packed[0] != 0x01.toByte()) return null
        return try {
            val bin = java.io.ByteArrayInputStream(packed, 1, packed.size - 1)
            java.util.zip.InflaterInputStream(bin, java.util.zip.Inflater(true)).use { it.readBytes() }
        } catch (_: Exception) { null }
    }

    /** Deletes this group's frames that belong to another signature (stale after an edit). */
    fun purgeStale(pid: String, gid: Int, sig: String) {
        val d = dir(pid, gid)
        d.listFiles()?.forEach { if (!it.name.startsWith(sig + "_")) it.delete() }
        synchronized(lock) {
            for (k in haveMemo.keys.toList()) if (k.startsWith("$pid/$gid/") && !k.startsWith("$pid/$gid/$sig/")) haveMemo.remove(k)
        }
    }

    /** purgeStale, but only the first time a signature is seen for the group. */
    fun purgeStaleOnce(pid: String, gid: Int, sig: String) {
        val k = "$pid/$gid"
        val seen: String?
        synchronized(lock) { seen = purgedSig[k]; purgedSig[k] = sig }
        if (seen != sig) purgeStale(pid, gid, sig)
    }

    /** Drops one group's frames (flag turned off) or the whole project's. */
    fun clear(pid: String, gid: Int? = null) {
        val u = if (gid != null) dir(pid, gid) else File(root, pid)
        u.deleteRecursively()
        synchronized(lock) {
            val pre = if (gid != null) "$pid/$gid/" else "$pid/"
            for (k in haveMemo.keys.toList()) if (k.startsWith(pre)) haveMemo.remove(k)
        }
    }

    fun clearAll() {
        root.deleteRecursively()
        synchronized(lock) { haveMemo.clear(); sigMemo.clear() }
    }
}
