package com.saiki.motion.core

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

// Port of Sources/Model/Project.swift (Scene + Project). JSON schema is IDENTICAL to iOS so .saikiproject files
// open on both platforms. NOTE: org.json optDouble() defaults to NaN -> always pass explicit defaults (done below).
// Defs (PropDef tables) live in Defs.kt. Layer is the real port in Layer.kt.

class Scene(var name: String) {
    var layers = mutableListOf<Layer>()
    var duration = 5f
    var fov = 55f
    var bg: Int = 0xFF000000.toInt()
    var markers = mutableListOf<Float>()
    var markerNames = linkedMapOf<Float, String>()

    fun markerName(t: Float): String? {
        for (m in markers) if (Math.abs(m - t) < 0.02f) { val n = markerNames[m]; if (!n.isNullOrEmpty()) return n }
        return null
    }
    fun setMarkerName(t: Float, name: String) {
        for (m in markers) if (Math.abs(m - t) < 0.02f) {
            if (name.isEmpty()) markerNames.remove(m) else markerNames[m] = name
            return
        }
    }
    /** name -> time for expressions; duplicate names: last wins (same as iOS). */
    fun markersByName(): Map<String, Float> { val o = HashMap<String, Float>(); for ((t, n) in markerNames) o[n] = t; return o }

    fun toJson() = JSONObject().apply {
        put("name", name); putF("duration", duration); putF("fov", fov)
        putD("bg", colorToJson(bg))
        put("layers", JSONArray().also { a -> layers.forEach { a.put(it.toJson()) } })
        put("markers", JSONArray().also { a -> markers.forEach { a.putF(it) } })
        put("markerNames", JSONObject().also { o -> for ((k, v) in markerNames) o.put(String.format(Locale.US, "%.3f", k.toDouble()), v) })
    }

    companion object {
        fun fromJson(o: JSONObject): Scene {
            val s = Scene(o.optString("name", "Scene"))
            s.duration = maxOf(0.1f, o.optDouble("duration", 5.0).toFloat())
            s.fov = o.optDouble("fov", 55.0).toFloat()
            s.bg = o.optDouble("bg", 0.0).toLong().coerceIn(0L, 0xFFFFFFFFL).toInt()   // UInt32(clamping:) on iOS
            o.optJSONArray("layers")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { s.layers.add(Layer.fromJson(it)) } }
            o.optJSONArray("markers")?.let { a -> for (i in 0 until a.length()) s.markers.add(a.optDouble(i, 0.0).toFloat()) }
            o.optJSONObject("markerNames")?.let { m -> for (k in m.keys()) s.markerNames[parseSwiftFloat(k) ?: 0f] = m.optString(k, "") }
            return s
        }
    }
}

class Project(
    var id: String = UUID.randomUUID().toString().uppercase(Locale.US),   // Swift UUIDString is uppercase
    var name: String,
    var createdAt: Long = System.currentTimeMillis(),
    var updatedAt: Long = System.currentTimeMillis(),
    var w: Int = 1080, var h: Int = 1920, var fps: Int = 30, var nextId: Int = 1,
) {
    var scenes = mutableListOf(Scene("Scene 1"))

    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("createdAt", createdAt); put("updatedAt", updatedAt)
        put("w", w.toLong()); put("h", h.toLong()); put("fps", fps.toLong()); put("nextId", nextId.toLong())
        put("scenes", JSONArray().also { a -> scenes.forEach { a.put(it.toJson()) } })
    }

    companion object {
        fun fromJson(o: JSONObject): Project {
            val p = Project(
                id = o.optString("id", UUID.randomUUID().toString().uppercase(Locale.US)),
                name = o.optString("name", "Untitled"),
                createdAt = o.optDouble("createdAt", 0.0).toLong(), updatedAt = o.optDouble("updatedAt", 0.0).toLong(),
                w = o.optInt("w", 1080), h = o.optInt("h", 1920),
                fps = o.optInt("fps", 30).coerceIn(10, 60), nextId = o.optInt("nextId", 1))
            p.scenes = mutableListOf()
            o.optJSONArray("scenes")?.let { a -> for (i in 0 until a.length()) a.optJSONObject(i)?.let { p.scenes.add(Scene.fromJson(it)) } }
            if (p.scenes.isEmpty()) p.scenes = mutableListOf(Scene("Scene 1"))
            return p
        }
    }
}
