package com.saiki.motion.core

import android.net.Uri
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.UUID

// Port of Sources/Model/ProjectArchive.swift — the ".saikiproject" bundle:
//   "SAIKIPRJ1\n" | u32 jsonLen LE | json (media paths -> "@media/<key>") | u32 count | per file: u16 keyLen, key, u64 len, data
object ProjectArchive {
    const val fileExtension = "saikiproject"
    private val magic = "SAIKIPRJ1\n".toByteArray(Charsets.UTF_8)
    private const val prefix = "@media/"

    private fun open(uri: Uri): InputStream? = try { Paths.appContext.contentResolver.openInputStream(uri) } catch (_: Exception) { null }

    fun isArchive(uri: Uri): Boolean {
        val ins = open(uri) ?: return false
        return ins.use {
            val head = readExact(it, magic.size)
            head != null && head.copyOf(8).contentEquals(magic.copyOf(8))
        }
    }

    private fun le32(v: Long) = byteArrayOf((v and 0xFF).toByte(), ((v shr 8) and 0xFF).toByte(), ((v shr 16) and 0xFF).toByte(), ((v shr 24) and 0xFF).toByte())
    private fun le16(v: Int) = byteArrayOf((v and 0xFF).toByte(), ((v shr 8) and 0xFF).toByte())
    private fun le64(v: Long): ByteArray { val o = ByteArray(8); for (i in 0 until 8) o[i] = ((v ushr (8 * i)) and 0xFF).toByte(); return o }
    private fun readExact(i: InputStream, n: Int): ByteArray? {
        if (n == 0) return ByteArray(0)
        val b = ByteArray(n); var off = 0
        while (off < n) { val r = i.read(b, off, n - off); if (r < 0) return null; off += r }
        return b
    }
    private fun u(d: ByteArray): Long { var v = 0L; for ((i, b) in d.withIndex()) v = v or ((b.toLong() and 0xFF) shl (8 * i)); return v }
    private fun skipFully(i: InputStream, n: Long) { var left = n; while (left > 0) { val s = i.skip(left); if (s <= 0) { if (i.read() < 0) break; left-- } else left -= s } }

    /** Writes "<name>.saikiproject" into the cache folder. Returns null on failure. */
    fun export(id: String): File? {
        val src = Projects.load(id) ?: return null
        val o = parseJson(src.toJson().toCompact()) ?: return null
        val p = Project.fromJson(o)                       // private copy we may rewrite

        val keyForPath = HashMap<String, String>()
        class F(val key: String, val path: String)
        val files = mutableListOf<F>()
        fun claim(path: String?): String? {
            if (path == null || path.isEmpty() || !File(path).exists()) return path
            keyForPath[path]?.let { return prefix + it }
            var key = path.substringAfterLast('/')
            if (files.any { it.key == key }) key = "${files.size}_$key"
            keyForPath[path] = key
            files.add(F(key, path))
            return prefix + key
        }
        for (s in p.scenes) for (l in s.layers) { l.imagePath = claim(l.imagePath); l.fontPath = claim(l.fontPath) }

        val json = p.toJson().toCompact().toByteArray(Charsets.UTF_8)
        val safe = src.name.map { if ("/\\:*?\"<>|".indexOf(it) >= 0) '_' else it }.joinToString("")
        Paths.ensure()
        val dest = File(Paths.appContext.cacheDir, (if (safe.isEmpty()) "project" else safe) + "." + fileExtension)
        dest.delete()
        return try {
            dest.outputStream().buffered().use { out: OutputStream ->
                out.write(magic)
                out.write(le32(json.size.toLong()))
                out.write(json)
                val real = files.filter { File(it.path).exists() }
                out.write(le32(real.size.toLong()))
                for (f in real) {
                    val keyBytes = f.key.toByteArray(Charsets.UTF_8)
                    val size = File(f.path).length()
                    val kb = if (keyBytes.size > 65535) keyBytes.copyOf(65535) else keyBytes
                    out.write(le16(minOf(keyBytes.size, 65535)))
                    out.write(kb)
                    out.write(le64(size))
                    File(f.path).inputStream().use { it.copyTo(out, 1 shl 20) }
                }
            }
            dest
        } catch (e: Exception) { dest.delete(); null }
    }

    /** Unpacks a .saikiproject into the store under a fresh id; media get fresh names and every path is repointed. */
    fun importArchive(uri: Uri, includeMedia: Boolean = true): Project? {
        val raw = open(uri) ?: return null
        return BufferedInputStream(raw, 1 shl 16).use { fh ->
            val head = readExact(fh, magic.size) ?: return null
            if (!head.copyOf(8).contentEquals(magic.copyOf(8))) return null
            val lenData = readExact(fh, 4) ?: return null
            val jsonLen = u(lenData)
            if (jsonLen <= 0 || jsonLen >= 400_000_000) return null
            val jsonData = readExact(fh, jsonLen.toInt()) ?: return null
            val obj = parseJson(String(jsonData, Charsets.UTF_8)) ?: return null
            val p = Project.fromJson(obj)

            Projects.ensureDirs()
            val newPath = HashMap<String, String>()
            readExact(fh, 4)?.let { cData ->
                val count = u(cData).toInt()
                for (n in 0 until minOf(count, 100_000)) {
                    val kl = readExact(fh, 2) ?: break
                    val kb = readExact(fh, u(kl).toInt()) ?: break
                    val key = String(kb, Charsets.UTF_8)
                    val sl = readExact(fh, 8) ?: break
                    var left = u(sl)
                    if (!includeMedia) { skipFully(fh, left); continue }   // keep the project's existing files
                    val clean = key.replace("/", "_")
                    val dest = File(Projects.mediaDir(), ProjectIO.sandboxName(clean))
                    val w = try { dest.outputStream() } catch (_: Exception) { break }
                    w.use {
                        val buf = ByteArray(1 shl 16)
                        while (left > 0) { val r = fh.read(buf, 0, minOf(left, buf.size.toLong()).toInt()); if (r <= 0) break; it.write(buf, 0, r); left -= r }
                    }
                    newPath[key] = dest.absolutePath
                }
            }
            fun fix(path: String?): String? {
                if (path == null || !path.startsWith(prefix)) return path
                return newPath[path.substring(prefix.length)]
            }
            for (s in p.scenes) for (l in s.layers) { l.imagePath = fix(l.imagePath); l.fontPath = fix(l.fontPath) }
            run {   // ProjectArchive.swift:180-184: add every font the project brought along to the font library
                val fontFiles = java.util.TreeSet<String>()
                for (s in p.scenes) for (l in s.layers) { val f = l.fontPath; if (f != null && f.isNotEmpty()) fontFiles.add(f) }
                if (fontFiles.isNotEmpty()) FontLibrary.importURLs(fontFiles.map { android.net.Uri.fromFile(File(it)) }, null)
            }
            p.id = UUID.randomUUID().toString().uppercase(Locale.US)
            if (p.name.isEmpty()) p.name = Paths.displayName(uri).substringBeforeLast('.', Paths.displayName(uri))
            val nLayers = p.scenes.sumOf { it.layers.size }
            Projects.lastImportNote = "${p.scenes.size} scenes · $nLayers layers · ${newPath.size} media"
            Projects.save(p)
            p
        }
    }
}
