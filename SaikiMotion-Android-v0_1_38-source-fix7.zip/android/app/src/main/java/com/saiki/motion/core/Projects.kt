package com.saiki.motion.core

import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.Locale
import java.util.UUID

// Port of Sources/Model/Projects.swift + ProjectIO.swift — the project store.
// <filesDir>/SaikiMotion/projects/<id>.json, media in <filesDir>/SaikiMotion/media (iOS: Documents/SaikiMotion/...).

object Projects {
    var lastError: String? = null
    val root: File get() = Paths.root
    val dir: File get() = File(root, "projects")
    fun mediaDir(): File = File(root, "media")
    fun fileURL(id: String): File = File(dir, "$id.json")
    private fun bakURL(id: String): File = File(dir, "$id.bak")

    fun ensureDirs() { Paths.ensure(); dir.mkdirs(); mediaDir().mkdirs() }

    /** Saves the project (bumps updatedAt). Returns the written text. */
    fun save(id: String, project: Project): String {
        ensureDirs()
        project.updatedAt = System.currentTimeMillis()
        project.id = id
        val text = project.toJson().toCompact()
        val url = fileURL(id)
        try {
            if (url.exists()) { val bak = bakURL(id); bak.delete(); try { url.copyTo(bak, overwrite = true) } catch (_: Exception) {} }
            val tmp = File(dir, "$id.json.tmp"); tmp.writeText(text, Charsets.UTF_8)
            if (!tmp.renameTo(url)) { url.delete(); if (!tmp.renameTo(url)) throw java.io.IOException("rename failed") }
            val back = try { url.readText(Charsets.UTF_8) } catch (_: Exception) { null }
            lastError = if (back != null && parseJson(back) != null) null else "the saved file could not be read back"
        } catch (e: Exception) {
            lastError = e.localizedMessage
            android.util.Log.e("SaikiMotion", "Project save failed: $e")
        }
        StoreNotification.post(StoreNotification.Name.projectsChanged)
        return text
    }

    fun save(project: Project): String = save(project.id, project)

    fun load(id: String): Project? {
        val text = try { fileURL(id).readText(Charsets.UTF_8) } catch (_: Exception) { return null }
        parseJson(text)?.let { return Project.fromJson(it) }
        // unreadable main file -> fall back to the backup instead of an empty project
        val t2 = try { bakURL(id).readText(Charsets.UTF_8) } catch (_: Exception) { return null }
        return parseJson(t2)?.let { Project.fromJson(it) }
    }

    /** All projects, newest-touched first. */
    fun list(): List<Project> {
        ensureDirs()
        val files = dir.listFiles() ?: return emptyList()
        return files.filter { it.extension == "json" }.mapNotNull { load(it.nameWithoutExtension) }.sortedByDescending { it.updatedAt }
    }

    fun thumbFile(id: String): File { val d = File(root, "thumbs"); d.mkdirs(); return File(d, "$id.jpg") }

    fun delete(id: String) {
        thumbFile(id).delete()
        Folders.move(id, null)
        fileURL(id).delete()
        StoreNotification.post(StoreNotification.Name.projectsChanged)
    }

    fun rename(id: String, name: String) { val p = load(id) ?: return; p.name = name; save(p) }

    /** Deep-copies a project under a new id ("Name copy"). */
    fun duplicate(id: String): Project? {
        val p = load(id) ?: return null
        val o = parseJson(p.toJson().toCompact()) ?: return null
        val copy = Project.fromJson(o)
        copy.id = UUID.randomUUID().toString().uppercase(Locale.US)
        copy.name = p.name + " copy"
        save(copy)
        return copy
    }

    fun exportFile(id: String): File = fileURL(id)

    /** Replaces project `id` with the contents of a project file (keeps its id and name). */
    fun overwrite(id: String, from: Uri, includeMedia: Boolean): Project? {
        val old = load(id) ?: return null
        val isArc = ProjectArchive.isArchive(from)
        val p = (if (isArc) ProjectArchive.importArchive(from, includeMedia) else importFile(from)) ?: return null
        val tmp = p.id
        if (isArc && !includeMedia) {
            val img = HashMap<Int, String>(); val font = HashMap<Int, String>()
            for (s in old.scenes) for (l in s.layers) { l.imagePath?.let { img[l.id] = it }; l.fontPath?.let { font[l.id] = it } }
            for (s in p.scenes) for (l in s.layers) { l.imagePath = img[l.id]; l.fontPath = font[l.id] }
        }
        p.id = id
        p.name = old.name
        // PARITY (suspected iOS bug, kept): Projects.swift `guard save(&p) == nil` — save returns the text (never nil), so iOS always returns nil here
        // and HomeViewController.swift:1360 reports failure after a successful overwrite. Ported line-for-line; owner to decide.
        if (save(p) != null) return null
        if (tmp != id) delete(tmp)
        return p
    }

    var lastImportNote = ""

    /** Imports a project JSON: copies it into the store under a fresh id so re-importing never collides. */
    fun importFile(uri: Uri): Project? {
        if (ProjectArchive.isArchive(uri)) return ProjectArchive.importArchive(uri)
        val data: ByteArray = (try { Paths.appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() } } catch (_: Exception) { null }) ?: return null
        var o = lenientParse(data) ?: return null
        // unwrap {"project": {...}} style containers
        if (o.optJSONArray("scenes") == null && o.optJSONArray("layers") == null) {
            for (k in listOf("project", "data", "composition", "comp", "root", "document")) { val inner = o.optJSONObject(k); if (inner != null) { o = inner; break } }
        }
        val p = Project.fromJson(o)
        // a bare composition ({"layers": [...]} with no scenes list) becomes the first scene
        if (o.optJSONArray("scenes") == null && o.optJSONArray("layers") != null) p.scenes = mutableListOf(Scene.fromJson(o))
        p.id = UUID.randomUUID().toString().uppercase(Locale.US)
        if (p.name.isEmpty() || p.name == "Untitled") p.name = Paths.displayName(uri).substringBeforeLast('.', Paths.displayName(uri))
        val nl = p.scenes.sumOf { it.layers.size }
        lastImportNote = "${p.scenes.size} scenes · $nl layers" +
            (if (nl == 0) " · file keys: " + o.keys().asSequence().take(8).joinToString(",") else "")
        save(p)
        return p
    }

    private fun decodeStrict(b: ByteArray, cs: Charset): String? = try {
        cs.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString()
    } catch (e: CharacterCodingException) { null }

    /** Tolerates BOM, UTF-16, NULs and junk before/after the JSON object. */
    fun lenientParse(data: ByteArray): JSONObject? {
        val texts = mutableListOf<String>()
        decodeStrict(data, Charsets.UTF_8)?.let { texts.add(it) }
        decodeStrict(data, Charsets.UTF_16)?.let { texts.add(it) }
        texts.add(String(data, Charsets.ISO_8859_1))
        for (raw in texts) {
            val t = raw.replace("\uFEFF", "").replace("\u0000", "").trim()
            parseJson(t)?.let { return it }
            val a = t.indexOf('{'); val b = t.lastIndexOf('}')
            if (a >= 0 && b >= 0 && a < b) parseJson(t.substring(a, b + 1))?.let { return it }
        }
        return null
    }

    fun resLabel(w: Int, h: Int): String {
        val r = w.toDouble() / max(h, 1).toDouble()
        val ar = if (r > 1.2) "landscape" else if (r < 0.83) "portrait" else "square"
        val hd = max(w, h)
        val tag = if (hd >= 2000) "2K" else if (hd >= 1000) "1080p" else "SD"
        return "$tag $ar"
    }

    fun resLabel(p: Project): String {
        val layers = p.scenes.sumOf { it.layers.size }
        val word = if (p.scenes.size == 1) "scene" else "scenes"
        return "${p.scenes.size} $word · $layers layers · ${p.fps} fps"
    }

    private fun max(a: Int, b: Int) = if (a > b) a else b
}

object ProjectIO {
    fun ensureDirs() = Projects.ensureDirs()

    /** Unique media file name for a source name: "<timestamp>_<name>"; fonts become "<ts>_font.<ext>". */
    fun sandboxName(original: String): String {
        val ts = (System.currentTimeMillis() / 1000).toInt()
        val clean = original.replace("/", "_")
        val lc = clean.lowercase(Locale.US)
        if (lc.endsWith(".ttf") || lc.endsWith(".otf")) return "${ts}_font.${clean.substringAfterLast('.', "")}"
        return "${ts}_$clean"
    }

    /** Copies a picked file into Projects.mediaDir. Returns the stored file's absolute path, or null on failure. */
    fun copyMediaIntoSandbox(source: Uri, kind: String = ""): String? {
        ensureDirs()
        val dest = File(Projects.mediaDir(), sandboxName(Paths.displayName(source)))
        return try {
            if (dest.exists()) dest.delete()
            Paths.appContext.contentResolver.openInputStream(source)?.use { i -> dest.outputStream().use { o -> i.copyTo(o) } } ?: return null
            dest.absolutePath
        } catch (_: Exception) { null }
    }

    fun writeDataIntoSandbox(data: ByteArray, original: String): String? {
        ensureDirs()
        val dest = File(Projects.mediaDir(), sandboxName(original))
        return try { val tmp = File(dest.path + ".tmp"); tmp.writeBytes(data); tmp.renameTo(dest); dest.absolutePath } catch (_: Exception) { null }
    }

    fun mediaFile(name: String): File = File(Projects.mediaDir(), name)
    fun deleteMedia(name: String) { mediaFile(name).delete() }
}
