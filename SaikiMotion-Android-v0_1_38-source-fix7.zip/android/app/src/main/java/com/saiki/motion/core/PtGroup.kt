package com.saiki.motion.core

/** Render/Particular.swift:40-50 PtGroup (the rest of Particular.swift is the particle sim, ported with the particle slice). */
object PtGroup {
    const val maxExtra = 3
    fun pre(g: Int): String = if (g <= 0) "" else "g$g"
    fun strip(k: String): String {
        if (k.length > 4 && k[0] == 'g' && k[1] in '1'..'3' && k[2] == 'p' && k[3] == 't') return k.substring(2)
        return k
    }
    fun count(g: (String) -> Float): Int = 1 + minOf(maxExtra, maxOf(0, Math.round(g("ptGroups"))))
    fun reader(g: (String) -> Float, gi: Int): (String) -> Float = if (gi <= 0) g else { k -> g(pre(gi) + k) }
}
