package com.saiki.motion.core

import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.cos

// Port of Sources/Render/ParticularAssets.swift:501-824 — the .saikiparticle preset library:
// PtPreset, PtPresetStore (encode/decode/list/save/importFile/delete/exportURL) and PtBuiltins.all.
// The other types of the same Swift file (PtPath/PtGradient/PtParams/PtImages) live in ParticularAssets.kt.

// MARK: - Presets (.saikiparticle)

class PtPreset(
    var id: String,
    var name: String,
    var cat: String,
    var params: MutableMap<String, Float>,
    var thumbT: Float = 1.6f,
    var custom: Boolean = false,
    var url: File? = null
)

object PtPresetStore {
    const val ext = "saikiparticle"
    val dir: File get() = File(Paths.root, "ParticlePresets").apply { mkdirs() }

    /** File contents: plain JSON, with any imported sprite / emitter image embedded so the file is self-contained. */
    fun encode(name: String, params: Map<String, Float>): ByteArray? {
        return try {
            val o = JSONObject()
            o.put("format", "saikiparticle")
            o.put("version", 1)
            o.put("name", name)
            val p = JSONObject()
            for ((k, v) in params) p.put(k, v.toDouble())
            o.put("params", p)
            val spriteId = params["ptSpriteId"]?.toInt()
            if (spriteId != null && (params["ptSprite"] ?: 0f) == 6f) {
                PtImages.data(spriteId)?.let { (d, c) -> o.put("sprite", android.util.Base64.encodeToString(d, android.util.Base64.NO_WRAP)); o.put("spriteCells", c) }
            }
            val emId = params["ptEmImgId"]?.toInt()
            if (emId != null && emId > 0) {
                PtImages.data(emId)?.let { (d, c) -> o.put("emImage", android.util.Base64.encodeToString(d, android.util.Base64.NO_WRAP)); o.put("emCells", c) }
            }
            val bumpId = params["ptBumpId"]?.toInt()
            if (bumpId != null && bumpId > 0) {
                PtImages.data(bumpId)?.let { (d, c) -> o.put("bump", android.util.Base64.encodeToString(d, android.util.Base64.NO_WRAP)); o.put("bumpCells", c) }
            }
            // iOS: JSONSerialization with [.prettyPrinted, .sortedKeys]
            val ks = ArrayList<String>(); val it = o.keys(); while (it.hasNext()) ks.add(it.next())
            ks.sort()
            val sb = StringBuilder("{\n")
            for ((i, k) in ks.withIndex()) {
                sb.append("  \"").append(JSONWriter.escape(k)).append("\" : ")
                val v = o.opt(k)
                when (v) {
                    is String -> sb.append(JSONWriter.escape(v))
                    else -> sb.append(JSONWriter.scalar(v))
                }
                sb.append(if (i < ks.size - 1) ",\n" else "\n")
            }
            sb.append("}")
            sb.toString().toByteArray(Charsets.UTF_8)
        } catch (_: Exception) { null }
    }

    fun decode(data: ByteArray): PtPreset? {
        val o = try { JSONObject(String(data, Charsets.UTF_8)) } catch (_: Exception) { null } ?: return null
        if (o.optString("format", "") != "saikiparticle") return null
        val raw = o.optJSONObject("params") ?: return null
        val p = HashMap<String, Float>()
        for (k in raw.keys()) {
            val v = raw.opt(k)
            if (v is Number) p[k] = v.toFloat()
        }
        val sprite = o.optString("sprite", "")
        if (sprite.isNotEmpty()) {
            val d = try { android.util.Base64.decode(sprite, android.util.Base64.DEFAULT) } catch (_: Exception) { null }
            if (d != null) PtImages.addData(d, o.optInt("spriteCells", 1))?.let { p["ptSpriteId"] = it.toFloat() }
        }
        val em = o.optString("emImage", "")
        if (em.isNotEmpty()) {
            val d = try { android.util.Base64.decode(em, android.util.Base64.DEFAULT) } catch (_: Exception) { null }
            if (d != null) PtImages.addData(d, o.optInt("emCells", 1))?.let { p["ptEmImgId"] = it.toFloat() }
        }
        val bump = o.optString("bump", "")
        if (bump.isNotEmpty()) {
            val d = try { android.util.Base64.decode(bump, android.util.Base64.DEFAULT) } catch (_: Exception) { null }
            if (d != null) PtImages.addData(d, o.optInt("bumpCells", 1))?.let { p["ptBumpId"] = it.toFloat() }
        }
        val name = o.optString("name", "Imported")
        return PtPreset("u" + UUID.randomUUID().toString().uppercase(), name, "Mine", p, 1.6f, true)
    }

    fun list(): List<PtPreset> {
        val fs = dir.listFiles() ?: return emptyList()
        val items = ArrayList<Pair<Long, PtPreset>>()
        for (u in fs) {
            if (u.extension != ext) continue
            val d = try { u.readBytes() } catch (_: Exception) { null } ?: continue
            var p = decodeStored(d) ?: continue
            p.id = "f" + u.name
            p.url = u
            items.add(Pair(u.lastModified(), p))
        }
        return items.sortedByDescending { it.first }.map { it.second }
    }

    /** Stored files keep their media ids as-is (embedded media only matters when a file arrives from outside). */
    private fun decodeStored(data: ByteArray): PtPreset? {
        val o = try { JSONObject(String(data, Charsets.UTF_8)) } catch (_: Exception) { null } ?: return null
        if (o.optString("format", "") != "saikiparticle") return null
        val raw = o.optJSONObject("params") ?: return null
        val p = HashMap<String, Float>()
        for (k in raw.keys()) {
            val v = raw.opt(k)
            if (v is Number) p[k] = v.toFloat()
        }
        return PtPreset("", o.optString("name", "Preset"), "Mine", p, 1.6f, true)
    }

    fun save(name: String, params: Map<String, Float>): PtPreset? {
        val safe = name.split('/', '\\', ':', '?', '*', '"', '<', '>', '|').joinToString("").trim()
        val nm = if (safe.isEmpty()) "Preset" else safe
        var u = File(dir, "$nm.$ext")
        var n = 2
        while (u.exists()) { u = File(dir, "$nm $n.$ext"); n++ }
        val d = encode(nm, params) ?: return null
        return try { u.writeBytes(d); PtPreset("f" + u.name, nm, "Mine", HashMap(params), 1.6f, true, u) } catch (_: Exception) { null }
    }

    /** Imports a file from outside: media is unpacked, then it is saved into the library. */
    fun importFile(url: File): PtPreset? {
        val d = try { url.readBytes() } catch (_: Exception) { null } ?: return null
        val p = decode(d) ?: return null
        return save(p.name, p.params)
    }

    fun delete(p: PtPreset) { p.url?.let { try { it.delete() } catch (_: Exception) {} } }

    /** A temporary .saikiparticle file ready to share. */
    fun exportURL(name: String, params: Map<String, Float>): File? {
        val d = encode(name, params) ?: return null
        val u = File(Paths.appContext.cacheDir, "$name.$ext")
        return try { u.writeBytes(d); u } catch (_: Exception) { null }
    }
}

// MARK: - Built-in presets

object PtBuiltins {
    val all: List<PtPreset> by lazy {
        val out = ArrayList<PtPreset>()
        fun add(name: String, cat: String, t: Float, d: Map<String, Float>,
                grad: IntArray? = null, a: Int? = null, b: Int? = null, groups: List<Map<String, Float>> = emptyList()) {
            val p = HashMap<String, Float>(d)
            for (g in groups) for ((k, v) in g) p[k] = v
            if (groups.isNotEmpty()) p["ptGroups"] = groups.size.toFloat()
            if (grad != null) for ((k, v) in PtGradient.params(PtGradient.evenly(grad))) p[k] = v
            if (a != null) for ((k, v) in PtParams.color("ptColA", a)) p[k] = v
            if (b != null) for ((k, v) in PtParams.color("ptColB", b)) p[k] = v
            out.add(PtPreset("b$name", name, cat, p, t))
        }
        /** One extra particle group (n = 1…3): every key is stored under the group prefix. */
        fun G(n: Int, d: Map<String, Float>, grad: IntArray? = null): Map<String, Float> {
            val q = HashMap<String, Float>(d)
            if (grad != null) for ((k, v) in PtGradient.params(PtGradient.evenly(grad))) q[k] = v
            val o = HashMap<String, Float>()
            for ((k, v) in q) o[PtGroup.pre(n) + k] = v
            return o
        }
        fun merge(vararg maps: Map<String, Float>): Map<String, Float> {
            val m = HashMap<String, Float>()
            for (x in maps) for ((k, v) in x) m[k] = v
            return m
        }
        val pinkG = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFC2E1.toInt(), 0xFFFF7AB8.toInt(), 0x00D03A86)
        // Signature looks
        add("Realistic Firework", "Signature", 1.2f, mapOf(
            "ptEmType" to 2f, "ptBehavior" to 1f, "ptSizeX" to 0.03f, "ptSizeY" to 0.03f, "ptSizeZ" to 0.03f, "ptPosY" to 0.25f, "ptRate" to 190f, "ptLife" to 2.4f, "ptLifeRand" to 0.25f,
            "ptVel" to 1.5f, "ptVelRand" to 0.45f, "ptAir" to 0.55f, "ptGravity" to 0.55f, "ptSize" to 0.008f, "ptSoft" to 0.6f, "ptSizeEnd" to 0.25f, "ptTrail" to 5f, "ptTrailLen" to 0.35f,
            "ptTwinkle" to 0.7f, "ptTwinkleRate" to 7f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.5f),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD36B.toInt(), 0xFFFF6A1F.toInt(), 0x00C81E00))
        add("Dissolve", "Signature", 1.3f, mapOf(
            "ptEmType" to 11f, "ptBehavior" to 2f, "ptSizeX" to 0.7f, "ptSizeY" to 0.9f, "ptSizeZ" to 0.2f, "ptRate" to 1400f, "ptLife" to 2.5f, "ptVel" to 0.12f, "ptSpread" to 0.5f,
            "ptDissStart" to 0.3f, "ptDissDur" to 2f, "ptDissSweep" to 0.85f, "ptScatter" to 0.8f, "ptWindY" to 0.35f, "ptWindX" to 0.45f, "ptCurl" to 0.8f, "ptSize" to 0.007f, "ptSoft" to 0.2f,
            "ptFadeIn" to 0.05f, "ptFadeOut" to 0.45f),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFE9B0.toInt(), 0xFFFFB347.toInt(), 0x00FF7A00))
        add("Digital Rain", "Signature", 2.4f, mapOf(
            "ptEmType" to 1f, "ptSizeX" to 0.9f, "ptSizeY" to 0f, "ptSizeZ" to 0.3f, "ptPosY" to 1.3f, "ptMotion" to 2f, "ptDirX" to 0f, "ptDirY" to -1f, "ptDirZ" to 0f, "ptVel" to 0.9f, "ptVelRand" to 0.3f,
            "ptSpread" to 0f, "ptLife" to 3.2f, "ptLifeRand" to 0f, "ptRate" to 155f, "ptQuant" to 0.07f, "ptTrail" to 7f, "ptTrailLen" to 0.45f, "ptSprite" to 3f, "ptSpriteTint" to 1f,
            "ptSize" to 0.016f, "ptSoft" to 0f, "ptSizeRand" to 0.1f, "ptFadeIn" to 0.05f, "ptFadeOut" to 0.15f),
            grad = intArrayOf(0xFF00561F.toInt(), 0xFF00E050.toInt(), 0xFFB8FFC8.toInt(), 0xFFFFFFFF.toInt()))
        add("Rose Petals", "Signature", 2.5f, mapOf(
            "ptEmType" to 1f, "ptSizeX" to 1f, "ptSizeY" to 0.1f, "ptSizeZ" to 0.8f, "ptPosY" to 1.3f, "ptMotion" to 2f, "ptDirY" to -1f, "ptVel" to 0.2f, "ptSpread" to 0.3f, "ptGravity" to 0.25f, "ptAir" to 0.5f,
            "ptWindX" to 0.15f, "ptFlutter" to 1.2f, "ptFlutterFreq" to 2.2f, "ptSpin" to 1.6f, "ptSpinRand" to 1f, "ptCurl" to 0.5f, "ptCurlScale" to 0.8f, "ptLife" to 6f, "ptRate" to 12f, "ptSize" to 0.05f,
            "ptSoft" to 0f, "ptSizeRand" to 0.5f, "ptDof" to 0.5f, "ptSprite" to 4f, "ptSpriteTint" to 0f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.15f))
        add("Fluid Wave", "Signature", 2.0f, mapOf(
            "ptEmType" to 1f, "ptSizeX" to 1.4f, "ptSizeY" to 0.01f, "ptSizeZ" to 0.9f, "ptPosY" to -0.1f, "ptVel" to 0f, "ptLife" to 6f, "ptLifeRand" to 0f, "ptRate" to 600f, "ptSize" to 0.006f, "ptSoft" to 0.8f,
            "ptWaveAmp" to 0.25f, "ptWaveFreq" to 3.2f, "ptWaveSpeed" to 2.2f, "ptCurl" to 0.3f, "ptDof" to 0.4f, "ptFadeIn" to 0.2f, "ptFadeOut" to 0.2f),
            grad = intArrayOf(0xFFB8F3FF.toInt(), 0xFF22A6D9.toInt(), 0xFF0B4F8A.toInt(), 0xFF031B3D.toInt()))
        add("Golden Glisten", "Signature", 3.0f, mapOf(
            "ptEmType" to 1f, "ptSizeX" to 1.2f, "ptSizeY" to 0.3f, "ptSizeZ" to 1f, "ptPosY" to -1.1f, "ptMotion" to 2f, "ptDirX" to 0.25f, "ptDirY" to 1f, "ptVel" to 0.35f, "ptVelRand" to 0.8f, "ptSpread" to 0.6f,
            "ptAir" to 0.1f, "ptCurl" to 0.6f, "ptCurlScale" to 0.7f, "ptLife" to 5f, "ptRate" to 300f, "ptSize" to 0.01f, "ptSizeRand" to 0.9f, "ptSprite" to 1f, "ptSpin" to 1.5f, "ptSpinRand" to 1f,
            "ptTwinkle" to 0.8f, "ptTwinkleRate" to 2.5f, "ptDof" to 0.9f, "ptSoft" to 0.3f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.4f),
            grad = intArrayOf(0xFFFFF8E0.toInt(), 0xFFF2D49A.toInt(), 0xFFC9A063.toInt(), 0x00706040))
        add("Petal Vortex", "Signature", 2.8f, mapOf(
            "ptEmType" to 5f, "ptSizeX" to 0.9f, "ptSizeY" to 0.1f, "ptSizeZ" to 0.9f, "ptPosY" to -0.8f, "ptMotion" to 2f, "ptDirY" to 1f, "ptVel" to 0.55f, "ptSpread" to 0.1f, "ptSwirl" to 1.6f, "ptSwirlPull" to 0.25f,
            "ptFlutter" to 0.6f, "ptSpin" to 2f, "ptSpinRand" to 1f, "ptCurl" to 0.3f, "ptLife" to 5f, "ptRate" to 28f, "ptSize" to 0.04f, "ptSoft" to 0f, "ptSprite" to 4f, "ptSpriteTint" to 0f, "ptDof" to 0.3f,
            "ptFadeIn" to 0.1f, "ptFadeOut" to 0.2f))
        // Leaf Vortex: the reference look (white / copper leaves in a twisting column, falling light streaks, glints)
        add("Leaf Vortex", "Signature", 3.0f, mapOf(
            "ptEmType" to 10f, "ptSizeX" to 0.16f, "ptSizeY" to 0.75f, "ptSizeZ" to 0.16f, "ptPosY" to -0.05f, "ptMotion" to 2f, "ptDirY" to 1f, "ptVel" to 0.05f, "ptVelRand" to 0.6f, "ptSpread" to 0.4f,
            "ptSwirl" to 1.4f, "ptSwirlPull" to 0.15f, "ptCurl" to 0.55f, "ptCurlScale" to 0.9f, "ptCurlSpeed" to 0.4f, "ptTurb" to 0.2f, "ptFlutter" to 1.1f, "ptFlutterFreq" to 2.6f,
            "ptSpin" to 2.2f, "ptSpinRand" to 1f, "ptLife" to 4f, "ptLifeRand" to 0.3f, "ptRate" to 85f, "ptSize" to 0.036f, "ptSizeRand" to 0.6f, "ptSoft" to 0f, "ptDof" to 0.25f,
            "ptSprite" to 9f, "ptSpriteTint" to 0f, "ptFadeIn" to 0.12f, "ptFadeOut" to 0.15f, "ptMBlur" to 0.8f, "ptMBSamples" to 5f),
            groups = listOf(
                G(1, mapOf("ptEmType" to 1f, "ptSizeX" to 0.5f, "ptSizeY" to 0f, "ptSizeZ" to 0.25f, "ptPosY" to 1.25f, "ptMotion" to 2f, "ptDirY" to -1f, "ptVel" to 0.7f, "ptVelRand" to 0.4f, "ptSpread" to 0f,
                      "ptLife" to 2.6f, "ptRate" to 95f, "ptTrail" to 10f, "ptTrailLen" to 0.9f, "ptSize" to 0.0028f, "ptSoft" to 0.25f, "ptOpacity" to 0.45f, "ptFadeIn" to 0.15f, "ptFadeOut" to 0.4f),
                  grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFE8E8F0.toInt())),
                G(2, mapOf("ptEmType" to 10f, "ptSizeX" to 0.16f, "ptSizeY" to 0.75f, "ptSizeZ" to 0.16f, "ptPosY" to -0.05f, "ptVel" to 0f, "ptLife" to 1.1f, "ptRate" to 7f, "ptSize" to 0.11f, "ptSizeRand" to 0.7f,
                      "ptSprite" to 2f, "ptSpriteTint" to 1f, "ptTwinkle" to 0.6f, "ptTwinkleRate" to 4f, "ptSoft" to 0.3f, "ptSwirl" to 1.4f, "ptSpin" to 0.5f, "ptFadeIn" to 0.3f, "ptFadeOut" to 0.4f),
                  grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFE2C4.toInt(), 0x00FFB070))))
        // Volumetric / 3D model / motion blur
        add("Cumulus Clouds", "Volumetric", 5.0f, mapOf(
            "ptEmType" to 2f, "ptSizeX" to 0.55f, "ptSizeY" to 0.28f, "ptSizeZ" to 0.3f, "ptPosY" to 0.2f, "ptVel" to 0.02f, "ptWindX" to 0.05f, "ptCurl" to 0.15f, "ptCurlScale" to 0.5f,
            "ptLife" to 10f, "ptRate" to 14f, "ptSize" to 0.22f, "ptSizeRand" to 0.5f, "ptSoft" to 0.4f, "ptOpacity" to 0.55f, "ptSprite" to 8f, "ptSpriteTint" to 1f, "ptSpin" to 0.05f, "ptSpinRand" to 1f,
            "ptFadeIn" to 0.25f, "ptFadeOut" to 0.25f, "ptVolume" to 0.9f, "ptVolLight" to 50f),
            a = 0xFFFFFFFF.toInt(), b = 0xFFDCE8FF.toInt())
        add("Storm Clouds", "Volumetric", 5.0f, mapOf(
            "ptEmType" to 2f, "ptSizeX" to 0.9f, "ptSizeY" to 0.18f, "ptSizeZ" to 0.4f, "ptPosY" to 0.55f, "ptVel" to 0.02f, "ptWindX" to 0.08f, "ptCurl" to 0.25f, "ptCurlScale" to 0.6f,
            "ptLife" to 12f, "ptRate" to 18f, "ptSize" to 0.3f, "ptSizeRand" to 0.5f, "ptSoft" to 0.4f, "ptOpacity" to 0.6f, "ptSprite" to 8f, "ptSpriteTint" to 1f, "ptSpinRand" to 1f,
            "ptFadeIn" to 0.25f, "ptFadeOut" to 0.25f, "ptVolume" to 1f, "ptVolLight" to -60f),
            a = 0xFF8A93A6.toInt(), b = 0xFF2E3446.toInt(),
            groups = listOf(G(1, mapOf("ptEmType" to 1f, "ptSizeX" to 0.7f, "ptSizeY" to 0.15f, "ptSizeZ" to 0.2f, "ptPosY" to 0.55f, "ptRate" to 2f, "ptLife" to 1f, "ptSize" to 0.5f, "ptSprite" to 5f, "ptSoft" to 1f,
                           "ptTwinkle" to 1f, "ptTwinkleRate" to 6f, "ptOpacity" to 0.7f, "ptVel" to 0f), grad = intArrayOf(0xFFEAF2FF.toInt(), 0x00A8C4FF))))
        add("Ground Fog", "Volumetric", 6.0f, mapOf(
            "ptEmType" to 1f, "ptSizeX" to 1.4f, "ptSizeY" to 0.08f, "ptSizeZ" to 0.8f, "ptPosY" to -0.75f, "ptWindX" to 0.08f, "ptCurl" to 0.3f, "ptCurlScale" to 0.5f, "ptLife" to 9f, "ptRate" to 14f,
            "ptSize" to 0.3f, "ptSizeEnd" to 1.4f, "ptSizeRand" to 0.5f, "ptSoft" to 0.6f, "ptOpacity" to 0.35f, "ptSprite" to 8f, "ptSpriteTint" to 1f, "ptSpinRand" to 1f,
            "ptFadeIn" to 0.3f, "ptFadeOut" to 0.3f, "ptVolume" to 0.5f, "ptVolLight" to 80f),
            a = 0xFFD7E3F0.toInt(), b = 0xFF9FB4CC.toInt())
        add("Nebula", "Volumetric", 6.0f, mapOf(
            "ptEmType" to 2f, "ptSizeX" to 0.8f, "ptSizeY" to 0.5f, "ptSizeZ" to 0.5f, "ptVel" to 0.01f, "ptCurl" to 0.4f, "ptCurlScale" to 0.6f, "ptLife" to 12f, "ptRate" to 12f, "ptSize" to 0.4f,
            "ptSizeRand" to 0.6f, "ptSoft" to 1f, "ptOpacity" to 0.35f, "ptSprite" to 8f, "ptSpriteTint" to 1f, "ptSpin" to 0.03f, "ptSpinRand" to 1f, "ptFadeIn" to 0.3f, "ptFadeOut" to 0.3f, "ptVolume" to 0.6f),
            grad = intArrayOf(0xFF7A3CFF.toInt(), 0xFFFF4FA3.toInt(), 0xFF2BC4FF.toInt(), 0x003060FF),
            groups = listOf(G(1, mapOf("ptEmType" to 2f, "ptSizeX" to 1f, "ptSizeY" to 0.7f, "ptSizeZ" to 0.7f, "ptVel" to 0f, "ptRate" to 40f, "ptLife" to 6f, "ptSize" to 0.012f, "ptSoft" to 0.4f, "ptTwinkle" to 0.9f,
                           "ptTwinkleRate" to 1.5f, "ptFadeIn" to 0.2f, "ptFadeOut" to 0.2f), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFCFE0FF.toInt()))))
        add("Model Aura", "3D Model", 3.0f, mapOf(
            "ptEmType" to 17f, "ptMotion" to 6f, "ptVel" to 0.1f, "ptVelRand" to 0.6f, "ptRate" to 500f, "ptLife" to 2.2f, "ptSize" to 0.006f, "ptSoft" to 0.8f, "ptCurl" to 0.8f, "ptWindY" to 0.2f,
            "ptTwinkle" to 0.5f, "ptTwinkleRate" to 3f, "ptMBlur" to 1f, "ptMBSamples" to 5f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.5f),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD36B.toInt(), 0xFFFF6A1F.toInt(), 0x00C81E00),
            groups = listOf(G(1, mapOf("ptEmType" to 17f, "ptMotion" to 6f, "ptVel" to 0.05f, "ptRate" to 30f, "ptLife" to 3f, "ptSize" to 0.12f, "ptOpacity" to 0.18f, "ptSprite" to 8f, "ptSpriteTint" to 1f, "ptSoft" to 0.6f,
                           "ptVolume" to 0.6f, "ptFadeIn" to 0.3f, "ptFadeOut" to 0.4f), grad = intArrayOf(0xFFB8E8FF.toInt(), 0x003070FF))))
        add("Speed Streaks", "Motion Blur", 1.2f, mapOf(
            "ptEmType" to 1f, "ptSizeX" to 0.9f, "ptSizeY" to 0.5f, "ptSizeZ" to 0.6f, "ptMotion" to 2f, "ptDirX" to -1f, "ptVel" to 2.2f, "ptVelRand" to 0.5f, "ptSpread" to 0.02f, "ptLife" to 1.6f, "ptRate" to 140f,
            "ptSize" to 0.01f, "ptSoft" to 0.5f, "ptMBlur" to 3f, "ptMBSamples" to 10f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.3f), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFF7FD9FF.toInt(), 0x002A8CFF))
        add("Falling Maple Leaf", "Nature", 3.5f, mapOf(
            "ptEmType" to 1f, "ptSizeX" to 0.9f, "ptSizeY" to 0.05f, "ptSizeZ" to 0.6f, "ptPosY" to 1.3f, "ptMotion" to 2f, "ptDirY" to -1f, "ptVel" to 0.2f, "ptVelRand" to 0.3f, "ptSpread" to 0.2f,
            "ptGravity" to 0.25f, "ptAir" to 0.5f, "ptWindX" to 0.12f, "ptFlutter" to 1.4f, "ptFlutterFreq" to 1.6f, "ptCurl" to 0.35f, "ptCurlScale" to 0.8f, "ptSpin" to 1.1f, "ptSpinRand" to 1f,
            "ptLife" to 7f, "ptLifeRand" to 0.2f, "ptRate" to 4f, "ptSize" to 0.09f, "ptSizeRand" to 0.35f, "ptSoft" to 0f, "ptDof" to 0.3f, "ptSprite" to 10f, "ptSpriteTint" to 0f,
            "ptBump" to 1.3f, "ptTumble" to 0.8f, "ptVolLight" to 40f, "ptFadeIn" to 0.05f, "ptFadeOut" to 0.12f, "ptMBlur" to 0.4f, "ptMBSamples" to 4f))
        // More looks
        add("Snow", "Nature", 3.0f, mapOf("ptEmType" to 1f, "ptSizeX" to 1.2f, "ptSizeY" to 0.05f, "ptSizeZ" to 0.8f, "ptPosY" to 1.4f, "ptMotion" to 2f, "ptDirY" to -1f, "ptVel" to 0.25f, "ptSpread" to 0.2f, "ptRate" to 80f,
                                    "ptLife" to 8f, "ptFlutter" to 0.5f, "ptFlutterFreq" to 1.4f, "ptSoft" to 0.8f, "ptSize" to 0.014f, "ptDof" to 0.6f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.15f),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFE6F2FF.toInt()))
        add("Fireflies", "Nature", 3.0f, mapOf("ptEmType" to 1f, "ptSizeX" to 1.2f, "ptSizeY" to 0.7f, "ptSizeZ" to 0.8f, "ptVel" to 0.05f, "ptRate" to 18f, "ptLife" to 6f, "ptCurl" to 1.2f, "ptCurlScale" to 0.6f,
                                         "ptTwinkle" to 0.9f, "ptTwinkleRate" to 0.8f, "ptSize" to 0.014f, "ptSoft" to 1f, "ptDof" to 0.5f, "ptFadeIn" to 0.2f, "ptFadeOut" to 0.3f),
            grad = intArrayOf(0xFFF4FF8A.toInt(), 0xFFB8F23A.toInt(), 0x0070B000))
        add("Embers", "Fire", 2.2f, mapOf("ptEmType" to 4f, "ptSizeX" to 0.6f, "ptSizeZ" to 0.4f, "ptPosY" to -1.1f, "ptMotion" to 2f, "ptDirY" to 1f, "ptVel" to 0.4f, "ptVelRand" to 0.7f, "ptSpread" to 0.5f, "ptWindY" to 0.3f,
                                    "ptTurb" to 1f, "ptRate" to 90f, "ptLife" to 4f, "ptSize" to 0.008f, "ptSoft" to 0.5f, "ptTrail" to 2f, "ptTrailLen" to 0.15f, "ptSizeEnd" to 0.2f, "ptFadeIn" to 0.05f, "ptFadeOut" to 0.5f),
            grad = PtGradient.presets[1].second)
        add("Sparks Fountain", "Fire", 1.4f, mapOf("ptEmType" to 0f, "ptMotion" to 2f, "ptDirY" to 1f, "ptVel" to 1.6f, "ptVelRand" to 0.4f, "ptSpread" to 0.25f, "ptGravity" to 1.4f, "ptAir" to 0.1f, "ptRate" to 120f,
                                              "ptLife" to 2f, "ptPosY" to -1f, "ptSize" to 0.008f, "ptSoft" to 0.3f, "ptTrail" to 3f, "ptTrailLen" to 0.12f, "ptFloorOn" to 1f, "ptFloorY" to -1.05f, "ptBounce" to 0.4f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.3f),
            grad = PtGradient.presets[3].second)
        add("Confetti", "Party", 0.9f, mapOf("ptEmType" to 0f, "ptBehavior" to 1f, "ptMotion" to 0f, "ptVel" to 1.6f, "ptVelRand" to 0.6f, "ptAir" to 0.5f, "ptGravity" to 1.2f, "ptRate" to 100f, "ptLife" to 3f, "ptPosY" to -0.2f,
                                       "ptSpin" to 4f, "ptSpinRand" to 1f, "ptSprite" to 1f, "ptSize" to 0.014f, "ptSizeRand" to 0.6f, "ptGrBy" to 1f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.2f),
            grad = PtGradient.presets[19].second)
        add("Magic Dust", "Magic", 2.4f, mapOf("ptEmType" to 2f, "ptSizeX" to 0.5f, "ptSizeY" to 0.5f, "ptSizeZ" to 0.4f, "ptVel" to 0.1f, "ptRate" to 80f, "ptLife" to 4f, "ptCurl" to 1f, "ptSprite" to 2f, "ptSize" to 0.02f,
                                         "ptTwinkle" to 0.8f, "ptTwinkleRate" to 3f, "ptSpin" to 1f, "ptSpinRand" to 1f, "ptFadeIn" to 0.2f, "ptFadeOut" to 0.3f),
            grad = PtGradient.presets[9].second)
        add("Starfield", "Space", 2.0f, mapOf("ptEmType" to 1f, "ptSizeX" to 2f, "ptSizeY" to 1.4f, "ptSizeZ" to 4f, "ptMotion" to 2f, "ptDirX" to 0f, "ptDirY" to 0f, "ptDirZ" to 1f, "ptVel" to 1.2f, "ptSpread" to 0f, "ptRate" to 200f,
                                        "ptLife" to 6f, "ptSize" to 0.006f, "ptSoft" to 0.2f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.1f), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFBFD4FF.toInt()))
        add("Galaxy Spiral", "Space", 3.0f, mapOf("ptEmType" to 4f, "ptSizeX" to 1.1f, "ptSizeZ" to 1.1f, "ptVel" to 0f, "ptSwirl" to 0.8f, "ptRate" to 120f, "ptLife" to 8f, "ptSize" to 0.006f, "ptSoft" to 0.5f,
                                            "ptDof" to 0.3f, "ptFadeIn" to 0.2f, "ptFadeOut" to 0.3f), grad = PtGradient.presets[13].second)
        add("Bubbles", "Nature", 2.5f, mapOf("ptEmType" to 1f, "ptSizeX" to 1f, "ptSizeY" to 0.05f, "ptSizeZ" to 0.6f, "ptPosY" to -1.3f, "ptMotion" to 2f, "ptDirY" to 1f, "ptVel" to 0.35f, "ptSpread" to 0.2f, "ptRate" to 14f,
                                       "ptLife" to 6f, "ptWaveFreq" to 2f, "ptFlutter" to 0.5f, "ptSprite" to 5f, "ptSize" to 0.045f, "ptSizeRand" to 0.7f, "ptOpacity" to 0.6f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.2f),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFA8E6FF.toInt()))
        add("Plasma Curl", "Magic", 2.0f, mapOf("ptEmType" to 2f, "ptSizeX" to 0.3f, "ptSizeY" to 0.3f, "ptSizeZ" to 0.3f, "ptVel" to 0.2f, "ptRate" to 70f, "ptLife" to 3f, "ptCurl" to 2.2f, "ptCurlScale" to 1.2f,
                                          "ptTrail" to 4f, "ptTrailLen" to 0.3f, "ptSize" to 0.01f, "ptSoft" to 0.7f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.3f), grad = PtGradient.presets[12].second)
        add("Smoke Wisps", "Fire", 2.5f, mapOf("ptEmType" to 0f, "ptPosY" to -0.8f, "ptMotion" to 2f, "ptDirY" to 1f, "ptVel" to 0.3f, "ptSpread" to 0.3f, "ptRate" to 18f, "ptLife" to 4f, "ptCurl" to 0.8f, "ptSoft" to 1f,
                                         "ptSize" to 0.05f, "ptSizeStart" to 0.5f, "ptSizeEnd" to 3f, "ptOpacity" to 0.3f, "ptFadeIn" to 0.2f, "ptFadeOut" to 0.5f), grad = PtGradient.presets[24].second)
        add("Energy Orb", "Magic", 2.0f, mapOf("ptEmType" to 12f, "ptSizeX" to 0.5f, "ptSizeY" to 0.5f, "ptSizeZ" to 0.5f, "ptVel" to 0f, "ptSwirl" to 2.5f, "ptCurl" to 0.8f, "ptRate" to 90f, "ptLife" to 3f, "ptTrail" to 3f,
                                         "ptTrailLen" to 0.25f, "ptSize" to 0.008f, "ptSoft" to 0.6f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.3f), grad = PtGradient.presets[12].second)
        add("Rain", "Nature", 1.5f, mapOf("ptEmType" to 1f, "ptSizeX" to 1.3f, "ptSizeY" to 0.05f, "ptSizeZ" to 0.8f, "ptPosY" to 1.5f, "ptMotion" to 2f, "ptDirX" to 0.1f, "ptDirY" to -1f, "ptVel" to 2.2f, "ptSpread" to 0f,
                                    "ptRate" to 120f, "ptLife" to 1.4f, "ptTrail" to 3f, "ptTrailLen" to 0.06f, "ptSize" to 0.006f, "ptSoft" to 0.3f, "ptOpacity" to 0.7f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.1f),
            grad = intArrayOf(0xFFE6F4FF.toInt(), 0xFFA8D4FF.toInt()))

        // Fireworks
        add("Golden Willow", "Fireworks", 1.6f, mapOf("ptEmType" to 2f, "ptBehavior" to 1f, "ptSizeX" to 0.03f, "ptSizeY" to 0.03f, "ptSizeZ" to 0.03f, "ptPosY" to 0.35f, "ptRate" to 150f, "ptLife" to 3.4f, "ptLifeRand" to 0.2f,
                                               "ptVel" to 1.3f, "ptVelRand" to 0.4f, "ptAir" to 0.7f, "ptGravity" to 0.45f, "ptTrail" to 10f, "ptTrailLen" to 0.6f, "ptSize" to 0.007f, "ptSoft" to 0.5f, "ptSizeEnd" to 0.3f,
                                               "ptTwinkle" to 0.4f, "ptTwinkleRate" to 5f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.6f), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD36B.toInt(), 0xFFE0952B.toInt(), 0x00A05A10))
        add("Pink Peony", "Fireworks", 1.2f, mapOf("ptEmType" to 12f, "ptBehavior" to 1f, "ptSizeX" to 0.03f, "ptSizeY" to 0.03f, "ptSizeZ" to 0.03f, "ptPosY" to 0.3f, "ptRate" to 220f, "ptLife" to 2.4f, "ptVel" to 1.4f, "ptVelRand" to 0.25f,
                                            "ptAir" to 0.55f, "ptGravity" to 0.5f, "ptTrail" to 4f, "ptTrailLen" to 0.3f, "ptSize" to 0.009f, "ptSoft" to 0.6f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.45f),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFB3D9.toInt(), 0xFFFF4FA3.toInt(), 0x00B0206A))
        add("Chrysanthemum", "Fireworks", 1.3f, mapOf("ptEmType" to 2f, "ptBehavior" to 1f, "ptSizeX" to 0.03f, "ptSizeY" to 0.03f, "ptSizeZ" to 0.03f, "ptPosY" to 0.3f, "ptRate" to 120f, "ptLife" to 2.8f, "ptVel" to 1.5f, "ptVelRand" to 0.2f,
                                                "ptAir" to 0.6f, "ptGravity" to 0.5f, "ptTrail" to 6f, "ptTrailLen" to 0.45f, "ptSize" to 0.008f, "ptSoft" to 0.5f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.5f),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD36B.toInt(), 0xFFFF5A1F.toInt(), 0x00A01800),
            groups = listOf(G(1, mapOf("ptEmType" to 2f, "ptBehavior" to 1f, "ptSizeX" to 0.03f, "ptSizeY" to 0.03f, "ptSizeZ" to 0.03f, "ptPosY" to 0.3f, "ptRate" to 140f, "ptLife" to 2f, "ptVel" to 0.75f, "ptVelRand" to 0.3f,
                              "ptAir" to 0.6f, "ptGravity" to 0.4f, "ptSize" to 0.007f, "ptSoft" to 0.6f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.5f, "ptTwinkle" to 0.6f), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFA8E6FF.toInt(), 0x0038BDF8))))
        add("Ring Firework", "Fireworks", 1.2f, mapOf("ptEmType" to 15f, "ptBehavior" to 1f, "ptSizeX" to 0.04f, "ptSizeY" to 0.04f, "ptSizeZ" to 0.02f, "ptPosY" to 0.3f, "ptMotion" to 6f, "ptRate" to 140f, "ptLife" to 2.2f, "ptLifeRand" to 0f,
                                               "ptVel" to 1.5f, "ptVelRand" to 0.05f, "ptAir" to 0.55f, "ptGravity" to 0.3f, "ptTrail" to 5f, "ptTrailLen" to 0.3f, "ptSize" to 0.009f, "ptSoft" to 0.5f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.5f),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFF8FD8FF.toInt(), 0xFF3A7BFF.toInt(), 0x001A2A9A))
        add("Crackle Firework", "Fireworks", 1.8f, mapOf("ptEmType" to 2f, "ptBehavior" to 1f, "ptSizeX" to 0.03f, "ptSizeY" to 0.03f, "ptSizeZ" to 0.03f, "ptPosY" to 0.3f, "ptRate" to 100f, "ptLife" to 3f, "ptVel" to 1.4f, "ptVelRand" to 0.3f,
                                                  "ptAir" to 0.6f, "ptGravity" to 0.5f, "ptTrail" to 3f, "ptTrailLen" to 0.3f, "ptSize" to 0.008f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.5f),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD36B.toInt(), 0x00FF6A00),
            groups = listOf(G(1, mapOf("ptEmType" to 2f, "ptBehavior" to 1f, "ptSizeX" to 0.03f, "ptSizeY" to 0.03f, "ptSizeZ" to 0.03f, "ptPosY" to 0.3f, "ptRate" to 130f, "ptLife" to 3f, "ptVel" to 1.2f, "ptVelRand" to 0.5f, "ptAir" to 0.6f, "ptGravity" to 0.55f,
                              "ptSize" to 0.005f, "ptSoft" to 0f, "ptTwinkle" to 1f, "ptTwinkleRate" to 14f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.4f), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0x0000FFFF))))
        add("Rainbow Firework", "Fireworks", 1.2f, mapOf("ptEmType" to 12f, "ptBehavior" to 1f, "ptSizeX" to 0.03f, "ptSizeY" to 0.03f, "ptSizeZ" to 0.03f, "ptPosY" to 0.3f, "ptRate" to 230f, "ptLife" to 2.4f, "ptVel" to 1.4f, "ptVelRand" to 0.2f,
                                                   "ptAir" to 0.55f, "ptGravity" to 0.5f, "ptTrail" to 3f, "ptTrailLen" to 0.25f, "ptSize" to 0.009f, "ptGrBy" to 1f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.45f), grad = PtGradient.presets[19].second)
        add("Palm Firework", "Fireworks", 1.8f, mapOf("ptEmType" to 0f, "ptBehavior" to 1f, "ptPosY" to 0.2f, "ptRate" to 40f, "ptLife" to 3f, "ptVel" to 1.3f, "ptVelRand" to 0.25f, "ptAir" to 0.5f, "ptGravity" to 0.8f, "ptTrail" to 10f, "ptTrailLen" to 0.8f,
                                              "ptSize" to 0.016f, "ptSoft" to 0.5f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.5f), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFC857.toInt(), 0xFFE07A10.toInt(), 0x00802800))
        add("Sparkler", "Fireworks", 1.0f, mapOf("ptEmType" to 0f, "ptPosY" to -0.4f, "ptMotion" to 0f, "ptVel" to 1.2f, "ptVelRand" to 0.6f, "ptRate" to 300f, "ptLife" to 0.6f, "ptGravity" to 1f, "ptTrail" to 2f, "ptTrailLen" to 0.08f, "ptSize" to 0.006f,
                                         "ptSoft" to 0.3f, "ptTwinkle" to 0.8f, "ptTwinkleRate" to 12f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.4f), grad = PtGradient.presets[3].second)
        // Pink / rose
        val petalFall = mapOf("ptEmType" to 6f, "ptSizeX" to 0.5f, "ptSizeY" to 0.02f, "ptSizeZ" to 0.1f, "ptPosY" to 1.3f, "ptMotion" to 2f, "ptDirX" to 0.15f, "ptDirY" to -1f, "ptVel" to 0.5f, "ptVelRand" to 0.4f, "ptSpread" to 0.25f,
                              "ptGravity" to 0.7f, "ptAir" to 0.3f, "ptFlutter" to 1.3f, "ptFlutterFreq" to 2.4f, "ptSpin" to 1.5f, "ptSpinRand" to 1f, "ptCurl" to 0.6f, "ptCurlScale" to 0.8f, "ptLife" to 5f, "ptLifeRand" to 0.3f,
                              "ptRate" to 22f, "ptSize" to 0.05f, "ptSizeRand" to 0.6f, "ptSoft" to 0f, "ptSprite" to 7f, "ptSpriteTint" to 0f, "ptDof" to 0.4f, "ptFadeIn" to 0.08f, "ptFadeOut" to 0.15f)
        val glitterFall = mapOf("ptEmType" to 6f, "ptSizeX" to 0.5f, "ptSizeY" to 0.02f, "ptSizeZ" to 0.1f, "ptPosY" to 1.3f, "ptMotion" to 2f, "ptDirX" to 0.15f, "ptDirY" to -1f, "ptVel" to 0.55f, "ptVelRand" to 0.5f, "ptSpread" to 0.45f,
                                "ptGravity" to 0.8f, "ptAir" to 0.2f, "ptCurl" to 0.6f, "ptLife" to 4f, "ptRate" to 220f, "ptSize" to 0.009f, "ptSizeRand" to 0.9f, "ptSprite" to 2f, "ptSpriteTint" to 1f, "ptSpin" to 2f, "ptSpinRand" to 1f,
                                "ptTwinkle" to 0.9f, "ptTwinkleRate" to 4f, "ptDof" to 0.5f, "ptSoft" to 0.4f, "ptFadeIn" to 0.08f, "ptFadeOut" to 0.25f)
        val bokehFall = mapOf("ptEmType" to 6f, "ptSizeX" to 0.5f, "ptSizeY" to 0.02f, "ptSizeZ" to 0.2f, "ptPosY" to 1.3f, "ptMotion" to 2f, "ptDirY" to -1f, "ptVel" to 0.45f, "ptSpread" to 0.35f, "ptGravity" to 0.7f, "ptLife" to 5f, "ptRate" to 25f,
                              "ptSize" to 0.03f, "ptSizeRand" to 0.8f, "ptSprite" to 5f, "ptSpriteTint" to 1f, "ptOpacity" to 0.35f, "ptDof" to 0.7f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.3f)
        add("Pink Rose Waterfall", "Pink", 3.2f, petalFall, groups = listOf(G(1, glitterFall, grad = pinkG), G(2, bokehFall, grad = intArrayOf(0xFFFFE6F2.toInt(), 0xFFFF9FCC.toInt(), 0x00FF5FA8))))
        add("Red Rose Waterfall", "Pink", 3.2f, merge(petalFall, mapOf("ptSprite" to 4f)), groups = listOf(G(1, glitterFall, grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD27A.toInt(), 0xFFFF4A5A.toInt(), 0x00A0102A))))
        add("Pink Petal Rain", "Pink", 3.0f, merge(petalFall, mapOf("ptEmType" to 1f, "ptSizeX" to 1f, "ptSizeZ" to 0.8f, "ptRate" to 14f, "ptDirX" to 0f, "ptVel" to 0.2f, "ptGravity" to 0.3f)),
            groups = listOf(G(1, merge(glitterFall, mapOf("ptEmType" to 1f, "ptSizeX" to 1f, "ptSizeZ" to 0.8f, "ptRate" to 90f, "ptDirX" to 0f, "ptVel" to 0.2f, "ptGravity" to 0.3f)), grad = pinkG)))
        add("Pink Glisten", "Pink", 3.0f, mapOf("ptEmType" to 1f, "ptSizeX" to 1.2f, "ptSizeY" to 0.3f, "ptSizeZ" to 1f, "ptPosY" to -1.1f, "ptMotion" to 2f, "ptDirX" to 0.25f, "ptDirY" to 1f, "ptVel" to 0.35f, "ptVelRand" to 0.8f, "ptSpread" to 0.6f, "ptAir" to 0.1f,
                                          "ptCurl" to 0.6f, "ptCurlScale" to 0.7f, "ptLife" to 5f, "ptRate" to 300f, "ptSize" to 0.01f, "ptSizeRand" to 0.9f, "ptSprite" to 2f, "ptSpin" to 1.5f, "ptSpinRand" to 1f, "ptTwinkle" to 0.8f, "ptTwinkleRate" to 2.5f,
                                          "ptDof" to 0.9f, "ptSoft" to 0.3f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.4f), grad = pinkG)
        // Shockwaves
        val ring = mapOf("ptEmType" to 15f, "ptBehavior" to 1f, "ptSizeX" to 0.05f, "ptSizeY" to 0.05f, "ptSizeZ" to 0.02f, "ptMotion" to 6f, "ptRate" to 250f, "ptLife" to 1.2f, "ptLifeRand" to 0f, "ptVel" to 1.6f, "ptVelRand" to 0.06f,
                         "ptAir" to 0.6f, "ptSize" to 0.01f, "ptSoft" to 0.5f, "ptTrail" to 3f, "ptTrailLen" to 0.1f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.6f)
        add("Shockwave Ring", "Shockwave", 0.7f, ring, grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFF8FD8FF.toInt(), 0x000070FF))
        add("Double Shockwave", "Shockwave", 0.8f, ring, grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFF8FD8FF.toInt(), 0x000070FF),
            groups = listOf(G(1, merge(ring, mapOf("ptVel" to 1.0f, "ptSize" to 0.014f, "ptRate" to 180f, "ptLife" to 1.4f)), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFB347.toInt(), 0x00FF4A00))))
        add("Shockwave Sphere", "Shockwave", 0.7f, merge(ring, mapOf("ptEmType" to 12f, "ptSizeZ" to 0.05f, "ptRate" to 500f)), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFB8F3FF.toInt(), 0x002288FF))
        add("Ground Slam", "Shockwave", 0.8f, merge(ring, mapOf("ptEmType" to 5f, "ptSizeX" to 0.05f, "ptSizeZ" to 0.05f, "ptSizeY" to 0.01f, "ptPosY" to -0.7f, "ptVel" to 1.8f, "ptRate" to 260f)),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD9A0.toInt(), 0x00FF9A30),
            groups = listOf(G(1, mapOf("ptEmType" to 5f, "ptBehavior" to 1f, "ptSizeX" to 0.3f, "ptSizeZ" to 0.3f, "ptSizeY" to 0.01f, "ptPosY" to -0.7f, "ptMotion" to 2f, "ptDirY" to 1f, "ptVel" to 0.5f, "ptSpread" to 0.5f, "ptGravity" to 0.5f,
                              "ptRate" to 40f, "ptLife" to 1.6f, "ptSize" to 0.04f, "ptSoft" to 1f, "ptSizeEnd" to 2.5f, "ptOpacity" to 0.5f, "ptFadeIn" to 0.05f, "ptFadeOut" to 0.6f), grad = PtGradient.presets[24].second)))
        add("Ripple Field", "Shockwave", 1.4f, mapOf("ptEmType" to 16f, "ptSizeX" to 0.9f, "ptSizeY" to 0.9f, "ptVel" to 0f, "ptRate" to 800f, "ptLife" to 4f, "ptLifeRand" to 0f, "ptSize" to 0.006f, "ptSoft" to 0.4f, "ptFadeIn" to 0.3f, "ptFadeOut" to 0.3f,
                                               "ptShockAmp" to 0.25f, "ptShockSpeed" to 0.8f, "ptShockWidth" to 0.1f, "ptShockPeriod" to 2f, "ptShockGlow" to 2.5f), grad = PtGradient.presets[11].second)
        add("Sonic Boom", "Shockwave", 0.6f, merge(ring, mapOf("ptSizeX" to 0.02f, "ptSizeY" to 0.02f, "ptVel" to 2.6f, "ptAir" to 0.3f, "ptTrail" to 8f, "ptTrailLen" to 0.15f, "ptRate" to 300f, "ptLife" to 1f)),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFA8E6FF.toInt(), 0x0038BDF8),
            groups = listOf(G(1, mapOf("ptEmType" to 12f, "ptBehavior" to 1f, "ptSizeX" to 0.05f, "ptSizeY" to 0.05f, "ptSizeZ" to 0.05f, "ptMotion" to 6f, "ptVel" to 1.2f, "ptAir" to 0.6f, "ptRate" to 40f, "ptLife" to 1.2f, "ptSize" to 0.05f, "ptSoft" to 1f,
                              "ptOpacity" to 0.25f, "ptFadeIn" to 0.05f, "ptFadeOut" to 0.6f), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFA8E6FF.toInt(), 0x00000000))))
        add("Pink Shockwave", "Shockwave", 0.8f, merge(ring, mapOf("ptSprite" to 2f, "ptSpriteTint" to 1f, "ptSize" to 0.014f, "ptSpin" to 3f, "ptSpinRand" to 1f)), grad = pinkG,
            groups = listOf(G(1, merge(glitterFall, mapOf("ptEmType" to 12f, "ptBehavior" to 1f, "ptSizeX" to 0.05f, "ptSizeY" to 0.05f, "ptSizeZ" to 0.05f, "ptPosY" to 0f, "ptMotion" to 6f, "ptDirX" to 0f, "ptDirY" to 0f, "ptVel" to 1.1f, "ptAir" to 0.5f, "ptGravity" to 0.2f, "ptRate" to 150f, "ptLife" to 1.8f)), grad = pinkG)))
        add("Fire Blast", "Shockwave", 0.9f, mapOf("ptEmType" to 12f, "ptBehavior" to 1f, "ptSizeX" to 0.05f, "ptSizeY" to 0.05f, "ptSizeZ" to 0.05f, "ptMotion" to 6f, "ptVel" to 1.6f, "ptVelRand" to 0.4f, "ptAir" to 0.7f, "ptRate" to 120f, "ptLife" to 1.6f, "ptTurb" to 1f,
                                             "ptSize" to 0.03f, "ptSoft" to 1f, "ptSizeEnd" to 2f, "ptOpacity" to 0.7f, "ptFadeIn" to 0.03f, "ptFadeOut" to 0.6f), grad = PtGradient.presets[0].second,
            groups = listOf(G(1, mapOf("ptEmType" to 0f, "ptBehavior" to 1f, "ptMotion" to 0f, "ptVel" to 1.8f, "ptVelRand" to 0.5f, "ptAir" to 0.3f, "ptGravity" to 0.8f, "ptRate" to 140f, "ptLife" to 1.6f, "ptTrail" to 3f, "ptTrailLen" to 0.1f, "ptSize" to 0.007f,
                              "ptSoft" to 0.3f, "ptFadeIn" to 0.02f, "ptFadeOut" to 0.4f), grad = PtGradient.presets[3].second)))
        add("Speed Lines", "Shockwave", 0.8f, merge(ring, mapOf("ptSizeX" to 0.15f, "ptSizeY" to 0.15f, "ptVel" to 2.2f, "ptAir" to 0.1f, "ptTrail" to 10f, "ptTrailLen" to 0.2f, "ptRate" to 120f, "ptSize" to 0.005f, "ptSoft" to 0f)), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0x00FFFFFF))
        add("Energy Ripples", "Shockwave", 1.5f, mapOf("ptEmType" to 3f, "ptGridN" to 12f, "ptSizeX" to 0.9f, "ptSizeY" to 0.9f, "ptSizeZ" to 0.01f, "ptVel" to 0f, "ptRate" to 600f, "ptLife" to 3f, "ptLifeRand" to 0f, "ptSize" to 0.01f, "ptSoft" to 0.5f,
                                                 "ptFadeIn" to 0.3f, "ptFadeOut" to 0.3f, "ptShockAmp" to 0.3f, "ptShockSpeed" to 1f, "ptShockWidth" to 0.15f, "ptShockPeriod" to 2.5f, "ptShockGlow" to 3f), grad = PtGradient.presets[12].second)
        // Path presets: the curve is stored in the preset (ptPath* keys), so it can be redrawn in the designer
        val wave = (0 until 14).map { i -> val t = i.toFloat() / 13f; V3(-1.0f + 2.0f * t, 0.35f * sin(t * 6.2832f * 1.5f), 0.45f * cos(t * 6.2832f * 1.2f)) }
        val loop = (0 until 16).map { i -> val t = i.toFloat() / 16f * 6.2832f; V3(0.85f * sin(t), 0.32f * sin(2f * t) + 0.1f, 0.5f * cos(t)) }
        val loopP = PtPath.params(loop, closed = true)
        add("Golden Trail", "Path", 3.0f, merge(loopP, mapOf(
            "ptEmType" to 18f, "ptPathMode" to 1f, "ptPathSpeed" to 0.22f, "ptSizeX" to 0.012f, "ptVel" to 0.04f, "ptSpread" to 1f, "ptCurl" to 0.35f, "ptCurlScale" to 1.2f,
            "ptLife" to 2.4f, "ptLifeRand" to 0.2f, "ptRate" to 420f, "ptSize" to 0.008f, "ptSizeRand" to 0.5f, "ptSizeEnd" to 0.3f, "ptSoft" to 0.7f, "ptTwinkle" to 0.4f, "ptTwinkleRate" to 5f,
            "ptFadeIn" to 0.01f, "ptFadeOut" to 0.65f, "ptGlow" to 1.2f, "ptGlowSize" to 3f)),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD36B.toInt(), 0xFFE0A030.toInt(), 0x00A06010),
            groups = listOf(G(1, merge(loopP, mapOf(
                "ptEmType" to 18f, "ptPathMode" to 1f, "ptPathSpeed" to 0.22f, "ptSizeX" to 0.004f, "ptVel" to 0f, "ptLife" to 0.12f, "ptRate" to 120f, "ptSize" to 0.05f, "ptSprite" to 2f, "ptSpriteTint" to 1f,
                "ptSoft" to 0.3f, "ptFadeIn" to 0.2f, "ptFadeOut" to 0.5f, "ptGlow" to 2f, "ptGlowSize" to 3f)), grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFE9B0.toInt()))))
        add("Starlight River", "Path", 3.5f, merge(PtPath.params(wave), mapOf(
            "ptEmType" to 18f, "ptPathMode" to 0f, "ptPathFlow" to 0.22f, "ptSizeX" to 0.05f, "ptVel" to 0f, "ptCurl" to 0.5f, "ptCurlScale" to 1f, "ptLife" to 4.5f, "ptLifeRand" to 0.25f, "ptRate" to 150f,
            "ptSize" to 0.009f, "ptSizeRand" to 0.7f, "ptSoft" to 0.6f, "ptTwinkle" to 0.5f, "ptTwinkleRate" to 2f, "ptDof" to 0.3f, "ptFadeIn" to 0.15f, "ptFadeOut" to 0.25f,
            "ptMBlur" to 0.6f, "ptMBSamples" to 4f, "ptGlow" to 1f, "ptGlowSize" to 3f)),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFF8FE8FF.toInt(), 0xFF3A8CFF.toInt(), 0x002040B0))
        add("Aurora Veil", "Volumetric", 6.0f, mapOf(
            "ptEmType" to 1f, "ptSizeX" to 1.3f, "ptSizeY" to 0.25f, "ptSizeZ" to 0.3f, "ptPosY" to 0.5f, "ptVel" to 0.02f, "ptWindX" to 0.1f, "ptWaveAmp" to 0.18f, "ptWaveFreq" to 1.6f, "ptWaveSpeed" to 0.5f,
            "ptCurl" to 0.2f, "ptCurlScale" to 0.5f, "ptLife" to 10f, "ptRate" to 13f, "ptSize" to 0.28f, "ptSizeRand" to 0.5f, "ptSoft" to 1f, "ptOpacity" to 0.3f, "ptSprite" to 8f, "ptSpriteTint" to 1f,
            "ptSpinRand" to 1f, "ptFadeIn" to 0.3f, "ptFadeOut" to 0.3f, "ptVolume" to 0.3f, "ptGlow" to 0.5f, "ptGlowSize" to 2f),
            grad = intArrayOf(0x0000FFA0, 0xFF3DFFB0.toInt(), 0xFF2BD4E0.toInt(), 0xFF8A5CFF.toInt(), 0x005030C0))
        add("Glow Lanterns", "Glow", 4.0f, mapOf(
            "ptEmType" to 1f, "ptSizeX" to 1f, "ptSizeY" to 0.1f, "ptSizeZ" to 0.7f, "ptPosY" to -1.1f, "ptMotion" to 2f, "ptDirY" to 1f, "ptVel" to 0.18f, "ptVelRand" to 0.5f, "ptSpread" to 0.15f,
            "ptWindX" to 0.06f, "ptCurl" to 0.3f, "ptCurlScale" to 0.6f, "ptLife" to 9f, "ptRate" to 5f, "ptSize" to 0.03f, "ptSizeRand" to 0.4f, "ptSoft" to 0.5f, "ptDof" to 0.4f,
            "ptTwinkle" to 0.25f, "ptTwinkleRate" to 1.2f, "ptFadeIn" to 0.15f, "ptFadeOut" to 0.3f, "ptGlow" to 1.6f, "ptGlowSize" to 4f),
            grad = intArrayOf(0xFFFFF0C0.toInt(), 0xFFFFB347.toInt(), 0xFFFF6A1F.toInt(), 0x00C81E00))
        add("Neon Comets", "Glow", 2.0f, mapOf(
            "ptEmType" to 1f, "ptSizeX" to 0.9f, "ptSizeY" to 0.5f, "ptSizeZ" to 0.4f, "ptMotion" to 2f, "ptDirX" to 1f, "ptDirY" to -0.4f, "ptVel" to 1.2f, "ptVelRand" to 0.6f, "ptSpread" to 0.1f,
            "ptCurl" to 0.5f, "ptCurlScale" to 0.8f, "ptLife" to 2.2f, "ptRate" to 22f, "ptSize" to 0.012f, "ptSoft" to 0.7f, "ptMBlur" to 2f, "ptMBSamples" to 8f,
            "ptFadeIn" to 0.05f, "ptFadeOut" to 0.5f, "ptGlow" to 2f, "ptGlowSize" to 3f),
            grad = intArrayOf(0xFFFFFFFF.toInt(), 0xFF4FF3FF.toInt(), 0xFFB14DFF.toInt(), 0x00FF3DB5))
        // glow on the existing light-emitting looks
        for ((n, gl, gs) in listOf(Triple("Realistic Firework", 0.8f, 3.0f), Triple("Fireflies", 1.4f, 4.0f), Triple("Embers", 0.9f, 3.0f), Triple("Golden Glisten", 0.6f, 3.0f))) {
            out.firstOrNull { it.name == n }?.let { it.params["ptGlow"] = gl; it.params["ptGlowSize"] = gs }
        }
        out
    }
}
