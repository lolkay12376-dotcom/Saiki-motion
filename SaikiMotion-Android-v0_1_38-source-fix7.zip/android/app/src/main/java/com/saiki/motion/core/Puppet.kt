package com.saiki.motion.core

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

// Port of Sources/Model/Puppet.swift (model + math). Gl.drawMesh (GL) is not ported: the Vulkan scene renderer draws PuppetMath.mesh().

class PuppetPin(var id: Int, var rx: Float, var ry: Float)

/** One sway effect on a puppet: kind 0 = Wave (procedural), kind 1 = Physics (reacts to movement, gravity, wind). */
class SwayLayer {
    var kind = 0
    var link = -1                        // physics: index of a Wave sway that drives it (-1 = movement only)
    var style = 0                        // 0 Normal, 1 Hair, 2 Skirt, 3 Breeze (a preset of the values below)
    var chain = mutableListOf<Int>()
    var speed = 0.8f; var deg = 20f; var wave = 0.5f; var tip = 1.5f; var rand = 0f
    var seed = 1
    var weight = 1                       // physics: 0 light, 1 medium, 2 heavy
    var stiff = 45f; var damp = 40f; var grav = 0f; var wind = 0f
    var on = true
    // extra physics customisation + linking to another layer's Wave (e.g. back skirt follows front skirt)
    var followId = -1                    // layer id of the Wave to follow (-1 = none)
    var followIdx = 0                    // sway index of the Wave to follow
    var followAmt = 1f                   // multiplier on the followed wave's strength
    var delay = 0f                       // seconds the followed wave is late by
    var windFreq = 0.7f                  // gust speed (Hz)
    var limit = 1.2f                     // max stretch (x of layer size)
    var massMul = 1f                     // extra mass multiplier on top of Light/Medium/Heavy

    /** Applies a sway type: Normal, Hair (long, lagging, loose), Skirt (hem swings together, slow), Breeze (soft gusts). */
    fun applyStyle(st: Int) {
        style = st
        if (kind == 0) {
            val v = arrayOf(
                floatArrayOf(0.8f, 20f, 0.5f, 1.5f, 0f), floatArrayOf(0.7f, 14f, 0.9f, 2.2f, 0.25f),
                floatArrayOf(0.55f, 12f, 0.25f, 1.0f, 0.1f), floatArrayOf(0.35f, 8f, 1.6f, 1.8f, 0.5f))
            val a = v[max(0, min(3, st))]
            speed = a[0]; deg = a[1]; wave = a[2]; tip = a[3]; rand = a[4]
        } else {
            val v = arrayOf(
                floatArrayOf(45f, 40f, 0f, 0f, 20f), floatArrayOf(30f, 25f, 25f, 0f, 25f),
                floatArrayOf(55f, 45f, 10f, 0f, 18f), floatArrayOf(40f, 35f, 0f, 35f, 15f))
            val a = v[max(0, min(3, st))]
            stiff = a[0]; damp = a[1]; grav = a[2]; wind = a[3]; deg = a[4]
        }
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.putL("style", style.toLong()).putL("link", link.toLong())
        o.putL("kind", kind.toLong()); o.put("on", on); o.putF("speed", speed); o.putF("deg", deg)
        o.putF("wave", wave); o.putF("tip", tip); o.putF("rand", rand); o.putL("seed", seed.toLong())
        o.putL("weight", weight.toLong()); o.putF("stiff", stiff); o.putF("damp", damp)
        o.putF("grav", grav); o.putF("wind", wind)
        o.putL("followId", followId.toLong()).putL("followIdx", followIdx.toLong()).putF("followAmt", followAmt)
        o.putF("delay", delay); o.putF("windFreq", windFreq); o.putF("limit", limit); o.putF("massMul", massMul)
        val ca = JSONArray(); for (c in chain) ca.put(c.toLong())
        o.put("chain", ca)
        return o
    }
    companion object {
        fun fromJson(o: JSONObject): SwayLayer {
            val s = SwayLayer()
            s.style = clamp(o.optI("style", 0), 0, 3); s.link = o.optI("link", -1)
            s.kind = clamp(o.optI("kind", 0), 0, 1); s.on = o.optB("on", true)
            s.speed = o.optF("speed", 0.8f); s.deg = o.optF("deg", 20f); s.wave = o.optF("wave", 0.5f)
            s.tip = o.optF("tip", 1.5f); s.rand = o.optF("rand", 0f); s.seed = o.optI("seed", 1)
            s.weight = clamp(o.optI("weight", 1), 0, 2)
            s.stiff = o.optF("stiff", 45f); s.damp = o.optF("damp", 40f)
            s.grav = o.optF("grav", 0f); s.wind = o.optF("wind", 0f)
            s.followId = o.optI("followId", -1); s.followIdx = o.optI("followIdx", 0); s.followAmt = o.optF("followAmt", 1f)
            s.delay = o.optF("delay", 0f); s.windFreq = o.optF("windFreq", 0.7f)
            s.limit = o.optF("limit", 1.2f); s.massMul = o.optF("massMul", 1f)
            o.optJSONArray("chain")?.let { ca -> for (i in 0 until ca.length()) s.chain.add(ca.optI(i, 0)) }
            return s
        }
    }
}

/** A smooth bend made from several selected pins. mode 0 = Bend (pins rotate about the first pin, more toward the last),
 *  mode 1 = Close/Open (pins squash toward their centre line, like an eyelid), mode 2 = Point bend.
 *  `amt` can be keyframed: track "bnd<i>amt". */
class BendLayer {
    var name = "Bend"
    var pins = mutableListOf<Int>()
    var mode = 0
    var angle = 45f              // mode 0: degrees at the tip; mode 1: closing strength in % (negative = opens wider)
    var smooth = 0.7f            // 0 linear ... 1 very smooth ease in/out
    var tip = 1.0f               // falloff exponent root -> tip
    var amt = 1f                 // 0...1 how much the bend is applied (animate this)
    var side = 0                 // mode 2 (Point bend): 0 = bend everything below the point, 1 = everything above
    var target = 0f              // where the bend hinges along the pin order: 0 = at the first pin, 0.5 = in the middle
    var affectWave = false       // waves on these pins swing around the bent shape
    var affectPhys = false       // physics on these pins reacts to (lags behind) the bend
    var on = true
    fun applyPreset(i: Int) {
        when (i) {
            0 -> { name = "Classic Bend"; mode = 0; angle = 45f; smooth = 0.5f; tip = 1.2f; target = 0f }
            1 -> { name = "Soft Bend"; mode = 0; angle = 25f; smooth = 1f; tip = 1.0f; target = 0f }
            2 -> { name = "Middle Bend"; mode = 0; angle = 60f; smooth = 0.8f; tip = 1f; target = 0.5f }
            3 -> { name = "Eye Close"; mode = 1; angle = 100f; smooth = 0.8f; tip = 1f }
            else -> { name = "Eye Open"; mode = 1; angle = -40f; smooth = 0.8f; tip = 1f }
        }
    }
    fun toJson(): JSONObject {
        val o = JSONObject(); val a = JSONArray(); for (c in pins) a.put(c.toLong())
        o.put("name", name); o.putL("mode", mode.toLong()); o.putF("angle", angle); o.putF("smooth", smooth)
        o.putF("tip", tip); o.putF("amt", amt); o.put("on", on); o.put("pins", a)
        o.putL("side", side.toLong()); o.putF("target", target); o.put("affectWave", affectWave); o.put("affectPhys", affectPhys)
        return o
    }
    companion object {
        val presetNames = listOf("Classic Bend", "Soft Bend", "Middle Bend", "Eye Close", "Eye Open")
        fun fromJson(o: JSONObject): BendLayer {
            val b = BendLayer()
            b.name = o.optS("name", "Bend"); b.mode = clamp(o.optI("mode", 0), 0, 2)
            b.angle = o.optF("angle", 45f); b.smooth = o.optF("smooth", 0.7f); b.tip = o.optF("tip", 1f)
            b.amt = o.optF("amt", 1f); b.on = o.optB("on", true)
            b.side = clamp(o.optI("side", 0), 0, 1); b.target = o.optF("target", 0f); b.affectWave = o.optB("affectWave", false); b.affectPhys = o.optB("affectPhys", false)
            o.optJSONArray("pins")?.let { a -> for (i in 0 until a.length()) b.pins.add(a.optI(i, 0)) }
            return b
        }
    }
}

class Puppet {
    var bends = mutableListOf<BendLayer>()
    var bendSel = 0                 // editor only
    var on = true
    var pins = mutableListOf<PuppetPin>()
    var nextId = 1
    var density = 1                 // 0 low, 1 medium, 2 high
    var showMesh = true
    var stiffness = 2f              // falloff power (higher = more local)
    var swayOn = false
    var lockRoot = true
    var swayStrength = 1            // 0 gentle, 1 medium, 2 strong
    var swayChain = mutableListOf<Int>()       // pin ids, root first
    var swaySpeed = 0.8f
    var swayDeg = 20f
    var swayWave = 0.5f
    var swayTip = 1.5f
    var swayRand = 0f
    var swaySeed = 1
    var sways = mutableListOf<SwayLayer>()     // every wave / physics effect on this layer
    var swaySel = 0                 // editor only

    fun pin(id: Int): PuppetPin? = pins.firstOrNull { it.id == id }
    fun number(id: Int): Int = (pins.indexOfFirst { it.id == id }.let { if (it < 0) 0 else it }) + 1

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("on", on); o.putL("nextId", nextId.toLong()); o.putL("density", density.toLong())
        o.put("showMesh", showMesh); o.putF("stiffness", stiffness)
        o.put("swayOn", swayOn); o.put("lockRoot", lockRoot)
        o.putL("swayStrength", swayStrength.toLong()); o.putF("swaySpeed", swaySpeed)
        o.putF("swayDeg", swayDeg); o.putF("swayWave", swayWave); o.putF("swayTip", swayTip)
        o.putF("swayRand", swayRand); o.putL("swaySeed", swaySeed.toLong())
        val pa = JSONArray()
        for (p in pins) pa.put(JSONObject().putL("id", p.id.toLong()).putF("rx", p.rx).putF("ry", p.ry))
        o.put("pins", pa)
        val sa = JSONArray(); for (w in sways) sa.put(w.toJson())
        o.put("sways", sa)
        val ba = JSONArray(); for (b in bends) ba.put(b.toJson())
        o.put("bends", ba)
        val ca = JSONArray(); for (c in swayChain) ca.put(c.toLong())
        o.put("chain", ca)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Puppet {
            val p = Puppet()
            p.on = o.optB("on", true)
            p.nextId = max(1, o.optI("nextId", 1))
            p.density = clamp(o.optI("density", 1), 0, 3)
            p.showMesh = o.optB("showMesh", true)
            p.stiffness = o.optF("stiffness", 2f)
            p.swayOn = o.optB("swayOn", false)
            p.lockRoot = o.optB("lockRoot", true)
            p.swayStrength = clamp(o.optI("swayStrength", 1), 0, 2)
            p.swaySpeed = o.optF("swaySpeed", 0.8f)
            p.swayDeg = o.optF("swayDeg", 20f); p.swayWave = o.optF("swayWave", 0.5f)
            p.swayTip = o.optF("swayTip", 1.5f); p.swayRand = o.optF("swayRand", 0f)
            p.swaySeed = o.optI("swaySeed", 1)
            o.optJSONArray("pins")?.let { pa ->
                for (i in 0 until pa.length()) pa.optJSONObject(i)?.let { po -> p.pins.add(PuppetPin(po.optI("id", 0), po.optF("rx", 0f), po.optF("ry", 0f))) }
            }
            o.optJSONArray("chain")?.let { ca -> for (i in 0 until ca.length()) p.swayChain.add(ca.optI(i, 0)) }
            o.optJSONArray("bends")?.let { ba ->
                for (i in 0 until ba.length()) ba.optJSONObject(i)?.let { bo -> p.bends.add(BendLayer.fromJson(bo)) }
            }
            val sa = o.optJSONArray("sways")
            if (sa != null) {
                for (i in 0 until sa.length()) sa.optJSONObject(i)?.let { so -> p.sways.add(SwayLayer.fromJson(so)) }
            } else if (p.swayOn && p.swayChain.isNotEmpty()) {
                val w = SwayLayer()
                w.chain = p.swayChain.toMutableList(); w.speed = p.swaySpeed; w.deg = p.swayDeg; w.wave = p.swayWave
                w.tip = p.swayTip; w.rand = p.swayRand; w.seed = p.swaySeed
                p.sways = mutableListOf(w)
            }
            return p
        }
    }
}

/** Shared state between the Puppet panel and the viewport overlay. */
object PuppetEdit {
    var mode = 0              // 0 add, 1 select, 2 multi
    var tab = 0               // panel tab: 0 Pin / 1 Mesh / 2 Sway
    var sel = mutableListOf<Int>()       // selected pin ids (last = primary)
    var fine = false
    var onChange: (() -> Unit)? = null
}

class PuppetMesh(val pos: FloatArray, val uv: FloatArray, val idx: ShortArray)

object PuppetMath {
    val segs = intArrayOf(7, 12, 18, 28)
    private class GCache(val key: FloatArray, val out: FloatArray)
    private val gCaches = HashMap<Int, GCache>()

    fun rnd(seed: Int, k: Int): Float {
        // UInt32(truncatingIfNeeded: seed &* 7919 &+ k &* 104729 &+ 12345) with 64-bit Int wrap
        var x: UInt = (seed.toLong() * 7919L + k.toLong() * 104729L + 12345L).toUInt()
        x = x * 1664525u + 1013904223u
        x = x xor (x shr 13)
        x = x * 1664525u + 1013904223u
        return (x shr 8).toFloat() / (1 shl 24).toFloat() * 2 - 1
    }

    /** Wave sway: each chained pin swings around the root pin, more toward the tip. */
    fun waveOffset(p: Puppet, s: SwayLayer, pin: PuppetPin, t: Float, qs: Pair<Float, Float>, lay: Layer? = null): Pair<Float, Float> {
        val k = s.chain.indexOf(pin.id)
        if (k < 0) return Pair(0f, 0f)
        val root = p.pin(s.chain[0]) ?: return Pair(0f, 0f)
        val ext = extWave(s)
        val g = ext ?: s                    // follow another layer's Wave (back skirt <- front skirt)
        val amt0 = if (ext != null) s.followAmt else 1f
        val tw = if (ext != null) t - s.delay else t
        val n = s.chain.size
        val PI = Math.PI.toFloat()
        val base: Float = if (p.lockRoot) (if (n > 1) k.toFloat() / (n - 1).toFloat() else 0f) else (k + 1).toFloat() / n.toFloat()
        val w = if (base <= 0) 0f else Math.pow(base.toDouble(), max(g.tip, 0.1f).toDouble()).toFloat()
        val r = rnd(g.seed, k)
        val ph = 2 * PI * g.speed * tw - k.toFloat() * g.wave + g.rand * r * PI
        val amp = 1 + g.rand * r * 0.5f
        val gdeg = g.deg * amt0
        if (k == 0) return if (p.lockRoot) Pair(0f, 0f) else Pair(0.03f * gdeg / 20 * w * sin(ph), 0f)
        val ang = gdeg * PI / 180 * w * sin(ph) * amp
        var bp = Pair(0f, 0f); var br = Pair(0f, 0f)      // bends set to "affect waves" shape the swing
        if (lay != null && p.bends.isNotEmpty()) { bp = bendShift(lay, p, pin, t, qs, false); br = bendShift(lay, p, root, t, qs, false) }
        val vx = (pin.rx + bp.first - root.rx - br.first) * qs.first; val vy = (pin.ry + bp.second - root.ry - br.second) * qs.second
        val c = cos(ang); val sn = sin(ang)
        val rx = vx * c - vy * sn; val ry = vx * sn + vy * c
        return Pair((rx - vx) / max(qs.first, 0.0001f), (ry - vy) / max(qs.second, 0.0001f))
    }

    /** The Wave on another layer this sway follows, or null. */
    fun extWave(s: SwayLayer): SwayLayer? {
        if (s.followId < 0) return null
        val fl = Editor.scene.layers.firstOrNull { it.id == s.followId } ?: return null
        val fp = fl.puppet ?: return null
        if (!fp.swayOn || s.followIdx !in fp.sways.indices) return null
        val w = fp.sways[s.followIdx]
        return if (w.kind == 0 && w.on) w else null
    }

    /** Bend parameter: the stored number, or the layer track (keyframes / expression) "bnd<i><name>" when one exists. */
    fun bv(l: Layer, idx: Int, name: String, v: Float, t: Float): Float {
        val k = "bnd$idx$name"
        return if (l.props[k] != null) l.p(k, t) else v
    }

    /** Smooth bend / eyelid offset of one pin. */
    fun bendOffset(l: Layer, p: Puppet, b: BendLayer, idx: Int, pin: PuppetPin, t: Float, qs: Pair<Float, Float>): Pair<Float, Float> {
        val amt = max(0f, min(1f, bv(l, idx, "amt", b.amt, t)))
        if (amt <= 0f) return Pair(0f, 0f)
        val angle = bv(l, idx, "ang", b.angle, t); val tip = bv(l, idx, "tip", b.tip, t)
        val sm = max(0f, min(1f, bv(l, idx, "smo", b.smooth, t)))
        fun ease(x: Float): Float { val c = max(0f, min(1f, x)); val e = c * c * c * (c * (c * 6 - 15) + 10); return c + (e - c) * sm }
        val PI = Math.PI.toFloat()
        if (b.mode == 2) {
            // Point bend: the whole puppet below (or above) the chosen point bends around it, easing in from the point
            val hid = b.pins.firstOrNull() ?: return Pair(0f, 0f)
            if (pin.id == hid) return Pair(0f, 0f)
            val h = p.pin(hid) ?: return Pair(0f, 0f)
            val below = b.side == 0
            val dy = if (below) (h.ry - pin.ry) else (pin.ry - h.ry)
            if (dy <= 0f) return Pair(0f, 0f)
            var far = 0f
            for (q in p.pins) { val d = if (below) (h.ry - q.ry) else (q.ry - h.ry); if (d > far) far = d }
            val w = Math.pow(ease(dy / max(far, 0.0001f)).toDouble(), max(tip, 0.1f).toDouble()).toFloat()
            val ang = angle * PI / 180 * amt * w
            val vx = (pin.rx - h.rx) * qs.first; val vy = (pin.ry - h.ry) * qs.second
            val c = cos(ang); val sn = sin(ang)
            return Pair(((vx * c - vy * sn) - vx) / max(qs.first, 0.0001f), ((vx * sn + vy * c) - vy) / max(qs.second, 0.0001f))
        }
        val k = b.pins.indexOf(pin.id)
        if (k < 0 || b.pins.size <= 1) return Pair(0f, 0f)
        val n = b.pins.size
        if (b.mode == 0) {
            // hinge point along the pin order: target 0 = first pin, 0.5 = middle. Pins before it stay put,
            // pins after it swing around it, easing in so the bend is smooth.
            val tg = max(0f, min(0.98f, bv(l, idx, "tgt", b.target, t)))
            val pos = tg * (n - 1).toFloat(); val kf = k.toFloat()
            if (kf <= pos) return Pair(0f, 0f)
            val i0 = pos.toInt(); val i1 = min(i0 + 1, n - 1); val fr = pos - i0.toFloat()
            val a0 = p.pin(b.pins[i0]) ?: return Pair(0f, 0f)
            val a1 = p.pin(b.pins[i1]) ?: return Pair(0f, 0f)
            val px = a0.rx + (a1.rx - a0.rx) * fr; val py = a0.ry + (a1.ry - a0.ry) * fr
            val w = Math.pow(ease((kf - pos) / max((n - 1).toFloat() - pos, 0.0001f)).toDouble(), max(tip, 0.1f).toDouble()).toFloat()
            val ang = angle * PI / 180 * amt * w
            val vx = (pin.rx - px) * qs.first; val vy = (pin.ry - py) * qs.second
            val c = cos(ang); val sn = sin(ang)
            return Pair(((vx * c - vy * sn) - vx) / max(qs.first, 0.0001f), ((vx * sn + vy * c) - vy) / max(qs.second, 0.0001f))
        }
        // eyelid: squash toward the pins' centre line, strongest in the middle (smooth = rounder lid)
        val ps = b.pins.mapNotNull { p.pin(it) }
        if (ps.isEmpty()) return Pair(0f, 0f)
        val cy = ps.fold(0f) { acc, q -> acc + q.ry } / ps.size.toFloat()
        val minX = ps.minOf { it.rx }; val maxX = ps.maxOf { it.rx }
        val u = if (maxX > minX) (pin.rx - minX) / (maxX - minX) else 0.5f
        val mid = 1 - abs(u * 2 - 1)                              // 0 at corners, 1 in the middle
        val w = (1 - sm) + sm * ease(mid)
        return Pair(0f, (cy - pin.ry) * (angle / 100) * amt * w)
    }

    /** Sum of the bends that are set to affect waves (phys = false) or physics (phys = true) on this pin. */
    fun bendShift(l: Layer, p: Puppet, pin: PuppetPin, t: Float, qs: Pair<Float, Float>, phys: Boolean): Pair<Float, Float> {
        if (p.bends.isEmpty()) return Pair(0f, 0f)
        var sx = 0f; var sy = 0f
        for ((i, b) in p.bends.withIndex()) {
            if (!(b.on && (if (phys) b.affectPhys else b.affectWave) && (b.mode == 2 || b.pins.contains(pin.id)))) continue
            val o = bendOffset(l, p, b, i, pin, t, qs); sx += o.first; sy += o.second
        }
        return Pair(sx, sy)
    }

    /** Value of a physics setting: the stored number, or the layer track when one exists. */
    private fun pv(l: Layer, idx: Int, key: String, v: Float, t: Float): Float =
        if (l.props["sw$idx$key"] != null) l.p("sw$idx$key", t) else v

    private class PCache(val key: FloatArray, val out: Map<Int, Pair<Float, Float>>)
    private val physCache = HashMap<Int, PCache>()

    /** Physics sway for every chained pin. Stateless: a spring/damper is integrated over the last ~1.2 s of the layer's own motion. */
    fun physicsOffsets(l: Layer, p: Puppet, s: SwayLayer, idx: Int, t: Float, qs: Pair<Float, Float>): Map<Int, Pair<Float, Float>> {
        // FREEZE FIX: a physics layer's anchor reads its parent's mesh, which used to run the parent's own full
        // physics sim for every sub-step (cost multiplied per link -> endless freeze on long chains / cycles).
        // Nested calls now return no physics (parent's keyed + wave motion still carries the child), so cost is bounded.
        val depth = physDepth.get() ?: 0
        if (depth >= 1 || s.chain.size < 2) return emptyMap()
        physDepth.set(depth + 1)
        try {
            return physicsOffsetsInner(l, p, s, idx, t, qs)
        } finally {
            physDepth.set(depth)
        }
    }

    // Thread.current.threadDictionary["puppetPhysDepth"] twin (iOS Puppet.swift).
    private val physDepth = ThreadLocal.withInitial { 0 }

    private fun physicsOffsetsInner(l: Layer, p: Puppet, s: SwayLayer, idx: Int, t: Float, qs: Pair<Float, Float>): Map<Int, Pair<Float, Float>> {
        val stiff = pv(l, idx, "stiff", s.stiff, t); val damp = pv(l, idx, "damp", s.damp, t)
        val grav = pv(l, idx, "grav", s.grav, t); val wind = pv(l, idx, "wind", s.wind, t)
        val m0 = Xf.matrix(l, t); val m1 = Xf.matrix(l, t - 0.25f); val m2 = Xf.matrix(l, t - 0.6f)
        val kl = ArrayList<Float>()
        kl.addAll(listOf(l.id.toFloat(), t, stiff, damp, grav, wind, s.weight.toFloat(), s.deg, qs.first, qs.second))
        for (a in m0) kl.add(a); for (a in m1) kl.add(a); for (a in m2) kl.add(a)
        val ext = extWave(s)
        val drv: SwayLayer? = if (s.link in 0 until p.sways.count() && p.sways[s.link].kind == 0 && p.sways[s.link].on) p.sways[s.link] else (if (ext != null) s else null)
        if (drv != null) kl.addAll(listOf(s.link.toFloat(), drv.speed, drv.deg, drv.wave, drv.tip, drv.rand, drv.seed.toFloat(), drv.chain.size.toFloat()))
        val e2 = extWave(drv ?: s)
        if (e2 != null) kl.addAll(listOf(s.followId.toFloat(), e2.speed, e2.deg, e2.wave, e2.tip, e2.rand, e2.seed.toFloat(), s.followAmt, s.delay))
        kl.addAll(listOf(s.windFreq, s.limit, s.massMul))
        val par = if (followsParentPuppet(l)) parentLayer(l) else null
        if (par != null) {              // the parent's puppet motion over the last second is part of the cache key
            for (i in 0 until 4) {
                val tk = t - i.toFloat() * 0.3f; val o = Xf.apply(Xf.matrix(l, tk), 0f, 0f)
                val f = follow(pctx(par, tk), o.first, o.second); kl.add(f.first); kl.add(f.second)
            }
        }
        for (id in s.chain) p.pin(id)?.let { q ->
            kl.add(id.toFloat()); kl.add(q.rx); kl.add(q.ry)
            val bs = bendShift(l, p, q, t, qs, true); kl.add(bs.first); kl.add(bs.second)
        }
        val key = kl.toFloatArray()
        val ck = l.id * 64 + idx
        physCache[ck]?.let { if (it.key.contentEquals(key)) return it.out }
        val out = HashMap<Int, Pair<Float, Float>>()
        val n = s.chain.size
        val mass = floatArrayOf(0.6f, 1f, 1.7f)[s.weight] * max(s.massMul, 0.1f)
        val dt = 1.0f / 30                       // one anchor sample per 1/30 s, two spring sub-steps each
        val w2 = min((20 + stiff * 8) / mass, 3.2f / (dt * dt / 4)); val c = 1 + damp * 0.4f
        val g = grav * 0.06f * mass; val wd = wind * 0.05f
        val steps = 36; val t0 = max(0f, t - steps.toFloat() * dt)
        val hw = qs.first / 2; val hh = qs.second / 2
        val det = m0[0] * m0[3] - m0[1] * m0[2]
        if (!(abs(det) > 1e-8f)) return out
        // LAG FIX: everything that does not depend on the pin (layer matrix, parent mesh, step times) is computed ONCE
        // per step here instead of once per pin per step.
        fun mk(tt: Float, h: Float): Step {
            val mt = Xf.matrix(l, tt)
            val par2 = par ?: return Step(tt, h, mt, null, Pair(0f, 0f))
            val ctx = pctx(par2, tt); val o = Xf.apply(mt, 0f, 0f)
            return Step(tt, h, mt, ctx, follow(ctx, o.first, o.second))
        }
        val stepsData = ArrayList<Step>()
        stepsData.add(mk(t0, 0f))
        var tt0 = t0
        while (tt0 < t - 1e-5f) { val h = min(dt, t - tt0); tt0 += h; stepsData.add(mk(tt0, h)) }
        val PI = Math.PI.toFloat()
        for ((k, id) in s.chain.withIndex()) {
            val pin = p.pin(id) ?: continue
            if (k == 0 && p.lockRoot) continue
            val base: Float = if (n > 1) (k + (if (p.lockRoot) 0 else 1)).toFloat() / (if (p.lockRoot) n - 1 else n).toFloat() else 1f
            val wt = Math.pow(max(base, 0f).toDouble(), max(s.tip, 0.1f).toDouble()).toFloat()
            fun anchor(st: Step): Pair<Float, Float> {
                // a linked Wave drives the anchor, so the physics adds follow-through (lag, overshoot) to the wave
                val wo = if (drv != null) waveOffset(p, drv, pin, st.tt, qs, l) else Pair(0f, 0f)
                val bs = bendShift(l, p, pin, st.tt, qs, true)       // bends with "Affect physics" move the anchor
                val a = Xf.apply(st.mt, (pin.rx + wo.first + bs.first) * hw, (pin.ry + wo.second + bs.second) * hh)
                if (st.ctx == null) return a
                val fp = follow(st.ctx!!, a.first, a.second)
                return Pair(a.first + fp.first - st.fo.first, a.second + fp.second - st.fo.second)
            }
            val a0 = anchor(stepsData[0])
            var xx = a0.first; var xy = a0.second; var vx = 0f; var vy = 0f
            for (i in 1 until stepsData.size) {
                val st = stepsData[i]; val a = anchor(st); val h = st.h
                val gust = 1 + 0.5f * sin(2 * PI * s.windFreq * st.tt + k.toFloat())
                for (j in 0 until 2) {
                    val hh2 = h / 2
                    val ax = w2 * (a.first - xx) - c * vx + wd * gust * wt
                    val ay = w2 * (a.second - xy) - c * vy - g * wt
                    vx += ax * hh2; vy += ay * hh2
                    xx += vx * hh2; xy += vy * hh2
                }
            }
            val a = anchor(stepsData[stepsData.size - 1])
            val k2 = s.deg / 20                      // Strength scales how far the pin may lag
            var dx = (xx - a.first) * k2; var dy = (xy - a.second) * k2
            val lim = max(hw, hh) * max(s.limit, 0.05f); val len = sqrt(dx * dx + dy * dy)
            if (len > lim) { dx *= lim / len; dy *= lim / len }
            val lx = (m0[3] * dx - m0[2] * dy) / det; val ly = (-m0[1] * dx + m0[0] * dy) / det
            out[id] = Pair(lx / max(hw, 0.0001f), ly / max(hh, 0.0001f))
        }
        if (physCache.size > 200) physCache.clear()
        physCache[ck] = PCache(key, out)
        return out
    }

    /** One parent's mesh state at one time, reused for every pin (iOS PuppetMath.PCtx). */
    class PCtx(val pm: FloatArray, val inv: FloatArray, val hw: Float, val hh: Float, val pins: List<FloatArray>, val stiff: Float)

    /** One step of the physics integration: time, step size, layer matrix, parent mesh, parent-follow offset. */
    class Step(val tt: Float, val h: Float, val mt: FloatArray, val ctx: PCtx?, val fo: Pair<Float, Float>)

    fun pctx(parent: Layer, t: Float): PCtx? {
        if (parent.type == LayerType.GROUP) return null
        val pp = parent.puppet ?: return null
        if (!pp.on || pp.pins.isEmpty()) return null
        val pm = Xf.matrix(parent, t)
        val inv = Xf.invert(pm) ?: return null
        val qs = Xf.puppetQuad(parent)
        return PCtx(pm, inv, max(qs.first / 2, 0.0001f), max(qs.second / 2, 0.0001f), activePins(parent, pp, t), pp.stiffness)
    }

    fun follow(c: PCtx?, wx: Float, wy: Float): Pair<Float, Float> {
        if (c == null) return Pair(0f, 0f)
        val lp = Xf.apply(c.inv, wx, wy)
        val d = disp(c.pins, c.stiff, lp.first / c.hw, lp.second / c.hh)
        val w1 = Xf.apply(c.pm, lp.first + d.first * c.hw, lp.second + d.second * c.hh)
        return Pair(w1.first - wx, w1.second - wy)
    }

    // ---- parent puppet follow (used by Physics sway) --------------------------------------------
    /** A layer with an enabled Physics sway and a parent follows the parent's puppet: the point where it hangs on the
     *  parent moves with the parent's deformed mesh (pins keyed, dragged or swaying), not only with its transform. */
    fun followsParentPuppet(l: Layer): Boolean {
        if (l.parentId < 0) return false
        val p = l.puppet ?: return false
        if (!p.on || !p.swayOn) return false
        return p.sways.any { it.on && it.kind == 1 }
    }

    fun parentLayer(l: Layer): Layer? {
        if (l.parentId < 0 || l.parentId == l.id) return null
        val seen = HashSet<Int>(); seen.add(l.id); var cur = l.parentId     // stop on parent cycles
        while (cur >= 0) {
            if (seen.contains(cur)) return null
            seen.add(cur)
            cur = Editor.scene.layers.firstOrNull { it.id == cur }?.parentId ?: -1
        }
        return Editor.scene.layers.firstOrNull { it.id == l.parentId }
    }

    /** World-space displacement the parent's puppet mesh gives to the world point (wx, wy) at time t. */
    fun parentFollow(parent: Layer, t: Float, wx: Float, wy: Float): Pair<Float, Float> =
        follow(pctx(parent, t), wx, wy)

    /** Offset from rest of one pin at time t (keyed tracks + every sway layer). */
    fun offset(l: Layer, p: Puppet, pin: PuppetPin, t: Float, qs: Pair<Float, Float>? = null,
               phys: Map<Int, Map<Int, Pair<Float, Float>>>? = null): Pair<Float, Float> {
        var ox = (l.props["pp${pin.id}x"]?.eval(t) ?: 0f) + (l.rigOff["pp${pin.id}x"] ?: 0f)
        var oy = (l.props["pp${pin.id}y"]?.eval(t) ?: 0f) + (l.rigOff["pp${pin.id}y"] ?: 0f)
        val hasSway = p.swayOn && p.sways.isNotEmpty()
        if (!hasSway && p.bends.isEmpty()) return Pair(ox, oy)
        val q = qs ?: Xf.quadSize(l)
        if (hasSway) {
            for ((i, s) in p.sways.withIndex()) {
                if (!(s.on && s.chain.contains(pin.id))) continue
                if (s.kind == 0) { val o = waveOffset(p, s, pin, t, q, l); ox += o.first; oy += o.second }
                else { val o = (phys?.get(i) ?: physicsOffsets(l, p, s, i, t, q))[pin.id]; if (o != null) { ox += o.first; oy += o.second } }
            }
        }
        for ((i, b) in p.bends.withIndex()) {
            if (!(b.on && (b.mode == 2 || b.pins.contains(pin.id)))) continue
            val o = bendOffset(l, p, b, i, pin, t, q); ox += o.first; oy += o.second
        }
        return Pair(ox, oy)
    }

    fun pinPos(l: Layer, p: Puppet, pin: PuppetPin, t: Float, qs: Pair<Float, Float>? = null): Pair<Float, Float> {
        val o = offset(l, p, pin, t, qs)
        return Pair(pin.rx + o.first, pin.ry + o.second)
    }

    fun wgt(d2: Float, pw: Float): Float {
        val e = d2 + 0.00001f
        return if (pw == 2f) 1 / e else Math.pow(e.toDouble(), (-pw * 0.5f).toDouble()).toFloat()
    }

    /** Displacement of a rest point (inverse-distance weighted, with a hold weight so far-away points stay put). pins: (rx, ry, ox, oy). */
    fun disp(pins: List<FloatArray>, pw: Float, x: Float, y: Float): Pair<Float, Float> {
        var sx = 0f; var sy = 0f; var sw = Math.pow(1.4, -pw.toDouble()).toFloat()
        for (q in pins) {
            val dx = x - q[0]; val dy = y - q[1]
            val w = wgt(dx * dx + dy * dy, pw)
            sx += w * q[2]; sy += w * q[3]; sw += w
        }
        return Pair(sx / sw, sy / sw)
    }

    fun activePins(l: Layer, p: Puppet, t: Float): List<FloatArray> {
        val swOn = p.swayOn && p.sways.isNotEmpty()
        val qs = if (swOn || p.bends.isNotEmpty()) Xf.quadSize(l) else Pair(1f, 1f)
        val ph = HashMap<Int, Map<Int, Pair<Float, Float>>>()     // each physics sway is solved once for all pins, not once per pin
        if (swOn) for ((i, s) in p.sways.withIndex()) if (s.on && s.kind == 1) ph[i] = physicsOffsets(l, p, s, i, t, qs)
        return p.pins.map { val o = offset(l, p, it, t, qs, ph); floatArrayOf(it.rx, it.ry, o.first, o.second) }
    }

    /** Deformed grid vertex positions (aPos space), row-major, (n+1)^2 points. */
    @Synchronized fun gridPositions(l: Layer, p: Puppet, t: Float): FloatArray {
        val n = segs[p.density]
        val pins = activePins(l, p, t)
        val kl = ArrayList<Float>(); kl.add(l.id.toFloat()); kl.add(n.toFloat()); kl.add(p.stiffness)
        for (q in pins) { kl.add(q[0]); kl.add(q[1]); kl.add(q[2]); kl.add(q[3]) }
        val key = kl.toFloatArray()
        val ck = l.id * 8 + p.density
        gCaches[ck]?.let { if (it.key.contentEquals(key)) return it.out }
        val out = FloatArray((n + 1) * (n + 1) * 2); var o = 0
        for (j in 0..n) {
            val y = -1 + 2 * j.toFloat() / n.toFloat()
            for (i in 0..n) {
                val x = -1 + 2 * i.toFloat() / n.toFloat()
                val d = disp(pins, p.stiffness, x, y)
                out[o++] = x + d.first; out[o++] = y + d.second
            }
        }
        if (gCaches.size > 400) gCaches.clear()
        gCaches[ck] = GCache(key, out)
        return out
    }

    private val topoCache = HashMap<Int, Pair<FloatArray, ShortArray>>()
    @Synchronized fun topology(n: Int): Pair<FloatArray, ShortArray> {
        topoCache[n]?.let { return it }
        val uv = FloatArray((n + 1) * (n + 1) * 2); var u = 0
        for (j in 0..n) for (i in 0..n) { uv[u++] = i.toFloat() / n.toFloat(); uv[u++] = j.toFloat() / n.toFloat() }
        val idx = ShortArray(n * n * 6); var q = 0
        for (j in 0 until n) for (i in 0 until n) {
            val a = j * (n + 1) + i; val b = a + 1; val c = a + (n + 1); val d = c + 1
            idx[q++] = a.toShort(); idx[q++] = b.toShort(); idx[q++] = c.toShort(); idx[q++] = b.toShort(); idx[q++] = d.toShort(); idx[q++] = c.toShort()
        }
        val r = Pair(uv, idx); topoCache[n] = r
        return r
    }

    /** Mesh for the renderer, or null when the layer has no active puppet. */
    fun mesh(l: Layer, t: Float): PuppetMesh? {
        val p = l.puppet ?: return null
        if (!p.on || p.pins.isEmpty()) return null
        val (uv, idx) = topology(segs[p.density])
        return PuppetMesh(gridPositions(l, p, t), uv, idx)
    }
}
