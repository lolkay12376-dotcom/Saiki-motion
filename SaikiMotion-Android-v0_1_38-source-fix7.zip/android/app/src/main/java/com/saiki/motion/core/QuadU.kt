package com.saiki.motion.core

// QuadU — the std140 uniform of the quad/shape/mesh/warp passes (shared/shaders/glsl/quad.frag binding 8;
// == MetalSceneRenderer.swift struct QuadU). `data` is the flat float array in exactly the std140 order
// the shaders declare (see jni_scene.cpp offsets: color abcd t+quad aspect/flipY/kind/corner rot3 flags vp0-3 gradP gradC gradM).
class QuadU {
    @JvmField val data = FloatArray(52)

    fun color(r: Float, g: Float, b: Float, a: Float) { data[0] = r; data[1] = g; data[2] = b; data[3] = a }
    fun abcd(a: Float, b: Float, c: Float, d: Float) { data[4] = a; data[5] = b; data[6] = c; data[7] = d }
    fun t(x: Float, y: Float) { data[8] = x; data[9] = y }
    fun quad(w: Float, h: Float) { data[10] = w; data[11] = h }
    var aspect: Float
        get() = data[12]
        set(v) { data[12] = v }
    var flipY: Float
        get() = data[13]
        set(v) { data[13] = v }
    var kind: Float
        get() = data[14]
        set(v) { data[14] = v }
    var corner: Float
        get() = data[15]
        set(v) { data[15] = v }
    fun rot3(rx: Float, ry: Float, z: Float, invCam: Float) { data[16] = rx; data[17] = ry; data[18] = z; data[19] = invCam }
    fun flags(x: Float, y: Float, z: Float, w: Float) { data[20] = x; data[21] = y; data[22] = z; data[23] = w }
    val flagsData: FloatArray get() = data
    fun vp(v: FloatArray) { if (v.size == 16) System.arraycopy(v, 0, data, 24, 16) }
    fun gradP(x1: Float, y1: Float, x2: Float, y2: Float) { data[40] = x1; data[41] = y1; data[42] = x2; data[43] = y2 }
    fun gradC(r: Float, g: Float, b: Float, a: Float) { data[44] = r; data[45] = g; data[46] = b; data[47] = a }
    fun gradM(mode: Float, a: Float, b: Float, c: Float) { data[48] = mode; data[49] = a; data[50] = b; data[51] = c }
}
