package com.saiki.motion.core

import com.saiki.motion.render.NativeRenderer
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Registry.swift Preset. */
class Preset(val name: String, val builtin: Boolean, val json: JSONObject)

/**
 * Port of Sources/Effects/Registry.swift (the effect catalog).
 * Substitutions: Bundle.main resources -> Assets (shared/resources); GL compile check -> Vulkan twin (see validateProgram).
 */
object Registry {
    val CATEGORIES = listOf("Controls", "Universe", "Node Video", "Light and glow", "Color", "Stylize", "Distort", "Blur",
        "Generate", "Glitch and motion", "Keying", "Transform and time", "Custom")

    /** Display order (defs). */
    @Volatile var order: List<EffectDef> = emptyList(); private set
    /** Fast id lookup. */
    @Volatile var byId: Map<String, EffectDef> = emptyMap(); private set
    /** Shader-compile problems, id -> log. "__gl" = GL context trouble. */
    val errors: MutableMap<String, String> = HashMap()
    /** Folder-name-keyed scan problems for the SDK IDE. */
    val sdkErrors: MutableMap<String, String> = HashMap()
    private var initialized = false
    private val lock = Any()

    /** Registry.initialize(): idempotent, the catalog loads ONCE. Needs Paths.init() first. */
    fun initialize() {
        if (initialized) return
        reloadSdk()
        // == Registry.swift:117: warm the shader check off the main thread 1.5 s after load —
        // EffectThumbs compiles every shader and records errors, one pass does both jobs.
        Thread {
            Thread.sleep(1500)
            EffectThumbs.generate { }
        }.start()
    }

    fun reloadSdk() { synchronized(lock) {
        val ord = ArrayList<EffectDef>(); val ids = HashMap<String, EffectDef>()
        sdkErrors.clear(); errors.clear()

        // 1 - the GLSL engine's built-ins
        for (d in Builtins.all()) { ids[d.id] = d; ord.add(d) }

        // 2 - the bundled SDK examples
        for (id in Builtins.exampleIds) {
            val d = Builtins.exampleById(id) ?: continue
            d.builtin = true; d.bundled = true
            ids[d.id] = d; ord.add(d)
        }

        // 2b - bundled multi-pass .aureaplugin effects (sdk/plugins/<name>/plugin.json)
        for (name in Assets.list("sdk/plugins").sorted()) {
            val base = "sdk/plugins/$name"
            val d = EffectDef.fromAureaPlugin(name, "asset:$base") { rel -> Assets.readText("$base/$rel") } ?: continue
            d.builtin = true; d.bundled = true
            ids[d.id] = d; ord.add(d)
        }

        // 3 - user effects: <sdkRoot>/<folder>/{effect.json, effect.glsl}
        val root = sdkRoot()
        val folders = root.list()
        if (folders != null) {
            for (folder in folders.sorted()) {
                val dir = File(root, folder)
                if (!dir.isDirectory) continue
                val jf = File(dir, "effect.json")
                val text = try { jf.readText(Charsets.UTF_8) } catch (_: Exception) { continue }
                val o = parseJson(text)
                if (o == null) { sdkErrors[folder] = "effect.json is not valid JSON."; continue }
                val d = EffectDef.fromJson(o, dir.path)
                if (d == null) { sdkErrors[folder] = "effect.json has no name."; continue }
                // the code may live in effect.json ("code") or effect.glsl
                if (d.glsl.isEmpty()) d.glsl = try { File(dir, "effect.glsl").readText(Charsets.UTF_8) } catch (_: Exception) { "" }
                if (d.glsl.isEmpty()) { sdkErrors[folder] = "effect.glsl is empty or missing."; continue }
                ids[d.id] = d; ord.add(d)
            }
        }
        order = ord; byId = ids
        initialized = true
    } }

    /** The SDK folder (created on demand - dropping files in is a feature). */
    fun sdkRoot(): File { val f = File(Paths.root, "sdk"); f.mkdirs(); return f }

    /** Creates a new effect folder with a starter json + glsl. */
    fun newEffectFolder(name: String): File {
        val root = sdkRoot()
        val slug = name.lowercase().map { c -> if ((c in 'a'..'z') || (c in '0'..'9')) c else '_' }.joinToString("")
        var s = slug.trim('_')
        if (s.isEmpty()) s = "effect"
        var dir = File(root, s)
        var n = 2
        while (dir.exists()) { dir = File(root, "$s$n"); n++ }
        dir.mkdirs()
        val json = JSONObject().put("id", s).put("name", name).put("description", "My custom effect.").put("category", "Custom")
        val params = JSONArray()
        params.put(JSONObject().put("name", "amount").put("label", "Amount").putD("min", 0.0).putD("max", 1.0).putD("def", 0.5))
        json.put("params", params)
        val colors = JSONArray()
        colors.put(JSONObject().put("name", "tint").put("label", "Tint").put("def", "#FFFF7A9E"))
        json.put("colors", colors)
        json.put("code", "vec4 c = src(uv);\nreturn vec4(mix(c.rgb, tint.rgb, amount), c.a);\n")
        try { File(dir, "effect.json").writeText(json.toPretty(4), Charsets.UTF_8) } catch (_: Exception) {}
        try { File(dir, "effect.glsl").writeText("vec4 effect(vec2 uv) {\n    vec4 c = src(uv);\n    return vec4(mix(c.rgb, tint.rgb, amount), c.a);\n}\n", Charsets.UTF_8) } catch (_: Exception) {}
        return dir
    }

    // MARK: - lookup

    /** Entry-id resolution: "blur~2" -> the blur def. */
    fun get(entry: String): EffectDef? {
        var id = entry
        val r = id.indexOf('~'); if (r >= 0) id = id.substring(0, r)
        return byId[id]
    }

    /** A fresh entry id for stacking the same effect twice: "blur", "blur~2"... */
    fun uniqueEntry(l: Layer, id: String): String {
        if (!l.fx.contains(id)) return id
        var n = 2
        while (l.fx.contains("$id~$n")) n++
        return "$id~$n"
    }

    /** Instance-scoped parameter (key carries the entry prefix). */
    fun instProp(l: Layer, entry: String, pd: PropDef): PropDef {
        val d = get(entry)
        val single = (d?.kind ?: 0) == 1
        return PropDef(if (single) pd.key else entry + "__" + pd.key, pd.label, pd.min, pd.max, pd.def, pd.dec, pd.options, pd.inf, pd.span)
    }

    /** Instance-scoped color parameter. */
    fun instColor(l: Layer, entry: String, cp: ColorParam): ColorParam {
        val d = get(entry)
        val single = (d?.kind ?: 0) == 1
        return ColorParam(if (single) cp.key else entry + "__" + cp.key, cp.label, cp.def)
    }

    /** Parameters created at runtime (text animation values) so the graph/timeline can label them. */
    var dyn: MutableMap<String, PropDef> = HashMap()

    /** Reverse lookup: a track key -> its PropDef (graph editor labels). */
    fun propDef(key: String): PropDef? {
        dyn[key]?.let { return it }
        val sk = PtGroup.strip(key)
        if (sk != key) return propDef(sk)
        for (d in order) {
            for (p in d.props) if (p.key == key) return p
            if (!key.startsWith(d.id + "__")) continue
            val sub = key.substring(d.id.length + 2)
            for (p in d.props) if (p.key == sub) return p
        }
        for (p in Defs.transform + Defs.scaleXY + Defs.pos3d + Defs.rot3d + Defs.anchor + Defs.text + Defs.audio + Defs.camera + Defs.flare + Defs.blur)
            if (p.key == key) return p
        return null
    }

    // MARK: - shaders

    /** Records a shader problem (thread-safe). */
    fun noteError(id: String, msg: String) {
        synchronized(lock) { errors[id] = if (msg.length > 400) msg.substring(0, 400) else msg }
    }

    private val checked = HashSet<String>()

    /**
     * Registry.validateProgram. iOS compiles on a throwaway GL context; Android hands the Vulkan twin source to the async shaderc cache (NativeRenderer.fxPrepare).
     * PARITY-NOTE(Registry.swift:222): iOS's throwaway EAGL context compiles synchronously; the shaderc cache compiles on a background
     * thread, so the verdict is only known once that finishes — a failure noted here is whatever fxStatus reports at call time.
     */
    fun validateProgram(d: EffectDef): Boolean {
        synchronized(lock) {
            if (checked.contains(d.id)) return errors[d.id] == null
            checked.add(d.id)
        }
        val key = FxGlsl.key(d)
        NativeRenderer.fxPrepare(key, FxGlsl.vulkanSource(d), d.name)
        if (NativeRenderer.fxStatus(key) == 2) { noteError(d.id, NativeRenderer.fxError(key)); return false }
        return true
    }

    /** Lines of prelude the compiler counts before the user's code. */
    fun codeLineOffset(d: EffectDef): Int = Gl.effectShaderSource(d).second

    // MARK: - custom effects

    /** Imports an effect from JSON text (file picker or Create dialog). Returns an error string, or null on success. */
    fun addCustom(txt: String): String? {
        val o = parseJson(txt) ?: return "Not valid JSON."
        val d = EffectDef.fromJson(o, null) ?: return "The effect needs a name."
        if (d.glsl.isEmpty()) {
            o.optJSONArray("code")?.let { code ->
                // multi-line code arrays: join
                var s = ""
                for (i in 0 until code.length()) s += code.optS(i) + "\n"
                d.glsl = s
            }
        }
        if (d.glsl.isEmpty()) return "The effect has no GLSL code."
        val dir = File(sdkRoot(), d.id)
        dir.mkdirs()
        try { File(dir, "effect.json").writeText(d.toJson().toPretty(4), Charsets.UTF_8) } catch (_: Exception) {}
        try { File(dir, "effect.glsl").writeText(d.glsl, Charsets.UTF_8) } catch (_: Exception) {}
        reloadSdk()
        return null
    }

    /** Deletes a user effect folder by id (bundled/built-ins are refused). */
    fun deleteCustom(id: String) {
        val d = byId[id] ?: return
        val src = d.source
        if (d.builtin || d.bundled || src == null) return
        File(src).deleteRecursively()
        synchronized(lock) { checked.remove(id); errors.remove(id) }
        reloadSdk()
    }

    /** effect.json representation for export. */
    fun toJson(d: EffectDef): JSONObject = d.toJson()

    // MARK: - presets

    private var presetList = ArrayList<Preset>()
    private var presetsLoaded = false

    private fun presetsFile() = File(Paths.root, "presets.json")

    private fun loadPresets() {
        presetsLoaded = true
        presetList = ArrayList()
        val o = try { parseJson(presetsFile().readText(Charsets.UTF_8)) } catch (_: Exception) { null } ?: return
        val a = o.optJSONArray("presets") ?: return
        for (i in 0 until a.length()) {
            val po = a.optJSONObject(i) ?: continue
            val fx = po.optJSONObject("fx") ?: continue
            presetList.add(Preset(po.optS("name", "Preset"), po.optB("builtin"), fx))
        }
    }

    fun presets(): List<Preset> { if (!presetsLoaded) loadPresets(); return presetList }

    fun savePreset(o: JSONObject) {
        if (!presetsLoaded) loadPresets()
        val name = o.optS("name", "Preset")
        presetList.removeAll { it.name == name }
        presetList.add(Preset(name, false, o))
        persistPresets()
    }

    fun deletePreset(name: String) {
        if (!presetsLoaded) loadPresets()
        presetList.removeAll { it.name == name && !it.builtin }
        persistPresets()
    }

    private fun persistPresets() {
        val a = JSONArray()
        for (p in presetList) a.put(JSONObject().put("name", p.name).put("builtin", p.builtin).put("fx", p.json))
        try { presetsFile().writeText(JSONObject().put("presets", a).toPretty(4), Charsets.UTF_8) } catch (_: Exception) {}
    }

    /** Snapshots a layer's effects (params at time t) as a preset payload. */
    fun capturePreset(l: Layer, name: String, t: Float): JSONObject {
        val fxArr = JSONArray()
        for (entry in l.fx) {
            val d = get(entry) ?: continue
            val eo = JSONObject().put("id", d.id)
            val tracks = JSONObject()
            val single = d.kind == 1
            for (pd in d.props) {
                val k = if (single) pd.key else entry + "__" + pd.key
                l.props[k]?.let { tracks.put(pd.key, it.toJson()) }
            }
            for (cp in d.colors) {
                val base = if (single) cp.key else entry + "__" + cp.key
                val co = JSONObject()
                for (sfx in listOf("_r", "_g", "_b", "_a")) l.props[base + sfx]?.let { co.put(sfx, it.toJson()) }
                tracks.put(cp.key, co)
            }
            eo.put("tracks", tracks)
            val ins = JSONObject()
            for ((k, v) in l.inputs) if (k.startsWith("$entry:")) ins.putL(k.substring(entry.length + 1), v.toLong())
            eo.put("inputs", ins)
            if (l.fxOff.contains(entry)) eo.put("off", true)
            fxArr.put(eo)
        }
        return JSONObject().put("name", name).put("fx", fxArr)
    }

    /** Applies a preset payload to a layer (replaces its effect stack). */
    fun applyPreset(l: Layer, json: JSONObject) {
        val fxArr = json.optJSONArray("fx") ?: return
        l.fx = mutableListOf()
        l.fxOff = LinkedHashSet()
        for (i in 0 until fxArr.length()) {
            val eo = fxArr.optJSONObject(i) ?: continue
            val d = byId[eo.optS("id")] ?: continue
            val entry = if (d.kind == 1) d.id else uniqueEntry(l, d.id)
            l.fx.add(entry)
            if (eo.optB("off")) l.fxOff.add(entry)
            val single = d.kind == 1
            eo.optJSONObject("tracks")?.let { tracks ->
                for (pd in d.props) {
                    val to = tracks.optJSONObject(pd.key) ?: continue
                    l.track(if (single) pd.key else entry + "__" + pd.key).load(to)
                }
                for (cp in d.colors) {
                    val co = tracks.optJSONObject(cp.key) ?: continue
                    val base = if (single) cp.key else entry + "__" + cp.key
                    for (sfx in listOf("_r", "_g", "_b", "_a")) co.optJSONObject(sfx)?.let { l.track(base + sfx).load(it) }
                }
            }
            eo.optJSONObject("inputs")?.let { ins ->
                val it = ins.keys()
                while (it.hasNext()) { val nm = it.next(); l.inputs["$entry:$nm"] = ins.optI(nm) }
            }
        }
    }
}

/** Sources/Effects/BuiltinsControls.swift ControlFx (only the parts Expr needs). */
object ControlFx {
    val ids = listOf("slidercontrol", "anglecontrol", "checkboxcontrol", "colorcontrol", "pointcontrol", "point3dcontrol", "layercontrol")
    val fns: Map<String, Pair<String, String>> = mapOf(
        "slider" to ("slidercontrol" to "slider"), "angle" to ("anglecontrol" to "angle"),
        "checkbox" to ("checkboxcontrol" to "checkbox"),
        "pointx" to ("pointcontrol" to "px"), "pointy" to ("pointcontrol" to "py"),
        "point3x" to ("point3dcontrol" to "px"), "point3y" to ("point3dcontrol" to "py"), "point3z" to ("point3dcontrol" to "pz"),
        "colorr" to ("colorcontrol" to "color_r"), "colorg" to ("colorcontrol" to "color_g"), "colorb" to ("colorcontrol" to "color_b"),
        "layerctl" to ("layercontrol" to "layer"))
}
