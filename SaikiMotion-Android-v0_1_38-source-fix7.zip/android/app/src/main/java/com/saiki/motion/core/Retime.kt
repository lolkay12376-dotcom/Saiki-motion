package com.saiki.motion.core

import java.util.IdentityHashMap
import kotlin.math.abs
import kotlin.math.max

// Port of Sources/Model/Retime.swift

class RetimeSnap(val layer: Layer) {
    val oldF: (Float) -> Float = layer.srcMap()
    class Orig(val tr: Track, val key: Key, val t0: Float)
    val origTimes = mutableListOf<Orig>()
    init {
        for ((k, tr) in layer.props) if (!k.startsWith("remap")) for (key in tr.keys) origTimes.add(Orig(tr, key, key.t))
    }
}

/** Scene time -> source time (offset-free) from the current remap state. */
fun Layer.srcMap(): (Float) -> Float {
    val st = start
    val rt = props["remapT"]
    if (rt != null && rt.keys.isNotEmpty()) {
        val c = Track(rt.base); c.keys = rt.keys.map { it.copy() }.toMutableList()
        return { c.eval(it) }
    }
    val sp = props["remapSpeed"]
    if (sp != null) {
        val c = Track(sp.base); c.keys = sp.keys.map { it.copy() }.toMutableList()
        return { (it - st) * c.eval(it) }
    }
    return { it - st }
}

fun Layer.retimeSnapshot(): RetimeSnap? = if (type == LayerType.VIDEO || type == LayerType.MODEL) RetimeSnap(this) else null

/** Re-places the snapshotted keys for the CURRENT remap state (idempotent: always computed from the originals). */
fun Layer.retime(snap: RetimeSnap?) {
    if (snap == null || snap.layer !== this) return
    val f = srcMap()
    val span = max(end - start, 0.1f)
    val lo = start; val hi = start + span * 10
    val n = 512
    fun inverse(s: Float, fallback: Float): Float {
        var prevT = lo; var prevV = f(lo)
        if (abs(prevV - s) < 1e-5f) return prevT
        for (i in 1..n) {
            val t = lo + (hi - lo) * i.toFloat() / n.toFloat()
            val v = f(t)
            if ((prevV - s) * (v - s) <= 0 && abs(v - prevV) > 1e-7f) {
                var a = prevT; var b = t; var fa = prevV
                for (k in 0 until 22) {
                    val m = (a + b) / 2; val fm = f(m)
                    if ((fa - s) * (fm - s) <= 0) b = m else { a = m; fa = fm }
                }
                return (a + b) / 2
            }
            prevT = t; prevV = v
        }
        return fallback
    }
    val seen = IdentityHashMap<Track, Boolean>()
    val tracks = mutableListOf<Track>()
    for (o in snap.origTimes) {
        o.key.t = if (o.t0 < start - 1e-4f || o.t0 > end + 1e-4f) o.t0 else inverse(snap.oldF(o.t0), o.t0)
        if (seen.put(o.tr, true) == null) tracks.add(o.tr)
    }
    for (tr in tracks) tr.keys.sortBy { it.t }
}
