package com.saiki.motion.core

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// Port of Sources/Model/Rig.swift (rig group data, Live2D-style physics, Warp deformer).

class RigParam(var id: Int, var name: String, var lo: Float, var hi: Float, var def: Float) {
    var folder = 0                  // parameter folder id (0 = root)
    val key: String get() = "rp$id"
}

class RigKey(var v: Float, var o: Float)

class RigBinding(var id: Int, var paramId: Int, var layerId: Int, var key: String, var keys: MutableList<RigKey> = mutableListOf()) {
    var rest: Float? = null          // implicit zero-output key at the parameter default (not stored as a key)

    fun eval(v: Float): Float {
        var ks: MutableList<RigKey> = keys
        val rv = rest
        if (rv != null && !ks.any { abs(it.v - rv) < 1e-3f }) {
            ks = ks.toMutableList(); ks.add(RigKey(rv, 0f)); ks.sortBy { it.v }
        }
        val f = ks.firstOrNull() ?: return 0f
        val l = ks.last()
        if (v <= f.v) return f.o
        if (v >= l.v) return l.o
        for (i in 1 until ks.size) if (v <= ks[i].v) {
            val a = ks[i - 1]; val b = ks[i]
            val d = b.v - a.v
            return if (d < 1e-6f) b.o else a.o + (b.o - a.o) * (v - a.v) / d
        }
        return l.o
    }

    fun setKey(pv: Float, out: Float) {
        val i = keys.indexOfFirst { abs(it.v - pv) < 1e-3f }
        if (i >= 0) keys[i].o = out
        else { keys.add(RigKey(pv, out)); keys.sortBy { it.v } }
    }
}

/** A layer (usually a Rotate Deformer or hair layer) that the pendulum swings, with its own amount and lag. */
class PhysTarget(var layerId: Int, var deg: Float, var delay: Float)

/** Physics input (the "cause"). */
class PhysIn(var paramId: Int, var influence: Float = 100f) {
    var invert = false
    var useRange = false            // false -> parameter min / default / max
    var nmin = -1f; var ncen = 0f; var nmax = 1f
}

/** Physics output (the "effect"): a parameter that the simulated pendulum drives (value is ADDED). */
class PhysOut(var paramId: Int, var scale: Float = 1f) {
    var pend = 0
    var limit = 1f
    var invert = false
    var peak = 0f
}

/** Extra pendulum in a group's chain. */
class PhysPend { var length = 0.5f; var damping = 0.3f; var reaction = 0.6f }

class PhysState(var th: FloatArray = FloatArray(0), var w: FloatArray = FloatArray(0), var u1: FloatArray = FloatArray(0), var u2: FloatArray = FloatArray(0), var uf: FloatArray = FloatArray(0))

/** Live2D-style physics group: input parameter(s) move a pendulum, whose swing drives output parameter(s). */
class PhysGroup(var id: Int, var name: String) {
    var on = true
    var ins = mutableListOf<PhysIn>()
    var outs = mutableListOf<PhysOut>()
    var length = 0.5f
    var damping = 0.3f
    var ease = 0.85f
    var reaction = 0.5f
    var strength = 1f
    var maxDeg = 30f
    var weight = 1f
    var gravity = 1f
    var delay = 0f
    var follow = 0.35f
    var wind = 0f         // legacy, ignored
    var pends = mutableListOf<PhysPend>()
    var lS = PhysState(); var lLast = 0.0; var lInit = false; var lPrevU = 0f; var lAcc = 0f
    var lastRaw = FloatArray(0)    // true (unlimited) pendulum angles in radians, for the diagram
    var targets = mutableListOf<PhysTarget>()   // legacy direct layer targets

    fun angle(g: Layer, rig: Rig, t: Float): Float = angles(g, rig, t)[0]

    /** One value (-1...1) per pendulum in the chain. Deterministic: re-simulated from rest over the last 2 s. */
    fun angles(g: Layer, rig: Rig, t: Float): FloatArray {
        val n = 1 + pends.size
        val used = ins.mapNotNull { i -> rig.param(i.paramId)?.let { Pair(i, it) } }
        if (used.isEmpty()) return FloatArray(n)
        val total = max(100f, used.fold(0f) { a, b -> a + b.first.influence })
        val dt = 1.0f / 60; val g0 = 9.8f * max(gravity, 0.05f)
        val live = used.all { (g.props[it.second.key]?.keys?.size ?: 0) <= 1 && !(g.props[it.second.key]?.exprOn ?: false) }
        val steps = (min(max(t, 0f), 1.2f) / dt).toInt()
        var tau = t - steps.toFloat() * dt
        val maxR = max(maxDeg, 1f) * Math.PI.toFloat() / 180
        fun u(x0: Float): Float {
            var sum = 0f
            val x = x0 - delay
            for ((i, p) in used) {
                val v = g.props[p.key]?.eval(x) ?: p.def
                val lo = if (i.useRange) i.nmin else p.lo; val c = if (i.useRange) i.ncen else p.def; val hi = if (i.useRange) i.nmax else p.hi
                val nn = if (v >= c) (v - c) / max(hi - c, 1e-4f) else (v - c) / max(c - lo, 1e-4f)
                sum += max(-1.5f, min(1.5f, nn)) * (if (i.invert) -1f else 1f) * i.influence / total
            }
            val r = ease / 0.85f
            return sum * strength * (r * r)
        }
        // Input gain is much higher and the input low-pass much shorter than before: the old values made physics stiff and late.
        val kIn = 1.6f
        fun step(s: PhysState, uIn: Float, h: Float, lag: Float) {
            for (k in 0 until n) {
                val len = if (k == 0) length else pends[k - 1].length
                val dmp = if (k == 0) damping else pends[k - 1].damping
                val rea = if (k == 0) reaction else pends[k - 1].reaction
                val L = max(len, 0.05f)
                val c = 2 * (0.05f + 0.95f * dmp) * sqrt(g0 / L)
                val inp = if (k == 0) uIn else s.th[k - 1] / maxR
                val tc = 0.002f + (1 - min(max(rea, 0f), 1f)) * 0.03f + (if (k == 0) max(lag, 0f) else 0f)
                s.uf[k] += (inp - s.uf[k]) * (1 - exp(-h / tc))
                var a = (s.uf[k] - 2 * s.u1[k] + s.u2[k]) / (h * h) * kIn
                a = min(120f, max(-120f, a))
                val eq = if (k == 0) follow * s.uf[0] * maxR else 0f
                s.w[k] += (-(g0 / L) * sin(s.th[k] - eq) - c * s.w[k] - a / L * cos(s.th[k])) * h
                s.th[k] += s.w[k] * h
                s.u2[k] = s.u1[k]; s.u1[k] = s.uf[k]
            }
        }
        fun fresh(u0: Float): PhysState = PhysState(FloatArray(n), FloatArray(n), FloatArray(n) { u0 }, FloatArray(n) { u0 }, FloatArray(n) { u0 })
        fun out(s: PhysState): FloatArray { lastRaw = s.th.copyOf(); return FloatArray(s.th.size) { min(1f, max(-1f, s.th[it] / maxR)) } }
        if (live) {
            // Input is not keyframed: simulate in real time from the live value, so dragging a slider swings it.
            val now = System.nanoTime() / 1e9
            val ucur = u(0f)
            if (!lInit || lS.th.size != n) { lInit = true; lS = fresh(ucur); lPrevU = ucur; lAcc = 0f; lLast = now }
            // Fixed 1/120 s steps with the input interpolated across the frame so it never moves in jumps.
            lAcc += min(max(now - lLast, 0.0), 0.1).toFloat(); lLast = now
            val hh = 1.0f / 120
            val ns = (lAcc / hh).toInt()
            if (ns > 0) {
                for (i in 1..ns) step(lS, lPrevU + (ucur - lPrevU) * i.toFloat() / ns.toFloat(), hh, delay)
                lAcc -= ns.toFloat() * hh; lPrevU = ucur
            }
            if (lS.th.any { abs(it) > 0.003f } || lS.w.any { abs(it) > 0.02f } || abs(ucur - lS.uf[0]) > 0.002f) Rig.liveActive = true
            return out(lS)
        }
        val st = fresh(u(tau))
        for (j in 0 until steps) {
            tau += dt
            step(st, u(tau), dt, 0f)
        }
        return out(st)
    }
}

/** Two parameters driven together by one 2D pad. */
class RigLink(var id: Int, var name: String, var xId: Int, var yId: Int)

class RigFolder(var id: Int, var name: String) { var open = true }

class Rig {
    var folders = mutableListOf<RigFolder>()
    var pfolders = mutableListOf<RigFolder>()   // parameter folders
    var links = mutableListOf<RigLink>()        // 2D linked parameter pads
    var folderOf = LinkedHashMap<Int, Int>()    // layer id -> folder id (absent = root)
    var params = mutableListOf<RigParam>()
    var bindings = mutableListOf<RigBinding>()
    var members = mutableListOf<Int>()          // layer ids imported into this rig group
    var phys = mutableListOf<PhysGroup>()
    var nextId = 1

    fun param(id: Int): RigParam? = params.firstOrNull { it.id == id }

    fun addParam(name: String, lo: Float, hi: Float, def: Float, g: Layer): RigParam {
        val p = RigParam(nextId, name, lo, hi, def); nextId += 1
        params.add(p)
        g.track(p.key).base = def
        return p
    }

    fun value(p: RigParam, g: Layer, t: Float): Float = g.p(p.key, t)

    /** Existing binding for (param, layer, key) or a new one with a zero key at the default. */
    fun binding(p: RigParam, layerId: Int, key: String, create: Boolean): RigBinding? {
        bindings.firstOrNull { it.paramId == p.id && it.layerId == layerId && it.key == key }?.let { return it }
        if (!create) return null
        val b = RigBinding(nextId, p.id, layerId, key, mutableListOf()); b.rest = p.def; nextId += 1
        bindings.add(b)
        return b
    }

    fun removeLayer(id: Int) {
        members.removeAll { it == id }
        folderOf.remove(id)
        bindings.removeAll { it.layerId == id }
    }

    fun removeParam(id: Int) { links.removeAll { it.xId == id || it.yId == id } }

    companion object {
        /** Set while a real-time (non-keyframed) pendulum is still moving; the editor re-renders on `onLiveTick`. */
        @Volatile var liveActive = false
        @Volatile var onLiveTick: (() -> Unit)? = null
        private var tickerRequested = false
        /** Must live on the MAIN looper (Rig.apply is also called from render threads). */
        @Synchronized fun startTicker() {
            if (tickerRequested) return
            tickerRequested = true
            val h = Handler(Looper.getMainLooper())
            val r = object : Runnable {
                override fun run() {
                    if (liveActive) { liveActive = false; onLiveTick?.invoke() }
                    h.postDelayed(this, 1000L / 60)
                }
            }
            h.post(r)
        }
        /** True when any rig group has an enabled physics group. */
        fun hasLivePhysics(layers: List<Layer>): Boolean {
            for (g in layers) { val r = g.rig ?: continue; for (pg in r.phys) if (pg.on) return true }
            return false
        }

        // MARK: apply (called before every frame is drawn)

        /** Members of a rig group = every layer below it in the timeline (children, folders, deformers). */
        private var lastSig = 0
        fun syncMembers(layers: List<Layer>) {
            var h = 1
            for (l in layers) { h = h * 31 + l.id; h = h * 31 + l.parentId; l.rig?.let { h = h * 31 + System.identityHashCode(it) } }
            val sig = h
            if (sig == lastSig) return
            lastSig = sig
            for (g in layers) {
                val r = g.rig ?: continue
                val inside = HashSet<Int>(); inside.add(g.id); var grew = true
                while (grew) {
                    grew = false
                    for (l in layers) if (!inside.contains(l.id) && inside.contains(l.parentId)) { inside.add(l.id); grew = true }
                }
                val ids = layers.filter { it.id != g.id && inside.contains(it.id) }.map { it.id }
                if (ids != r.members) r.members = ids.toMutableList()
            }
        }

        fun descendants(g: Layer, layers: List<Layer>): List<Layer> {
            val inside = HashSet<Int>(); inside.add(g.id); val out = ArrayList<Layer>(); var grew = true
            while (grew) {
                grew = false
                for (l in layers) if (!inside.contains(l.id) && inside.contains(l.parentId)) { inside.add(l.id); out.add(l); grew = true }
            }
            return out
        }

        fun apply(layers: List<Layer>, t: Float, live: Map<Int, Map<String, Float>> = emptyMap()) {
            var any = false
            for (l in layers) if (l.rig != null || l.warp != null) { any = true; break }
            if (!any) {
                for (l in layers) if (l.rigOff.isNotEmpty()) l.rigOff.clear()
                return
            }
            syncMembers(layers); startTicker()
            for (l in layers) { if (l.rigOff.isNotEmpty()) l.rigOff.clear(); if (l.warpOff.isNotEmpty()) l.warpOff.clear() }
            val byId = HashMap<Int, Layer>()
            for (l in layers) byId[l.id] = l
            for (g in layers) {
                val r = g.rig ?: continue
                val mem = HashSet(r.members)
                val ph = HashMap<Int, Float>()
                for (pg in r.phys) {
                    if (!pg.on) continue
                    val aa = pg.angles(g, r, t); val a0 = aa[0]
                    for (o in pg.outs) {
                        val p = r.param(o.paramId) ?: continue
                        val f = max(-o.limit, min(o.limit, aa[min(max(o.pend, 0), aa.size - 1)] * o.scale * pg.weight * (if (o.invert) -1f else 1f)))
                        ph[p.id] = (ph[p.id] ?: 0f) + f * (p.hi - p.lo) / 2
                        o.peak = max(o.peak * 0.985f, abs(f))
                    }
                    for (tg in pg.targets) {
                        val tl = byId[tg.layerId] ?: continue
                        val a = if (tg.delay > 0.001f) pg.angle(g, r, t - tg.delay) else a0
                        tl.rigOff["rotZ"] = (tl.rigOff["rotZ"] ?: 0f) + a * pg.weight * tg.deg
                    }
                }
                for (b in r.bindings) {
                    if (!mem.contains(b.layerId)) continue
                    val p = r.param(b.paramId) ?: continue
                    val target = byId[b.layerId] ?: continue
                    target.rigOff[b.key] = (target.rigOff[b.key] ?: 0f) + b.eval(g.p(p.key, t) + (ph[p.id] ?: 0f))
                }
            }
            fun depth(l: Layer): Int { var d = 0; var c = l; while (d < 50) { val p = byId[c.parentId] ?: break; d += 1; c = p }; return d }
            for (w in layers.filter { it.deformer == 1 }.sortedByDescending { depth(it) }) { w.warp?.let { applyWarp(w, it, layers, t) } }
            for ((id, d) in live) { val l = byId[id] ?: continue; for ((k, v) in d) l.rigOff[k] = v + (l.warpOff[k] ?: 0f) }
        }

        /** Warp deformer: bilinear control-grid offsets are added to the mesh pins of every image layer inside. */
        fun applyWarp(w: Layer, wp: Warp, layers: List<Layer>, t: Float) {
            val n = max(2, wp.n)
            val offs = FloatArray(n * n * 2); var moved = false
            for (k in 0 until n * n) {
                offs[2 * k] = w.p("wx$k", t); offs[2 * k + 1] = w.p("wy$k", t)
                if (offs[2 * k] != 0f || offs[2 * k + 1] != 0f) moved = true
            }
            if (!moved) return
            val mw = Xf.matrix(w, t)
            val invW = Xf.invert(mw) ?: return
            for (l in descendants(w, layers)) {
                if (l.type != LayerType.IMAGE) continue
                val pp = l.puppet ?: continue
                if (!pp.on || pp.pins.isEmpty()) continue
                val ml = Xf.matrix(l, t)
                val invL = Xf.invert(ml) ?: continue
                val (qw, qh) = Xf.quadSize(l)
                for (pin in pp.pins) {
                    val cx = (l.props["pp${pin.id}x"]?.eval(t) ?: 0f) + (l.rigOff["pp${pin.id}x"] ?: 0f)
                    val cy = (l.props["pp${pin.id}y"]?.eval(t) ?: 0f) + (l.rigOff["pp${pin.id}y"] ?: 0f)
                    val wpos = Xf.apply(ml, (pin.rx + cx) * qw / 2, (pin.ry + cy) * qh / 2)
                    val q = Xf.apply(invW, wpos.first, wpos.second)
                    val ru = (q.first - wp.bx) / max(wp.bw, 1e-4f); val rv = (q.second - wp.by) / max(wp.bh, 1e-4f)
                    // outside the grid the deformation fades out instead of dragging the whole layer along
                    val out = max(max(max(-ru, ru - 1), max(-rv, rv - 1)), 0f)
                    val fade = max(0f, 1 - out / 0.12f)
                    if (fade <= 0) continue
                    val u = wp.index(ru, false)
                    val v = wp.index(rv, true)
                    val i0 = min(n - 2, u.toInt()); val j0 = min(n - 2, v.toInt())
                    val fu = u - i0.toFloat(); val fv = v - j0.toFloat()
                    var dx = 0f; var dy = 0f
                    val di = intArrayOf(0, 1, 0, 1); val dj = intArrayOf(0, 0, 1, 1)
                    val wg = floatArrayOf((1 - fu) * (1 - fv), fu * (1 - fv), (1 - fu) * fv, fu * fv)
                    for (c in 0 until 4) {
                        val k = (j0 + dj[c]) * n + (i0 + di[c])
                        dx += offs[2 * k] * wg[c] * fade; dy += offs[2 * k + 1] * wg[c] * fade
                    }
                    // W-local displacement -> world -> layer-local
                    val wx = mw[0] * dx + mw[2] * dy; val wy = mw[1] * dx + mw[3] * dy
                    val lx = invL[0] * wx + invL[2] * wy; val ly = invL[1] * wx + invL[3] * wy
                    val kx = "pp${pin.id}x"; val ky = "pp${pin.id}y"
                    l.rigOff[kx] = (l.rigOff[kx] ?: 0f) + lx / (qw / 2); l.warpOff[kx] = (l.warpOff[kx] ?: 0f) + lx / (qw / 2)
                    l.rigOff[ky] = (l.rigOff[ky] ?: 0f) + ly / (qh / 2); l.warpOff[ky] = (l.warpOff[ky] ?: 0f) + ly / (qh / 2)
                }
            }
        }

        fun fromJson(o: JSONObject): Rig {
            val r = Rig()
            r.nextId = max(1, o.optI("nextId", 1))
            o.optJSONArray("params")?.let { pa ->
                for (i in 0 until pa.length()) {
                    val p = pa.optJSONObject(i) ?: continue
                    val rp = RigParam(p.optI("id", 0), p.optS("name", "Param"), p.optF("lo", 0f), p.optF("hi", 1f), p.optF("def", 0f))
                    rp.folder = p.optI("pf", 0)
                    r.params.add(rp)
                }
            }
            o.optJSONArray("bindings")?.let { ba ->
                for (i in 0 until ba.length()) {
                    val b = ba.optJSONObject(i) ?: continue
                    val ks = mutableListOf<RigKey>()
                    b.optJSONArray("keys")?.let { ka -> for (j in 0 until ka.length()) ka.optJSONObject(j)?.let { k -> ks.add(RigKey(k.optF("v", 0f), k.optF("o", 0f))) } }
                    val nb = RigBinding(b.optI("id", 0), b.optI("param", 0), b.optI("layer", 0), b.optS("key", "x"), ks)
                    val rv = b.optF("rest", -99999f)
                    nb.rest = if (rv > -99998f) rv else r.param(nb.paramId)?.def
                    r.bindings.add(nb)
                }
            }
            o.optJSONArray("members")?.let { ma -> for (i in 0 until ma.length()) r.members.add(ma.optI(i, 0)) }
            o.optJSONArray("phys")?.let { pa ->
                for (i in 0 until pa.length()) {
                    val q = pa.optJSONObject(i) ?: continue
                    val g = PhysGroup(q.optI("id", 0), q.optS("name", "Pendulum"))
                    g.on = q.optB("on", true)
                    g.length = q.optF("len", 0.5f); g.damping = q.optF("damp", 0.3f); g.strength = q.optF("str", 1f)
                    g.ease = q.optF("ease", 0.85f); g.reaction = q.optF("react", 0.5f); g.gravity = q.optF("grav", 1f); g.delay = q.optF("dly", 0f)
                    g.maxDeg = q.optF("max", 30f); g.weight = q.optF("wt", 1f); g.follow = q.optF("fol", 0.35f)
                    val ia = q.optJSONArray("ins")
                    if (ia != null) {
                        for (k in 0 until ia.length()) ia.optJSONObject(k)?.let { x ->
                            val pi = PhysIn(x.optI("p", 0), x.optF("infl", 100f)); pi.invert = x.optB("inv", false)
                            pi.useRange = x.optB("ur", false); pi.nmin = x.optF("nmin", -1f); pi.ncen = x.optF("ncen", 0f); pi.nmax = x.optF("nmax", 1f)
                            g.ins.add(pi)
                        }
                    } else if (q.optI("in", -1) >= 0) g.ins.add(PhysIn(q.optI("in", -1)))
                    val oa = q.optJSONArray("outs")
                    if (oa != null) {
                        for (k in 0 until oa.length()) oa.optJSONObject(k)?.let { x ->
                            val po = PhysOut(x.optI("p", 0), x.optF("sc", 1f)); po.invert = x.optB("inv", false); po.limit = x.optF("lim", 1f); po.pend = x.optI("pi", 0); g.outs.add(po)
                        }
                    } else if (q.optI("out", -1) >= 0) g.outs.add(PhysOut(q.optI("out", -1), 1f))
                    q.optJSONArray("pe")?.let { pe -> for (k in 0 until pe.length()) pe.optJSONObject(k)?.let { x ->
                        val pd = PhysPend(); pd.length = x.optF("len", 0.5f); pd.damping = x.optF("damp", 0.3f); pd.reaction = x.optF("react", 0.6f); g.pends.add(pd) } }
                    q.optJSONArray("tg")?.let { ta -> for (k in 0 until ta.length()) ta.optJSONObject(k)?.let { x -> g.targets.add(PhysTarget(x.optI("l", 0), x.optF("d", 0f), x.optF("dl", 0f))) } }
                    r.phys.add(g)
                }
            }
            o.optJSONArray("folders")?.let { fa -> for (i in 0 until fa.length()) fa.optJSONObject(i)?.let { f ->
                val rf = RigFolder(f.optI("id", 0), f.optS("name", "Folder")); rf.open = f.optB("open", true); r.folders.add(rf) } }
            o.optJSONArray("folderOf")?.let { fo -> for (i in 0 until fo.length()) fo.optJSONObject(i)?.let { e -> r.folderOf[e.optI("l", 0)] = e.optI("f", 0) } }
            o.optJSONArray("pfolders")?.let { fa -> for (i in 0 until fa.length()) fa.optJSONObject(i)?.let { f ->
                val rf = RigFolder(f.optI("id", 0), f.optS("name", "Folder")); rf.open = f.optB("open", true); r.pfolders.add(rf) } }
            o.optJSONArray("links")?.let { la -> for (i in 0 until la.length()) la.optJSONObject(i)?.let { k -> r.links.add(RigLink(k.optI("id", 0), k.optS("name", "Link"), k.optI("x", 0), k.optI("y", 0))) } }
            return r
        }
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.putL("nextId", nextId.toLong())
        val pa = JSONArray()
        for (p in params) pa.put(JSONObject().putL("id", p.id.toLong()).put("name", p.name).putF("lo", p.lo).putF("hi", p.hi).putF("def", p.def).putL("pf", p.folder.toLong()))
        o.put("params", pa)
        val ba = JSONArray()
        for (b in bindings) {
            val ka = JSONArray()
            for (k in b.keys) ka.put(JSONObject().putF("v", k.v).putF("o", k.o))
            ba.put(JSONObject().putL("id", b.id.toLong()).putL("param", b.paramId.toLong()).putL("layer", b.layerId.toLong()).put("key", b.key).put("keys", ka).putF("rest", b.rest ?: -99999f))
        }
        o.put("bindings", ba)
        val ma = JSONArray(); for (m in members) ma.put(m.toLong())
        o.put("members", ma)
        val pha = JSONArray()
        for (q in phys) {
            val ia = JSONArray(); val oa = JSONArray()
            for (i in q.ins) ia.put(JSONObject().putL("p", i.paramId.toLong()).putF("infl", i.influence).put("inv", i.invert).put("ur", i.useRange).putF("nmin", i.nmin).putF("ncen", i.ncen).putF("nmax", i.nmax))
            for (x in q.outs) oa.put(JSONObject().putL("p", x.paramId.toLong()).putF("sc", x.scale).putL("pi", x.pend.toLong()).putF("lim", x.limit).put("inv", x.invert))
            val pe = JSONArray(); for (x in q.pends) pe.put(JSONObject().putF("len", x.length).putF("damp", x.damping).putF("react", x.reaction))
            val ta = JSONArray(); for (x in q.targets) ta.put(JSONObject().putL("l", x.layerId.toLong()).putF("d", x.deg).putF("dl", x.delay))
            pha.put(JSONObject().putL("id", q.id.toLong()).put("name", q.name).put("on", q.on)
                .put("ins", ia).put("outs", oa).putF("len", q.length)
                .putF("damp", q.damping).putF("ease", q.ease).putF("react", q.reaction).putF("grav", q.gravity).putF("dly", q.delay)
                .putF("str", q.strength).putF("max", q.maxDeg).putF("wt", q.weight).putF("fol", q.follow)
                .put("pe", pe).put("tg", ta))
        }
        o.put("phys", pha)
        val fa = JSONArray(); for (f in folders) fa.put(JSONObject().putL("id", f.id.toLong()).put("name", f.name).put("open", f.open))
        o.put("folders", fa)
        val fo = JSONArray(); for ((l, f) in folderOf) fo.put(JSONObject().putL("l", l.toLong()).putL("f", f.toLong()))
        o.put("folderOf", fo)
        val pfa = JSONArray(); for (f in pfolders) pfa.put(JSONObject().putL("id", f.id.toLong()).put("name", f.name).put("open", f.open))
        o.put("pfolders", pfa)
        val la = JSONArray(); for (k in links) la.put(JSONObject().putL("id", k.id.toLong()).put("name", k.name).putL("x", k.xId.toLong()).putL("y", k.yId.toLong()))
        o.put("links", la)
        return o
    }
}

/** Warp deformer control grid (n x n points over a box in the deformer group's local space). */
class Warp {
    var n = 4
    var bx = -0.5f; var by = -0.5f; var bw = 1f; var bh = 1f
    var cu = mutableListOf<Float>(); var cv = mutableListOf<Float>()   // lattice lines (0...1) when the pen has made it non-uniform
    fun lineU(i: Int): Float = if (cu.size == n) cu[i] else i.toFloat() / max(n - 1, 1).toFloat()
    fun lineV(j: Int): Float = if (cv.size == n) cv[j] else j.toFloat() / max(n - 1, 1).toFloat()
    fun rest(k: Int): Pair<Float, Float> {
        val i = k % n; val j = k / n
        return Pair(bx + bw * lineU(i), by + bh * lineV(j))
    }
    /** Fractional lattice index for a 0...1 position along one axis. */
    fun index(r: Float, v: Boolean): Float {
        val c = if (r < 0) 0f else min(1f, r)
        for (i in 0 until n - 1) {
            val a = if (v) lineV(i) else lineU(i); val b = if (v) lineV(i + 1) else lineU(i + 1)
            if (c <= b || i == n - 2) return i.toFloat() + (if (b - a < 1e-6f) 0f else min(1f, max(0f, (c - a) / (b - a))))
        }
        return 0f
    }
    fun toJson(): JSONObject {
        val o = JSONObject().putL("n", n.toLong()).putF("bx", bx).putF("by", by).putF("bw", bw).putF("bh", bh)
        val a = JSONArray(); for (x in cu) a.putF(x)
        val b = JSONArray(); for (x in cv) b.putF(x)
        return o.put("cu", a).put("cv", b)
    }
    companion object {
        fun fromJson(o: JSONObject): Warp {
            val w = Warp()
            w.n = max(2, o.optI("n", 4)); w.bx = o.optF("bx", -0.5f); w.by = o.optF("by", -0.5f)
            w.bw = o.optF("bw", 1f); w.bh = o.optF("bh", 1f)
            o.optJSONArray("cu")?.let { a -> if (a.length() == w.n) w.cu = MutableList(a.length()) { a.optF(it, 0f) } }
            o.optJSONArray("cv")?.let { a -> if (a.length() == w.n) w.cv = MutableList(a.length()) { a.optF(it, 0f) } }
            return w
        }
    }
}
