package com.saiki.motion.core

import java.util.IdentityHashMap
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Port of Sources/Render/Scatter.swift — places copies of a 3D model on the surface of a target layer.
 * PARITY-NOTE(Scatter.swift:218): simd_quatf(from:to:) / simd_float4x4(quat) are Math3D substitutes — the same rotation, but the
 * quaternion sign / last-ulp rounding can differ from simd (no visible effect on placement).
 */
object Scatter {
    class Tri(val a: V3, val b: V3, val c: V3, val na: V3 = V3.ZERO, val nb: V3 = V3.ZERO, val nc: V3 = V3.ZERO)
    class P(val pos: V3, val n: V3, val r: FloatArray /*4*/, val r2: FloatArray /*2*/, val u: Float, val g: Float = 0f)

    private val PI = Math.PI.toFloat()

    // MARK: surfaces
    private val triCache = IdentityHashMap<GlbModel, List<Tri>>()
    @JvmStatic fun tris(g: GlbModel): List<Tri> {
        triCache[g]?.let { return it }
        val out = ArrayList<Tri>()
        for (p in g.prims) {
            if (p.verts.isEmpty() || p.mode != GlbModel.GL_TRIANGLES) continue
            val idx: IntArray = if (p.cpuIdx.isEmpty()) IntArray(p.verts.size / 12) { it } else p.cpuIdx
            fun v(i: Int): V3 { val b = i * 12; return V3(p.verts[b], p.verts[b + 1], p.verts[b + 2]) }
            fun nv(i: Int): V3 { val b = i * 12; return V3(p.verts[b + 3], p.verts[b + 4], p.verts[b + 5]) }
            var i = 0
            while (i + 2 < idx.size) {
                val a = v(idx[i]); val b = v(idx[i + 1]); val c = v(idx[i + 2])
                // winding follows the mesh's own vertex normals, so "up" is really up whatever the file's winding
                val fn = cross(b - a, c - a); val vn = nv(idx[i]) + nv(idx[i + 1]) + nv(idx[i + 2])
                if (dot(vn, vn) > 1e-6f && dot(fn, vn) < 0) out.add(Tri(a, c, b, nv(idx[i]), nv(idx[i + 2]), nv(idx[i + 1])))
                else out.add(Tri(a, b, c, nv(idx[i]), nv(idx[i + 1]), nv(idx[i + 2])))
                i += 3
            }
        }
        if (triCache.size > 8) triCache.clear()
        triCache[g] = out
        return out
    }
    /** Infinite-ish ground plane (world XZ at height y, facing up) — scatter target id -2. */
    @JvmStatic fun ground(size: Float, y: Float): List<Tri> {
        val s = max(size, 0.1f) / 2
        val a = V3(-s, y, s); val b = V3(s, y, s); val c = V3(s, y, -s); val d = V3(-s, y, -s)
        return listOf(Tri(a, b, c), Tri(a, c, d))
    }
    /** A flat image / video plane (local space, facing +Z). */
    @JvmStatic fun quad(w: Float, h: Float): List<Tri> {
        val x = max(w, 0.01f) / 2; val y = max(h, 0.01f) / 2
        val a = V3(-x, -y, 0f); val b = V3(x, -y, 0f); val c = V3(x, y, 0f); val d = V3(-x, y, 0f)
        return listOf(Tri(a, b, c), Tri(a, c, d))
    }

    // MARK: random + noise
    private class Rng(var s: Long) {
        fun f(): Float {
            s = s xor (s shl 13); s = s xor (s ushr 7); s = s xor (s shl 17)
            return (s ushr 40).toFloat() / 16777216f
        }
    }
    private fun hash(x: Int, y: Int, z: Int): Float {
        var h = x * 374761393 + y * 668265263 + z * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        return ((h xor (h ushr 16)) and 0xFFFF).toFloat() / 65535f
    }
    private fun noise(p: V3): Float {
        val fx = floor(p.x); val fy = floor(p.y); val fz = floor(p.z)
        val tx = p.x - fx; val ty = p.y - fy; val tz = p.z - fz
        val sx = tx * tx * (3f - 2 * tx); val sy = ty * ty * (3f - 2 * ty); val sz = tz * tz * (3f - 2 * tz)
        val i0 = fx.toInt(); val i1 = fy.toInt(); val i2 = fz.toInt()
        fun h(a: Int, b: Int, c: Int): Float = hash(i0 + a, i1 + b, i2 + c)
        val x00 = h(0, 0, 0) + (h(1, 0, 0) - h(0, 0, 0)) * sx; val x10 = h(0, 1, 0) + (h(1, 1, 0) - h(0, 1, 0)) * sx
        val x01 = h(0, 0, 1) + (h(1, 0, 1) - h(0, 0, 1)) * sx; val x11 = h(0, 1, 1) + (h(1, 1, 1) - h(0, 1, 1)) * sx
        val y0 = x00 + (x10 - x00) * sy; val y1 = x01 + (x11 - x01) * sy
        return y0 + (y1 - y0) * sz
    }

    // MARK: placement (cached until the settings / target change)
    private val keys = HashMap<Int, String>(); private val caches = HashMap<Int, List<P>>(); private val groupPts = HashMap<Int, List<V3>>()

    /** Lower-id scatter models on the same target that are on (group "avoid each other"). */
    private fun groupMates(l: Layer): List<Layer> {
        if (!(l.xf("scAvoid", 0f) > 0.5f)) return emptyList()
        val t = l.xf("scTarget", -1f)
        return Editor.scene.layers.filter { it.id < l.id && it.type == LayerType.MODEL && it.xf("scList", 0f) > 0.5f && it.xf("scOn", 0f) > 0.5f && it.xf("scTarget", -1f) == t }
    }
    private fun avoidSet(l: Layer): List<V3> = groupMates(l).flatMap { groupPts[it.id] ?: emptyList() }

    /** Scatter group: models with the same group number and target share ONE set of points (made by the lowest-id member,
     *  using its count / seed / slope / filters); each point goes to exactly one member, chosen by the members' weights. */
    private fun groupMembers(l: Layer): List<Layer> {
        val g = l.xf("scGroup", 0f)
        if (!(g > 0.5f)) return emptyList()
        val t = l.xf("scTarget", -1f)
        return Editor.scene.layers.filter { it.type == LayerType.MODEL && it.xf("scList", 0f) > 0.5f && it.xf("scOn", 0f) > 0.5f && it.xf("scGroup", 0f) == g && it.xf("scTarget", -1f) == t }.sortedBy { it.id }
    }

    @JvmStatic fun placements(l: Layer, tris: List<Tri>, targetM: M4): List<P> {
        val mem = groupMembers(l)
        val lead = mem.firstOrNull()
        if (mem.size <= 1 || lead == null) return basePlacements(l, tris, targetM)
        val all = basePlacements(lead, tris, targetM)
        val tw = mem.fold(0f) { acc, m -> acc + max(m.xf("scWeight", 1f), 0f) }
        if (!(tw > 1e-6f)) return emptyList()
        var lo = 0f
        for ((i, m) in mem.withIndex()) {
            val hi = if (i == mem.size - 1) 2f else lo + max(m.xf("scWeight", 1f), 0f) / tw
            if (m.id == l.id) { val a = lo; val b = hi; return all.filter { it.g >= a && it.g < b } }
            lo = hi
        }
        return emptyList()
    }

    private fun basePlacements(l: Layer, tris: List<Tri>, targetM: M4): List<P> {
        var key = "${l.id}|${l.x3s}|${tris.size}"
        if (l.xf("scAvoid", 0f) > 0.5f) key += "|av" + groupMates(l).joinToString(",") { "${it.id}:${groupPts[it.id]?.size ?: 0}:${((groupPts[it.id]?.firstOrNull()?.x ?: 0f) * 100).toInt()}" }
        for (c in 0 until 4) { val v = targetM.col(c); key += "|${(v.x * 500).toInt()},${(v.y * 500).toInt()},${(v.z * 500).toInt()}" }
        val ck = caches[l.id]
        if (keys[l.id] == key && ck != null) return ck
        val g = generate(l, tris, targetM)
        keys[l.id] = key; caches[l.id] = g; groupPts[l.id] = g.map { it.pos }
        return g
    }

    private fun mkP(rng: Rng, p: V3, n: V3, out: Int, count: Int): P {
        val r = floatArrayOf(rng.f(), rng.f(), rng.f(), rng.f()); val r2 = floatArrayOf(rng.f(), rng.f())
        return P(p, n, r, r2, out.toFloat() / max(count, 1).toFloat(), hash((p.x * 977).toInt(), (p.y * 977).toInt(), (p.z * 977).toInt()))
    }
    private fun dist(a: V3, b: V3) = length(a - b)

    private fun generate(l: Layer, tris: List<Tri>, M: M4): List<P> {
        if (tris.isEmpty()) return emptyList()
        val count = min((l.xf("scCount", 60f) * max(l.xf("scFreq", 1f), 0f) * max(l.xf("scMaster", 1f), 0f)).toInt(), 3000)
        if (count <= 0) return emptyList()
        // group: models set to "avoid each other" keep a minimum distance from the points of lower-id models on the same target
        val avoidPts = avoidSet(l)
        val avoidD = max(l.xf("scMinDist", 0.2f), 0.01f)
        val rng = Rng((max(1, l.xf("scSeed", 1f).toInt()).toLong() * 0x9E3779B97F4A7C15uL.toLong()) or 1L)
        val even = l.xf("scMode", 0f) >= 0.5f
        val minD = l.xf("scMinDist", 0.2f)
        val sMin = l.xf("scSlopeMin", 0f); val sMax = l.xf("scSlopeMax", 180f)
        val hMin = l.xf("scHMin", -100f); val hMax = l.xf("scHMax", 100f)
        val nScale = l.xf("scNoiseScale", 3f); val nThr = l.xf("scNoiseThr", 0f)
        val flip = if (l.xf("scFlip", 0f) >= 0.5f) -1f else 1f
        val jitter = l.xf("scJitter", 0f)
        // target -3: random points in an air box (clouds etc.), no surface needed
        if (l.xf("scTarget", -1f).toInt() == -3) {
            val sz = max(l.xf("scGroundSize", 10f), 0.1f) / 2; val ah = max(l.xf("scAirH", 4f), 0.01f) / 2; val cy = l.xf("scGroundY", 0f)
            val out = ArrayList<P>(); var tries = 0
            while (out.size < count && tries < count * 14) {
                tries += 1
                val px = (rng.f() * 2 - 1) * sz; val py = cy + (rng.f() * 2 - 1) * ah; val pz = (rng.f() * 2 - 1) * sz
                var p = V3(px, py, pz)
                if (nThr > 0 && noise(p * max(nScale, 0.01f)) < nThr) continue
                if (even && out.any { dist(it.pos, p) < minD }) continue
                if (avoidPts.isNotEmpty() && avoidPts.any { dist(it, p) < avoidD }) continue
                if (jitter > 0) { val jx = rng.f() - 0.5f; val jy = rng.f() - 0.5f; val jz = rng.f() - 0.5f; p = p + V3(jx, jy, jz) * jitter * 0.2f }
                out.add(mkP(rng, p, V3(0f, 1f, 0f), out.size, count))
            }
            return out
        }
        // world-space triangles + cumulative area
        val c0 = M.col(0).xyz(); val c1 = M.col(1).xyz(); val c2 = M.col(2).xyz()
        val det = dot(c0, cross(c1, c2))
        // normal matrix transpose(inverse(m3)) (cofactor form): correct under non-uniform scale
        val k0 = cross(c1, c2); val k1 = cross(c2, c0); val k2 = cross(c0, c1)
        val okInv = abs(det) > 1e-12f
        fun nw(v: V3): V3 {
            val r = if (okInv) (k0 * v.x + k1 * v.y + k2 * v.z) / det else (c0 * v.x + c1 * v.y + c2 * v.z)
            return if (length(r) > 1e-9f) normalize(r) else V3.ZERO
        }
        val smooth = l.xf("scSmooth", 1f) > 0.5f
        val cum = FloatArray(tris.size); var tot = 0f
        val wt = ArrayList<Tri>(tris.size)
        for ((ti, t) in tris.withIndex()) {
            fun w(v: V3): V3 { val r = M * V4(v.x, v.y, v.z, 1f); return V3(r.x, r.y, r.z) }
            val a = w(t.a); val b = w(t.b); val c = w(t.c)
            wt.add(Tri(a, b, c, nw(t.na), nw(t.nb), nw(t.nc)))
            tot += 0.5f * length(cross(b - a, c - a)); cum[ti] = tot
        }
        if (!(tot > 1e-9f)) return emptyList()
        val mirror = if (det < 0) -1f else 1f            // a mirrored target flips triangle winding
        val out = ArrayList<P>()
        var tries = 0
        while (out.size < count && tries < count * 14) {
            tries += 1
            val r = rng.f() * tot
            var lo = 0; var hi = cum.size - 1
            while (lo < hi) { val m = (lo + hi) / 2; if (cum[m] < r) lo = m + 1 else hi = m }
            val t = wt[lo]
            var u = rng.f(); var v = rng.f()
            if (u + v > 1) { u = 1 - u; v = 1 - v }
            var p = t.a + (t.b - t.a) * u + (t.c - t.a) * v
            var n = cross(t.b - t.a, t.c - t.a)
            if (length(n) < 1e-12f) continue
            n = normalize(n)
            if (smooth) {      // follow the ground's smooth vertex normals (hills, terrain) instead of its flat faces, on the same side as the face
                val sn = t.na * (1 - u - v) + t.nb * u + t.nc * v
                if (length(sn) > 1e-6f) { val s2 = normalize(sn); if (dot(s2, n) > 0.2f) n = s2 }
            }
            n = n * flip * mirror
            val slope = acos(max(-1f, min(1f, n.y))) * 180 / PI
            if (slope < sMin || slope > sMax) continue
            if (p.y < hMin || p.y > hMax) continue
            if (nThr > 0 && noise(p * max(nScale, 0.01f)) < nThr) continue
            if (even && out.any { dist(it.pos, p) < minD }) continue
            if (avoidPts.isNotEmpty() && avoidPts.any { dist(it, p) < avoidD }) continue
            if (jitter > 0) { val jx = rng.f() - 0.5f; val jy = rng.f() - 0.5f; val jz = rng.f() - 0.5f; p = p + V3(jx, jy, jz) * jitter * 0.2f }
            out.add(mkP(rng, p, n, out.size, count))
        }
        return out
    }

    // MARK: per-frame matrices
    private fun rot(deg: Float, axis: V3): M4 = M4.fromQuat(Quat.angleAxis(deg * PI / 180, axis))
    private fun scaleCol(m: M4, c: Int, s: Float) { val v = m.col(c); m.setCol(c, V4(v.x * s, v.y * s, v.z * s, v.w * s)) }

    /** World matrix of every instance (before the model's own centring / normalising). */
    @JvmStatic fun matrices(l: Layer, ps: List<P>, time: Float): List<M4> {
        val base = l.p("scale", time) * l.xf("scScale", 1f)
        val rnd = l.xf("scScaleRnd", 0.3f); val squash = l.xf("scSquash", 0f)
        val align = l.xf("scAlign", 1f); val yaw = l.xf("scYaw", 360f); val tilt = l.xf("scTilt", 0f)
        val lift = l.xf("scLift", 0f); val liftR = l.xf("scLiftRnd", 0f)
        val sway = l.xf("scSway", 0f); val swaySp = l.xf("scSwaySpeed", 1f)
        val grow = l.xf("scGrow", 0f); val stag = l.xf("scStagger", 0.5f)
        val fix = rot(l.xf("scRotZ", 0f), V3(0f, 0f, 1f)) * rot(l.xf("scRotX", 0f), V3(1f, 0f, 0f)) * rot(l.xf("scRotY", 0f), V3(0f, 1f, 0f))
        val up = V3(0f, 1f, 0f)
        val out = ArrayList<M4>(ps.size)
        for (p in ps) {
            var g = 1f
            if (grow > 0) { val x = max(0f, min(1f, (time - l.start - stag * p.u * grow) / grow)); g = x * x * (3 - 2 * x) }
            if (g <= 0.0005f) continue
            val s = max(0.001f, base * (1 + (p.r[2] - 0.5f) * 2 * rnd)) * g
            val sy = s * (1 + (p.r[3] - 0.5f) * 2 * squash)
            val dir = normalize(up * (1 - align) + p.n * align + V3(0f, 1e-5f, 0f))
            var R = M4.fromQuat(Quat.fromTo(up, dir))
            R = R * rot(p.r[0] * yaw, up) * rot((p.r[1] - 0.5f) * 2 * tilt, V3(1f, 0f, 0f))
            if (sway != 0f) {
                val a = sin((time * swaySp + p.r2[0] * 6.283f) * 6.283f) * sway
                R = R * rot(a, V3(1f, 0f, 0f)) * rot(a * 0.6f, V3(0f, 0f, 1f))
            }
            R = R * fix
            scaleCol(R, 0, s); scaleCol(R, 1, sy); scaleCol(R, 2, s)
            val pos = p.pos + p.n * (lift + (p.r2[1] - 0.5f) * 2 * liftR)
            R.setCol(3, V4(pos.x, pos.y, pos.z, 1f))
            out.add(R)
        }
        return out
    }

    /** Everything the renderers need in one call. null when scattering is off or has no valid target. */
    @JvmStatic fun instances(l: Layer, target: Layer?, tris: List<Tri>, targetM: M4, time: Float): List<M4>? {
        if (!(l.xf("scOn", 0f) > 0.5f) || target == null || tris.isEmpty()) return null
        val out = matrices(l, placements(l, tris, targetM), time)
        // Air / ground fields are anchored to the layer itself: moving the layer moves the whole field.
        // Applied here, after the cached placement, so dragging never regenerates it.
        val tid = l.xf("scTarget", -1f).toInt()
        if (tid == -2 || tid == -3) {
            val lt = l.editTime("x", time)
            val ox = l.p("x", lt); val oy = l.p("y", lt); val oz = Xf.worldZ(l, time)
            if (ox != 0f || oy != 0f || oz != 0f) for (m in out) { val c = m.col(3); m.setCol(3, V4(c.x + ox, c.y + oy, c.z + oz, c.w)) }
        }
        return out
    }
}
