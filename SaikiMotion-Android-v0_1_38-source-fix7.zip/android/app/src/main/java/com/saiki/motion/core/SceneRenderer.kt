package com.saiki.motion.core

import com.saiki.motion.render.SceneRendererN

import kotlin.math.*

// Port of Render/MetalSceneRenderer.swift (the live iOS render path) driving the Vulkan core.
// Behaviour reference: Render/SceneRenderer.swift (the GL legacy compositor — same layer pipeline,
// same constants/clamps/order; where the Metal file notes "port of GL x" the GL file is the spec).
//
// Native surface used (jni_bridge/jni_model + vk_core):
//   SceneRendererN.begin()/encodeQuadPass/composite/blit/clear/finish  (this slice's additions)
//   MetalModelRenderer.draw / MetalVolumeRenderer.draw / MetalFlare/MetalParticles/MetalGlow ports
// Everything below mirrors MetalSceneRenderer.swift:20-1210 line-for-line.

/** MetalSceneRenderer.swift:23 onVideoFrame: main-thread hook when a video layer gets a fresh frame. */
// (declared on SceneRenderer companion)

private class MBPlan(var samples: Int = 1, var shutter: Float = 0f, var amount: Float = 0f)

object SceneRenderer {
    // == MetalSceneRenderer statics ==
    /** Called on the main thread when a video layer got a fresh frame (preview redraw trigger). */
    @JvmField var onVideoFrame: (() -> Unit)? = null
    /** Called on the main thread after a GPU fault so the preview can redraw from clean targets. */
    @JvmField var onFault: (() -> Unit)? = null
    /** Effects that need GL-only machinery. Empty since stage 5b (Deep Glow now runs in MetalGlow). */
    val glOnlyEffects: Set<String> = emptySet()
    /** Working resolution override (SceneRenderer.size / sizeOverride, SceneRenderer.swift:87). */
    @JvmField var sizeOverride: IntArray? = null
    /** Scene Setup orbit camera [fov°, eyeX, eyeY, eyeZ, rotX°, rotY°] (SceneRenderer.swift:2109 editCam). */
    var editCam: FloatArray? = null
    /** 3D editor volume overlay: non-volume layers only feed occlusion (MetalSceneRenderer.swift:233). */
    @JvmField var occlusionOnly = false
    /** GL flare shader did not compile: flares are drawn by the Metal/Vulkan renderer instead (SceneRenderer.swift:55). */
    @Volatile var flareGLFailed = false
    /** True while an export render is running — SceneRenderer.swift isExport read by the effect guard
     *  (export waits for the quick test via EffectGuard.clearedWaiting instead of skipping). */
    @Volatile var isExporting = false
    /** The preview's renderer, so the editor overlay projects gizmos like the shader (SceneRenderer.swift:726 gizmoSource). */
    @JvmField var gizmoSource: SceneRendererInstance? = null

    val shared: SceneRendererInstance? by lazy { SceneRendererInstance() }

    /** SceneRenderer.swift:86 size(project:quality:) — height 1024/quality, width by aspect. */
    fun size(project: Project, quality: Int): IntArray {
        sizeOverride?.let { return it }
        val ar = project.w.toFloat() / max(project.h, 1).toFloat()
        val h = 1024 / max(1, quality)
        return intArrayOf(max(2, (h.toFloat() * ar).toInt()), h)
    }
}

class SceneRendererInstance internal constructor() {
    var quality = 1
    /** Export renders use the full motion-blur sample budget (mirrors SceneRenderer.isExport). */
    var isExport = false
    var width = 576; private set
    var height = 1024; private set
    /** Why the last renderFrame() returned false ("" when it rendered). */
    var lastFallbackReason = ""; private set
    var buildError: String? = null; private set

    // targets (MetalSceneRenderer.swift:41-58)
    private var sceneT: MetalTarget? = null
    private var scratchT: MetalTarget? = null
    private var layerA: MetalTarget? = null
    private var layerB: MetalTarget? = null
    private var accumT: MetalTarget? = null
    private var groupT: MetalTarget? = null
    private var groupAccT: MetalTarget? = null
    private var curBackdropTex: Long = 0L
    private var bgCopyT: MetalTarget? = null
    private var hazeT: MetalTarget? = null
    private var fxSnapT: MetalTarget? = null
    private var inT0: MetalTarget? = null
    private var inT1: MetalTarget? = null
    private var warpT: MetalTarget? = null
    private var liveGrp = HashMap<Int, Pair<String, MetalTarget>>()
    private val glow = MetalGlow
    internal val models = MetalModelRenderer()
    private val volumes = MetalVolumeRenderer()
    private val particles = MetalParticlesRenderer
    private val flares = MetalFlareRenderer
    private var glowBlurComp = 1f
    private var groupPool = ArrayList<MetalTarget>()
    private var groupDepth = 0
    private val images = MetalImageCache
    private var samplers = HashMap<Int, VideoFrames.Sampler>()
    private var recording = false
    // pre-rendered group frame cache (MetalSceneRenderer.swift:559-583)
    private var preTex = HashMap<String, Long>()
    private var preOrder = ArrayList<String>()
    private var preBusy = HashSet<String>()
    private val preLock = Object()
    private val preQueue = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "saiki.prerender.prefetch") }
    private val preBytes: Int get() = width * height * 4

    val ready: Boolean get() = SceneRendererN.ready()

    fun trimMemory() { images.flush(); trimPreCache(); glow.trimMemory(); models.trimMemory(); volumes.trimMemory(); flares.trimMemory() }

    /** SceneRenderer.swift:1208 warm: loads a freshly imported model / volume right away (on the import
     *  toast) so the first frame doesn't stall while the file is parsed. */
    fun warm(path: String) {
        if (path.lowercase().endsWith(".vdb")) VdbVolume.load(path) else models.loadModel(path)
    }
    fun releaseVideos() { samplers.clear() }

    /** SceneRenderer.swift:738 gizmoProject: layer-local quad points → world (x, y) as drawn on screen
     *  (3D layers go through rotX/rotY, z and the camera, same maths as the quad vertex shader). */
    fun gizmoProject(l: com.saiki.motion.core.Layer, time: Float, pts: List<Pair<Float, Float>>): List<Pair<Float, Float>> {
        val m = Xf.matrix(l, time)
        if (!l.is3d) return pts.map { Xf.apply(m, it.first, it.second) }
        // SceneRenderer.swift:741-746: 3D layers rotate their quad points about the layer origin
        // (Z rotation is already in the matrix), then z + the camera VP are applied.
        val lt = l.editTime("x", time)
        val d = Math.PI.toFloat() / 180f
        val rx = l.p("rotX", lt) * d
        val ry = -l.p("rotY", lt) * d
        var z = Xf.worldZ(l, time)
        if (!z.isFinite()) z = 0f
        var vp = MetalCam.vp(l, time, width, height)          // SceneRenderer.swift:2123 cameraVP (editCam / nearest camera)
        if (vp != null && !vp.all { it.isFinite() }) vp = null // SceneRenderer.swift:2091 broken camera: draw flat, never vanish
        val ar = width.toFloat() / max(height, 1).toFloat()
        val cx0 = m[4]; val cy0 = m[5]
        val cy = cos(ry); val sy = sin(ry)
        val cx = cos(rx); val sx = sin(rx)
        val out = ArrayList<Pair<Float, Float>>(pts.size)
        for (p in pts) {
            val w = Xf.apply(m, p.first, p.second)
            var ox = w.first - cx0; val oy = w.second - cy0; var oz = 0f
            // SceneRenderer.swift:753-756: yaw first, then pitch, about (cx0, cy0)
            val ox1 = ox * cy + oz * sy
            val oz1 = -ox * sy + oz * cy
            val oy1 = oy * cx - oz1 * sx
            val oz2 = oy * sx + oz1 * cx
            ox = ox1
            val px = cx0 + ox; val py = cy0 + oy1; val pz = oz2 + z
            if (vp != null) {
                // SceneRenderer.swift:758-763: through the camera VP; NDC x scaled back to world units
                val cw = max(vp[3] * px + vp[7] * py + vp[11] * pz + vp[15], 0.02f)
                val nx = (vp[0] * px + vp[4] * py + vp[8] * pz + vp[12]) / cw
                val ny = (vp[1] * px + vp[5] * py + vp[9] * pz + vp[13]) / cw
                out.add(Pair(nx * ar, ny))
            } else {
                // SceneRenderer.swift:764-765: default z = 3 perspective, w clamped so gizmos never vanish
                val wv = max(1f - pz / 3f, 0.02f)
                out.add(Pair(px / wv, py / wv))
            }
        }
        return out
    }

    // MARK: - eligibility (MetalSceneRenderer.swift:104-146)

    /** Flares are light: with the default blend they add onto the scene instead of covering it. */
    private fun flareMode(l: Layer): Int = if (l.type == LayerType.FLARE) { if (l.blend == 2) 2 else 1 } else l.blend

    private fun isVdb(l: Layer): Boolean = l.type == LayerType.MODEL && (l.imagePath ?: "").lowercase().endsWith(".vdb")

    /** Volumes draw after every other layer (stable), like GL vdbLast. Water last: reads depth + picture below. */
    private fun vdbLast(ls: List<Layer>): List<Layer> {
        fun isW(l: Layer) = l.type == LayerType.MODEL && l.xf("water", 0f) > 0.5f
        val isF: (Layer) -> Boolean = { it.type == LayerType.FLARE }
        if (ls.none { isVdb(it) || isW(it) || isF(it) }) return ls
        return ls.filter { !isVdb(it) && !isW(it) && !isF(it) } + ls.filter { isVdb(it) } + ls.filter { isW(it) } + ls.filter { isF(it) }
    }

    /** null when the whole frame can render; otherwise the reason it can't. */
    fun ineligibleReason(scene: Scene, time: Float): String? {
        for (l in scene.layers) {
            if (!l.visible || time < l.start - 0.001f || time > l.end + 0.001f) continue
            when (l.type) {
                LayerType.FLARE -> if (!flares.ready) {
                    // GL flare shader did not compile / pipeline missing: mark it so the Vulkan path owns flares
                    // (iOS SceneRenderer.swift:2710 flareGLFailed + EffectCrashLog twin).
                    if (!SceneRenderer.flareGLFailed) {
                        SceneRenderer.flareGLFailed = true
                        EffectCrashLog.writeLog("optical_flare", "Optical Flare", "shader-compile-error", "first render", "GL shader failed: flare pipeline not available", markBroken = false)
                    }
                    return "flare shader not ready"
                }
                LayerType.PARTICLES -> if (!particles.ready) return "particle shader not ready"
                LayerType.MODEL -> if (isVdb(l)) { if (!SceneRendererN.pipelineReady("vdb.frag")) return "volume shader not ready" }
                                   else if (!modelsReady()) return "model shader not ready"
                else -> {}
            }
            if (l.type == LayerType.SHAPE && Xf.isParticles(l) && !particles.ready) return "particle shader not ready"
            for (entry in l.fx) {
                if (l.fxOff.contains(entry)) continue
                val d = Registry.get(entry) ?: continue
                if (d.passes.isNotEmpty()) return "GL-only plugin ${d.id}"
                if (SceneRenderer.glOnlyEffects.contains(d.id)) return "GL-only effect ${d.id}"
            }
        }
        return null
    }

    private fun modelsReady() = SceneRendererN.pipelineReady("model.frag")

    // MARK: - frame entry (MetalSceneRenderer.swift:148-215)

    /** Encodes the whole frame. false = this frame cannot render (see lastFallbackReason). */
    fun renderFrame(project: Project, scene: Scene, time: Float): Boolean {
        discardFrame()
        if (!ready) { lastFallbackReason = "Metal scene shaders not ready"; return false }
        Rig.apply(scene.layers, time)
        models.depthDirty = true
        val r = ineligibleReason(scene, time)
        if (r != null) { lastFallbackReason = r; return false }
        ensureTargets(project)
        val st = sceneT ?: run { lastFallbackReason = "no command buffer"; return false }
        if (!SceneRendererN.begin()) { lastFallbackReason = "no command buffer"; return false }
        recording = true
        groupDepth = 0

        val bg = scene.bg
        clearTarget(st, ((bg ushr 16) and 0xFF) / 255f, ((bg ushr 8) and 0xFF) / 255f, (bg and 0xFF) / 255f, 1f)
        val visited = HashSet<Layer>()
        for (l in vdbLast(scene.layers)) {
            if (l.parentId >= 0) {
                val par = scene.layers.firstOrNull { it.id == l.parentId }
                if (par != null && par.type == LayerType.GROUP) continue
            }
            drawLayer(l, project, scene, time, st, visited)
        }
        lastFallbackReason = ""
        return true
    }

    /** Blits the encoded frame to the swapchain and commits. false = nothing shown. */
    private var stalls = 0

    fun presentFrame(): Boolean {
        val st = sceneT ?: return false
        if (!recording) return false
        val ok = SceneRendererN.present(st.handle)
        recording = false
        if (ok) { stalls = 0; return true }
        // Present failed (GPU behind / surface gone). Keep the last picture on screen and retry shortly -
        // never fall back to another renderer / stop redrawing (MetalPreview.swift presentFrame twin).
        stalls += 1
        if (stalls >= 20) { recover(); stalls = 0 }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ SceneRenderer.onFault?.invoke() }, 50)
        return true
    }

    /** Commits the encoded frame, waits for the GPU and returns it as a bitmap (offscreen path). */
    fun snapshotFrame(): android.graphics.Bitmap? {
        val st = sceneT ?: return false.let { null }
        if (!recording) return null
        SceneRendererN.finish()
        recording = false
        return SceneRendererN.readTarget(st.handle)
    }

    /** Drops every cached target + any half-encoded frame. The next frame rebuilds them (cures a poisoned preview after lag). */
    fun recover() {
        discardFrame()
        sceneT = null
    }

    fun discardFrame() {
        if (recording) { SceneRendererN.finish(); recording = false }
    }

    /** One-shot offscreen render for thumbnails / the frame cache. nil = cannot render. */
    fun thumbnail(project: Project, scene: Scene, time: Float, quality: Int): android.graphics.Bitmap? {
        this.quality = quality
        if (!renderFrame(project, scene, time)) return null
        return snapshotFrame()
    }

    /** 3D editor: renders only `layers` (VDB volumes) through `vp`. nil = caller keeps its fallback. */
    fun volumeOverlay(layers: List<Layer>, vp: FloatArray, time: Float, quality: Int, size: IntArray?, full: Boolean): android.graphics.Bitmap? {
        val sc = Scene("vdb-overlay")
        sc.layers = layers.toMutableList(); sc.fov = Editor.scene.fov; sc.bg = 0xFF000000.toInt()
        val oldQ = this.quality
        this.quality = quality
        MetalCam.vpOverride = vp
        SceneRenderer.occlusionOnly = !full
        SceneRenderer.sizeOverride = size
        try {
            if (!renderFrame(Editor.project, sc, time)) return null
            return snapshotFrame()
        } finally {
            MetalCam.vpOverride = null
            SceneRenderer.occlusionOnly = false
            SceneRenderer.sizeOverride = null
            this.quality = oldQ
        }
    }

    // MARK: - targets (MetalSceneRenderer.swift:249-276)

    private fun ensureTargets(project: Project) {
        val sz = SceneRenderer.size(project, quality)
        width = sz[0]; height = sz[1]
        val st = sceneT
        if (st == null || st.width != width || st.height != height) {
            sceneT = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
            scratchT = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
            layerA = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
            layerB = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
            accumT = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
            groupT = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
            groupAccT = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
            warpT = null
            fxSnapT = null; inT0 = null; inT1 = null
            liveGrp.clear()
            groupPool.clear()
        }
    }

    private fun poolTarget(d: Int): MetalTarget {
        while (groupPool.size <= d) groupPool.add(MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false))
        return groupPool[d]
    }

    private fun clearTarget(t: MetalTarget, r: Float = 0f, g: Float = 0f, b: Float = 0f, a: Float = 0f) {
        SceneRendererN.clear(t.handle, r, g, b, a)
    }

    // MARK: - per layer (MetalSceneRenderer.swift:278-351)

    private fun drawLayer(l: Layer, project: Project, scene: Scene, time: Float, target: MetalTarget, visited: HashSet<Layer>) {
        if (!l.visible || time < l.start - 0.001f || time > l.end + 0.001f) return
        curBackdropTex = target.tex     // Copy Background reads the composite below this layer
        if (SceneRenderer.occlusionOnly && !isVdb(l)) {
            // fills the shared model depth so volumes behind this model are hidden; colour is thrown away
            if (l.type == LayerType.MODEL) {
                val a = layerA ?: return
                clearTarget(a); models.draw(l, time, Editor.scene.fov, a)
            }
            return
        }
        if (visited.contains(l)) return
        visited.add(l)
        try {
            when (l.type) {
                LayerType.AUDIO, LayerType.CAMERA, LayerType.NULL -> return
                LayerType.GROUP -> {
                    if (Xf.isPlaneGroup(l)) {
                        drawPreRenderedGroup(l, project, scene, time, target, visited)
                    } else if (l.mask == 0 && (l.mblur || (Xf.camera(l)?.mblur ?: false))) {
                        val img = blurredGroupImage(l, project, scene, time, visited)
                        if (img != null) composite(target, img.tex, alpha = l.p("opacity", time), mode = l.blend)
                    } else {
                        drawGroup(l, project, scene, time, target, visited)
                    }
                    return
                }
                else -> {}
            }

            val tw = twitchRetime(l, project, time)
            val opacity = l.p("opacity", l.editTime("opacity", tw))
            val moveFx = movingFx(l, tw)
            val mb = motionBlurPlan(l, tw, moveFx)
            if (l.is3d && l.type != LayerType.ADJUST &&
                l.fx.any { !l.fxOff.contains(it) && Registry.get(it)?.id == "motiontile" }) {
                // Motion Tile on a 3D layer: tile the layer flat, then place the tiled plane in 3D
                val savedCam = SceneRenderer.editCam
                SceneRenderer.editCam = null
                Xf.flatDraw = true; Xf.bakingPlane = true; Xf.bakeRoot = l.id
                renderLayerContent(l, tw, target)
                applyEffects(l, tw)
                Xf.flatDraw = false; Xf.bakingPlane = false; Xf.bakeRoot = -1
                SceneRenderer.editCam = savedCam
                layerA?.let { placePlane(l, it.tex, tw, target, opacity) }
                return
            }
            if (mb.samples > 1) {
                val acc = accumT
                if (acc != null) { drawMotionBlurred(l, mb, moveFx, tw, opacity, acc, target); return }
            } else if ((l.type == LayerType.IMAGE || l.type == LayerType.VIDEO) && l.blend == 0 && l.mask == 0 && l.clipIds.isEmpty() && l.fxChain().isEmpty()
                       && nearerOccluders(l, scene, tw, visited).isEmpty() && !planeUsesDepth(l, scene)) {
                // fast path: one blended quad straight into the target
                if (opacity <= 0.0005f) return
                drawMedia(l, tw, opacity, target, clear = false, blend = true)
                return
            }
            renderLayerContent(l, tw, target)
            applyEffects(l, tw)
            cutByNearer3D(l, scene, tw, visited)
            clipByMasks(l, scene, tw, visited)
            val a = layerA; val b = layerB
            if (a != null && b != null && planeUsesDepth(l, scene)) {
                if (models.occludePlane(l, tw, a, b)) blit(b.tex, a)
            }
            if (l.type == LayerType.ADJUST && opacity >= 0.999f && l.blend == 0 && l.mask == 0 && l.clipIds.isEmpty() && l.fxChain().isNotEmpty()) {
                // An adjustment layer REPLACES what is below it. Compositing its result "over" the original left
                // the untouched picture visible behind shaken / tiled / moved pixels (two layers showing).
                // The Vulkan blit pass draws with blending disabled (iOS glDisable(GL_BLEND) twin).
                layerA?.let { blit(it.tex, target) }
            } else {
                layerA?.let { composite(target, it.tex, alpha = opacity, mode = flareMode(l)) }
            }
        } finally {
            visited.remove(l)
        }
    }

    /** Nearer occluding 3D layers (media planes, models, VDB volumes) that should cut layer `l`. */
    private fun nearerOccluders(l: Layer, scene: Scene, time: Float, visited: Set<Layer>): List<Layer> {
        if (!l.occlude || !(l.is3d || l.type == LayerType.MODEL) || Xf.flatDraw) return emptyList()
        val z = Xf.worldZ(l, time)
        val depthModel = l.type == LayerType.MODEL && !isVdb(l)
        val depthPlane = l.type != LayerType.MODEL && l.is3d && !isVdb(l)
        return scene.layers.filter { o ->
            if ((depthModel || depthPlane) && o.occlude && ((depthModel && o.type != LayerType.MODEL && o.is3d) || (depthPlane && o.type == LayerType.MODEL && !isVdb(o)))) return@filter false
            o !== l && o.visible && o.occlude && (o.is3d || o.type == LayerType.MODEL) && o.type != LayerType.ADJUST
                && o.parentId == l.parentId && o.isRenderable() && o.type != LayerType.PARTICLES && o.type != LayerType.FLARE
                && time >= o.start - 0.001f && time <= o.end + 0.001f && !visited.contains(o)
                && Xf.worldZ(o, time) > z + 0.001f && o.p("opacity", time) > 0.5f
                && !(depthModel && o.type == LayerType.MODEL && !isVdb(o))
        }
    }

    /** A 3D image / video plane that must take part in the shared model depth buffer. */
    private fun planeUsesDepth(l: Layer, scene: Scene): Boolean {
        if (!l.occlude || !l.is3d || l.type == LayerType.MODEL || Xf.flatDraw || SceneRenderer.occlusionOnly) return false
        return scene.layers.any { it.type == LayerType.MODEL && it.visible && it.occlude && !isVdb(it) }
    }

    /** Live2D-style clipping mask (port of the GL clipByMasks): layerA kept only where mask layers have pixels. */
    private fun clipByMasks(l: Layer, scene: Scene, time: Float, visited: HashSet<Layer>) {
        val a = layerA ?: return; val b = layerB ?: return; val c = accumT ?: return
        if (l.clipIds.isEmpty()) return
        val ms = scene.layers.filter { m ->
            l.clipIds.contains(m.id) && m !== l && m.isRenderable() && !visited.contains(m)
                && time >= m.start - 0.001f && time <= m.end + 0.001f }
        if (ms.isEmpty()) return
        blit(a.tex, c)                                                    // snapshot of the layer
        clearTarget(b)
        for (m in ms) {
            renderLayerContent(m, time, a)                                // mask -> layerA
            composite(b, a.tex, alpha = 1f, mode = 0)
        }
        clearTarget(a)
        composite(a, c.tex, mask = b.tex, maskMode = if (l.clipInv) 2 else 1, alpha = 1f, mode = 0)
    }

    private fun cutByNearer3D(l: Layer, scene: Scene, time: Float, visited: HashSet<Layer>) {
        val occ = nearerOccluders(l, scene, time, visited)
        val a = layerA ?: return; val b = layerB ?: return; val c = accumT ?: return
        if (occ.isEmpty()) return
        blit(a.tex, c)                                                    // snapshot of the layer
        for (o in occ) {
            renderLayerContent(o, time, a)                                // occluder -> layerA
            blit(a.tex, b)                                                // its silhouette
            clearTarget(a)
            composite(a, c.tex, mask = b.tex, maskMode = 2, alpha = 1f, mode = 0)
            blit(a.tex, c)
        }
    }

    // MARK: - motion blur (MetalSceneRenderer.swift:404-519)

    /** Effects that move the picture themselves; blurred by evaluating the effects at every sample. */
    private fun movingFx(l: Layer, time: Float): Boolean {
        for (e in l.fx) {
            if (l.fxOff.contains(e)) continue
            when (Registry.get(e)?.id) {
                "oscillate", "randisp", "sshake", "autoshake" -> return true
                "motiontile" -> if (l.p(e + "__mtScrollX", time) != 0f || l.p(e + "__mtScrollY", time) != 0f) return true
                "twitch" -> if (l.p(e + "__twEnSlide", time) >= 0.5f || l.p(e + "__twEnScale", time) >= 0.5f) return true
                else -> {}
            }
        }
        return false
    }

    private fun mbJitter(s: Int, time: Float): Float {
        var h = (s * 73856093).toUInt() xor ((time * 1000).toInt() * 19349663).toUInt()
        h = ((h xor (h shr 13)) * 1274126177u)
        h = h xor (h shr 16)
        return (h and 0xFFFFu).toFloat() / 65536f
    }

    /** Max on-screen distance (pixels) a quad corner/centre travels over the shutter. */
    private fun screenTravel(l: Layer, time: Float, shutter: Float): Float {
        var (qw, qh) = Xf.quadSize(l)
        val isPart = l.type == LayerType.PARTICLES || l.fx.contains("particles") || l.fx.contains("bccstrands") || l.fx.contains("particular")
        if (isPart) { qw *= 2.5f; qh *= 2.5f }
        val useCam = l.is3d || (isPart && Xf.camera(l) != null)
        val ar = width.toFloat() / max(height, 1).toFloat()
        val halfW = width * 0.5f; val halfH = height * 0.5f
        fun proj(t: Float, cx: Float, cy: Float): Pair<Float, Float>? {
            val m = Xf.matrix(l, t)
            val x = cx * qw; val y = cy * qh
            val wx = m[0] * x + m[2] * y + m[4]; val wy = m[1] * x + m[3] * y + m[5]
            if (useCam) {
                val z = Xf.worldZ(l, t)
                val vp = MetalCam.vp(l, t, width, height)
                if (vp != null) {
                    val cw = vp[3] * wx + vp[7] * wy + vp[11] * z + vp[15]
                    if (cw < 0.02f) return null
                    return Pair((vp[0] * wx + vp[4] * wy + vp[8] * z + vp[12]) / cw,
                                (vp[1] * wx + vp[5] * wy + vp[9] * z + vp[13]) / cw)
                }
                val w = 1 - z / 3
                if (w < 0.02f) return null
                return Pair(wx / ar / w, wy / w)
            }
            return Pair(wx / ar, wy)
        }
        var best = 0f
        val pts = listOf(Pair(-0.5f, -0.5f), Pair(0.5f, -0.5f), Pair(-0.5f, 0.5f), Pair(0.5f, 0.5f), Pair(0f, 0f))
        for ((cx, cy) in pts) {
            val a = proj(time - shutter * 0.5f, cx, cy) ?: continue
            val b = proj(time + shutter * 0.5f, cx, cy) ?: continue
            val dx = (a.first - b.first) * halfW; val dy = (a.second - b.second) * halfH
            best = max(best, sqrt(dx * dx + dy * dy))
        }
        return best
    }

    private fun motionBlurPlan(l: Layer, time: Float, moveFx: Boolean): MBPlan {
        val plan = MBPlan()
        if (!(l.mblur || (Xf.camera(l)?.mblur ?: false))) return plan
        plan.amount = l.p("mbAmount", time)
        plan.shutter = 0.12f * plan.amount
        val cap = min(max(2f, l.p("mbSamples", time)), 64f).toInt()
        val camMoves = (Xf.camera(l) != null) && (l.is3d || l.type == LayerType.MODEL || l.type == LayerType.PARTICLES)
        val hasParticles = Xf.isParticles(l)
        val content = l.type == LayerType.VIDEO || l.type == LayerType.PARTICLES || l.type == LayerType.MODEL || l.type == LayerType.FLARE || l.fxChain().isNotEmpty() || camMoves
        val px = screenTravel(l, time, plan.shutter)
        var n = 1
        if (px >= 0.5f) {
            n = min(if (hasParticles) (if (isExport) 32 else 6) else (if (isExport) 64 else 10),
                    max(if (isExport) 8 else 4, ceil(px).toInt() / (if (isExport) 1 else 2) + 1))
        } else if (content && !hasParticles && l.type != LayerType.ADJUST && l.type != LayerType.IMAGE && l.type != LayerType.TEXT && l.type != LayerType.SHAPE && l.type != LayerType.FLARE && l.type != LayerType.MODEL) {
            n = min(cap, if (isExport) 6 else 3)      // only video (internal motion) needs averaging when nothing moves
        }
        if (l.type == LayerType.ADJUST) n = 1          // averaging copies of the scene only dims glow/bloom
        else if (moveFx) n = max(n, if (isExport) 96 else 12)
        plan.samples = n
        return plan
    }

    private fun drawMotionBlurred(l: Layer, plan: MBPlan, moveFx: Boolean, time: Float, opacity: Float, acc: MetalTarget, target: MetalTarget) {
        val a = layerA ?: return
        val n = plan.samples
        if (Xf.isParticles(l)) particles.simTime = time
        try {
            clearTarget(acc)
            for (s in 0 until n) {
                models.depthDirty = true
                val u = (s.toFloat() + mbJitter(s, time)) / n.toFloat()
                var st = time - plan.shutter * (u - 0.5f)
                if (l.mbStutter) st = time - plan.shutter * 0.5f * roundAway(s.toFloat() / max(n - 1, 1).toFloat() - 0.5f)
                val t = min(max(st, l.start), l.end)
                renderLayerContent(l, t, target)
                if (moveFx) applyEffects(l, t)
                composite(acc, a.tex, alpha = 1f / (s + 1).toFloat(), mode = 5,
                          rgbShift = if (l.mbRgb) (u - 0.5f) * 0.004f * plan.amount else 0f)
            }
            if (l.fxChain().isNotEmpty() && !moveFx) {
                // effects run once on the blurred result; blurred content is dimmer, so keep Deep Glow's strength
                glowBlurComp = 2.4f
                try {
                    blit(acc.tex, a)
                    applyEffects(l, time)
                    composite(target, a.tex, alpha = opacity, mode = flareMode(l))
                } finally { glowBlurComp = 1f }
            } else {
                composite(target, acc.tex, alpha = opacity, mode = flareMode(l))
            }
        } finally {
            particles.simTime = null
        }
    }

    // MARK: - groups (MetalSceneRenderer.swift:521-552)

    /** A precomp renders its children into a private buffer, then mask, group effects, opacity and blend. */
    private fun drawGroup(g: Layer, project: Project, scene: Scene, time: Float, target: MetalTarget, visited: HashSet<Layer>) {
        val children = scene.layers.filter { it.parentId == g.id }
        if (children.isEmpty()) return
        val opacity = g.p("opacity", time)
        val hasFx = g.fx.isNotEmpty()
        val hasPuppet = (g.puppet?.on ?: false) && !(g.puppet?.pins?.isEmpty() ?: true)
        if (!(g.precomp || Xf.has3DContent(g) || g.mask != 0 || hasFx || hasPuppet) || groupDepth >= 4) {
            for (c in vdbLast(children)) drawLayer(c, project, scene, time, target, visited)
            return
        }
        val img = precompImage(g, children, project, scene, time, visited)
        if (img != null) {
            var src = img.tex
            if (hasPuppet) warpGroupImage(g, img.tex, time)?.let { src = it }
            composite(target, src, alpha = opacity, mode = g.blend)
        }
    }

    /** Puppet on a group: draws the flattened group image through the pin-deformed mesh. */
    private fun warpGroupImage(g: Layer, img: Long, time: Float): Long? {
        val pm = PuppetMath.mesh(g, time) ?: return null
        if (warpT == null || warpT!!.width != width || warpT!!.height != height)
            warpT = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
        val out = warpT ?: return null
        val u = QuadU()
        u.flipY = 1f
        if (!drawQuadPass("quad.frag", blend = false, out, clear = true, u, img, mesh = pm, warp = true)) return null
        return out.tex
    }

    // MARK: - pre-rendered groups (MetalSceneRenderer.swift:553-698)

    fun trimPreCache() { synchronized(preLock) { preTex.clear(); preOrder.clear() } }

    private fun buildPreTexture(raw: ByteArray, w: Int, h: Int): Long {
        // GL read-pixels order is bottom row first; Vulkan textures are top row first: flip.
        val row = w * 4
        val flipped = ByteArray(row * h)
        for (y in 0 until h) System.arraycopy(raw, y * row, flipped, (h - 1 - y) * row, row)
        return SceneRendererN.texCreate(w, h, flipped)
    }

    private fun preStore(key: String, t: Long, bytes: Int) {
        synchronized(preLock) {
            if (preTex[key] == null) preOrder.add(key)
            preTex[key] = t
            val cap = max(8, (200 shl 20) / max(bytes, 1))      // ~200 MB of decoded frames
            while (preOrder.size > cap) preTex.remove(preOrder.removeAt(0))
        }
    }

    private fun prefetchPre(pid: Any, gid: Int, sig: String, fps: Int, idx: Int, w: Int, h: Int) {
        if (!(FrameCache.playing || FrameCache.scrubbing)) return
        for (i in 1..4) {
            val n = idx + i
            val key = "$pid/$gid/$sig/${w}x$h/$n"
            val skip = synchronized(preLock) {
                val s = preTex[key] != null || preBusy.contains(key)
                if (!s) preBusy.add(key)
                s
            }
            if (skip) continue
            preQueue.execute {
                val raw = PreRender.load(pid.toString(), gid, sig, w, h, n)
                if (raw != null) preStore(key, buildPreTexture(raw, w, h), w * h * 4)
                synchronized(preLock) { preBusy.remove(key) }
            }
        }
    }

    private fun preRenderTexture(g: Layer, project: Project, scene: Scene, time: Float): Long? {
        val sig = PreRender.signature(g, project, scene)
        val idx = PreRender.frameIndex(time, project.fps)
        val key = "${project.id}/${g.id}/$sig/${width}x$height/$idx"
        val hit = synchronized(preLock) { preTex[key] }
        if (hit != null) {
            prefetchPre(project.id, g.id, sig, project.fps, idx, width, height)
            return hit
        }
        val raw = PreRender.load(project.id.toString(), g.id, sig, width, height, idx) ?: return null
        val t = buildPreTexture(raw, width, height)
        preStore(key, t, preBytes)
        prefetchPre(project.id, g.id, sig, project.fps, idx, width, height)
        return t
    }

    private fun drawPreRenderedGroup(l: Layer, project: Project, scene: Scene, time: Float, target: MetalTarget, visited: HashSet<Layer>) {
        val tex = preRenderTexture(l, project, scene, time)
        if (tex != null) {
            drawBakedPlane(l, tex, time, target)
            return
        }
        val kids = scene.layers.filter { it.parentId == l.id }
        if (kids.isEmpty()) return          // not baked yet: same look, rendered live
        val ckey = PreRender.signature(l, project, scene) + "|${PreRender.frameIndex(time, project.fps)}|${width}x$height"
        val c = liveGrp[l.id]
        if (c != null && c.first == ckey) {
            drawBakedPlane(l, c.second.tex, time, target)
            return
        }
        val savedCam = SceneRenderer.editCam
        SceneRenderer.editCam = null
        Xf.bakingPlane = true; Xf.bakeRoot = l.id
        val img = if (l.mblur && l.mask == 0)
            blurredGroupImage(l, project, scene, time, visited)
        else
            precompImage(l, kids, project, scene, time, visited, ownFx = false)
        Xf.bakingPlane = false; Xf.bakeRoot = -1
        SceneRenderer.editCam = savedCam
        if (img == null) return
        val old = liveGrp[l.id]?.second
        val ct = if (old != null && old.width == width && old.height == height) old
                 else MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
        blit(img.tex, ct)
        liveGrp[l.id] = ckey to ct
        drawBakedPlane(l, ct.tex, time, target)
    }

    /** Group effects run live on the baked picture (never part of the bake), then the flat picture is placed. */
    private fun drawBakedPlane(g: Layer, tex: Long, time: Float, target: MetalTarget) {
        val a = layerA ?: return
        if (layerB == null) return
        val opacity = g.p("opacity", time)
        var src = tex
        if (g.fx.isNotEmpty()) {
            blit(tex, a)
            applyEffects(g, time)
            src = a.tex
        }
        if ((g.puppet?.on ?: false) && !(g.puppet?.pins?.isEmpty() ?: true)) warpGroupImage(g, src, time)?.let { src = it }
        placePlane(g, src, time, target, opacity)
    }

    /** The flat picture `src` placed with the group's transform, 3D rotation and the scene / edit camera. */
    private fun placePlane(g: Layer, src: Long, time: Float, target: MetalTarget, opacity: Float) {
        val b = layerB ?: return
        var vp: FloatArray? = null
        if (g.is3d || Xf.camera(g) != null) {
            vp = MetalCam.vp(g, time, width, height)
            if (vp != null && !vp.all { it.isFinite() }) {      // broken camera: plain composite
                composite(target, src, alpha = opacity, mode = g.blend); return
            }
        }
        val ar = width.toFloat() / max(height, 1).toFloat()
        val m = Xf.matrix(g, time)
        val u = QuadU()
        u.abcd(m[0], m[1], m[2], m[3])
        u.t(m[4], m[5])
        u.quad(ar * 2f, 2f)
        u.aspect = ar
        u.flipY = 1f
        if (g.is3d || vp != null) set3D(u, g, time, rotate = g.is3d, vp)
        if (!drawQuadPass("quad.frag", blend = false, b, clear = true, u, src)) return
        composite(target, b.tex, alpha = opacity, mode = g.blend)
    }

    // MARK: - group motion blur (MetalSceneRenderer.swift:699-727)

    /** The motion-blurred picture of a group (before opacity / blend); lives in groupAccT. */
    private fun blurredGroupImage(g: Layer, project: Project, scene: Scene, time: Float, visited: HashSet<Layer>): MetalTarget? {
        val children = scene.layers.filter { it.parentId == g.id }
        val acc = groupAccT ?: return null; val grp = groupT ?: return null
        if (children.isEmpty()) return null
        val amount = g.p("mbAmount", time)
        val shutter = 0.12f * amount
        var travel = 0f
        for (c in children) travel = max(travel, screenTravel(c, time, shutter))
        val n = if (travel >= 0.5f)
            min(if (isExport) 48 else 8, max(if (isExport) 8 else 4, ceil(travel).toInt() / (if (isExport) 1 else 3) + 1))
        else min(max(2f, g.p("mbSamples", time)), if (isExport) 12f else 4f).toInt()
        clearTarget(acc)
        for (s in 0 until n) {
            models.depthDirty = true
            val st = min(max(time - shutter * ((s.toFloat() + mbJitter(s, time)) / n.toFloat() - 0.5f), g.start), g.end)
            clearTarget(grp)
            for (c in vdbLast(children)) drawLayer(c, project, scene, st, grp, visited)
            composite(acc, grp.tex, alpha = 1f / (s + 1).toFloat(), mode = 5)
        }
        return acc
    }

    /** Port of precompImage. NOTE (matte): the matte is the first child's finished content (layerA after its effects). */
    private fun precompImage(g: Layer, children: List<Layer>, project: Project, scene: Scene, time: Float,
                             visited: HashSet<Layer>, ownFx: Boolean = true): MetalTarget? {
        val a = layerA ?: return null
        if (groupDepth >= 4) return null
        val grp = poolTarget(groupDepth)
        groupDepth++
        try {
            clearTarget(grp)
            // Mask Group: the top child is only the matte (never drawn itself); the rest are matted by it
            val matte: Layer? = if (g.mask != 0) children.last() else null
            for (c in vdbLast(children)) {
                if (c === matte) continue
                drawLayer(c, project, scene, time, grp, visited)
            }
            if (matte != null) {
                if (matte.isRenderable()) {
                    renderLayerContent(matte, time, grp)
                    applyEffects(matte, time)
                    composite(grp, grp.tex, mask = a.tex, maskMode = g.mask, alpha = 1f, mode = 99)
                } else {
                    clearTarget(grp)
                }
            }
            blit(grp.tex, a)
            if (ownFx && g.fx.isNotEmpty()) applyEffects(g, time)
            return a
        } finally { groupDepth-- }
    }

    // MARK: - content (MetalSceneRenderer.swift:759-812)

    /** Port of renderLayerContent: draws the layer's own content into layerA (cleared first). */
    private fun renderLayerContent(l: Layer, time: Float, target: MetalTarget) {
        val a = layerA ?: return
        var drew = false
        when (l.type) {
            LayerType.IMAGE, LayerType.VIDEO ->
                drew = drawMedia(l, time, 1f, a, clear = true, blend = false)
            LayerType.TEXT ->
                drew = drawText(l, time, a)
            LayerType.SHAPE ->
                if (Xf.isParticles(l)) {
                    // "Particles" added from the + menu is a Shape layer carrying the particles effect
                    clearTarget(a)
                    if (l.p(Xf.showSrcKey(l), l.editTime(Xf.showSrcKey(l), time)) >= 0.5f) drawShape(l, time, a)
                    ptPrepareModel(l, time); particles.draw(l, time, Editor.scene.fov, a)
                    drew = true
                } else {
                    drew = drawShape(l, time, a)
                }
            LayerType.FLARE -> {
                clearTarget(a)
                flares.draw(l, time, Editor.scene.fov, isExport, models.occlusionDepth(), a)
                drew = true
            }
            LayerType.PARTICLES -> {
                clearTarget(a)
                if (l.p(Xf.showSrcKey(l), l.editTime(Xf.showSrcKey(l), time)) >= 0.5f) drawShape(l, time, a)
                ptPrepareModel(l, time); particles.draw(l, time, Editor.scene.fov, a)
                drew = true
            }
            LayerType.MODEL -> {
                clearTarget(a)
                if (isVdb(l)) {
                    val path = l.imagePath
                    if (path != null) {
                        var overrides: List<FloatArray?> = listOf(null)
                        val inst = models.scatterWorld(l, time)
                        if (inst != null) {
                            val vpv = MetalCam.vpForModel(l, Editor.scene.fov, time, a.width, a.height)
                            fun depth(m: M4): Float = vpv[3] * m.m[12] + vpv[7] * m.m[13] + vpv[11] * m.m[14] + vpv[15]
                            overrides = inst.sortedByDescending { depth(it) }.take(8).map { it.m.copyOf() }   // far -> near; 8 copies max
                            if (l.xf("scKeep", 0f) > 0.5f) overrides = overrides + null
                        }
                        for (ov in overrides) {
                            volumes.draw(l, path, time, Editor.scene.fov, a, target,
                                         if (l.occlude) models.occlusionDepth() else 0L, ov, overrides.size > 1)
                        }
                    }
                } else {
                    models.draw(l, time, Editor.scene.fov, a, target)
                }
                drew = true
            }
            LayerType.ADJUST ->
                drew = blit(target.tex, a)     // content = the buffer below
            else -> {}
        }
        if (!drew) clearTarget(a)
    }

    /** Particular "Model" emitter: hand the sim the target model's surface points for this frame. */
    private fun ptPrepareModel(l: Layer, time: Float) {
        if (!Xf.isParticular(l)) return
        val lt = l.editTime("x", time)
        for (gi in 0 until PtGroup.count { l.p(it, lt) }) {
            val pre = PtGroup.pre(gi)
            if (Math.round(l.p(pre + "ptEmType", lt)) == 17) {
                val id = Math.round(l.p(pre + "ptModelLayer", lt)).toInt()
                PtModelSource.set(id, models.ptSurface(l, id, time))
            }
        }
    }

    // MARK: - drawing primitives (MetalSceneRenderer.swift:813-990)

    private fun composite(target: MetalTarget, src: Long, mask: Long = 0L, maskMode: Int = 0,
                          alpha: Float, mode: Int, rgbShift: Float = 0f) {
        val scratch = scratchT ?: return
        SceneRendererN.composite(target.handle, scratch.handle, src, mask, alpha, mode, maskMode, rgbShift)
    }

    private fun blit(src: Long, to: MetalTarget): Boolean = SceneRendererN.blit(src, to.handle)

    private fun set3D(u: QuadU, l: Layer, time: Float, rotate: Boolean, vp: FloatArray?) {
        var rx = 0f; var ry = 0f; var zz = 0f
        if (rotate) {
            val lt = l.editTime("x", time)
            val d = Math.PI.toFloat() / 180f
            val tilt = Xf.inheritedTilt(l, time)
            rx = (l.p("rotX", lt) + tilt.first) * d
            ry = -(l.p("rotY", lt) + tilt.second) * d
            zz = Xf.worldZ(l, time)
            if (!zz.isFinite()) zz = 0f
        }
        u.rot3(rx, ry, zz, 1f / 3f)
        u.flags(if (vp != null) 1f else 0f, 1f, 0f, 0f)
        if (vp != null && vp.size == 16) u.vp(vp)
    }

    private fun drawQuadPass(frag: String, blend: Boolean, into: MetalTarget, clear: Boolean,
                             u: QuadU, tex: Long, mesh: PuppetMesh? = null, warp: Boolean = false): Boolean {
        var pos: FloatArray? = null; var uv: FloatArray? = null
        var count = 4
        if (mesh != null) {
            val ep = ArrayList<Float>(mesh.idx.size * 2); val eu = ArrayList<Float>(mesh.idx.size * 2)
            for (i in mesh.idx) {
                val k = i.toInt() * 2
                if (k + 1 >= mesh.pos.size || k + 1 >= mesh.uv.size) continue
                ep.add(mesh.pos[k]); ep.add(mesh.pos[k + 1]); eu.add(mesh.uv[k]); eu.add(mesh.uv[k + 1])
            }
            count = ep.size / 2 - (ep.size / 2) % 3
            if (count < 3) return false
            pos = ep.toFloatArray(); uv = eu.toFloatArray()
        }
        val vname = if (mesh == null) "fs.vert" else (if (warp) "warp.vert" else "mesh.vert")
        return SceneRendererN.quadPass(frag, vname, blend, into.handle, clear, u.data, tex, pos, uv, count)
    }

    private fun quadUniforms(l: Layer, time: Float): QuadU {
        val (qw, qh) = Xf.quadSize(l)
        val m = Xf.matrix(l, time)
        val u = QuadU()
        u.abcd(m[0], m[1], m[2], m[3])
        u.t(m[4], m[5])
        u.quad(qw, qh)
        u.aspect = width.toFloat() / max(height, 1).toFloat()
        if (l.is3d && !Xf.flatDraw) {
            var vp = MetalCam.vp(l, time, width, height)
            if (vp != null && !vp.all { it.isFinite() }) vp = null   // broken camera: draw flat, never vanish
            set3D(u, l, time, rotate = true, vp)
        }
        return u
    }

    private fun drawMedia(l: Layer, time: Float, opacity: Float, into: MetalTarget, clear: Boolean, blend: Boolean): Boolean {
        val path = l.imagePath ?: return false
        var tex = 0L
        if (l.type == LayerType.VIDEO) {
            val smp = samplerFor(l, path)
            l.twixSource(time)?.let { smp.bucketsPerSec = Math.round(it.fps) }
            tex = smp.texture(sourceTime(l, time))
        }
        if (tex == 0L) tex = images.texture(path, quality)
        if (tex == 0L) return false
        val u = quadUniforms(l, time)
        u.color(opacity, opacity, opacity, opacity)
        u.flipY = 1f
        return drawQuadPass("quad.frag", blend, into, clear, u, tex, PuppetMath.mesh(l, time))
    }

    private fun drawText(l: Layer, time: Float, into: MetalTarget): Boolean {
        val img = TextRaster.raster(l, time)
        if (img.width <= 1 || img.height <= 1) return false
        val tex = SceneRendererN.texCreateCapped(img.width, img.height, img, 4096) ?: return false
        val u = quadUniforms(l, time)
        u.flipY = 1f
        return drawQuadPass("quad.frag", blend = false, into, clear = true, u, tex, PuppetMath.mesh(l, time))
    }

    private var pathTex = HashMap<Int, Pair<Int, Long>>()

    private fun drawShape(l: Layer, time: Float, into: MetalTarget): Boolean {
        if (l.shape == ShapeKind.PATH) {
            val key = l.vpath.hashKey xor l.color
            var tex = pathTex[l.id]?.takeIf { it.first == key }?.second
            if (tex == null || tex == 0L) {
                val img = VPathRaster.image(l.vpath, l.color)
                val t = SceneRendererN.texCreateCapped(img.width, img.height, img, 1024)
                if (t != 0L) { pathTex[l.id] = key to t; tex = t }
            }
            if (tex == null || tex == 0L) return false
            val u = quadUniforms(l, time)
            u.flipY = 1f
            return drawQuadPass("quad.frag", blend = false, into, clear = true, u, tex, PuppetMath.mesh(l, time))
        }
        val u = quadUniforms(l, time)
        val c = l.color
        u.color(((c ushr 16) and 0xFF) / 255f, ((c ushr 8) and 0xFF) / 255f, (c and 0xFF) / 255f, ((c ushr 24) and 0xFF) / 255f)
        u.kind = l.shape.glKind
        u.corner = l.p("shapeRound", time)
        u.flags(u.flagsData[0], u.flagsData[1], l.p("shapeThick", time), u.flagsData[3])
        if (l.gradMode > 0) {
            val c2 = l.color2
            u.gradC(((c2 ushr 16) and 0xFF) / 255f, ((c2 ushr 8) and 0xFF) / 255f, (c2 and 0xFF) / 255f, ((c2 ushr 24) and 0xFF) / 255f)
            u.gradP(l.gradX1, l.gradY1, l.gradX2, l.gradY2)
            u.gradM(l.gradMode.toFloat(), 0f, 0f, 0f)
        }
        return drawQuadPass("shape.frag", blend = false, into, clear = true, u, 0L, PuppetMath.mesh(l, time))
    }

    private var twixSamplers = HashMap<Int, VideoFrames.Sampler>()
    private fun twixSamplerFor(l: Layer, path: String, fps: Int): VideoFrames.Sampler {
        val s = twixSamplers[l.id]
        if (s != null) { s.bucketsPerSec = fps; return s }
        val ns = VideoFrames.Sampler(path)
        ns.bucketsPerSec = fps
        twixSamplers[l.id] = ns
        return ns
    }

    private fun samplerFor(l: Layer, path: String): VideoFrames.Sampler {
        val s = samplers[l.id]
        if (s != null) return s
        // export: decode the exact frame now, never draw a still-empty async texture
        val ns = VideoFrames.Sampler(path, synchronous = isExport)
        // MetalSceneRenderer.swift:1020 s.onFrame = { MetalSceneRenderer.onVideoFrame?() } —
        // SceneRenderer.swift:25 videoFrameArrived twin: a fresh async frame triggers the preview redraw.
        ns.onUploaded = { SceneRenderer.onVideoFrame?.invoke() }
        samplers[l.id] = ns
        return ns
    }

    /** Source-media time for a video layer at scene time `t` (remap aware) — copy of SceneRenderer.sourceTime. */
    private fun sourceTime(l: Layer, t: Float): Float {
        val tw = l.twixSource(t)
        if (tw != null) return tw.a                // Twixtor: frame A of the interpolated pair
        val tr = l.props["remapT"]
        if (tr != null && tr.keys.isNotEmpty()) {
            return max(0f, tr.eval(t) + l.srcOffset)
        }
        val sp = l.props["remapSpeed"]?.eval(t) ?: 1f
        return max(0f, (t - l.start) * sp + l.srcOffset)
    }

    /** Twitch "Time" operator: random frame snaps of the layer's own footage (port of GL twitchRetime). */
    private fun twitchRetime(l: Layer, project: Project, time: Float): Float {
        if (l.fx.isEmpty()) return time
        var t = time
        for (e in l.fx) {
            if (l.fxOff.contains(e)) continue
            if (Registry.get(e)?.id != "twitch") continue
            if (l.p(e + "__twEnTime", time) < 0.5f) continue
            val k = e + "__"
            val step = floor(time * 8 * l.p(k + "twSpeed", time) * l.p(k + "twTmSpeed", time))
            val seed = l.p(k + "twTmSeed", time)
            fun h(a: Float): Float {
                var x = (a * 1000).toInt().toUInt() * 2654435761u
                x = (x xor (x shr 15)) * 2246822519u; x = x xor (x shr 13)
                return (x and 0xFFFFu).toFloat() / 65536f
            }
            if (h(step * 3.1f + seed * 7.7f) >= l.p(k + "twTmTwitches", time)) continue
            val frames = (h(step * 5.3f + seed + 1) * 2 - 1) * l.p(k + "twTmAmount", time) * l.p(k + "twAmount", time)
            t += roundAway(frames) / max(1, project.fps).toFloat()
        }
        return min(max(t, l.start), l.end)
    }

    // MARK: - effects (MetalSceneRenderer.swift:1030-1210)

    private fun paramValue(l: Layer, key: String, def: Float, time: Float): Float {
        val tr = l.props[key]
        if (tr != null) return tr.evalExpr(l.editTime(key, time), time, if (tr.exprActive()) Editor.scene.markersByName() else emptyMap())
        return def
    }

    private fun colorComp(l: Layer, key: String, def: Float, time: Float): Float {
        val tr = l.props[key]
        if (tr != null) return tr.eval(l.editTime(key, time))
        return def
    }

    private fun effectSteps(l: Layer, time: Float): List<FxStepData> =
        FxSteps.effectSteps(l, time) { lay, path, tw -> twixSamplerFor(lay, path, Math.round(tw.fps)).texture(tw.b) }

    /** Layer inputs (in0 / in1) of effects: renders each referenced layer's content into a dedicated target. */
    private fun bindEffectInputs(steps: ArrayList<FxStepData>, time: Float) {
        val a = layerA ?: return; val st = sceneT ?: return
        if (fxSnapT == null) fxSnapT = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
        if (inT0 == null) inT0 = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
        if (inT1 == null) inT1 = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
        val snap = fxSnapT ?: return
        val made = HashMap<Int, Long>()
        var used = 0
        var snapped = false
        fun inputTexture(rid: Int?): Long {
            if (rid == null) return 0L
            val ref = Editor.scene.layers.firstOrNull { it.id == rid } ?: return 0L
            if (!ref.isRenderable()) return 0L
            made[rid]?.let { return it }
            if (used >= 2) return 0L
            val dst = if (used == 0) inT0!! else inT1!!
            if (!snapped) { blit(a.tex, snap); snapped = true }
            renderLayerContent(ref, time, st)
            blit(a.tex, dst)
            models.depthDirty = true
            used++
            made[rid] = dst.tex
            return dst.tex
        }
        for (i in steps.indices) {
            steps[i].in0 = inputTexture(steps[i].inRef0)
            val t1 = inputTexture(steps[i].inRef1)
            if (t1 != 0L) steps[i].in1 = t1
        }
        if (snapped) blit(snap.tex, a)
    }

    /** On-screen size of a 3D layer relative to the same layer flat at Z = 0 (1 for 2D layers). */
    private fun layerZScale(l: Layer, time: Float): Float {
        if (!l.is3d || l.type == LayerType.GROUP || l.type == LayerType.ADJUST) return 1f
        val (qw, _) = Xf.quadSize(l)
        val ar = width.toFloat() / max(height, 1).toFloat()
        val m = Xf.matrix(l, time)
        val z = Xf.worldZ(l, time)
        val a = Pair(m[0] * -0.5f * qw + m[4], m[1] * -0.5f * qw + m[5])
        val b = Pair(m[0] * 0.5f * qw + m[4], m[1] * 0.5f * qw + m[5])
        val flat = sqrt(((a.first - b.first) / ar).let { it * it } + (a.second - b.second).let { it * it })
        if (flat < 1e-5f) return 1f
        fun ndc(q: Pair<Float, Float>): Pair<Float, Float>? {
            val vp = MetalCam.vp(l, time, width, height)
            if (vp != null) {
                val cw = vp[3] * q.first + vp[7] * q.second + vp[11] * z + vp[15]
                if (cw < 0.02f) return null
                return Pair((vp[0] * q.first + vp[4] * q.second + vp[8] * z + vp[12]) / cw,
                            (vp[1] * q.first + vp[5] * q.second + vp[9] * z + vp[13]) / cw)
            }
            val w = 1 - z / 3
            if (w < 0.02f) return null
            return Pair(q.first / ar / w, q.second / w)
        }
        val pa = ndc(a) ?: return 1f
        val pb = ndc(b) ?: return 1f
        return min(max(sqrt((pa.first - pb.first).let { it * it } + (pa.second - pb.second).let { it * it }) / flat, 0.03f), 4f)
    }

    private fun applyEffects(l: Layer, time: Float) {
        val a = layerA ?: return; val b = layerB ?: return
        if (l.fxChain().isEmpty()) return
        val steps = ArrayList(effectSteps(l, time))
        if (steps.isEmpty()) return
        if (steps.any { it.inRef0 != null || it.inRef1 != null }) bindEffectInputs(steps, time)
        if (steps.any { it.def.id == "copybg" } && curBackdropTex != 0L) {
            if (bgCopyT == null || bgCopyT!!.width != width || bgCopyT!!.height != height)
                bgCopyT = MetalTarget(SceneRendererN.targetCreate(width, height, false), width, height, false)
            val dst = bgCopyT
            if (dst != null && blit(curBackdropTex, dst)) {
                for (i in steps.indices) if (steps[i].def.id == "copybg") steps[i].in0 = dst.tex
            }
        }
        var rect: Triple<FloatArray, FloatArray, FloatArray>? = null
        if (l.type != LayerType.GROUP && l.type != LayerType.ADJUST) {          // the layer's rectangle in world units
            val m = Xf.matrix(l, time)
            val (qw, qh) = Xf.quadSize(l)
            rect = Triple(floatArrayOf(m[4], m[5]), floatArrayOf(m[0] * qw, m[1] * qw), floatArrayOf(m[2] * qh, m[3] * qh))
        }
        var read = a; var write = b
        var sawBlurFx = false
        for (st in steps) {
            val id = st.def.id
            if (id == "blur" || id == "radialblur" || id == "blurmo" || id == "dirblur") sawBlurFx = true
            if (id == "deepglow") {
                val gp = MetalGlow.Params()
                fun v(key: String, def: Float): Float {
                    val i = st.def.props.indexOfFirst { it.key == key }
                    return if (i >= 0 && i < st.props.size) st.props[i] else def
                }
                gp.radius = v("radius", 0.12f); gp.intensity = v("intensity", 1f)
                gp.threshold = v("threshold", 0.3f); gp.knee = v("knee", 0.5f)
                gp.falloff = v("falloff", 0.5f); gp.tintAmt = v("tintAmt", 0f)
                gp.tintHue = v("tintHue", 0.08f); gp.chroma = v("chroma", 0f); gp.glowOnly = v("glowOnly", 0f)
                gp.blurComp = if (sawBlurFx) max(glowBlurComp, 2.4f) else glowBlurComp
                gp.zScale = layerZScale(l, time)
                if (glow.apply(gp, read, write)) { val t = read; read = write; write = t }
                continue
            }
            if (id == "shine") ShineCam.resolve(st.def, st.props, l, time, width, height)
            if (id == "mbl") {
                // Haze/Flare: a smooth multi-scale bloom of the highlights handed to the Looks shader as input.
                fun hv(k: String, d: Float): Float {
                    val i = st.def.props.indexOfFirst { it.key == k }
                    return if (i >= 0 && i < st.props.size) st.props[i] else d
                }
                if (hv("mbHf", 0f) > 0.5f) {
                    if (hazeT == null || hazeT!!.width != width || hazeT!!.height != height)
                        hazeT = MetalTarget(SceneRendererN.targetCreate(width, height, true), width, height, true)
                    val ht = hazeT
                    if (ht != null) {
                        val gp = MetalGlow.Params()
                        gp.radius = 0.03f + hv("mbHfRe", 53.2f) * 0.0045f
                        gp.intensity = 1f; gp.threshold = 0.5f; gp.knee = 0.6f
                        gp.falloff = hv("mbHfSo", 49f) * 0.01f
                        gp.glowOnly = 1f
                        if (glow.apply(gp, read, ht)) st.in0 = ht.tex
                    }
                }
            }
            if (FxGlsl.apply(st, read, write, time, rect)) { val t = read; read = write; write = t }
        }
        if (read !== a) SceneRendererN.swapTargets(a.handle, b.handle)
    }
}
