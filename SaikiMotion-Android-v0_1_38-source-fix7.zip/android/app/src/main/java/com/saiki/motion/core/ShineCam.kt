package com.saiki.motion.core

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// Port of Sources/Effects/BuiltinsShine.swift enum ShineCam (the camera the Shine effect looks through).
// resolve() is called by the scene renderer for every "shine" step and by the dashboard gizmo, so both agree.
object ShineCam {
    private val PI = Math.PI.toFloat()

    /** The camera an effect looks through: the layer's own scene camera, or — for an adjustment layer above
     *  the camera — the nearest visible camera of the same scope below it. */
    fun camera(l: Layer): Layer? {
        if (Xf.flatDraw) return null
        Xf.camera(l)?.let { return it }
        if (l.type != LayerType.ADJUST) return null
        val idx = Editor.scene.layers.indexOfFirst { it === l }
        if (idx < 0) return null
        val scope = Xf.cameraScope(l)
        var best: Layer? = null
        var bi = -1
        for ((j, c) in Editor.scene.layers.withIndex()) {
            if (c.type != LayerType.CAMERA || !c.visible || j >= idx || Xf.cameraScope(c) != scope) continue
            if (j > bi) { best = c; bi = j }
        }
        return best
    }

    /** View-projection for a layer seen through the camera (adjustment layers, 3D layers, models); null otherwise. */
    fun viewProj(l: Layer, time: Float, width: Int, height: Int): FloatArray? {
        if (l.type != LayerType.ADJUST && !l.is3d && l.type != LayerType.MODEL) return null
        val ar = width.toFloat() / max(height, 1).toFloat()
        val e = SceneRenderer.editCam
        if (e != null) {
            return MetalCam.lookAt(e[0], ar, e[1], e[2], e[3], e[4] * PI / 180f, e[5] * PI / 180f, 0f)
        }
        val cam = camera(l) ?: return null
        return MetalCam.vpCamera(cam, time, width, height)
    }

    /** World point -> screen. nx/ny NDC (-1..1, y up); scale = on-screen size of one world unit vs the neutral view. */
    fun project(l: Layer, time: Float, width: Int, height: Int, x: Float, y: Float, z: Float): ProjectResult {
        val ar = width.toFloat() / max(height, 1).toFloat()
        val vp = viewProj(l, time, width, height)
        if (vp != null) {
            val cw = vp[3] * x + vp[7] * y + vp[11] * z + vp[15]
            if (cw < 0.02f) return ProjectResult(0f, 0f, 1f, false)
            return ProjectResult((vp[0] * x + vp[4] * y + vp[8] * z + vp[12]) / cw,
                                 (vp[1] * x + vp[5] * y + vp[9] * z + vp[13]) / cw,
                                 abs(vp[5]) / cw, true)
        }
        if (l.type == LayerType.ADJUST || l.is3d || l.type == LayerType.MODEL) {      // no camera: default z = 3 view
            val w = 1 - z / 3
            if (w < 0.02f) return ProjectResult(0f, 0f, 1f, false)
            return ProjectResult(x / ar / w, y / w, 1 / w, true)
        }
        val m = affine(l, time)
        return ProjectResult((m[0] * x + m[2] * y + m[4]) / ar, m[1] * x + m[3] * y + m[5], layerScale(l, time), true)
    }

    class ProjectResult(val nx: Float, val ny: Float, val scale: Float, val visible: Boolean)

    private fun affine(l: Layer, t: Float): FloatArray {
        var m = Xf.matrix(l, t)
        val det = m[0] * m[3] - m[1] * m[2]
        if (!det.isFinite() || abs(det) < 1e-6f) {
            m = floatArrayOf(1f, 0f, 0f, 1f, if (m[4].isFinite()) m[4] else 0f, if (m[5].isFinite()) m[5] else 0f)
        }
        return m
    }

    /** Uniform on-screen scale of the layer's own 2D transform (1 when degenerate). */
    fun layerScale(l: Layer, t: Float): Float {
        val m = affine(l, t)
        val s = sqrt(abs(m[0] * m[3] - m[1] * m[2]))
        return if (s.isFinite() && s > 1e-4f) s else 1f
    }

    /** A point in the layer's own space (world units from its centre) -> world: position, rotation, scale, parents,
     *  and the 3D tilt (rotX / rotY, same order as the model matrix). */
    fun world(l: Layer, t: Float, lx: Float, ly: Float, lz: Float): Triple<Float, Float, Float> {
        val m = affine(l, t)
        val lt = l.editTime("x", t)
        val ux = m[0] * lx + m[2] * ly; val uy = m[1] * lx + m[3] * ly
        var sc = l.p("scale", lt)
        if (!sc.isFinite() || sc < 1e-4f) sc = 1f
        val is3 = (l.is3d && l.type != LayerType.ADJUST && l.type != LayerType.GROUP) || l.type == LayerType.MODEL
        if (!is3) return Triple(m[4] + ux, m[5] + uy, 0f)
        val uz = lz * sc
        // same order and signs as the layer quad shader (clipPos): rotY (negated) first, then rotX
        val rx = l.p("rotX", lt) * PI / 180f; val ry = -l.p("rotY", lt) * PI / 180f
        val cy = cos(ry); val sy = sin(ry); val cx = cos(rx); val sx = sin(rx)
        val x1 = ux * cy + uz * sy; val z1 = -ux * sy + uz * cy
        val y2 = uy * cx - z1 * sx; val z2 = uy * sx + z1 * cx
        return Triple(m[4] + x1, m[5] + y2, Xf.worldZ(l, t) + z2)
    }

    /** Turns the stored source / mask inputs into the on-screen values the shader reads (shX, shY, shSc, shVis, shMX...). */
    fun resolve(def: EffectDef, props: FloatArray, l: Layer, time: Float, width: Int, height: Int) {
        val idx = HashMap<String, Int>()
        for ((i, p) in def.props.withIndex()) idx[p.key] = i
        fun get(k: String, d: Float): Float { val i = idx[k]; return if (i != null && i < props.size) props[i] else d }
        fun put(k: String, v: Float) { val i = idx[k]; if (i != null && i < props.size) props[i] = v }
        val ar = width.toFloat() / max(height, 1).toFloat()
        val three = get("shType", 0f) > 0.5f; val follow = get("shFollow", 1f) > 0.5f
        val lscale = layerScale(l, time)
        var sc = 1f; var vis = 1f
        if (three) {
            val lx = get("shWX", 0f); val ly = get("shWY", 0.3f); val lz = get("shWZ", 0f)
            val w = if (follow) world(l, time, lx, ly, lz) else Triple(lx, ly, lz)
            val p = project(l, time, width, height, w.first, w.second, w.third)
            put("shX", (p.nx * 0.5f + 0.5f) * 100f); put("shY", (0.5f - p.ny * 0.5f) * 100f)
            sc = min(max(p.scale, 0.05f), 6f); vis = if (p.visible) 1f else 0f
        } else if (follow) {
            val w = world(l, time, (get("shX", 50f) * 0.02f - 1f) * ar, 1f - get("shY", 35f) * 0.02f, 0f)
            put("shX", (w.first / ar * 0.5f + 0.5f) * 100f); put("shY", (0.5f - w.second * 0.5f) * 100f)
            sc = lscale
        }
        if (follow && get("shMask", 0f) > 0.5f) {
            val w = world(l, time, (get("shMX", 50f) * 0.02f - 1f) * ar, 1f - get("shMY", 50f) * 0.02f, 0f)
            put("shMX", (w.first / ar * 0.5f + 0.5f) * 100f); put("shMY", (0.5f - w.second * 0.5f) * 100f)
            put("shMW", get("shMW", 40f) * lscale); put("shMH", get("shMH", 45f) * lscale)
        }
        put("shSc", sc); put("shVis", vis)
    }

    /** Moves the input pair (kx, ky) until the resolved on-screen point sits under the finger (dashboard gizmo). */
    fun solve(def: EffectDef, base: FloatArray, l: Layer, time: Float, width: Int, height: Int,
              kx: String, ky: String, outX: String, outY: String, target: Pair<Float, Float>, step: Float, needVis: Boolean = true): Pair<Float, Float>? {
        fun ix(k: String): Int? = def.props.indexOfFirst { it.key == k }.takeIf { it >= 0 }
        val i1 = ix(kx) ?: return null; val i2 = ix(ky) ?: return null
        val o1 = ix(outX) ?: return null; val o2 = ix(outY) ?: return null
        val iv = ix("shVis") ?: return null
        fun eval(x: Float, y: Float): Pair<Float, Float>? {
            val p = base.copyOf(); p[i1] = x; p[i2] = y
            resolve(def, p, l, time, width, height)
            return if (needVis && p[iv] < 0.5f) null else Pair(p[o1], p[o2])
        }
        var x = base[i1]; var y = base[i2]
        repeat(6) {
            val p0 = eval(x, y) ?: return null
            val ex = target.first - p0.first; val ey = target.second - p0.second
            if (abs(ex) + abs(ey) < 0.01f) return@repeat
            val px = eval(x + step, y) ?: return null
            val py = eval(x, y + step) ?: return null
            val j00 = (px.first - p0.first) / step; val j10 = (px.second - p0.second) / step
            val j01 = (py.first - p0.first) / step; val j11 = (py.second - p0.second) / step
            val det = j00 * j11 - j01 * j10
            if (abs(det) < 1e-9f) return null
            x += (j11 * ex - j01 * ey) / det
            y += (-j10 * ex + j00 * ey) / det
        }
        return Pair(x, y)
    }
}
