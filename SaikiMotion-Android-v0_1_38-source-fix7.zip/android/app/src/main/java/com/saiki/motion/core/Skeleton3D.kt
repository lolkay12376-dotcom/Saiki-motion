package com.saiki.motion.core

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

// Port of Sources/Model/Skeleton3D.swift: bones for a 3D model layer; pose = per-bone rotation + offset on top of the rest pose.

class Bone3D(var name: String, var parent: Int, var bindWorld: M4, var restLocal: M4) {
    var rot = Quat.IDENTITY
    var off = V3.ZERO
    var physics = false          // driven by VRM spring bone / PMX rigid body
}

class Skeleton3D {
    var bones = mutableListOf<Bone3D>()
    var phys: Physics3D? = null
    var physicsOn = true
    /** Bumped every time the simulated pose changed (the viewport redraws the bone overlay on it). */
    var simTick = 0; private set
    private var simW: List<M4>? = null
    private var topoCache = IntArray(0)
    private var bindInv = listOf<M4>()
    private var sig = ""
    val poseSig: String get() = sig

    /** Parents before children. */
    fun order(): IntArray {
        if (topoCache.size == bones.size) return topoCache
        val seen = BooleanArray(bones.size)
        val out = ArrayList<Int>(bones.size)
        for (i in bones.indices) {
            val chain = ArrayList<Int>()
            var c = i; var g = 0
            while (c >= 0 && c < bones.size && !seen[c] && g < 4096) { chain.add(c); seen[c] = true; c = bones[c].parent; g += 1 }
            chain.reverse(); out.addAll(chain)
        }
        topoCache = out.toIntArray()
        return topoCache
    }

    /** World matrices of the posed skeleton without physics (model space). */
    fun poseWorld(): Array<M4> {
        val w = Array(bones.size) { M4.identity() }
        for (i in order()) {
            val b = bones[i]; val l = local(b)
            w[i] = if (b.parent >= 0 && b.parent < bones.size && b.parent != i) w[b.parent] * l else l
        }
        return w
    }

    /** World matrices as drawn: pose + physics when the simulation is on. */
    fun world(): List<M4> {
        val s = simW
        if (physicsOn && s != null && s.size == bones.size) return s
        return poseWorld().toList()
    }

    fun skinMatrices(): List<M4> {
        if (bindInv.size != bones.size) bindInv = bones.map { it.bindWorld.inverse() }
        val w = world()
        return List(bones.size) { w[it] * bindInv[it] }
    }

    fun resetPose() { for (b in bones) { b.rot = Quat.IDENTITY; b.off = V3.ZERO } }

    /** Loads the layer's bone tracks at `t` into the pose. True when the pose changed. */
    fun loadPose(l: Layer, t: Float): Boolean {
        val vals = HashMap<Int, FloatArray>()
        for (key in l.props.keys) {
            val k = boneKey(key) ?: continue
            if (k.first >= bones.size) continue
            val v = vals[k.first] ?: FloatArray(6)
            val x = l.p(key, t)
            v[k.second] = if (x.isFinite()) x else 0f
            vals[k.first] = v
        }
        val parts = ArrayList<String>()
        for (i in vals.keys.sorted()) parts.add("$i:" + (vals[i] ?: FloatArray(0)).joinToString(",") { String.format(Locale.US, "%.5f", it) })
        val s = parts.joinToString(";")
        if (s == sig) return false
        sig = s
        resetPose()
        for ((i, v) in vals) { bones[i].rot = quat(v[0], v[1], v[2]); bones[i].off = V3(v[3], v[4], v[5]) }
        return true
    }

    /** Removes every bone track of the layer (Reset pose) and clears the pose. */
    fun clearTracks(l: Layer) {
        for (k in l.props.keys.toList()) if (boneKey(k) != null) l.props.remove(k)
        resetPose(); sig = "\u0000"          // differs from any pose signature, so the next loadPose re-skins
    }

    // MARK: physics

    /** Advances the simulation to timeline time `t` (`wall` = real seconds since the last call). True when any bone moved. */
    fun stepPhysics(t: Float, wall: Float): Boolean {
        val ph = phys
        if (!(physicsOn && ph != null && ph.active)) {
            if (simW != null) { simW = null; simTick += 1; return true }
            return false
        }
        val new = ph.solve(this, t, wall)
        var moved = true
        val old = simW
        if (old != null && old.size == new.size) {
            moved = false
            for (i in new.indices) if (differs(old[i], new[i])) { moved = true; break }
        }
        simW = new.toList()
        if (moved) simTick += 1
        return moved
    }

    /** Drops the simulation state (the next step starts from the pose). */
    fun resetPhysics() { simW = null; phys?.lastT = null }

    companion object {
        /** Local matrix of a bone with its pose applied. */
        fun local(b: Bone3D): M4 {
            val d = M4.fromQuat(b.rot)
            d.setCol(3, V4(b.off.x, b.off.y, b.off.z, 1f))
            return b.restLocal * d
        }

        /** Euler degrees (XYZ) -> quaternion. */
        fun quat(rx: Float, ry: Float, rz: Float): Quat {
            val d = Math.PI.toFloat() / 180
            return Quat.angleAxis(rz * d, V3(0f, 0f, 1f)) * Quat.angleAxis(ry * d, V3(0f, 1f, 0f)) * Quat.angleAxis(rx * d, V3(1f, 0f, 0f))
        }

        /** (bone, channel 0...5) of a bone track key ("bn<i>rx/ry/rz/px/py/pz"), null for any other key. */
        fun boneKey(k: String): Pair<Int, Int>? {
            if (!(k.length > 4 && k.startsWith("bn"))) return null
            val ax = when (k.substring(k.length - 2)) { "rx" -> 0; "ry" -> 1; "rz" -> 2; "px" -> 3; "py" -> 4; "pz" -> 5; else -> return null }
            val i = k.substring(2, k.length - 2).toIntOrNull() ?: return null
            if (i < 0) return null
            return Pair(i, ax)
        }

        private fun differs(a: M4, b: M4): Boolean {
            for (c in 0 until 4) {
                val ca = a.col(c); val cb = b.col(c)
                if (abs(ca.x - cb.x) > 1e-5f * (1 + abs(cb.x)) || abs(ca.y - cb.y) > 1e-5f * (1 + abs(cb.y)) || abs(ca.z - cb.z) > 1e-5f * (1 + abs(cb.z))) return true
            }
            return false
        }

        // MARK: skinning

        /** Skins interleaved vertices (12 floats each: pos, normal, uv, ...) with the given skin matrices. */
        fun skinVerts(base: FloatArray, jnt: ShortArray, wgt: FloatArray, mats: List<M4>): FloatArray {
            val v = base.copyOf()
            val n = v.size / 12
            if (!(jnt.size >= n * 4 && wgt.size >= n * 4)) return v
            for (i in 0 until n) {
                val o = V4(v[i * 12], v[i * 12 + 1], v[i * 12 + 2], 1f)
                val on = V4(v[i * 12 + 3], v[i * 12 + 4], v[i * 12 + 5], 0f)
                var p = V4(0f, 0f, 0f, 0f); var nn = V4(0f, 0f, 0f, 0f); var ws = 0f
                for (k in 0 until 4) {
                    val w = wgt[i * 4 + k]; if (w <= 0) continue
                    val bi = jnt[i * 4 + k].toInt() and 0xFFFF; if (bi >= mats.size) continue
                    p = p + (mats[bi] * o) * w; nn = nn + (mats[bi] * on) * w; ws += w
                }
                if (ws < 0.999f) { p = p + o * (1 - ws); nn = nn + on * (1 - ws) }
                v[i * 12] = p.x; v[i * 12 + 1] = p.y; v[i * 12 + 2] = p.z
                val l = max(length(V3(nn.x, nn.y, nn.z)), 1e-6f)
                v[i * 12 + 3] = nn.x / l; v[i * 12 + 4] = nn.y / l; v[i * 12 + 5] = nn.z / l
            }
            return v
        }

        // MARK: sidecar ("<model>.glb.skel") written by the PMX / FBX importers
        // v1 "SKL1": bones + skin weights.  v2 "SKL2": v1 + PMX rigid bodies and joints (physics). Both are read.
        const val magic1: Int = 0x314C4B53
        const val magic2: Int = 0x324C4B53

        /** 1 / 2 for a readable sidecar, 0 when missing. */
        fun sidecarVersion(path: String): Int {
            val m = try { RandomAccessFile(path, "r").use { f -> val b = ByteArray(4); if (f.read(b) != 4) return 0; ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).int } } catch (_: Exception) { return 0 }
            return if (m == magic2) 2 else if (m == magic1) 1 else 0
        }

        fun write(sk: Skeleton3D, joints: List<ShortArray>, weights: List<FloatArray>, path: String) {
            val bo = ByteArrayOutputStream()
            fun u32(v: Int) { bo.write(v and 0xFF); bo.write((v ushr 8) and 0xFF); bo.write((v ushr 16) and 0xFF); bo.write((v ushr 24) and 0xFF) }
            fun f32(v: Float) = u32(java.lang.Float.floatToRawIntBits(v))
            fun v3(v: V3) { f32(v.x); f32(v.y); f32(v.z) }
            u32(magic2); u32(sk.bones.size)
            for (b in sk.bones) {
                val nm = b.name.toByteArray(Charsets.UTF_8).let { if (it.size > 200) it.copyOf(200) else it }
                u32(nm.size); bo.write(nm)
                u32(b.parent)
                for (c in 0 until 4) { val col = b.bindWorld.col(c); for (r in 0 until 4) f32(col[r]) }
                for (c in 0 until 4) { val col = b.restLocal.col(c); for (r in 0 until 4) f32(col[r]) }
                u32(if (b.physics) 1 else 0)
            }
            u32(joints.size)
            for (k in joints.indices) {
                val j = joints[k]; val w = weights[k]
                u32(j.size / 4)
                for (x in j) { bo.write(x.toInt() and 0xFF); bo.write((x.toInt() ushr 8) and 0xFF) }
                for (x in w) f32(x)
            }
            // physics trailer
            val bodies = sk.phys?.bodies ?: mutableListOf(); val pj = sk.phys?.joints ?: mutableListOf()
            u32(bodies.size)
            for (b in bodies) {
                u32(b.bone); u32(max(b.group, 0)); u32(max(b.mask, 0)); u32(max(b.shape, 0))
                v3(b.size); v3(b.pos); f32(b.rot.x); f32(b.rot.y); f32(b.rot.z); f32(b.rot.w)
                f32(b.mass); f32(b.linDamp); f32(b.angDamp); f32(b.repulsion); f32(b.friction); u32(max(b.mode, 0))
            }
            u32(pj.size)
            for (j in pj) { u32(j.a); u32(j.b); v3(j.pos); v3(j.moveLo); v3(j.moveHi); v3(j.rotLo); v3(j.rotHi); v3(j.springMove); v3(j.springRot) }
            try { File(path).writeBytes(bo.toByteArray()) } catch (_: Exception) {}
        }

        fun read(path: String): Triple<Skeleton3D, List<ShortArray>, List<FloatArray>>? {
            val data = try { File(path).readBytes() } catch (_: Exception) { return null }
            if (data.size <= 8) return null
            var o = 0
            fun u32(): Int { if (o + 4 > data.size) { o = data.size + 1; return 0 }; val v = (data[o].toInt() and 0xFF) or ((data[o + 1].toInt() and 0xFF) shl 8) or ((data[o + 2].toInt() and 0xFF) shl 16) or ((data[o + 3].toInt() and 0xFF) shl 24); o += 4; return v }
            fun f32(): Float = java.lang.Float.intBitsToFloat(u32())
            fun v3(): V3 { val x = f32(); val y = f32(); val z = f32(); return V3(x, y, z) }
            fun mat(): M4 { val m = M4.identity(); for (c in 0 until 4) { val a = f32(); val b = f32(); val cc = f32(); val d = f32(); m.setCol(c, V4(a, b, cc, d)) }; return m }
            val mg = u32()
            if (!(mg == magic1 || mg == magic2)) return null
            val nb = u32(); if (!(nb > 0 && nb < 100_000)) return null
            val sk = Skeleton3D()
            for (i in 0 until nb) {
                val nl = u32(); if (!(nl in 0 until 400 && o + nl <= data.size)) return null     // Swift UInt32 -> Int: huge values fail the < 400 test
                val name = String(data, o, nl, Charsets.UTF_8); o += nl
                val parent = u32()
                val bind = mat(); val rest = mat()
                val bn = Bone3D(name, parent, bind, rest)
                bn.physics = u32() != 0
                sk.bones.add(bn)
            }
            val np = u32(); if (!(np in 0 until 10_000)) return null
            val J = ArrayList<ShortArray>(); val W = ArrayList<FloatArray>()
            for (i in 0 until np) {
                val n = u32(); if (!(n >= 0 && o.toLong() + n.toLong() * 24 <= data.size)) return null
                val j = ShortArray(n * 4); val w = FloatArray(n * 4)
                for (k in 0 until n * 4) { j[k] = ((data[o].toInt() and 0xFF) or ((data[o + 1].toInt() and 0xFF) shl 8)).toShort(); o += 2 }
                for (k in 0 until n * 4) w[k] = f32()
                J.add(j); W.add(w)
            }
            if (mg == magic2 && o + 8 <= data.size) {
                val ph = Physics3D()
                val nbod = u32()
                if (nbod >= 0 && nbod < 100_000 && o.toLong() + nbod.toLong() * 80 <= data.size) {
                    for (i in 0 until nbod) {
                        val bone = u32(); val grp = u32(); val mask = u32(); val shape = u32()
                        val size = v3(); val pos = v3()
                        val qx = f32(); val qy = f32(); val qz = f32(); val qw = f32()
                        val mass = f32(); val ld = f32(); val ad = f32(); val rep = f32(); val fr = f32()
                        val mode = u32()
                        ph.bodies.add(PmxBody(bone, grp, mask, shape, size, pos, Quat(qx, qy, qz, qw), mass, ld, ad, rep, fr, mode))
                    }
                    val nj = u32()
                    if (nj >= 0 && nj < 200_000 && o.toLong() + nj.toLong() * 92 <= data.size) {
                        for (i in 0 until nj) {
                            val a = u32(); val c = u32()
                            val pos = v3(); val ml = v3(); val mh = v3(); val rl = v3(); val rh = v3(); val sm = v3(); val sr = v3()
                            ph.joints.add(PmxJoint(a, c, pos, ml, mh, rl, rh, sm, sr))
                        }
                    }
                    if (ph.active) {
                        for (bd in ph.bodies) if (bd.mode != 0 && bd.bone >= 0 && bd.bone < sk.bones.size) sk.bones[bd.bone].physics = true
                        sk.phys = ph
                    }
                }
            }
            return Triple(sk, J, W)
        }
    }
}
