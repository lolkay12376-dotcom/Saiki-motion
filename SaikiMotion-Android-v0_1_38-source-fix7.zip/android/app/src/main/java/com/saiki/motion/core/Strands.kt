package com.saiki.motion.core

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Port of Sources/Render/Strands.swift — BCC Organic Strands: deterministic 3D strand field (pure function of seed + time).
 * PARITY-NOTE(Strands.swift:7): h() hashes sin(x*127.1+311.7)*43758.5453 in Float; Kotlin's sin(Float) computes in double and rounds
 * back, so the fract can differ from iOS sinf() by ~1 ulp — amplified into different (but equally deterministic) noise.
 */
object StrandsSim {
    private fun h(x: Float): Float { val s = sin(x * 127.1f + 311.7f) * 43758.5453f; return s - floor(s) }

    private fun lat(x: Int, y: Int, z: Int, seed: Float): Float =
        h(x.toFloat() * 1.0f + y.toFloat() * 57.0f + z.toFloat() * 113.0f + seed * 17.0f)

    /** Smooth 3D value noise in 0...1. */
    @JvmStatic fun noise3(x: Float, y: Float, z: Float, seed: Float): Float {
        val xi = floor(x).toInt(); val yi = floor(y).toInt(); val zi = floor(z).toInt()
        val fx = x - floor(x); val fy = y - floor(y); val fz = z - floor(z)
        val ux = fx * fx * (3 - 2 * fx); val uy = fy * fy * (3 - 2 * fy); val uz = fz * fz * (3 - 2 * fz)
        fun l2(a: Float, b: Float, t: Float): Float = a + (b - a) * t
        val c00 = l2(lat(xi, yi, zi, seed), lat(xi + 1, yi, zi, seed), ux)
        val c10 = l2(lat(xi, yi + 1, zi, seed), lat(xi + 1, yi + 1, zi, seed), ux)
        val c01 = l2(lat(xi, yi, zi + 1, seed), lat(xi + 1, yi, zi + 1, seed), ux)
        val c11 = l2(lat(xi, yi + 1, zi + 1, seed), lat(xi + 1, yi + 1, zi + 1, seed), ux)
        return l2(l2(c00, c10, uy), l2(c01, c11, uy), uz)
    }

    /** Swift Float.rounded(): half away from zero. */
    private fun rnd(v: Float): Int = (if (v < 0f) -floor(-v + 0.5f) else floor(v + 0.5f)).toInt()

    @JvmStatic fun field(l: Layer, lt: Float, t: Float): List<Particle> {
        fun P(k: String): Float = l.p(k, lt)
        val seed = P("stSeed")
        val nStr = max(1, min(P("stCount").toInt(), 600))
        val dens = max(2, min(P("stDensity").toInt(), 150))
        val total = min(nStr * dens, 40000)
        val per = max(2, total / nStr)
        val pd = Math.PI.toFloat() / 180f
        // strand direction basis
        var dir = V3(P("stDirX"), P("stDirY"), P("stDirZ"))
        if (dot(dir, dir) < 1e-6f) dir = V3(0f, 1f, 0f)
        dir = normalize(dir)
        val up = if (abs(dir.y) > 0.95f) V3(1f, 0f, 0f) else V3(0f, 1f, 0f)
        val tu = normalize(cross(dir, up)); val tv = cross(dir, tu)
        val spread = P("stSpread") * pd
        val len0 = P("stLength"); val lenVar = P("stLenVar")
        val thick = P("stThick"); val thickVar = P("stThickVar"); val taper = P("stTaper")
        val grav = P("stGravity")
        val shape = rnd(P("stShape"))
        val scx = P("stScaleX"); val scy = P("stScaleY"); val scz = P("stScaleZ")
        val bend = P("stBend"); val freq = max(0.05f, P("stFreq")); val nThick = P("stNThick")
        val evoT = t * P("stEvSpeed")
        val evx = P("stEvX") + evoT; val evy = P("stEvY") + evoT; val evz = P("stEvZ") + evoT
        val indiv = P("stIndiv") > 0.5f
        val srcSup = P("stSrcSup"); val dstSup = P("stDstSup")
        val destOn = P("stDestOn") > 0.5f
        val dest = V3(P("stDX"), P("stDY"), P("stDZ")); val pull = P("stPull")
        val mv = P("stMove") + t * P("stMoveSpeed"); val mvRand = P("stMoveRand"); val loop = max(0.2f, P("stLoop"))
        val gs = P("stGScale"); val cen = V3(P("stCX"), P("stCY"), P("stCZ"))
        val rx = P("stRotX") * pd; val ry = P("stRotY") * pd; val rz = P("stRotZ") * pd
        val cx = cos(rx); val sx = sin(rx); val cy = cos(ry); val sy = sin(ry); val cz = cos(rz); val sz = sin(rz)
        val mirror = rnd(P("stMirror"))
        val soft = P("stSoft")
        val out = ArrayList<Particle>(nStr * per * (if (mirror > 0) 2 else 1))

        for (j in 0 until nStr) {
            val b = j.toFloat() * 1.618f + seed * 7.13f
            val h1 = h(b); val h2 = h(b + 3.7f); val h3 = h(b + 8.1f); val h4 = h(b + 12.9f); val h5 = h(b + 17.3f)
            // source point
            var B = V3(0f, 0f, 0f)
            when (shape) {
                1 -> B = V3((h1 - 0.5f) * 2 * scx, 0f, 0f)
                2 -> { val a = h1 * 2 * Math.PI.toFloat(); B = V3(cos(a) * scx, sin(a) * scy, 0f) }
                3 -> {
                    val z = h1 * 2 - 1; val a = h2 * 2 * Math.PI.toFloat(); val r = sqrt(1 - z * z)
                    B = V3(r * cos(a) * scx, r * sin(a) * scy, z * scz)
                }
                4 -> B = V3((h1 - 0.5f) * 2 * scx, (h2 - 0.5f) * 2 * scy, 0f)
                else -> {}
            }
            // direction inside the spread cone
            val ca = spread * sqrt(h3); val az = h4 * 2 * Math.PI.toFloat()
            val d = normalize(dir * cos(ca) + (tu * cos(az) + tv * sin(az)) * sin(ca))
            val L = len0 * (1 + (h5 - 0.5f) * 2 * lenVar)
            val tk = thick * (1 + (h3 - 0.5f) * 2 * thickVar)
            val nOff = if (indiv) V3(h1, h2, h3) * 20f else V3(0f, 0f, 0f)
            val mvj = mv + mvRand * h2 * loop

            for (i in 0 until per) {
                val u = i.toFloat() / (per - 1).toFloat()
                val a = (u + mvj) / loop
                val s = (a - floor(a))            // 0...1 along the strand (loops back to the source)
                val sa = s * loop
                var p = B + d * (L * sa)
                p = V3(p.x, p.y - grav * L * sa * sa * 0.5f, p.z)
                if (destOn) p = p + (dest - (B + d * (L * sa))) * pull * sa
                val qx = p.x * freq + evx + nOff.x; val qy = p.y * freq + evy + nOff.y; val qz = p.z * freq + evz + nOff.z
                val nx = noise3(qx, qy, qz, seed) - 0.5f
                val ny = noise3(qx + 31.4f, qy, qz, seed) - 0.5f
                val nz = noise3(qx, qy + 17.9f, qz + 5.5f, seed) - 0.5f
                val ramp = (1 - srcSup) + srcSup * min(1f, sa / 0.3f * (1 / max(len0, 0.001f)) * 0.3f)
                val tip = (1 - dstSup) + dstSup * (1 - s * s)
                val k = bend * 2 * L * sa * ramp * tip
                p = V3(p.x + nx * k, p.y + ny * k, p.z + nz * k)
                val nt = noise3(qx * 1.7f + 9, qy * 1.7f, qz * 1.7f, seed + 1)
                var size = tk * max(0.04f, 1 - taper * s) * (1 + nThick * (nt - 0.5f) * 2)
                size = max(0.02f, size)
                // global scale + rotation + centre
                var vx = p.x * gs; var vy = p.y * gs; var vz = p.z * gs
                var y1 = vy * cx - vz * sx; var z1 = vy * sx + vz * cx; vy = y1; vz = z1
                val x2 = vx * cy + vz * sy; z1 = -vx * sy + vz * cy; vx = x2; vz = z1
                val x3 = vx * cz - vy * sz; y1 = vx * sz + vy * cz; vx = x3; vy = y1
                vx += cen.x; vy += cen.y; vz += cen.z
                size *= gs
                out.add(Particle(vx, vy, vz, size, s, soft))
                if (mirror == 1 || mirror == 3) out.add(Particle(-vx, vy, vz, size, s, soft))
                else if (mirror == 2) out.add(Particle(vx, -vy, vz, size, s, soft))
            }
        }
        return out
    }
}
