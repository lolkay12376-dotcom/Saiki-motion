package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.math.BigDecimal
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Port of the Terrain MODEL code: Sources/UI/TerrainPanel.swift lines 1-616 (TKind, TNode, HImg, HeightImages, TerrainGraph,
 * PLayer, TerrainPBR, TerrainGLB) + Sources/UI/TerrainNodeEditor.swift 13-101 and 561-575 (TGNode, TGWire, TGraph, TKind.desc).
 * The TerrainPanel / TerrainNodeEditor views themselves are slice 9.
 * PARITY-NOTE(TerrainPanel.swift:145,159,178): sin/cos/pow/exp go through kotlin.math (computed in double, rounded back to Float),
 * so heights can differ from iOS's sinf/powf/expf by 1 ulp.
 * HeightImages.load (TerrainPanel.swift:61) / TerrainPBR.raster (:403) decode via BitmapFactory + createScaledBitmap instead of
 * CGContext: luma weights (0.299/0.587/0.114) and alpha premultiplication are replicated by hand; resampling is bilinear either way.
 */

// ExtrasPanel.swift:54 / :117 — minimal data holders needed by TerrainPBR/TerrainGLB.
// The PolyHaven download UI and ExtrasGLB.build are ported in ui/ExtrasPanel.kt (PolyHavenNet / the ExtrasGLB extension);
// they consume these holders — do not redefine them here.
object PolyHaven {
    class Maps(val diff: Bitmap? = null, val nor: Bitmap? = null, val rough: Bitmap? = null, val metal: Bitmap? = null, val ao: Bitmap? = null, val disp: Bitmap? = null)
}
object ExtrasGLB {
    class Packed(val base: ByteArray? = null, val mr: ByteArray? = null, val occ: ByteArray? = null, val hasNormal: Boolean = false, val height: ByteArray? = null)
}

class TParam(val name: String, val lo: Float, val hi: Float, val def: Float, val opts: List<String>? = null)

enum class TKind(val raw: Int) {
    noise(0), ridged(1), hills(2), craters(3), warp(4), terrace(5), curve(6), level(7), smooth(8), erode(9), island(10), voronoi(11),
    gradient(12), invert(13), blend(14), baked(15), constant(16), billow(17), waves(18), dunes(19), slope(20), sharpen(21), heightTex(22), pbr(23);

    val title: String get() = TITLES[raw]
    /** SF Symbol name (UI slice maps to Android vector icons). */
    val icon: String get() = ICONS[raw]
    val isGen: Boolean get() = when (this) {
        noise, ridged, hills, craters, voronoi, gradient, constant, billow, waves, dunes, heightTex -> true
        else -> false
    }

    val params: List<TParam> get() {
        val mix = TParam("Mix", 0f, 3f, 0f, listOf("Add", "Mul", "Max", "Replace"))
        return when (this) {
            noise, ridged, billow -> listOf(TParam("Scale", 1f, 16f, 3f), TParam("Detail", 1f, 8f, 5f), TParam("Roughness", 0f, 1f, 0.5f), TParam("Strength", 0f, 1f, 1f), TParam("Seed", 1f, 99f, 1f), mix)
            hills -> listOf(TParam("Scale", 1f, 10f, 3f), TParam("Strength", 0f, 1f, 1f), mix)
            craters -> listOf(TParam("Count", 1f, 40f, 10f), TParam("Size", 0.03f, 0.3f, 0.1f), TParam("Depth", 0f, 1f, 0.5f), TParam("Seed", 1f, 99f, 1f))
            warp -> listOf(TParam("Amount", 0f, 0.3f, 0.08f), TParam("Scale", 1f, 10f, 3f), TParam("Seed", 1f, 99f, 1f))
            terrace -> listOf(TParam("Steps", 2f, 20f, 6f), TParam("Sharpness", 0f, 1f, 0.6f))
            curve -> listOf(TParam("Power", 0.3f, 4f, 1.5f))
            level -> listOf(TParam("Low", 0f, 1f, 0f), TParam("High", 0f, 1f, 1f))
            smooth -> listOf(TParam("Iterations", 1f, 12f, 2f))
            erode -> listOf(TParam("Iterations", 1f, 40f, 12f), TParam("Talus", 0.002f, 0.06f, 0.015f), TParam("Amount", 0f, 1f, 0.5f))
            island -> listOf(TParam("Radius", 0.2f, 1f, 0.8f), TParam("Falloff", 0.05f, 1f, 0.4f))
            voronoi -> listOf(TParam("Cells", 2f, 30f, 8f), TParam("Strength", 0f, 1f, 1f), TParam("Seed", 1f, 99f, 1f), TParam("Style", 0f, 2f, 0f, listOf("Plateaus", "Edges", "Cones")), mix)
            gradient -> listOf(TParam("Angle", 0f, 360f, 0f), TParam("Strength", 0f, 1f, 1f), TParam("Shape", 0f, 1f, 0f, listOf("Linear", "Radial")), mix)
            blend -> listOf(TParam("Mode", 0f, 4f, 0f, listOf("Add", "Mul", "Max", "Min", "Lerp")), TParam("Factor", 0f, 1f, 0.5f))
            invert, baked -> emptyList()
            constant -> listOf(TParam("Value", 0f, 1f, 0.5f), mix)
            waves -> listOf(TParam("Frequency", 1f, 30f, 8f), TParam("Angle", 0f, 360f, 0f), TParam("Warp", 0f, 1f, 0.3f), TParam("Strength", 0f, 1f, 1f), mix)
            dunes -> listOf(TParam("Frequency", 1f, 20f, 6f), TParam("Angle", 0f, 360f, 30f), TParam("Sharpness", 0f, 1f, 0.5f), TParam("Strength", 0f, 1f, 1f), TParam("Seed", 1f, 99f, 1f), mix)
            slope -> listOf(TParam("Gain", 0.5f, 6f, 2f))
            sharpen -> listOf(TParam("Amount", 0f, 3f, 1f))
            heightTex -> listOf(TParam("Strength", 0f, 1f, 1f), TParam("Invert", 0f, 1f, 0f, listOf("Off", "On")), TParam("Blur", 0f, 8f, 0f), mix)
            pbr -> listOf(TParam("Tiling", 1f, 30f, 6f), TParam("Strength", 0f, 1f, 1f), TParam("Height from", 0f, 1f, 0f), TParam("Height to", 0f, 1f, 1f), TParam("Height soft", 0f, 0.5f, 0.15f), TParam("Slope from", 0f, 1f, 0f), TParam("Slope to", 0f, 1f, 1f))
        }
    }

    /** TerrainNodeEditor.swift:561 */
    val desc: String get() = when (this) {
        noise -> "Smooth fractal noise"; ridged -> "Sharp mountain ridges"; billow -> "Soft rounded hills"
        hills -> "Gentle rolling hills"; voronoi -> "Cells, edges, cones"; waves -> "Straight or warped ripples"
        dunes -> "Sand dune ridges"; gradient -> "Linear / radial ramp"; craters -> "Impact craters"
        constant -> "Flat value"; warp -> "Bend shapes with noise"; terrace -> "Stepped plateaus"
        curve -> "Power curve on heights"; level -> "Clamp low / high"; smooth -> "Blur the heights"
        erode -> "Thermal erosion"; island -> "Fade to sea at edges"; invert -> "Flip high and low"
        slope -> "Steepness map"; sharpen -> "Crisper detail"; blend -> "Combine two heightfields"
        heightTex -> "Import a height-map image"; pbr -> "Import or pick PBR maps"; baked -> ""
    }

    companion object {
        @JvmStatic fun fromRaw(r: Int): TKind? = values().firstOrNull { it.raw == r }
        private val TITLES = listOf("Noise", "Ridged noise", "Rolling hills", "Craters", "Domain warp", "Terrace", "Curve", "Level / plateau", "Smooth", "Erosion", "Island mask", "Voronoi cells", "Gradient", "Invert", "Blend (2 inputs)", "Graph", "Constant", "Billow noise", "Waves", "Dunes", "Slope map", "Sharpen", "Height texture", "PBR material")
        private val ICONS = listOf("waveform", "mountain.2", "water.waves", "circle.dashed", "tornado", "chart.bar.fill", "point.topleft.down.curvedto.point.bottomright.up", "arrow.up.and.down.square", "drop", "wind", "circle.hexagongrid", "hexagon", "slider.horizontal.below.rectangle", "circle.lefthalf.filled", "arrow.triangle.merge", "point.3.connected.trianglepath.dotted", "equal.square", "cloud", "wave.3.right", "sun.dust", "angle", "wand.and.stars", "photo", "paintpalette")
    }
}

class HImg(val w: Int, val h: Int, val d: FloatArray)

class TNode(val kind: TKind, over: Map<Int, Float> = emptyMap()) {
    var p: FloatArray = FloatArray(0)
    var on = true
    val id: Int = counter.incrementAndGet()
    var img: HImg? = null
    init {
        p = kind.params.map { it.def }.toFloatArray()
        for ((i, v) in over) if (i < p.size) p[i] = v
    }
    companion object { private val counter = AtomicInteger(0) }
}

object HeightImages {
    private val cache = HashMap<String, HImg>()
    @JvmStatic @Synchronized fun load(path: String?): HImg? {
        if (path == null || path.isEmpty()) return null
        cache[path]?.let { return it }
        val bm = BitmapFactory.decodeFile(path) ?: return null
        val k = min(1.0, 512.0 / max(bm.width, bm.height).toDouble())
        val w = max(2, (bm.width.toDouble() * k).toInt()); val h = max(2, (bm.height.toDouble() * k).toInt())
        val sc = if (bm.width == w && bm.height == h) bm else Bitmap.createScaledBitmap(bm, w, h, true)
        val px = IntArray(w * h); sc.getPixels(px, 0, w, 0, 0, w, h)
        val d = FloatArray(w * h) {
            val c = px[it]; val a = Color.alpha(c) / 255f      // CG gray context starts black: colour × alpha
            val g = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) * a
            (max(0, min(255, (g + 0.5f).toInt())).toFloat()) / 255f
        }
        val im = HImg(w, h, d); cache[path] = im; return im
    }
}

object TerrainGraph {
    /** the node-graph editor result (evaluated at the requested resolution); used by the `.baked` node */
    @JvmStatic var bakedEval: ((Int, Float, Int) -> FloatArray)? = null

    private fun hash(x: Int, y: Int, s: Int): Float {
        var h = x * 374761393 + y * 668265263 + s * 1274126177
        h = (h xor (h ushr 13)) * 1274126177
        return ((h xor (h ushr 16)) and 0xFFFF).toFloat() / 65535f
    }
    private fun vn(x: Float, y: Float, s: Int): Float {
        val ix = floor(x).toInt(); val iy = floor(y).toInt(); val fx = x - floor(x); val fy = y - floor(y)
        val sx = fx * fx * (3 - 2 * fx); val sy = fy * fy * (3 - 2 * fy)
        val a = hash(ix, iy, s); val b = hash(ix + 1, iy, s); val c = hash(ix, iy + 1, s); val d = hash(ix + 1, iy + 1, s)
        return (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sy
    }
    private fun fbm(a: Float, b: Float, scale: Float, oct: Int, rough: Float, seed: Int, ridged: Boolean): Float {
        var amp = 1f; var f = scale; var sum = 0f; var norm = 0f
        for (i in 0 until oct) {
            var n = vn(a * f, b * f, seed + i * 31)
            if (ridged) { val r = 1 - abs(2 * n - 1); n = r * r }
            sum += n * amp; norm += amp
            amp *= 0.3f + 0.45f * rough; f *= 2.03f
        }
        return sum / norm
    }
    private fun sstep(a: Float, b: Float, x: Float): Float { val t = max(0f, min(1f, (x - a) / (b - a))); return t * t * (3 - 2 * t) }
    private fun lerp3(a: V3, b: V3, t: Float): V3 = a + (b - a) * t

    @JvmStatic fun boxBlur(a: FloatArray, res: Int, it: Int): FloatArray {
        val R = res + 1; val f = a.copyOf()
        for (n in 0 until max(it, 0)) {
            val s = f.copyOf()
            for (j in 0 until R) for (i in 0 until R) {
                var t = 0f
                for (dj in -1..1) for (di in -1..1) t += s[min(max(i + di, 0), res) + min(max(j + dj, 0), res) * R]
                f[i + j * R] = t / 9
            }
        }
        return f
    }
    private fun norm(f: FloatArray) {
        if (f.isEmpty()) return
        var lo = f[0]; var hi = f[0]
        for (v in f) { if (v < lo) lo = v; if (v > hi) hi = v }
        if (!(hi - lo > 1e-6f)) return
        val k = 1 / (hi - lo); for (i in f.indices) f[i] = (f[i] - lo) * k
    }
    private fun mix(f: Float, n: Float, s: Float, mode: Int): Float = when (mode) {
        1 -> f * (1 + (n - 1) * s)
        2 -> max(f, n * s)
        3 -> f + (n - f) * s
        else -> f + n * s
    }

    /** Evaluates the node stack on a (res+1)² grid; result 0...1 with edge fade and sea floor applied. */
    @JvmStatic fun eval(nodes: List<TNode>, res: Int, edge: Float, sea: Float, scale: Float = 1f, seed: Int = 0,
                        masks: ((Int, FloatArray) -> Unit)? = null, initial: FloatArray? = null, raw: Boolean = false): FloatArray {
        val R = res + 1; val inv = 1 / res.toFloat()
        var f = initial?.copyOf() ?: FloatArray(R * R)
        val zs = 1 / max(scale, 0.05f); val so = seed * 7919
        fun zc(t: Float): Float = 0.5f + (t - 0.5f) * zs
        for (nd in nodes) {
            if (!nd.on) continue
            val p = nd.p
            val before = if (masks != null) f.copyOf() else FloatArray(0)
            when (nd.kind) {
                TKind.noise, TKind.ridged, TKind.billow -> {
                    val mode = p[5].toInt(); val sd = p[4].toInt() + so; val ob = p[1].toInt(); val rg = nd.kind == TKind.ridged
                    for (j in 0 until R) for (i in 0 until R) {
                        var n = fbm(zc(i * inv), zc(j * inv), p[0], ob, p[2], sd, rg)
                        if (nd.kind == TKind.billow) n = abs(2 * n - 1)
                        f[i + j * R] = mix(f[i + j * R], n, p[3], mode)
                    }
                }
                TKind.hills -> {
                    for (j in 0 until R) for (i in 0 until R) {
                        val a = zc(i * inv); val b = zc(j * inv); val k = p[0] / 3; val ph = seed.toFloat() * 0.37f
                        val n = 0.5f + 0.28f * sin(a * 6.2f * k + 0.7f + ph) * cos(b * 5.1f * k + ph) + 0.14f * sin(a * 13 * k + b * 9 * k) * cos(b * 11 * k - a * 4 * k + ph)
                        f[i + j * R] = mix(f[i + j * R], n, p[1], p[2].toInt())
                    }
                }
                TKind.craters -> {
                    norm(f)
                    for (c in 0 until p[0].toInt()) {
                        val csd = p[3].toInt() + so
                        val cx = 0.5f + (hash(c, 1, csd) - 0.5f) * scale; val cy = 0.5f + (hash(c, 2, csd) - 0.5f) * scale
                        val r = p[1] * (0.5f + hash(c, 3, csd)) * scale
                        val j0 = max(0, ((cy - r * 1.4f) * res.toFloat()).toInt()); val j1 = min(res, ((cy + r * 1.4f) * res.toFloat()).toInt() + 1)
                        val i0 = max(0, ((cx - r * 1.4f) * res.toFloat()).toInt()); val i1 = min(res, ((cx + r * 1.4f) * res.toFloat()).toInt() + 1)
                        if (j0 > j1 || i0 > i1) continue
                        for (j in j0..j1) for (i in i0..i1) {
                            val dx = i * inv - cx; val dy = j * inv - cy; val d = sqrt(dx * dx + dy * dy) / r
                            val bowl = if (d < 1) -(1 - d * d) else 0f
                            val rim = 0.35f * exp(-(d - 1) * (d - 1) * 18)
                            f[i + j * R] += (bowl + rim) * p[2] * 0.4f
                        }
                    }
                }
                TKind.warp -> {
                    val src = f.copyOf(); val sd = p[2].toInt() + so
                    for (j in 0 until R) for (i in 0 until R) {
                        val a = i * inv; val b = j * inv
                        val x = max(0f, min(1f, a + (vn(zc(a) * p[1], zc(b) * p[1], sd) - 0.5f) * 2 * p[0])) * res.toFloat()
                        val y = max(0f, min(1f, b + (vn(zc(a) * p[1], zc(b) * p[1], sd + 17) - 0.5f) * 2 * p[0])) * res.toFloat()
                        val x0 = min(x.toInt(), res - 1); val y0 = min(y.toInt(), res - 1); val fx = x - x0.toFloat(); val fy = y - y0.toFloat()
                        val v0 = src[x0 + y0 * R] * (1 - fx) + src[x0 + 1 + y0 * R] * fx
                        val v1 = src[x0 + (y0 + 1) * R] * (1 - fx) + src[x0 + 1 + (y0 + 1) * R] * fx
                        f[i + j * R] = v0 * (1 - fy) + v1 * fy
                    }
                }
                TKind.terrace -> {
                    norm(f)
                    val n = p[0]
                    for (k in f.indices) {
                        val s = f[k] * n; val fl = floor(s); val fr = s - fl
                        val sharp = if (fr < 0.5f) 0.5f * (fr * 2).pow(1 + p[1] * 5) else 1 - 0.5f * ((1 - fr) * 2).pow(1 + p[1] * 5)
                        f[k] = (fl + sharp) / n
                    }
                }
                TKind.curve -> { norm(f); for (k in f.indices) f[k] = max(f[k], 0f).pow(p[0]) }
                TKind.level -> {
                    norm(f)
                    val lo = min(p[0], p[1] - 0.01f); val hi = max(p[1], lo + 0.01f)
                    for (k in f.indices) f[k] = max(0f, min(1f, (f[k] - lo) / (hi - lo)))
                }
                TKind.smooth -> {
                    for (it in 0 until p[0].toInt()) {
                        val s = f.copyOf()
                        for (j in 1 until res) for (i in 1 until res) {
                            var t = 0f
                            for (dj in -1..1) for (di in -1..1) t += s[(i + di) + (j + dj) * R]
                            f[i + j * R] = t / 9
                        }
                    }
                }
                TKind.erode -> {
                    norm(f)
                    val tal = p[1]; val amt = p[2] * 0.25f
                    val dirs = arrayOf(intArrayOf(1, 0), intArrayOf(0, 1), intArrayOf(-1, 0), intArrayOf(0, -1))
                    for (it in 0 until p[0].toInt()) {
                        val dl = FloatArray(R * R)
                        for (j in 0 until R) for (i in 0 until R) {
                            val k = i + j * R
                            for (dd in dirs) {
                                val ni = i + dd[0]; val nj = j + dd[1]
                                if (ni < 0 || nj < 0 || ni > res || nj > res) continue
                                val d = f[k] - f[ni + nj * R]
                                if (d > tal) { val m = amt * (d - tal); dl[k] -= m; dl[ni + nj * R] += m }
                            }
                        }
                        for (k in f.indices) f[k] += dl[k]
                    }
                }
                TKind.voronoi -> {
                    val cells = p[0]; val sd = p[2].toInt() + so; val style = p[3].toInt(); val mode = p[4].toInt()
                    for (j in 0 until R) for (i in 0 until R) {
                        val a = zc(i * inv) * cells; val b = zc(j * inv) * cells
                        val ia = floor(a).toInt(); val ib = floor(b).toInt()
                        var d1 = 9f; var d2 = 9f; var cid = 0f
                        for (dj in -1..1) for (di in -1..1) {
                            val cx = ia + di; val cy = ib + dj
                            val qx = cx.toFloat() + hash(cx, cy, sd); val qy = cy.toFloat() + hash(cx, cy, sd + 77)
                            val d = sqrt((qx - a) * (qx - a) + (qy - b) * (qy - b))
                            if (d < d1) { d2 = d1; d1 = d; cid = hash(cx, cy, sd + 5) } else if (d < d2) { d2 = d }
                        }
                        val n = if (style == 0) cid else (if (style == 1) 1 - sstep(0f, 0.18f, d2 - d1) else 1 - min(d1, 1f))
                        f[i + j * R] = mix(f[i + j * R], n, p[1], mode)
                    }
                }
                TKind.gradient -> {
                    val ang = p[0] * Math.PI.toFloat() / 180; val ca = cos(ang); val sa = sin(ang); val radial = p[2].toInt() == 1; val mode = p[3].toInt()
                    for (j in 0 until R) for (i in 0 until R) {
                        val x = zc(i * inv) - 0.5f; val y = zc(j * inv) - 0.5f
                        val n = if (radial) 1 - min(1f, sqrt(x * x + y * y) * 2) else max(0f, min(1f, 0.5f + x * ca + y * sa))
                        f[i + j * R] = mix(f[i + j * R], n, p[1], mode)
                    }
                }
                TKind.invert -> { norm(f); for (k in f.indices) f[k] = 1 - f[k] }
                TKind.blend, TKind.pbr -> {}
                TKind.constant -> { val mode = p[1].toInt(); for (k in f.indices) f[k] = mix(f[k], p[0], 1f, mode) }
                TKind.waves -> {
                    val fr = p[0]; val ang = p[1] * Math.PI.toFloat() / 180; val ca = cos(ang); val sa = sin(ang); val mode = p[4].toInt()
                    for (j in 0 until R) for (i in 0 until R) {
                        val a = zc(i * inv); val b = zc(j * inv); val w = vn(a * 3, b * 3, so + 9)
                        f[i + j * R] = mix(f[i + j * R], 0.5f + 0.5f * sin(6.2832f * fr * (a * ca + b * sa) + p[2] * 6 * w), p[3], mode)
                    }
                }
                TKind.dunes -> {
                    val fr = p[0]; val ang = p[1] * Math.PI.toFloat() / 180; val ca = cos(ang); val sa = sin(ang); val sd = p[4].toInt() + so; val mode = p[5].toInt()
                    for (j in 0 until R) for (i in 0 until R) {
                        val a = zc(i * inv); val b = zc(j * inv); val w = vn(a * 2, b * 2, sd)
                        val s = 0.5f + 0.5f * sin(6.2832f * fr * (a * ca + b * sa) + w * 5)
                        val n = s.pow(1 + p[2] * 3) * (0.4f + 0.6f * vn(a * 4, b * 4, sd + 3))
                        f[i + j * R] = mix(f[i + j * R], n, p[3], mode)
                    }
                }
                TKind.slope -> {
                    norm(f)
                    val o = FloatArray(R * R)
                    for (j in 1 until res) for (i in 1 until res) {
                        val gx = f[i + 1 + j * R] - f[i - 1 + j * R]; val gz = f[i + (j + 1) * R] - f[i + (j - 1) * R]
                        o[i + j * R] = sqrt(gx * gx + gz * gz)
                    }
                    norm(o); for (k in o.indices) o[k] = max(o[k], 0f).pow(1 / p[0])
                    f = o
                }
                TKind.sharpen -> {
                    val b = boxBlur(f, res, 1)
                    for (k in f.indices) f[k] += (f[k] - b[k]) * p[0] * 2
                }
                TKind.heightTex -> {
                    val im = nd.img
                    if (im != null) {
                        var t = FloatArray(R * R)
                        for (j in 0 until R) for (i in 0 until R) {
                            val u = max(0f, min(1f, zc(i * inv))) * (im.w - 1).toFloat(); val v = max(0f, min(1f, zc(j * inv))) * (im.h - 1).toFloat()
                            val x0 = min(u.toInt(), im.w - 2); val y0 = min(v.toInt(), im.h - 2); val fx = u - x0.toFloat(); val fy = v - y0.toFloat()
                            val a = im.d[x0 + y0 * im.w] * (1 - fx) + im.d[x0 + 1 + y0 * im.w] * fx
                            val b = im.d[x0 + (y0 + 1) * im.w] * (1 - fx) + im.d[x0 + 1 + (y0 + 1) * im.w] * fx
                            t[i + j * R] = a * (1 - fy) + b * fy
                        }
                        if (p[2] >= 1) t = boxBlur(t, res, p[2].toInt())
                        if (p[1] > 0.5f) for (k in t.indices) t[k] = 1 - t[k]
                        for (k in f.indices) f[k] = mix(f[k], t[k], p[0], p[3].toInt())
                    }
                }
                TKind.baked -> { val g = bakedEval; if (g != null) { val r = g(res, scale, seed); if (r.size == f.size) f = r.copyOf() } }
                TKind.island -> {
                    norm(f)
                    for (j in 0 until R) for (i in 0 until R) {
                        val dx = i * inv - 0.5f; val dy = j * inv - 0.5f; val d = sqrt(dx * dx + dy * dy) * 2
                        f[i + j * R] *= 1 - sstep(p[0] - p[1], p[0], d)
                    }
                }
            }
            if (masks != null) {      // this node's own influence 0...1 (used to assign PBR layers per node)
                val d = FloatArray(f.size)
                if (nd.kind == TKind.noise || nd.kind == TKind.ridged || nd.kind == TKind.hills) {
                    for (k in f.indices) d[k] = f[k] - before[k]
                    norm(d)
                } else {
                    var mxv = 1e-6f
                    for (k in f.indices) { d[k] = abs(f[k] - before[k]); mxv = max(mxv, d[k]) }
                    for (k in f.indices) d[k] /= mxv
                }
                masks(nd.id, d)
            }
        }
        if (raw) return f
        norm(f)
        for (j in 0 until R) for (i in 0 until R) {
            var v = f[i + j * R]
            if (edge > 0) {
                val e = min(min(i * inv, 1 - i * inv), min(j * inv, 1 - j * inv)) * 2
                v *= sstep(0f, max(edge, 0.01f), e)
            }
            f[i + j * R] = max(v, sea)
        }
        return f
    }

    /** Procedural colour: shore sand → grass → rock → snow by height (0...1), slope and sea level. */
    @JvmStatic fun colour(t: Float, slope: Float, sea: Float): V3 {
        val r = max(1 - sea, 0.05f); val h = (t - sea) / r
        var c = lerp3(V3(0.76f, 0.68f, 0.46f), V3(0.28f, 0.5f, 0.2f), sstep(0.04f, 0.2f, h))
        c = lerp3(c, V3(0.45f, 0.42f, 0.4f), max(sstep(0.5f, 0.75f, h), sstep(0.12f, 0.35f, slope)))
        return lerp3(c, V3(0.95f, 0.95f, 0.95f), sstep(0.8f, 0.95f, h) * (1 - sstep(0.2f, 0.5f, slope)))
    }

    /** Small shaded preview: terrain colours, or (weights = true) the PBR layer weight map. */
    @JvmStatic fun preview(nodes: List<TNode>, edge: Float, sea: Float, scale: Float, seed: Int, amp: Float, layers: List<PLayer>, weights: Boolean, size: Int = 96): Bitmap? {
        val F = TerrainPBR.analyse(nodes, size, edge, sea, scale, seed, amp)
        val f = F.f; val R = size + 1; val wm = weights && layers.isNotEmpty()
        val px = IntArray(size * size)
        val L = normalize(V3(-0.5f, 0.7f, -0.5f))
        for (j in 0 until size) for (i in 0 until size) {
            val hx = f[min(i + 1, size) + j * R] - f[max(i - 1, 0) + j * R]; val hz = f[i + min(j + 1, size) * R] - f[i + max(j - 1, 0) * R]
            val n = normalize(V3(-hx * 6, 1f, -hz * 6))
            val sh = 0.35f + 0.75f * max(0f, dot(n, L)); val k = i + j * R; val t = f[k]
            val c: V3
            if (t <= sea + 0.001f) c = V3(0.16f, 0.36f, 0.55f)
            else if (wm) {
                val w = TerrainPBR.vertexW(F, layers, sea, k); var mxw = 0f; for (x in w) mxw = max(mxw, x); if (w.isEmpty()) mxw = 0f
                val wb = 1 - min(1f, mxw)
                var acc = V3(0.4f, 0.4f, 0.4f) * wb; var tot = wb
                for ((li, x) in w.withIndex()) { acc = acc + TerrainPBR.palette[li % 8] * x; tot += x }
                c = acc / max(tot, 1e-4f)
            } else c = colour(t, 1 - n.y, sea)
            val r8 = max(0, min(255, (c.x * sh * 255).toInt())); val g8 = max(0, min(255, (c.y * sh * 255).toInt())); val b8 = max(0, min(255, (c.z * sh * 255).toInt()))
            px[i + j * size] = Color.argb(255, r8, g8, b8)
        }
        return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
    }

    // name, nodes, edge fade, sea
    class Preset(val name: String, val nodes: List<TNode>, val edge: Float, val sea: Float)
    val presets: List<Preset> by lazy {
        listOf(
            Preset("Rolling hills", listOf(TNode(TKind.hills, mapOf(2 to 3f)), TNode(TKind.noise, mapOf(0 to 6f, 3 to 0.15f, 5 to 0f))), 0.3f, 0f),
            Preset("Mountains", listOf(TNode(TKind.ridged, mapOf(0 to 3f, 2 to 0.55f, 5 to 3f)), TNode(TKind.noise, mapOf(0 to 8f, 3 to 0.2f, 5 to 0f)), TNode(TKind.erode), TNode(TKind.curve, mapOf(0 to 1.4f))), 0.25f, 0f),
            Preset("Islands", listOf(TNode(TKind.noise, mapOf(0 to 3f, 5 to 3f)), TNode(TKind.warp), TNode(TKind.island, mapOf(0 to 0.85f, 1 to 0.5f)), TNode(TKind.smooth)), 0.15f, 0.22f),
            Preset("Mesa / canyon", listOf(TNode(TKind.noise, mapOf(0 to 2.5f, 5 to 3f)), TNode(TKind.warp, mapOf(0 to 0.1f)), TNode(TKind.level, mapOf(0 to 0.15f, 1 to 0.7f)), TNode(TKind.terrace, mapOf(0 to 5f, 1 to 0.5f)), TNode(TKind.erode, mapOf(0 to 6f))), 0.25f, 0f),
            Preset("Cratered moon", listOf(TNode(TKind.noise, mapOf(0 to 4f, 3 to 0.4f, 5 to 3f)), TNode(TKind.craters, mapOf(0 to 25f, 1 to 0.08f, 2 to 0.7f))), 0.3f, 0f))
    }
}

// MARK: - PBR layers

class PLayer(var id: Int, var nodes: MutableList<Int> = ArrayList(), var tex: String? = null, var texName: String = "", var tiling: Float = 6f, var strength: Float = 1f) {
    var hLo = 0f; var hHi = 1f; var hSoft = 0.15f       // height above sea, 0...1
    var sLo = 0f; var sHi = 1f; var sSoft = 0.15f       // slope, 0 flat ... 1 steep
    var wLo = 0f; var wHi = 0.5f; var wSoft = 0.05f     // shore: height above sea level (field units)
    var on = true
}

object TerrainPBR {
    @JvmField val palette: List<V3> = listOf(V3(1f, 0.3f, 0.3f), V3(0.3f, 0.8f, 0.3f), V3(0.3f, 0.5f, 1f), V3(1f, 0.85f, 0.2f),
        V3(0.8f, 0.4f, 1f), V3(0.2f, 0.9f, 0.9f), V3(1f, 0.6f, 0.2f), V3(0.9f, 0.5f, 0.7f))
    class Field(val f: FloatArray, val slope: FloatArray, val masks: Map<Int, FloatArray>, val res: Int)
    class TexSet(val s: Int, var avg: V3 = V3(0.5f, 0.5f, 0.5f), val diff: ByteArray?, val nor: ByteArray?, val rough: ByteArray?, val metal: ByteArray?, val ao: ByteArray?, val disp: ByteArray?)
    class Smp(var c: V3 = V3(0f, 0f, 0f), var r: Float = 0.9f, var m: Float = 0f, var ao: Float = 1f, var h: Float = 0.5f, var nx: Float = 0f, var ny: Float = 0f)
    class SplatLayer(val d: ByteArray, val n: ByteArray, val r: ByteArray, val tile: Float, val str: Float)
    class SplatData(val w0: ByteArray, val w1: ByteArray, val layers: List<SplatLayer>)

    @JvmStatic fun sst(a: Float, b: Float, x: Float): Float { val t = max(0f, min(1f, (x - a) / max(b - a, 1e-5f))); return t * t * (3 - 2 * t) }
    @JvmStatic fun band(lo: Float, hi: Float, soft: Float, x: Float, open: Float): Float {
        val up = if (lo <= 0) 1f else sst(lo - soft * 0.5f, lo + soft * 0.5f, x)
        val dn = if (hi >= open) 1f else 1 - sst(hi - soft * 0.5f, hi + soft * 0.5f, x)
        return up * dn
    }

    @JvmStatic fun analyse(nodes: List<TNode>, res: Int, edge: Float, sea: Float, scale: Float, seed: Int, amp: Float): Field {
        val masks = HashMap<Int, FloatArray>()
        val f = TerrainGraph.eval(nodes, res, edge, sea, scale, seed, masks = { id, a -> masks[id] = a })
        val R = res + 1; val step = 1 / res.toFloat()
        val sl = FloatArray(R * R)
        for (j in 0 until R) for (i in 0 until R) {
            val i0 = max(i - 1, 0); val i1 = min(i + 1, res); val j0 = max(j - 1, 0); val j1 = min(j + 1, res)
            val gx = (f[i1 + j * R] - f[i0 + j * R]) * amp / ((i1 - i0).toFloat() * step); val gz = (f[i + j1 * R] - f[i + j0 * R]) * amp / ((j1 - j0).toFloat() * step)
            sl[i + j * R] = min(1f, (1 - 1 / sqrt(gx * gx + gz * gz + 1)) * 3)
        }
        return Field(f, sl, masks, res)
    }

    /** Rule weight of every layer at vertex k: node mask × height band × slope band × shore band. */
    @JvmStatic fun vertexW(F: Field, L: List<PLayer>, sea: Float, k: Int): FloatArray {
        val t = F.f[k]; val h = (t - sea) / max(1 - sea, 0.05f); val shore = t - sea; val sl = F.slope[k]
        return FloatArray(L.size) { li ->
            val l = L[li]
            var m = 1f
            if (l.nodes.isNotEmpty()) { m = 0f; for (n in l.nodes) { val a = F.masks[n]; if (a != null) m = max(m, a[k]) }; m = sst(0.1f, 0.5f, m) }
            m * band(l.hLo, l.hHi, l.hSoft, h, 1f) * band(l.sLo, l.sHi, l.sSoft, sl, 1f) * band(l.wLo, l.wHi, l.wSoft, shore, 0.5f)
        }
    }

    // MARK: texture sampling
    /** RGBA8 premultiplied raster of the image scaled to s×s (CGContext substitute). */
    @JvmStatic fun raster(img: Bitmap?, s: Int): ByteArray? {
        if (img == null) return null
        val sc = if (img.width == s && img.height == s) img else Bitmap.createScaledBitmap(img, s, s, true)
        val px = IntArray(s * s); sc.getPixels(px, 0, s, 0, 0, s, s)
        val d = ByteArray(s * s * 4)
        for (i in px.indices) {
            val c = px[i]; val a = Color.alpha(c)
            var r = Color.red(c); var g = Color.green(c); var b = Color.blue(c)
            if (a < 255) { r = (r * a + 127) / 255; g = (g * a + 127) / 255; b = (b * a + 127) / 255 }
            d[i * 4] = r.toByte(); d[i * 4 + 1] = g.toByte(); d[i * 4 + 2] = b.toByte(); d[i * 4 + 3] = a.toByte()
        }
        return d
    }
    @JvmStatic fun texSet(m: PolyHaven.Maps, s: Int): TexSet {
        fun g(i: Bitmap?): ByteArray? { val r = raster(i, s) ?: return null; return ByteArray(s * s) { r[it * 4] } }
        val ts = TexSet(s, diff = raster(m.diff, s), nor = raster(m.nor, s), rough = g(m.rough), metal = g(m.metal), ao = g(m.ao), disp = g(m.disp))
        val d = ts.diff
        if (d != null) {
            var ax = 0f; var ay = 0f; var az = 0f; var cnt = 0f
            var p = 0
            while (p < d.size / 4) {
                ax += (d[p * 4].toInt() and 255).toFloat() / 255; ay += (d[p * 4 + 1].toInt() and 255).toFloat() / 255; az += (d[p * 4 + 2].toInt() and 255).toFloat() / 255
                cnt += 1; p += 37
            }
            if (cnt > 0) ts.avg = V3(ax / cnt, ay / cnt, az / cnt)
        }
        return ts
    }
    @JvmStatic fun bil(a: ByteArray, s: Int, x: Float, y: Float, st: Int, c: Int): Float {
        val X = (x - floor(x)) * s.toFloat(); val Y = (y - floor(y)) * s.toFloat()
        val x0 = min(X.toInt(), s - 1); val y0 = min(Y.toInt(), s - 1); val tx = X - x0.toFloat(); val ty = Y - y0.toFloat()
        val x1 = (x0 + 1) % s; val y1 = (y0 + 1) % s
        fun u(i: Int) = (a[i].toInt() and 255).toFloat()
        val p00 = u((x0 + y0 * s) * st + c); val p10 = u((x1 + y0 * s) * st + c); val p01 = u((x0 + y1 * s) * st + c); val p11 = u((x1 + y1 * s) * st + c)
        return ((p00 + (p10 - p00) * tx) * (1 - ty) + (p01 + (p11 - p01) * tx) * ty) / 255
    }
    @JvmStatic fun sample(T: TexSet, x: Float, y: Float, nm: Boolean): Smp {
        val s = Smp(); val z = T.s
        val d = T.diff
        if (d != null) s.c = V3(bil(d, z, x, y, 4, 0), bil(d, z, x, y, 4, 1), bil(d, z, x, y, 4, 2)) else s.c = V3(0.5f, 0.5f, 0.5f)
        T.rough?.let { s.r = bil(it, z, x, y, 1, 0) }
        T.metal?.let { s.m = bil(it, z, x, y, 1, 0) }
        T.ao?.let { s.ao = bil(it, z, x, y, 1, 0) }
        T.disp?.let { s.h = bil(it, z, x, y, 1, 0) }
        val n = T.nor
        if (nm && n != null) { s.nx = bil(n, z, x, y, 4, 0) * 2 - 1; s.ny = bil(n, z, x, y, 4, 1) * 2 - 1 }
        return s
    }
    @JvmStatic fun lerpS(a: Smp, b: Smp, t: Float): Smp {
        val o = Smp(); val u = 1 - t
        o.c = a.c * u + b.c * t; o.r = a.r * u + b.r * t; o.m = a.m * u + b.m * t; o.ao = a.ao * u + b.ao * t
        o.h = a.h * u + b.h * t; o.nx = a.nx * u + b.nx * t; o.ny = a.ny * u + b.ny * t
        return o
    }
    /** Anti-repeat: the texture at two scales (second one rotated 37°), mixed by a slow low-frequency pattern. */
    @JvmStatic fun mix2(T: TexSet, x: Float, y: Float, u: Float, v: Float, nm: Boolean): Smp {
        val a = sample(T, x, y, nm); val cs = 0.7986f; val sn = 0.6018f
        val b = sample(T, (x * cs - y * sn) * 0.93f + 17.3f, (x * sn + y * cs) * 0.93f + 5.1f, nm)
        val bx = b.nx; val by = b.ny; b.nx = bx * cs + by * sn; b.ny = -bx * sn + by * cs
        val k = 0.5f + 0.3f * sin(u * 9.1f + v * 5.3f) * cos(v * 7.7f - u * 3.9f)
        val o = lerpS(a, b, k)
        val g = 1 / sqrt(k * k + (1 - k) * (1 - k))      // variance-preserving blend
        o.c = T.avg + (o.c - T.avg) * g; o.h = 0.5f + (o.h - 0.5f) * g; o.nx *= g; o.ny *= g
        return o
    }
    /** Planar sample; on steep slopes blended with an XY/ZY projection (triplanar-like) so cliffs don't stretch. */
    @JvmStatic fun layerSample(T: TexSet, L: PLayer, u: Float, v: Float, yh: Float, sl: Float): Smp {
        val tl = L.tiling
        var s = mix2(T, u * tl, v * tl, u, v, true)
        val st = sst(0.35f, 0.75f, sl)
        if (st > 0.02f) {
            val t = lerpS(mix2(T, u * tl, yh * tl, u, v, false), mix2(T, v * tl, yh * tl, u, v, false), 0.5f)
            t.nx = s.nx; t.ny = s.ny
            s = lerpS(s, t, st)
        }
        return s
    }
    /** UIImage(from RGBA bytes) + jpegData/pngData substitute. */
    private fun encode(d: ByteArray, T: Int, jpeg: Boolean, q: Int): ByteArray? {
        val px = IntArray(T * T) { Color.argb(d[it * 4 + 3].toInt() and 255, d[it * 4].toInt() and 255, d[it * 4 + 1].toInt() and 255, d[it * 4 + 2].toInt() and 255) }
        val bm = Bitmap.createBitmap(px, T, T, Bitmap.Config.ARGB_8888)
        val bo = ByteArrayOutputStream()
        val ok = if (jpeg) bm.compress(Bitmap.CompressFormat.JPEG, q, bo) else bm.compress(Bitmap.CompressFormat.PNG, 100, bo)
        return if (ok) bo.toByteArray() else null
    }
    @JvmStatic fun jpeg(d: ByteArray, T: Int): ByteArray? = encode(d, T, true, 90)
    @JvmStatic fun png(d: ByteArray, T: Int): ByteArray? = encode(d, T, false, 100)
    @JvmStatic fun b8(v: Float): Byte = max(0, min(255, (v * 255).toInt())).toByte()

    /** Splat export: only the rule weight maps (1024) and a procedural macro colour are baked here. Max 4 textured layers. */
    @JvmStatic fun bake(o: TerrainGLB.Opt, all: List<PLayer>, sets: Map<String, TexSet>, size: Int): Pair<ExtrasGLB.Packed, SplatData>? {
        val layers = all.filter { it.tex != null && sets[it.tex!!] != null }.take(4)
        if (layers.isEmpty()) return null
        val F = analyse(o.nodes, o.res, o.edge, o.sea, o.scale, o.seed, o.height)
        val res = o.res; val R = res + 1; val n = layers.size; val sea = o.sea; val T = 1024
        val VW = Array(n) { FloatArray(R * R) }
        for (k in 0 until R * R) { val w = vertexW(F, layers, sea, k); for (l in 0 until n) VW[l][k] = w[l] }
        val w0 = ByteArray(T * T * 4) { 255.toByte() }; val w1 = w0.copyOf(); val base = w0.copyOf()
        val resF = res.toFloat(); val invT = 1 / T.toFloat()
        for (y in 0 until T) {
            val v = (y.toFloat() + 0.5f) * invT; val gy = min(v * resF, resF - 0.001f); val j0 = gy.toInt(); val fy = gy - j0.toFloat()
            for (x in 0 until T) {
                val u = (x.toFloat() + 0.5f) * invT; val gx = min(u * resF, resF - 0.001f); val i0 = gx.toInt(); val fx = gx - i0.toFloat()
                val k00 = i0 + j0 * R; val k10 = k00 + 1; val k01 = k00 + R; val k11 = k01 + 1
                val a00 = (1 - fx) * (1 - fy); val a10 = fx * (1 - fy); val a01 = (1 - fx) * fy; val a11 = fx * fy
                val q = (x + y * T) * 4
                for (l in 0 until n) {
                    val a = VW[l]; val w = a[k00] * a00 + a[k10] * a10 + a[k01] * a01 + a[k11] * a11
                    if (l < 3) w0[q + l] = b8(w) else w1[q] = b8(w)
                }
                for (l in n until 3) w0[q + l] = 0
                if (n < 4) w1[q] = 0
                w1[q + 1] = 0; w1[q + 2] = 0
                val t = F.f[k00] * a00 + F.f[k10] * a10 + F.f[k01] * a01 + F.f[k11] * a11
                val sl = F.slope[k00] * a00 + F.slope[k10] * a10 + F.slope[k01] * a01 + F.slope[k11] * a11
                val tint = 0.9f + 0.2f * (0.5f + 0.5f * sin(u * 17 + sin(v * 11) * 2) * cos(v * 13 - u * 5))
                val c = TerrainGraph.colour(t, sl / 3, sea) * tint
                base[q] = b8(c.x); base[q + 1] = b8(c.y); base[q + 2] = b8(c.z)
            }
        }
        val ph = ByteArray(16 * 4) { 255.toByte() }; val po = ph.copyOf()
        for (i in 0 until 16) { ph[i * 4] = 128.toByte(); ph[i * 4 + 1] = 230.toByte(); ph[i * 4 + 2] = 0; po[i * 4] = 255.toByte(); po[i * 4 + 1] = 128.toByte(); po[i * 4 + 2] = 128.toByte() }
        val out = ArrayList<SplatLayer>()
        for (L in layers) {
            val ts = sets[L.tex!!]!!; val z = ts.s; val cnt = z * z
            val dd = ByteArray(cnt * 4) { 255.toByte() }; val nm = dd.copyOf(); val rh = dd.copyOf()
            for (i in 0 until cnt) {
                val d = ts.diff
                if (d != null) { dd[i * 4] = d[i * 4]; dd[i * 4 + 1] = d[i * 4 + 1]; dd[i * 4 + 2] = d[i * 4 + 2] } else { dd[i * 4] = 128.toByte(); dd[i * 4 + 1] = 128.toByte(); dd[i * 4 + 2] = 128.toByte() }
                nm[i * 4] = ts.nor?.get(i * 4) ?: 128.toByte(); nm[i * 4 + 1] = ts.nor?.get(i * 4 + 1) ?: 128.toByte(); nm[i * 4 + 2] = ts.ao?.get(i) ?: 255.toByte()
                rh[i * 4] = ts.disp?.get(i) ?: 128.toByte(); rh[i * 4 + 1] = ts.rough?.get(i) ?: 230.toByte(); rh[i * 4 + 2] = ts.metal?.get(i) ?: 0
            }
            val dj = jpeg(dd, z); val np = png(nm, z); val rp = png(rh, z)
            if (dj == null || np == null || rp == null) continue
            out.add(SplatLayer(dj, np, rp, L.tiling, L.strength))
        }
        if (out.isEmpty()) return null
        val wa = png(w0, T) ?: return null; val wb = png(w1, T) ?: return null
        val pk = ExtrasGLB.Packed(base = jpeg(base, T), mr = png(ph, 4), occ = png(po, 4), hasNormal = true)
        return Pair(pk, SplatData(wa, wb, out))
    }
}

object TerrainGLB {
    class Opt(var nodes: List<TNode> = emptyList(), var res: Int = 128, var height: Float = 0.25f, var edge: Float = 0.3f, var sea: Float = 0f, var tiles: Int = 4, var scale: Float = 1f, var seed: Int = 0)

    @JvmStatic fun build(o: Opt, p: ExtrasGLB.Packed?, splat: TerrainPBR.SplatData? = null): ByteArray {
        val res = o.res; val R = res + 1
        val amp = o.height
        val field = TerrainGraph.eval(o.nodes, res, o.edge, o.sea, o.scale, o.seed)
        val hs = FloatArray(R * R) { field[it] * amp }
        val nv = R * R
        val pos = FloatArray(nv * 3); val nor = FloatArray(nv * 3); val uv = FloatArray(nv * 2); val col = FloatArray(nv * 4); val idx = IntArray(res * res * 6)
        val step = 1 / res.toFloat()
        var q = 0
        for (j in 0 until R) for (i in 0 until R) {
            val a = i.toFloat() * step; val b = j.toFloat() * step; val y = hs[i + j * R]
            pos[q * 3] = (a - 0.5f) * o.scale; pos[q * 3 + 1] = y * o.scale; pos[q * 3 + 2] = (b - 0.5f) * o.scale
            val dx = hs[min(i + 1, res) + j * R] - hs[max(i - 1, 0) + j * R]; val dz = hs[i + min(j + 1, res) * R] - hs[i + max(j - 1, 0) * R]
            val sx = (min(i + 1, res) - max(i - 1, 0)).toFloat() * step; val sz = (min(j + 1, res) - max(j - 1, 0)).toFloat() * step
            val n = normalize(V3(-dx / sx, 1f, -dz / sz))
            nor[q * 3] = n.x; nor[q * 3 + 1] = n.y; nor[q * 3 + 2] = n.z
            uv[q * 2] = a * o.tiles.toFloat(); uv[q * 2 + 1] = b * o.tiles.toFloat()
            if (p?.base != null) { col[q * 4] = 1f; col[q * 4 + 1] = 1f; col[q * 4 + 2] = 1f; col[q * 4 + 3] = 1f } else {      // no texture: shore → grass → rock → snow
                val c = TerrainGraph.colour(if (amp > 0) y / amp else 0.5f, 1 - n.y, o.sea)
                col[q * 4] = c.x; col[q * 4 + 1] = c.y; col[q * 4 + 2] = c.z; col[q * 4 + 3] = 1f
            }
            q++
        }
        var t = 0
        for (j in 0 until res) for (i in 0 until res) {
            val a = i + j * R
            idx[t++] = a; idx[t++] = a + 1; idx[t++] = a + R; idx[t++] = a + 1; idx[t++] = a + R + 1; idx[t++] = a + R
        }
        val bin = ByteArrayOutputStream(); val views = JSONArray()
        fun add(d: ByteArray, tg: Int?): Int {
            while (bin.size() % 4 != 0) bin.write(0)
            val v = JSONObject(); v.put("buffer", 0); v.put("byteOffset", bin.size()); v.put("byteLength", d.size)
            if (tg != null) v.put("target", tg)
            bin.write(d); views.put(v); return views.length() - 1
        }
        fun fbytes(a: FloatArray): ByteArray { val b = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (x in a) b.putFloat(x); return b.array() }
        fun ibytes(a: IntArray): ByteArray { val b = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (x in a) b.putInt(x); return b.array() }
        val vp = add(fbytes(pos), 34962); val vn_ = add(fbytes(nor), 34962); val vu = add(fbytes(uv), 34962); val vi = add(ibytes(idx), 34963); val vc = add(fbytes(col), 34962)
        val mn = floatArrayOf(1e9f, 1e9f, 1e9f); val mx = floatArrayOf(-1e9f, -1e9f, -1e9f)
        for (i in 0 until nv) for (k in 0 until 3) { mn[k] = min(mn[k], pos[i * 3 + k]); mx[k] = max(mx[k], pos[i * 3 + k]) }
        fun farr(a: FloatArray): JSONArray { val r = JSONArray(); for (x in a) r.put(x as Any); return r }
        fun accessor(view: Int, ct: Int, count: Int, type: String): JSONObject {
            val a = JSONObject(); a.put("bufferView", view); a.put("componentType", ct); a.put("count", count); a.put("type", type); return a
        }
        val acc = JSONArray()
        acc.put(accessor(vp, 5126, nv, "VEC3").also { it.put("min", farr(mn)); it.put("max", farr(mx)) })
        acc.put(accessor(vn_, 5126, nv, "VEC3")); acc.put(accessor(vu, 5126, nv, "VEC2")); acc.put(accessor(vi, 5125, idx.size, "SCALAR")); acc.put(accessor(vc, 5126, nv, "VEC4"))
        val images = JSONArray(); val textures = JSONArray()
        fun tex(d: ByteArray?, mime: String): Int? {
            if (d == null) return null
            val im = JSONObject(); im.put("bufferView", add(d, null)); im.put("mimeType", mime); images.put(im)
            val tx = JSONObject(); tx.put("source", images.length() - 1); tx.put("sampler", 0); textures.put(tx)
            return textures.length() - 1
        }
        fun ti(i: Int) = JSONObject().put("index", i)
        val pbr = JSONObject(); pbr.put("metallicFactor", 1.0); pbr.put("roughnessFactor", 1.0)
        val mat = JSONObject(); mat.put("doubleSided", true)
        val b = tex(p?.base, "image/jpeg")
        if (b != null) pbr.put("baseColorTexture", ti(b)) else pbr.put("baseColorFactor", JSONArray().put(1).put(1).put(1).put(1))
        val m = tex(p?.mr, "image/png")
        if (m != null) pbr.put("metallicRoughnessTexture", ti(m)) else { pbr.put("metallicFactor", 0.0); pbr.put("roughnessFactor", 0.9) }
        val oc = tex(p?.occ, "image/png")
        if (oc != null) mat.put("occlusionTexture", ti(oc))
        mat.put("pbrMetallicRoughness", pbr)
        val asset = JSONObject(); asset.put("version", "2.0"); asset.put("generator", "SaikiMotion Terrain")
        if (splat != null) {
            val ls = JSONArray()
            for (L in splat.layers) { val lo = JSONObject(); lo.put("d", add(L.d, null)); lo.put("n", add(L.n, null)); lo.put("r", add(L.r, null)); lo.put("tile", L.tile as Any); lo.put("str", L.str as Any); ls.put(lo) }
            val sp = JSONObject(); sp.put("w0", add(splat.w0, null)); sp.put("w1", add(splat.w1, null)); sp.put("layers", ls)
            asset.put("extras", JSONObject().put("splat", sp))
        }
        val json = JSONObject()
        json.put("asset", asset); json.put("scene", 0); json.put("scenes", JSONArray().put(JSONObject().put("nodes", JSONArray().put(0))))
        json.put("nodes", JSONArray().put(JSONObject().put("mesh", 0)))
        val attrs = JSONObject().put("POSITION", 0).put("NORMAL", 1).put("TEXCOORD_0", 2).put("COLOR_0", 4)
        json.put("meshes", JSONArray().put(JSONObject().put("primitives", JSONArray().put(JSONObject().put("attributes", attrs).put("indices", 3).put("material", 0)))))
        json.put("materials", JSONArray().put(mat)); json.put("accessors", acc); json.put("bufferViews", views)
        while (bin.size() % 4 != 0) bin.write(0)
        json.put("buffers", JSONArray().put(JSONObject().put("byteLength", bin.size())))
        json.put("samplers", JSONArray().put(JSONObject().put("magFilter", 9729).put("minFilter", 9987).put("wrapS", 10497).put("wrapT", 10497)))
        json.put("images", images); json.put("textures", textures)
        var js = json.toString().toByteArray(Charsets.UTF_8)
        if (js.size % 4 != 0) { val pad = 4 - js.size % 4; js = js + ByteArray(pad) { 0x20 } }
        val bb = bin.toByteArray()
        val out = ByteBuffer.allocate(12 + 8 + js.size + 8 + bb.size).order(ByteOrder.LITTLE_ENDIAN)
        out.putInt(0x46546C67); out.putInt(2); out.putInt(12 + 8 + js.size + 8 + bb.size)
        out.putInt(js.size); out.putInt(0x4E4F534A); out.put(js)
        out.putInt(bb.size); out.putInt(0x004E4942); out.put(bb)
        return out.array()
    }
}

// MARK: - TerrainNodeEditor.swift 13-101: wire graph model

class TGNode(var id: Int, var kind: Int, var p: FloatArray, var x: Double, var y: Double, var on: Boolean = true,
             var tex: String? = null, var texName: String? = null, var files: List<String>? = null, var img: String? = null) {
    fun copy() = TGNode(id, kind, p.copyOf(), x, y, on, tex, texName, files?.toList(), img)
}
class TGWire(var from: Int, var to: Int, var port: Int)

class TGraph {
    var nodes: MutableList<TGNode> = ArrayList(); var wires: MutableList<TGWire> = ArrayList(); var next = 1
    var height = 0.35f; var edge = 0.25f; var sea = 0f; var scale = 1f; var seed = 1f

    /** value copy (Swift struct semantics) */
    fun copy(): TGraph {
        val g = TGraph(); g.nodes = nodes.map { it.copy() }.toMutableList(); g.wires = wires.map { TGWire(it.from, it.to, it.port) }.toMutableList()
        g.next = next; g.height = height; g.edge = edge; g.sea = sea; g.scale = scale; g.seed = seed; return g
    }

    fun add(k: TKind, x: Double, y: Double): Int {
        val id = next; next += 1
        nodes.add(TGNode(id, k.raw, k.params.map { it.def }.toFloatArray(), x, y)); return id
    }
    fun node(id: Int): TGNode? = nodes.firstOrNull { it.id == id }
    fun inputs(n: TGNode): Int = if (n.kind < 0) 2 else (if (TKind.fromRaw(n.kind) == TKind.blend) 2 else (if (TKind.fromRaw(n.kind) == TKind.pbr) 0 else 1))
    fun hasOutput(n: TGNode): Boolean = n.kind >= 0
    fun source(id: Int, port: Int): Int? = wires.firstOrNull { it.to == id && it.port == port }?.from
    /** true when `a` (transitively) feeds `b` — used to refuse wires that would make a loop */
    fun feeds(a: Int, b: Int, d: Int = 0): Boolean {
        if (a == b) return true
        if (d > 64) return true
        for (w in wires) if (w.to == b) { if (feeds(a, w.from, d + 1)) return true }
        return false
    }

    /** Heightfield before edge / sea / normalise. */
    fun raw(res: Int, scale: Float, seed: Int): FloatArray {
        val R = res + 1; val zero = FloatArray(R * R)
        val memo = HashMap<Int, FloatArray>()
        fun v(id: Int, d: Int): FloatArray? {
            memo[id]?.let { return it }
            if (d >= 64) return null
            val n = node(id) ?: return null; val k = TKind.fromRaw(n.kind) ?: return null
            var a: FloatArray? = source(id, 0)?.let { v(it, d + 1) }
            if (a != null && a.size != R * R) a = null
            val out: FloatArray
            if (!n.on || k == TKind.pbr) out = a ?: zero
            else if (k == TKind.blend) {
                val A = a ?: zero; val B = source(id, 1)?.let { v(it, d + 1) } ?: zero
                val mode = (n.p.firstOrNull() ?: 0f).toInt(); val f = if (n.p.size > 1) n.p[1] else 0.5f
                out = A.copyOf()
                for (i in out.indices) {
                    out[i] = when (mode) {
                        1 -> A[i] * (1 + (B[i] - 1) * f)
                        2 -> max(A[i], B[i] * f)
                        3 -> min(A[i], B[i])
                        4 -> A[i] + (B[i] - A[i]) * f
                        else -> A[i] + B[i] * f
                    }
                }
            } else {
                val t = TNode(k); t.p = n.p.copyOf()
                if (k == TKind.heightTex) t.img = HeightImages.load(n.img)
                out = TerrainGraph.eval(listOf(t), res, 0f, 0f, scale, seed, initial = a, raw = true)
            }
            memo[id] = out; return out
        }
        return source(0, 0)?.let { v(it, 0) } ?: zero
    }
    fun field(res: Int): FloatArray =
        TerrainGraph.eval(emptyList(), res, edge, sea, scale, seed.toInt(), initial = raw(res, scale, seed.toInt()))

    // Codable JSON (Swift JSONEncoder key set; optionals omitted when nil)
    fun json(): String {
        val sb = StringBuilder("{")
        sb.append("\"nodes\":[")
        nodes.forEachIndexed { i, n ->
            if (i > 0) sb.append(',')
            sb.append("{\"id\":").append(n.id).append(",\"kind\":").append(n.kind).append(",\"p\":[")
            n.p.forEachIndexed { k, v -> if (k > 0) sb.append(','); sb.append(num(v.toDouble(), v.toString())) }
            sb.append("],\"x\":").append(num(n.x, n.x.toString())).append(",\"y\":").append(num(n.y, n.y.toString())).append(",\"on\":").append(n.on)
            n.tex?.let { sb.append(",\"tex\":").append(JSONObject.quote(it)) }
            n.texName?.let { sb.append(",\"texName\":").append(JSONObject.quote(it)) }
            n.files?.let { fl -> sb.append(",\"files\":[").append(fl.joinToString(",") { JSONObject.quote(it) }).append(']') }
            n.img?.let { sb.append(",\"img\":").append(JSONObject.quote(it)) }
            sb.append('}')
        }
        sb.append("],\"wires\":[")
        wires.forEachIndexed { i, w -> if (i > 0) sb.append(','); sb.append("{\"from\":").append(w.from).append(",\"to\":").append(w.to).append(",\"port\":").append(w.port).append('}') }
        sb.append("],\"next\":").append(next)
        for ((k, v) in listOf("height" to height, "edge" to edge, "sea" to sea, "scale" to scale, "seed" to seed)) sb.append(",\"").append(k).append("\":").append(num(v.toDouble(), v.toString()))
        return sb.append('}').toString()
    }

    companion object {
        private fun num(d: Double, s: String): String {
            if (d == Math.rint(d) && abs(d) < 1e15) return d.toLong().toString()
            return if (s.contains('E') || s.contains('e')) BigDecimal(s).toPlainString() else s
        }

        @JvmStatic fun make(): TGraph {
            val g = TGraph()
            g.nodes = arrayListOf(TGNode(0, -1, FloatArray(0), 520.0, 70.0))
            val a = g.add(TKind.ridged, 30.0, 30.0); val b = g.add(TKind.erode, 190.0, 60.0); val c = g.add(TKind.curve, 350.0, 90.0)
            g.wires = arrayListOf(TGWire(a, b, 0), TGWire(b, c, 0), TGWire(c, 0, 0))
            return g
        }

        /** The old linear stack as a chain: node1 → node2 → … → Output. */
        @JvmStatic fun fromStack(s: List<TNode>, edge: Float, sea: Float): TGraph {
            val g = TGraph(); g.edge = edge; g.sea = sea
            g.nodes = arrayListOf(TGNode(0, -1, FloatArray(0), 40.0 + s.size.toDouble() * 170, 70.0))
            var prev = -1
            for ((i, n) in s.withIndex()) {
                if (n.kind == TKind.baked) continue
                val id = g.add(n.kind, 30.0 + i.toDouble() * 170, 30.0 + (i % 2).toDouble() * 60)
                val k = g.nodes.indexOfFirst { it.id == id }
                if (k >= 0) { g.nodes[k].p = n.p.copyOf(); g.nodes[k].on = n.on }
                if (prev >= 0) g.wires.add(TGWire(prev, id, 0))
                prev = id
            }
            if (prev >= 0) g.wires.add(TGWire(prev, 0, 0))
            return g
        }

        /** Swift `try? JSONDecoder().decode` — null when a required key is missing/mistyped. */
        @JvmStatic fun from(json: String): TGraph? {
            return try {
                val o = JSONObject(json)
                val g = TGraph()
                val na = o.getJSONArray("nodes"); val wa = o.getJSONArray("wires")
                for (i in 0 until na.length()) {
                    val n = na.getJSONObject(i); val pa = n.getJSONArray("p")
                    val fl = if (n.has("files") && !n.isNull("files")) n.getJSONArray("files").let { a -> List(a.length()) { a.getString(it) } } else null
                    g.nodes.add(TGNode(n.getInt("id"), n.getInt("kind"), FloatArray(pa.length()) { pa.getDouble(it).toFloat() }, n.getDouble("x"), n.getDouble("y"), n.getBoolean("on"),
                        if (n.has("tex") && !n.isNull("tex")) n.getString("tex") else null,
                        if (n.has("texName") && !n.isNull("texName")) n.getString("texName") else null, fl,
                        if (n.has("img") && !n.isNull("img")) n.getString("img") else null))
                }
                for (i in 0 until wa.length()) { val w = wa.getJSONObject(i); g.wires.add(TGWire(w.getInt("from"), w.getInt("to"), w.getInt("port"))) }
                g.next = o.getInt("next"); g.height = o.getDouble("height").toFloat(); g.edge = o.getDouble("edge").toFloat()
                g.sea = o.getDouble("sea").toFloat(); g.scale = o.getDouble("scale").toFloat(); g.seed = o.getDouble("seed").toFloat()
                g
            } catch (e: Exception) { null }
        }
    }
}
