package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import java.text.BreakIterator
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tan

/**
 * Port of Sources/Render/TextRaster.swift: text layers -> Bitmap (ARGB_8888, premultiplied).
 * UIKit NSAttributedString drawing -> Paint/Canvas. Substitutes (unverified vs iOS pixels):
 *  - iOS font families (Georgia, Menlo, ...) -> the Android family names the layer already stores (Typeface.create(l.font)).
 *  - kern = Paint.letterSpacing (em); TextKit omits the kern after the last glyph of a line, so widths subtract it.
 *  - CGContext shadow -> blurred alpha copy of the composite (BlurMaskFilter, sigma = blur/2).
 */
object TextRaster {
    private val customTypefaces = HashMap<String, Typeface?>()

    // MARK: - fonts

    private fun customTypeface(path0: String): Typeface? = synchronized(customTypefaces) {
        val path = FontLibrary.resolve(path0)
        if (customTypefaces.containsKey(path)) return customTypefaces[path]
        val t = try { if (java.io.File(path).exists()) Typeface.createFromFile(path) else null } catch (_: Exception) { null }
        customTypefaces[path] = t; t
    }

    /** UIFont equivalent: a Typeface + pixel size. */
    class TF(val tf: Typeface, val px: Float)

    fun font(l: Layer, px: Float): TF {
        val fp = l.fontPath
        if (fp != null) { val t = customTypeface(fp); if (t != null) return TF(t, px) }
        val style = (if (l.bold) Typeface.BOLD else 0) or (if (l.italic) Typeface.ITALIC else 0)
        return TF(Typeface.create(Typeface.create(l.font, Typeface.NORMAL), style), px)
    }

    private fun transformed(s: String, caps: Int): String {
        if (caps == 1) return s.uppercase(Locale.ROOT)
        if (caps == 2) return s.lowercase(Locale.ROOT)
        return s
    }

    /** Swift Characters (grapheme clusters). */
    private fun chars(s: String): List<String> {
        val out = ArrayList<String>(); val bi = BreakIterator.getCharacterInstance(Locale.ROOT); bi.setText(s)
        var st = bi.first(); var en = bi.next()
        while (en != BreakIterator.DONE) { out.add(s.substring(st, en)); st = en; en = bi.next() }
        return out
    }

    private fun paintFor(f: TF, kernPx: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
        p.typeface = f.tf; p.textSize = f.px; p.letterSpacing = if (f.px > 0f) kernPx / f.px else 0f
        return p
    }
    private fun lineH(p: Paint): Float { val m = p.fontMetrics; return m.descent - m.ascent + m.leading }
    /** TextKit width of one line: no kern after the last glyph. */
    private fun lineW(p: Paint, s: String): Float {
        if (s.isEmpty()) return 0f
        return p.measureText(s) - p.letterSpacing * p.textSize
    }
    /** boundingRect(usesLineFragmentOrigin) of text with '\n' lines: (width, height). */
    private fun bounds(p: Paint, text: String): Pair<Float, Float> {
        val lines = text.split('\n'); var w = 0f
        for (ln in lines) w = max(w, lineW(p, ln))
        return Pair(w, lineH(p) * lines.size)
    }

    // MARK: - keyframable values

    /** Colour with optional keyframes: four channel tracks "tc_<name>_r/g/b/a" win when present. */
    fun col(l: Layer, name: String, fb: Int, t: Float): Int {
        val base = "tc_$name"
        if (l.props[base + "_r"] == null) return fb
        fun ch(sfx: String, def: Int, shift: Int): Int {
            val tr = l.props[base + sfx]
            if (tr != null) return (clamp(tr.eval(t), 0f, 1f) * 255 + 0.5f).toInt()
            return (def ushr shift) and 0xFF
        }
        return (ch("_a", fb, 24) shl 24) or (ch("_r", fb, 16) shl 16) or (ch("_g", fb, 8) shl 8) or ch("_b", fb, 0)
    }

    /** A numeric animation value: its keyframe track when the user made one, else the stored value. */
    fun tv(l: Layer, key: String, fb: Float, t: Float): Float {
        val tr = l.props[key]
        if (tr != null) { val v = tr.eval(t); return if (v.isFinite()) v else fb }
        return fb
    }
    fun fv(l: Layer, fx: TextFx, i: Int, t: Float): Float = tv(l, "fx_${fx.id}_$i", fx.v[i], t)

    // MARK: - measurement

    private class Lay(val tw: Float, val th: Float, val padX: Float, val padY: Float) { val cw get() = tw + padX * 2; val ch get() = th + padY * 2 }

    /** Everything in em units (font size = 1). measure() and raster() both use this. */
    private fun layout(l: Layer, t: Float): Lay {
        val text = transformed(if (l.text.isEmpty()) " " else l.text, l.caps)
        val px = 512f
        val f = font(l, px)
        val b = bounds(paintFor(f, l.p("spacing", t) * px), text)
        val tw = max(b.first, px * 0.3f) / px; val th = max(b.second, px * 0.6f) / px
        var pad = 0.1f + (l.p("strokeW", t) + l.p("stroke2W", t)) + (l.p("borderW", t) + l.p("borderPad", t))
        if (l.shadowOn) pad += abs(l.p("shadowX", t)) + abs(l.p("shadowY", t)) + l.p("shadowBlur", t) * 1.5f
        var ext = 0f
        var trackEm = 0f
        val n = max(chars(text).size, 1).toFloat()
        for (a in l.anims) {
            if (a.type == 12) {
                for (fx in a.fx) {
                    fun v(i: Int) = fv(l, fx, i, t)
                    when (fx.kind) {
                        0 -> ext += max(abs(v(0)), abs(v(1))) + max(0f, v(2) - 1) * 0.7f + (if (v(3) != 0f) 0.4f else 0f)
                        1 -> ext += max(v(0), v(1)) + v(3) * 0.7f + v(2) / 90 * 0.5f
                        2 -> ext += 0.3f
                        3 -> trackEm += abs(v(0)) * n
                        4 -> ext += tan(min(max(abs(v(0)), abs(v(1))), 80f) * Math.PI.toFloat() / 180) * 0.6f
                    }
                }
            } else {
                ext += a.distance + max(0f, a.scaleFrom - 1) * 0.7f + (if (a.type == 6) 0.4f else 0f)
            }
        }
        pad += min(ext, 3f)
        return Lay(tw, th, pad + min(trackEm, 6f), pad)
    }

    /** Size of the whole text bitmap in em-units. */
    fun measure(l: Layer, t: Float = 0f): Pair<Float, Float> { val y = layout(l, t); return Pair(y.cw, y.ch) }

    /** Height of one text line in em-units (the scale reference for quadSize). */
    fun lineHeight(l: Layer, t: Float = 0f): Float = layout(l, t).th

    // MARK: - raster

    private class Style(val l: Layer, val t: Float, val text: String, val f: TF, val kern: Float, val underline: Boolean, val strike: Boolean)

    /** Renders the text layer at time `t0` into a Bitmap (transparent background, premultiplied alpha). */
    fun raster(l: Layer, t0: Float): Bitmap {
        val t: Float = if (t0.isFinite()) min(max(t0, 0f), 100_000f) else 0f
        val text = transformed(if (l.text.isEmpty()) " " else l.text, l.caps)
        val lay = layout(l, t)
        val px = min(256f, 4000f / max(max(lay.cw, lay.ch), 1f))
        val f = font(l, px)

        val spacingV = l.p("spacing", t)
        val kern = spacingV * px
        val strokeWV = l.p("strokeW", t) * px
        val stroke2WV = l.p("stroke2W", t) * px
        val borderWV = l.p("borderW", t)
        val borderPadV = l.p("borderPad", t)
        val borderRadV = l.p("borderRadius", t)
        val shX = l.p("shadowX", t); val shY = l.p("shadowY", t); val shB = l.p("shadowBlur", t)

        val hasAnims = l.anims.isNotEmpty()
        val mp = paintFor(f, kern)
        val padX = lay.padX * px; val padY = lay.padY * px
        val pad = padX
        val tb = bounds(mp, text)
        val borderPadPx = borderPadV * px
        val borderWPx = borderWV * px
        val w = ceil(lay.cw * px).toInt(); val h = ceil(lay.ch * px).toInt()

        val ts = if (hasAnims) (t * 60).toInt().toFloat() / 60 else 0f
        val animSig = l.anims.joinToString("|") { a ->
            "${a.type},${a.mode},${a.start},${a.dur},${a.stagger},${a.distance},${a.scaleFrom},${a.rotFrom},${a.speed},${a.ease},${a.fade},${a.curve.x1},${a.curve.y1},${a.curve.x2},${a.curve.y2}," + a.fx.joinToString(";") { "${it.kind}:${it.v}" }
        } + "#" + l.props.filter { it.key.startsWith("fx_") || it.key.startsWith("an_") }.toSortedMap().values.joinToString(",") { "${it.eval(t)}" }
        val key = "$text|${col(l, "color", l.color, t)}|${col(l, "strokeColor", l.strokeColor, t)}|$strokeWV|${l.font}|${l.fontPath ?: ""}|${l.bold}${l.italic}${l.underline}${l.strike}|$spacingV|${l.align}|${l.caps}|${l.strokePos}|${l.strokeJoin}|$stroke2WV|${col(l, "stroke2Color", l.stroke2Color, t)}|$borderWV|${col(l, "borderColor", l.borderColor, t)}|${col(l, "borderFill", l.borderFill, t)}|$borderPadV|$borderRadV|${l.borderDash}|${l.shadowOn}|$shX|$shY|$shB|${col(l, "shadowColor", l.shadowColor, t)}|$animSig|$ts"
        val ck = key + "-" + String.format(Locale.US, "%d-%d", w, h)   // full key instead of Swift hashValue (no collisions)
        synchronized(cache) { cache[ck]?.let { return it } }

        val bmp = Bitmap.createBitmap(max(w, 1), max(h, 1), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val originY = padY   // first line's top
        val lineWd = tb.first

        // border box behind the text
        if (borderWV > 0.001f || colorAlpha(col(l, "borderFill", l.borderFill, t)) > 0) {
            val bx = pad - borderPadPx - borderWPx / 2
            val by = padY - borderPadPx - borderWPx / 2
            val bw = lineWd + (borderPadPx + borderWPx / 2) * 2
            val bh = tb.second + (borderPadPx + borderWPx / 2) * 2
            val r = min(borderRadV * px, min(bw, bh) / 2)
            val path = Path(); path.addRoundRect(RectF(bx, by, bx + bw, by + bh), r, r, Path.Direction.CW)
            val bf = col(l, "borderFill", l.borderFill, t)
            if (colorAlpha(bf) > 0) { val p = Paint(Paint.ANTI_ALIAS_FLAG); p.style = Paint.Style.FILL; p.color = bf; c.drawPath(path, p) }
            if (borderWV > 0.001f) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG); p.style = Paint.Style.STROKE; p.color = col(l, "borderColor", l.borderColor, t); p.strokeWidth = borderWPx
                if (l.borderDash) p.pathEffect = DashPathEffect(floatArrayOf(borderWPx * 3, borderWPx * 2), 0f)
                c.drawPath(path, p)
            }
        }

        val st = Style(l, t, text, f, kern, l.underline, l.strike)
        // text block (stroke2 -> stroke -> fill), one shadow for the whole composite
        if (l.shadowOn) {
            val layer = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
            drawStyled(Canvas(layer), st, pad, originY, lineWd, hasAnims, px, strokeWV, stroke2WV)
            val sigma = shB * px / 2
            val sp = Paint(Paint.ANTI_ALIAS_FLAG)
            if (sigma > 0f) sp.maskFilter = BlurMaskFilter(max((sigma - 0.5f) / 0.57735f, 0.01f), BlurMaskFilter.Blur.NORMAL)
            val off = IntArray(2)
            val alpha = layer.extractAlpha(sp, off)
            val tint = Paint(Paint.ANTI_ALIAS_FLAG); tint.color = col(l, "shadowColor", l.shadowColor, t)
            c.drawBitmap(alpha, shX * px + off[0], shY * px + off[1], tint)
            c.drawBitmap(layer, 0f, 0f, null)
            alpha.recycle(); layer.recycle()
        } else {
            drawStyled(c, st, pad, originY, lineWd, hasAnims, px, strokeWV, stroke2WV)
        }
        synchronized(cache) { cache[ck] = bmp; cacheOrder.add(ck); trimCache() }
        return bmp
    }

    /** Layers the passes back to front: second stroke, stroke, fill. Stroke passes draw outline only, centred, width in px. */
    private fun drawStyled(c: Canvas, s: Style, pad: Float, originY: Float, lineW: Float, animated: Boolean, px: Float, sw: Float, sw2: Float) {
        val l = s.l; val t = s.t
        fun pass(fill: Int?, strokeColor: Int?, widthPx: Float) = drawTextBlock(c, s, fill, strokeColor, widthPx, pad, originY, lineW, animated, px)
        val fill = col(l, "color", l.color, t)
        val sc = col(l, "strokeColor", l.strokeColor, t)
        // stroke is centred on the outline: outside = 2x, center = 1x, inside = 1x over the fill
        val pos = l.strokePos
        val outerW = if (pos == 0) sw * 2 else sw
        if (sw2 > 0.01f) pass(null, col(l, "stroke2Color", l.stroke2Color, t), (outerW / 2 + sw2) * 2 + (if (pos == 0) 0 else 0))
        if (sw > 0.01f && pos == 0) pass(null, sc, outerW)
        pass(fill, null, 0f)
        if (sw > 0.01f && pos != 0) pass(null, sc, if (pos == 2) sw else sw)
    }

    private fun animEase(a: TextAnim, p: Float): Float = when (a.ease) {
        0 -> p
        1 -> Track.bezier(p, 0f, 0f, 0.58f, 1f)
        2 -> Track.bezier(p, 0.42f, 0f, 0.58f, 1f)
        3 -> Track.bounceOut(p)
        4 -> Track.bezier(p, a.curve.x1, a.curve.y1, a.curve.x2, a.curve.y2)
        else -> p
    }

    /** One pass: fill colour (stroke == null) or outline-only stroke (fill == null). Draws the text (per-letter when animated). */
    private fun drawTextBlock(c: Canvas, s: Style, fill: Int?, strokeColor: Int?, strokePx: Float, pad: Float, originY: Float, lineW: Float, animated: Boolean, px: Float) {
        val l = s.l; val t = s.t; val text = s.text
        fun setup(p: Paint) {
            if (strokeColor != null && strokePx > 0f) { p.style = Paint.Style.STROKE; p.strokeWidth = strokePx; p.strokeMiter = 10f; p.color = strokeColor }
            else if (fill != null) { p.style = Paint.Style.FILL; p.color = fill }
            else { p.style = Paint.Style.FILL; p.color = 0 }   // .clear with no stroke draws nothing
            p.isUnderlineText = s.underline && fill != null; p.isStrikeThruText = s.strike && fill != null
        }
        if (!animated) {
            val p = paintFor(s.f, s.kern); setup(p)
            val b = bounds(p, text)
            val x = when (l.align) { 0 -> pad; 2 -> pad + lineW - b.first; else -> pad + (lineW - b.first) / 2 }
            val lh = lineH(p); val asc = -p.fontMetrics.ascent
            for ((i, ln) in text.split('\n').withIndex()) c.drawText(ln, x, originY + i * lh + asc, p)
            return
        }

        // per-letter: measure each glyph, advance manually, apply anims
        val cs = chars(text)
        var x = pad
        val totalW = lineW
        // total extra width added by Tracking effects, so the line stays aligned while it spreads
        var trackSum = 0f
        for (i in cs.indices) {
            for (a in l.anims) if (a.type == 12) {
                val aStart = tv(l, "an_${a.id}_start", a.start, t)
                val aDur = max(0.05f, tv(l, "an_${a.id}_end", a.start + a.dur, t) - aStart)
                val aStag = tv(l, "an_${a.id}_stag", a.stagger, t)
                val lt = t - aStart - i * aStag
                val p = clamp(lt / aDur, 0f, 1f)
                val e = animEase(a, p)
                val k = if (a.mode == 0) (1 - e) else (if (a.mode == 1) e else sin(p * Math.PI.toFloat()))
                for (fx in a.fx) if (fx.kind == 3) trackSum += fv(l, fx, 0, t) * k * px
            }
        }
        val plain = paintFor(s.f, s.kern)
        if (l.align == 1) x = pad + (totalW - lineW(plain, text) - trackSum) / 2
        if (l.align == 2) x = pad + (totalW - lineW(plain, text) - trackSum)

        val gp = paintFor(s.f, 0f); setup(gp)          // single glyph: no trailing kern in size()
        val glyphH = lineH(gp); val asc = -gp.fontMetrics.ascent
        val maxStagger = l.anims.fold(0f) { m, a -> max(m, a.stagger) }
        val PI = Math.PI.toFloat()
        for ((i, ch) in cs.withIndex()) {
            val gw = lineW(gp, ch).let { if (ch == "\n") 0f else it }
            val delay = i * maxStagger
            var alpha = 1f; var scale = 1f; var rot = 0f; var dx = 0f; var dy = 0f
            var skx = 0f; var sky = 0f; var sx = 1f; var sy = 1f; var persp = 0f; var track = 0f

            for (a in l.anims) {
                val isC = a.type == 12
                val aStart = if (isC) tv(l, "an_${a.id}_start", a.start, t) else a.start
                val aDur = if (isC) max(0.05f, tv(l, "an_${a.id}_end", a.start + a.dur, t) - aStart) else a.dur
                val aStag = if (isC) tv(l, "an_${a.id}_stag", a.stagger, t) else a.stagger
                val lt = t - aStart - (if (isC) i * aStag else delay)
                val p = clamp(lt / max(aDur, 0.05f), 0f, 1f)
                val e = animEase(a, p)
                if (a.type == 12) {
                    // custom: mode 0 in (from -> rest), 1 out (rest -> to), 2 loop (ping-pong)
                    val kk = if (a.mode == 0) (1 - e) else (if (a.mode == 1) e else sin(p * PI))
                    val active = lt >= 0 && lt <= aDur
                    for (fx in a.fx) {
                        val v = List(fx.v.size) { fv(l, fx, it, t) }
                        when (fx.kind) {
                            0 -> {
                                dx += v[0] * kk * px; dy += v[1] * kk * px
                                scale *= 1 + (v[2] - 1) * kk
                                rot += v[3] * kk * PI / 180
                                alpha *= 1 - (1 - v[4]) * kk
                            }
                            1 -> if (active || a.mode == 2) {
                                val ph = v[4] * (t * 2 * PI) + i * v[5] * 2
                                dx += v[0] * px * sin(ph)
                                dy += v[1] * px * cos(ph * 1.3f)
                                rot += v[2] * PI / 180 * sin(ph * 0.9f)
                                scale *= 1 + v[3] * sin(ph * 1.1f)
                            }
                            2 -> {
                                val rx = v[0] * kk * PI / 180; val ry = v[1] * kk * PI / 180
                                sx *= cos(ry); sy *= cos(rx)
                                persp += v[2] * (abs(sin(ry)) + abs(sin(rx))) * (if (sin(ry) >= 0) 1 else -1)
                            }
                            3 -> track += v[0] * kk * px
                            4 -> { skx += tan(v[0] * kk * PI / 180); sky += tan(v[1] * kk * PI / 180) }
                        }
                    }
                    continue
                }
                when (a.type) {
                    0 -> dy += (1 - e) * a.distance * px                                       // slide up in
                    1 -> dy -= (1 - e) * a.distance * px                                       // slide down in
                    2 -> alpha *= if (a.fade) e else (if (p >= 1) 1f else 0.15f + 0.85f * e)   // fade in
                    3 -> scale *= a.scaleFrom + (1 - a.scaleFrom) * e                          // scale in
                    4 -> alpha *= if (p >= 1) 1f else (if (e > 0.5f) 1f else 0f)               // typewriter
                    5 -> scale *= a.scaleFrom + (1 - a.scaleFrom) * Track.bounceOut(p)         // pop
                    6 -> rot += (1 - e) * a.rotFrom * PI / 180                                 // rotate in
                    7 -> dy -= e * a.distance * px                                             // slide up out
                    8 -> alpha *= 1 - e                                                        // fade out
                    9 -> dy += e * a.distance * px                                             // slide down out
                    10 -> scale *= a.scaleFrom + (1 - a.scaleFrom) * Track.bounceOut(p)
                    11 -> alpha *= e                                                           // outline draw
                }
            }

            val cx = x + gw / 2
            val cy = originY + glyphH / 2
            c.save()
            c.translate(cx + dx, cy + dy)
            c.rotate(rot * 180f / PI)
            c.scale(scale, scale)
            if (skx != 0f || sky != 0f || sx != 1f || sy != 1f || persp != 0f) {
                // 3D flip / skew approximated as an affine (cos-squash + perspective shear): CGAffineTransform(a,b,c,d)
                val ta = if (sx == 0f) 0.0001f else sx; val tbb = sky + persp * 0.35f * sx
                val tc = skx + persp * 0.0f; val td = if (sy == 0f) 0.0001f else sy
                val m = Matrix(); m.setValues(floatArrayOf(ta, tc, 0f, tbb, td, 0f, 0f, 0f, 1f))
                c.concat(m)
            }
            val gAlpha = clamp(alpha, 0f, 1f)
            val gp2 = Paint(gp); gp2.alpha = (gp.alpha * gAlpha + 0.5f).toInt()
            if (ch != "\n") c.drawText(ch, -gw / 2, -glyphH / 2 + asc, gp2)
            c.restore()

            x += gw + s.kern + track
        }
    }

    // MARK: - cache

    private val cache = HashMap<String, Bitmap>()
    private val cacheOrder = ArrayList<String>()

    /** Caller holds the cache lock. Evicts oldest entries. */
    private fun trimCache() {
        while (cacheOrder.size > 40) { val k = cacheOrder.removeAt(0); cache.remove(k) }
    }

    /** Called when a project closes. */
    fun clearCache() = synchronized(cache) { cache.clear(); cacheOrder.clear() }
}
