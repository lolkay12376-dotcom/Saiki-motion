package com.saiki.motion.core

import kotlin.math.floor
import kotlin.math.max

// Port of Sources/Effects/TwixtorTime.swift — source-time mapping for layers carrying the Twixtor effect.
class TwixSource(val a: Float, val b: Float, val frac: Float, val fps: Float, val entry: String)

/** Source frame pair (A, B) and the in-between position for the layer's own Twixtor effect, if any. */
fun Layer.twixSource(t: Float): TwixSource? {
    val e = fx.firstOrNull { !fxOff.contains(it) && Registry.get(it)?.id == "twixtor" } ?: return null
    fun pv(k: String, def: Float): Float {
        val key = e + "__" + k
        val tr = props[key]
        if (tr != null) return tr.eval(editTime(key, t))
        return def
    }
    val fps = max(1f, pv("twInFps", 24f))
    val s = if (pv("twMode", 0f) < 0.5f) max(0f, (t - start) * pv("twSpeed", 100f) / 100f + srcOffset)
            else max(0f, pv("twFrame", 0f) / fps + srcOffset)
    val f = s * fps
    val fl = floor(f + 1e-4f)
    return TwixSource(fl / fps, (fl + 1) / fps, max(0f, f - fl), fps, e)
}
