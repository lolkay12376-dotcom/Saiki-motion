package com.saiki.motion.core

// Port of Sources/Effects/BuiltinsUniverse2.swift (UniversePreset struct + UniversePresets.glow/.zoom/.prism)
// + Sources/Effects/BuiltinsUniverse3.swift (extension: gofi/ecto/carousel + words/thumbRes)
// + Sources/Effects/BuiltinsUniverse4.swift (extension: edge/hud presets).
// The dashboard-preset data only; the EffectDefs themselves live in the fx registry ports.

/** BuiltinsUniverse2.swift:6-12. cols/tint are 0xAARRGGBB (iOS UInt32 -> Kotlin Long). */
class UniversePreset(
    val name: String,
    val vals: Map<String, Float> = emptyMap(),
    val cols: Map<String, Long> = emptyMap(),
    val tint: Long? = null,     // dashboard thumbnail tint
    val bloom: Float = 0.6f     // dashboard thumbnail bloom
)

object UniversePresets {
    // BuiltinsUniverse2.swift:274-278
    fun list(id: String): List<UniversePreset> = when (id) {
        "uglow" -> glow
        "upointzoom" -> zoom
        "ugofi" -> gofi
        "uecto" -> ecto
        "ucarousel" -> carousel
        "uedge" -> edge
        "uhud" -> hud
        else -> prism
    }

    val title: Map<String, String> = mapOf(
        "uglow" to "GLOW", "uprism" to "PRISM DISPLACEMENT", "upointzoom" to "POINT ZOOM", "ugofi" to "GLO FI II",
        "uecto" to "ECTO", "ucarousel" to "CAROUSEL", "uedge" to "EDGE GLOW", "uhud" to "HUD COMPONENTS")

    // BuiltinsUniverse2.swift:280-292
    val glow: List<UniversePreset> = listOf(
        UniversePreset("Blue Tint", mapOf("ugCS" to 75f, "ugInt" to 1.5f), mapOf("ugC1" to 0xFF2B6BFFL, "ugC2" to 0xFFA8D4FFL), 0xFF0A2A66L, 0.9f),
        UniversePreset("Green Tint", mapOf("ugCS" to 75f, "ugInt" to 1.5f), mapOf("ugC1" to 0xFF18C45AL, "ugC2" to 0xFFC8FFD8L), 0xFF0A4A22L, 0.9f),
        UniversePreset("Hard Light Prism", mapOf("ugThr" to 70f, "ugFall" to 3f, "ugGam" to 1.3f, "ugInt" to 1.6f, "ugAbX" to 18f, "ugAbR" to 1.5f, "ugAbB" to -1.5f, "ugAbFall" to 0f), bloom = 1.0f),
        UniversePreset("Highlights", mapOf("ugThr" to 80f, "ugThrS" to 10f, "ugSize" to 20f, "ugInt" to 2f), bloom = 0.5f),
        UniversePreset("Horizontal Spectrum", mapOf("ugW" to 60f, "ugSize" to 40f, "ugInt" to 1.5f, "ugAbX" to 30f, "ugAbFall" to 2f, "ugAbSat" to 140f), bloom = 0.8f),
        UniversePreset("Optical Noise", mapOf("ugNoise" to 60f, "ugSize" to 35f, "ugInt" to 1.2f), bloom = 0.7f),
        UniversePreset("Rainbow Gleam", mapOf("ugSize" to 45f, "ugInt" to 1.5f, "ugAbX" to 15f, "ugAbY" to 15f, "ugPass" to 6f, "ugAbSat" to 160f), bloom = 1.0f),
        UniversePreset("Red Tint", mapOf("ugCS" to 75f, "ugInt" to 1.5f), mapOf("ugC1" to 0xFFFF2B3AL, "ugC2" to 0xFFFFC0B0L), 0xFF5A0A12L, 0.9f),
        UniversePreset("Soft Glow", mapOf("ugSize" to 60f, "ugFall" to 1f, "ugInt" to 0.8f, "ugThr" to 40f, "ugThrS" to 60f), bloom = 1.2f),
        UniversePreset("Subtle Aberration", mapOf("ugSize" to 25f, "ugInt" to 1f, "ugAbX" to 6f, "ugAbY" to 3f), bloom = 0.6f),
        UniversePreset("Vertical Spectrum", mapOf("ugH" to 60f, "ugSize" to 40f, "ugInt" to 1.5f, "ugAbX" to 0f, "ugAbY" to 30f, "ugAbFall" to 2f, "ugAbSat" to 140f), bloom = 0.8f),
    )

    // BuiltinsUniverse2.swift:293-298
    val zoom: List<UniversePreset> = listOf(
        UniversePreset("Hologram Beam", mapOf("pzLen" to 100f, "pzGain" to 1.5f, "pzBlend" to 0f), bloom = 0.8f),
        UniversePreset("Long Projection", mapOf("pzLen" to 300f, "pzGain" to 1.8f, "pzBlend" to 40f), bloom = 1.0f),
        UniversePreset("Light Source Glow", mapOf("pzLen" to 150f, "pzGain" to 1.2f, "pzBlend" to 75f, "pzMode" to 2f), bloom = 0.6f),
        UniversePreset("Soft Reveal", mapOf("pzLen" to 60f, "pzGain" to 1f, "pzBlend" to 100f), bloom = 0.4f),
    )

    // BuiltinsUniverse2.swift:299-308
    val prism: List<UniversePreset> = listOf(
        UniversePreset("Default", bloom = 0f),
        UniversePreset("Minor Refraction", mapOf("upGlass" to 0.5f), bloom = 0f),
        UniversePreset("Major Refraction", mapOf("upGlass" to 3f, "upIdx" to 1.5f), bloom = 0f),
        UniversePreset("Reverse Color", mapOf("upRR" to 1.1f, "upRG" to 1f, "upRB" to 0.9f), bloom = 0f),
        UniversePreset("Oil Slick", mapOf("upGlass" to 2f, "upSoft" to 8f, "upRR" to 0.7f, "upRB" to 1.4f, "upLInt" to 0.6f, "upGam" to 1.4f), bloom = 0f),
        UniversePreset("Opalescent", mapOf("upGlass" to 1.5f, "upSoft" to 12f, "upRR" to 0.8f, "upRG" to 1f, "upRB" to 1.25f, "upLInt" to 0.4f), bloom = 0f),
        UniversePreset("Heavy Glass", mapOf("upGlass" to 6f, "upIdx" to 2f, "upSoft" to 4f, "upLInt" to 0.8f), bloom = 0f),
        UniversePreset("Soft Prism", mapOf("upGlass" to 1f, "upSoft" to 20f, "upRR" to 0.85f, "upRB" to 1.15f), bloom = 0f),
    )

    // BuiltinsUniverse3.swift:6-14 (name, highlights, midtones, shadows)
    private data class GofiScheme(val name: String, val hi: Long, val mid: Long, val sh: Long)
    private val gofiSchemes: List<GofiScheme> = listOf(
        GofiScheme("Chlorophyll", 0xFFB8FFB0L, 0xFF3FCB4AL, 0xFF0B5A1EL), GofiScheme("Nostalgic", 0xFFFFE066L, 0xFFFF6FA8L, 0xFF5B2A9AL),
        GofiScheme("Ice", 0xFFE8FBFFL, 0xFF6CC8FFL, 0xFF1A4FA8L), GofiScheme("Warm", 0xFFFFF0B0L, 0xFFFF9A3AL, 0xFFB01E1EL),
        GofiScheme("Ember", 0xFFFFD27AL, 0xFFFF5A1FL, 0xFF4A0E0EL), GofiScheme("Ocean", 0xFFB8F3FFL, 0xFF1FA7C9L, 0xFF0A2E6BL),
        GofiScheme("Sunset", 0xFFFFE0A0L, 0xFFFF5E8AL, 0xFF5A1E8CL), GofiScheme("Neon", 0xFFFFFFFFL, 0xFFFF2BD6L, 0xFF2B2BFFL),
        GofiScheme("Mono", 0xFFFFFFFFL, 0xFFA0A0A0L, 0xFF303030L), GofiScheme("Royal", 0xFFE6D0FFL, 0xFF8A4BFFL, 0xFF2A0F66L),
        GofiScheme("Toxic", 0xFFF4FF8AL, 0xFF9AE600L, 0xFF2A5A00L), GofiScheme("Candy", 0xFFFFD6F0L, 0xFFFF8AD0L, 0xFF7A5CFFL))

    // BuiltinsUniverse3.swift:15-19 (name, inner, outer)
    private data class EctoColor(val name: String, val cIn: Long, val cOut: Long)
    private val ectoColors: List<EctoColor> = listOf(
        EctoColor("Aqualight", 0xFFE8FFFFL, 0xFF3FD0E0L), EctoColor("Chroma", 0xFFA0FF70L, 0xFF00B000L), EctoColor("Cool", 0xFFD8E0FFL, 0xFF3050FFL),
        EctoColor("Phantom", 0xFFFFFFFFL, 0xFFB0B0B0L), EctoColor("Proton Beam", 0xFFFFA0FFL, 0xFFE020D0L), EctoColor("Slimer", 0xFFC0FFC0L, 0xFF20B040L),
        EctoColor("The Twinkle", 0xFFFFE070L, 0xFFFF7A00L), EctoColor("Warm", 0xFFFF8070L, 0xFFE01010L))

    // BuiltinsUniverse3.swift:20-30 (name, inner, outer, pattern)
    private data class EctoLook(val name: String, val cIn: Long, val cOut: Long, val pat: Float)
    private val ectoLooks: List<EctoLook> = listOf(
        EctoLook("A Ghost", 0xFFFFFFFFL, 0xFF6A6AFFL, 0f), EctoLook("Baja Blast", 0xFFA0FF90L, 0xFF00D020L, 2f),
        EctoLook("Castle Byers", 0xFFFF9080L, 0xFFFF1010L, 1f), EctoLook("Dry Ice", 0xFFE0FFFFL, 0xFF30B0FFL, 0f),
        EctoLook("Film Glow", 0xFFE0E8FFL, 0xFF4060FFL, 0f), EctoLook("Flame Outlines", 0xFFFFE060L, 0xFFFF3000L, 3f),
        EctoLook("Flames", 0xFFFFC060L, 0xFFFF2000L, 3f), EctoLook("Ghost Wind", 0xFFE0D0FFL, 0xFF6030FFL, 0f),
        EctoLook("Golden State", 0xFFFFE9A0L, 0xFFFFA000L, 1f), EctoLook("Green Laser", 0xFFA0FFA0L, 0xFF00E040L, 2f),
        EctoLook("Heat Haze", 0xFFFFE0A0L, 0xFFFF4000L, 3f), EctoLook("Hot Neon", 0xFFFFC8E8L, 0xFFFF2080L, 2f),
        EctoLook("Infection", 0xFFFFE080L, 0xFFFF6000L, 1f), EctoLook("Ladyhawke", 0xFFFFA090L, 0xFFD01010L, 1f),
        EctoLook("Laser Whip", 0xFFFFB090L, 0xFFFF3010L, 2f), EctoLook("Lightning", 0xFFE8E8FFL, 0xFF3030FFL, 2f),
        EctoLook("Limelight", 0xFFE0FFF8L, 0xFF30D0C0L, 0f), EctoLook("Neon Glow", 0xFFFFA0F0L, 0xFFD020D0L, 2f),
        EctoLook("Optical Glow", 0xFFFFFFFFL, 0xFF7080FFL, 0f), EctoLook("Outline", 0xFFC8D8FFL, 0xFF2060FFL, 2f),
        EctoLook("Outrun", 0xFFFFA0E0L, 0xFFFF10A0L, 2f), EctoLook("Poltergeist", 0xFFFFFFFFL, 0xFF4A5AFFL, 1f),
        EctoLook("Smokey", 0xFFFFFFFFL, 0xFF6060E0L, 1f), EctoLook("Space Coast", 0xFFFFFFFFL, 0xFF30C8FFL, 0f),
        EctoLook("The Deep", 0xFFA0FFE8L, 0xFF00B090L, 0f), EctoLook("The Librarian", 0xFFE0A0FFL, 0xFF8020FFL, 1f))

    // BuiltinsUniverse3.swift:312-321
    val gofi: List<UniversePreset> by lazy {
        val l = ArrayList<UniversePreset>()
        for ((d, tag) in listOf(Pair(0, ""), Pair(1, "H "), Pair(2, "V "))) {
            for (s in gofiSchemes) {
                l.add(UniversePreset(tag + s.name,
                    mapOf("gfDir" to d.toFloat(), "gfMap" to 0f),
                    mapOf("gfHi" to s.hi, "gfMd" to s.mid, "gfSh" to s.sh),
                    s.mid, 1.3f))
            }
        }
        l
    }

    // BuiltinsUniverse3.swift:322-333
    val ecto: List<UniversePreset> by lazy {
        val l = ArrayList<UniversePreset>()
        for (c in ectoColors) {
            l.add(UniversePreset(c.name, emptyMap(), mapOf("ecIn" to c.cIn, "ecOut" to c.cOut), c.cOut, 1.2f))
        }
        for (k in ectoLooks) {
            val wild = if (k.pat == 0f) 20f else (if (k.pat == 2f) 30f else 65f)
            l.add(UniversePreset(k.name,
                mapOf("ecPat" to k.pat, "ecDist" to wild, "ecFlow" to if (k.pat == 3f) 40f else 24f),
                mapOf("ecIn" to k.cIn, "ecOut" to k.cOut), k.cOut, 1.2f))
        }
        l
    }

    // BuiltinsUniverse3.swift:334-345
    val carousel: List<UniversePreset> = listOf(
        UniversePreset("Acid Stardust", mapOf("caFr" to 1f, "caProc" to 80f, "caR" to 70f, "caG" to 60f, "caB" to 40f, "caFade" to 45f, "caLS" to 5f, "caOp" to 70f), mapOf("caLC" to 0xFFFFD890L), 0xFF301808L, 0f),
        UniversePreset("Electric Vision", mapOf("caFr" to 2f, "caProc" to 70f, "caR" to 40f, "caG" to 50f, "caB" to 90f, "caVig" to 55f, "caLS" to 1f, "caOp" to 75f), mapOf("caLC" to 0xFFFF70A0L), 0xFF180830L, 0f),
        UniversePreset("Enchanted Light", mapOf("caFr" to 2f, "caProc" to 45f, "caFade" to 40f, "caLS" to 1f, "caOp" to 85f), mapOf("caLC" to 0xFFFFB060L), 0xFF302008L, 0f),
        UniversePreset("Mars Eyes", mapOf("caFr" to 2f, "caProc" to 60f, "caR" to 90f, "caG" to 30f, "caB" to 30f, "caLS" to 1f, "caOp" to 70f), mapOf("caLC" to 0xFFFF6040L), 0xFF301008L, 0f),
        UniversePreset("Pink Dahlias", mapOf("caFr" to 4f, "caProc" to 55f, "caR" to 80f, "caG" to 30f, "caB" to 70f, "caFade" to 35f, "caLS" to 1f, "caOp" to 70f), mapOf("caLC" to 0xFFFF90B0L), 0xFF301020L, 0f),
        UniversePreset("Rose Clouds", mapOf("caFr" to 3f, "caProc" to 40f, "caR" to 70f, "caG" to 40f, "caB" to 60f, "caFade" to 55f, "caLS" to 5f, "caOp" to 55f), mapOf("caLC" to 0xFFFFB0C0L), 0xFF281018L, 0f),
        UniversePreset("Strawberry Lemonade", mapOf("caFr" to 2f, "caProc" to 50f, "caR" to 80f, "caG" to 60f, "caB" to 30f, "caLS" to 1f, "caOp" to 80f), mapOf("caLC" to 0xFFFFD060L), 0xFF301808L, 0f),
        UniversePreset("Summer Goth", mapOf("caFr" to 1f, "caProc" to 75f, "caR" to 50f, "caG" to 30f, "caB" to 90f, "caVig" to 60f, "caFade" to 40f, "caLS" to 5f, "caOp" to 55f), mapOf("caLC" to 0xFFB090FFL), 0xFF201038L, 0f),
        UniversePreset("Tiger Dream", mapOf("caFr" to 2f, "caProc" to 55f, "caR" to 80f, "caG" to 60f, "caB" to 20f, "caFade" to 35f, "caLS" to 1f, "caOp" to 85f), mapOf("caLC" to 0xFFFFA030L), 0xFF302008L, 0f),
        UniversePreset("Waves of Azul", mapOf("caFr" to 2f, "caProc" to 65f, "caR" to 20f, "caG" to 60f, "caB" to 90f, "caVig" to 50f, "caLS" to 2f, "caOp" to 60f), mapOf("caLC" to 0xFF50B0FFL), 0xFF082030L, 0f),
    )

    // BuiltinsUniverse3.swift:346-347
    val words: Map<String, String> = mapOf("uecto" to "Ecto", "ugofi" to "Glo Fi")
    val thumbRes: Map<String, String> = mapOf("ucarousel" to "fx_woman", "uedge" to "fx_girl", "uglow" to "fx_girl")

    // BuiltinsUniverse4.swift:301-310
    val edge: List<UniversePreset> = listOf(
        UniversePreset("Aura", mapOf("egCol" to 1f, "egEdge" to 300f, "egBr" to 150f, "egRad" to 70f), mapOf("egTint" to 0xFFB070FFL), 0xFF301050L, 0.9f),
        UniversePreset("Cool", mapOf("egCol" to 1f, "egEdge" to 300f, "egBr" to 150f), mapOf("egTint" to 0xFF3A8CFFL), 0xFF0A2A66L, 0.9f),
        UniversePreset("Default", bloom = 0.3f),
        UniversePreset("Huelogram", mapOf("egCol" to 1f, "egEdge" to 350f, "egBr" to 130f, "egSat" to 160f), mapOf("egTint" to 0xFF40E0E0L), 0xFF083838L, 0.9f),
        UniversePreset("Intense", mapOf("egEdge" to 500f, "egBr" to 300f, "egRad" to 40f), tint = 0xFF202020L, bloom = 1.0f),
        UniversePreset("Soft", mapOf("egEdge" to 150f, "egBr" to 80f, "egRad" to 120f, "egSat" to 0f), tint = 0xFF181818L, bloom = 0.5f),
        UniversePreset("Sparkle", mapOf("egCol" to 1f, "egEdge" to 400f, "egBr" to 250f, "egRad" to 30f), mapOf("egTint" to 0xFFFF40A0L), 0xFF501030L, 1.1f),
        UniversePreset("Warm", mapOf("egCol" to 1f, "egEdge" to 300f, "egBr" to 150f), mapOf("egTint" to 0xFFFF9030L), 0xFF402008L, 0.9f),
    )

    // BuiltinsUniverse4.swift:311-322
    val hud: List<UniversePreset> = listOf(
        UniversePreset("Targeting 1", mapOf("h1Type" to 5f, "h1Anim" to 5f, "h1Rad" to 150f, "h2Type" to 6f, "h2Rad" to 100f), mapOf("h1C" to 0xFF30D0FFL, "h2C" to 0xFF30D0FFL), 0xFF083040L, 0.9f),
        UniversePreset("Slinky Rings", mapOf("h1Type" to 1f, "h1Seg" to 340f, "h1Anim" to 4f, "h1Cn" to 34f, "h1CS" to -3f, "h1CR" to 5f, "h1CF" to 5f), mapOf("h1C" to 0xFF4AB0FFL), 0xFF0A2A66L, 1.0f),
        UniversePreset("Wide Chevrons", mapOf("h1Type" to 3f, "h1Rad" to 200f, "h1Cn" to 2f, "h1CY" to 60f, "h1CS" to 0f, "h1CF" to 4f, "h1Anim" to 2f, "h1Amp" to 2f), mapOf("h1C" to 0xFF40D0FFL), 0xFF083040L, 0.8f),
        UniversePreset("Radar", mapOf("h1Type" to 8f, "h1Rad" to 260f, "h1Anim" to 4f, "h1Spd" to 0.5f, "h2Type" to 1f, "h2Rad" to 220f, "h2Seg" to 300f, "h2Anim" to 4f), mapOf("h1C" to 0xFF40FF90L, "h2C" to 0xFF40FF90L), 0xFF083018L, 0.9f),
        UniversePreset("HUD Clock", mapOf("h1Type" to 1f, "h1Rad" to 260f, "h1Seg" to 270f, "h2Type" to 8f, "h2Rad" to 240f, "h3Type" to 1f, "h3Rad" to 180f, "h3Seg" to 90f, "h3Anim" to 4f), mapOf("h1C" to 0xFFFFC040L, "h2C" to 0xFF40D0FFL, "h3C" to 0xFF40D0FFL), 0xFF302008L, 0.9f),
        UniversePreset("Widget Spin", mapOf("h1Type" to 2f, "h1Anim" to 4f, "h1Rad" to 160f, "h2Type" to 7f, "h2Rad" to 120f, "h3Type" to 6f, "h3Rad" to 200f), mapOf("h1C" to 0xFF70FFE0L, "h2C" to 0xFF70FFE0L, "h3C" to 0xFF70FFE0L), 0xFF083830L, 0.9f),
        UniversePreset("Hex Grid", mapOf("h1Type" to 7f, "h1Cn" to 6f, "h1CX" to 70f, "h1CY" to 40f, "h1CS" to 0f, "h1Rad" to 50f, "h1CF" to 2f), mapOf("h1C" to 0xFF50FF90L), 0xFF083018L, 0.8f),
        UniversePreset("Dot Grid", mapOf("h1Type" to 9f, "h1Rad" to 220f, "h1SW" to 3f, "h1Anim" to 1f, "h1Amp" to 1f), mapOf("h1C" to 0xFF50FF90L), 0xFF083018L, 0.7f),
        UniversePreset("Pointer Stack", mapOf("h1Type" to 10f, "h1Rad" to 200f, "h1Cn" to 4f, "h1CY" to 50f, "h1CF" to 4f, "h1CS" to 0f, "h1Anim" to 2f), mapOf("h1C" to 0xFFFF9040L), 0xFF402008L, 0.9f),
        UniversePreset("Triangle Orbit", mapOf("h1Type" to 4f, "h1Anim" to 3f, "h1Orb" to 30f, "h1Cn" to 8f, "h1CR" to 10f, "h1CF" to 3f, "h1Rad" to 120f), mapOf("h1C" to 0xFFFF40C0L), 0xFF401030L, 1.0f),
    )
}
