package com.saiki.motion.core

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import java.io.File
import kotlin.math.abs
import kotlin.math.floor

// Port of the pieces of Sources/Core/Util.swift the model layer needs (clamp, ktRandom, noise1, Paths).

fun <T : Comparable<T>> clamp(v: T, lo: T, hi: T): T { if (v < lo) return lo; if (v > hi) return hi; return v }

/** Swift Float.rounded() = half away from zero (kotlin.math.round is half-even). */
fun roundAway(x: Float): Float { val a = abs(x); var f = floor(a); if (a - f >= 0.5f) f += 1f; return if (x < 0) -f else f }

/** java.util.Random-style LCG: UInt64 wrapping multiply/add (Swift &* &+). */
fun ktRandom(seed: LongArray): ULong {
    val s = seed[0].toULong() * 6364136223846793005UL + 1442695040888963407UL
    seed[0] = s.toLong(); return s
}

/** Deterministic 1-D value noise used by expressions. */
fun noise1(x: Float): Float {
    val i = floor(x); val f = x - i; val u = f * f * (3 - 2 * f)
    fun h(n: Float): Float {
        var s = n.toRawBits().toUInt()
        s = s * 747796405u + 2891336453u
        s = ((s shr ((s shr 28).toInt() + 4)) xor s) * 277803737u
        s = (s shr 22) xor s
        return (s % 1000u).toFloat() / 1000f
    }
    return h(i) * (1 - u) + h(i + 1) * u
}

/** iOS Paths: root = <Documents>/SaikiMotion -> <filesDir>/SaikiMotion. Call Paths.init(context) from Application/Activity first. */
object Paths {
    lateinit var appContext: Context
    fun init(c: Context) { appContext = c.applicationContext }
    val root: File get() = File(appContext.filesDir, "SaikiMotion")
    val cache: File get() = File(appContext.cacheDir, "SaikiMotion")
    fun ensure() { cache.mkdirs(); root.mkdirs() }
    /** URL.lastPathComponent equivalent for a picked Uri. */
    fun displayName(u: Uri): String {
        if (u.scheme == "content") try {
            appContext.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) return it.getString(0) }
        } catch (_: Exception) {}
        return u.lastPathSegment?.substringAfterLast('/') ?: "file"
    }
}

/** Store.swift notifications (posted on the main thread). */
object StoreNotification {
    enum class Name { projectsChanged, languageChanged }
    private val listeners = java.util.concurrent.CopyOnWriteArrayList<Pair<Name, () -> Unit>>()
    fun observe(n: Name, f: () -> Unit) { listeners.add(n to f) }
    fun post(n: Name) { Handler(Looper.getMainLooper()).post { for ((k, f) in listeners) if (k == n) f() } }
}

// Util.swift colour helpers (ARGB Int like iOS Int32).
fun colorAlpha(c: Int): Int = (c ushr 24) and 0xFF
fun colorRed(c: Int): Int = (c ushr 16) and 0xFF
fun colorGreen(c: Int): Int = (c ushr 8) and 0xFF
fun colorBlue(c: Int): Int = c and 0xFF
fun argbColor(a: Int, r: Int, g: Int, b: Int): Int = (maxOf(a, 0) shl 24) or (maxOf(r, 0) shl 16) or (maxOf(g, 0) shl 8) or maxOf(b, 0)   // UInt32(clamping:) only clamps negatives

/** Util.swift:46 */
fun nowMs(): Long = System.currentTimeMillis()
