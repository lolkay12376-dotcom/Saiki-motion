package com.saiki.motion.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path

// Port of Sources/Model/VPath.swift (model + VPathRaster via android.graphics.Canvas).
class VPt(var x: Float, var y: Float, var ix: Float = 0f, var iy: Float = 0f, var ox: Float = 0f, var oy: Float = 0f) {
    val curved: Boolean get() = ix != 0f || iy != 0f || ox != 0f || oy != 0f
    fun copy() = VPt(x, y, ix, iy, ox, oy)
}

class VPath {
    var pts = mutableListOf<VPt>()
    var closed = false
    val hashKey: Int get() { var h = if (closed) 1 else 0; for (p in pts) { h = h * 31 + p.x.hashCode(); h = h * 31 + p.y.hashCode(); h = h * 31 + p.ix.hashCode(); h = h * 31 + p.iy.hashCode(); h = h * 31 + p.ox.hashCode(); h = h * 31 + p.oy.hashCode() }; return h }

    /** Segment i -> i+1 (wraps when closed) as 4 control points in the given mapping (x0,y0,x1,y1,x2,y2,x3,y3), or null. */
    fun segment(i: Int, m: (Float, Float) -> Pair<Float, Float>): FloatArray? {
        val n = pts.size
        if (!(n > 1 && i < (if (closed) n else n - 1))) return null
        val a = pts[i]; val b = pts[(i + 1) % n]
        val p0 = m(a.x, a.y); val p1 = m(a.x + a.ox, a.y + a.oy); val p2 = m(b.x + b.ix, b.y + b.iy); val p3 = m(b.x, b.y)
        return floatArrayOf(p0.first, p0.second, p1.first, p1.second, p2.first, p2.second, p3.first, p3.second)
    }

    fun bezier(m: (Float, Float) -> Pair<Float, Float>): Path {
        val p = Path()
        val f = pts.firstOrNull() ?: return p
        val s0 = m(f.x, f.y); p.moveTo(s0.first, s0.second)
        for (i in 0 until (if (closed) pts.size else pts.size - 1)) {
            val s = segment(i, m) ?: break
            p.cubicTo(s[2], s[3], s[4], s[5], s[6], s[7])
        }
        if (closed) p.close()
        return p
    }

    /** Splits segment i at t (de Casteljau) and inserts the new point; the curve shape is unchanged. */
    fun split(i: Int, t: Float) {
        val n = pts.size; val j = (i + 1) % n
        val a = pts[i]; val b = pts[j]
        fun l(p: Float, q: Float) = p + (q - p) * t
        val p0x = a.x; val p0y = a.y; val p1x = a.x + a.ox; val p1y = a.y + a.oy
        val p2x = b.x + b.ix; val p2y = b.y + b.iy; val p3x = b.x; val p3y = b.y
        val q0x = l(p0x, p1x); val q0y = l(p0y, p1y); val q1x = l(p1x, p2x); val q1y = l(p1y, p2y); val q2x = l(p2x, p3x); val q2y = l(p2y, p3y)
        val r0x = l(q0x, q1x); val r0y = l(q0y, q1y); val r1x = l(q1x, q2x); val r1y = l(q1y, q2y)
        val sx = l(r0x, r1x); val sy = l(r0y, r1y)
        pts[i].ox = q0x - a.x; pts[i].oy = q0y - a.y
        pts[j].ix = q2x - b.x; pts[j].iy = q2y - b.y
        pts.add(i + 1, VPt(sx, sy, r0x - sx, r0y - sy, r1x - sx, r1y - sy))
    }
}

object VPathRaster {
    /** Closed paths are filled, open paths stroked. Square RGBA bitmap; path -1...1 maps to the full square. */
    fun image(vp: VPath, color: Int, side: Float = 512f): Bitmap {
        val n = maxOf(1, side.toInt())
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val path = vp.bezier { x, y -> Pair((x * 0.5f + 0.5f) * side, (y * 0.5f + 0.5f) * side) }
        val pt = Paint(Paint.ANTI_ALIAS_FLAG); pt.color = color
        if (vp.closed) { pt.style = Paint.Style.FILL; path.fillType = Path.FillType.WINDING; c.drawPath(path, pt) }
        else { pt.style = Paint.Style.STROKE; pt.strokeWidth = side * 0.03f; pt.strokeCap = Paint.Cap.ROUND; pt.strokeJoin = Paint.Join.ROUND; c.drawPath(path, pt) }
        return bmp
    }
}
