package com.saiki.motion.core

import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.util.zip.Inflater
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Port of Sources/Render/VdbVolume.swift (VdbVolume + CloudGen). OpenVDB FloatGrid reader (Blosc via JNI NativeBlosc, zlib via java.util.zip).
 * Intentionally NOT ported: the private, never-called parseGrid/bloscDecode/bloscDecodeSplit (VdbVolume.swift:156-300, dead code on iOS).
 * Compression.framework (compression_decode_buffer) -> java.util.zip.Inflater(nowrap): parity kept — the Java side grows its
 * output buffer dynamically where iOS retries at 4x, and truncated streams return empty on both (compression_decode_buffer 0 / Inflater throws -> caught -> empty).
 */
class VdbVolume {

    class Grid {
        var name: String = ""
        var voxelSize: Float = 1f
        var nx = 0; var ny = 0; var nz = 0
        var origin = intArrayOf(0, 0, 0)
        var data: FloatArray = FloatArray(0)       // x + nx * (y + ny * z)
    }

    var grids: List<Grid> = emptyList()
    var bounds: Triple<Float, Float, Float> = Triple(1f, 1f, 1f)   // normalized extents

    // MARK: - ZIP + VDB parsing

    // Real OpenVDB reader (file format >= 222, FloatGrid 5-4-3, Blosc / zlib / none, float or half).
    // Leaves are splatted into a 128³ lattice (axes swapped to our y-up world).
    private fun parse(b: ByteArray): Boolean {
        return try { parseImpl(b) } catch (e: IndexOutOfBoundsException) { false } catch (e: NegativeArraySizeException) { false }
    }

    private fun parseImpl(b: ByteArray): Boolean {
        var p = 0
        fun u8(): Int { val v = if (p < b.size) (b[p].toInt() and 255) else 0; p += 1; return v }
        fun rd32(): Int { val v = if (p + 4 <= b.size) u32(b, p) else 0L; p += 4; return if (v > Int.MAX_VALUE) Int.MAX_VALUE else v.toInt() }   // Swift Int(UInt32)
        fun rd32raw(): Int { val v = if (p + 4 <= b.size) u32(b, p).toInt() else 0; p += 4; return v }                                              // Int32(truncatingIfNeeded:)
        fun rd64(): Long { val v = if (p + 8 <= b.size) u64(b, p) else 0L; p += 8; return v }
        fun str(): String {
            val n = rd32()
            if (n < 0 || p.toLong() + n > b.size) { p = b.size; return "" }
            val s = strictUtf8(b, p, n) ?: ""
            p += n
            return s
        }
        fun meta() { val n = rd32(); for (i in 0 until n) { str(); str(); val sz = rd32(); p += max(0, sz) } }
        if (!(b.size > 64 && u32(b, 0) == 0x56444220L)) return false
        p = 8
        val ver = rd32(); if (ver < 222) return false
        p += 8; p += 1                       // library major/minor, hasGridOffsets
        p += 36                              // uuid
        meta()
        val gridCount = rd32()
        if (!(gridCount > 0 && gridCount < 64)) return false
        for (gi in 0 until gridCount) {
            str(); val type = str(); str()
            val gridPos = rd64(); rd64(); val endPos = rd64()
            if (!(gridPos > 0 && gridPos < b.size)) return false
            if (!type.startsWith("Tree_float")) { p = endPos.coerceIn(Int.MIN_VALUE.toLong(), Int.MAX_VALUE.toLong()).toInt(); continue }
            val half = type.endsWith("HalfFloat")
            p = gridPos.toInt()
            val comp = rd32()
            meta()
            val map = str()
            when (map) {
                "TranslationMap" -> p += 24
                "ScaleMap", "UniformScaleMap" -> p += 120
                "ScaleTranslateMap", "UniformScaleTranslateMap" -> p += 144
                else -> p += 128
            }
            if (rd32() != 1) return false       // buffer count
            p += 4                              // background
            val nTiles = rd32(); val nKids = rd32()
            p += nTiles * 17
            class Leaf(val o: IntArray, val mask: ByteArray)
            val leaves = ArrayList<Leaf>()
            fun mask(n: Int): ByteArray {
                val r = if (p.toLong() + n <= b.size) b.copyOfRange(p, p + n) else ByteArray(n)
                p += n; return r
            }
            fun on(m: ByteArray, i: Int): Boolean = ((m[i shr 3].toInt() and 255) shr (i and 7)) and 1 == 1
            fun values(count: Int, vmask: ByteArray?, ve: Boolean): FloatArray {
                val md = u8()
                var in0 = 0f; var in1 = 0f
                if (md == 2 || md == 4 || md == 5) { in0 = Float.fromBits(rd32raw()); if (md == 5) in1 = Float.fromBits(rd32raw()) }
                var sel = ByteArray(0)
                if (md == 3 || md == 4 || md == 5) sel = mask(count / 8)
                var n = count
                if (comp and 2 != 0 && md != 6 && vmask != null) { n = 0; for (i in 0 until count) if (on(vmask, i)) n += 1 }
                val es = if (ve) 2 else 4
                var raw = ByteArray(0)
                if (comp and 4 != 0 || comp and 1 != 0) {
                    val cb = rd64()
                    if (cb > 0 && p.toLong() + cb <= b.size) {
                        val chunk = b.copyOfRange(p, p + cb.toInt()); p += cb.toInt()
                        raw = if (comp and 4 != 0) NativeBlosc.decompress(chunk, n * es) else inflateZlib(chunk)
                    } else { val k = n * es; if (p.toLong() + k <= b.size) { raw = b.copyOfRange(p, p + k); p += k } }
                } else { val k = n * es; if (p.toLong() + k <= b.size) { raw = b.copyOfRange(p, p + k); p += k } }
                fun at(i: Int): Float {
                    if ((i + 1).toLong() * es > raw.size) return 0f
                    return if (ve) halfToFloat(u16(raw, i * 2)) else Float.fromBits(u32(raw, i * 4).toInt())
                }
                if (n == count) return FloatArray(count) { at(it) }
                val out = FloatArray(count); var k = 0
                for (i in 0 until count) {
                    if (vmask != null && on(vmask, i)) { out[i] = at(k); k += 1 } else { out[i] = if (sel.isNotEmpty() && on(sel, i)) in1 else in0 }
                }
                return out
            }
            fun internalNode(log2: Int, o: IntArray) {
                val total = 1 shl (3 * log2)
                val cm = mask(total / 8); val vm = mask(total / 8)
                values(total, vm, half)
                val dim = 1 shl log2; val childLog = if (log2 == 5) 7 else 3
                for (i in 0 until total) {
                    if (!on(cm, i)) continue
                    val x = i shr (2 * log2); val y = (i shr log2) and (dim - 1); val z = i and (dim - 1)
                    val co = intArrayOf(o[0] + (x shl childLog), o[1] + (y shl childLog), o[2] + (z shl childLog))
                    if (log2 == 5) internalNode(4, co) else leaves.add(Leaf(co, mask(64)))
                }
            }
            for (k in 0 until nKids) {
                val o = intArrayOf(rd32raw(), rd32raw(), rd32raw())
                internalNode(5, o)
            }
            if (!(leaves.isNotEmpty() && leaves.size < 400000)) return false
            var mn0 = Int.MAX_VALUE; var mn1 = Int.MAX_VALUE; var mn2 = Int.MAX_VALUE
            var mx0 = Int.MIN_VALUE; var mx1 = Int.MIN_VALUE; var mx2 = Int.MIN_VALUE
            for (l in leaves) {
                mn0 = min(mn0, l.o[0]); mn1 = min(mn1, l.o[1]); mn2 = min(mn2, l.o[2])
                mx0 = max(mx0, l.o[0] + 8); mx1 = max(mx1, l.o[1] + 8); mx2 = max(mx2, l.o[2] + 8)
            }
            val ex = (mx0 - mn0).toFloat(); val ey = (mx1 - mn1).toFloat(); val ez = (mx2 - mn2).toFloat()
            val N = 128
            var lat = FloatArray(N * N * N)
            for (l in leaves) {
                p += 64                          // each leaf's buffer block starts with its value mask again
                val v = values(512, l.mask, half)
                for (i in 0 until 512) {
                    if (!(v[i] > 0 && on(l.mask, i))) continue
                    val x = l.o[0] - mn0 + (i shr 6); val y = l.o[1] - mn1 + ((i shr 3) and 7); val z = l.o[2] - mn2 + (i and 7)
                    val X = min(N - 1, (x.toFloat() / ex * N.toFloat()).toInt()); val Y = min(N - 1, (z.toFloat() / ez * N.toFloat()).toInt())
                    val Z = N - 1 - min(N - 1, (y.toFloat() / ey * N.toFloat()).toInt())
                    val k = X + N * (Y + N * Z)
                    lat[k] += v[i]      // average, not max: max filled the whole box with cloud
                }
            }
            val cell = max(1f, ex / N.toFloat() * ey / N.toFloat() * ez / N.toFloat())
            for (k in lat.indices) lat[k] /= cell
            // soften: one 1-2-1 blur per axis → smooth smoke instead of speckle
            for (axis in 0 until 3) {
                val st = if (axis == 0) 1 else (if (axis == 1) N else N * N)
                val o = lat.copyOf()
                for (z in 0 until N) for (y in 0 until N) for (x in 0 until N) {
                    val c = when (axis) { 0 -> x; 1 -> y; else -> z }
                    val k = x + N * (y + N * z)
                    val a = if (c > 0) lat[k - st] else lat[k]; val bb = if (c < N - 1) lat[k + st] else lat[k]
                    o[k] = (a + 2 * lat[k] + bb) * 0.25f
                }
                lat = o
            }
            // normalise to the 98th percentile: bright cores saturate, the outline keeps its shape
            val nzl = ArrayList<Float>()
            var kk = 0
            while (kk < lat.size) { if (lat[kk] > 0) nzl.add(lat[kk]); kk += 5 }
            nzl.sort()
            val ref = max(if (nzl.isEmpty()) 1f else nzl[min(nzl.size - 1, (nzl.size.toFloat() * 0.98f).toInt())], 1e-6f)
            for (k in lat.indices) lat[k] = min(lat[k] / ref, 1f)
            val g = Grid(); g.name = "density"; g.nx = N; g.ny = N; g.nz = N; g.data = lat
            grids = listOf(g)
            val m = max(ex, max(ey, ez))
            bounds = Triple(ex / m, ez / m, ey / m)
            return true
        }
        return false
    }

    // MARK: - sampling

    fun density(x: Int, y: Int, z: Int): Float {
        val g = grids.firstOrNull() ?: return 0f
        val ix = x.coerceIn(0, g.nx - 1)
        val iy = y.coerceIn(0, g.ny - 1)
        val iz = z.coerceIn(0, g.nz - 1)
        val idx = ix + g.nx * (iy + g.ny * iz)
        if (idx < 0 || idx >= g.data.size) return 0f
        return g.data[idx]
    }

    companion object {
        private val cache = HashMap<String, VdbVolume>()

        @JvmStatic @Synchronized fun load(path: String): VdbVolume? {
            cache[path]?.let { return it }
            val data: ByteArray = try { File(path).readBytes() } catch (e: Exception) { return null }
            val head = strictUtf8(data, 0, min(40, data.size))
            if (head != null && head.startsWith("SAIKICLOUD")) {
                val v = CloudGen.make(String(data, Charsets.UTF_8)); cache[path] = v; return v
            }
            if (head != null && head.startsWith("SAIKIMIST")) {
                val v = MistGen.make(String(data, Charsets.UTF_8)); cache[path] = v; return v
            }
            val v = VdbVolume()
            if (!v.parse(data)) return null
            cache[path] = v
            return v
        }
        @JvmStatic @Synchronized fun evict(path: String) { cache.remove(path) }

        /** Swift String(bytes:encoding:.utf8) is nil on invalid UTF-8. */
        private fun strictUtf8(b: ByteArray, off: Int, n: Int): String? = try {
            Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b, off, n)).toString()
        } catch (e: CharacterCodingException) { null }

        private fun u16(b: ByteArray, o: Int): Int = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8)
        private fun u32(b: ByteArray, o: Int): Long =
            (b[o].toLong() and 255) or ((b[o + 1].toLong() and 255) shl 8) or ((b[o + 2].toLong() and 255) shl 16) or ((b[o + 3].toLong() and 255) shl 24)
        private fun u64(b: ByteArray, o: Int): Long { var v = 0L; for (k in 0 until 8) v = v or ((b[o + k].toLong() and 255) shl (8 * k)); return v }

        private fun halfToFloat(h: Int): Float {
            // OpenEXR half → float
            val sign = (h shr 15) and 1
            val exp = (h shr 10) and 0x1F
            val mant = h and 0x3FF
            val f: Float = if (exp == 0) mant.toFloat() * 2f.pow(-24)
            else if (exp == 31) (if (mant == 0) Float.POSITIVE_INFINITY else Float.NaN)
            else (mant or 0x400).toFloat() * 2f.pow(-13) * 2f.pow((exp - 15).toFloat())
            return if (sign == 1) -f else f
        }

        /** zlib (raw deflate with 2-byte header skip like OpenVDB writes). */
        @JvmStatic fun inflateZlib(input: ByteArray): ByteArray {
            if (input.size <= 2) return ByteArray(0)
            var off = 0
            if ((input[0].toInt() and 0x0F) == 8 && (((input[0].toInt() and 255) shl 8) or (input[1].toInt() and 255)) % 31 == 0) off = 2
            return inflateRaw(input.copyOfRange(off, input.size))
        }

        @JvmStatic fun inflate(input: ByteArray): ByteArray = inflateRaw(input)

        private fun inflateRaw(src: ByteArray): ByteArray {
            if (src.isEmpty()) return ByteArray(0)
            val inf = Inflater(true)
            return try {
                inf.setInput(src)
                val out = ByteArrayOutputStream(max(64, src.size * 8))
                val buf = ByteArray(65536)
                while (!inf.finished()) {
                    val n = inf.inflate(buf)
                    if (n > 0) out.write(buf, 0, n) else if (inf.needsInput() || inf.needsDictionary()) break
                }
                out.toByteArray()
            } catch (_: Exception) { ByteArray(0) } finally { inf.end() }
        }
    }
}

// MARK: - procedural clouds ("SAIKICLOUD type seed scatter")

object CloudGen {
    @JvmField val types = listOf("Cumulus", "Stratus", "Cumulonimbus", "Wispy", "Scattered")
    private fun hash(x: Int, y: Int, z: Int, s: Int): Float {
        var h = x * 374761393 + y * 668265263 + z * 1274126177 + s * 362437
        h = (h xor (h ushr 13)) * 1274126177; h = h xor (h ushr 16)
        return (h and 0xFFFFFF).toFloat() / 0xFFFFFF.toFloat()
    }
    private fun noise(x: Float, y: Float, z: Float, s: Int): Float {
        val xi = floor(x).toInt(); val yi = floor(y).toInt(); val zi = floor(z).toInt()
        val fx = x - xi.toFloat(); val fy = y - yi.toFloat(); val fz = z - zi.toFloat()
        val u = fx * fx * (3 - 2 * fx); val v = fy * fy * (3 - 2 * fy); val w = fz * fz * (3 - 2 * fz)
        fun h(a: Int, b: Int, c: Int): Float = hash(xi + a, yi + b, zi + c, s)
        val x00 = h(0, 0, 0) + (h(1, 0, 0) - h(0, 0, 0)) * u; val x10 = h(0, 1, 0) + (h(1, 1, 0) - h(0, 1, 0)) * u
        val x01 = h(0, 0, 1) + (h(1, 0, 1) - h(0, 0, 1)) * u; val x11 = h(0, 1, 1) + (h(1, 1, 1) - h(0, 1, 1)) * u
        val y0 = x00 + (x10 - x00) * v; val y1 = x01 + (x11 - x01) * v
        return y0 + (y1 - y0) * w
    }
    private fun fbm(x: Float, y: Float, z: Float, s: Int): Float {
        var a = 0.5f; var f = 1f; var r = 0f
        for (i in 0 until 4) { r += a * noise(x * f, y * f, z * f, s); f *= 2.1f; a *= 0.5f }
        return r
    }
    private class Sphere(val x: Float, val y: Float, val z: Float, val r: Float)
    /** A bumpy mound of overlapping spheres: wide flat base, cauliflower top (like a real cumulus). */
    private fun mound(cx: Float, cz: Float, base: Float, W: Float, H: Float, n: Int, r0: Float, r1: Float, seed: Int, salt: Int): List<Sphere> {
        val out = ArrayList<Sphere>()
        for (i in 0 until n) {
            val a = hash(i, salt, 1, seed) * 6.2832f; val d = sqrt(hash(i, salt, 2, seed)) * W
            val px = cx + cos(a) * d; val pz = cz + sin(a) * d
            val k = 1 - (d / W) * (d / W)                                    // dome profile
            val py = base + H * k * (0.25f + 0.75f * hash(i, salt, 3, seed))
            val r = (r0 + (r1 - r0) * hash(i, salt, 4, seed)) * (0.6f + 0.6f * k)
            out.add(Sphere(px, py, pz, r))
        }
        return out
    }
    @JvmStatic fun make(spec: String): VdbVolume {
        val p = spec.split(' ').filter { it.isNotEmpty() }
        val type = if (p.size > 1) (p[1].toIntOrNull() ?: 0) else 0; val seed = if (p.size > 2) (p[2].toIntOrNull() ?: 1) else 1
        val scatter = (if (p.size > 3) (p[3].toIntOrNull() ?: 0) else 0) > 0 || type == 4
        var sp: List<Sphere> = emptyList()
        if (scatter) {
            val acc = ArrayList<Sphere>()
            for (c in 0 until 5) {
                val cx = 0.5f + (hash(c, 1, 9, seed) - 0.5f) * 0.62f; val cz = 0.5f + (hash(c, 2, 9, seed) - 0.5f) * 0.62f
                acc += mound(cx, cz, 0.22f, 0.12f + 0.05f * hash(c, 3, 9, seed), 0.26f, 26, 0.03f, 0.065f, seed, c + 10)
            }
            sp = acc
        } else {
            sp = when (type) {
                1 -> mound(0.5f, 0.5f, 0.4f, 0.46f, 0.14f, 80, 0.04f, 0.08f, seed, 0)
                2 -> mound(0.5f, 0.5f, 0.12f, 0.22f, 0.78f, 110, 0.05f, 0.11f, seed, 0)
                3 -> mound(0.5f, 0.5f, 0.4f, 0.46f, 0.1f, 40, 0.04f, 0.08f, seed, 0)
                else -> mound(0.5f, 0.5f, 0.2f, 0.34f, 0.5f, 120, 0.045f, 0.11f, seed, 0)
            }
        }
        val n = 128; val wispy = type == 3
        val g = VdbVolume.Grid(); g.nx = n; g.ny = n; g.nz = n; g.voxelSize = 1f
        val data = FloatArray(n * n * n)
        val base = if (scatter) 0.22f else (if (type == 2) 0.12f else (if (type == 1 || wispy) 0.4f else 0.2f))
        val spa = sp.toTypedArray()
        java.util.stream.IntStream.range(0, n).parallel().forEach { z ->
            val fz = z.toFloat() / (n - 1).toFloat()
            for (y in 0 until n) {
                val fy = y.toFloat() / (n - 1).toFloat()
                for (x in 0 until n) {
                    val fx = x.toFloat() / (n - 1).toFloat()
                    var m = -1f
                    for (b in spa) {
                        val dx = fx - b.x; val dy = fy - b.y; val dz = fz - b.z
                        if (abs(dy) > b.r || abs(dx) > b.r) continue
                        m = max(m, 1 - sqrt(dx * dx + dy * dy + dz * dz) / b.r)
                    }
                    if (m < -0.5f) continue
                    // billow detail: coarse bumps + fine cauliflower grain eroding the edge
                    val c1 = fbm(fx * 7 + seed.toFloat(), fy * 7, fz * 7, seed)
                    val c2 = noise(fx * 22, fy * 22, fz * 22, seed + 5)
                    var e = m + (c1 - 0.5f) * 0.5f + (c2 - 0.5f) * 0.32f + (noise(fx * 44, fy * 44, fz * 44, seed + 9) - 0.5f) * 0.14f
                    if (wispy) e = m * 0.6f + (fbm(fx * 3, fy * 14, fz * 14, seed + 3) - 0.45f) * 1.1f
                    var d = min(max((e - 0.05f) / 0.17f, 0f), 1f); d = d * d * (3 - 2 * d)
                    d *= min(max((fy - base + 0.02f) / 0.06f, 0f), 1f)              // flat underside
                    data[x + n * (y + n * z)] = d
                }
            }
        }
        g.data = data
        val v = VdbVolume(); v.grids = listOf(g)
        v.bounds = Triple(1f, 0.8f, 1f)
        return v
    }
}
