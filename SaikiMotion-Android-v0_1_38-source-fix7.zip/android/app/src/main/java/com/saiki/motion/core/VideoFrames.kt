package com.saiki.motion.core

import com.saiki.motion.render.SceneRendererN

import android.graphics.Bitmap
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import kotlin.math.max

// Port of Sources/Render/VideoFrames.swift.
// iOS uses AVAssetImageGenerator at 1/10s buckets; per the RULES substitute table AVFoundation ->
// MediaCodec/MediaExtractor. Bucket stride follows the Swift code exactly (24 buckets/sec, VideoFrames.swift:85).
object VideoFrames {
    private val assets = HashMap<String, MediaMetadataRetriever>()

    fun asset(path: String): MediaMetadataRetriever {
        val a = assets[path]
        if (a != null) return a
        val r = MediaMetadataRetriever()
        r.setDataSource(path)
        assets[path] = r
        return r
    }

    /** VideoFrames.swift:25 videoSize: natural size with the preferred transform applied (rotation 90/270 swaps). */
    fun videoSize(path: String): Pair<Int, Int>? {
        return try {
            val r = asset(path)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: return null
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: return null
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) Pair(h, w) else Pair(w, h)
        } catch (_: Exception) { null }
    }

    /** VideoFrames.swift:31 duration (seconds). */
    fun duration(path: String): Float {
        return try {
            val d = asset(path).extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            d / 1000f
        } catch (_: Exception) { 0f }
    }

    // MARK: - sampler

    /**
     * Frame sampler: 24 buckets/sec like the iOS code. Async mode decodes on a background single-thread
     * executor and uploads on the render thread via [SceneRendererN]; sync mode (exporter) decodes inline.
     * The decode uses MediaMetadataRetriever.getFrameAtTime (OPTION_CLOSEST_SYNC-like tolerance ±50ms
     * mirrors requestedTimeToleranceBefore/After = 0.05s) capped at 1280px in async mode.
     */
    class Sampler(val path: String, val synchronous: Boolean = false) {
        /** Async mode: fired on the main thread after a fresh frame uploads. */
        var onUploaded: (() -> Unit)? = null
        /** Twixtor bucket rate (MetalSceneRenderer.swift:1072: bucketsPerSec = tw.fps). */
        @Volatile var bucketsPerSec: Int = 24
        private var pendingBucket = -1
        private val reqLock = Object()
        private var wantBucket = -1          // newest bucket asked for; queued older ones are skipped
        private var texH: Long = 0L
        private var bucket = -1
        var sizeW = 1; private set
        var sizeH = 1; private set
        private val queue: java.util.concurrent.ExecutorService? =
            if (synchronous) null
            else java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r, "saiki.video.${path.hashCode()}") }

        init {
            val s = videoSize(path)
            if (s != null) { sizeW = s.first; sizeH = s.second }
        }

        /** The frame at `srcTime` (seconds into the source) as a native texture handle. */
        fun texture(srcTime: Float): Long {
            val b = (max(0f, srcTime) * bucketsPerSec).toInt()
            if (b == bucket && texH != 0L) return texH
            if (synchronous) {
                generate(srcTime, b)
                return texH
            }
            synchronized(reqLock) { wantBucket = b }
            if (b == pendingBucket) return texH
            pendingBucket = b
            val q = queue
            if (q != null) {
                q.execute {
                    val w = synchronized(reqLock) { wantBucket }
                    if (w != b) {                       // playhead already moved on: don't decode a frame nobody will see
                        android.os.Handler(android.os.Looper.getMainLooper()).post { if (pendingBucket == b) pendingBucket = -1 }
                        return@execute
                    }
                    generate(srcTime, b)
                }
            }
            return texH
        }

        private fun generate(t: Float, b: Int) {
            // Decode via the shared retriever (rotation applied, SDR). Async preview caps at ~1280px
            // (VideoFrames.swift:62: decoding/uploading 4K frames was the main source of lag).
            val r = try { asset(path) } catch (_: Exception) { return }
            val bmp = try {
                val ms = (max(0f, t) * 1_000_000f).toLong()
                val opts = android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                var img = r.getFrameAtTime(ms, opts)
                if (img == null) img = r.frameAtTimeNear(ms)
                img?.let {
                    if (!synchronous && (it.width > 1280 || it.height > 1280)) {
                        val s = 1280f / max(it.width, it.height)
                        Bitmap.createScaledBitmap(it, (it.width * s).toInt().coerceAtLeast(1), (it.height * s).toInt().coerceAtLeast(1), true)
                    } else it
                }
            } catch (_: Exception) { null } ?: return
            val doUpload = {
                val newTex = SceneRendererN.texCreate(bmp.width, bmp.height, SceneRendererN.bitmapRgba(bmp))
                if (newTex != 0L) {
                    if (texH != 0L) SceneRendererN.texFree(texH)
                    texH = newTex
                    bucket = b
                    pendingBucket = -1
                }
            }
            if (synchronous) {
                doUpload()
            } else {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    doUpload()
                    onUploaded?.invoke()
                }
            }
        }

        val current: Long get() = texH
    }
}

/** OPTION_CLOSEST fallback: seek a little before and take the sync frame (tolerance 0.05s like iOS). */
private fun MediaMetadataRetriever.frameAtTimeNear(us: Long): Bitmap? = try {
    getFrameAtTime((us - 50_000L).coerceAtLeast(0L), android.media.MediaMetadataRetriever.OPTION_PREVIOUS_SYNC)
        ?: getFrameAtTime(us, android.media.MediaMetadataRetriever.OPTION_NEXT_SYNC)
} catch (_: Exception) { null }
