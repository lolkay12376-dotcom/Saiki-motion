package com.saiki.motion.core

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.sqrt

// Port of Sources/Render/WaterAssets.swift — procedural water textures.
// A tileable normal map for the water/refraction effects and a caustics sheet for pools, generated
// once with value noise, cached, handed to shaders as ordinary textures.
object WaterAssets {
    /** Tileable water normal map (RGB = normals, tileable). */
    fun normalMap(size: Int = 256): Bitmap {
        val key = "water_n$size"
        cache[key]?.let { return it }
        val img = renderNormal(size)
        cache[key] = img
        return img
    }

    /** Tileable caustics intensity map (white on transparent). */
    fun caustics(size: Int = 256): Bitmap {
        val key = "water_c$size"
        cache[key]?.let { return it }
        val img = renderCaustics(size)
        cache[key] = img
        return img
    }

    private val cache = HashMap<String, Bitmap>()

    // MARK: - generators

    private fun renderNormal(n: Int): Bitmap {
        val height = FloatArray(n * n)
        // layered tileable value noise
        for (y in 0 until n) {
            for (x in 0 until n) {
                val fx = x.toFloat() / n.toFloat()
                val fy = y.toFloat() / n.toFloat()
                var h = 0f
                var amp = 1f
                var sc = 4f
                repeat(4) {
                    h += amp * tnoise(fx * sc, fy * sc, n / sc * 0.5f)
                    amp *= 0.5f
                    sc *= 2f
                }
                height[y * n + x] = h / 1.875f
            }
        }
        val data = ByteArray(n * n * 4)
        for (y in 0 until n) {
            for (x in 0 until n) {
                val l = height[y * n + ((x - 1 + n) % n)]
                val r = height[y * n + ((x + 1) % n)]
                val u = height[((y - 1 + n) % n) * n + x]
                val d = height[((y + 1) % n) * n + x]
                val nx = (l - r) * 2
                val ny = (u - d) * 2
                val nz = 0.6f
                val len = sqrt(nx * nx + ny * ny + nz * nz)
                val i = (y * n + x) * 4
                data[i] = clamp255((nx / len * 0.5f + 0.5f) * 255f)
                data[i + 1] = clamp255((ny / len * 0.5f + 0.5f) * 255f)
                data[i + 2] = clamp255((nz / len * 0.5f + 0.5f) * 255f)
                data[i + 3] = -1
            }
        }
        return image(data, n, n)
    }

    private fun renderCaustics(n: Int): Bitmap {
        val data = ByteArray(n * n * 4)
        for (y in 0 until n) {
            for (x in 0 until n) {
                val fx = x.toFloat() / n.toFloat()
                val fy = y.toFloat() / n.toFloat()
                // voronoi-ish caustic webs: two noise fields sharpened
                val a = tnoise(fx * 6f, fy * 6f, n / 6f * 0.5f)
                val b = tnoise(fx * 9f + 3.7f, fy * 9f + 1.3f, n / 9f * 0.5f)
                val v = abs(a - b).pow(0.6f)
                val bright = ((1.0 - v * 3.2).toFloat()).coerceIn(0f, 1f)
                val i = (y * n + x) * 4
                val c = (bright * 255).toInt().toByte()
                data[i] = c; data[i + 1] = c; data[i + 2] = kotlin.math.min(255, (c.toInt() and 0xFF) + 18).toByte()
                data[i + 3] = (bright * 220).toInt().toByte()
            }
        }
        return image(data, n, n)
    }

    private fun clamp255(v: Float): Byte = v.toInt().coerceIn(0, 255).toByte()

    private fun image(data: ByteArray, w: Int, h: Int): Bitmap {
        val px = IntArray(w * h)
        for (i in 0 until w * h) {
            val r = data[i * 4].toInt() and 0xFF
            val g = data[i * 4 + 1].toInt() and 0xFF
            val b = data[i * 4 + 2].toInt() and 0xFF
            val a = data[i * 4 + 3].toInt() and 0xFF
            px[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return bmp
    }

    /** Tileable value noise with period `period`. */
    private fun tnoise(x: Float, y: Float, period: Float): Float {
        val xi = floor(x); val yi = floor(y)
        val xf = x - xi; val yf = y - yi
        val u = xf * xf * (3 - 2 * xf)
        val v = yf * yf * (3 - 2 * yf)
        fun h(px: Float, py: Float): Float {
            var n: Long = (px + py * period * 57.0f).toRawBits().toLong()
            n = n * 747796405L + 2891336453L
            val sh = ((n ushr 32) + 4L).toInt()
            n = ((n ushr sh) xor n) * 277803737L
            n = (n ushr 22) xor n
            return (n % 10000L).toFloat() / 10000f
        }
        val x0 = ((xi % period) + period) % period
        val x1 = (x0 + 1) % period
        val y0 = ((yi % period) + period) % period
        val y1 = (y0 + 1) % period
        val a = h(x0, y0); val b = h(x1, y0)
        val c = h(x0, y1); val d = h(x1, y1)
        return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v
    }
}

/** One-tap water looks. Every value stays editable afterwards in the layer's Water settings. */
object WaterPresets {
    val names = listOf("Ocean", "Lake", "River", "Pool", "Storm", "Tropical")
    val keys = listOf("wAmp", "wFreq", "wSpeed", "wChop", "wFoam", "wDepth", "wClar", "wTurb", "wRefr", "wSss", "wGlint", "wDetail", "wVar", "wSwell", "wSwellLen", "wCaps")
    val vals = listOf(
        floatArrayOf(0.06f, 4f, 1.0f, 0.65f, 0.6f, 0.8f, 0.55f, 0.10f, 0.5f, 0.5f, 1.0f, 0.6f, 0.9f, 1.2f, 0.15f, 0.6f),     // Ocean
        floatArrayOf(0.015f, 7f, 0.6f, 0.25f, 0.1f, 0.6f, 0.5f, 0.20f, 0.5f, 0.4f, 1.0f, 0.5f, 0.6f, 0.3f, 0.15f, 0.1f),     // Lake
        floatArrayOf(0.02f, 9f, 2.2f, 0.45f, 0.35f, 0.35f, 0.45f, 0.35f, 0.5f, 0.3f, 1.0f, 0.9f, 0.8f, 0.15f, 0.2f, 0.2f),   // River
        floatArrayOf(0.004f, 12f, 0.5f, 0.1f, 0.0f, 0.3f, 1.0f, 0.0f, 0.8f, 0.2f, 1.2f, 0.35f, 0.3f, 0.0f, 0.15f, 0.0f),     // Pool
        floatArrayOf(0.12f, 3f, 1.8f, 1.0f, 1.0f, 0.9f, 0.3f, 0.35f, 0.4f, 0.4f, 1.0f, 1.0f, 1.0f, 1.6f, 0.15f, 1.0f),       // Storm
        floatArrayOf(0.03f, 5f, 0.9f, 0.4f, 0.3f, 0.4f, 1.0f, 0.0f, 0.6f, 0.8f, 1.0f, 0.6f, 0.7f, 0.5f, 0.15f, 0.2f))        // Tropical

    fun apply(i: Int, l: Layer) {
        if (i < 0 || i >= vals.size) return
        for ((k, x) in keys.zip(vals[i].toList())) l.xset(k, x)
    }
}
