package com.saiki.motion.core

import android.graphics.BitmapFactory
import android.media.ExifInterface
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Port of Sources/Render/Xf.swift (transforms). Matrices are FloatArray [a b c d tx ty] like CGAffineTransform.
 * nullMotion returns FloatArray(4) = (dx, dy, dr, dz). lockFlags returns BooleanArray(3) = (rot, scale, move).
 */
object Xf {
    /** Particle layers (dedicated type, or a shape carrying the Particles effect). */
    fun isParticles(l: Layer): Boolean =
        l.type == LayerType.PARTICLES || (l.fx.contains("particles") && !l.fxOff.contains("particles")) || isStrands(l) || isParticular(l)
    fun isParticular(l: Layer): Boolean = l.fx.contains("particular") && !l.fxOff.contains("particular")
    /** BCC Organic Strands: a shape layer carrying the "bccstrands" effect (drawn by the particle renderer). */
    fun isStrands(l: Layer): Boolean = l.fx.contains("bccstrands") && !l.fxOff.contains("bccstrands")
    fun showSrcKey(l: Layer): String = if (isParticular(l)) "ptShowSrc" else if (isStrands(l)) "stShowSrc" else "pShowSrc"

    /** Puppet pin space. A group's puppet warps the flattened canvas image, so its pin space is the whole canvas. */
    fun puppetQuad(l: Layer): Pair<Float, Float> {
        if (l.type == LayerType.GROUP) return Pair(2 * Editor.project.w.toFloat() / max(Editor.project.h, 1).toFloat(), 2f)
        return quadSize(l)
    }
    fun puppetMatrix(l: Layer, t: Float): FloatArray = if (l.type == LayerType.GROUP) floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f) else matrix(l, t)

    /** Natural quad size (world units) of a layer's content. */
    fun quadSize(l: Layer): Pair<Float, Float> {
        when (l.type) {
            LayerType.IMAGE, LayerType.VIDEO -> {
                val (iw, ih) = contentAspect(l)
                val h = 1.0f
                return Pair(h * iw / max(ih, 0.0001f), h)
            }
            LayerType.TEXT -> {
                val fs = l.p("fontSize", Editor.time)
                val (cw, ch) = TextRaster.measure(l, Editor.time)
                val lh = max(TextRaster.lineHeight(l, Editor.time), 0.0001f)
                return Pair(cw / lh * fs, ch / lh * fs)
            }
            LayerType.SHAPE -> return Pair(0.8f, 0.84f)
            LayerType.FLARE -> return Pair(2f, 2f)
            LayerType.PARTICLES -> return Pair(2f, 2f)
            LayerType.MODEL -> return Pair(1f, 1f)
            else -> return Pair(0.8f, 0.84f)
        }
    }

    /** Source pixel aspect of a layer's media (1:1 when unknown). */
    private val aspectCache = HashMap<String, Pair<Float, Float>>()
    fun contentAspect(l: Layer): Pair<Float, Float> {
        val path = l.imagePath ?: return Pair(1f, 1f)
        synchronized(aspectCache) { aspectCache[path]?.let { return it } }
        val r = contentAspectRaw(l)
        synchronized(aspectCache) { aspectCache[path] = r }
        return r
    }
    private fun contentAspectRaw(l: Layer): Pair<Float, Float> {
        val path = l.imagePath ?: return Pair(1f, 1f)
        val ext = path.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (listOf("glb", "gltf", "obj", "fbx", "abc", "vdb", "pmx", "mmd", "ply", "spz").contains(ext)) return Pair(1f, 1f)
        val o = BitmapFactory.Options(); o.inJustDecodeBounds = true
        try { BitmapFactory.decodeFile(path, o) } catch (_: Exception) {}
        if (o.outWidth > 0 && o.outHeight > 0) {
            var w = o.outWidth; var h = o.outHeight
            // UIImage.size already accounts for EXIF orientation
            try { val ori = ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1); if (ori in 5..8) { val x = w; w = h; h = x } } catch (_: Exception) {}
            return Pair(w.toFloat(), h.toFloat())
        }
        VideoFrames.videoSize(path)?.let { return Pair(it.first.toFloat(), it.second.toFloat()) }
        return Pair(1f, 1f)
    }

    /** 3x3 affine (a..f) of a layer at time `t`, parents included. */
    fun matrix(l: Layer, t: Float): FloatArray = chainMatrix(l, t, 0)

    private fun chainMatrix(l: Layer, t: Float, depth: Int, fixPos: Boolean = false): FloatArray {
        if (depth >= 16) return floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
        // while a group is being baked its own transform (and everything above it) is left out
        if (l.id == bakeRoot) return floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
        var m = localMatrix(l, t, if (fixPos) l.start else null)
        if (l.parentId >= 0) {
            val parent = Editor.scene.layers.firstOrNull { it.id == l.parentId }
            if (parent != null) {
                val lk = lockFlags(l, t)
                val pm = chainMatrix(parent, t, depth + 1, lk[2] || fixPos)   // freeze the whole chain above, not just the direct parent
                m = if (lk[0] || lk[1]) mulLocked(pm, m, lk[0], lk[1]) else mul(pm, m)
                // Physics sway: the layer hangs on the parent's DEFORMED mesh (parent puppet pins), not just its transform
                if (PuppetMath.followsParentPuppet(l)) {
                    val o = apply(m, 0f, 0f); val f = PuppetMath.parentFollow(parent, t, o.first, o.second)
                    m[4] += f.first; m[5] += f.second
                }
            }
        }
        return m
    }

    /** Flags of the layer's Parent Lock effect (all false when missing or switched off): (rot, scale, move). */
    fun lockFlags(l: Layer, t: Float): BooleanArray {
        if (l.fx.isEmpty() || !l.fx.any { !l.fxOff.contains(it) && Registry.get(it)?.id == "parentlock" }) return booleanArrayOf(false, false, false)
        return booleanArrayOf(l.p("plRot", t) > 0.5f, l.p("plScale", t) > 0.5f, l.p("plMove", t) > 0.5f)
    }

    private fun lockedLinear(p: FloatArray, rot: Boolean, scl: Boolean): FloatArray {
        var a = p[0]; var b = p[1]; var c = p[2]; var d = p[3]
        if (rot) {
            val ang = atan2(b, a); val cs = cos(-ang); val sn = sin(-ang)
            val na = a * cs - b * sn; val nb = a * sn + b * cs
            val nc = c * cs - d * sn; val nd = c * sn + d * cs
            a = na; b = nb; c = nc; d = nd
        }
        if (scl) {
            val sx = max(1e-6f, sqrt(a * a + b * b)); val sy = max(1e-6f, sqrt(c * c + d * d))
            a /= sx; b /= sx; c /= sy; d /= sy
        }
        return floatArrayOf(a, b, c, d, 0f, 0f)
    }

    /** Changes a layer's parent without moving it (Parent Lock effect included). */
    fun reparentKeepingPose(l: Layer, newId: Int, t: Float, autoKey: Boolean) {
        val world = matrix(l, t)
        l.parentId = newId
        var loc = world
        if (newId >= 0) {
            val par = Editor.scene.layers.firstOrNull { it.id == newId }
            if (par != null) {
                val pm = chainMatrix(par, t, 0)
                val lk = lockFlags(l, t)
                val invP = invert(pm) ?: return
                val invL = invert(lockedLinear(pm, lk[0], lk[1])) ?: return
                val lin = mul(invL, floatArrayOf(world[0], world[1], world[2], world[3], 0f, 0f))
                val tr = apply(invP, world[4], world[5])
                loc = floatArrayOf(lin[0], lin[1], lin[2], lin[3], tr.first, tr.second)
            }
        }
        fun put(k: String, v: Float) { l.track(k).set(l.editTime(k, t), v, autoKey) }
        val a = loc[0]; val b = loc[1]; val c = loc[2]; val d = loc[3]
        var deg = atan2(b, a) * 180 / Math.PI.toFloat()
        val curRot = l.p("rotZ", l.editTime("rotZ", t))
        deg += 360 * roundAway((curRot - deg) / 360)
        val sxCur = max(1e-4f, abs(l.p("scaleX", l.editTime("scaleX", t))))
        val newSc = sqrt(a * a + b * b) / sxCur
        val newSy = sqrt(c * c + d * d) / max(1e-4f, newSc)
        put("rotZ", deg); put("scale", newSc); put("scaleY", newSy)
        val lm = localMatrix(l, t)
        val x = l.p("x", l.editTime("x", t)); val y = l.p("y", l.editTime("y", t))
        put("x", x + (loc[4] - lm[4])); put("y", y + (loc[5] - lm[5]))
    }

    /** Like `mul`, but the child's own orientation ignores the parent's rotation and/or scale while its position still follows. */
    private fun mulLocked(p: FloatArray, m: FloatArray, rot: Boolean, scl: Boolean): FloatArray {
        var a = p[0]; var b = p[1]; var c = p[2]; var d = p[3]
        if (rot) {
            val ang = atan2(b, a); val cs = cos(-ang); val sn = sin(-ang)
            val na = a * cs - b * sn; val nb = a * sn + b * cs
            val nc = c * cs - d * sn; val nd = c * sn + d * cs
            a = na; b = nb; c = nc; d = nd
        }
        if (scl) {
            val sx = max(1e-6f, sqrt(a * a + b * b)); val sy = max(1e-6f, sqrt(c * c + d * d))
            a /= sx; b /= sx; c /= sy; d /= sy
        }
        return floatArrayOf(m[0] * a + m[1] * c, m[0] * b + m[1] * d,
            m[2] * a + m[3] * c, m[2] * b + m[3] * d,
            m[4] * p[0] + m[5] * p[2] + p[4], m[4] * p[1] + m[5] * p[3] + p[5])
    }

    /** Z position including the parent chain (a child's Z is relative to its 3D parent). */
    fun worldZ(l: Layer, t: Float): Float {
        var z = l.p("z", l.editTime("x", t))
        if (l.type == LayerType.NULL && l.is3d && l.fx.isNotEmpty()) z += nullMotion(l, l.editTime("x", t))[3]
        var cur = l; var depth = 0
        while (cur.parentId >= 0 && depth < 16) {
            val pid = cur.parentId
            val par = Editor.scene.layers.firstOrNull { it.id == pid } ?: break
            if (par.id == bakeRoot) break
            if (par.is3d || par.type == LayerType.MODEL) {
                z += par.p("z", par.editTime("x", t))
                if (par.type == LayerType.NULL && par.fx.isNotEmpty()) z += nullMotion(par, par.editTime("x", t))[3]
            }
            cur = par; depth += 1
        }
        return z
    }

    /** Tilt (rotX, rotY in degrees) inherited from 3D Null parents. */
    fun inheritedTilt(l: Layer, t: Float): Pair<Float, Float> {
        var rx = 0f; var ry = 0f
        var cur = l; var depth = 0
        while (cur.parentId >= 0 && depth < 16) {
            val pid = cur.parentId
            val par = Editor.scene.layers.firstOrNull { it.id == pid } ?: break
            if (par.id == bakeRoot) break
            if (par.type == LayerType.NULL && par.is3d) {
                val pt = par.editTime("x", t)
                rx += par.p("rotX", pt); ry += par.p("rotY", pt)
            }
            cur = par; depth += 1
        }
        return Pair(rx, ry)
    }

    /** A world-space movement (dx, dy) expressed in the layer's own position space (parent chain undone). */
    fun toParentSpace(l: Layer, t: Float, dx: Float, dy: Float): Pair<Float, Float> {
        if (l.parentId < 0) return Pair(dx, dy)
        val par = Editor.scene.layers.firstOrNull { it.id == l.parentId } ?: return Pair(dx, dy)
        val pm = matrix(par, t)
        val det = pm[0] * pm[3] - pm[1] * pm[2]
        if (!(abs(det) > 1e-6f)) return Pair(dx, dy)
        return Pair((pm[3] * dx - pm[2] * dy) / det, (-pm[1] * dx + pm[0] * dy) / det)
    }

    /** The layer's own matrix: translate to (x, y), rotate, scale, then offset by the anchor inside the quad. */
    fun localMatrix(l: Layer, t: Float, posT: Float? = null): FloatArray {
        val lt = l.editTime("x", t)
        val pt = if (posT != null) l.editTime("x", posT) else lt      // posT: position frozen at that time (Lock Movement)
        val x = l.p("x", pt)
        val y = l.p("y", pt)
        val sc = l.p("scale", lt)
        val sx = l.p("scaleX", lt)
        val sy = l.p("scaleY", lt)
        val rz = l.p("rotZ", lt) * Math.PI.toFloat() / 180
        val ax = l.p("anchorX", lt)
        val ay = l.p("anchorY", lt)
        val (qw, qh) = quadSize(l)

        // anchor offset in world units (rotated with the quad)
        val ox = -(ax - 50) / 100 * qw * sc * sx
        val oy = (ay - 50) / 100 * qh * sc * sy
        val c = cos(rz); val s = sin(rz)
        val rox = ox * c - oy * s
        val roy = ox * s + oy * c

        // Null layers: movement effects (shake / oscillate) move everything parented to the null
        var nx = 0f; var ny = 0f; var nr = 0f
        if (l.type == LayerType.NULL && l.fx.isNotEmpty()) { val m = nullMotion(l, lt); nx = m[0]; ny = m[1]; nr = m[2] }
        val c2 = if (nr == 0f) c else cos(rz + nr); val s2 = if (nr == 0f) s else sin(rz + nr)

        // T(x + rox, y + roy) * R(rz) * S(sc*sx, sc*sy)
        val a = c2 * sc * sx; val b = s2 * sc * sx
        val cc = -s2 * sc * sy; val d = c2 * sc * sy
        return floatArrayOf(a, b, cc, d, x + rox + nx, y + roy + ny)
    }

    /** Movement effects on a Null layer -> (dx, dy, rotation radians, dz). */
    fun nullMotion(l: Layer, t: Float): FloatArray {
        fun noise(k: Float, seed: Float): Float = sin(k * 1.7f + seed) * 0.5f + sin(k * 2.9f + seed * 2.3f) * 0.3f + sin(k * 5.3f + seed * 0.7f) * 0.2f
        var dx = 0f; var dy = 0f; var dr = 0f; var dz = 0f
        val d3 = l.is3d
        val PI = Math.PI.toFloat()
        for (e in l.fx) {
            if (l.fxOff.contains(e)) continue
            val d = Registry.get(e) ?: continue
            fun v(key: String): Float {
                val k = if (d.kind == 1) key else e + "__" + key
                return if (l.p(k, t) == 0f && l.props[k] == null) (d.props.firstOrNull { it.key == key }?.def ?: 0f) else l.p(k, t)
            }
            when (d.id) {
                "sshake" -> {
                    val a = v("amount") * 2; val tt = t * v("speed")
                    dx += noise(tt, 3.7f) * a * 2; dy += noise(tt, 9.2f) * a * 2
                    dr += noise(tt, 5.1f) * v("rot") * PI / 180 * 2
                    if (d3) dz += noise(tt, 2.9f) * a * 2
                }
                "oscillate" -> {
                    val a = v("amount") * 2; val f = v("freq")
                    dx += sin(t * f) * a; dy += cos(t * f * 0.8f) * a
                    if (d3) dz += sin(t * f * 1.3f + 1.1f) * a          // 3D null: wobbles in depth too
                }
                "autoshake" -> {
                    val beat = t * v("rate") / 60; val ph = beat - floor(beat); val a = v("amount") * 2 * exp(-ph * 6)
                    dx += noise(beat * 40, 1.3f) * a * 2; dy += noise(beat * 40, 7.7f) * a * 2
                    if (d3) dz += noise(beat * 40, 4.1f) * a * 2
                }
                else -> if (d.id.startsWith("shake_")) {
                    val i = if (d.id.endsWith("impact")) 1 else if (d.id.endsWith("earthquake")) 2 else 0
                    val a = floatArrayOf(0.012f, 0.05f, 0.09f)[i] * 2; val sp = floatArrayOf(2.5f, 7f, 12f)[i]
                    dx += noise(t * sp, 3.7f) * a * 2; dy += noise(t * sp, 9.2f) * a * 2
                    if (d3) dz += noise(t * sp, 6.3f) * a * 2
                }
            }
        }
        return floatArrayOf(dx, dy, dr, dz)
    }

    /** Effects a Null layer accepts: movement only. */
    fun isMovementFx(id: String): Boolean = id == "sshake" || id == "oscillate" || id == "autoshake" || id.startsWith("shake_")

    /** C * M (CGAffineTransformConcat(child, parent): child applied first, then parent). */
    fun mul(c: FloatArray, m: FloatArray): FloatArray {
        val a = m[0] * c[0] + m[1] * c[2]
        val b = m[0] * c[1] + m[1] * c[3]
        val cc = m[2] * c[0] + m[3] * c[2]
        val d = m[2] * c[1] + m[3] * c[3]
        val tx = m[4] * c[0] + m[5] * c[2] + c[4]
        val ty = m[4] * c[1] + m[5] * c[3] + c[5]
        return floatArrayOf(a, b, cc, d, tx, ty)
    }

    /** Applies the matrix to a point. */
    fun apply(m: FloatArray, x: Float, y: Float): Pair<Float, Float> = Pair(m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5])

    /** World-space corners of the layer quad at time t (tl, tr, br, bl). */
    fun quadCorners(l: Layer, t: Float): List<Pair<Float, Float>> {
        val m = matrix(l, t)
        val (qw, qh) = quadSize(l)
        val hw = qw / 2; val hh = qh / 2
        return listOf(apply(m, -hw, hh), apply(m, hw, hh), apply(m, hw, -hh), apply(m, -hw, -hh))
    }

    /** Hit test in world space. */
    fun hit(l: Layer, x: Float, y: Float, t: Float): Boolean {
        val m = matrix(l, t)
        val inv = invert(m) ?: return false
        val (qw, qh) = quadSize(l)
        val p = apply(inv, x, y)
        return abs(p.first) <= qw / 2 && abs(p.second) <= qh / 2
    }

    fun invert(m: FloatArray): FloatArray? {
        val det = m[0] * m[3] - m[1] * m[2]
        if (abs(det) < 1e-9f) return null
        val id = 1 / det
        return floatArrayOf(m[3] * id, -m[1] * id, -m[2] * id, m[0] * id,
            (m[2] * m[5] - m[3] * m[4]) * id, (m[1] * m[4] - m[0] * m[5]) * id)
    }

    /** True while a pre-rendered group bakes its flat plane: the scene camera is ignored inside. */
    @Volatile var bakingPlane = false
    /** Id of the group currently being baked (-1 = none): its transform is treated as identity. */
    @Volatile var bakeRoot = -1
    /** Draw 3D layers flat (no rotation / camera). */
    @Volatile var flatDraw = false

    /** A group flattened into its own 2D picture (pre-render / pre-comp): owns its own camera scope. */
    fun isFlatScope(g: Layer): Boolean = g.type == LayerType.GROUP && ((g.prerender && PreRender.enabled) || g.precomp || has3DContent(g))

    /** A group that holds a 3D scene (camera, model, 3D layer, particles...) is always flattened like a pre-comp. */
    fun has3DContent(g: Layer): Boolean {
        if (!(g.type == LayerType.GROUP && g.mask == 0 && g.rig == null)) return false
        return PreRender.descendants(g, Editor.scene).any {
            it.type == LayerType.CAMERA || it.type == LayerType.MODEL || it.type == LayerType.PARTICLES || it.is3d || isParticular(it) || isStrands(it)
        }
    }

    /** Group drawn as one flat plane (baked frame or live-flattened). */
    fun isPlaneGroup(g: Layer): Boolean = g.type == LayerType.GROUP && ((g.prerender && PreRender.enabled) || has3DContent(g))

    /** Id of the nearest flattened group above `l` (-1 = the main scene). */
    fun cameraScope(l: Layer): Int {
        var cur = l; var depth = 0
        while (cur.parentId >= 0 && depth < 16) {
            val pid = cur.parentId
            val par = Editor.scene.layers.firstOrNull { it.id == pid } ?: break
            if (isFlatScope(par)) return par.id
            cur = par; depth += 1
        }
        return -1
    }

    /** The camera that looks at `l`: nearest visible camera above it in the stack within the same scope. */
    fun camera(l: Layer): Layer? {
        if (flatDraw) return null
        if (bakingPlane && l.id == bakeRoot) return null
        val idx = Editor.scene.layers.indexOfFirst { it === l }
        if (idx < 0) return null
        val scope = cameraScope(l)
        var best: Layer? = null; var bestIdx = -1
        for ((j, c) in Editor.scene.layers.withIndex()) {
            if (!(c.type == LayerType.CAMERA && c.visible && j > idx)) continue
            if (cameraScope(c) != scope) continue
            if (bestIdx < 0 || j < bestIdx) { best = c; bestIdx = j }
        }
        return best
    }

    /** Convert canvas-normalized (0..1, 0..1 top-left) to world units. */
    fun world(nx: Float, ny: Float, ar: Float): Pair<Float, Float> = Pair(nx * 2 * ar - ar, 1 - ny * 2)
}
