package com.saiki.motion.render

import android.content.res.AssetManager
import android.view.Surface

/** JNI bridge to the Vulkan core (cpp/vk_core.cpp). Mirrors iOS MetalCore's role. */
object NativeRenderer {
    init { System.loadLibrary("saiki") }
    external fun init(surface: Surface, assets: AssetManager): Boolean
    external fun resize(w: Int, h: Int)
    external fun frame(timeSec: Float)
    external fun destroy()

    // ---- effect runtime (cpp/fx_runtime.cpp == MetalEffects): async runtime GLSL -> SPIR-V (NDK shaderc), passthrough until ready ----
    external fun fxPrepare(key: String, glsl450: String, name: String): Boolean   // idempotent; starts the background compile on first use
    external fun fxStatus(key: String): Int       // -1 unknown, 0 compiling (canRun), 1 ready, 2 failed
    external fun fxError(key: String): String
    external fun fxReadyCount(): Int              // bumps whenever a compile finishes (== MetalEffects.readyNote): redraw the preview when it changes
}
