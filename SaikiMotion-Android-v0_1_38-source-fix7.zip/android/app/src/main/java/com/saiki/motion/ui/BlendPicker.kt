@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import com.saiki.motion.render.SceneRendererN
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIControl
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// Port of Sources/UI/BlendPicker.swift — grouped (collapsible ^) blend-mode picker with live sample
// icons. Icons are rendered with the real composite pass (SceneRendererN), so they always match output.

object BlendModes {
    class Mode(val name: String, val id: Int)
    class Group(val title: String, val modes: List<Mode>)

    /** id = value stored in Layer.blend (must match composite.frag). */
    val groups = listOf(
        Group("Dissolve modes", listOf(Mode("Normal", 0), Mode("Dissolve", 10))),
        Group("Darken", listOf(Mode("Darken", 11), Mode("Multiply", 3), Mode("Color Burn", 12), Mode("Linear Burn", 13), Mode("Darker Color", 14))),
        Group("Lighten", listOf(Mode("Add", 1), Mode("Lighten", 15), Mode("Screen", 2), Mode("Color Dodge", 16), Mode("Lighter Color", 17))),
        Group("Contrast", listOf(Mode("Overlay", 18), Mode("Soft Light", 19), Mode("Hard Light", 20), Mode("Vivid Light", 21),
                                 Mode("Linear Light", 22), Mode("Pin Light", 23), Mode("Hard Mix", 24))),
        Group("Inversion", listOf(Mode("Difference", 25), Mode("Exclusion", 26), Mode("Subtract", 27), Mode("Divide", 28))),
        Group("Component", listOf(Mode("Hue", 31), Mode("Saturation", 32), Mode("Color", 33), Mode("Luminosity", 34))))

    fun name(id: Int): String = groups.flatMap { it.modes }.firstOrNull { it.id == id }?.name ?: "Normal"

    private val cache = HashMap<Int, android.graphics.Bitmap>()
    private const val S = 64

    /** Sample: blue→yellow backdrop with a pink→green soft circle blended on top. */
    fun icon(mode: Int): android.graphics.Bitmap? {
        cache[mode]?.let { return it }
        val n = S
        val bg = ByteArray(n * n * 4) { 255.toByte() }
        val fg = ByteArray(n * n * 4)
        for (y in 0 until n) for (x in 0 until n) {
            val i = (y * n + x) * 4
            val fx = x.toFloat() / (n - 1); val fy = y.toFloat() / (n - 1)
            bg[i] = (30 + 220 * fx).toInt().toByte(); bg[i + 1] = (60 + 140 * fx).toInt().toByte(); bg[i + 2] = (200 - 140 * fx).toInt().toByte()
            val dx = x - n / 2f; val dy = y - n / 2f
            val a = min(1f, max(0f, (n * 0.38f - sqrt(dx * dx + dy * dy)) / 2))
            fg[i] = (a * (230 - 170 * fy)).toInt().toByte(); fg[i + 1] = (a * (60 + 170 * fy)).toInt().toByte()
            fg[i + 2] = (a * (120 + 40 * fy)).toInt().toByte(); fg[i + 3] = (a * 255).toInt().toByte()
        }
        val tb = SceneRendererN.texCreate(n, n, bg)
        val tf = SceneRendererN.texCreate(n, n, fg)
        if (tb == 0L || tf == 0L) return null
        val outH = SceneRendererN.targetCreate(n, n, false)
        if (outH == 0L) return null
        val scratchH = SceneRendererN.targetCreate(n, n, false)
        // runSync twin: composite through the bridge inside a sync frame
        if (!SceneRendererN.begin()) return null
        val ok = SceneRendererN.composite(outH, scratchH, SceneRendererN.targetTex(tb), 0L, 1f, mode, 0, 0f)
        var img: android.graphics.Bitmap? = null
        if (ok) img = SceneRendererN.readTarget(outH)
        SceneRendererN.finish()
        SceneRendererN.targetFree(outH); SceneRendererN.targetFree(scratchH)
        SceneRendererN.texFree(tb); SceneRendererN.texFree(tf)
        if (img != null) cache[mode] = img
        return img
    }
}

private class BlendTile(val name: String, val icon: android.graphics.Bitmap?, val selected: Boolean) : UIControl(com.saiki.motion.uikit.appContext!!) {
    init {
        onClick = { }
    }

    var pick: (() -> Unit)? = null
        set(v) { field = v; onClick = { v?.invoke() } }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val sel = pick != null && isSelected
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
        // icon square
        val pad = 4f
        val iw = rect.width - pad * 2
        val ih = iw
        val r = android.graphics.RectF(pad, pad, pad + iw, pad + ih)
        c.canvas.drawRoundRect(r, 8f, 8f, p.apply { color = 0x2E000000.toInt() or 0xFF000000.toInt() })
        if (icon != null) c.canvas.drawBitmap(icon, null, r, p)
        if (sel) {
            p.style = android.graphics.Paint.Style.STROKE; p.strokeWidth = 2.5f; p.color = 0xFFFF8A1F.toInt()
            c.canvas.drawRoundRect(r, 8f, 8f, p)
            p.style = android.graphics.Paint.Style.FILL
        }
        drawText(name, rect.midX, pad + ih + 16f, color = if (sel) 0xFFFF8A1F.toInt() else 0xFFFFFFFF.toInt(), size = 11f,
                 bold = sel, align = NSTextAlignment.center)
    }

    var selectedNow = false
}

object BlendPicker {
    private val open = HashSet<String>()
    private var seeded = false

    fun build(current: Int, onPick: (Int) -> Unit, onToggle: () -> Unit): UiView {
        if (!seeded) { seeded = true; open.add(BlendModes.groups[0].title) }
        BlendModes.groups.firstOrNull { g -> g.modes.any { it.id == current } }?.let { open.add(it.title) }
        val ctx = com.saiki.motion.uikit.appContext!!
        val rows = ArrayList<List<Pair<BlendTile, Int>>>()
        val headers = ArrayList<Pair<Header, String>>()
        var y = 0f
        return object : UiView(ctx) {
            override fun layoutSubviews() {
                var yy = 0f
                val w = rectWidth()
                for ((h, _) in headers) { h.frame = CGRect(0f, yy, w, 48f); yy += 56f
                    val isOpen = h.isOpenNow
                    if (isOpen) {
                        for (row in rows) {
                            val cw = w / 4
                            for ((ci, t) in row.withIndex()) t.first.frame = CGRect(ci * cw + 3f, yy, cw - 6f, cw + 22f)
                            yy += row.firstOrNull()?.first?.rectHeight()?.plus(26f) ?: 90f
                        }
                    }
                }
                val total = yy
                val host = superview
                if (host is com.saiki.motion.uikit.CapScroll) host.contentSize = CGSize(host.contentSize.width, max(host.contentSize.height, total))
                setNeedsDisplay()
            }
            public override fun draw(rect: CGRect) { /* children draw themselves */ }
        }.also { root ->
            for (g in BlendModes.groups) {
                val isOpen = open.contains(g.title)
                val h = Header(g.title, isOpen, g.modes.firstOrNull { it.id == current }?.name)
                h.toggle = {
                    if (isOpen) open.remove(g.title) else open.add(g.title)
                    onToggle()
                }
                headers.add(Pair(h, g.title))
                root.addSubview(h)
                if (!isOpen) continue
                var row = ArrayList<Pair<BlendTile, Int>>()
                for ((k, m) in g.modes.withIndex()) {
                    val t = BlendTile(m.name, BlendModes.icon(m.id), m.id == current)
                    t.selectedNow = m.id == current
                    t.pick = { onPick(m.id) }
                    row.add(Pair(t, m.id))
                    if (row.size == 4) { rows.add(row); for (tt in row) root.addSubview(tt.first); row = ArrayList() }
                }
                if (row.isNotEmpty()) { rows.add(row); for (tt in row) root.addSubview(tt.first) }
            }
            root.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        }
    }

    class Header(private val title: String, var isOpenNow: Boolean, private val current: String?) : TapView() {
        var toggle: (() -> Unit)? = null

        init {
            onClick = { toggle?.invoke() }
        }

        public override fun draw(rect: CGRect) {
            val c = UIGraphics.getCurrentContext() ?: return
            fillRoundRect(c, rect, 10f, 0x1C000000.toInt() or 0xFF000000.toInt())
            drawText(title, 14f, rect.midY + 5.5f, color = 0xFFFFFFFF.toInt(), size = 16f, bold = true, align = NSTextAlignment.left)
            if (!isOpenNow && current != null) {
                val cw = measureText(current, 13f)
                drawText(current, rect.width - 46f - cw, rect.midY + 4.5f, color = 0xFFFF8A1F.toInt(), size = 13f, bold = false, align = NSTextAlignment.left)
            }
            Icons.draw(c, if (isOpenNow) "chevron_up" else "chevron_down", rect.width - 24f, rect.midY, 18f, 0xFF909090.toInt())
        }
    }
}

// Port of Sources/UI/PlusMenu.swift — the 3D editor's "+" menu: a custom grouped popover.
// Top level is four short rows; each opens its own small page, so nothing is a 15-item wall.

class PlusItem {
    var title: String
    var icon: String
    var checked: Boolean? = null          // non-null = toggle row (menu stays open)
    var children: List<PlusItem>? = null   // non-null = opens a page
    var action: (() -> Unit)? = null

    constructor(title: String, icon: String, checked: Boolean? = null, children: List<PlusItem>? = null, action: (() -> Unit)? = null) {
        this.title = title; this.icon = icon; this.checked = checked; this.children = children; this.action = action
    }
}

class PlusMenuView(private val accent: Int) : UiView(com.saiki.motion.uikit.appContext!!) {
    private val card = object : UiView(context) {
        public override fun draw(rect: CGRect) {
            val c = UIGraphics.getCurrentContext() ?: return
            // shadow + card
            val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            p.setShadowLayer(18f, 0f, 6f, 0x73000000)
            p.color = 0xFA212126.toInt()
            c.canvas.drawRoundRect(android.graphics.RectF(0f, 0f, rect.width, rect.height), 18f, 18f, p)
            p.clearShadowLayer()
            p.style = android.graphics.Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0x14FFFFFF
            c.canvas.drawRoundRect(android.graphics.RectF(0f, 0f, rect.width, rect.height), 18f, 18f, p)
        }
    }
    private var root: List<PlusItem> = emptyList()
    private var path = ArrayList<Int>()
    private var rebuilt: (() -> List<PlusItem>)? = null

    init {
        setBackgroundColor(0x03000000)       // catches outside taps
        val outsideTap = com.saiki.motion.uikit.UITapGestureRecognizer { dismiss() }
        outsideTap.cancelsTouchesInView = false
        addGestureRecognizer(outsideTap)
        addSubview(card)
    }

    /** Shows the menu above `anchor`, right-aligned to it. `items` is re-read after every toggle so checks stay current. */
    fun present(host: UiView, anchor: UiView, items: () -> List<PlusItem>) {
        rebuilt = items; root = items(); path.clear()
        frame = CGRect(0f, 0f, host.rectWidth(), host.rectHeight())
        host.addSubview(this)
        val a = anchor.convertBoundsTo(host)
        val cardW = 270f
        card.frame = CGRect(host.rectWidth() - a.right, max(8f, a.top - 8f - estHeight()), cardW, estHeight())
        fill()
        card.alpha = 0f
        com.saiki.motion.uikit.UIViewAnimator.animate(0.16f) { card.alpha = 1f }
    }

    private fun estHeight(): Float {
        val (_, items) = current()
        return 12f + items.size * 46f + (if (path.isNotEmpty()) 52f else 0f)
    }

    fun dismiss() {
        com.saiki.motion.uikit.UIViewAnimator.animate(0.12f) { card.alpha = 0f }
        removeFromSuperview()
    }

    private fun current(): Pair<String?, List<PlusItem>> {
        var items = root
        var title: String? = null
        for (i in path) {
            if (i >= items.size) break
            val ch = items[i].children ?: break
            title = items[i].title
            items = ch
        }
        return Pair(title, items)
    }

    private fun fill() {
        card.subviews.forEach { it.removeFromSuperview() }
        card.frame = CGRect(card.frame.x, card.frame.y, card.frame.width, estHeight())
        val (title, items) = current()
        var y = 6f
        if (title != null) {
            val h = row(title, "chev_left", null, header = true) { path.removeAt(path.size - 1); fill() }
            h.frame = CGRect(6f, y, card.frame.width - 12f, 46f)
            card.addSubview(h)
            y += 46f
        }
        for ((i, it) in items.withIndex()) {
            val r = row(it.title, it.icon, it, header = false) { tap(i) }
            r.frame = CGRect(6f, y, card.frame.width - 12f, 46f)
            card.addSubview(r)
            y += 46f
        }
    }

    private fun tap(i: Int) {
        val (_, items) = current()
        if (i >= items.size) return
        val it = items[i]
        if (it.children != null) { path.add(i); fill(); return }
        it.action?.invoke()
        if (it.checked != null) {
            val r = rebuilt
            if (r != null) { root = r(); fill() }
        } else dismiss()
    }

    private fun row(title: String, icon: String, trailing: PlusItem?, header: Boolean, onTap: () -> Unit): UiView {
        val v = object : TapView() {
            public override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                if (isHighlighted) {
                    fillRoundRect(c, rect, 12f, 0x1AFFFFFF)
                }
                Icons.draw(c, icon, 23f, rect.midY, 22f, if (header) 0xFFB0B0B0.toInt() else 0xFFFFFFFF.toInt())
                drawText(title, 56f, rect.midY + 5.5f, color = 0xFFFFFFFF.toInt(), size = if (header) 15f else 16f,
                         bold = header, align = NSTextAlignment.left)
                if (trailing != null) {
                    val on = trailing.checked
                    if (on != null) {
                        val sw = 40f; val sh = 24f
                        val x0 = rect.width - 12f - sw; val y0 = rect.midY - sh / 2
                        fillRoundRect(c, CGRect(x0, y0, sw, sh), 12f, if (on) accent else 0xFF4D4D4D.toInt())
                        fillCircle(c, if (on) x0 + sw - 12f else x0 + 12f, y0 + sh / 2, 9f, 0xFFFFFFFF.toInt())
                    } else if (trailing.children != null) {
                        Icons.draw(c, "chev_right", rect.width - 21f, rect.midY, 18f, 0xFF909090.toInt())
                    }
                }
            }
        }
        v.onClick = onTap
        return v
    }
}
