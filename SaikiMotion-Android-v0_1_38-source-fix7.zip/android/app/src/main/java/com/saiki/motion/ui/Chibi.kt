@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import android.graphics.BitmapFactory
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.capScrollOf
import kotlin.math.min

// Port of Sources/UI/Chibi.swift — the app mascots.
// chibi_thinking: the empty-projects illustration on the Projects tab.
// chibi_writing: the AI Suggest "in development" illustration on the AI tab.
class ChibiView(val which: Int) : UiView(com.saiki.motion.uikit.appContext!!) {   // 0 thinking, 1 writing
    private var loaded = false
    private var bmp: android.graphics.Bitmap? = null

    init {
        isUserInteractionEnabled = false
    }

    private val resourceName: String
        get() = if (which == 0) "chibi_thinking" else "chibi_writing"

    public override fun layoutSubviews() {
        super.layoutSubviews()
        if (!loaded) {
            loaded = true
            // assets/img first (bundle root twin: Resources/img is copied into assets)
            bmp = try {
                com.saiki.motion.uikit.appContext!!.assets.open("img/$resourceName.png").use { BitmapFactory.decodeStream(it) }
            } catch (_: Exception) { null }
            setNeedsDisplay()
        }
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val b = bmp ?: return
        val p = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
        // aspect-fit inside bounds inset by 6
        val iw = rect.width - 12f; val ih = rect.height - 12f
        if (iw <= 0 || ih <= 0) return
        val s = min(iw / b.width, ih / b.height)
        val dw = b.width * s; val dh = b.height * s
        c.canvas.drawBitmap(b, null, android.graphics.RectF(6f + (iw - dw) / 2, 6f + (ih - dh) / 2,
                                                             6f + (iw + dw) / 2, 6f + (ih + dh) / 2), p)
    }
}
