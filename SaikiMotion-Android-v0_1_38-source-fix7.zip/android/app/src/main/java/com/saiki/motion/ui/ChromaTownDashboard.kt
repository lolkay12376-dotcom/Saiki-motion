@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/ChromaTownDashboard.swift — full-screen ChromaTown dashboard (opened by "Open
// Dashboard…" in the effect panel). Live preview on top, Chroma Style switch, the 32 presets as a
// tappable grid, and every parameter as a slider. Close = revert to how the effect looked on
// opening, Apply = keep. The preset table mirrors Sources/Effects/BuiltinsChromaTown.swift:91-118.

package com.saiki.motion.ui

import com.saiki.motion.core.EffectDef
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.PropDef
import com.saiki.motion.core.Registry
import com.saiki.motion.core.SceneRenderer
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UISegmentedControl
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UISwitch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.uikit.fillRoundRect
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** BuiltinsChromaTown.swift:8 */
val chromaTownStyles = listOf("Chromatic Spectrum", "Start/End Colorize", "Start/End Fill")

/** BuiltinsChromaTown.swift:91 — preset (key → value). Colours: ctSC / ctEC as 0xAARRGGBB. */
class ChromaTownPreset(val name: String, val vals: Map<String, Float>, val sc: Long, val ec: Long)

object ChromaTownPresets {
    val all: List<ChromaTownPreset> by lazy {
        val out = ArrayList<ChromaTownPreset>()
        fun add(n: String, style: Float, v: Map<String, Float>, s: Long, e: Long) {
            val m = HashMap<String, Float>()
            m["ctStyle"] = style
            m.putAll(v)
            out.add(ChromaTownPreset(n, m, s, e))
        }
        val cols = listOf(0xFF8AD2FFL to 0xFFFFC08AL, 0xFFFF2D55L to 0xFF2D5BFFL, 0xFF00E5C8L to 0xFF7B2DFFL, 0xFFFFB300L to 0xFFFF3D00L)
        for ((i, c) in cols.withIndex()) {
            val f = i.toFloat()
            add("Spectrum Zoom ${i + 1}", 0f, mapOf("ctSScale" to 100f, "ctEScale" to 130f + f * 25f, "ctSRot" to 0f, "ctERot" to 0f, "ctSLens" to 0f, "ctELens" to 0f, "ctSBlur" to 10f, "ctEBlur" to 30f + f * 10f), c.first, c.second)
            add("Vortex ${i + 1}", 0f, mapOf("ctSScale" to 100f, "ctEScale" to 100f + f * 8f, "ctSRot" to 0f, "ctERot" to 40f + f * 45f, "ctSLens" to 0f, "ctELens" to 10f, "ctSBlur" to 5f, "ctEBlur" to 25f), c.first, c.second)
            add("Lens Warp ${i + 1}", 0f, mapOf("ctSScale" to 80f, "ctEScale" to 96f, "ctSRot" to 5f, "ctERot" to -2f, "ctSLens" to 11f + f * 6f, "ctELens" to 2f, "ctSBlur" to 21f, "ctEBlur" to 0f), c.first, c.second)
            add("Linear Streak ${i + 1}", 0f, mapOf("ctSX" to 0.35f - f * 0.05f, "ctEX" to 0.65f + f * 0.05f, "ctSY" to 0.5f, "ctEY" to 0.5f, "ctSScale" to 100f, "ctEScale" to 100f, "ctSRot" to 0f, "ctERot" to 0f, "ctSLens" to 0f, "ctELens" to 0f, "ctSBlur" to 0f, "ctEBlur" to 0f), c.first, c.second)
            add("Tint Sweep ${i + 1}", 1f, mapOf("ctSScale" to 90f, "ctEScale" to 105f + f * 6f, "ctSRot" to 0f, "ctERot" to 6f * f, "ctSBlur" to 8f, "ctEBlur" to 18f, "ctFalloff" to 0.2f), c.first, c.second)
            add("Colorize Burst ${i + 1}", 1f, mapOf("ctSScale" to 100f, "ctEScale" to 150f + f * 20f, "ctSBlur" to 15f, "ctEBlur" to 40f, "ctSRot" to 0f, "ctERot" to 0f), c.first, c.second)
            add("Fill Glow ${i + 1}", 2f, mapOf("ctSScale" to 95f, "ctEScale" to 125f + f * 10f, "ctSBlur" to 20f, "ctEBlur" to 50f, "ctFalloff" to 0.6f), c.first, c.second)
            add("Soft Spectrum ${i + 1}", 0f, mapOf("ctSScale" to 96f, "ctEScale" to 100f, "ctSRot" to 2f, "ctERot" to -2f, "ctSBlur" to 4f + f * 3f, "ctEBlur" to 0f, "ctColorful" to 70f + f * 20f, "ctComp" to 0.6f + f * 0.1f), c.first, c.second)
        }
        out
    }
}

class ChromaTownDashboardViewController(private val lay: Layer, private val entry: String, private val onDone: () -> Unit) : UIViewController() {
    private val def: EffectDef? = Registry.get(entry)
    private val snap = HashMap<String, Float>()
    private var savedVideoCb: (() -> Unit)? = null
    private val pv by lazy {
        savedVideoCb = SceneRenderer.onVideoFrame
        PreviewView(appContext!!).apply { quality = 2 }
    }
    private val accent = argbToUIColor(C.GREEN)
    private val sliders = UiView(appContext!!)
    private val styleSeg = UISegmentedControl(chromaTownStyles.map { it.replace("Start/End ", "") })
    private var grid: UiView = UiView(appContext!!)
    private val sliderRefs = HashMap<String, Pair<UISlider, UILabel>>()
    private val switchRefs = HashMap<String, UISwitch>()

    init {
        for ((k, t) in lay.props) if (k.startsWith(entry + "__")) snap[k] = t.base
    }

    private fun key(k: String) = "${entry}__$k"

    private fun valx(k: String): Float {
        val t = lay.props[key(k)]
        if (t != null) return t.eval(lay.editTime(key(k), Editor.time))
        return def?.props?.firstOrNull { it.key == k }?.def ?: 0f
    }

    private fun set(k: String, v: Float) { lay.track(key(k)).base = v }

    private fun setColor(k: String, argb: Long) {
        lay.track(key(k) + "_a").base = ((argb shr 24) and 0xFF).toFloat() / 255f
        lay.track(key(k) + "_r").base = ((argb shr 16) and 0xFF).toFloat() / 255f
        lay.track(key(k) + "_g").base = ((argb shr 8) and 0xFF).toFloat() / 255f
        lay.track(key(k) + "_b").base = (argb and 0xFF).toFloat() / 255f
    }

    private val bar = UiView(appContext!!)
    private val box = UiView(appContext!!)
    private val scroll = UIScrollView(appContext!!)
    private val titleL = UILabel(appContext!!)
    private val closeBtn = PillButton("✕", null, C.CARD2, C.TEXT)
    private val applyBtn = PillButton("Apply", null, C.GREEN, C.BG)

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(0xFF0F0F0F.toInt())
        titleL.text = "uni.ChromaTown Dashboard"; titleL.font = UIFont.semiboldSystemFont(16f); titleL.textColor = UIColor.white
        titleL.textAlignment = NSTextAlignment.center
        closeBtn.onClick = { finish(apply = false) }
        applyBtn.onClick = { finish(apply = true) }
        view.addSubview(bar); view.addSubview(box); view.addSubview(styleSeg); view.addSubview(grid); view.addSubview(scroll)
        bar.addSubview(closeBtn); bar.addSubview(titleL); bar.addSubview(applyBtn)
        box.setBackgroundColor(0xFF000000.toInt())
        box.addSubview(pv)
        styleSeg.selectedSegmentIndex = valx("ctStyle").toInt()
        styleSeg.onValueChanged = {
            set("ctStyle", styleSeg.selectedSegmentIndex.toFloat())
            pv.requestDraw()
        }
        scroll.addSubview(sliders)
        for (pd in def?.props ?: emptyList()) {
            if (pd.options == null) sliders.addSubview(sliderRow(pd))
        }
        for (pd in def?.props ?: emptyList()) {
            if (pd.options != null && pd.key != "ctStyle") sliders.addSubview(switchRow(pd))
        }
        relayout()
        view.onLayout = { _ -> relayout() }
    }

    private fun relayout() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w < 10 || h < 10) return
        bar.frame = CGRect(0f, 0f, w, 52f)
        closeBtn.frame = CGRect(12f, 9f, 92f, 34f)
        applyBtn.frame = CGRect(w - 84f, 9f, 72f, 34f)
        titleL.frame = CGRect(104f, 11f, w - 208f, 30f)
        box.frame = CGRect(0f, 52f, w, h * 0.36f)
        val aspect = max(Editor.project.w, 1).toFloat() / max(Editor.project.h, 1).toFloat()
        var pw = box.rectWidth(); var ph = pw / aspect
        if (ph > box.rectHeight()) { ph = box.rectHeight(); pw = ph * aspect }
        pv.frame = CGRect((box.rectWidth() - pw) / 2, (box.rectHeight() - ph) / 2, pw, ph)
        styleSeg.frame = CGRect(12f, box.frame.maxY + 10f, w - 24f, 32f)
        grid.frame = CGRect(0f, styleSeg.frame.maxY + 10f, w, 84f)
        layoutGrid(w)
        scroll.frame = CGRect(0f, grid.frame.maxY + 10f, w, h - grid.frame.maxY - 10f)
        layoutSliders()
    }

    private fun layoutGrid(w: Float) {
        grid.subviews.toList().forEach { it.removeFromSuperview() }
        val cellW = 96f
        val list = ChromaTownPresets.all
        var x = 12f
        for (p in list) {
            val cell = object : TapView() {
                public override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 10f, 0xFF0D0D0D.toInt())
                    // gradient swatch: dark -> sc -> ec
                    val p0 = android.graphics.Paint()
                    p0.shader = android.graphics.LinearGradient(0f, 0f, rect.width, rect.height,
                        intArrayOf(0xFF0D0D0D.toInt(), (p.sc and 0xFFFFFFFFL).toInt(), (p.ec and 0xFFFFFFFFL).toInt()),
                        null, android.graphics.Shader.TileMode.CLAMP)
                    c.paint.style = android.graphics.Paint.Style.FILL
                    c.canvas.drawRoundRect(android.graphics.RectF(0f, 0f, rect.width, rect.height), 10f, 10f, p0)
                    drawText(p.name, rect.midX, rect.height - 12f, color = C.TEXT, size = 10f, bold = true,
                        align = NSTextAlignment.center)
                }
            }
            cell.setBackgroundColor(0x00000000)
            cell.onClick = { applyPreset(p) }
            cell.frame = CGRect(x, 0f, cellW, 84f)
            cell.clipsToBounds = true
            grid.addSubview(cell)
            x += cellW + 8f
        }
        grid.frame = CGRect(grid.frame.x, grid.frame.y, max(x, grid.rectWidth()), 84f)
    }

    private fun layoutSliders() {
        var y = 0f
        for (v in sliders.subviews) {
            val vh = if (v.subviews.size == 2 && v.subviews[1] is UISwitch) 32f else 64f
            v.frame = CGRect(16f, y, max(scroll.rectWidth() - 32f, 10f), vh)
            v.onLayout?.invoke(max(scroll.rectWidth() - 32f, 10f))
            y += vh + 6f
        }
        sliders.frame = CGRect(0f, 0f, scroll.rectWidth(), y + 16f)
        scroll.contentSize = CGSize(scroll.rectWidth(), y + 16f)
    }

    override fun viewDidAppear(a: Boolean) {
        super.viewDidAppear(a)
        pv.requestDraw()
        android.os.Handler(android.os.Looper.getMainLooper()).post { pv.requestDraw() }
    }

    private fun sliderRow(pd: PropDef): UiView {
        val name = UILabel(appContext!!)
        name.text = pd.label; name.textColor = UIColor.white; name.font = UIFont.systemFont(13f)
        val num = UILabel(appContext!!)
        num.textColor = accent; num.font = UIFont.monospacedDigitSystemFont(13f); num.textAlignment = NSTextAlignment.right
        val s = UISlider(appContext!!)
        s.minValue = pd.min; s.maxValue = pd.max; s.value = valx(pd.key)
        fun fmt(v: Float): String = String.format(Locale.US, "%.${pd.dec}f", v)
        num.text = fmt(s.value)
        s.onValueChanged = {
            set(pd.key, s.value)
            num.text = fmt(s.value)
            pv.requestDraw()
        }
        sliderRefs[pd.key] = Pair(s, num)
        val col = UiView(appContext!!)
        col.addSubview(name); col.addSubview(num); col.addSubview(s)
        col.onLayout = { w ->
            name.frame = CGRect(0f, 0f, w * 0.6f, 20f)
            num.frame = CGRect(w - 64f, 0f, 64f, 20f)
            s.frame = CGRect(0f, 24f, w, 34f)
        }
        return col
    }

    private fun switchRow(pd: PropDef): UiView {
        val name = UILabel(appContext!!)
        name.text = pd.label; name.textColor = UIColor.white; name.font = UIFont.systemFont(13f)
        val sw = UISwitch(appContext!!)
        sw.isOn = valx(pd.key) >= 0.5f
        sw.onValueChanged = { set(pd.key, if (sw.isOn) 1f else 0f); pv.requestDraw() }
        sliderRefs.remove(pd.key)
        switchRefs[pd.key] = sw
        val r = UiView(appContext!!)
        r.addSubview(name); r.addSubview(sw)
        r.onLayout = { w -> name.frame = CGRect(0f, 6f, w - 60f, 20f); sw.frame = CGRect(w - 54f, 0f, 50f, 32f) }
        return r
    }

    private fun applyPreset(p: ChromaTownPreset) {
        // reset every param to default, then lay the preset over it
        for (pd in def?.props ?: emptyList()) set(pd.key, pd.def)
        for ((k, v) in p.vals) set(k, v)
        setColor("ctSC", p.sc); setColor("ctEC", p.ec)
        for ((k, r) in sliderRefs) {
            val v = valx(k)
            r.first.value = v
            val dec = def?.props?.firstOrNull { it.key == k }?.dec ?: 2
            r.second.text = String.format(Locale.US, "%.${dec}f", v)
        }
        for ((k, sw) in switchRefs) sw.isOn = valx(k) >= 0.5f
        styleSeg.selectedSegmentIndex = valx("ctStyle").toInt()
        pv.requestDraw()
    }

    private fun finish(apply: Boolean) {
        if (!apply) {
            for (k in lay.props.keys.toList()) {
                if (!k.startsWith(entry + "__")) continue
                val b = snap[k]
                if (b != null) lay.props[k]?.base = b else lay.props.remove(k)
            }
        }
        SceneRenderer.onVideoFrame = savedVideoCb
        val done = onDone
        dismiss(animated = true) { done() }
    }
}
