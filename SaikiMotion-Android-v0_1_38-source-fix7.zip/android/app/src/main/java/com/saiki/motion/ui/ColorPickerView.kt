@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import android.graphics.Color
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.UIControl
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.argbToUIColor
import kotlin.math.min

// Port of Sources/UI/ColorPickerView.swift — the HSV color picker square + hue/opacity bars.
// Gradients use LinearGradient/ComposeShader over the same rounded-rect clips.
class ColorPickerView : UIControl(com.saiki.motion.uikit.appContext!!) {
    var onChange: ((Int) -> Unit)? = null
    private var hue = 0f
    private var sat = 1f
    private var bri = 1f
    // PORT NOTE: Kotlin private `alpha` renamed (View.alpha collision).
    private var alphaVal = 1f
    private var drag = 0
    private val barH: CGFloat = 28f
    private val gap: CGFloat = 12f

    fun setColor(c: Int) {
        val hsvn = argbToHSV(c)
        hue = hsvn[0]; sat = hsvn[1]; bri = hsvn[2]
        alphaVal = colorAlpha(c) / 255f
        setNeedsDisplay()
    }

    fun color(): Int = hsvToARGB(hue, sat, bri, (alphaVal * 255).toInt())

    private fun sqH(): CGFloat = boundsRect.height - 2 * (barH + gap)

    companion object {
        fun hsvToARGB(h: Float, s: Float, v: Float, a: Int = 255): Int {
            val c = Color.HSVToColor(floatArrayOf(h % 360f, s, v))
            return (a shl 24) or (c and 0xFFFFFF)
        }

        fun argbToHSV(c: Int): FloatArray {
            val hsv = FloatArray(3)
            Color.RGBToHSV((c shr 16) and 0xFF, (c shr 8) and 0xFF, c and 0xFF, hsv)
            return floatArrayOf(hsv[0], hsv[1], hsv[2])
        }

        fun colorAlpha(c: Int): Int = (c ushr 24) and 0xFF
    }

    private fun marker(c: CGContext, x: CGFloat, y: CGFloat) {
        strokeCircle(c, x, y, 9f, 3f, 0xFFFFFFFF.toInt())
        strokeCircle(c, x, y, 10.5f, 1.2f, 0xFF000000.toInt())
    }

    /** Rounded-rect clipped horizontal/vertical multi-stop gradient (CGGradient twin). */
    private fun gradientRoundRect(c: CGContext, r: CGRect, radius: CGFloat, colors: IntArray, vertical: Boolean) {
        c.saveGState()
        c.addPath(com.saiki.motion.uikit.CGPath.roundedRect(r, radius, radius))
        c.clipPath()
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        val shader = if (colors.size == 2) {
            android.graphics.LinearGradient(
                if (vertical) 0f else r.x, if (vertical) r.y else 0f,
                if (vertical) 0f else r.x + r.width, if (vertical) r.y + r.height else 0f,
                colors[0], colors[1], android.graphics.Shader.TileMode.CLAMP)
        } else {
            android.graphics.LinearGradient(
                if (vertical) 0f else r.x, if (vertical) r.y else 0f,
                if (vertical) 0f else r.x + r.width, if (vertical) r.y + r.height else 0f,
                colors, null, android.graphics.Shader.TileMode.CLAMP)
        }
        p.shader = shader
        c.canvas.drawRect(r.x, r.y, r.x + r.width, r.y + r.height, p)
        c.restoreGState()
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width
        val sh = sqH()
        val sq = CGRect(0f, 0f, w, sh)
        // white → hue (horizontal)
        gradientRoundRect(c, sq, 10f, intArrayOf(0xFFFFFFFF.toInt(), hsvToARGB(hue, 1f, 1f) or 0xFF000000.toInt()), vertical = false)
        // transparent black → black (vertical)
        gradientRoundRect(c, sq, 10f, intArrayOf(0x00000000, 0xFF000000.toInt()), vertical = true)
        marker(c, sat * w, (1 - bri) * sh)
        // hue bar
        val hy = sh + gap
        val bar = CGRect(0f, hy, w, barH)
        val cols = IntArray(7) { hsvToARGB(it * 60f, 1f, 1f) or 0xFF000000.toInt() }
        gradientRoundRect(c, bar, barH / 2, cols, vertical = false)
        marker(c, hue / 360f * w, hy + barH / 2)
        // opacity bar
        val ay = hy + barH + gap
        val abar = CGRect(0f, ay, w, barH)
        fillRoundRect(c, abar, barH / 2, 0xFF666666.toInt())
        val base = hsvToARGB(hue, sat, bri)
        gradientRoundRect(c, abar, barH / 2,
            intArrayOf(base and 0x00FFFFFF, base or 0xFF000000.toInt()), vertical = false)
        marker(c, alphaVal * w, ay + barH / 2)
    }

    private fun apply(pt: CGPoint) {
        val w = boundsRect.width
        val sh = sqH()
        val pxv = (pt.x / w).coerceIn(0f, 1f)
        if (drag == 1) {
            sat = pxv
            bri = 1 - (pt.y / sh).coerceIn(0f, 1f)
        } else if (drag == 2) {
            hue = pxv * 359.9f
        } else {
            alphaVal = pxv
        }
        setNeedsDisplay()
        onChange?.invoke(color())
    }

    override fun touchesBegan(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val pt = t.location(this)
        val sh = sqH()
        disallowParentScrollInterception(this, true)
        drag = if (pt.y < sh) 1 else (if (pt.y < sh + gap + barH + gap / 2) 2 else 3)
        apply(pt)
    }

    override fun touchesMoved(touches: Set<UITouch>, event: UIEvent?) {
        if (drag == 0) return
        val t = touches.firstOrNull() ?: return
        apply(t.location(this))
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(this, false)
    }

    override fun touchesCancelled(touches: Set<UITouch>, event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(this, false)
    }
}
