@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/CrashBrowser.swift — Settings > Crash: browse, copy and export crash logs and
// effect crash logs (UI). + Sources/UI/PhysicsScreen.swift (full-screen pendulum editor).

package com.saiki.motion.ui

import com.saiki.motion.app.Dlg
import com.saiki.motion.core.CrashLog
import com.saiki.motion.core.EffectCrashLog
import com.saiki.motion.core.EffectThumbs
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.Rig
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UITableViewController
import com.saiki.motion.uikit.UITableView
import com.saiki.motion.uikit.UITableViewCell
import com.saiki.motion.uikit.UITableViewDataSource
import com.saiki.motion.uikit.UITableViewDelegate
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// MARK: - CrashBrowser

private fun mbt(t: String?): Float = com.saiki.motion.uikit.measureText(t ?: "", 15f, true)

class CrashBrowserViewController(private val dir: File?) : UITableViewController(), UITableViewDataSource, UITableViewDelegate {
    private var items: MutableList<Item> = ArrayList()
    /** UIBarButtonItem.title is a val in this shim; swap the item to change its label. */
    var navRightTitle: String = "Export thumbnails"
        set(v) {
            field = v
            val old = navigationItem?.rightBarButtonItem
            if (old != null) navigationItem?.rightBarButtonItem = com.saiki.motion.uikit.UIBarButtonItem(v, 0, null)
        }
    var navBusy = false

    class Item(val title: String, val sub: String, val url: File, val isDir: Boolean)

    init {
        this.title = when {
            dir == null -> "Crash"
            dir.name == "EffectCrashLogs" -> "Effect crash logs"
            else -> dir.name
        }
    }

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        if (dir == null) {
            navigationItem?.leftBarButtonItem = com.saiki.motion.uikit.UIBarButtonItem("Close", 0) { close() }
            navigationItem?.rightBarButtonItem = com.saiki.motion.uikit.UIBarButtonItem("Export thumbnails", 0) { exportThumbs() }
        } else if (dir.parentFile?.name == "EffectCrashLogs") {
            val id = dir.name
            val on = EffectCrashLog.isBroken(id)
            navigationItem?.rightBarButtonItem = com.saiki.motion.uikit.UIBarButtonItem(if (on) "Re-enable" else "Disable", 0) { toggleBroken() }
        }
        reload()
        view.onLayout = { _ ->
            tableView.frame = CGRect(0f, 0f, view.rectWidth(), view.rectHeight())
            tableView.reloadData()
        }
    }

    private fun close() { dismiss(animated = true) }

    private fun exportThumbs() {
        navBusy = true
        navRightTitle = "Rendering…"
        EffectThumbs.exportBaked { folder, n ->
            navRightTitle = "Export thumbnails"
            val msg = if (folder == null) "Nothing was exported."
            else "$n effects saved to Files > SaikiMotion > ThumbExport. Copy all files into Resources/thumbs in the project and rebuild."
            Dlg(this).setTitle("Thumbnails").setMessage(msg).setPositiveButton("OK", null).show()
        }
    }

    private fun toggleBroken() {
        val id = dir!!.name
        EffectCrashLog.setBroken(id, !EffectCrashLog.isBroken(id))
        navRightTitle = if (EffectCrashLog.isBroken(id)) "Re-enable" else "Disable"
        reload()
    }

    private fun reload() {
        items = ArrayList()
        if (dir == null) {
            val c = CrashLog.crashDir(); val e = EffectCrashLog.rootDir()
            c.mkdirs(); e.mkdirs()
            items.add(Item("Crash logs", "${CrashLog.reportCount()} reports", c, true))
            items.add(Item("Effect crash logs", "${EffectCrashLog.count()} effects with problems", e, true))
        } else {
            val isEffectRoot = dir.name == "EffectCrashLogs"
            val list = dir.listFiles()?.filter { !it.name.startsWith(".") } ?: emptyList()
            val df = SimpleDateFormat("MMM d, yyyy, h:mm a", Locale.US)
            for (u in list) {
                val isD = u.isDirectory
                var sub = if (isD) "" else df.format(Date(u.lastModified()))
                if (isD && isEffectRoot) {
                    val n = u.listFiles()?.size ?: 0
                    sub = "$n log${if (n == 1) "" else "s"}" + (if (EffectCrashLog.isBroken(u.name)) "  •  switched off" else "")
                }
                items.add(Item(u.name, sub, u, isD))
            }
            items.sortByDescending { it.title }
        }
        tableView.reloadData()
    }

    override fun numberOfRows(t: UITableView, section: Int): Int = maxOf(items.size, 1)

    override fun cellForRow(t: UITableView, row: Int): UITableViewCell {
        val c = UITableViewCell(appContext!!)
        c.setBackgroundColor(C.CARD)
        c.textLabel?.textColor = argbToUIColor(C.TEXT)
        if (items.isEmpty()) {
            c.textLabel?.text = "Nothing here — no crashes or freezes recorded."
            c.selectionStyle = 0
            return c
        }
        val it = items[row]
        c.textLabel?.text = it.title
        c.detailTextLabel?.text = it.sub
        return c
    }

    override fun didSelectRow(t: UITableView, row: Int) {
        if (row >= items.size) return
        val it = items[row]
        val next = if (it.isDir) CrashBrowserViewController(it.url) else LogViewController(it.url)
        val nav = navigationController
        if (nav != null) nav.pushViewController(next, animated = true) else present(next, animated = true)
    }

    fun deleteRow(row: Int) {
        if (row >= items.size || dir == null) return
        items[row].url.deleteRecursively()
        reload()
    }
}

class LogViewController(private val url: File) : UIViewController() {
    private val tv = UILabel(appContext!!)
    private var text = ""
    var navRightTitle: String = "Copy"
        set(v) {
            field = v
            val old = navigationItem?.rightBarButtonItem
            if (old != null) navigationItem?.rightBarButtonItem = com.saiki.motion.uikit.UIBarButtonItem(v, 0, null)
        }

    init { title = url.name }

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        tv.font = com.saiki.motion.uikit.UIFont.monospacedFont(12f)
        tv.textColor = argbToUIColor(C.TEXT)
        text = try { url.readText() } catch (_: Exception) { "(could not read this file)" }
        tv.text = text
        tv.numberOfLines = 0
        val scroll = UIScrollView(appContext!!)
        scroll.addSubview(tv)
        view.addSubview(scroll)
        navigationItem?.rightBarButtonItem = com.saiki.motion.uikit.UIBarButtonItem("Copy", 0) { copyIt() }
        view.onLayout = { _ ->
            val w = view.rectWidth(); val h = view.rectHeight()
            if (w >= 10 && h >= 10) {
                scroll.frame = CGRect(0f, 0f, w, h)
                tv.frame = CGRect(8f, 8f, w - 16f, 20000f)
                scroll.contentSize = com.saiki.motion.uikit.CGSize(w, 20008f)
            }
        }
    }

    private fun copyIt() {
        val cm = appContext!!.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("log", text))
        navRightTitle = "Copied"
    }
}

// MARK: - PhysicsScreen (full-screen pendulum editor)

/// Draws the pendulum chain live from the real simulation.
private class ChainPreview(context: android.content.Context) : UiView(context) {
    var group: Layer? = null
    var rig: Rig? = null
    var pg: com.saiki.motion.core.PhysGroup? = null
    private var link: com.saiki.motion.uikit.CADisplayLink? = null

    fun start() {
        link?.invalidate()
        val l = com.saiki.motion.uikit.CADisplayLink(this, "tick")
        l.add(Any(), Any())
        link = l
    }

    fun stop() { link?.invalidate(); link = null }

    @Suppress("unused") fun tick() { Rig.liveActive = true; setNeedsDisplay() }

    public override fun draw(rect: CGRect) {
        val ctx = UIGraphics.getCurrentContext() ?: return
        val g = group ?: return; val r = rig ?: return; val pg = pg ?: return
        pg.angles(g, r, Editor.time)
        val a = pg.lastRaw
        var p = CGPoint(boundsRect.midX, 24f)
        var ang = 0f
        val seg = min(70f, (rectHeight() - 40f) / a.size)
        ctx.setStrokeColor(C.GREEN); ctx.setLineWidth(3f)
        ctx.setFillColor(C.TEXT)
        ctx.fillEllipse(CGRect(p.x - 5, p.y - 5, 10f, 10f))
        for (v in a) {
            ang += v
            val q = CGPoint(p.x + sin(ang) * seg, p.y + cos(ang) * seg)
            ctx.beginPath(); ctx.move(p); ctx.addLine(q); ctx.strokePath()
            ctx.fillEllipse(CGRect(q.x - 6, q.y - 6, 12f, 12f))
            p = q
        }
    }
}

class PhysicsScreenViewController(private val group: Layer, private val rig: Rig, private val pg: com.saiki.motion.core.PhysGroup) : UIViewController() {
    var pushUndo: () -> Unit = {}
    var onChange: () -> Unit = {}
    private val preview = ChainPreview(appContext!!)
    private val stack = UiView(appContext!!)
    private val scroll = UIScrollView(appContext!!)

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        val title = UILabel(appContext!!)
        title.text = "Physics — ${pg.name}"; title.textColor = argbToUIColor(C.TEXT); title.font = UIFont.boldSystemFont(18f)
        val close = bar("Done") { dismiss(animated = true) { onChange() } }
        val add = bar("＋ Pendulum") {
            pushUndo(); pg.pends.add(com.saiki.motion.core.PhysPend()); rebuild(); onChange()
        }
        val top = UiView(appContext!!)
        top.addSubview(title); top.addSubview(add); top.addSubview(close)
        preview.group = group; preview.rig = rig; preview.pg = pg
        view.addSubview(top); view.addSubview(preview); view.addSubview(scroll)
        scroll.addSubview(stack)
        rebuild()
        view.onLayout = { _ -> relayout() }
        relayout()
    }

    private fun relayout() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w < 10 || h < 10) return
        val top = view.safeAreaInsets.top
        val topBox = view.subviews[0]
        topBox.frame = CGRect(16f, top + 8f, w - 32f, 40f)
        (topBox.subviews[0] as? UILabel)?.let { it.frame = CGRect(0f, 9f, w - 32f - 220f, 22f) }
        var bx = topBox.rectWidth()
        for (i in 1 until topBox.subviews.size) {
            val b = topBox.subviews[i]
            val bw = mbt((b as PillButton).text) + 26f
            b.frame = CGRect(bx - bw, 4f, bw, 32f); bx -= bw + 10f
        }
        preview.frame = CGRect(16f, topBox.frame.maxY + 10f, w - 32f, (h - top - 50f) * 0.3f)
        scroll.frame = CGRect(16f, preview.frame.maxY + 10f, w - 32f, h - preview.frame.maxY - 20f)
        layoutStack()
    }

    private fun layoutStack() {
        var y = 0f
        for (v in stack.subviews) {
            val vh = v.rectHeight().takeIf { it > 0f } ?: 120f
            v.frame = CGRect(0f, y, kotlin.math.max(scroll.rectWidth(), 10f), vh)
            v.onLayout?.invoke(kotlin.math.max(scroll.rectWidth(), 10f))
            y += vh + 12f
        }
        stack.frame = CGRect(0f, 0f, scroll.rectWidth(), y + 24f)
        scroll.contentSize = com.saiki.motion.uikit.CGSize(scroll.rectWidth(), y + 24f)
    }

    override fun viewDidAppear(a: Boolean) { super.viewDidAppear(a); preview.start() }
    override fun viewWillDisappear(a: Boolean) { super.viewWillDisappear(a); preview.stop() }

    private fun bar(t: String, act: () -> Unit): PillButton {
        val b = PillButton(t, null, C.GREEN, C.BG)
        b.textSize = 15f
        b.onClick = { act() }
        return b
    }

    private fun slider(name: String, lo: Float, hi: Float, v: Float, set: (Float) -> Unit): UiView {
        val l = UILabel(appContext!!)
        l.textColor = argbToUIColor(C.TEXT); l.font = UIFont.systemFont(13f)
        fun txt(x: Float) { l.text = "$name: ${String.format(Locale.US, "%.2f", x)}" }
        txt(v)
        val s = UISlider(appContext!!)
        s.minValue = lo; s.maxValue = hi; s.value = v
        s.onValueChanged = { set(s.value); txt(s.value); Rig.liveActive = true; onChange() }
        val st = UiView(appContext!!)
        st.addSubview(l); st.addSubview(s)
        st.onLayout = { w -> l.frame = CGRect(0f, 0f, w, 20f); s.frame = CGRect(0f, 22f, w, 34f) }
        return st
    }

    private fun card(title: String, rows: List<UiView>): UiView {
        val t = UILabel(appContext!!)
        t.text = title; t.textColor = argbToUIColor(C.GREEN); t.font = UIFont.boldSystemFont(15f)
        val st = UiView(appContext!!)
        st.addSubview(t)
        for (r in rows) st.addSubview(r)
        val c = UiView(appContext!!)
        c.setBackgroundColor(C.CARD2)
        c.addSubview(st)
        st.onLayout = { w ->
            var y = 12f
            for (v in st.subviews) {
                val vh = if (v is UILabel) 22f else (v.rectHeight().takeIf { it > 0f } ?: 58f)
                v.frame = CGRect(12f, y, w - 24f, vh)
                v.onLayout?.invoke(w - 24f)
                y += vh + 10f
            }
            st.frame = CGRect(0f, 0f, w, y)
            c.frame = CGRect(c.frame.x, c.frame.y, w, y)
        }
        c.frame = CGRect(0f, 0f, 100f, 120f)
        return c
    }

    private fun rebuild() {
        stack.subviews.toList().forEach { it.removeFromSuperview() }
        val q = pg
        stack.addSubview(card("Pendulum 1", listOf(
            slider("Duration (short = snappy)", 0.1f, 2f, q.length) { q.length = it },
            slider("Reaction", 0f, 1f, q.reaction) { q.reaction = it },
            slider("Damping", 0f, 1f, q.damping) { q.damping = it })))
        for ((i, pd) in q.pends.withIndex()) {
            val del = PillButton("Delete pendulum ${i + 2}", null, 0x00000000.toInt(), C.TEXT)
            del.textSize = 15f
            del.onClick = {
                pushUndo(); q.pends.removeAt(i)
                for (o in q.outs) {
                    if (o.pend == i + 1) o.pend = 0
                    else if (o.pend > i + 1) o.pend -= 1
                }
                rebuild(); onChange()
            }
            stack.addSubview(card("Pendulum ${i + 2} — hangs from ${i + 1}", listOf(
                slider("Duration", 0.1f, 2f, pd.length) { pd.length = it },
                slider("Reaction", 0f, 1f, pd.reaction) { pd.reaction = it },
                slider("Damping", 0f, 1f, pd.damping) { pd.damping = it },
                del)))
        }
        stack.addSubview(card("Augmented physics (whole chain)", listOf(
            slider("Tilt follow (0 = inertia only)", 0f, 1f, q.follow) { q.follow = it },
            slider("Inertia (input gain)", 0f, 4f, q.strength) { q.strength = it },
            slider("Ease of swinging", 0.5f, 0.99f, q.ease) { q.ease = it },
            slider("Gravity (pull to rest)", 0.1f, 3f, q.gravity) { q.gravity = it },
            slider("Max angle (°)", 5f, 90f, q.maxDeg) { q.maxDeg = it },
            slider("Input delay (s)", 0f, 0.5f, q.delay) { q.delay = it })))
        layoutStack()
    }
}
