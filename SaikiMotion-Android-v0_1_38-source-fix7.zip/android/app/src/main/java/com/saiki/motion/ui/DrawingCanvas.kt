@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import com.saiki.motion.core.DrawItem
import com.saiki.motion.core.DrawLayerMeta
import com.saiki.motion.core.DrawStore
import com.saiki.motion.core.Paths
import com.saiki.motion.core.ProjectIO
import com.saiki.motion.core.Project
import com.saiki.motion.core.Projects
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.Scene
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UIGestureRecognizerState
import com.saiki.motion.uikit.UIPanGestureRecognizer
import com.saiki.motion.uikit.UIPinchGestureRecognizer
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import org.json.JSONObject
import java.io.File
import java.util.Timer
import java.util.TimerTask
import java.util.UUID
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// Port of Sources/Tools/DrawingCanvas.swift — bitmap layers, brush / eraser / smudge engine,
// undo and the canvas view.
//
// Every layer is a premultiplied-RGBA IntArray buffer the size of the canvas. A stroke is
// accumulated in an 8-bit coverage covMask and composited from a snapshot at the stroke
// opacity, so overlapping dabs never stack (the same behaviour as Ibis Paint's opacity slider).

enum class DrawTool { brush, eraser, smudge, eyedropper, transform, wand }

/** Customisable brush tip / stroke behaviour (shared by brush and eraser). */
class BrushStyle(
    var name: String = "Pen",
    var hardness: Float = 0.78f,      // 0 = fully soft edge, 1 = hard edge
    var spacing: Float = 0.12f,       // dab distance as a fraction of the radius
    var scatter: Float = 0f,          // random dab offset (fraction of radius)
    var grain: Float = 0f,            // paper / chalk texture strength
    var sizeJitter: Float = 0f,       // random dab size reduction
    var pressureSize: Float = 1f,     // how much pen pressure changes the size
    var square: Boolean = false,      // square tip
    var pressureOpacity: Float = 0f,  // how much pen pressure changes the opacity
    var tipStart: Float = 0f,         // taper-in length at the start of a stroke (0 = none)
    var tipEnd: Float = 0f            // taper-out length at the end of a stroke (0 = none)
) {
    fun copy(): BrushStyle = BrushStyle(name, hardness, spacing, scatter, grain, sizeJitter, pressureSize, square, pressureOpacity, tipStart, tipEnd)

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("name", name); o.put("hardness", hardness.toDouble()); o.put("spacing", spacing.toDouble())
        o.put("scatter", scatter.toDouble()); o.put("grain", grain.toDouble()); o.put("sizeJitter", sizeJitter.toDouble())
        o.put("pressureSize", pressureSize.toDouble()); o.put("square", square)
        o.put("pressureOpacity", pressureOpacity.toDouble()); o.put("tipStart", tipStart.toDouble()); o.put("tipEnd", tipEnd.toDouble())
        return o
    }
    companion object {
        val presets: List<BrushStyle> = listOf(
            BrushStyle(),
            BrushStyle("G-Pen", 0.92f, 0.06f, pressureSize = 1f, tipStart = 0.3f, tipEnd = 0.5f),
            BrushStyle("Pencil", 0.55f, 0.1f, grain = 0.55f, pressureOpacity = 0.7f),
            BrushStyle("Marker", 0.92f, 0.08f, pressureSize = 0f, square = true),
            BrushStyle("Airbrush", 0f, 0.08f, pressureSize = 0.3f, pressureOpacity = 0.85f),
            BrushStyle("Chalk", 0.6f, 0.3f, scatter = 0.25f, grain = 0.85f, sizeJitter = 0.25f),
            BrushStyle("Watercolor", 0.12f, 0.1f, grain = 0.2f, pressureSize = 0.4f, pressureOpacity = 0.9f))
        /** Eraser tips: soft edges + pressure opacity, so erasing fades instead of cutting in one go (like Ibis Paint). */
        val eraserPresets: List<BrushStyle> = listOf(
            BrushStyle("Soft", 0.3f, 0.1f, pressureSize = 0.7f, pressureOpacity = 0.8f),
            BrushStyle("Hard", 0.95f, 0.08f, pressureSize = 0.5f),
            BrushStyle("Pencil", 0.5f, 0.1f, grain = 0.5f, pressureSize = 0.6f, pressureOpacity = 0.7f),
            BrushStyle("Tapered", 0.85f, 0.06f, pressureSize = 1f, tipStart = 0.3f, tipEnd = 0.5f))
        fun fromJson(o: JSONObject): BrushStyle = BrushStyle(
            name = o.optString("name", "Pen"),
            hardness = o.optDouble("hardness", 0.78).toFloat(),
            spacing = o.optDouble("spacing", 0.12).toFloat(),
            scatter = o.optDouble("scatter", 0.0).toFloat(),
            grain = o.optDouble("grain", 0.0).toFloat(),
            sizeJitter = o.optDouble("sizeJitter", 0.0).toFloat(),
            pressureSize = o.optDouble("pressureSize", 1.0).toFloat(),
            square = o.optBoolean("square", false),
            pressureOpacity = o.optDouble("pressureOpacity", 0.0).toFloat(),
            tipStart = o.optDouble("tipStart", 0.0).toFloat(),
            tipEnd = o.optDouble("tipEnd", 0.0).toFloat())
    }
}

object Checker {
    /** Checker fill for the transparent-canvas background (DrawingCanvas.swift Checker.fill). */
    fun fill(c: com.saiki.motion.uikit.CGContext, r: RectF, cell: Float) {
        val p = Paint()
        p.color = 0xFF4D4D4D.toInt()
        c.canvas.drawRect(r, p)
        p.color = 0xFF6B6B6B.toInt()
        var y = 0
        var yy = r.top
        while (yy < r.bottom) {
            var x = 0
            var xx = r.left
            while (xx < r.right) {
                if ((x + y) and 1 == 0) {
                    val cellR = RectF(xx, yy, min(xx + cell, r.right), min(yy + cell, r.bottom))
                    c.canvas.drawRect(cellR, p)
                }
                xx += cell; x += 1
            }
            yy += cell; y += 1
        }
    }
}

// MARK: - Layer bitmap ------------------------------------------------------------------

class PixLayer(val meta: DrawLayerMeta, val w: Int, val h: Int, val sourceFile: File? = null) {
    var dirty = false
    private var buf: IntArray? = null

    companion object { var loadedBytes = 0L }

    val isLoaded: Boolean get() = buf != null

    /** Pixels (premultiplied ARGB Ints). Loaded from disk on first use. */
    val px: IntArray
        get() { load(); return buf!! }

    private fun load() {
        if (buf != null) return
        if (meta.isFolder) { buf = IntArray(1); return }
        val n = w * h
        buf = IntArray(n)
        loadedBytes += n * 4L
        val u = sourceFile
        if (u != null && u.exists()) loadPNG(u)
    }

    /** Frees the pixels of a layer whose PNG on disk is up to date. */
    fun unload() { if (!dirty && !meta.isFolder) release() }

    private fun release() {
        if (buf == null) return
        if (!meta.isFolder) loadedBytes -= w * h * 4L
        buf = null
    }

    private fun loadPNG(url: File) {
        try {
            val b = BitmapFactory.decodeFile(url.path) ?: return
            val scaled = if (b.width == w && b.height == h) b else {
                val o = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val c = Canvas(o)
                val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                c.drawBitmap(b, null, RectF(0f, 0f, w.toFloat(), h.toFloat()), p)
                o
            }
            scaled.getPixels(buf!!, 0, w, 0, 0, w, h)
        } catch (_: Exception) {}
    }

    fun toBitmap(): Bitmap {
        load()
        return Bitmap.createBitmap(buf!!, w, h, Bitmap.Config.ARGB_8888)
    }

    fun pngData(): ByteArray? = try {
        val out = java.io.ByteArrayOutputStream()
        toBitmap().compress(Bitmap.CompressFormat.PNG, 100, out)
        out.toByteArray()
    } catch (_: Exception) { null }

    fun clear() { load(); java.util.Arrays.fill(px, 0); dirty = true }
}

// MARK: - Document ----------------------------------------------------------------------

class DrawDoc(val item: DrawItem) {
    var layers = ArrayList<PixLayer>()     // index 0 = bottom
    var activeId: String? = null
    val w: Int get() = item.w
    val h: Int get() = item.h

    val selLayer: PixLayer by lazy { PixLayer(DrawLayerMeta(id = "__sel__", name = "Selection Layer"), item.w, item.h) }
    var selHas = false

    init {
        for (m in item.layers) {
            layers.add(PixLayer(m, item.w, item.h, if (m.isFolder) null else DrawStore.layerFile(item.id, m.id)))
        }
        activeId = item.activeLayer ?: layers.lastOrNull { !it.meta.isFolder }?.meta?.id
        if (layers.isEmpty()) addLayer(name = "Layer 1")
        if (active == null) activeId = layers.lastOrNull { !it.meta.isFolder }?.meta?.id
    }

    fun recomputeSel() {
        if (!selLayer.isLoaded) { selHas = false; return }
        val p = selLayer.px
        for (v in p) if ((v ushr 24) != 0) { selHas = true; return }
        selHas = false
    }

    val active: PixLayer? get() = layers.firstOrNull { it.meta.id == activeId && !it.meta.isFolder }
    val activeIndex: Int get() = layers.indexOfFirst { it.meta.id == activeId }

    fun layer(id: String): PixLayer? = layers.firstOrNull { it.meta.id == id }
    fun parentChain(l: PixLayer): List<PixLayer> {
        val out = ArrayList<PixLayer>()
        var p = l.meta.parent
        while (p != null) { val f = layer(p) ?: break; out.add(f); p = f.meta.parent }
        return out
    }
    fun shown(l: PixLayer): Boolean = l.meta.visible && parentChain(l).all { it.meta.visible }
    fun alpha(l: PixLayer): Float {
        var a = l.meta.opacity
        for (f in parentChain(l)) a *= f.meta.opacity
        return a
    }

    fun addLayer(name: String? = null, folder: Boolean = false): PixLayer {
        val count = layers.count { it.meta.isFolder == folder } + 1
        val m = DrawLayerMeta(id = UUID.randomUUID().toString(), name = name ?: (if (folder) "Folder $count" else "Layer $count"))
        m.isFolder = folder
        val a = layers.firstOrNull { it.meta.id == activeId }
        if (a != null) m.parent = if (a.meta.isFolder) a.meta.id else a.meta.parent
        val l = PixLayer(m, w, h, null)
        l.dirty = !folder
        var at = layers.size
        val ai = layers.indexOfFirst { it.meta.id == activeId }
        if (ai >= 0) at = ai + 1
        layers.add(min(at, layers.size), l)
        if (folder) { val act = active; if (act != null && act.meta.parent == m.parent) act.meta.parent = m.id }
        if (!folder) activeId = m.id
        return l
    }

    fun duplicate(l: PixLayer) {
        if (l.meta.isFolder) return
        val i = layers.indexOfFirst { it === l }
        if (i < 0) return
        val m = l.meta
        val nm = DrawLayerMeta(id = UUID.randomUUID().toString(), name = m.name + " copy", visible = m.visible,
            opacity = m.opacity, isFolder = false, parent = m.parent, expanded = m.expanded)
        val c = PixLayer(nm, w, h, null)
        System.arraycopy(l.px, 0, c.px, 0, w * h)
        c.dirty = true
        layers.add(i + 1, c)
        activeId = nm.id
    }

    fun remove(l: PixLayer) {
        val id = l.meta.id
        for (c in layers) if (c.meta.parent == id) c.meta.parent = l.meta.parent
        layers.removeAll { it === l }
        DrawStore.layerFile(item.id, id).delete()
        if (layers.none { !it.meta.isFolder }) addLayer(name = "Layer 1")
        if (active == null) activeId = layers.lastOrNull { !it.meta.isFolder }?.meta?.id
    }

    fun mergeDown(l: PixLayer): Boolean {
        if (l.meta.isFolder) return false
        val i = layers.indexOfFirst { it === l }
        if (i < 0) return false
        val below = layers.subList(0, i).lastOrNull { !it.meta.isFolder } ?: return false
        val src = l.toBitmap()
        val dst = below.toBitmap()
        val c = Canvas(dst)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        p.alpha = (alpha(l) * 255).toInt()
        c.drawBitmap(src, 0f, 0f, p)
        dst.getPixels(below.px, 0, w, 0, 0, w, h)
        below.dirty = true
        remove(l)
        activeId = below.meta.id
        return true
    }

    /** Moves a layer one step up (+1) or down (-1) among its siblings. At the top / bottom of a
     *  folder the layer leaves the folder instead (so things can always be taken out again). */
    fun move(l: PixLayer, d: Int) {
        val i = layers.indexOfFirst { it === l }
        if (i < 0) return
        val pid = l.meta.parent
        if (pid != null) {
            val sib = layers.indices.filter { layers[it].meta.parent == pid }
            val atEdge = if (d > 0) sib.last() == i else sib.first() == i
            if (atEdge) { l.meta.parent = layer(pid)?.meta?.parent; return }
        }
        var j = i + d
        while (j >= 0 && j < layers.size && layers[j].meta.parent != l.meta.parent) j += d
        if (j < 0 || j >= layers.size) return
        layers.removeAt(i)
        layers.add(j, l)
    }

    /** Number of real (non-folder) layers. */
    val pixelLayerCount: Int get() = layers.count { !it.meta.isFolder }

    // MARK: composite helpers

    /// Clipping mask: the base is the nearest layer below (same folder) that is not itself clipped.
    fun clipBase(l: PixLayer): PixLayer? {
        if (!l.meta.isClip) return null
        var j = layers.indexOfFirst { it === l } - 1
        while (j >= 0) {
            val b = layers[j]
            if (b.meta.parent == l.meta.parent && !b.meta.isFolder && !b.meta.isClip) return b
            j -= 1
        }
        return null
    }

    /// The layer's picture cut to its base's shape (null = the base is hidden or missing: draw nothing).
    fun clippedImage(l: PixLayer, img: Bitmap): Bitmap? {
        val base = clipBase(l) ?: return null
        if (!shown(base)) return null
        val bimg = base.toBitmap()
        val tmp = makeBitmap()
        val c = Canvas(tmp)
        c.drawBitmap(img, 0f, 0f, null)
        val pm = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        pm.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN)
        c.drawBitmap(bimg, 0f, 0f, pm)
        return tmp
    }

    private fun drawLayer(l: PixLayer, c: Canvas) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        p.alpha = (alpha(l) * 255).toInt()
        c.drawBitmap(l.toBitmap(), 0f, 0f, p)
    }

    fun composite(range: IntRange, into: Canvas) {
        for (i in range) if (i in layers.indices) {
            val l = layers[i]
            if (l.meta.isFolder || !shown(l)) continue
            var img = l.toBitmap()
            var a = alpha(l)
            if (l.meta.isClip) {                       // clipped layers also take the base layer's opacity
                val base = clipBase(l)
                val cimg = if (base != null) clippedImage(l, img) else null
                if (cimg == null || base == null) continue
                img = cimg; a *= alpha(base)
            }
            val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            p.alpha = (a * 255).toInt()
            into.drawBitmap(img, 0f, 0f, p)
            trim(null)
        }
    }

    /** Keeps the RAM used by layer bitmaps bounded: clean layers are re-read from disk when needed. */
    fun trim(keep: PixLayer?) {
        if (PixLayer.loadedBytes <= 380_000_000L) return
        for (l in layers) if (l !== keep && l !== active && l.isLoaded && !l.dirty) {
            l.unload()
            if (PixLayer.loadedBytes <= 300_000_000L) break
        }
    }

    fun makeBitmap(): Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)

    private fun flattenBitmap(withPaper: Boolean): Bitmap {
        val bmp = makeBitmap()
        val c = Canvas(bmp)
        if (withPaper && item.paperWhite) {
            c.drawColor(0xFFFFFFFF.toInt())
        }
        composite(0 until layers.size, c)
        return bmp
    }
    fun flatten(withPaper: Boolean): Bitmap = flattenBitmap(withPaper)

    // MARK: saving

    fun syncMeta() {
        item.layers = layers.map { it.meta }.toMutableList()
        item.activeLayer = activeId
        item.updated = System.currentTimeMillis()
    }

    fun save() {
        for (l in layers) if (!l.meta.isFolder && l.dirty) {
            val d = l.pngData()
            if (d != null) try { DrawStore.layerFile(item.id, l.meta.id).writeBytes(d) } catch (_: Exception) {}
            l.dirty = false
        }
        trim(keep = null)
        try {
            val cg = flatten(withPaper = true)
            val maxS = 360f
            val sc = min(1f, maxS / max(w, h))
            val tw = max(1, (w * sc).toInt()); val th = max(1, (h * sc).toInt())
            val img = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
            val ic = Canvas(img)
            val r = RectF(0f, 0f, tw.toFloat(), th.toFloat())
            if (!item.paperWhite) {
                val gc = UIGraphics.getCurrentContext()
                if (gc != null) Checker.fill(gc, r, 8f)
            }
            val p = Paint(Paint.FILTER_BITMAP_FLAG)
            ic.drawBitmap(cg, null, r, p)
            DrawStore.thumbFile(item.id).outputStream().use { img.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) {}
        syncMeta()
        DrawStore.upsert(item)
    }
}

// MARK: - Undo --------------------------------------------------------------------------

class DrawUndo(
    val layerId: String,
    val x: Int, val y: Int, val w: Int, val h: Int,
    val before: IntArray,
    val after: IntArray
)

// MARK: - Canvas view -------------------------------------------------------------------

class DrawingCanvasView : UiView(appContext!!) {
    var doc: DrawDoc? = null
        set(v) { field = v; cachesDirty = true; fit() }
    /// Lock transparent pixels: brush and smudge keep the layer's existing shape (pixels that are transparent
    /// stay transparent, soft edges keep their alpha) so a cut-out picture can't be painted over or wiped out.
    var lockAlpha = false
    /// Blur brush: the smudge tool softens what is under the brush instead of dragging colour along.
    var blurMode = false
    var tool: DrawTool = DrawTool.brush
        set(v) { field = v; if (v != DrawTool.transform) cancelTransform() }
    var brushSize = 12f          // canvas pixels
    var opacity = 1f
    var style = BrushStyle()
    var eraserStyle = BrushStyle.eraserPresets[0]
    /** true = brush / eraser / wand edit the Selection Layer instead of the active layer */
    var selectionMode = false
        set(v) { field = v; setNeedsDisplay() }
    var wandTolerance = 32
    var wandContiguous = true
    var wandSubtract = false
    var onSelectionChanged: (() -> Unit)? = null
    private val st: BrushStyle get() = if (tool == DrawTool.eraser) eraserStyle else style
    private val target: PixLayer? get() = if (selectionMode) doc?.selLayer else doc?.active
    private var clip: IntArray? = null
    private var strokePts = ArrayList<Pair<CGPoint, Float>>()
    private var strokeDist = 0f
    private var strokeTotal = -1f
    private var wandPt: CGPoint? = null
    private var wandStartView = CGPoint.zero
    var color = 0xFF000000.toInt()
    var onColorPicked: ((Int) -> Unit)? = null
    var onChanged: (() -> Unit)? = null          // after a stroke / undo / redo / transform
    var onTransformState: ((Boolean) -> Unit)? = null
    var onBlocked: ((String) -> Unit)? = null

    val undoStack = ArrayList<DrawUndo>()
    val redoStack = ArrayList<DrawUndo>()
    private var undoBytes = 0L

    // view transform
    private var scale = 1f
    private var tx = 0f
    private var ty = 0f
    private var angle = 0f        // canvas view rotation (two-finger twist, like Ibis Paint)
    // caches
    private var below: Bitmap? = null
    private var above: Bitmap? = null
    var cachesDirty = true
    // stroke state
    private var snap: IntArray? = null
    private var covMask: ByteArray? = null
    private var stroking = false
    private var pending: CGPoint? = null
    private var lastPt = CGPoint.zero
    private var carry = 0f
    private var dminX = 0; private var dminY = 0; private var dmaxX = 0; private var dmaxY = 0
    private var strokeLayer: PixLayer? = null
    private var patch = FloatArray(0)
    private var patchR = 0
    private var holdTimer: Timer? = null
    private var picking = false
    // layer transform
    private var tfDX = 0f; private var tfDY = 0f; private var tfScale = 1f; private var tfAngle = 0f
    val isTransforming: Boolean get() = tfDX != 0f || tfDY != 0f || tfScale != 1f || tfAngle != 0f

    init {
        setBackgroundColor(0xFF1F1F1F.toInt())
        clipsToBounds = true
        val pinch = UIPinchGestureRecognizer { g -> onPinch(g) }
        val pan = UIPanGestureRecognizer { g -> onPan(g) }
        val rot = com.saiki.motion.uikit.UIRotateGestureRecognizer { r, p -> onRotate(r, p) }
        addGestureRecognizer(pinch)
        addGestureRecognizer(pan)
        addGestureRecognizer(rot)
    }

    private var firstLayout = true

    override fun layoutSubviews() {
        super.layoutSubviews()
        if (firstLayout && doc != null) { firstLayout = false; fit() }
    }

    fun fit() {
        val d = doc ?: return
        if (rectWidth() <= 10f) return
        val s = min(rectWidth() / d.w, rectHeight() / d.h) * 0.94f
        scale = s
        angle = 0f
        tx = (rectWidth() - d.w * s) / 2f
        ty = (rectHeight() - d.h * s) / 2f
        setNeedsDisplay()
    }

    val zoomScale: Float get() = scale

    fun toCanvas(p: CGPoint): CGPoint {
        val dx = p.x - tx; val dy = p.y - ty
        val c = cos(angle); val sn = sin(angle)
        return CGPoint((c * dx + sn * dy) / scale, (-sn * dx + c * dy) / scale)
    }
    private fun toView(p: CGPoint): CGPoint {
        val c = cos(angle); val sn = sin(angle)
        return CGPoint(scale * (c * p.x - sn * p.y) + tx, scale * (sn * p.x + c * p.y) + ty)
    }
    /** A finger movement in view space expressed in canvas pixels (rotation + zoom undone). */
    private fun canvasDelta(d: CGPoint): CGPoint {
        val c = cos(angle); val sn = sin(angle)
        return CGPoint((c * d.x + sn * d.y) / scale, (-sn * d.x + c * d.y) / scale)
    }

    fun invalidateCaches() { cachesDirty = true; setNeedsDisplay() }

    // MARK: drawing the view

    private fun rebuildCaches() {
        cachesDirty = false
        below = null; above = null
        val d = doc ?: return
        val ai = d.activeIndex
        val n = d.layers.size
        if (ai > 0) { val b = d.makeBitmap(); d.composite(0 until ai, Canvas(b)); below = b }
        if (ai >= 0 && ai + 1 < n) { val b = d.makeBitmap(); d.composite((ai + 1) until n, Canvas(b)); above = b }
        if (ai < 0) { val b = d.makeBitmap(); d.composite(0 until n, Canvas(b)); below = b }
    }

    public override fun draw(rect: CGRect) {
        val d = doc ?: return
        val c = UIGraphics.getCurrentContext() ?: return
        if (cachesDirty) rebuildCaches()
        val cw = d.w.toFloat(); val ch = d.h.toFloat()
        val canvasRect = RectF(0f, 0f, cw, ch)
        c.setFillColor(0xFF1F1F1F.toInt()); c.fill(CGRect(0f, 0f, rectWidth(), rectHeight()))
        c.saveGState()
        c.translateBy(tx, ty)
        c.rotate(angle)
        c.scaleBy(scale, scale)
        c.canvas.save()
        c.canvas.clipRect(canvasRect)
        if (d.item.paperWhite) {
            c.setFillColor(0xFFFFFFFF.toInt()); c.fill(CGRect(0f, 0f, cw, ch))
        } else {
            c.setFillColor(0xFF4D4D4D.toInt()); c.fill(CGRect(0f, 0f, cw, ch))
            c.setFillColor(0xFF6B6B6B.toInt())
            val t = 12f / scale
            val corners = listOf(toCanvas(CGPoint(rect.minX, rect.minY)), toCanvas(CGPoint(rect.maxX, rect.minY)),
                toCanvas(CGPoint(rect.maxX, rect.maxY)), toCanvas(CGPoint(rect.minX, rect.maxY)))
            val bx0 = corners.minOf { it.x }; val bx1 = corners.maxOf { it.x }
            val by0 = corners.minOf { it.y }; val by1 = corners.maxOf { it.y }
            var y = floor(by0 / t) * t
            while (y < by1) {
                var x = floor(bx0 / t) * t
                while (x < bx1) {
                    val ix = Math.round(x / t); val iy = Math.round(y / t)
                    if ((ix + iy) and 1 == 0) c.canvas.drawRect(RectF(x, y, x + t, y + t), c.paint)
                    x += t
                }
                y += t
            }
        }
        val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        below?.let { c.canvas.drawBitmap(it, null, canvasRect, p) }
        val a = d.active
        if (a != null && d.shown(a)) {
            var img = a.toBitmap()
            var aAlpha = d.alpha(a)
            if (a.meta.isClip) {
                val base = d.clipBase(a)
                val cl = if (base != null) d.clippedImage(a, img) else null
                if (cl != null && base != null) { img = cl; aAlpha *= d.alpha(base) } else { aAlpha = 0f }
            }
            c.canvas.save()
            if (tool == DrawTool.transform && isTransforming) {
                val m = layerTransform()
                c.canvas.concat(android.graphics.Matrix().apply { setValues(floatArrayOf(m.a, m.b, m.tx, m.c, m.d, m.ty, 0f, 0f, 1f)) })
            }
            val lp = Paint(p)
            lp.alpha = (aAlpha * 255).toInt()
            c.canvas.drawBitmap(img, null, canvasRect, lp)
            c.canvas.restore()
        }
        above?.let { c.canvas.drawBitmap(it, null, canvasRect, p) }
        if (d.selLayer.isLoaded && (d.selHas || selectionMode)) {
            val sp = Paint(p)
            sp.alpha = ((if (selectionMode) 0.65f else 0.38f) * 255).toInt()
            c.canvas.drawBitmap(d.selLayer.toBitmap(), null, canvasRect, sp)
        }
        c.canvas.restore()
        c.setStrokeColor(0x2EFFFFFF.toInt())
        c.setLineWidth(1f / scale)
        c.canvas.drawRect(canvasRect, c.paint)
        c.restoreGState()
    }

    // MARK: navigation gestures

    private fun onPan(g: UIPanGestureRecognizer) {
        if (g.state == UIGestureRecognizerState.began) abortStroke()
        val d = g.translation(this)
        g.setTranslationZero()
        if (tool == DrawTool.transform) {
            val cd = canvasDelta(d); tfDX += cd.x; tfDY += cd.y; onTransformState?.invoke(true)
        } else { tx += d.x; ty += d.y }
        setNeedsDisplay()
    }

    private fun onPinch(g: UIPinchGestureRecognizer) {
        if (g.state == UIGestureRecognizerState.began) abortStroke()
        val f = g.scale
        g.scale = 1f
        if (tool == DrawTool.transform) {
            tfScale = max(0.05f, min(20f, tfScale * f)); onTransformState?.invoke(true)
        } else {
            val p = g.location(this)
            val ns = max(0.05f, min(40f, scale * f))
            val k = ns / scale
            tx = p.x - (p.x - tx) * k
            ty = p.y - (p.y - ty) * k
            scale = ns
        }
        setNeedsDisplay()
    }

    class Affine2(val a: Float, val b: Float, val c: Float, val d: Float, val tx: Float, val ty: Float)

    /** Two-finger rotation: the uikit layer reports (rotation, location) — see UIRotateGestureRecognizerAdapter. */
    private fun onRotate(r: Float, p: CGPoint) {
        abortStroke()
        if (tool == DrawTool.transform) {
            tfAngle += r
            onTransformState?.invoke(true)
            setNeedsDisplay()
            return
        }
        // rotate the whole view around the fingers' midpoint (Ibis Paint style)
        val c = cos(r); val sn = sin(r)
        val vx = tx - p.x; val vy = ty - p.y
        tx = p.x + c * vx - sn * vy
        ty = p.y + sn * vx + c * vy
        angle += r
        // gentle snap back to upright when the canvas is almost level (on lift the adapter sends 0 rotation)
        setNeedsDisplay()
    }

    fun snapLevel() {
        val a = atan2(sin(angle), cos(angle))
        if (abs(a) < 0.06f) {
            val p = lastRotateLoc
            val back = -a
            val c2 = cos(back); val s2 = sin(back)
            val ux = tx - p.x; val uy = ty - p.y
            tx = p.x + c2 * ux - s2 * uy
            ty = p.y + s2 * ux + c2 * uy
            angle = 0f
            setNeedsDisplay()
        }
    }

    private var lastRotateLoc = CGPoint.zero

    // MARK: layer transform

    private fun layerTransform(): Affine2 {
        val cx = (doc!!.w).toFloat() / 2f; val cy = (doc!!.h).toFloat() / 2f
        val c = cos(tfAngle); val s = sin(tfAngle)
        // t = translate(cx+dx, cy+dy) * rotate(tfAngle) * scale(tfScale) * translate(-cx, -cy)
        // q = R*S*(p - c) + (cx+dx, cy+dy)
        val a = c * tfScale; val b = s * tfScale; val cc = -s * tfScale; val d = c * tfScale
        val e = cx + tfDX; val f = cy + tfDY
        return Affine2(a, b, cc, d, e - (a * cx + b * cy), f - (cc * cx + d * cy))
    }

    fun cancelTransform() {
        if (!isTransforming) return
        tfDX = 0f; tfDY = 0f; tfScale = 1f; tfAngle = 0f
        onTransformState?.invoke(false)
        setNeedsDisplay()
    }

    fun applyTransform() {
        val d = doc ?: return
        val layer = d.active ?: return
        if (!isTransforming) return
        val n = d.w * d.h
        val before = layer.px.copyOf(n)
        val tmp = Bitmap.createBitmap(d.w, d.h, Bitmap.Config.ARGB_8888)
        val c = Canvas(tmp)
        val m = layerTransform()
        val mat = android.graphics.Matrix()
        mat.setValues(floatArrayOf(m.a, m.b, m.tx, m.c, m.d, m.ty, 0f, 0f, 1f))
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(layer.toBitmap(), mat, p)
        tmp.getPixels(layer.px, 0, d.w, 0, 0, d.w, d.h)
        layer.dirty = true
        val after = layer.px.copyOf(n)
        pushUndo(DrawUndo(layer.meta.id, 0, 0, d.w, d.h, before, after))
        tfDX = 0f; tfDY = 0f; tfScale = 1f; tfAngle = 0f
        onTransformState?.invoke(false)
        setNeedsDisplay()
        onChanged?.invoke()
    }

    // MARK: undo / redo

    private fun pushUndo(u: DrawUndo) {
        undoStack.add(u); undoBytes += (u.before.size + u.after.size) * 4L
        for (r in redoStack) undoBytes -= (r.before.size + r.after.size) * 4L
        redoStack.clear()
        while (undoBytes > 160_000_000L && undoStack.size > 1) {
            val f = undoStack.removeAt(0); undoBytes -= (f.before.size + f.after.size) * 4L
        }
    }
    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    private fun apply(u: DrawUndo, pixels: IntArray) {
        val d = doc ?: return
        val l = d.layer(u.layerId) ?: (if (u.layerId == "__sel__") d.selLayer else null) ?: return
        if (l.meta.isFolder) return
        for (row in 0 until u.h) {
            val dst = (u.y + row) * d.w + u.x
            System.arraycopy(pixels, row * u.w, l.px, dst, u.w)
        }
        l.dirty = true
        if (l === d.selLayer) { d.recomputeSel(); onSelectionChanged?.invoke() }
        invalidateCaches()
    }

    fun undo() {
        val u = undoStack.removeLastOrNull() ?: return
        apply(u, u.before); redoStack.add(u); onChanged?.invoke()
    }
    fun redo() {
        val u = redoStack.removeLastOrNull() ?: return
        apply(u, u.after); undoStack.add(u); onChanged?.invoke()
    }

    // MARK: touches

    override fun touchesBegan(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.first() ?: return
        val d = doc ?: return
        if ((event?.touches?.size ?: 1) > 1) { abortStroke(); return }
        val p = toCanvas(t.location(this))
        if (tool == DrawTool.eyedropper) { picking = true; pickAt(p); return }
        if (tool == DrawTool.transform) { lastPt = t.location(this); return }
        if (tool == DrawTool.wand) {
            if (d.active == null) { onBlocked?.invoke("Select a layer first"); return }
            wandPt = p; wandStartView = t.location(this); return
        }
        if (selectionMode && tool == DrawTool.smudge) { onBlocked?.invoke("Not available on the Selection Layer"); return }
        val l = target ?: run { onBlocked?.invoke("Select a layer first"); return }
        if (!selectionMode && !d.shown(l)) { onBlocked?.invoke("This layer is hidden"); return }
        pending = p
        lastPt = p
        holdTimer?.cancel()
        if (tool == DrawTool.brush || tool == DrawTool.eraser) {
            holdTimer = Timer()
            holdTimer?.schedule(object : TimerTask() {
                override fun run() {
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        if (pending != null && !stroking) {
                            pending = null
                            picking = true
                            pickAt(lastPt)
                        }
                    }
                }
            }, 450)
        }
    }

    override fun touchesMoved(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.first() ?: return
        val d = doc ?: return
        if ((event?.touches?.size ?: 1) > 1) { abortStroke(); return }
        val vp = t.location(this)
        val p = toCanvas(vp)
        if (picking) { pickAt(p); return }
        if (tool == DrawTool.wand) {
            if (wandPt != null && hypot(vp.x - wandStartView.x, vp.y - wandStartView.y) > 10f) wandPt = null
            return
        }
        if (tool == DrawTool.transform) {
            val cd = canvasDelta(CGPoint(vp.x - lastPt.x, vp.y - lastPt.y)); tfDX += cd.x; tfDY += cd.y
            lastPt = vp; onTransformState?.invoke(true); setNeedsDisplay(); return
        }
        val s = pending
        if (s != null) {
            if (hypot(p.x - s.x, p.y - s.y) * scale < 4f) return
            holdTimer?.cancel()
            beginStroke(s)
            pending = null
        }
        if (!stroking) return
        extendStroke(p)
        if (tool != DrawTool.smudge) flush() else setNeedsDisplay()
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        holdTimer?.cancel()
        picking = false
        if (tool == DrawTool.wand) { val p = wandPt; wandPt = null; if (p != null) wandTap(p); return }
        val s = pending
        if (s != null) {                                  // a tap = one dab
            pending = null
            beginStroke(s)
        }
        if (stroking) endStroke()
        if (angle != 0f && !stroking) snapLevel()
    }

    override fun touchesCancelled(touches: Set<UITouch>, event: UIEvent?) {
        holdTimer?.cancel()
        picking = false
        abortStroke()
    }

    // MARK: eyedropper

    private var pickBmp: Bitmap? = null

    private fun pickAt(p: CGPoint) {
        val d = doc ?: return
        if (pickBmp == null) pickBmp = d.flatten(withPaper = true)
        val x = p.x.toInt(); val y = p.y.toInt()
        val b = pickBmp ?: return
        if (x < 0 || y < 0 || x >= b.width || y >= b.height) return
        val v = b.getPixel(x, y)
        val a = (v ushr 24) / 255f
        val col = if (a <= 0.004f) 0xFF808080.toInt()
        else {
            val r = min(255f, ((v shr 16) and 0xFF) / a).toInt()
            val g = min(255f, ((v shr 8) and 0xFF) / a).toInt()
            val bl = min(255f, (v and 0xFF) / a).toInt()
            (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
        }
        if (a > 0.004f) onColorPicked?.invoke(col)
    }

    // MARK: strokes

    private fun ensureBuffers() {
        val d = doc!!
        val n = d.w * d.h
        if (snap == null) {
            snap = IntArray(n)
            covMask = ByteArray(n)
        }
    }

    private fun beginStroke(p: CGPoint) {
        val l = target ?: return
        val d = doc!!
        ensureBuffers()
        System.arraycopy(l.px, 0, snap!!, 0, d.w * d.h)
        strokeLayer = l
        clip = if (!selectionMode && d.selHas && d.selLayer.isLoaded) d.selLayer.px else null
        strokePts = ArrayList(listOf(Pair(p, 1f)))
        strokeDist = 0f; strokeTotal = -1f
        stroking = true
        dminX = Int.MAX_VALUE; dminY = Int.MAX_VALUE; dmaxX = -1; dmaxY = -1
        lastPt = p
        carry = 0f
        if (tool == DrawTool.smudge) {
            patchR = max(2, (brushSize / 2).toInt())
            patch = FloatArray((patchR * 2 + 1) * (patchR * 2 + 1) * 4)
            samplePatch(p, patch, patchR, 0f, l)
        } else {
            dab(p, 0f)
            flush()
        }
    }

    private fun extendStroke(p: CGPoint) {
        if (!stroking) return
        val l = strokeLayer ?: return
        val r = max(0.5f, brushSize / 2)
        val step = max(0.7f, r * (if (tool == DrawTool.smudge) 0.18f else max(0.03f, st.spacing)))
        var dx = p.x - lastPt.x; var dy = p.y - lastPt.y
        val dist = hypot(dx, dy)
        if (dist < 0.01f) return
        dx /= dist; dy /= dist
        var pos = step - carry
        while (pos <= dist) {
            val q = CGPoint(lastPt.x + dx * pos, lastPt.y + dy * pos)
            if (tool == DrawTool.smudge) smudgeStep(q, l) else dab(q, strokeDist + pos)
            pos += step
        }
        carry = dist - (pos - step)
        strokeDist += dist
        if (tool != DrawTool.smudge) strokePts.add(Pair(p, 1f))
        lastPt = p
    }

    private fun abortStroke() {
        wandPt = null
        holdTimer?.cancel()
        pending = null
        val l = strokeLayer; val sn = snap
        if (!stroking || l == null || sn == null) { stroking = false; return }
        if (dmaxX >= dminX) { restoreFromSnap(l, sn); clearMask() }
        stroking = false
        invalidateCaches()
    }

    private fun restoreFromSnap(l: PixLayer, sn: IntArray) {
        val d = doc!!
        val x0 = max(0, dminX); val x1 = min(d.w - 1, dmaxX)
        val y0 = max(0, dminY); val y1 = min(d.h - 1, dmaxY)
        if (x1 >= x0 && y1 >= y0) {
            for (y in y0..y1) {
                val o = y * d.w + x0
                System.arraycopy(sn, o, l.px, o, x1 - x0 + 1)
            }
        }
    }

    /** Re-draws the finished stroke with a tapered end (needs the total length, so it can only happen on lift). */
    private fun replayWithEndTaper() {
        val l = strokeLayer ?: return
        val sn = snap ?: return
        if (dmaxX < dminX || strokePts.size <= 1) return
        val pts = strokePts
        var total = 0f
        for (i in 1 until pts.size) total += hypot(pts[i].first.x - pts[i - 1].first.x, pts[i].first.y - pts[i - 1].first.y)
        restoreFromSnap(l, sn)
        clearMask()
        strokeTotal = total; strokeDist = 0f; carry = 0f; lastPt = pts[0].first
        dab(pts[0].first, 0f)
        for (i in 1 until pts.size) extendStroke(pts[i].first)
        flush()
    }

    private fun endStroke() {
        val d = doc ?: return
        val l = strokeLayer ?: return
        val sn = snap ?: return
        if (!stroking) return
        if (tool != DrawTool.smudge && st.tipEnd > 0f) replayWithEndTaper()
        stroking = false
        pickBmp = null
        if (dmaxX >= dminX) {
            val x = max(0, dminX); val y = max(0, dminY)
            val w = min(d.w - 1, dmaxX) - x + 1
            val h = min(d.h - 1, dmaxY) - y + 1
            if (w > 0 && h > 0) {
                val before = IntArray(w * h)
                val after = IntArray(w * h)
                for (row in 0 until h) {
                    val o = (y + row) * d.w + x
                    System.arraycopy(sn, o, before, row * w, w)
                    System.arraycopy(l.px, o, after, row * w, w)
                }
                if (!before.contentEquals(after)) {   // erasing already-transparent pixels changes nothing
                    pushUndo(DrawUndo(l.meta.id, x, y, w, h, before, after))
                    l.dirty = true
                }
            }
            clearMask()
        }
        if (selectionMode) { d.recomputeSel(); onSelectionChanged?.invoke() }
        onChanged?.invoke()
    }

    private fun clearMask() {
        val m = covMask ?: return
        val d = doc!!
        if (dmaxX < dminX) return
        val x0 = max(0, dminX); val x1 = min(d.w - 1, dmaxX)
        val y0 = max(0, dminY); val y1 = min(d.h - 1, dmaxY)
        if (x1 < x0 || y1 < y0) return
        val count = x1 - x0 + 1
        for (y in y0..y1) {
            val row = y * d.w + x0
            m.fill(0, row, row + count)
        }
    }

    private fun grow(x0: Int, y0: Int, x1: Int, y1: Int) {
        dminX = min(dminX, x0); dminY = min(dminY, y0); dmaxX = max(dmaxX, x1); dmaxY = max(dmaxY, y1)
    }

    private var flushX0 = Int.MAX_VALUE; private var flushY0 = Int.MAX_VALUE
    private var flushX1 = -1; private var flushY1 = -1

    /** Stamps a soft round dab into the coverage covMask. */
    private fun grainNoise(x: Int, y: Int): Float {
        var h = (x * 73856093) xor (y * 19349663)
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFF) / 65535f
    }

    private fun taperScale(d: Float): Float {
        val L = max(8f, brushSize * 5f)
        var t = 1f
        if (st.tipStart > 0f) t = min(t, d / (st.tipStart * L))
        if (st.tipEnd > 0f && strokeTotal >= 0f) t = min(t, (strokeTotal - d) / (st.tipEnd * L))
        t = min(1f, max(0f, t))
        return 0.1f + 0.9f * (t * t * (3f - 2f * t))
    }

    private val rnd = java.util.Random()

    private fun dab(p0: CGPoint, along: Float) {
        val m = covMask ?: return
        val sy = st; val W = doc!!.w; val H = doc!!.h
        var p = p0
        var r = max(0.5f, brushSize / 2)
        if (sy.tipStart > 0f || sy.tipEnd > 0f) r = max(0.5f, r * taperScale(along))
        if (sy.sizeJitter > 0f) r = max(0.5f, r * (1f - sy.sizeJitter * rnd.nextFloat()))
        if (sy.scatter > 0f) {
            val an = rnd.nextFloat() * (2f * Math.PI.toFloat())
            val dd = r * sy.scatter * rnd.nextFloat()
            p = CGPoint(p.x + cos(an) * dd, p.y + sin(an) * dd)
        }
        val x0 = max(0, floor(p.x - r - 1f).toInt()); val x1 = min(W - 1, ceil(p.x + r + 1f).toInt())
        val y0 = max(0, floor(p.y - r - 1f).toInt()); val y1 = min(H - 1, ceil(p.y + r + 1f).toInt())
        if (x1 < x0 || y1 < y0) return
        val aa = max(1f, r * (1f - sy.hardness))
        val isEraser = tool == DrawTool.eraser
        val eraserPeak = 0.12f + 0.88f * sy.hardness   // radius blur: 100 = erases everything in the radius at once
        for (y in y0..y1) {
            val dy = y + 0.5f - p.y
            for (x in x0..x1) {
                val dx = x + 0.5f - p.x
                val d = if (sy.square) max(abs(dx), abs(dy)) else hypot(dx, dy)
                var cov = min(1f, max(0f, (r - d) / aa))
                if (cov <= 0f) continue
                if (sy.grain > 0f) cov *= 1f - sy.grain + sy.grain * grainNoise(x, y)
                if (isEraser) cov *= eraserPeak
                val v = (cov * 255).toInt().toByte()
                val i = y * W + x
                if (v > m[i]) m[i] = v
            }
        }
        grow(x0, y0, x1, y1)
        flushX0 = min(flushX0, x0); flushY0 = min(flushY0, y0); flushX1 = max(flushX1, x1); flushY1 = max(flushY1, y1)
    }

    /** Composites the covMask over the stroke-start snapshot for the pixels touched since the last flush. */
    private fun flush() {
        if (flushX1 < flushX0) return
        val l = strokeLayer ?: return
        val m = covMask ?: return
        val sn = snap ?: return
        var col = color
        if (selectionMode) col = 0xFF3366FF.toInt()       // selection paint is always blue
        val R = ((col shr 16) and 0xFF).toFloat()
        val G = ((col shr 8) and 0xFF).toFloat()
        val B = (col and 0xFF).toFloat()
        val op = opacity
        val erase = tool == DrawTool.eraser
        val dst = l.px
        val W = doc!!.w
        for (y in flushY0..flushY1) {
            for (x in flushX0..flushX1) {
                val i = y * W + x
                val mv = m[i].toInt() and 0xFF
                if (mv == 0) continue
                var a = mv / 255f * op
                if (clip != null) a *= ((clip!![i] ushr 24) and 0xFF) / 255f
                val sv = sn[i]
                if (erase) {
                    // Eraser only ever lowers alpha (premultiplied: colour scales with it), so erased pixels end up
                    // truly transparent - never black, never opaque - and already-transparent pixels stay untouched.
                    val a0 = (sv ushr 24) and 0xFF
                    if (a0 == 0) { dst[i] = 0; continue }
                    val k = max(0f, min(1f, 1f - a))
                    val na = max(0, min(255, Math.round(a0 * k)))
                    val ca = Math.round(((sv shr 16) and 0xFF) * k); val cb = Math.round(((sv shr 8) and 0xFF) * k); val cc = Math.round((sv and 0xFF) * k)
                    dst[i] = (na shl 24) or (min(na, ca) shl 16) or (min(na, cb) shl 8) or min(na, cc)
                } else if (lockAlpha && !selectionMode) {
                    val a0 = ((sv ushr 24) and 0xFF).toFloat()
                    if (a0 == 0f) { dst[i] = 0; continue }
                    val k = 1f - a; val al = a0 / 255f
                    fun ch(c: Float, old: Int): Int {
                        val col = c * a + old * 255f / a0 * k
                        return max(0, min(255, Math.round(col * al)))
                    }
                    dst[i] = ((sv ushr 24) and 0xFF shl 24) or
                        (ch(R, (sv shr 16) and 0xFF) shl 16) or
                        (ch(G, (sv shr 8) and 0xFF) shl 8) or
                        ch(B, sv and 0xFF)
                } else {
                    val k = 1f - a
                    dst[i] = (0xFF shl 24) or
                        (min(255, (R * a + ((sv shr 16) and 0xFF) * k).toInt()) shl 16) or
                        (min(255, (G * a + ((sv shr 8) and 0xFF) * k).toInt()) shl 8) or
                        min(255, (B * a + (sv and 0xFF) * k).toInt())
                }
            }
        }
        setNeedsDisplay()
        flushX0 = Int.MAX_VALUE; flushY0 = Int.MAX_VALUE; flushX1 = -1; flushY1 = -1
    }

    // MARK: smudge

    private fun samplePatch(p: CGPoint, pt: FloatArray, r: Int, keep: Float, layer: PixLayer) {
        val d = doc!!
        val side = r * 2 + 1
        val cx = p.x.toInt(); val cy = p.y.toInt()
        for (j in 0 until side) {
            val y = cy + j - r
            if (y < 0 || y >= d.h) continue
            for (i in 0 until side) {
                val x = cx + i - r
                if (x < 0 || x >= d.w) continue
                val v = layer.px[y * d.w + x]
                val k = (j * side + i) * 4
                pt[k] = pt[k] * keep + ((v shr 16) and 0xFF) * (1 - keep)
                pt[k + 1] = pt[k + 1] * keep + ((v shr 8) and 0xFF) * (1 - keep)
                pt[k + 2] = pt[k + 2] * keep + (v and 0xFF) * (1 - keep)
                pt[k + 3] = pt[k + 3] * keep + ((v ushr 24) and 0xFF) * (1 - keep)
            }
        }
    }

    /// Blur brush: every pixel under the brush moves toward the average of its 5x5 neighbourhood (colour weighted by alpha).
    private fun blurStep(p: CGPoint, l: PixLayer) {
        val d = doc!!
        val r = patchR; val m = 2
        val dst = l.px
        val cx = Math.round(p.x); val cy = Math.round(p.y)
        val x0 = max(0, cx - r - m); val y0 = max(0, cy - r - m); val x1 = min(d.w - 1, cx + r + m); val y1 = min(d.h - 1, cy + r + m)
        if (x1 < x0 || y1 < y0) return
        val sw = x1 - x0 + 1; val sh = y1 - y0 + 1
        val src = IntArray(sw * sh) { dst[(y0 + it / sw) * d.w + x0 + it % sw] }
        val strength = max(0.08f, opacity) * 0.8f; val rr = r.toFloat()
        for (y in max(0, cy - r)..min(d.h - 1, cy + r)) {
            for (x in max(0, cx - r)..min(d.w - 1, cx + r)) {
                val dx = (x - cx).toFloat(); val dy = (y - cy).toFloat()
                val cov = min(1f, max(0f, (rr - hypot(dx, dy)) / max(1f, rr * 0.5f)))
                if (cov <= 0f) continue
                val o = y * d.w + x
                if (lockAlpha && !selectionMode && ((dst[o] ushr 24) and 0xFF) == 0) continue
                var k = cov * strength
                if (clip != null) k *= ((clip!![o] ushr 24) and 0xFF) / 255f
                var sr = 0f; var sg = 0f; var sb = 0f; var sa = 0f; var n = 0f
                for (j in -m..m) {
                    val yy = y + j; if (yy < y0 || yy > y1) continue
                    for (i in -m..m) {
                        val xx = x + i; if (xx < x0 || xx > x1) continue
                        val q = src[(yy - y0) * sw + (xx - x0)]
                        sr += ((q shr 16) and 0xFF); sg += ((q shr 8) and 0xFF); sb += (q and 0xFF); sa += ((q ushr 24) and 0xFF); n += 1f
                    }
                }
                if (n <= 0f) continue
                // the layer buffer is premultiplied: a plain average of the four channels blurs colour and edge together
                val locked = lockAlpha && !selectionMode
                val a0 = ((dst[o] ushr 24) and 0xFF).toFloat()
                val cap = if (locked) a0.toInt() else 255
                fun ch(old: Int, avg: Float): Int = max(0, min(cap, Math.round(old * (1 - k) + avg / n * k)))
                val nv = dst[o]
                val na = if (locked) (nv ushr 24) and 0xFF else max(0, min(255, Math.round(a0 * (1 - k) + sa / n * k)))
                dst[o] = (na shl 24) or
                    (ch((nv shr 16) and 0xFF, sr) shl 16) or
                    (ch((nv shr 8) and 0xFF, sg) shl 8) or
                    ch(nv and 0xFF, sb)
            }
        }
        grow(cx - r, cy - r, cx + r, cy + r)
        flushX0 = min(flushX0, cx - r); flushY0 = min(flushY0, cy - r)
        flushX1 = max(flushX1, cx + r); flushY1 = max(flushY1, cy + r)
    }

    private fun smudgeStep(p: CGPoint, l: PixLayer) {
        if (blurMode) { blurStep(p, l); return }
        val d = doc!!
        val r = patchR
        val dst = l.px
        val side = r * 2 + 1
        val cx = Math.round(p.x); val cy = Math.round(p.y)
        val strength = max(0.08f, opacity) * 0.8f
        val rr = r.toFloat()
        for (j in 0 until side) {
            val y = cy + j - r
            if (y < 0 || y >= d.h) continue
            for (i in 0 until side) {
                val x = cx + i - r
                if (x < 0 || x >= d.w) continue
                val dx = (i - r).toFloat(); val dy = (j - r).toFloat()
                val dist = hypot(dx, dy)
                val cov = min(1f, max(0f, (rr - dist) / max(1f, rr * 0.5f)))
                if (cov <= 0f) continue
                val idx = y * d.w + x
                var k = cov * strength
                if (clip != null) k *= ((clip!![idx] ushr 24) and 0xFF) / 255f
                val pk = (j * side + i) * 4
                fun mix(v: Int, pkc: Int): Int =
                    max(0, min(255, Math.round(v * (1 - k) + patch[pkc] * k)))
                val sv = dst[idx]
                if (lockAlpha && !selectionMode) {
                    val a0 = (sv ushr 24) and 0xFF
                    if (a0 == 0) continue
                    fun lm(v: Int, pkc: Int): Int = max(0, min(a0, Math.round(v * (1 - k) + patch[pkc] * k)))
                    dst[idx] = ((sv ushr 24) and 0xFF shl 24) or
                        (lm((sv shr 16) and 0xFF, pk) shl 16) or
                        (lm((sv shr 8) and 0xFF, pk + 1) shl 8) or
                        lm(sv and 0xFF, pk + 2)
                    continue
                }
                dst[idx] = (mix((sv ushr 24) and 0xFF, pk + 3) shl 24) or
                    (mix((sv shr 16) and 0xFF, pk) shl 16) or
                    (mix((sv shr 8) and 0xFF, pk + 1) shl 8) or
                    mix(sv and 0xFF, pk + 2)
            }
        }
        grow(cx - r, cy - r, cx + r, cy + r)
        val keep = min(0.97f, 0.55f + 0.42f * opacity)
        samplePatch(p, patch, r, keep, l)
    }

    // MARK: selection layer / magic wand

    private fun snapshot(l: PixLayer): IntArray = l.px.copyOf(doc!!.w * doc!!.h)

    /** Diffs the layer against `before`, stores only the changed rectangle as one undo step. */
    private fun commit(l: PixLayer, before: IntArray) {
        val d = doc!!
        val w = d.w; val h = d.h
        var x0 = w; var y0 = h; var x1 = -1; var y1 = -1
        for (y in 0 until h) {
            val row = y * w
            var xs = 0
            while (xs < w && before[row + xs] == l.px[row + xs]) xs += 1
            if (xs >= w) continue
            var xe = w - 1
            while (xe > xs && before[row + xe] == l.px[row + xe]) xe -= 1
            x0 = min(x0, xs); x1 = max(x1, xe); y0 = min(y0, y); y1 = max(y1, y)
        }
        if (x1 < x0) return
        val rw = x1 - x0 + 1; val rh = y1 - y0 + 1
        val bef = IntArray(rw * rh)
        val aft = IntArray(rw * rh)
        for (row in 0 until rh) {
            val o = (y0 + row) * w + x0
            System.arraycopy(before, o, bef, row * rw, rw)
            System.arraycopy(l.px, o, aft, row * rw, rw)
        }
        pushUndo(DrawUndo(l.meta.id, x0, y0, rw, rh, bef, aft))
        l.dirty = true
    }

    private fun finishSelOp(before: IntArray) {
        val d = doc!!
        commit(d.selLayer, before)
        d.recomputeSel()
        setNeedsDisplay()
        onSelectionChanged?.invoke()
        onChanged?.invoke()
    }

    private fun setSel(p: IntArray, i: Int, a: Int) {
        p[i] = (a shl 24) or (51 * a / 255 shl 16) or (102 * a / 255 shl 8) or 255 * a / 255
    }

    fun removeSelection() {
        val d = doc ?: return
        if (!d.selHas) return
        val b = snapshot(d.selLayer)
        d.selLayer.clear()
        finishSelOp(b)
    }

    fun invertSelection() {
        val d = doc!!
        val p = d.selLayer.px
        val b = snapshot(d.selLayer)
        for (i in 0 until d.w * d.h) setSel(p, i, 255 - ((p[i] ushr 24) and 0xFF))
        finishSelOp(b)
    }

    /** Select every pixel that has paint on the active layer. */
    fun selectOpacity() {
        val d = doc!!
        val src = d.active ?: run { onBlocked?.invoke("Select a layer first"); return }
        val b = snapshot(d.selLayer)
        val p = d.selLayer.px
        val s = src.px
        for (i in 0 until d.w * d.h) {
            val a = (s[i] ushr 24) and 0xFF
            if (a > ((p[i] ushr 24) and 0xFF)) setSel(p, i, a)
        }
        finishSelOp(b)
    }

    /** Clears the active layer inside the selection (whole layer if nothing is selected). */
    fun clearLayer() {
        val d = doc!!
        val l = d.active ?: run { onBlocked?.invoke("Select a layer first"); return }
        val b = snapshot(l)
        val p = l.px
        if (d.selHas) {
            val sp = d.selLayer.px
            for (i in 0 until d.w * d.h) {
                val sa = (sp[i] ushr 24) and 0xFF
                if (sa == 0) continue
                val k = 255 - sa
                val v = p[i]
                p[i] = ((((v ushr 24) and 0xFF) * k / 255) shl 24) or
                    ((((v shr 16) and 0xFF) * k / 255) shl 16) or
                    ((((v shr 8) and 0xFF) * k / 255) shl 8) or
                    ((v and 0xFF) * k / 255)
            }
        } else {
            l.clear()
        }
        commit(l, b)
        invalidateCaches()
        onChanged?.invoke()
    }

    /** Magic wand: picks the colour under the tap on the active layer and adds (or subtracts) it to the Selection Layer. */
    private fun wandTap(pt: CGPoint) {
        val d = doc!!
        val w = d.w; val h = d.h
        val x = pt.x.toInt(); val y = pt.y.toInt()
        if (x < 0 || y < 0 || x >= w || y >= h) return
        val src = d.active ?: return
        val s = src.px
        val v0 = s[y * w + x]
        val r0 = (v0 shr 16) and 0xFF; val g0 = (v0 shr 8) and 0xFF; val b0 = v0 and 0xFF; val a0 = (v0 ushr 24) and 0xFF
        val tol = wandTolerance
        fun match(i: Int): Boolean {
            val v = s[i]
            return abs(((v shr 16) and 0xFF) - r0) <= tol && abs(((v shr 8) and 0xFF) - g0) <= tol
                && abs((v and 0xFF) - b0) <= tol && abs(((v ushr 24) and 0xFF) - a0) <= tol
        }
        val mark = ByteArray(w * h)
        if (wandContiguous) {
            val stack = ArrayList<Int>()
            stack.add(y * w + x)
            while (stack.isNotEmpty()) {
                val seed = stack.removeAt(stack.size - 1)
                if (mark[seed].toInt() != 0) continue
                val sy = seed / w; val sx = seed % w
                var l = sx; var r = sx
                while (l > 0 && mark[sy * w + l - 1].toInt() == 0 && match(sy * w + l - 1)) l -= 1
                while (r < w - 1 && mark[sy * w + r + 1].toInt() == 0 && match(sy * w + r + 1)) r += 1
                for (xx in l..r) mark[sy * w + xx] = 1
                for (ny in intArrayOf(sy - 1, sy + 1)) if (ny in 0 until h) {
                    var xx = l
                    while (xx <= r) {
                        val ii = ny * w + xx
                        if (mark[ii].toInt() == 0 && match(ii)) {
                            stack.add(ii)
                            xx += 1
                            while (xx <= r && mark[ny * w + xx].toInt() == 0 && match(ny * w + xx)) xx += 1
                        } else xx += 1
                    }
                }
            }
        } else {
            for (i in 0 until w * h) if (match(i)) mark[i] = 1
        }
        val before = snapshot(d.selLayer)
        val p = d.selLayer.px
        val sub = wandSubtract
        for (i in 0 until w * h) if (mark[i].toInt() != 0) {
            if (sub) p[i] = 0 else setSel(p, i, 255)
        }
        finishSelOp(before)
    }

    // MARK: copy / cut / paste

    class Clip(val x: Int, val y: Int, val w: Int, val h: Int, val px: IntArray)

    companion object { var clipboard: Clip? = null }

    /** Copies the active layer's pixels inside the selection (whole layer if nothing is selected). */
    fun copySelection(cut: Boolean): Boolean {
        val d = doc!!
        val l = d.active ?: run { onBlocked?.invoke("Select a layer first"); return false }
        val W = d.w; val H = d.h
        val src = l.px
        val sp = if (d.selHas) d.selLayer.px else null
        var x0 = W; var y0 = H; var x1 = -1; var y1 = -1
        for (y in 0 until H) {
            for (x in 0 until W) {
                val o = y * W + x
                if ((src[o] ushr 24) == 0) continue
                if (sp != null && (sp[o] ushr 24) == 0) continue
                x0 = min(x0, x); x1 = max(x1, x); y0 = min(y0, y); y1 = max(y1, y)
            }
        }
        if (x1 < x0) { onBlocked?.invoke("Nothing to copy"); return false }
        val cw = x1 - x0 + 1; val ch = y1 - y0 + 1
        val px = IntArray(cw * ch)
        for (y in 0 until ch) {
            for (x in 0 until cw) {
                val o = (y0 + y) * W + x0 + x
                val k = if (sp != null) (sp[o] ushr 24) and 0xFF else 255
                val v = src[o]
                fun m(c: Int): Int = (c * k / 255)
                px[y * cw + x] = (m((v ushr 24) and 0xFF) shl 24) or (m((v shr 16) and 0xFF) shl 16) or
                    (m((v shr 8) and 0xFF) shl 8) or m(v and 0xFF)
            }
        }
        clipboard = Clip(x0, y0, cw, ch, px)
        if (cut) clearLayer()
        return true
    }

    /** Pastes the clipboard into `l` at its original position. */
    fun paste(l: PixLayer) {
        val c = clipboard ?: return
        val d = doc!!
        val W = d.w
        for (y in 0 until c.h) {
            if (c.y + y < 0 || c.y + y >= d.h) continue
            System.arraycopy(c.px, y * c.w, l.px, (c.y + y) * W + c.x, min(c.w, W - c.x))
        }
        l.dirty = true
        d.activeId = l.meta.id
        invalidateCaches()
        onChanged?.invoke()
    }
}

// MARK: - helpers --------------------------------------------------------------------------

/** DrawingCanvas.swift argbFrom: UIColor → 0xAARRGGBB Int. */
fun argbFrom(c: Int): Int = c or (0xFF shl 24)

/** Drawing → a new video-editor project (one full-canvas image layer per drawing layer,
 *  folders become group layers). (DrawingEditorViewController.swift DrawExport.) */
object DrawExport {
    fun toProject(item: DrawItem, done: (String?) -> Unit) {
        Thread {
            val project = Project(name = item.name, w = item.w, h = item.h, fps = 30)
            val scene = project.scenes[0]
            var ok = true
            val groups = HashMap<String, Layer>()
            val groupOrder = ArrayList<String>()
            fun group(pid: String): Layer? {
                groups[pid]?.let { return it }
                val fm = item.layers.firstOrNull { it.id == pid } ?: return null
                val ng = Layer(project.nextId, fm.name, LayerType.GROUP)
                project.nextId += 1
                ng.end = scene.duration
                ng.visible = fm.visible
                ng.track("opacity").base = fm.opacity
                groups[pid] = ng; groupOrder.add(pid)
                val pp = fm.parent
                if (pp != null) { val pg = group(pp); if (pg != null) ng.parentId = pg.id }
                return ng
            }
            fun addImage(png: ByteArray, name: String, visible: Boolean, parent: String?, opacity: Float = 1f) {
                val path = ProjectIO.writeDataIntoSandbox(png, "${scene.layers.size + 1}_$name.png")
                if (path == null) { ok = false; return }
                val l = Layer(project.nextId, name, LayerType.IMAGE)
                project.nextId += 1
                l.imagePath = path
                l.end = scene.duration
                l.visible = visible
                l.track("opacity").base = opacity
                if (parent != null) { val g = group(parent); if (g != null) l.parentId = g.id }
                scene.layers.add(l)
            }
            if (item.paperWhite) {
                try {
                    val bmp = Bitmap.createBitmap(item.w, item.h, Bitmap.Config.ARGB_8888)
                    val c = Canvas(bmp)
                    c.drawColor(0xFFFFFFFF.toInt())
                    val out = java.io.ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                    addImage(out.toByteArray(), "Paper", visible = true, parent = null)
                } catch (_: Exception) { ok = false }
            }
            for (m in item.layers) if (!m.isFolder) {
                val data = try { DrawStore.layerFile(item.id, m.id).readBytes() } catch (_: Exception) { null } ?: continue
                addImage(data, m.name, m.visible, m.parent, m.opacity)
                if (!ok) break
            }
            for (pid in groupOrder) { groups[pid]?.let { scene.layers.add(it) } }
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                if (!ok) { done(null); return@post }
                Projects.save(project)
                done(project.id)
            }
        }.start()
    }
}
