@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import com.saiki.motion.app.DocPicker
import com.saiki.motion.core.AnimeDecomposer
import com.saiki.motion.core.DecomposedLayer
import com.saiki.motion.core.DrawItem
import com.saiki.motion.core.DrawStore
import com.saiki.motion.core.DrawingArchive
import com.saiki.motion.core.Paths
import com.saiki.motion.core.Prefs
import com.saiki.motion.core.PSDWriter
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIAlertAction
import com.saiki.motion.uikit.UIAlertActionStyle
import com.saiki.motion.uikit.UIAlertController
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UITableView
import com.saiki.motion.uikit.UITableViewCell
import com.saiki.motion.uikit.UITableViewDataSource
import com.saiki.motion.uikit.UITableViewDelegate
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UiImageView
import com.saiki.motion.uikit.appContext
import org.json.JSONObject
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

// Port of Sources/Tools/DrawingEditorViewController.swift — the paint screen of the Drawing Editor.
// Ibis-Paint-style layout in the editor's dark / orange theme: top bar (undo / redo / send to
// editor), canvas, two sliders (size + opacity), bottom bar (tool, color, layers).
// Long-press on the canvas = eyedropper. Layer panel: add, folder, rename, duplicate, merge,
// reorder, opacity, background.
// PHPicker / UIActivityViewController / drag-to-reorder ride the Android pickers, share hook
// and long-press menus — PORT NOTE.

// MARK: - small widgets -----------------------------------------------------------------

class DrawBtn(icon: String? = null, var symbol: String? = null, var title: String? = null, action: (() -> Unit)? = null) : TapView() {
    var icon: String? = icon
        set(v) { field = v; setNeedsDisplay() }
    var tint: Int = C.TEXT
        set(v) { field = v; setNeedsDisplay() }
    var active = false
        set(v) { field = v; setNeedsDisplay() }

    init {
        setBackgroundColor(0x00000000)
        onClick = action
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val col = if (isHighlighted || active) C.GREEN else tint
        val hasGlyph = icon != null || symbol != null
        val gy = if (title != null && hasGlyph) rect.midY - 8f else rect.midY
        val i = icon
        if (i != null) Icons.draw(c, i, rect.midX, gy, 22f, col)
        if (title != null) {
            val t = title!!
            if (hasGlyph) com.saiki.motion.uikit.drawText(t, rect.midX, rect.maxY - 7f, color = col, size = 10f, bold = true, align = NSTextAlignment.center)
            else com.saiki.motion.uikit.drawText(t, rect.midX, rect.midY + 5f, color = col, size = 13f, bold = true, align = NSTextAlignment.center)
        }
    }
}

private class DrawSliderRow : UiView(appContext!!) {
    val label = UILabel()
    val minus = DrawBtn(title = "−")
    val plus = DrawBtn(title = "+")
    val slider = UISlider()
    var onChange: ((Float) -> Unit)? = null
    var format: (Float) -> String = { (it * 100).toInt().toString() }

    init {
        label.font = UIFont.monospacedDigitSystemFont(15f, 600)
        label.textColor = UIColor(C.TEXT)
        label.textAlignment = NSTextAlignment.right
        slider.onValueChanged = { changed() }
        for (b in listOf(minus, plus)) {
            b.setBackgroundColor(C.CARD2)
            b.tint = C.TEXT
        }
        minus.onClick = { nudge(-0.02f) }
        plus.onClick = { nudge(0.02f) }
        addSubview(label); addSubview(minus); addSubview(slider); addSubview(plus)
    }

    fun set(v: Float) { slider.value = v; label.text = format(v) }
    private fun nudge(d: Float) { set(max(0f, min(1f, slider.value + d))); onChange?.invoke(slider.value) }
    private fun changed() { label.text = format(slider.value); onChange?.invoke(slider.value) }

    override fun layoutSubviews() {
        super.layoutSubviews()
        val h = rectHeight()
        label.frame = CGRect(8f, 0f, 46f, h)
        minus.frame = CGRect(60f, (h - 30f) / 2f, 30f, 30f)
        plus.frame = CGRect(rectWidth() - 40f, (h - 30f) / 2f, 30f, 30f)
        slider.frame = CGRect(98f, 0f, rectWidth() - 98f - 48f, h)
    }
}

private class LayerCell : UITableViewCell() {
    val eye = DrawBtn(icon = "eye")
    val thumb = UiImageView()
    val name = UILabel()
    val info = UILabel()
    val chev = DrawBtn(icon = "chev_down")
    var indent = 0f

    init {
        setBackgroundColor(0x00000000)
        thumb.contentMode = com.saiki.motion.uikit.UIViewContentMode.scaleAspectFit
        thumb.setBackgroundColor(C.CARD2)
        name.font = UIFont.semiboldSystemFont(15f); name.textColor = UIColor(C.TEXT)
        info.font = UIFont.systemFont(11f); info.textColor = UIColor(C.DIM)
        addSubview(eye); addSubview(thumb); addSubview(name); addSubview(info); addSubview(chev)
    }

    override fun layoutSubviews() {
        super.layoutSubviews()
        val h = rectHeight(); val w = rectWidth()
        eye.frame = CGRect(2f, 0f, 40f, h)
        thumb.frame = CGRect(46f + indent, 7f, h - 14f, h - 14f)
        val tx = thumb.frame.maxX + 10f
        name.frame = CGRect(tx, 9f, w - tx - 48f, 20f)
        info.frame = CGRect(tx, 31f, w - tx - 48f, 16f)
        chev.frame = CGRect(w - 44f, 0f, 40f, h)
    }
}

// MARK: - editor -------------------------------------------------------------------------

class DrawingEditorViewController(val item: DrawItem) : UIViewController(),
    UITableViewDataSource, UITableViewDelegate {
    val doc = DrawDoc(item)
    /** Direct-edit mode (from the video editor): "Save" hands the flattened picture back through this. */
    var onApply: ((Bitmap) -> Unit)? = null
    private val canvas = DrawingCanvasView()
    private val top = UiView(); private val bottom = UiView(); private val sliders = UiView(); private val xfBar = UiView()
    private val titleBtn = DrawBtn()
    private val undoBtn = DrawBtn(icon = "undo"); private val redoBtn = DrawBtn(icon = "redo")
    private val brushBtn = DrawBtn(); private val eraserBtn = DrawBtn(); private val lockBtn = DrawBtn()
    private var brushStyle = BrushStyle()
    private var eraserStyle = BrushStyle.eraserPresets[0]
    private var curStyle: BrushStyle
        get() = if (tool == DrawTool.eraser) eraserStyle else brushStyle
        set(v) { if (tool == DrawTool.eraser) eraserStyle = v else brushStyle = v }
    private val curPresets: List<BrushStyle> get() = if (tool == DrawTool.eraser) BrushStyle.eraserPresets else BrushStyle.presets
    private val selBadge = UILabel()
    private val toolBtn = DrawBtn(); private val colorBtn = TapView(); private val layersBtn = DrawBtn(); private val fitBtn = DrawBtn(icon = "fit")
    private val sizeRow = DrawSliderRow(); private val opRow = DrawSliderRow(); private val blurRow = DrawSliderRow()
    private val dot = UiView()
    private var dotTimer: java.util.Timer? = null
    private var panel: UiView? = null
    private var panelKind = 0                  // 0 none, 1 tools, 2 color, 3 layers, 4 brush, 5 selection
    private var table: UITableView? = null
    private var rows = ArrayList<Pair<PixLayer, Int>>()
    private val thumbs = HashMap<String, Bitmap>()
    private var tool = DrawTool.brush
    private var curColor = C.TEXT
    private var sizeNorm = 0.2f
    private var opNorm = 1f
    private var layerOpSlider: UISlider? = null
    private var layerOpLabel: UILabel? = null

    private val backBtn = DrawBtn(icon = "back"); private val moreBtn = DrawBtn(icon = "more"); private val sendBtn = DrawBtn(icon = "export")
    private val xfCancel = DrawBtn(title = "Cancel"); private val xfApply = DrawBtn(title = "Apply")

    // MARK: lifecycle

    override fun viewDidLoad() {
        canvas.lockAlpha = false                          // brush paints transparent pixels (toggle in Tools to lock)
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        val ud = Prefs
        curColor = ud.getInt("draw.color", 0xFF000000.toInt())
        ud.getString("draw.size", null)?.toFloatOrNull()?.let { sizeNorm = it }
        ud.getString("draw.op", null)?.toFloatOrNull()?.let { opNorm = it }
        ud.getString("draw.style", null)?.let { s -> try { brushStyle = BrushStyle.fromJson(JSONObject(s)) } catch (_: Exception) {} }
        ud.getString("draw.estyle", null)?.let { s -> try { eraserStyle = BrushStyle.fromJson(JSONObject(s)) } catch (_: Exception) {} }
        canvas.style = brushStyle
        canvas.eraserStyle = eraserStyle
        canvas.doc = doc
        view.addSubview(canvas)
        canvas.onColorPicked = { c -> setColor(argbFrom(c), remember = false) }
        canvas.onChanged = { afterEdit() }
        canvas.onTransformState = { on -> refreshXf(on) }
        canvas.onBlocked = { msg -> Toast.show(msg) }
        canvas.onSelectionChanged = { refreshSelUI() }
        selBadge.font = UIFont.boldSystemFont(12f); selBadge.textColor = UIColor(0xFFFFFFFF.toInt())
        selBadge.setBackgroundColor(0xE63366FF.toInt())
        selBadge.textAlignment = NSTextAlignment.center
        selBadge.isHidden = true; selBadge.isUserInteractionEnabled = false
        view.addSubview(selBadge)
        dot.setBackgroundColor(0x40000000.toInt())
        dot.isHidden = true; dot.isUserInteractionEnabled = false
        view.addSubview(dot)

        buildTop(); buildBottom(); buildSliders(); buildXfBar()
        setTool(DrawTool.brush)
        setColor(curColor, remember = false)
        applyBrushValues()
        afterEdit()
    }

    override fun viewWillAppear(animated: Boolean) {
        super.viewWillAppear(animated)
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        val w = view.rectWidth(); val sa = view.safeAreaInsets
        val topH = 52f + sa.top
        val botH = 62f + max(sa.bottom, 6f)
        top.frame = CGRect(0f, 0f, w, topH)
        bottom.frame = CGRect(0f, view.rectHeight() - botH, w, botH)
        sliders.frame = CGRect(0f, bottom.frame.minY - 130f, w, 130f)
        xfBar.frame = sliders.frame
        canvas.frame = CGRect(0f, topH, w, sliders.frame.minY - topH)

        val bt = top.rectWidth()
        val y = sa.top
        for ((i, b) in listOf(backBtn, undoBtn, redoBtn).withIndex()) b.frame = CGRect(6f + i * 46f, y + 4f, 44f, 44f)
        moreBtn.frame = CGRect(bt - 50f, y + 4f, 44f, 44f)
        sendBtn.frame = CGRect(bt - 96f, y + 4f, 44f, 44f)
        titleBtn.frame = CGRect(150f, y + 4f, bt - 150f - 100f, 44f)

        val bw = bottom.rectWidth()
        val bwid = bw / 7f
        brushBtn.frame = CGRect(0f, 4f, bwid, 54f)
        eraserBtn.frame = CGRect(bwid, 4f, bwid, 54f)
        colorBtn.frame = CGRect(2 * bwid + (bwid - 44f) / 2f, 9f, 44f, 44f)
        toolBtn.frame = CGRect(3 * bwid, 4f, bwid, 54f)
        fitBtn.frame = CGRect(4 * bwid, 4f, bwid, 54f)
        lockBtn.frame = CGRect(5 * bwid, 4f, bwid, 54f)
        layersBtn.frame = CGRect(6 * bwid, 4f, bwid, 54f)

        sizeRow.frame = CGRect(0f, 4f, w, 40f)
        opRow.frame = CGRect(0f, 46f, w, 40f)
        blurRow.frame = CGRect(0f, 88f, w, 40f)
        xfCancel.frame = CGRect(20f, 22f, w / 2f - 30f, 44f)
        xfApply.frame = CGRect(w / 2f + 10f, 22f, w / 2f - 30f, 44f)
        selBadge.frame = CGRect(12f, canvas.frame.minY + 8f, min(w - 24f, 330f), 22f)
        layoutPanel()
    }

    // MARK: building

    private fun buildTop() {
        top.setBackgroundColor(C.PANEL)
        view.addSubview(top)
        backBtn.onClick = { goBack() }
        undoBtn.onClick = { canvas.undo() }
        redoBtn.onClick = { canvas.redo() }
        sendBtn.onClick = { sendToEditor() }
        moreBtn.onClick = { moreMenu() }
        titleBtn.onClick = { renameArt() }
        for (b in listOf(backBtn, undoBtn, redoBtn, titleBtn, sendBtn, moreBtn)) top.addSubview(b)
        sendBtn.tint = C.GREEN
        if (onApply != null) { sendBtn.icon = null; sendBtn.title = "Save" }   // direct mode: Save = apply to comp
    }

    private fun buildBottom() {
        bottom.setBackgroundColor(C.PANEL)
        view.addSubview(bottom)
        brushBtn.icon = "brush"; brushBtn.title = "Brush"
        brushBtn.onClick = {
            if (tool == DrawTool.brush) togglePanel(4) else { closePanel(); setTool(DrawTool.brush) }
        }
        eraserBtn.icon = "eraser"; eraserBtn.title = "Eraser"
        eraserBtn.onClick = {
            if (tool == DrawTool.eraser) togglePanel(4) else { closePanel(); setTool(DrawTool.eraser) }
        }
        toolBtn.onClick = { togglePanel(1) }
        colorBtn.onClick = { togglePanel(2) }
        colorBtn.setBackgroundColor(curColor)
        layersBtn.icon = "layers"; layersBtn.title = "Layers"
        layersBtn.onClick = { togglePanel(3) }
        lockBtn.icon = "layers"; lockBtn.title = if (canvas.lockAlpha) "Transparent pixels: Locked" else "Transparent pixels: Paintable"
        lockBtn.onClick = {
            canvas.lockAlpha = !canvas.lockAlpha; lockBtn.active = canvas.lockAlpha
            lockBtn.title = if (canvas.lockAlpha) "Transparent pixels: Locked" else "Transparent pixels: Paintable"
            Toast.show(if (canvas.lockAlpha) "Transparent pixels are locked — brush and smudge keep the shape" else "Transparent pixels can be painted")
        }
        fitBtn.title = "Fit"
        fitBtn.onClick = { canvas.fit() }
        for (b in listOf(brushBtn, eraserBtn, colorBtn, toolBtn, fitBtn, lockBtn, layersBtn)) bottom.addSubview(b)
    }

    private fun buildSliders() {
        sliders.setBackgroundColor(0xF51C1C22.toInt())
        view.addSubview(sliders)
        sizeRow.format = { v -> sizeFor(v).roundToInt().toString() }
        sizeRow.onChange = { v -> sizeNorm = v; applyBrushValues(); showDot() }
        opRow.onChange = { v -> opNorm = v; applyBrushValues() }
        blurRow.onChange = { v ->
            curStyle.hardness = v; curStyle.name = "Custom"; applyStyle()
        }
        val cap = UILabel(); cap.text = "BLUR"; cap.font = UIFont.boldSystemFont(9f)
        cap.textColor = UIColor(C.DIM); cap.frame = CGRect(10f, 0f, 44f, 12f); cap.textAlignment = NSTextAlignment.right
        blurRow.addSubview(cap)
        sliders.addSubview(sizeRow); sliders.addSubview(opRow); sliders.addSubview(blurRow)
        blurRow.set(curStyle.hardness)
        sizeRow.set(sizeNorm); opRow.set(opNorm)
    }

    private fun buildXfBar() {
        xfBar.setBackgroundColor(C.PANEL)
        xfBar.isHidden = true
        view.addSubview(xfBar)
        xfCancel.tint = C.TEXT
        xfApply.tint = C.GREEN
        xfCancel.onClick = { canvas.cancelTransform() }
        xfApply.onClick = { canvas.applyTransform() }
        xfBar.addSubview(xfCancel); xfBar.addSubview(xfApply)
        val hint = UILabel()
        hint.text = "Drag to move · pinch to scale · rotate with two fingers"
        hint.font = UIFont.systemFont(11f); hint.textColor = UIColor(C.DIM)
        hint.textAlignment = NSTextAlignment.center
        hint.frame = CGRect(0f, 2f, 600f, 18f)
        xfBar.addSubview(hint)
    }

    private fun refreshXf(on: Boolean) { xfBar.isHidden = tool != DrawTool.transform; sliders.isHidden = tool == DrawTool.transform }

    // MARK: tool / color / values

    private fun sizeFor(n: Float): Float = 1f + n.pow(2.2f) * 399f

    private fun applyBrushValues() {
        canvas.brushSize = sizeFor(sizeNorm)
        canvas.opacity = opNorm
        sizeRow.set(sizeNorm); opRow.set(opNorm)
        Prefs.setString("draw.size", sizeNorm.toString())
        Prefs.setString("draw.op", opNorm.toString())
    }

    private fun showDot() {
        val d = max(4f, min(260f, canvas.brushSize * canvas.zoomScale))
        dot.frame = CGRect(canvas.frame.midX - d / 2f, canvas.frame.midY - d / 2f, d, d)
        dot.isHidden = false
        dotTimer?.cancel()
        dotTimer = java.util.Timer()
        dotTimer?.schedule(object : java.util.TimerTask() {
            override fun run() {
                android.os.Handler(android.os.Looper.getMainLooper()).post { dot.isHidden = true }
            }
        }, 800)
    }

    private fun setSelectionMode(on: Boolean) {
        canvas.selectionMode = on
        if (on && tool !in listOf(DrawTool.brush, DrawTool.eraser, DrawTool.wand)) setTool(DrawTool.brush)
        refreshSelUI()
        if (panelKind == 3) reloadRows()
    }

    private fun refreshSelUI() {
        val has = doc.selHas
        selBadge.isHidden = !canvas.selectionMode
        selBadge.text = "SELECTION LAYER · " + (if (has) "Existing" else "No Selection") + " · blue paint"
        if (panelKind == 3) updateSelRow()
        if (panelKind == 5) updateSelPanel()
    }

    private fun setTool(t: DrawTool) {
        if ((t == DrawTool.smudge || t == DrawTool.transform) && canvas.selectionMode) setSelectionMode(false)
        tool = t
        canvas.tool = t
        val names = mapOf(
            DrawTool.brush to ("brush" to "Brush"), DrawTool.eraser to ("eraser" to "Eraser"),
            DrawTool.smudge to ("smudge" to "Smudge"), DrawTool.eyedropper to ("pipette" to "Pick"),
            DrawTool.transform to ("move" to "Transform"), DrawTool.wand to ("wand" to "Wand"))
        brushBtn.active = t == DrawTool.brush
        eraserBtn.active = t == DrawTool.eraser
        if (t == DrawTool.brush || t == DrawTool.eraser) blurRow.set(curStyle.hardness)
        if (t == DrawTool.brush || t == DrawTool.eraser) { toolBtn.icon = "more"; toolBtn.title = "Tools" }
        else if (t == DrawTool.wand) { toolBtn.icon = "wand"; toolBtn.title = "Wand" }
        else { toolBtn.icon = names[t]?.first; toolBtn.title = names[t]?.second }
        toolBtn.tint = C.TEXT
        refreshXf(false)
        if (t == DrawTool.transform && doc.active == null) Toast.show("Select a layer first")
    }

    private fun setColor(c: Int, remember: Boolean) {
        curColor = c or (0xFF shl 24)
        canvas.color = curColor
        colorBtn.setBackgroundColor(curColor)
        Prefs.setInt("draw.color", curColor)
        if (remember) {
            val r = (Prefs.getString("draw.recent", "") ?: "").split(",").filter { it.isNotEmpty() }
                .mapNotNull { it.toIntOrNull() }.toMutableList()
            r.removeAll { it == curColor }
            r.add(0, curColor)
            Prefs.setString("draw.recent", r.take(12).joinToString(","))
        }
    }

    private fun recentColors(): List<Int> =
        (Prefs.getString("draw.recent", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }

    private fun afterEdit() {
        undoBtn.alpha = if (canvas.canUndo) 1f else 0.35f
        redoBtn.alpha = if (canvas.canRedo) 1f else 0.35f
        titleBtn.title = doc.item.name
        layersBtn.title = "Layers · " + doc.layers.count { !it.meta.isFolder }
        doc.active?.let { thumbs.remove(it.meta.id) }
        if (panelKind == 3) reloadRows()
        refreshSelUI()
    }

    // MARK: panels

    private fun togglePanel(k: Int) {
        val was = panelKind
        closePanel()
        if (was == k) return
        panelKind = k
        val p = UiView()
        p.setBackgroundColor(C.CARD)
        p.clipsToBounds = true
        view.addSubview(p)
        panel = p
        when (k) {
            1 -> buildToolsPanel(p)
            2 -> buildColorPanel(p)
            4 -> buildBrushPanel(p)
            5 -> buildSelPanel(p)
            else -> buildLayersPanel(p)
        }
        layoutPanel()
    }

    private fun closePanel() {
        panel?.removeFromSuperview(); panel = null; table = null
        panelKind = 0
    }

    private fun layoutPanel() {
        val p = panel ?: return
        val w = view.rectWidth()
        val bottomY = bottom.frame.minY - 6f
        when (panelKind) {
            1 -> p.frame = CGRect(10f, bottomY - 360f, min(260f, w - 20f), 360f)
            5 -> p.frame = CGRect(10f, bottomY - 450f, w - 20f, 450f)
            2 -> p.frame = CGRect(10f, bottomY - 360f, w - 20f, 360f)
            4 -> { val hh = min(bottomY - top.frame.maxY - 8f, 462f); p.frame = CGRect(10f, bottomY - hh, w - 20f, hh) }
            else -> {
                val h = min(view.rectHeight() * 0.62f, 520f)
                p.frame = CGRect(10f, bottomY - h, w - 20f, h)
            }
        }
        if (panelKind == 3) layoutLayerPanel(p)
        if (panelKind == 2) layoutColorPanel(p)
        if (panelKind == 1) layoutToolsPanel(p)
        if (panelKind == 4) layoutBrushPanel(p)
        if (panelKind == 5) layoutSelPanel(p)
    }

    // tools ------------------------------------------------------------------------------

    private val toolDefs: List<Triple<DrawTool, String, String>> = listOf(
        Triple(DrawTool.brush, "brush", "Brush"), Triple(DrawTool.eraser, "eraser", "Eraser"),
        Triple(DrawTool.smudge, "smudge", "Smudge"), Triple(DrawTool.smudge, "smudge", "Blur"), Triple(DrawTool.eyedropper, "pipette", "Eyedropper"),
        Triple(DrawTool.transform, "move", "Transform"), Triple(DrawTool.wand, "wand", "Magic Wand"),
        Triple(DrawTool.brush, "select", "Selection"))

    private fun buildToolsPanel(p: UiView) {
        for ((i, d) in toolDefs.withIndex()) {
            val isSelBtn = d.third == "Selection"
            val b = DrawBtn(icon = d.second, title = d.third) {
                closePanel()
                if (isSelBtn) togglePanel(5) else { canvas.blurMode = d.third == "Blur"; setTool(d.first) }
            }
            b.active = !isSelBtn && d.first == tool && (d.first != DrawTool.smudge || (d.third == "Blur") == canvas.blurMode)
            b.setTag(100 + i)
            p.addSubview(b)
        }
        val hint = UILabel()
        hint.text = "Hold the canvas to pick a color"
        hint.font = UIFont.systemFont(11f); hint.textColor = UIColor(C.DIM)
        hint.tag = 99; hint.textAlignment = NSTextAlignment.center
        p.addSubview(hint)
    }

    private fun layoutToolsPanel(p: UiView) {
        val cw = p.rectWidth() / 2f
        for (i in 0 until toolDefs.size) {
            p.findViewWithTag(100 + i)?.frame = CGRect((i % 2) * cw, 8f + (i / 2) * 64f, cw, 62f)
        }
        p.findViewWithTag(99)?.frame = CGRect(0f, p.rectHeight() - 30f, p.rectWidth(), 20f)
    }

    // brush panel ------------------------------------------------------------------------

    private fun applyStyle() {
        canvas.style = brushStyle
        canvas.eraserStyle = eraserStyle
        Prefs.setString("draw.style", brushStyle.toJson().toString())
        Prefs.setString("draw.estyle", eraserStyle.toJson().toString())
    }

    private val styleNames = listOf("Radius blur", "Spacing", "Scatter", "Grain", "Size jitter", "Pressure size",
        "Pressure opacity", "Tip start", "Tip end")

    private fun styleValue(i: Int): Float {
        val st = curStyle
        return when (i) {
            0 -> st.hardness
            1 -> min(1f, max(0f, (st.spacing - 0.03f) / 0.6f))
            2 -> st.scatter
            3 -> st.grain
            4 -> st.sizeJitter
            5 -> st.pressureSize
            6 -> st.pressureOpacity
            7 -> st.tipStart
            else -> st.tipEnd
        }
    }

    private fun setStyleValue(i: Int, v: Float) {
        when (i) {
            0 -> curStyle.hardness = v
            1 -> curStyle.spacing = 0.03f + v * 0.6f
            2 -> curStyle.scatter = v
            3 -> curStyle.grain = v
            4 -> curStyle.sizeJitter = v
            5 -> curStyle.pressureSize = v
            6 -> curStyle.pressureOpacity = v
            7 -> curStyle.tipStart = v
            else -> curStyle.tipEnd = v
        }
        curStyle.name = "Custom"
        applyStyle()
        if (i == 0) blurRow.set(v)
    }

    private fun buildBrushPanel(p: UiView) {
        for ((i, ps) in curPresets.withIndex()) {
            val b = DrawBtn(title = ps.name) {
                curStyle = ps.copy(); applyStyle(); blurRow.set(ps.hardness); closePanel(); togglePanel(4)
            }
            b.setTag(400 + i)
            b.active = ps.name == curStyle.name
            b.setBackgroundColor(C.CARD2)
            p.addSubview(b)
        }
        val sq = DrawBtn(title = if (curStyle.square) "Tip: Square  (tap for Round)" else "Tip: Round  (tap for Square)") {
            curStyle.square = !curStyle.square; curStyle.name = "Custom"; applyStyle(); closePanel(); togglePanel(4)
        }
        sq.setTag(420)
        sq.setBackgroundColor(C.CARD2)
        p.addSubview(sq)
        for ((i, n) in styleNames.withIndex()) {
            val l = UILabel(); l.text = n; l.setTag(430 + i)
            l.font = UIFont.semiboldSystemFont(12f); l.textColor = UIColor(C.TEXT)
            p.addSubview(l)
            val r = DrawSliderRow(); r.setTag(440 + i)
            r.set(styleValue(i))
            r.onChange = { v -> setStyleValue(i, v) }
            p.addSubview(r)
        }
    }

    private fun layoutBrushPanel(p: UiView) {
        val w = p.rectWidth()
        val n = curPresets.size
        val perRow = 4
        val cw = (w - 16f) / perRow
        for (i in 0 until n) {
            p.findViewWithTag(400 + i)?.frame = CGRect(8f + (i % perRow) * cw + 2f, 8f + (i / perRow) * 40f, cw - 4f, 36f)
        }
        val rows = (n + perRow - 1) / perRow
        val y0 = 8f + rows * 40f + 2f
        p.findViewWithTag(420)?.frame = CGRect(10f, y0, w - 20f, 32f)
        for (i in 0 until styleNames.size) {
            val y = y0 + 38f + i * 34f
            p.findViewWithTag(430 + i)?.frame = CGRect(12f, y, 92f, 34f)
            p.findViewWithTag(440 + i)?.frame = CGRect(100f, y, w - 108f, 34f)
        }
    }

    // selection panel ---------------------------------------------------------------------

    private fun selBtn(p: UiView, tag: Int, title: String, act: () -> Unit) {
        val b = DrawBtn(title = title) { act() }
        b.setTag(tag); b.setBackgroundColor(C.CARD2)
        p.addSubview(b)
    }

    private fun buildSelPanel(p: UiView) {
        val t = UILabel(); t.setTag(500); t.font = UIFont.boldSystemFont(16f); t.textColor = UIColor(C.TEXT); p.addSubview(t)
        val hint = UILabel(); hint.setTag(501); hint.numberOfLines = 0
        hint.font = UIFont.systemFont(11f); hint.textColor = UIColor(C.DIM)
        hint.text = "On the Selection Layer: Brush paints blue selection, Eraser removes it, Wand adds to it. On any other layer, painting only affects the selected area."
        p.addSubview(hint)
        selBtn(p, 510, "") { setSelectionMode(!canvas.selectionMode); updateSelPanel() }
        selBtn(p, 511, "Magic Wand") { closePanel(); setTool(DrawTool.wand) }
        selBtn(p, 512, "Invert Selection") { canvas.invertSelection() }
        selBtn(p, 513, "Remove Selection") { canvas.removeSelection() }
        selBtn(p, 514, "Clear Layer") { canvas.clearLayer() }
        selBtn(p, 515, "Select Opacity") { canvas.selectOpacity() }
        selBtn(p, 518, "Cut") { clipAction(cut = true) }
        selBtn(p, 519, "Copy") { clipAction(cut = false) }
        selBtn(p, 522, "Paste") { pasteAction() }
        selBtn(p, 516, "") { canvas.wandContiguous = !canvas.wandContiguous; updateSelPanel() }
        selBtn(p, 517, "") { canvas.wandSubtract = !canvas.wandSubtract; updateSelPanel() }
        val tl = UILabel(); tl.setTag(520); tl.text = "Wand tolerance"
        tl.font = UIFont.semiboldSystemFont(12f); tl.textColor = UIColor(C.TEXT); p.addSubview(tl)
        val r = DrawSliderRow(); r.setTag(521)
        r.format = { (it * 128).toInt().toString() }
        r.set(canvas.wandTolerance / 128f)
        r.onChange = { v -> canvas.wandTolerance = (v * 128).toInt() }
        p.addSubview(r)
        updateSelPanel()
    }

    private fun clipAction(cut: Boolean) {
        if (canvas.copySelection(cut)) Toast.show(if (cut) "Cut" else "Copied")
    }

    private fun pasteAction() {
        if (DrawingCanvasView.clipboard == null) { Toast.show("Nothing to paste"); return }
        val l = doc.addLayer(name = "Pasted")
        canvas.paste(l)
        reloadRows(); afterEdit()
    }

    private fun updateSelPanel() {
        val p = panel ?: return
        if (panelKind != 5) return
        (p.findViewWithTag(500) as? UILabel)?.text = "Selection Layer: " + (if (doc.selHas) "Existing" else "No Selection")
        (p.findViewWithTag(510) as? DrawBtn)?.title = if (canvas.selectionMode) "Editing Selection Layer (tap to leave)" else "Edit Selection Layer (blue paint)"
        (p.findViewWithTag(510) as? DrawBtn)?.active = canvas.selectionMode
        (p.findViewWithTag(516) as? DrawBtn)?.title = if (canvas.wandContiguous) "Wand: Same area only" else "Wand: Whole layer (Color Range)"
        (p.findViewWithTag(517) as? DrawBtn)?.title = if (canvas.wandSubtract) "Wand mode: Subtract" else "Wand mode: Add"
    }

    private fun layoutSelPanel(p: UiView) {
        val w = p.rectWidth(); val half = (w - 30f) / 2f
        p.findViewWithTag(500)?.frame = CGRect(14f, 10f, w - 28f, 24f)
        p.findViewWithTag(501)?.frame = CGRect(14f, 36f, w - 28f, 48f)
        p.findViewWithTag(510)?.frame = CGRect(10f, 90f, w - 20f, 40f)
        p.findViewWithTag(511)?.frame = CGRect(10f, 136f, w - 20f, 40f)
        val grid = listOf(Triple(512, 0, 0), Triple(513, 1, 0), Triple(514, 0, 1), Triple(515, 1, 1))
        for ((tag, c, r) in grid) {
            p.findViewWithTag(tag)?.frame = CGRect(10f + c * (half + 10f), 182f + r * 46f, half, 40f)
        }
        val third = (w - 40f) / 3f
        for ((i, tag) in listOf(518, 519, 522).withIndex()) {
            p.findViewWithTag(tag)?.frame = CGRect(10f + i * (third + 10f), 274f, third, 40f)
        }
        p.findViewWithTag(516)?.frame = CGRect(10f, 320f, w - 20f, 36f)
        p.findViewWithTag(517)?.frame = CGRect(10f, 360f, w - 20f, 36f)
        p.findViewWithTag(520)?.frame = CGRect(12f, 402f, 90f, 34f)
        p.findViewWithTag(521)?.frame = CGRect(100f, 402f, w - 108f, 34f)
    }

    // color ------------------------------------------------------------------------------

    private val colorPicker = ColorPickerView()

    private fun buildColorPanel(p: UiView) {
        colorPicker.setColor(curColor)
        colorPicker.onChange = { c -> setColor(c, remember = false) }
        p.addSubview(colorPicker)
        for ((i, c) in recentColors().withIndex()) {
            val sw = TapView()
            sw.setTag(200 + i)
            sw.setBackgroundColor(c)
            sw.onClick = {
                setColor(c, remember = false)
                colorPicker.setColor(c)
            }
            p.addSubview(sw)
        }
        val done = DrawBtn(title = "Save color") {
            setColor(curColor, remember = true)
            closePanel()
        }
        done.tint = C.GREEN; done.setTag(190)
        p.addSubview(done)
    }

    private fun layoutColorPanel(p: UiView) {
        colorPicker.frame = CGRect(14f, 14f, p.rectWidth() - 28f, 250f)
        val n = recentColors().size
        val size = 30f; val gap = 8f
        for (i in 0 until n) {
            p.findViewWithTag(200 + i)?.frame = CGRect(14f + i * (size + gap), 278f, size, size)
        }
        p.findViewWithTag(190)?.frame = CGRect(p.rectWidth() - 130f, p.rectHeight() - 48f, 120f, 40f)
    }

    // layers -----------------------------------------------------------------------------

    private fun buildLayersPanel(p: UiView) {
        val hdr = UILabel(); hdr.text = "Layer"; hdr.setTag(300)
        hdr.font = UIFont.boldSystemFont(17f); hdr.textColor = UIColor(C.TEXT)
        p.addSubview(hdr)
        val t = UITableView()
        t.setBackgroundColor(0x00000000)
        t.dataSource = this; t.delegate = this
        t.rowHeight = 58f
        p.addSubview(t); table = t

        val acts = listOf(
            Triple("plus", "Layer") { plusMenu() },
            Triple("folder", "Folder") { addLayer(folder = true) },
            Triple("dup", "Copy") { dupLayer() },
            Triple("chev_up", "Up") { moveLayer(1) },
            Triple("chev_down", "Down") { moveLayer(-1) },
            Triple("trash", "Delete") { deleteLayer() })
        for ((i, a) in acts.withIndex()) {
            val b = DrawBtn(icon = a.first, title = a.second, action = a.third); b.setTag(310 + i)
            if (a.second == "Delete") b.tint = C.RED
            p.addSubview(b)
        }
        val op = UISlider()
        op.onValueChanged = { layerOpChanged(op) }
        op.setTag(330); p.addSubview(op); layerOpSlider = op
        val ol = UILabel(); ol.font = UIFont.monospacedDigitSystemFont(13f, 600)
        ol.textColor = UIColor(C.TEXT); ol.setTag(331); p.addSubview(ol); layerOpLabel = ol
        val bg = UILabel(); bg.text = "Background"; bg.font = UIFont.semiboldSystemFont(12f)
        bg.textColor = UIColor(C.DIM); bg.setTag(340); p.addSubview(bg)
        for ((i, white) in listOf(true, false).withIndex()) {
            val sw = object : TapView() {
                override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    c.setFillColor(if (white) 0xFFFFFFFF.toInt() else C.CARD2)
                    c.canvas.drawRoundRect(RectF(0f, 0f, rect.width, rect.height), 8f, 8f, c.paint)
                    if (!white) {
                        c.setFillColor(C.DIM)
                        c.canvas.drawRoundRect(RectF(2f, 2f, rect.width / 2 - 2f, rect.height / 2 - 2f), 0f, 0f, c.paint)
                        c.canvas.drawRoundRect(RectF(rect.width / 2, rect.height / 2, rect.width - 2f, rect.height - 2f), 0f, 0f, c.paint)
                    }
                    c.setStrokeColor(if (doc.item.paperWhite == white) C.GREEN else C.LINE)
                    c.setLineWidth(if (doc.item.paperWhite == white) 3f else 1f)
                    c.canvas.drawRoundRect(RectF(1f, 1f, rect.width - 2f, rect.height - 2f), 8f, 8f, c.paint)
                }
            }
            sw.setTag(341 + i)
            sw.onClick = {
                doc.item.paperWhite = white
                canvas.invalidateCaches(); closePanel(); togglePanel(3)
            }
            p.addSubview(sw)
        }
        val sr = TapView(); sr.setTag(350)
        sr.setBackgroundColor(C.CARD2)
        sr.onClick = { setSelectionMode(!canvas.selectionMode) }
        val sw = IconView("select", 0xFF3366FF.toInt(), 30f); sw.setTag(351); sw.isUserInteractionEnabled = false
        val sn = UILabel(); sn.setTag(352); sn.text = "Selection Layer"
        sn.font = UIFont.semiboldSystemFont(15f); sn.textColor = UIColor(C.TEXT)
        val si = UILabel(); si.setTag(353); si.font = UIFont.systemFont(12f); si.textColor = UIColor(C.DIM)
        for (v in listOf(sw, sn, si)) sr.addSubview(v)
        p.addSubview(sr)
        selBtn(p, 354, "Invert") { canvas.invertSelection() }
        selBtn(p, 355, "Clear") { canvas.removeSelection() }
        updateSelRow()
        reloadRows()
    }

    private fun updateSelRow() {
        val p = panel ?: return
        val sr = p.findViewWithTag(350) ?: return
        sr.setBackgroundColor(if (canvas.selectionMode) 0x473366FF.toInt() else C.CARD2)
        (sr.findViewWithTag(353) as? UILabel)?.text = (if (doc.selHas) "Existing" else "No Selection") + (if (canvas.selectionMode) " · editing" else " · tap to edit")
    }

    private fun layoutLayerPanel(p: UiView) {
        val w = p.rectWidth(); val h = p.rectHeight()
        p.findViewWithTag(300)?.frame = CGRect(16f, 10f, 120f, 28f)
        val footer = 54f + 44f + 44f
        p.findViewWithTag(350)?.frame = CGRect(8f, 40f, w - 16f, 52f)
        p.findViewWithTag(351)?.frame = CGRect(8f, 8f, 36f, 36f)
        p.findViewWithTag(352)?.frame = CGRect(54f, 5f, w - 190f, 22f)
        p.findViewWithTag(353)?.frame = CGRect(54f, 27f, w - 190f, 18f)
        p.findViewWithTag(354)?.frame = CGRect(w - 130f, 46f, 56f, 40f)
        p.findViewWithTag(355)?.frame = CGRect(w - 70f, 46f, 56f, 40f)
        table?.frame = CGRect(6f, 98f, w - 12f, h - 98f - footer)
        val bw = (w - 12f) / 6f
        for (i in 0 until 6) p.findViewWithTag(310 + i)?.frame = CGRect(6f + i * bw, h - footer + 2f, bw, 50f)
        p.findViewWithTag(330)?.frame = CGRect(16f, h - footer + 56f, w - 90f, 30f)
        p.findViewWithTag(331)?.frame = CGRect(w - 66f, h - footer + 56f, 56f, 30f)
        p.findViewWithTag(340)?.frame = CGRect(16f, h - 42f, 100f, 30f)
        p.findViewWithTag(341)?.frame = CGRect(120f, h - 42f, 44f, 30f)
        p.findViewWithTag(342)?.frame = CGRect(172f, h - 42f, 44f, 30f)
    }

    private fun reloadRows() {
        rows = ArrayList()
        fun add(parent: String?, depth: Int) {
            for (l in doc.layers.reversed()) if (l.meta.parent == parent) {
                rows.add(l to depth)
                if (l.meta.isFolder && l.meta.expanded) add(l.meta.id, depth + 1)
            }
        }
        add(null, 0)
        // orphans (parent folder missing) show at the root
        for (l in doc.layers.reversed()) {
            val p = l.meta.parent ?: continue
            if (doc.layer(p) == null && rows.none { it.first === l }) rows.add(l to 0)
        }
        table?.reloadData()
        syncLayerOpacity()
    }

    private fun syncLayerOpacity() {
        val l = doc.layers.firstOrNull { it.meta.id == doc.activeId }
        layerOpSlider?.value = l?.meta?.opacity ?: 1f
        layerOpLabel?.text = "${(((l?.meta?.opacity ?: 1f)) * 100).toInt()}%"
    }

    private fun layerOpChanged(s: UISlider) {
        val l = doc.layers.firstOrNull { it.meta.id == doc.activeId } ?: return
        l.meta.opacity = s.value
        layerOpLabel?.text = "${(s.value * 100).toInt()}%"
        canvas.invalidateCaches()
        table?.reloadData()
    }

    override fun numberOfRows(t: UITableView, section: Int): Int = rows.size

    override fun cellForRow(t: UITableView, row: Int): UITableViewCell {
        val cell = LayerCell()
        val (l, depth) = rows[row]
        cell.indent = depth * 18f
        cell.name.text = l.meta.name
        val pct = (l.meta.opacity * 100).toInt()
        cell.info.text = if (l.meta.isFolder) "Folder · " + doc.layers.count { it.meta.parent == l.meta.id } + " items" else "$pct% · Normal"
        cell.eye.icon = if (l.meta.visible) "eye" else "eye_off"
        cell.eye.tint = if (l.meta.visible) C.TEXT else C.DIM
        cell.eye.onClick = {
            l.meta.visible = !l.meta.visible; canvas.invalidateCaches(); reloadRows()
        }
        cell.chev.isHidden = !l.meta.isFolder
        cell.chev.icon = if (l.meta.expanded) "chev_down" else "chev_up"
        cell.chev.onClick = { l.meta.expanded = !l.meta.expanded; reloadRows() }
        if (l.meta.isFolder) {
            cell.thumb.image = Icons.image("folder", 30f, C.GREEN)
            cell.thumb.contentMode = com.saiki.motion.uikit.UIViewContentMode.center
            cell.thumb.setBackgroundColor((C.GREEN and 0x00FFFFFF) or 0x2EFF5A2E.toInt())
        } else {
            cell.thumb.contentMode = com.saiki.motion.uikit.UIViewContentMode.scaleAspectFit
            cell.thumb.setBackgroundColor(C.CARD2)
            thumb(l)?.let { cell.thumb.image = com.saiki.motion.uikit.UIGraphicsImageRenderer(it.width, it.height).image { c -> c.canvas.drawBitmap(it, 0f, 0f, android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)) } }
        }
        if (l.meta.id == doc.activeId && !canvas.selectionMode) cell.setBackgroundColor((C.GREEN and 0x00FFFFFF) or 0x2EFF5A2E.toInt())
        return cell
    }

    override fun didSelectRow(t: UITableView, row: Int) {
        val l = rows.getOrNull(row)?.first ?: return
        if (canvas.selectionMode) { setSelectionMode(false); doc.activeId = l.meta.id; canvas.invalidateCaches(); reloadRows(); return }
        if (doc.activeId == l.meta.id) { layerMenu(l); return }   // tap the selected layer again for its menu
        doc.activeId = l.meta.id
        canvas.invalidateCaches()
        reloadRows()
    }

    private fun thumb(l: PixLayer): Bitmap? {
        thumbs[l.meta.id]?.let { return it }
        val img = try { l.toBitmap() } catch (_: Exception) { null } ?: return null
        thumbs[l.meta.id] = img
        doc.trim(keep = null)
        return img
    }

    private fun layerMenu(l: PixLayer) {
        doc.activeId = l.meta.id; canvas.invalidateCaches()
        val sheet = UIAlertController()
        sheet.title = l.meta.name
        sheet.addAction("Rename") {
            prompt("Rename", l.meta.name) { l.meta.name = it; reloadRows(); afterEdit() }
        }
        if (!l.meta.isFolder) {
            if (doc.layers.firstOrNull() != null && doc.layers.first() !== l) {   // the bottom layer has nothing below to clip to
                sheet.addAction(if (l.meta.isClip) "Release clipping mask" else "Clipping mask (clip to layer below)") {
                    l.meta.clipToBelow = if (l.meta.isClip) null else true
                    l.dirty = true
                    canvas.invalidateCaches(); reloadRows(); afterEdit()
                    Toast.show(if (l.meta.isClip) "Clipping mask ON — shows only where the layer below has paint" else "Clipping mask released")
                }
            }
            sheet.addAction("Duplicate") { dupLayer() }
            sheet.addAction("Merge down") {
                if (!doc.mergeDown(l)) Toast.show("Nothing below to merge into")
                thumbs.clear(); canvas.invalidateCaches(); reloadRows(); afterEdit()
            }
            sheet.addAction("Clear layer") {
                // asks first and goes through the canvas so it can be undone (iOS:1013-1023)
                val ask = UIAlertController()
                ask.title = "Clear “${l.meta.name}”?"
                ask.message = "Everything on this layer is erased. Undo brings it back."
                ask.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
                ask.addAction(UIAlertAction("Clear", UIAlertActionStyle.destructive) {
                    doc.activeId = l.meta.id
                    canvas.clearLayer()
                    thumbs.remove(l.meta.id); canvas.invalidateCaches(); reloadRows()
                })
                ask.showOver(this)
            }
        }
        for (f in doc.layers) if (f.meta.isFolder && f !== l && f.meta.id != l.meta.parent) {
            // == iOS:952 — a folder can never be dropped into itself or its own descendant
            if (f === l || doc.parentChain(f).any { it === l }) continue
            sheet.addAction("Move into “${f.meta.name}”") {
                if (doc.parentChain(f).any { it === l }) { Toast.show("Can't move a folder into itself"); return@addAction }
                l.meta.parent = f.meta.id; f.meta.expanded = true; reloadRows()
            }
        }
        if (l.meta.parent != null) {
            sheet.addAction("Move out of folder") { l.meta.parent = null; reloadRows() }
        }
        sheet.addAction(UIAlertAction("Delete", UIAlertActionStyle.destructive) { deleteLayer() })
        sheet.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
        sheet.showOver(this)
    }

    private fun addLayer(folder: Boolean) {
        doc.addLayer(folder = folder)
        canvas.invalidateCaches(); reloadRows(); afterEdit()
    }

    private fun dupLayer() {
        val l = doc.active ?: return
        doc.duplicate(l); canvas.invalidateCaches(); reloadRows(); afterEdit()
    }

    private fun moveLayer(d: Int) {
        val l = doc.layers.firstOrNull { it.meta.id == doc.activeId } ?: return
        doc.move(l, d); canvas.invalidateCaches(); reloadRows()
    }

    private fun deleteLayer() {
        val l = doc.layers.firstOrNull { it.meta.id == doc.activeId } ?: return
        if (!l.meta.isFolder && doc.pixelLayerCount <= 1) {
            Toast.show("Can't delete the only layer — use “Clear layer” instead"); return
        }
        val a = UIAlertController()
        a.title = "Delete “${l.meta.name}”?"
        a.message = if (l.meta.isFolder) "The layers inside are kept and moved out." else null
        a.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
        a.addAction(UIAlertAction("Delete", UIAlertActionStyle.destructive) {
            doc.remove(l); thumbs.clear(); canvas.invalidateCaches(); reloadRows(); afterEdit()
        })
        a.showOver(this)
    }

    // MARK: menus / actions

    private fun prompt(title: String, text: String, done: (String) -> Unit) {
        val a = UIAlertController()
        a.title = title
        a.addTextField { it.text = text }
        a.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
        a.addAction(UIAlertAction("OK", UIAlertActionStyle.default) {
            val t = a.textFields.firstOrNull()?.text?.trim() ?: ""
            if (t.isNotEmpty()) done(t)
        })
        a.showOver(this)
    }

    private fun renameArt() { prompt("Rename artwork", doc.item.name) { doc.item.name = it; afterEdit() } }

    private fun moreMenu() {
        val s = UIAlertController()
        s.addAction("Rename") { renameArt() }
        s.addAction("Import picture as layer") { pickPicture() }
        s.addAction("Save to Photos") { saveToPhotos() }
        s.addAction("Export PNG") { exportPNG() }
        s.addAction("Export PSD (layers)") { exportPSD() }
        s.addAction("Save as .saikidrawing") { exportDrawingFile() }
        if (onApply == null) {
            s.addAction("Send to video editor") { sendToEditor() }
        }
        s.addAction("Save") { saveNow(); Toast.show("Saved") }
        s.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
        s.showOver(this)
    }

    private fun plusMenu() {
        val s = UIAlertController()
        s.addAction("New layer") { addLayer(folder = false) }
        s.addAction("Import image from Photos") { pickPicture() }
        s.addAction("Import image from Files") { pickFile() }
        s.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
        s.showOver(this)
    }

    private fun pickPicture() { pickFile() }

    private fun pickFile() {
        DocPicker.pick { uri ->
            try {
                val img = Paths.appContext.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (img != null) importImage(img) else Toast.show("Couldn't read that image")
            } catch (_: Exception) { Toast.show("Couldn't read that image") }
        }
    }

    /** Puts a picture on a new layer, fitted and centred. */
    private fun importImage(img: Bitmap) {
        val l = doc.addLayer(name = "Picture")
        val k = min(doc.w.toFloat() / img.width, doc.h.toFloat() / img.height)
        val sw = img.width * k; val sh = img.height * k
        val out = Bitmap.createBitmap(doc.w, doc.h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        c.drawBitmap(img, null, RectF((doc.w - sw) / 2f, (doc.h - sh) / 2f, (doc.w + sw) / 2f, (doc.h + sh) / 2f), p)
        out.getPixels(l.px, 0, doc.w, 0, 0, doc.w, doc.h)
        l.dirty = true
        thumbs.clear()
        canvas.invalidateCaches(); afterEdit()
        if (panelKind == 3) reloadRows()
    }

    // MARK: save to Photos / PSD

    private fun saveToPhotos() {
        val bmp = try { doc.flatten(withPaper = true) } catch (_: Exception) { null }
        if (bmp == null) { Toast.show("Nothing to save"); return }
        // PHPhotoLibrary twin: save into the Pictures folder via MediaStore is not wired here;
        // the PNG export (share sheet) covers it — PORT NOTE.
        exportBitmap(bmp, "${doc.item.name}.png")
    }

    private fun exportBitmap(bmp: Bitmap, name: String) {
        try {
            val url = File(Paths.appContext.cacheDir, name)
            url.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            shareFile(url)
        } catch (_: Exception) { Toast.show("Export failed") }
    }

    /** UIActivityViewController twin — hands the file to the host (MainActivity wires the Android share intent). */
    var shareHook: ((File) -> Unit)? = null

    private fun shareFile(url: File) {
        val h = shareHook
        if (h != null) h(url) else Toast.show("Saved to ${url.name}")
    }

    private fun exportPSD() {
        saveNow()
        Toast.show("Building PSD…")
        val w = doc.w; val h = doc.h
        Thread {
            try {
                val out = ArrayList<DecomposedLayer>()
                for ((i, l) in doc.layers.withIndex()) {
                    if (l.meta.isFolder) continue
                    val ints = l.px
                    val alpha = doc.alpha(l)
                    var minX = w; var minY = h; var maxX = -1; var maxY = -1
                    for (y in 0 until h) for (x in 0 until w) if ((ints[y * w + x] ushr 24) != 0) {
                        if (x < minX) minX = x
                        if (x > maxX) maxX = x
                        if (y < minY) minY = y
                        if (y > maxY) maxY = y
                    }
                    var bx = 0; var by = 0; var bw = 1; var bh = 1
                    var rgba = ByteArray(4)
                    if (maxX >= minX) {
                        bx = minX; by = minY; bw = maxX - minX + 1; bh = maxY - minY + 1
                        rgba = ByteArray(bw * bh * 4)
                        for (y in 0 until bh) for (x in 0 until bw) {
                            val o = ((by + y) * w + bx + x) * 4
                            val d = (y * bw + x) * 4
                            val v = ints[(by + y) * w + bx + x]
                            val a = (v ushr 24) and 0xFF
                            if (a == 0) continue
                            rgba[d] = min(255, ((v shr 16) and 0xFF) * 255 / a).toByte()      // un-premultiply
                            rgba[d + 1] = min(255, ((v shr 8) and 0xFF) * 255 / a).toByte()
                            rgba[d + 2] = min(255, (v and 0xFF) * 255 / a).toByte()
                            rgba[d + 3] = max(0, min(255, (a * alpha).roundToInt())).toByte()
                        }
                    }
                    val grp = doc.parentChain(l).firstOrNull()?.meta?.name ?: ""
                    out.add(DecomposedLayer(l.meta.name, bx, by, bw, bh, rgba, doc.shown(l), bw * bh, grp, i))
                }
                if (doc.item.paperWhite) {
                    val white = ByteArray(w * h * 4) { 255.toByte() }
                    out.add(0, DecomposedLayer("Paper", 0, 0, w, h, white, true, w * h, "", -1))
                }
                val comp = AnimeDecomposer.composite(out, w, h)
                val data = PSDWriter.write(w, h, out, comp)
                val url = File(Paths.appContext.cacheDir, "${doc.item.name}.psd")
                url.delete()
                url.writeBytes(data)
                android.os.Handler(android.os.Looper.getMainLooper()).post { shareFile(url) }
            } catch (_: Exception) {
                android.os.Handler(android.os.Looper.getMainLooper()).post { Toast.show("PSD export failed") }
            }
        }.start()
    }

    private fun exportDrawingFile() {
        saveNow()
        val url = DrawingArchive.export(doc.item.id)
        if (url == null) { Toast.show("Export failed"); return }
        shareFile(url)
    }

    private fun exportPNG() {
        val bmp = try { doc.flatten(withPaper = true) } catch (_: Exception) { null } ?: return
        exportBitmap(bmp, "${doc.item.name}.png")
    }

    // MARK: save / leave

    private fun saveNow() { canvas.cancelTransform(); doc.save() }

    private fun goBack() {
        if (onApply != null) {                     // direct mode: back = discard the temporary copy
            val id = doc.item.id
            navigationController?.popViewController(animated = true)
            DrawStore.delete(id)
            return
        }
        Toast.show("Saving…")
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            saveNow()
            navigationController?.popViewController(animated = true)
        }
    }

    private fun sendToEditor() {
        val apply = onApply
        if (apply != null) {
            canvas.cancelTransform()
            val bmp = try { doc.flatten(withPaper = false) } catch (_: Exception) { null }
            if (bmp == null) { Toast.show("Could not render the drawing"); return }
            val id = doc.item.id
            navigationController?.popViewController(animated = true)
            apply(bmp)
            DrawStore.delete(id)
            return
        }
        Toast.show("Creating project…")
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            saveNow()
            DrawExport.toProject(doc.item) { id ->
                if (id == null) { Toast.show("Export failed"); return@toProject }
                Toast.show("Project created")
                navigationController?.pushViewController(com.saiki.motion.app.EditorViewController(id), animated = true)
            }
        }
    }
}
