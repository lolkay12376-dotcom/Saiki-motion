@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.saiki.motion.app.DocPicker
import com.saiki.motion.core.CrashLog
import com.saiki.motion.core.DrawItem
import com.saiki.motion.core.DrawStore
import com.saiki.motion.core.DrawingArchive
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.UIAlertAction
import com.saiki.motion.uikit.UIAlertActionStyle
import com.saiki.motion.uikit.UIAlertController
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UICollectionView
import com.saiki.motion.uikit.UICollectionViewCell
import com.saiki.motion.uikit.UICollectionViewDataSource
import com.saiki.motion.uikit.UICollectionViewDelegate
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UiImageView
import com.saiki.motion.uikit.appContext
import java.io.File
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

// Port of Sources/Tools/DrawingGalleryViewController.swift — "My Gallery" of the Drawing Editor.
// Grid of artworks and folders. Long-press an item for: Open, Rename, Add folder, Move,
// Duplicate, Send to video editor, Delete. "+" creates a canvas (preset sizes or custom),
// Import brings a picture in as a new artwork, Select does bulk delete / move.
// PHPicker / UIActivityViewController / context menus ride the Android pickers, Dlg sheets and
// UIAlertController twin (uikit) — PORT NOTE.

private class GalleryCell : UICollectionViewCell() {
    val img = UiImageView()
    val name = UILabel()
    val sub = UILabel()
    val check = UILabel()
    var borderSel = false
        set(v) { field = v; setNeedsDisplay() }

    init {
        img.contentMode = com.saiki.motion.uikit.UIViewContentMode.scaleAspectFit
        img.setBackgroundColor(C.CARD)
        name.font = UIFont.semiboldSystemFont(13f); name.textColor = UIColor(C.TEXT)
        name.textAlignment = com.saiki.motion.uikit.NSTextAlignment.center
        sub.font = UIFont.systemFont(11f); sub.textColor = UIColor(C.DIM)
        sub.textAlignment = com.saiki.motion.uikit.NSTextAlignment.center
        check.textAlignment = com.saiki.motion.uikit.NSTextAlignment.center; check.font = UIFont.boldSystemFont(14f)
        check.text = "✓"; check.textColor = UIColor(C.ONDARK); check.setBackgroundColor(C.GREEN)
        check.isHidden = true; check.isUserInteractionEnabled = false
        contentView.addSubview(img); contentView.addSubview(name); contentView.addSubview(sub); contentView.addSubview(check)
    }

    override fun layoutSubviews() {
        super.layoutSubviews()
        val w = contentView.rectWidth()
        img.frame = CGRect(0f, 0f, w, w)
        name.frame = CGRect(0f, w + 6f, w, 18f)
        sub.frame = CGRect(0f, w + 24f, w, 15f)
        check.frame = CGRect(w - 30f, 6f, 24f, 24f)
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        // the image frame border (selected = green)
        c.paint.style = android.graphics.Paint.Style.STROKE
        c.paint.strokeWidth = if (borderSel) 3f else 1f
        c.paint.color = if (borderSel) C.GREEN else C.LINE
        c.canvas.drawRoundRect(android.graphics.RectF(0.5f, 0.5f, rect.width - 0.5f, rect.width - 0.5f), 12f, 12f, c.paint)
        c.paint.style = android.graphics.Paint.Style.FILL
        super.draw(rect)
    }
}

class DrawingGalleryViewController(private val folderId: String? = null) : UIViewController(),
    UICollectionViewDataSource, UICollectionViewDelegate {
    private var items: List<DrawItem> = emptyList()
    private var selecting = false
    private var selected = HashSet<String>()
    private lateinit var collection: UICollectionView
    private val titleLabel = UILabel()
    private val empty = UILabel()
    private val header = UiView(); private val toolbar = UiView()
    private val selectBtn = DrawBtn(title = "Select")
    private val backBtn = DrawBtn(icon = "back")
    private var barButtons = ArrayList<DrawBtn>()
    private val thumbCache = HashMap<String, Bitmap>()

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        CrashLog.note("drawing_gallery")

        header.setBackgroundColor(C.PANEL)
        toolbar.setBackgroundColor(C.PANEL)
        collection = UICollectionView()
        collection.setBackgroundColor(0x00000000)
        collection.dataSource = this
        collection.delegate = this
        collection.sectionInset = com.saiki.motion.uikit.UIEdgeInsets(16f, 16f, 24f, 16f)
        collection.minimumInteritemSpacing = 12f
        collection.minimumLineSpacing = 14f
        view.addSubview(collection)
        view.addSubview(header); view.addSubview(toolbar)

        titleLabel.font = UIFont.boldSystemFont(18f); titleLabel.textColor = UIColor(C.TEXT)
        titleLabel.textAlignment = com.saiki.motion.uikit.NSTextAlignment.center
        header.addSubview(titleLabel)
        backBtn.onClick = { navigationController?.popViewController(animated = true) }
        selectBtn.tint = C.GREEN
        selectBtn.onClick = { toggleSelect() }
        header.addSubview(backBtn); header.addSubview(selectBtn)

        empty.text = "There is no artwork.\nPress ‘+’ to create a new artwork."
        empty.numberOfLines = 0; empty.textAlignment = com.saiki.motion.uikit.NSTextAlignment.center
        empty.font = UIFont.systemFont(16f); empty.textColor = UIColor(C.DIM)
        view.addSubview(empty)
        buildToolbar()
    }

    override fun viewWillAppear(animated: Boolean) {
        super.viewWillAppear(animated)
        reload()
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        val w = view.rectWidth()
        val sa = view.safeAreaInsets
        header.frame = CGRect(0f, 0f, w, 52f + sa.top)
        backBtn.frame = CGRect(6f, sa.top + 4f, 44f, 44f)
        selectBtn.frame = CGRect(w - 90f, sa.top + 4f, 84f, 44f)
        titleLabel.frame = CGRect(60f, sa.top + 4f, w - 150f, 44f)
        val tb = 58f + max(sa.bottom, 6f)
        toolbar.frame = CGRect(0f, view.rectHeight() - tb, w, tb)
        collection.frame = CGRect(0f, header.frame.maxY, w, toolbar.frame.minY - header.frame.maxY)
        empty.frame = CGRect(20f, view.rectHeight() / 2f - 50f, w - 40f, 80f)
        val n = barButtons.size.toFloat()
        for ((i, b) in barButtons.withIndex()) b.frame = CGRect(i * w / n, 2f, w / n, 54f)
    }

    // MARK: data

    private fun reload() {
        items = DrawStore.items(folderId)
        val parent = folderId?.let { DrawStore.item(it) }
        titleLabel.text = parent?.name ?: "My Gallery (${DrawStore.totalArtworks()})"
        backBtn.isHidden = false
        empty.isHidden = items.isNotEmpty()
        selectBtn.title = if (selecting) "Done" else "Select"
        buildToolbar()
        collection.reloadData()
    }

    private fun buildToolbar() {
        barButtons.forEach { it.removeFromSuperview() }
        barButtons = ArrayList()
        val defs: List<Triple<String, String, () -> Unit>> =
            if (selecting) listOf(
                Triple("trash", "Delete") { deleteSelected() },
                Triple("box", "Move") { moveSelected() },
                Triple("dup", "Duplicate") { duplicateSelected() })
            else listOf(
                Triple("plus", "New") { newSheet() },
                Triple("box", "Folder") { newFolder() },
                Triple("import", "Import") { importPicture() })
        for (d in defs) {
            val b = DrawBtn(icon = d.first, title = d.second, action = d.third)
            if (d.second == "Delete") b.tint = C.RED
            if (d.second == "New") b.tint = C.GREEN
            toolbar.addSubview(b); barButtons.add(b)
        }
        view.requestLayout()
        viewDidLayoutSubviews()
    }

    // MARK: collection

    override fun numberOfItems(cv: UICollectionView): Int = items.size

    override fun cellForItem(cv: UICollectionView, index: Int): UICollectionViewCell {
        val cell = GalleryCell()
        val it = items[index]
        cell.name.text = it.name
        cell.check.isHidden = !(selecting && selected.contains(it.id))
        cell.borderSel = selected.contains(it.id) && selecting
        if (it.isFolder) {
            val n = DrawStore.count(it.id)
            cell.sub.text = "$n item" + (if (n == 1) "" else "s")
            cell.img.setBackgroundColor((C.GREEN and 0x00FFFFFF) or 0x38FF5A2E.toInt())
            cell.img.image = Icons.image("folder", 56f, C.GREEN)
            cell.img.contentMode = com.saiki.motion.uikit.UIViewContentMode.center
        } else {
            cell.sub.text = "${it.w} × ${it.h}"
            cell.img.setBackgroundColor(C.CARD)
            cell.img.contentMode = com.saiki.motion.uikit.UIViewContentMode.scaleAspectFit
            cell.img.image = thumb(it)?.let { com.saiki.motion.uikit.UIImage(it) }
        }
        return cell
    }

    private fun thumb(it: DrawItem): Bitmap? {
        val key = it.id + it.updated
        thumbCache[key]?.let { return it }
        val t = try { BitmapFactory.decodeFile(DrawStore.thumbFile(it.id).path) } catch (_: Exception) { null }
        if (t != null) thumbCache[key] = t
        return t
    }

    override fun didSelectItem(cv: UICollectionView, index: Int) {
        val it = items.getOrNull(index) ?: return
        if (selecting) {
            if (selected.contains(it.id)) selected.remove(it.id) else selected.add(it.id)
            collection.reloadData()
            return
        }
        open(it)
    }

    // MARK: actions

    fun open(it: DrawItem) {
        if (it.isFolder) navigationController?.pushViewController(DrawingGalleryViewController(it.id), animated = true)
        else navigationController?.pushViewController(DrawingEditorViewController(it), animated = true)
    }

    private fun toggleSelect() {
        selecting = !selecting; selected.clear(); reload()
    }

    private fun promptText(title: String, text: String, done: (String) -> Unit) {
        val a = UIAlertController()
        a.title = title
        a.addTextField { it.text = text }
        a.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
        a.addAction(UIAlertAction("OK", UIAlertActionStyle.default) {
            val t = a.textFields.firstOrNull()?.text?.trim() ?: ""
            if (t.isNotEmpty()) done(t)
        })
        a.showOver(this)
    }

    private fun rename(it: DrawItem) { promptText("Rename", it.name) { n -> DrawStore.rename(it.id, n); reload() } }
    private fun newFolder() { promptText("New folder", "Folder") { n -> DrawStore.makeFolder(n, folderId); reload() } }

    private fun confirmDelete(ids: List<String>) {
        val a = UIAlertController()
        a.title = "Delete ${ids.size} item" + (if (ids.size == 1) "" else "s") + "?"
        a.message = "Folders are deleted with everything inside. This can’t be undone."
        a.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
        a.addAction(UIAlertAction("Delete", UIAlertActionStyle.destructive) {
            ids.forEach { DrawStore.delete(it) }
            selected.clear(); reload()
        })
        a.showOver(this)
    }

    private fun deleteSelected() { if (selected.isEmpty()) Toast.show("Nothing selected") else confirmDelete(selected.toList()) }
    private fun moveSelected() { if (selected.isEmpty()) Toast.show("Nothing selected") else pickFolder(selected.toList()) }
    private fun duplicateSelected() {
        for (id in selected) DrawStore.duplicate(id)
        selected.clear(); reload()
    }

    private fun pickFolder(ids: List<String>) {
        val s = UIAlertController()
        s.title = "Move to"
        s.addAction("My Gallery") {
            ids.forEach { DrawStore.move(it, null) }; selected.clear(); reload()
        }
        for (f in DrawStore.all().filter { it.isFolder && !ids.contains(it.id) }) {
            val path = DrawStore.path(f.id).joinToString(" / ") { it.name }
            s.addAction(path) {
                ids.forEach { DrawStore.move(it, f.id) }; selected.clear(); reload()
            }
        }
        s.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
        s.showOver(this)
    }

    private fun sendToEditor(it: DrawItem) {
        Toast.show("Creating project…")
        DrawExport.toProject(it) { id ->
            if (id == null) { Toast.show("Export failed"); return@toProject }
            Toast.show("Project created")
            navigationController?.pushViewController(com.saiki.motion.app.EditorViewController(id), animated = true)
        }
    }

    private fun itemMenu(it: DrawItem) {
        val s = UIAlertController()
        s.title = it.name
        s.addAction("Open") { open(it) }
        s.addAction("Rename") { rename(it) }
        s.addAction("Add folder") {
            promptText("New folder", "Folder") { n ->
                DrawStore.makeFolder(n, if (it.isFolder) it.id else folderId); reload()
            }
        }
        s.addAction("Move to…") { pickFolder(listOf(it.id)) }
        if (!it.isFolder) {
            s.addAction("Duplicate") { DrawStore.duplicate(it.id); reload() }
            s.addAction("Save as .saikidrawing") {
                val u = DrawingArchive.export(it.id)
                if (u == null) Toast.show("Export failed")
                else {
                    // UIActivityViewController twin: the system share sheet over the cached export
                    val act = currentShareIntent
                    act?.invoke(u)
                }
            }
            s.addAction("Send to video editor") { sendToEditor(it) }
        }
        s.addAction(UIAlertAction("Delete", UIAlertActionStyle.destructive) { confirmDelete(listOf(it.id)) })
        s.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
        s.showOver(this)
    }

    /** Hook for the Android share sheet (iOS UIActivityViewController). Set by the host screen. */
    var currentShareIntent: ((File) -> Unit)? = null

    // MARK: new canvas

    private fun newSheet() {
        val v = DrawingNewSheetViewController()
        v.onFolder = { newFolder() }
        v.onImport = { importPicture() }
        v.onCreate = { w, h, name -> create(w, h, name) }
        present(v, animated = true)
    }

    private fun create(w: Int, h: Int, name: String) {
        if (!com.saiki.motion.core.DrawPresets.valid(w, h)) {
            Toast.show("Size not supported (max ${com.saiki.motion.core.DrawPresets.maxSide} px, ~${com.saiki.motion.core.DrawPresets.maxPixels / 1_000_000} MP)")
            return
        }
        val it = DrawStore.newArtwork("$name ${DrawStore.totalArtworks() + 1}", w, h, folderId)
        navigationController?.pushViewController(DrawingEditorViewController(it), animated = true)
    }

    private fun importPicture() {
        val sh = UIAlertController()
        sh.title = "Import"
        sh.addAction("Picture from Photos") { importFromPicker() }
        sh.addAction("Drawing file (.saikidrawing)") {
            DocPicker.pick { uri -> importArchive(uri) }
        }
        sh.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
        sh.showOver(this)
    }

    private fun importFromPicker() {
        DocPicker.pick { uri ->
            try {
                val img = Paths.appContext.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                if (img != null) importImage(img) else Toast.show("Couldn’t import that picture")
            } catch (_: Exception) { Toast.show("Couldn’t import that picture") }
        }
    }

    private fun importImage(img: Bitmap) {
        val it = com.saiki.motion.core.DrawImport.fromImage(img, "Picture ${DrawStore.totalArtworks() + 1}", folderId)
        if (it == null) { Toast.show("Couldn’t import that picture"); return }
        navigationController?.pushViewController(DrawingEditorViewController(it), animated = true)
    }

    private fun importArchive(uri: android.net.Uri) {
        val f = File(Paths.appContext.cacheDir, "import_${System.currentTimeMillis()}.saikidrawing")
        try {
            Paths.appContext.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        } catch (_: Exception) { Toast.show("Not a .saikidrawing file"); return }
        var n = 0
        if (DrawingArchive.isArchive(f)) { if (DrawingArchive.importFile(f, folderId) != null) n += 1 }
        Toast.show(if (n > 0) "Imported $n drawing" + (if (n == 1) "" else "s") else "Not a .saikidrawing file")
        f.delete()
        reload()
    }
}

private val Paths get() = com.saiki.motion.core.Paths
