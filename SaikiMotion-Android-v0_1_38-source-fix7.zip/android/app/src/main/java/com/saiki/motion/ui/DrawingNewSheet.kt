@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import com.saiki.motion.core.DrawPresets
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.UIAlertAction
import com.saiki.motion.uikit.UIAlertController
import com.saiki.motion.uikit.UIAlertActionStyle
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import kotlin.math.max
import kotlin.math.min

// Port of Sources/Tools/DrawingNewSheet.swift — the "New" sheet of the drawing gallery
// (Folder, Import Picture, Illustration and Printing sizes).

private class SizeShape : UiView(appContext!!) {
    var w = 1
    var h = 1
    var dashed = true

    init { setBackgroundColor(0x00000000); isUserInteractionEnabled = false }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val box = CGRect(3f, 3f, rectWidth() - 6f, rectHeight() - 6f)
        val k = min(box.width / w, box.height / h)
        val rw = max(6f, w * k); val rh = max(6f, h * k)
        val r = CGRect(box.midX - rw / 2, box.midY - rh / 2, rw, rh)
        c.setStrokeColor(0xFFFF8C1A.toInt())
        c.setLineWidth(3f)
        if (dashed) c.setLineDash(0f, floatArrayOf(8f, 5f))
        c.stroke(r)
        c.setLineDash(0f, FloatArray(0))
    }
}

private class NewRow : TapView() {
    val left = UiView()
    val title = UILabel()
    var trailing: UiView = UiView()

    init {
        setBackgroundColor(0xFF121212.toInt())
        title.font = UIFont.systemFont(21f); title.textColor = UIColor(0xFFFFFFFF.toInt())
        addSubview(left); addSubview(title); addSubview(trailing)
    }

    override fun layoutSubviews() {
        super.layoutSubviews()
        val h = rectHeight()
        left.frame = CGRect(10f, (h - 48f) / 2f, 48f, 48f)
        val tw = trailing.rectWidth()
        trailing.frame = CGRect(rectWidth() - tw - 6f, (h - trailing.rectHeight()) / 2f, tw, trailing.rectHeight())
        title.frame = CGRect(70f, 0f, max(10f, trailing.frame.minX - 76f), h)
    }
}

class DrawingNewSheetViewController : UIViewController() {
    var onFolder: (() -> Unit)? = null
    var onImport: (() -> Unit)? = null
    var onCreate: ((Int, Int, String) -> Unit)? = null

    private var customW = 2000
    private var customH = 2000
    private val swapped = HashSet<String>()
    private val scroll = UIScrollView()
    private val stack = UiView()
    private val items = ArrayList<UiView>()

    private val illustration: List<Tuple4<String, Int, Int, Boolean>> = listOf(
        Tuple4("HD (Quality)", 1080, 2340, true), Tuple4("1:1 (2K)", 2048, 2048, true), Tuple4("3:4 (2K)", 1536, 2048, true),
        Tuple4("9:16 (2K)", 1080, 1920, true), Tuple4("X Header", 1500, 500, false), Tuple4("Chat Stamp", 370, 320, false),
        Tuple4("Vertical", 690, 4096, false))
    private val printing: List<Triple<String, Pair<Int, Int>, String?>> = listOf(
        Triple("Manga Manuscript", Pair(2039, 2894), null), Triple("Postcard (JP)", Pair(1181, 1748), "300 dpi"), Triple("A4", Pair(1240, 1754), "150 dpi"))

    class Tuple4<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)

    private val head = UiView()
    private val headTitle = UILabel()
    private val headX = TapView()

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(0xFF000000.toInt())
        headTitle.text = "New"; headTitle.font = UIFont.boldSystemFont(24f); headTitle.textColor = UIColor(0xFFFFFFFF.toInt())
        val ic = IconView("close", 0xFFFFFFFF.toInt(), 26f)
        ic.isUserInteractionEnabled = false
        ic.frame = CGRect(8f, 8f, 34f, 34f); headX.addSubview(ic)
        headX.onClick = { dismiss(animated = true) }
        head.addSubview(headTitle); head.addSubview(headX)
        view.addSubview(head)
        scroll.showsVerticalScrollIndicator = true
        view.addSubview(scroll)
        scroll.addSubview(stack)
        build()
    }

    override fun viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        val w = view.rectWidth()
        head.frame = CGRect(0f, 8f, w, 50f)
        headTitle.frame = CGRect(18f, 8f, 200f, 34f)
        headX.frame = CGRect(w - 56f, 0f, 50f, 50f)
        scroll.frame = CGRect(8f, 62f, w - 16f, view.rectHeight() - 62f - max(view.safeAreaInsets.bottom, 8f))
        layoutStack()
    }

    private fun layoutStack() {
        val w = scroll.rectWidth()
        var y = 0f
        for (v in items) { val h = v.rectHeight(); v.frame = CGRect(0f, y, w, h); y += h }
        stack.frame = CGRect(0f, 0f, w, y)
        scroll.contentSize = CGSize(w, y)
    }

    private fun rebuildKeepScroll() {
        val off = scroll.contentOffset
        build()
        layoutStack()
        scroll.contentOffset = off
    }

    private fun sectionHeader(s: String): UiView {
        val v = UiView()
        v.setBackgroundColor(0xFF242424.toInt())
        v.frame = CGRect(0f, 0f, 10f, 44f)
        val l = UILabel()
        l.text = s; l.font = UIFont.boldSystemFont(20f); l.textColor = UIColor(0xFFFF8C1A.toInt())
        l.frame = CGRect(16f, 0f, 300f, 44f); v.addSubview(l)
        return v
    }

    private fun line(): UiView {
        val v = UiView()
        v.setBackgroundColor(0xFF383838.toInt())
        v.frame = CGRect(0f, 0f, 10f, 1f)
        return v
    }

    private fun pill(text: String, icon: String, width: Float, tap: () -> Unit): UiView {
        val v = object : TapView() {
            override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                c.paint.color = 0xFF292929.toInt()
                c.canvas.drawRoundRect(android.graphics.RectF(0f, 0f, rect.width, rect.height), 8f, 8f, c.paint)
                c.paint.style = android.graphics.Paint.Style.STROKE
                c.paint.strokeWidth = 1.5f
                c.paint.color = 0xFFFF8C1A.toInt()
                c.canvas.drawRoundRect(android.graphics.RectF(0.75f, 0.75f, rect.width - 0.75f, rect.height - 0.75f), 8f, 8f, c.paint)
                c.paint.style = android.graphics.Paint.Style.FILL
            }
        }
        v.frame = CGRect(0f, 0f, width, 46f)
        val l = UILabel()
        l.text = text; l.font = UIFont.systemFont(22f); l.textColor = UIColor(0xFFFFFFFF.toInt())
        l.frame = CGRect(14f, 0f, width - 56f, 46f); l.isUserInteractionEnabled = false
        val ic = IconView(icon, 0xFFFF8C1A.toInt(), 22f); ic.isUserInteractionEnabled = false
        ic.frame = CGRect(width - 40f, 8f, 30f, 30f)
        v.addSubview(l); v.addSubview(ic)
        v.onClick = tap
        return v
    }

    private fun row(title: String, shape: UiView, trailing: UiView?, action: () -> Unit): NewRow {
        val r = NewRow()
        r.frame = CGRect(0f, 0f, 10f, 74f)
        r.title.text = title
        shape.frame = r.left.boundsRect
        r.left.addSubview(shape)
        if (trailing != null) { r.trailing = trailing; r.addSubview(trailing) }
        r.onClick = action
        return r
    }

    private fun iconShape(name: String): UiView {
        val iv = IconView(name, 0xFFFF8C1A.toInt(), 34f)
        iv.isUserInteractionEnabled = false
        iv.frame = CGRect(4f, 4f, 40f, 40f)
        return iv
    }

    private fun sizeShape(w: Int, h: Int, dashed: Boolean): UiView {
        val s = SizeShape()
        s.frame = CGRect(0f, 0f, 48f, 48f)
        s.w = w; s.h = h; s.dashed = dashed
        return s
    }

    private fun sizeLabel(w: Int, h: Int): UiView {
        val l = UILabel()
        l.text = "$w x $h"; l.font = UIFont.systemFont(22f); l.textColor = UIColor(0xFFBFBFBF.toInt())
        l.textAlignment = com.saiki.motion.uikit.NSTextAlignment.right
        l.frame = CGRect(0f, 0f, 150f, 46f)
        return l
    }

    private fun build() {
        items.forEach { it.removeFromSuperview() }; items.clear()
        fun add(v: UiView) { stack.addSubview(v); items.add(v) }
        add(row("Folder", iconShape("folder"), null) {
            dismiss(animated = true) { onFolder?.invoke() }
        }); add(line())
        add(row("Import Picture", iconShape("camera"), null) {
            dismiss(animated = true) { onImport?.invoke() }
        }); add(line())
        add(sectionHeader("Illustration")); add(line())

        add(row("Custom", sizeShape(customW, customH, dashed = true),
            pill("$customW x $customH", "edit", 230f) { editCustom() }) {
            dismiss(animated = true) { onCreate?.invoke(customW, customH, "Illustration") }
        }); add(line())

        for (p in illustration) {
            val sw = swapped.contains(p.a)
            val w = if (sw) p.c else p.b
            val h = if (sw) p.b else p.c
            val tr: UiView = if (p.d)
                pill("$w x $h", "chev_up", 230f) {
                    if (swapped.contains(p.a)) swapped.remove(p.a) else swapped.add(p.a)
                    rebuildKeepScroll()
                }
            else sizeLabel(w, h)
            add(row(p.a, sizeShape(w, h, dashed = true), tr) {
                dismiss(animated = true) { onCreate?.invoke(w, h, p.a) }
            }); add(line())
        }

        add(sectionHeader("For Printing")); add(line())
        for (p in printing) {
            val sw = swapped.contains(p.first)
            val w = if (sw) p.second.second else p.second.first
            val h = if (sw) p.second.first else p.second.second
            var tr: UiView? = null
            val dpi = p.third
            if (dpi != null) {
                tr = pill("$dpi  $w x $h", "chev_up", 290f) {
                    if (swapped.contains(p.first)) swapped.remove(p.first) else swapped.add(p.first)
                    rebuildKeepScroll()
                }
            }
            add(row(p.first, sizeShape(w, h, dashed = false), tr) {
                dismiss(animated = true) { onCreate?.invoke(w, h, p.first) }
            }); add(line())
        }
    }

    private fun editCustom() {
        val a = UIAlertController()
        a.title = "Custom canvas"
        a.message = "Max ${DrawPresets.maxSide} px per side"
        a.addTextField { it.placeholder = "Width"; it.text = "$customW" }
        a.addTextField { it.placeholder = "Height"; it.text = "$customH" }
        a.addAction(UIAlertAction("Cancel", UIAlertActionStyle.cancel, null))
        a.addAction(UIAlertAction("OK", UIAlertActionStyle.default) {
            val w = a.textFields.getOrNull(0)?.text?.toIntOrNull() ?: 0
            val h = a.textFields.getOrNull(1)?.text?.toIntOrNull() ?: 0
            if (DrawPresets.valid(w, h)) { customW = w; customH = h; rebuildKeepScroll() }
            else Toast.show("Size not supported (max ${DrawPresets.maxSide} px)")
        })
        a.showOver(this)
    }
}
