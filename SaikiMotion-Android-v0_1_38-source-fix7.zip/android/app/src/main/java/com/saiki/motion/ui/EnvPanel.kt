@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/EnvPanel.swift — Scene 3D "+" > Environment. Browse / import Poly Haven HDRIs;
// lights and reflects models, terrain PBR and water.

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.saiki.motion.app.EditorViewController
import com.saiki.motion.app.addMedia
import com.saiki.motion.app.refreshPanel
import com.saiki.motion.core.Editor
import com.saiki.motion.core.GlobalEnv
import com.saiki.motion.core.R3D
import com.saiki.motion.core.nowMs
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UISearchBar
import com.saiki.motion.uikit.UISegmentedControl
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UITableView
import com.saiki.motion.uikit.UITableViewCell
import com.saiki.motion.uikit.UITableViewDataSource
import com.saiki.motion.uikit.UITableViewDelegate
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.setThumb
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class EnvPanel(private val host: EditorViewController?) : UiView(appContext!!), UITableViewDataSource, UITableViewDelegate {
    private val accent = 0xFFFF8C14.toInt()
    private val search = UISearchBar(appContext!!)
    private val table = UITableView(appContext!!)
    private val status = UILabel(appContext!!)
    private val quality = UISegmentedControl(listOf("1k (fast)", "2k"))
    private var all: List<Pair<String, String>> = emptyList()      // (id, name)
    private var shown: List<Pair<String, String>> = emptyList()
    private val card = UiView(appContext!!)
    private val scroll = UIScrollView(appContext!!)
    private val listHolder = UiView(appContext!!)

    companion object {
        private var listCache: List<Pair<String, String>> = emptyList()

        fun present(host: EditorViewController, view: UiView) {
            if (view.subviews.any { it is EnvPanel }) return
            val v = EnvPanel(host)
            view.addSubview(v)
            v.frame = CGRect(0f, 0f, view.rectWidth(), view.rectHeight())
        }

        /** Inside-out UV sphere (equirect mapped, unlit) textured with the HDRI's preview picture. */
        fun skyGLB(jpg: ByteArray): ByteArray? {
            val W = 64; val H = 32
            val pos = ArrayList<Float>(); val nor = ArrayList<Float>(); val uv = ArrayList<Float>(); val idx = ArrayList<Int>()
            for (j in 0..H) for (i in 0..W) {
                val v = j.toFloat() / H; val u = i.toFloat() / W
                val th = v * Math.PI.toFloat(); val ph = (u - 0.5f) * 2f * Math.PI.toFloat()
                val x = sin(th) * cos(ph); val y = cos(th); val z = sin(th) * sin(ph)
                pos.add(x * 0.5f); pos.add(y * 0.5f); pos.add(z * 0.5f)
                nor.add(-x); nor.add(-y); nor.add(-z)
                uv.add(u); uv.add(v)
            }
            for (j in 0 until H) for (i in 0 until W) {
                val a = i + j * (W + 1); val b = a + W + 1
                idx.add(a); idx.add(a + 1); idx.add(b)
                idx.add(a + 1); idx.add(b + 1); idx.add(b)
            }
            val bin = ByteArrayOutputStream()
            val views = org.json.JSONArray()
            fun add(d: ByteArray, t: Int?): Int {
                while (bin.size() % 4 != 0) bin.write(0)
                val v = JSONObject(); v.put("buffer", 0); v.put("byteOffset", bin.size()); v.put("byteLength", d.size)
                if (t != null) v.put("target", t)
                bin.write(d); views.put(v); return views.length() - 1
            }
            fun fbytes(a: List<Float>): ByteArray { val b = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (x in a) b.putFloat(x); return b.array() }
            fun ibytes(a: List<Int>): ByteArray { val b = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (x in a) b.putInt(x); return b.array() }
            val vp = add(fbytes(pos), 34962); val vn = add(fbytes(nor), 34962); val vu = add(fbytes(uv), 34962)
            val vi = add(ibytes(idx), 34963); val im = add(jpg, null)
            val nv = pos.size / 3
            fun accessor(view: Int, ct: Int, count: Int, type: String): JSONObject =
                JSONObject().put("bufferView", view).put("componentType", ct).put("count", count).put("type", type)
            val acc = org.json.JSONArray()
            acc.put(accessor(vp, 5126, nv, "VEC3").put("min", org.json.JSONArray(listOf(-0.5, -0.5, -0.5))).put("max", org.json.JSONArray(listOf(0.5, 0.5, 0.5))))
            acc.put(accessor(vn, 5126, nv, "VEC3"))
            acc.put(accessor(vu, 5126, nv, "VEC2"))
            acc.put(accessor(vi, 5125, idx.size, "SCALAR"))
            val json = JSONObject()
            json.put("asset", JSONObject().put("version", "2.0").put("generator", "SaikiMotion Sky"))
            json.put("extensionsUsed", org.json.JSONArray().put("KHR_materials_unlit"))
            json.put("scene", 0).put("scenes", org.json.JSONArray().put(JSONObject().put("nodes", org.json.JSONArray().put(0))))
            json.put("nodes", org.json.JSONArray().put(JSONObject().put("mesh", 0)))
            json.put("meshes", org.json.JSONArray().put(JSONObject().put("primitives",
                org.json.JSONArray().put(JSONObject().put("attributes", JSONObject().put("POSITION", 0).put("NORMAL", 1).put("TEXCOORD_0", 2))
                    .put("indices", 3).put("material", 0)))))
            json.put("materials", org.json.JSONArray().put(JSONObject().put("doubleSided", true)
                .put("extensions", JSONObject().put("KHR_materials_unlit", JSONObject()))
                .put("pbrMetallicRoughness", JSONObject().put("baseColorTexture", JSONObject().put("index", 0))
                    .put("metallicFactor", 0.0).put("roughnessFactor", 1.0))))
            json.put("textures", org.json.JSONArray().put(JSONObject().put("source", 0).put("sampler", 0)))
            json.put("images", org.json.JSONArray().put(JSONObject().put("bufferView", im).put("mimeType", "image/jpeg")))
            json.put("samplers", org.json.JSONArray().put(JSONObject().put("magFilter", 9729).put("minFilter", 9987).put("wrapS", 10497).put("wrapT", 33071)))
            json.put("accessors", acc); json.put("bufferViews", views)
            while (bin.size() % 4 != 0) bin.write(0)
            json.put("buffers", org.json.JSONArray().put(JSONObject().put("byteLength", bin.size())))
            var js = json.toString().toByteArray(Charsets.UTF_8)
            if (js.size % 4 != 0) js = js + ByteArray(4 - js.size % 4) { 0x20 }
            val bb = bin.toByteArray()
            val out = ByteBuffer.allocate(12 + 8 + js.size + 8 + bb.size).order(ByteOrder.LITTLE_ENDIAN)
            out.putInt(0x46546C67); out.putInt(2); out.putInt(12 + 8 + js.size + 8 + bb.size)
            out.putInt(js.size); out.putInt(0x4E4F534A); out.put(js)
            out.putInt(bb.size); out.putInt(0x004E4942); out.put(bb)
            return out.array()
        }
    }

    init {
        setBackgroundColor(0x8C000000.toInt())
        build()
        if (listCache.isEmpty()) {
            PolyHavenNet.get("https://api.polyhaven.com/assets?t=hdris") { d ->
                uikitMain {
                    if (d != null) {
                        try {
                            val o = JSONObject(String(d))
                            val out = ArrayList<Pair<String, String>>()
                            for (k in o.keys()) {
                                val e = o.optJSONObject(k) ?: continue
                                out.add(Pair(k, e.optString("name", k)))
                            }
                            out.sortBy { it.second.lowercase() }
                            listCache = out
                        } catch (_: Exception) { }
                    }
                    all = listCache
                    filter("")
                    if (all.isEmpty()) status.text = "Could not reach Poly Haven. Check your connection."
                }
            }
        } else {
            all = listCache; filter("")
        }
    }

    private fun uikitMain(f: () -> Unit) {
        android.os.Handler(android.os.Looper.getMainLooper()).post(f)
    }

    private fun build() {
        card.setBackgroundColor(0xFF171717.toInt())
        addSubview(card)
        val x = PillButton("✕", null, C.CARD2, C.TEXT)
        x.onClick = { removeFromSuperview() }
        val headL = UILabel(appContext!!)
        headL.text = "Environment"; headL.textColor = UIColor.white; headL.font = UIFont.boldSystemFont(22f)
        search.placeholder = "Search Poly Haven HDRIs (sky, forest, studio…)"
        search.onTextChanged = { q -> filter(q) }
        table.dataSource = this
        table.delegate = this
        table.rowHeight = 60f
        quality.selectedSegmentIndex = 0
        val rm = PillButton("Remove environment", null, 0x00000000.toInt(), 0xFFFF6666.toInt())
        rm.onClick = {
            GlobalEnv.path = null
            status.text = "Environment removed."
            host?.render()
        }
        status.textColor = UIColor(0xFFB3B3B3.toInt()); status.font = UIFont.systemFont(12f); status.numberOfLines = 0
        status.text = if (GlobalEnv.path == null) "Pick an HDRI. It lights and reflects PBR, terrain and water." else "An environment is active."
        val sky = PillButton("Custom gradient sky…", null, 0x00000000.toInt(), accent)
        sky.onClick = {
            val sup = superview
            if (host != null && sup != null) SkyPanel.present(host, sup)
        }
        val head = UiView(appContext!!)
        head.addSubview(headL); head.addSubview(x)
        val body = UiView(appContext!!)
        body.addSubview(head)
        body.addSubview(search)
        listHolder.addSubview(table)
        body.addSubview(listHolder)
        body.addSubview(slider("Intensity", 0f, 3f, R3D.g("env", 1f)) { R3D.set("env", it); host?.render() })
        body.addSubview(slider("Rotation", 0f, 1f, R3D.g("envRot", 0f)) { R3D.set("envRot", it); host?.render() })
        val q = UiView(appContext!!)
        val ql = UILabel(appContext!!); ql.text = "Quality"; ql.textColor = UIColor(0xFFB3B3B3.toInt()); ql.font = UIFont.systemFont(13f)
        q.addSubview(ql); q.addSubview(quality)
        body.addSubview(q)
        body.addSubview(sky)
        body.addSubview(rm)
        body.addSubview(status)
        card.addSubview(body)
    }

    private fun slider(title: String, lo: Float, hi: Float, v: Float, cb: (Float) -> Unit): UiView {
        val l = UILabel(appContext!!)
        l.text = title; l.textColor = UIColor(0xFFB3B3B3.toInt()); l.font = UIFont.systemFont(13f)
        val valL = UILabel(appContext!!)
        valL.text = String.format(java.util.Locale.US, "%.2f", v)
        valL.textColor = UIColor(0xFFB3B3B3.toInt()); valL.font = UIFont.systemFont(12f); valL.textAlignment = NSTextAlignment.right
        val s = com.saiki.motion.uikit.UISlider(appContext!!)
        s.minValue = lo; s.maxValue = hi; s.value = v
        s.onValueChanged = { valL.text = String.format(java.util.Locale.US, "%.2f", s.value); cb(s.value) }
        val r = UiView(appContext!!)
        r.addSubview(l); r.addSubview(s); r.addSubview(valL)
        r.frame = CGRect(0f, 0f, 100f, 36f)
        r.onLayout = { w ->
            l.frame = CGRect(0f, 8f, 84f, 18f)
            s.frame = CGRect(88f, 2f, w - 88f - 44f, 32f)
            valL.frame = CGRect(w - 42f, 8f, 42f, 18f)
        }
        return r
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth(); val h = rectHeight()
        if (w < 10 || h < 10) return
        val top = safeAreaInsets.top
        card.frame = CGRect(12f, top + 40f, w - 24f, h - top - 52f)
        val body = card.subviews.firstOrNull() ?: return
        val cw = card.rectWidth()
        var y = 16f
        val head = body.subviews[0]
        head.frame = CGRect(16f, y, cw - 32f, 30f)
        head.subviews[0].frame = CGRect(0f, 4f, 200f, 26f)
        head.subviews[1].frame = CGRect(cw - 32f - 44f, 0f, 44f, 30f)
        y += 40f
        for (i in 1 until body.subviews.size) {
            val v = body.subviews[i]
            val vh = when {
                v === search -> 40f
                v === listHolder -> 260f
                v is UILabel -> 34f
                else -> 44f
            }
            v.frame = CGRect(16f, y, cw - 32f, vh)
            v.onLayout?.invoke(cw - 32f)
            if (v === search) { }
            if (v === listHolder) {
                table.frame = CGRect(0f, 0f, v.rectWidth(), vh)
                table.reloadData()
            }
            if (v.subviews.size == 2 && v.subviews[1] === quality) {
                v.subviews[0].frame = CGRect(0f, 10f, 60f, 18f)
                v.subviews[1].frame = CGRect(70f, 4f, v.rectWidth() - 70f, 32f)
            }
            y += vh + 10f
        }
        body.frame = CGRect(0f, 0f, cw, y)
    }

    private fun filter(q: String) {
        val k = q.trim().lowercase()
        shown = if (k.isEmpty()) all else all.filter { it.second.lowercase().contains(k) || it.first.contains(k) }
        table.reloadData()
    }

    override fun numberOfRows(t: UITableView, section: Int): Int = shown.size

    override fun cellForRow(t: UITableView, row: Int): UITableViewCell {
        val c = UITableViewCell(appContext!!)
        c.setBackgroundColor(0x00000000)
        c.textLabel?.textColor = UIColor.white
        val it = shown[row]
        c.textLabel?.text = it.second
        PolyHavenNet.thumb(it.first) { img ->
            uikitMain {
                if (img != null && row < shown.size && shown[row].first == it.first) c.setThumb(img)
            }
        }
        return c
    }

    override fun didSelectRow(t: UITableView, row: Int) {
        search.resignFirstResponder()
        if (busy) return
        busy = true
        val it = shown[row]
        val res = if (quality.selectedSegmentIndex == 0) "1k" else "2k"
        status.text = "Downloading ${it.second}…"
        fun fail(m: String) = uikitMain { busy = false; status.text = m }
        PolyHavenNet.get("https://api.polyhaven.com/files/${it.first}") { d ->
            if (d == null) { fail("Download failed."); return@get }
            val f = try { JSONObject(String(d)) } catch (_: Exception) { null }
            val h = f?.optJSONObject("hdri")
            if (h == null) { fail("Download failed."); return@get }
            var url: String? = null
            var ext = "hdr"
            outer@ for (r in listOf(res, "1k", "2k", "4k")) {
                for (e in listOf("hdr", "exr")) {
                    val u = h.optJSONObject(r)?.optJSONObject(e)?.optString("url")
                    if (!u.isNullOrEmpty()) { url = u; ext = e; break@outer }
                }
            }
            if (url == null) { fail("No HDRI file found."); return@get }
            val tmUrl = f.optJSONObject("tonemapped")?.optString("url")
            PolyHavenNet.get(url) { data ->
                if (data == null) { fail("Download failed."); return@get }
                val path = com.saiki.motion.core.ProjectIO.writeDataIntoSandbox(data, "env_${it.first}_$res.$ext")
                if (path == null) { fail("Download failed."); return@get }
                fun finish(sky: ByteArray?) {
                    val skyPath = sky?.let { skyGLB(it) }?.let { glbBytes ->
                        com.saiki.motion.core.ProjectIO.writeDataIntoSandbox(glbBytes, "sky_${it.first}_${nowMs()}.glb")
                    }
                    uikitMain {
                        busy = false
                        GlobalEnv.path = path
                        R3D.set("envGain", 1f)
                        status.text = "${it.second} applied."
                        if (skyPath != null) {
                            val h2 = host
                            if (h2 != null) {      // visible sky dome as its own layer
                                for (old in Editor.scene.layers.filter { it.name.startsWith("Sky · ") }) Editor.scene.layers.removeAll { o -> o === old }
                                h2.addMedia(skyPath, com.saiki.motion.core.LayerType.MODEL)
                                val l = Editor.scene.layers.lastOrNull { l2 -> l2.imagePath == skyPath }
                                if (l != null) {
                                    l.name = "Sky · ${it.second}"
                                    l.track("scale").base = 40f
                                    l.m3Env = false
                                    h2.refreshPanel()
                                }
                            }
                        }
                        host?.render()
                    }
                }
                if (tmUrl != null) PolyHavenNet.get(tmUrl) { finish(it) } else finish(null)
            }
        }
    }

    private var busy = false
}
