@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/ExtrasPanel.swift — Scene 3D "+" > Extras: a flat plane or a cube textured with
// a Poly Haven PBR material. Downloads every map Poly Haven has for the material (colour, normal,
// roughness, metal, AO, displacement), packs them into the three texture slots the model renderer
// already has, writes a tiny .glb and imports it as an ordinary model layer. The count slider turns
// it into an instanced scatter field (one draw call per primitive for any count, capped at 500).
//
//   colour           -> glTF base colour
//   rough / metal    -> metal-rough texture (G = rough, B = metal)
//   AO * cavity(disp)-> occlusion texture R;  normal XY -> its G / B  (the shader rebuilds Z, see MetalModel)

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.saiki.motion.app.EditorViewController
import com.saiki.motion.app.addMedia
import com.saiki.motion.app.refreshPanel
import com.saiki.motion.core.Editor
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.PolyHaven
import com.saiki.motion.core.ProjectIO
import com.saiki.motion.core.nowMs
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UISearchBar
import com.saiki.motion.uikit.UISegmentedControl
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UITableView
import com.saiki.motion.uikit.UITableViewCell
import com.saiki.motion.uikit.setThumb
import com.saiki.motion.uikit.UITableViewDataSource
import com.saiki.motion.uikit.UITableViewDelegate
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

// MARK: - Poly Haven (network layer; data holders live in core/Terrain.kt)

object PolyHavenNet {
    const val ua = "SaikiMotion/1.0 (iOS video editor)"
    const val maxCount = 500
    val listCache = ArrayList<PolyHavenEntry>()
    val thumbs = HashMap<String, Bitmap>()
    private val lock = Object()

    class PolyHavenEntry(val id: String, val name: String)

    fun get(url: String, done: (ByteArray?) -> Unit) {
        Thread {
            var data: ByteArray? = null
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 30000
                conn.readTimeout = 30000
                conn.setRequestProperty("User-Agent", ua)
                val ok = conn.responseCode in 200..299
                if (ok) data = conn.inputStream.use { it.readBytes() }
                conn.disconnect()
            } catch (_: Exception) { }
            done(if (data != null && data.isNotEmpty()) data else null)
        }.start()
    }

    fun list(done: (List<PolyHavenEntry>) -> Unit) {
        synchronized(lock) {
            if (listCache.isNotEmpty()) { done(listCache); return }
        }
        get("https://api.polyhaven.com/assets?t=textures") { d ->
            val out = ArrayList<PolyHavenEntry>()
            if (d != null) {
                try {
                    val o = JSONObject(String(d))
                    for (k in o.keys()) {
                        val e = o.optJSONObject(k) ?: continue
                        out.add(PolyHavenEntry(k, e.optString("name", k)))
                    }
                    out.sortBy { it.name.lowercase() }
                } catch (_: Exception) { }
            }
            if (out.isNotEmpty()) {
                synchronized(lock) { listCache.clear(); listCache.addAll(out) }
            }
            done(out)
        }
    }

    fun thumb(id: String, done: (Bitmap?) -> Unit) {
        synchronized(lock) { thumbs[id]?.let { done(it); return } }
        get("https://cdn.polyhaven.com/asset_img/thumbs/$id.png?width=128&height=128") { d ->
            val i = d?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
            if (i != null) synchronized(lock) { thumbs[id] = i }
            done(i)
        }
    }

    /** Downloads all maps at `res` ("1k" / "2k"), falling back to the nearest resolution each map has. */
    fun maps(id: String, res: String, done: (PolyHaven.Maps?) -> Unit) {
        get("https://api.polyhaven.com/files/$id") { d ->
            if (d == null) { done(null); return@get }
            val files = try { JSONObject(String(d)) } catch (_: Exception) { null } ?: run { done(null); return@get }
            fun url(keys: List<String>): String? {
                for (k in keys) {
                    val m = files.optJSONObject(k) ?: continue
                    for (r in listOf(res, "1k", "2k", "4k")) {
                        for (f in listOf("jpg", "png")) {
                            val u = m.optJSONObject(r)?.optJSONObject(f)?.optString("url")
                            if (!u.isNullOrEmpty()) return u
                        }
                    }
                }
                return null
            }
            val want = listOf(
                "diff" to listOf("Diffuse", "diff"), "nor" to listOf("nor_gl", "Normal"), "rough" to listOf("Rough"),
                "metal" to listOf("Metal"), "ao" to listOf("AO"), "disp" to listOf("Displacement", "Bump"))
            val got = HashMap<String, Bitmap>()
            val lck = Object()
            var remaining = 0
            fun finish() {
                if (got["diff"] == null && got["nor"] == null) { done(null); return }
                done(PolyHaven.Maps(got["diff"], got["nor"], got["rough"], got["metal"], got["ao"], got["disp"]))
            }
            for ((k, keys) in want) {
                val u = url(keys) ?: continue
                remaining++
                get(u) { data ->
                    if (data != null) {
                        val img = BitmapFactory.decodeByteArray(data, 0, data.size)
                        if (img != null) synchronized(lck) { got[k] = img }
                    }
                    synchronized(lck) {
                        remaining--
                        if (remaining == 0) finish()
                    }
                }
            }
            if (remaining == 0) finish()
        }
    }
}

// MARK: - texture packing + glb (ExtrasGLB extension; Packed holder lives in core/Terrain.kt)

object ExtrasGLB {
    /** RGBA8 pixels of `img` resampled to size x size (nil image -> nil). */
    private fun px(img: Bitmap?, size: Int): ByteArray? {
        if (img == null) return null
        val sc = if (img.width == size && img.height == size) img else Bitmap.createScaledBitmap(img, size, size, true)
        val out = IntArray(size * size)
        sc.getPixels(out, 0, size, 0, 0, size, size)
        val d = ByteArray(size * size * 4)
        for (i in out.indices) {
            val c = out[i]
            d[i * 4] = ((c shr 16) and 0xFF).toByte(); d[i * 4 + 1] = ((c shr 8) and 0xFF).toByte()
            d[i * 4 + 2] = (c and 0xFF).toByte(); d[i * 4 + 3] = ((c ushr 24) and 0xFF).toByte()
        }
        return d
    }

    private fun png(d: ByteArray, size: Int): ByteArray? {
        val bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val px = IntArray(size * size)
        for (i in 0 until size * size) {
            px[i] = (0xFF shl 24) or ((d[i * 4].toInt() and 255) shl 16) or ((d[i * 4 + 1].toInt() and 255) shl 8) or (d[i * 4 + 2].toInt() and 255)
        }
        bm.setPixels(px, 0, size, 0, 0, size, size)
        val out = ByteArrayOutputStream()
        if (!bm.compress(Bitmap.CompressFormat.PNG, 100, out)) return null
        return out.toByteArray()
    }

    private fun jpg(img: Bitmap, q: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        if (!img.compress(Bitmap.CompressFormat.JPEG, q, out)) return null
        return out.toByteArray()
    }

    fun pack(m: PolyHaven.Maps, size: Int): com.saiki.motion.core.ExtrasGLB.Packed {
        val n = size * size
        val base = m.diff?.let { jpg(it, 90) }     // colour keeps its own size; GPU loader caps at 2048
        val nor = px(m.nor, size); val rough = px(m.rough, size); val metal = px(m.metal, size)
        val ao = px(m.ao, size); val disp = px(m.disp, size)
        var mr: ByteArray? = null
        if (rough != null || metal != null || disp != null) {
            val o = ByteArray(n * 4) { 255.toByte() }
            for (i in 0 until n) {
                o[i * 4] = disp?.get(i * 4) ?: 255.toByte()
                o[i * 4 + 1] = rough?.get(i * 4) ?: 200.toByte()
                o[i * 4 + 2] = metal?.get(i * 4) ?: 0.toByte()
            }
            mr = png(o, size)
        }
        var occ: ByteArray? = null
        val dv = disp
        if (nor != null || ao != null || dv != null) {
            val o = ByteArray(n * 4) { 255.toByte() }
            for (i in 0 until n) {
                var a = (ao?.get(i * 4)?.toInt() ?: 255).toFloat() / 255f
                if (dv != null) a *= 0.8f + 0.2f * (dv[i * 4].toInt() and 255).toFloat() / 255f   // displacement -> cavity shading (bump look)
                o[i * 4] = max(0, min(255, (a * 255).toInt())).toByte()
                o[i * 4 + 1] = nor?.get(i * 4) ?: 128.toByte(); o[i * 4 + 2] = nor?.get(i * 4 + 1) ?: 128.toByte()
            }
            occ = png(o, size)
        }
        var h: ByteArray? = null
        if (dv != null) h = ByteArray(dv.size / 4) { dv[it * 4] }
        return com.saiki.motion.core.ExtrasGLB.Packed(base = base, mr = mr, occ = occ, hasNormal = nor != null, height = h)
    }

    /** Flat, finely subdivided grid facing up (+Y). The Metal model shader displaces it with waves and shades it as water. */
    fun water(res: Int = 192): ByteArray {
        val pos = ArrayList<Float>(); val nor = ArrayList<Float>(); val uv = ArrayList<Float>(); val idx = ArrayList<Int>()
        val R = res + 1
        for (j in 0 until R) for (i in 0 until R) {
            val a = i.toFloat() / res; val b = j.toFloat() / res
            pos.add(a - 0.5f); pos.add(0f); pos.add(b - 0.5f)
            nor.add(0f); nor.add(1f); nor.add(0f)
            uv.add(a); uv.add(b)
        }
        for (j in 0 until res) for (i in 0 until res) {
            val a = i + j * R
            idx.add(a); idx.add(a + 1); idx.add(a + R)
            idx.add(a + 1); idx.add(a + R + 1); idx.add(a + R)
        }
        return buildGlb("SaikiMotion Water", pos.toFloatArray(), nor.toFloatArray(), uv.toFloatArray(), idx.toIntArray(), null,
            JSONObject().put("doubleSided", true).put("alphaMode", "BLEND")
                .put("pbrMetallicRoughness", JSONObject().put("baseColorFactor", org.json.JSONArray(listOf(1, 1, 1, 1)))
                    .put("metallicFactor", 0.0).put("roughnessFactor", 0.05)))
    }

    private fun hash(x: Int, y: Int, z: Int): Float {
        var h = (x * 374761393 + y * 668265263 + z * 1274126177).toInt()
        h = ((h xor (h ushr 13)) * 1274126177).toInt()
        return ((h xor (h ushr 16)) and 0xFFFF).toFloat() / 65535f
    }

    /** Smooth value noise (0...1) — drives the procedural variation, continuous so tiles never show seams. */
    private fun vnoise(x: Float, y: Float, z: Int): Float {
        val ix = floor(x).toInt(); val iy = floor(y).toInt()
        val fx = x - floor(x); val fy = y - floor(y)
        val sx = fx * fx * (3 - 2 * fx); val sy = fy * fy * (3 - 2 * fy)
        val a = hash(ix, iy, z); val b = hash(ix + 1, iy, z); val c = hash(ix, iy + 1, z); val d = hash(ix + 1, iy + 1, z)
        return (a + (b - a) * sx) + ((c + (d - c) * sx) - (a + (b - a) * sx)) * sy
    }

    /** tiles x tiles repeats of the material per face, with domain-warped UVs and a slow colour drift (variation 0...1). */
    fun build(cube: Boolean, p: com.saiki.motion.core.ExtrasGLB.Packed?, tiles: Int, depth: Float, variation: Float): ByteArray {
        val pos = ArrayList<Float>(); val nor = ArrayList<Float>(); val uv = ArrayList<Float>(); val col = ArrayList<Float>(); val idx = ArrayList<Int>()
        val hmap = p?.height
        val hs = if (hmap != null) kotlin.math.sqrt(hmap.size.toDouble()).toInt() else 0
        fun height(u: Float, v: Float): Float {       // bilinear, wrapping
            if (hmap == null || hs <= 1) return 0.5f
            val x = (u - floor(u)) * hs; val y = (v - floor(v)) * hs
            val x0 = x.toInt() % hs; val y0 = y.toInt() % hs
            val x1 = (x0 + 1) % hs; val y1 = (y0 + 1) % hs
            val fx = x - floor(x); val fy = y - floor(y)
            fun g(a: Int, b: Int): Float = (hmap[b * hs + a].toInt() and 255).toFloat() / 255f
            return (g(x0, y0) * (1 - fx) + g(x1, y0) * fx) * (1 - fy) + (g(x0, y1) * (1 - fx) + g(x1, y1) * fx) * fy
        }
        val amp = depth * 0.25f / max(tiles, 1).toFloat()
        val res = if (cube) min(max(tiles * 40, 96), 160) else min(max(tiles * 48, 128), 320)
        var faceN = 0
        fun face(n: Triple<Float, Float, Float>, u: Triple<Float, Float, Float>, v: Triple<Float, Float, Float>, d: Float) {
            val base = pos.size / 3
            val R = res + 1
            val P = Array(R * R) { FloatArray(3) }
            for (j in 0 until R) for (i in 0 until R) {
                val a = i.toFloat() / res; val b = j.toFloat() / res
                var tu = a * tiles; var tv = b * tiles
                if (variation > 0f) {      // slow warp: no two tiles look identical, yet the field stays continuous
                    tu += (vnoise(a * 2.3f + 11f, b * 2.3f, faceN) - 0.5f) * 1.2f * variation
                    tv += (vnoise(a * 2.3f, b * 2.3f + 37f, faceN) - 0.5f) * 1.2f * variation
                }
                var hh = (height(tu, tv) - 0.5f) * amp
                if (cube) { val e = min(min(a, 1 - a), min(b, 1 - b)); hh *= min(1f, e / 0.03f) }      // keep cube edges closed
                val k = i + j * R
                P[k][0] = n.first * d + u.first * (a - 0.5f) + v.first * (0.5f - b) + n.first * hh
                P[k][1] = n.second * d + u.second * (a - 0.5f) + v.second * (0.5f - b) + n.second * hh
                P[k][2] = n.third * d + u.third * (a - 0.5f) + v.third * (0.5f - b) + n.third * hh
                uv.add(tu); uv.add(tv)
                val t = 1 + (vnoise(a * 3 + 5, b * 3 + 9, faceN + 7) - 0.5f) * 0.5f * variation
                col.add(t); col.add(t); col.add(t); col.add(1f)
            }
            for (j in 0 until R) for (i in 0 until R) {
                val pa = floatArrayOf(
                    P[min(i + 1, res) + j * R][0] - P[max(i - 1, 0) + j * R][0],
                    P[min(i + 1, res) + j * R][1] - P[max(i - 1, 0) + j * R][1],
                    P[min(i + 1, res) + j * R][2] - P[max(i - 1, 0) + j * R][2])
                val pb = floatArrayOf(
                    P[i + min(j + 1, res) * R][0] - P[i + max(j - 1, 0) * R][0],
                    P[i + min(j + 1, res) * R][1] - P[i + max(j - 1, 0) * R][1],
                    P[i + min(j + 1, res) * R][2] - P[i + max(j - 1, 0) * R][2])
                var nn = floatArrayOf(pb[1] * pa[2] - pb[2] * pa[1], pb[2] * pa[0] - pb[0] * pa[2], pb[0] * pa[1] - pb[1] * pa[0])
                val len = kotlin.math.sqrt(nn[0] * nn[0] + nn[1] * nn[1] + nn[2] * nn[2].toDouble()).toFloat()
                if (len > 1e-12f) nn = floatArrayOf(nn[0] / len, nn[1] / len, nn[2] / len) else nn = floatArrayOf(n.first, n.second, n.third)
                pos.add(P[i + j * R][0]); pos.add(P[i + j * R][1]); pos.add(P[i + j * R][2])
                nor.add(nn[0]); nor.add(nn[1]); nor.add(nn[2])
            }
            for (j in 0 until res) for (i in 0 until res) {
                val a = base + i + j * R
                idx.add(a); idx.add(a + R); idx.add(a + R + 1)
                idx.add(a); idx.add(a + R + 1); idx.add(a + 1)
            }
            faceN++
        }
        if (cube) {
            face(Triple(0f, 0f, 1f), Triple(1f, 0f, 0f), Triple(0f, 1f, 0f), 0.5f)
            face(Triple(0f, 0f, -1f), Triple(-1f, 0f, 0f), Triple(0f, 1f, 0f), 0.5f)
            face(Triple(1f, 0f, 0f), Triple(0f, 0f, -1f), Triple(0f, 1f, 0f), 0.5f)
            face(Triple(-1f, 0f, 0f), Triple(0f, 0f, 1f), Triple(0f, 1f, 0f), 0.5f)
            face(Triple(0f, 1f, 0f), Triple(1f, 0f, 0f), Triple(0f, 0f, -1f), 0.5f)
            face(Triple(0f, -1f, 0f), Triple(1f, 0f, 0f), Triple(0f, 0f, 1f), 0.5f)
        } else face(Triple(0f, 0f, 1f), Triple(1f, 0f, 0f), Triple(0f, 1f, 0f), 0f)

        var mat = JSONObject().put("doubleSided", true)
        var pbr = JSONObject().put("metallicFactor", 1.0).put("roughnessFactor", 1.0)
        val b = p?.base
        if (b != null) pbr.put("baseColorTexture", JSONObject().put("index", 0))
        else pbr.put("baseColorFactor", org.json.JSONArray(listOf(0.8, 0.8, 0.8, 1.0)))
        if (p?.mr != null) pbr.put("metallicRoughnessTexture", JSONObject().put("index", 1))
        else { pbr.put("metallicFactor", 0.0); pbr.put("roughnessFactor", 0.6) }
        if (p?.occ != null) mat.put("occlusionTexture", JSONObject().put("index", 2))
        mat = mat.put("pbrMetallicRoughness", pbr)
        val glb = buildGlb("SaikiMotion Extras", pos.toFloatArray(), nor.toFloatArray(), uv.toFloatArray(), idx.toIntArray(), col.toFloatArray(), mat,
            listOfNotNull(p?.base, p?.mr, p?.occ))
        return glb
    }

    /** Shared glTF 2.0 writer: VEC3 + VEC2 (+ optional VEC4 colour) + indices, textures appended as bufferViews. */
    private fun buildGlb(generator: String, pos: FloatArray, nor: FloatArray, uv: FloatArray, idx: IntArray, col: FloatArray?, mat: JSONObject, texs: List<ByteArray> = emptyList()): ByteArray {
        val bin = ByteArrayOutputStream()
        val views = org.json.JSONArray()
        fun add(d: ByteArray, tg: Int?): Int {
            while (bin.size() % 4 != 0) bin.write(0)
            val v = JSONObject(); v.put("buffer", 0); v.put("byteOffset", bin.size()); v.put("byteLength", d.size)
            if (tg != null) v.put("target", tg)
            bin.write(d); views.put(v); return views.length() - 1
        }
        fun fbytes(a: FloatArray): ByteArray { val b = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (x in a) b.putFloat(x); return b.array() }
        fun ibytes(a: IntArray): ByteArray { val b = ByteBuffer.allocate(a.size * 4).order(ByteOrder.LITTLE_ENDIAN); for (x in a) b.putInt(x); return b.array() }
        val vp = add(fbytes(pos), 34962); val vn = add(fbytes(nor), 34962); val vu = add(fbytes(uv), 34962); val vi = add(ibytes(idx), 34963)
        var vc = -1
        if (col != null) vc = add(fbytes(col), 34962)
        val nv = pos.size / 3
        val mn = FloatArray(3) { 1e9f }; val mx = FloatArray(3) { -1e9f }
        for (i in 0 until nv) for (k in 0 until 3) { mn[k] = min(mn[k], pos[i * 3 + k]); mx[k] = max(mx[k], pos[i * 3 + k]) }
        fun farr(a: FloatArray): org.json.JSONArray { val r = org.json.JSONArray(); for (x in a) r.put(x as Any); return r }
        fun accessor(view: Int, ct: Int, count: Int, type: String): JSONObject {
            val a = JSONObject(); a.put("bufferView", view); a.put("componentType", ct); a.put("count", count); a.put("type", type); return a
        }
        val acc = org.json.JSONArray()
        acc.put(accessor(vp, 5126, nv, "VEC3").also { it.put("min", farr(mn)).put("max", farr(mx)) })
        acc.put(accessor(vn, 5126, nv, "VEC3"))
        acc.put(accessor(vu, 5126, nv, "VEC2"))
        acc.put(accessor(vi, 5125, idx.size, "SCALAR"))
        if (vc >= 0) acc.put(accessor(vc, 5126, nv, "VEC4"))
        val images = org.json.JSONArray(); val textures = org.json.JSONArray()
        val mimes = listOf("image/jpeg", "image/png", "image/png")
        for ((i, d) in texs.withIndex()) {
            val im = JSONObject(); im.put("bufferView", add(d, null)); im.put("mimeType", mimes.getOrNull(i) ?: "image/png"); images.put(im)
            val tx = JSONObject(); tx.put("source", images.length() - 1); tx.put("sampler", 0); textures.put(tx)
        }
        val attrs = JSONObject().put("POSITION", 0).put("NORMAL", 1).put("TEXCOORD_0", 2)
        if (vc >= 0) attrs.put("COLOR_0", 4)
        val json = JSONObject()
        json.put("asset", JSONObject().put("version", "2.0").put("generator", generator))
        json.put("scene", 0).put("scenes", org.json.JSONArray().put(JSONObject().put("nodes", org.json.JSONArray().put(0))))
        json.put("nodes", org.json.JSONArray().put(JSONObject().put("mesh", 0)))
        json.put("meshes", org.json.JSONArray().put(JSONObject().put("primitives",
            org.json.JSONArray().put(JSONObject().put("attributes", attrs).put("indices", 3).put("material", 0)))))
        json.put("materials", org.json.JSONArray().put(mat))
        json.put("accessors", acc); json.put("bufferViews", views)
        while (bin.size() % 4 != 0) bin.write(0)
        json.put("buffers", org.json.JSONArray().put(JSONObject().put("byteLength", bin.size())))
        if (images.length() > 0) {
            json.put("samplers", org.json.JSONArray().put(JSONObject().put("magFilter", 9729).put("minFilter", 9987).put("wrapS", 10497).put("wrapT", 10497)))
            json.put("images", images); json.put("textures", textures)
        }
        var js = json.toString().toByteArray(Charsets.UTF_8)
        if (js.size % 4 != 0) js = js + ByteArray(4 - js.size % 4) { 0x20 }
        val bb = bin.toByteArray()
        val out = ByteBuffer.allocate(12 + 8 + js.size + 8 + bb.size).order(ByteOrder.LITTLE_ENDIAN)
        out.putInt(0x46546C67); out.putInt(2); out.putInt(12 + 8 + js.size + 8 + bb.size)
        out.putInt(js.size); out.putInt(0x4E4F534A); out.put(js)
        out.putInt(bb.size); out.putInt(0x004E4942); out.put(bb)
        return out.array()
    }
}

// MARK: - panel

class ExtrasPanel(private val host: EditorViewController) : UiView(appContext!!), UITableViewDataSource, UITableViewDelegate {
    private val accent = 0xFFFF8C14.toInt()
    private val shapeSeg = UISegmentedControl(listOf("Flat plane", "Cube", "Water"))
    private val depthSlider = UISlider(appContext!!)
    private val varSlider = UISlider(appContext!!)
    private val resSeg = UISegmentedControl(listOf("1k (fast)", "2k"))
    private val search = UISearchBar(appContext!!)
    private val table = UITableView(appContext!!)
    private val countLbl = UILabel(appContext!!)
    private val status = UILabel(appContext!!)
    private val slider = UISlider(appContext!!)
    private val addBtn = PillButton("Add to scene", null, 0xFFFF8C14.toInt(), 0xFF000000.toInt())
    private var all: List<PolyHavenNet.PolyHavenEntry> = emptyList()
    private var shown: List<PolyHavenNet.PolyHavenEntry> = emptyList()
    private var pick = -1                     // index in `shown`; -1 = plain (no texture)
    private var busy = false
    private val card = UiView(appContext!!)
    private val listHolder = UiView(appContext!!)

    companion object {
        fun present(host: EditorViewController, view: UiView) {
            if (view.subviews.any { it is ExtrasPanel }) return
            val v = ExtrasPanel(host)
            view.addSubview(v)
            v.frame = CGRect(0f, 0f, view.rectWidth(), view.rectHeight())
        }
    }

    init {
        setBackgroundColor(0x8C000000.toInt())
        addSubview(card)
        shapeSeg.selectedSegmentIndex = 0
        resSeg.selectedSegmentIndex = 0
        shapeSeg.onValueChanged = { shapeChanged() }
        search.placeholder = "Search Poly Haven textures (brick, wood, rock…)"
        search.onTextChanged = { q -> filter(q) }
        table.dataSource = this
        table.delegate = this
        table.rowHeight = 56f
        slider.minValue = 1f; slider.maxValue = 16f; slider.value = 3f
        depthSlider.minValue = 0f; depthSlider.maxValue = 1f; depthSlider.value = 0.5f
        varSlider.minValue = 0f; varSlider.maxValue = 1f; varSlider.value = 0.6f
        slider.onValueChanged = { slid() }
        countLbl.textColor = UIColor.white; countLbl.font = UIFont.boldSystemFont(15f)
        countLbl.frame = CGRect(0f, 0f, 300f, 20f)
        status.textColor = UIColor(0xFFB3B3B3.toInt()); status.font = UIFont.systemFont(12f); status.numberOfLines = 0
        status.frame = CGRect(0f, 0f, 280f, 34f)
        addBtn.textSize = 17f
        addBtn.onClick = { addTap() }
        addBtn.frame = CGRect(0f, 0f, 240f, 48f)
        card.addSubview(shapeSeg)
        card.addSubview(search)
        card.addSubview(listHolder)
        listHolder.addSubview(table)
        card.addSubview(slider)
        card.addSubview(countLbl)
        card.addSubview(depthSlider)
        card.addSubview(varSlider)
        card.addSubview(resSeg)
        card.addSubview(status)
        card.addSubview(addBtn)
        slid()
        PolyHavenNet.list { l ->
            uikitMain {
                all = l; filter("")
                if (l.isEmpty()) status.text = "Could not reach Poly Haven. Check your connection."
            }
        }
    }

    private fun uikitMain(f: () -> Unit) {
        android.os.Handler(android.os.Looper.getMainLooper()).post(f)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth(); val h = rectHeight()
        if (w < 10 || h < 10) return
        val top = safeAreaInsets.top
        card.setBackgroundColor(0xFF171717.toInt())
        card.frame = CGRect(12f, top + 40f, w - 24f, h - top - 52f)
        val cw = card.rectWidth()
        var y = 16f
        shapeSeg.frame = CGRect(16f, y, cw - 32f, 32f); y += 42f
        search.frame = CGRect(16f, y, cw - 32f, 40f); y += 48f
        listHolder.frame = CGRect(16f, y, cw - 32f, 240f)
        table.frame = CGRect(0f, 0f, listHolder.rectWidth(), 240f)
        table.reloadData()
        y += 248f
        slider.frame = CGRect(16f, y, cw - 32f, 30f); y += 32f
        countLbl.frame = CGRect(16f, y, cw - 32f, 20f); y += 24f
        depthSlider.frame = CGRect(16f, y, cw - 32f, 30f); y += 32f
        varSlider.frame = CGRect(16f, y, cw - 32f, 30f); y += 32f
        resSeg.frame = CGRect(16f, y, cw - 32f, 32f); y += 40f
        status.frame = CGRect(16f, y, cw - 32f, 34f); y += 38f
        addBtn.frame = CGRect(16f, y, cw - 32f, 48f)
    }

    private fun shapeChanged() {
        val isWater = shapeSeg.selectedSegmentIndex == 2
        search.isHidden = isWater
        listHolder.isHidden = isWater
        addBtn.text = if (isWater) "Add water" else "Add to scene"
        status.text = if (isWater) "Waves, foam, depth and colour are adjustable in the layer's properties." else ""
    }

    private fun slid() {
        val n = slider.value.toInt()
        countLbl.text = "$n × $n tiles per side (procedural, varied per tile)"
    }

    // list

    private fun filter(q: String) {
        val k = q.trim().lowercase()
        shown = if (k.isEmpty()) all else all.filter { it.name.lowercase().contains(k) || it.id.contains(k) }
        pick = -1
        table.reloadData()
    }

    override fun numberOfRows(t: UITableView, section: Int): Int = shown.size + 1

    override fun cellForRow(t: UITableView, row: Int): UITableViewCell {
        val c = UITableViewCell(appContext!!)
        c.setBackgroundColor(0x00000000)
        c.textLabel?.textColor = UIColor.white
        val i = row - 1
        c.textLabel?.text = if (i < 0) "Plain (no texture)" else shown[i].name
        c.accessoryType = if (i == pick) 1 else 0
        if (i >= 0) {
            val id = shown[i].id
            PolyHavenNet.thumb(id) { img ->
                uikitMain {
                    if (img != null && row - 1 < shown.size && shown[row - 1].id == id) {
                        c.setThumb(img)
                    }
                }
            }
        }
        return c
    }

    override fun didSelectRow(t: UITableView, row: Int) {
        pick = row - 1
        table.reloadData()
    }

    // build + import

    private fun addTap() {
        if (busy) return
        busy = true; addBtn.alpha = 0.5f
        val cube = shapeSeg.selectedSegmentIndex == 1
        val count = slider.value.toInt()
        val depth = depthSlider.value
        val vari = varSlider.value
        val res = if (resSeg.selectedSegmentIndex == 0) "1k" else "2k"
        val tex = if (pick >= 0 && pick < shown.size) shown[pick] else null
        if (shapeSeg.selectedSegmentIndex == 2) {      // Extras > Water
            busy = false; addBtn.alpha = 1f
            val path = ProjectIO.writeDataIntoSandbox(ExtrasGLB.water(), "extras_water_${nowMs()}.glb")
            if (path == null) { status.text = "Could not build the water."; return }
            host.addMedia(path, LayerType.MODEL)
            val l = Editor.scene.layers.lastOrNull { it.imagePath == path }
            if (l != null) {
                l.name = "Water"
                l.xset("water", 1f); l.xset("wAmp", 0.03f); l.xset("wFreq", 6f); l.xset("wSpeed", 1f)
                l.xset("wChop", 0.5f); l.xset("wFoam", 0.5f); l.xset("wDepth", 0.5f)
                host.render(); host.refreshPanel()
            }
            removeFromSuperview(); return
        }
        status.text = if (tex == null) "Building…" else "Downloading ${tex.name} maps…"
        fun finish(glb: ByteArray?, name: String, maps: Map<String, String>) {
            uikitMain {
                busy = false; addBtn.alpha = 1f
                if (glb == null) { status.text = "Could not build the object."; return@uikitMain }
                val path = ProjectIO.writeDataIntoSandbox(glb, "extras_${name}_${nowMs()}.glb")
                if (path == null) { status.text = "Could not build the object."; return@uikitMain }
                host.addMedia(path, LayerType.MODEL)
                val l = Editor.scene.layers.lastOrNull { it.imagePath == path }
                if (l != null) {
                    l.name = "${if (cube) "Cube" else "Plane"} · $name"
                    // every Poly Haven map is attached as its own texture: the PBR shader displaces real vertices
                    // with the height map, adds parallax + self-shadow, and uses the normal / roughness / metal / AO maps directly
                    l.pbrMaps.putAll(maps)
                    l.xset("pbrDisp", if (cube) 0.02f else 0.06f * max(depth, 0.3f))
                    l.xset("pbrSub", 0f); l.xset("pbrPar", 0.03f)
                    host.render(); host.refreshPanel()
                }
                removeFromSuperview()
            }
        }
        Thread {
            if (tex == null) {
                finish(ExtrasGLB.build(cube, null, count, 0f, vari), "plain", emptyMap())
                return@Thread
            }
            PolyHavenNet.maps(tex.id, res) { m ->
                if (m == null) {
                    uikitMain { busy = false; addBtn.alpha = 1f; status.text = "Download failed. Try again." }
                    return@maps
                }
                val files = HashMap<String, String>()
                fun save(key: String, img: Bitmap?) {
                    if (img == null) return
                    val d = ByteArrayOutputStream()
                    if (!img.compress(Bitmap.CompressFormat.PNG, 100, d)) return
                    val path = ProjectIO.writeDataIntoSandbox(d.toByteArray(), "pbr_${tex.id}_${key}_$res.png") ?: return
                    files[key] = path
                }
                save("albedo", m.diff); save("normal", m.nor); save("rough", m.rough)
                save("metal", m.metal); save("ao", m.ao); save("height", m.disp)
                finish(ExtrasGLB.build(cube, null, count, 0f, vari), tex.id, files)
            }
        }.start()
    }
}
