@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/FontBrowserViewController.swift — browse, import and organise fonts, pick one
// for a text layer.

package com.saiki.motion.ui

import android.graphics.Typeface
import com.saiki.motion.app.Dlg
import com.saiki.motion.app.DocPicker
import com.saiki.motion.core.FontFolder
import com.saiki.motion.core.FontLibrary
import com.saiki.motion.core.FontRecord
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UISearchBar
import com.saiki.motion.uikit.UITableViewController
import com.saiki.motion.uikit.UITableView
import com.saiki.motion.uikit.UITableViewCell
import com.saiki.motion.uikit.UITableViewDataSource
import com.saiki.motion.uikit.UITableViewDelegate
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.appContext
import java.io.File
import java.util.Locale

class FontBrowserViewController(private val folderId: String?) : UIViewController(), UITableViewDataSource, UITableViewDelegate {
    var onPick: ((FontRecord) -> Unit)? = null
    var currentPath: String? = null
    private val table = UITableView(appContext!!)
    private val titleLabel = UILabel(appContext!!)
    private val empty = UILabel(appContext!!)
    private var folders = listOf<com.saiki.motion.core.FontFolder>()
    private var fonts = listOf<FontRecord>()
    private var query = ""
    private val search = UISearchBar(appContext!!)
    private val addBtn = PillButton("＋", null, C.CARD2, C.TEXT)
    private val closeBtn = PillButton("✕", null, C.CARD2, C.TEXT)

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        val name = folderId?.let { id -> FontLibrary.folders.firstOrNull { it.id == id }?.name } ?: "Fonts"
        titleLabel.text = name
        titleLabel.font = UIFont.boldSystemFont(18f); titleLabel.textColor = argbToUIColor(C.TEXT)
        titleLabel.textAlignment = NSTextAlignment.center

        closeBtn.onClick = { closeTap() }
        addBtn.onClick = { addTap() }
        view.addSubview(closeBtn); view.addSubview(addBtn); view.addSubview(titleLabel)

        search.placeholder = "Search fonts"
        search.onTextChanged = { t -> query = t; reload() }
        view.addSubview(search)

        table.setBackgroundColor(0x00000000)
        table.dataSource = this
        table.delegate = this
        table.rowHeight = 62f
        view.addSubview(table)

        empty.text = "No fonts yet.\nTap + to import font files or a .zip of fonts."
        empty.numberOfLines = 0; empty.textAlignment = NSTextAlignment.center
        empty.textColor = argbToUIColor(C.DIM); empty.font = UIFont.systemFont(14f)
        view.addSubview(empty)
        reload()
        view.onLayout = { _ -> layoutAll() }
        layoutAll()
    }

    private fun layoutAll() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w < 10 || h < 10) return
        val top = kotlin.math.max(view.safeAreaInsets.top, 8f)
        closeBtn.frame = CGRect(6f, top, 48f, 44f)
        addBtn.frame = CGRect(w - 54f, top, 48f, 44f)
        titleLabel.frame = CGRect(60f, top, w - 120f, 44f)
        search.frame = CGRect(8f, top + 46f, w - 16f, 44f)
        val ty = top + 92f
        table.frame = CGRect(0f, ty, w, h - ty)
        empty.frame = CGRect(30f, ty + 40f, w - 60f, 80f)
    }

    private fun reload() {
        val q = query.lowercase()
        if (q.isEmpty()) {
            folders = if (folderId == null) FontLibrary.folders else emptyList()
            fonts = FontLibrary.fonts(folderId)
        } else {
            folders = emptyList()
            fonts = FontLibrary.fonts.filter { it.name.lowercase().contains(q) }
                .sortedBy { it.name.lowercase() }
        }
        empty.isHidden = !(folders.isEmpty() && fonts.isEmpty() && q.isEmpty())
        table.reloadData()
    }

    // MARK: actions

    private fun closeTap() {
        val nav = navigationController
        if (nav != null && nav.viewControllers.size > 1) nav.popViewController(animated = true)
        else dismiss(animated = true)
    }

    private fun addTap() {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items.add("Import fonts / ZIP…" to { pickFiles() })
        if (folderId == null) {
            items.add("New folder" to {
                prompt("New folder", "") { n -> FontLibrary.addFolder(n); reload() }
            })
        }
        items.add("Cancel" to {})
        Dlg(this).setTitle("").setItems(items.map { it.first }) { _, i -> items[i].second() }.show()
    }

    private fun pickFiles() {
        DocPicker.pick { uri ->
            Toast.show("Importing fonts…")
            val fid = folderId
            Thread {
                val n = FontLibrary.importURLs(listOf(uri), fid)
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    Toast.show(if (n > 0) "Added $n font${if (n == 1) "" else "s"}" else "No usable .ttf / .otf fonts found")
                    reload()
                }
            }.start()
        }
    }

    private fun prompt(title: String, text: String, done: (String) -> Unit) {
        val f = com.saiki.motion.uikit.UITextField(appContext!!)
        f.text = text
        Dlg(this).setTitle(title).setView(f).setPositiveButton("OK") { _, _ ->
            val t = f.text.trim()
            if (t.isNotEmpty()) done(t)
        }.setNegativeButton("Cancel", null).show()
    }

    private fun moveSheet(f: FontRecord) {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        if (f.folder != null) items.add("Fonts (top level)" to { FontLibrary.move(f.id, null); reload() })
        for (fo in FontLibrary.folders) {
            if (fo.id == f.folder) continue
            items.add(fo.name to { FontLibrary.move(f.id, fo.id); reload() })
        }
        items.add("New folder…" to {
            prompt("New folder", "") { nm -> FontLibrary.move(f.id, FontLibrary.addFolder(nm).id); reload() }
        })
        items.add("Cancel" to {})
        Dlg(this).setTitle("Move “${f.name}”").setItems(items.map { it.first }) { _, i -> items[i].second() }.show()
    }

    // MARK: table

    override fun numberOfRows(t: UITableView, section: Int): Int = if (section == 0) folders.size else fonts.size

    private fun sectionOf(row: Int): Int = row

    override fun cellForRow(t: UITableView, row: Int): UITableViewCell {
        val c = UITableViewCell(appContext!!)
        c.setBackgroundColor(0x00000000)
        c.textLabel?.textColor = argbToUIColor(C.TEXT)
        if (row < folders.size) {
            val f = folders[row]
            c.textLabel?.font = UIFont.boldSystemFont(16f)
            c.textLabel?.text = f.name
            val n = FontLibrary.count(f.id)
            c.detailTextLabel?.text = "$n font${if (n == 1) "" else "s"}"
        } else {
            val fi = row - folders.size
            if (fi >= fonts.size) return c
            val f = fonts[fi]
            val path = FontLibrary.path(f)
            // try the font itself for the label (registered per-call; fallback = system font)
            var face: Typeface? = null
            try { face = Typeface.createFromFile(File(path)) } catch (_: Exception) { }
            val l = c.textLabel
            if (l != null) {
                val p = if (face != null) android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    typeface = face; textSize = 20f
                } else null
                l.text = f.name
                if (p != null) l.drawBlock = { cv -> cv.drawText(f.name, 0f, 20f, p) }
            }
            c.detailTextLabel?.text = "The quick brown fox 0123"
        }
        return c
    }

    override fun didSelectRow(t: UITableView, row: Int) {
        if (row < folders.size) {
            val vc = FontBrowserViewController(folders[row].id)
            vc.onPick = onPick; vc.currentPath = currentPath
            val nav = navigationController
            if (nav != null) nav.pushViewController(vc, animated = true)
            else present(vc, animated = true)
        } else {
            val fi = row - folders.size
            if (fi >= fonts.size) return
            onPick?.invoke(fonts[fi])
            dismiss(animated = true)
        }
    }

    fun deleteRow(row: Int) {
        if (row < folders.size) {
            FontLibrary.deleteFolder(folders[row].id)
        } else {
            val fi = row - folders.size
            if (fi < fonts.size) FontLibrary.delete(fonts[fi].id)
        }
        reload()
    }

    fun renameRow(row: Int) {
        if (row < folders.size) {
            val f = folders[row]
            prompt("Rename folder", f.name) { n -> FontLibrary.renameFolder(f.id, n); reload() }
        } else {
            val fi = row - folders.size
            if (fi < fonts.size) {
                val f = fonts[fi]
                prompt("Rename font", f.name) { n -> FontLibrary.rename(f.id, n); reload() }
            }
        }
    }

    fun moveRow(row: Int) {
        val fi = row - folders.size
        if (fi in fonts.indices) moveSheet(fonts[fi])
    }
}
