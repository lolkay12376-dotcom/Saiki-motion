@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import com.saiki.motion.core.Ease
import com.saiki.motion.core.Editor
import com.saiki.motion.core.clamp
import com.saiki.motion.core.roundAway
import com.saiki.motion.core.Key
import com.saiki.motion.core.Track
import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.CGLineCap
import com.saiki.motion.uikit.CGLineJoin
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.UIControl
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.argbToUIColor
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot

// Port of Sources/UI/GraphEditor.swift — curve editors: GraphView (bezier), ValueGraphView, CurveThumb.

// MARK: - GraphView

/// Cubic bezier easing editor: drag the two handles.
class GraphView : UIControl() {
    var key: Key? = null
    var onBeginCb: (() -> Unit)? = null       // Swift onBegin
    var onChange: (() -> Unit)? = null
    private var drag = 0
    private val pad: CGFloat = 24f

    init {
        // Opaque + cleared on every draw: without this, dragging a handle smeared
        // dozens of old curves on top of each other.
        setBackgroundColor(android.graphics.Color.BLACK)
        clipsToBounds = true
    }

    private fun px(x: Float): CGFloat = pad + x * (boundsRect.width - 2 * pad)
    private fun py(y: Float): CGFloat = boundsRect.height - pad - (y + 0.5f) / 2f * (boundsRect.height - 2 * pad)
    private fun ux(x: CGFloat): Float = clamp((x - pad) / (boundsRect.width - 2 * pad), 0f, 1f)
    private fun uy(y: CGFloat): Float = clamp((boundsRect.height - pad - y) / (boundsRect.height - 2 * pad) * 2f - 0.5f, -0.5f, 1.5f)

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        c.setFillColor(android.graphics.Color.BLACK)
        c.fill(boundsRect)
        for (i in 0..4) {
            val gx = px(i.toFloat() / 4f)
            strokeLine(c, gx, py(-0.5f), gx, py(1.5f), 1f, 0xFF2A2A30.toInt())
        }
        for (i in 0..4) {
            val gy = py(-0.5f + i * 0.5f)
            strokeLine(c, px(0f), gy, px(1f), gy, 1f, 0xFF2A2A30.toInt())
        }
        val kk: Key? = key
        val k: Key
        if (kk == null) {
            drawText("Select a property with 2+ keyframes", boundsRect.width / 2, boundsRect.height / 2,
                     color = C.DIM, size = 12f, align = NSTextAlignment.center)
            return
        } else {
            k = kk
        }
        // reference style: white curve, green handles, green endpoints
        c.setStrokeColor(argbToUIColor(C.TEXT).cgColor)
        c.setLineWidth(3f)
        c.setLineCap(CGLineCap.round)
        c.setLineJoin(CGLineJoin.round)
        c.beginPath()
        for (i in 0..60) {
            val u = i.toFloat() / 60f
            val x = px(u); val y = py(Track.easeAt(k, u))
            if (i == 0) c.move(CGPoint(x, y)) else c.addLine(CGPoint(x, y))
        }
        c.strokePath()
        if (k.isBezier() && !k.rev) {
            strokeLine(c, px(0f), py(0f), px(k.x1), py(k.y1), 1.5f, C.GREEN)
            strokeLine(c, px(1f), py(1f), px(k.x2), py(k.y2), 1.5f, C.GREEN)
            // white ring + green core — clearly grabbable
            for (h in listOf(Pair(k.x1, k.y1), Pair(k.x2, k.y2))) {
                fillCircle(c, px(h.first), py(h.second), 8f, C.GREEN)
                strokeCircle(c, px(h.first), py(h.second), 8f, 2f, C.TEXT)
            }
        }
        // endpoint dots: small green rings at (0,0) and (1,1)
        strokeCircle(c, px(0f), py(0f), 4.5f, 2f, C.GREEN)
        strokeCircle(c, px(1f), py(1f), 4.5f, 2f, C.GREEN)
    }

    override fun touchesBegan(touches: Set<UITouch>, event: UIEvent?) {
        val k = key
        if (k == null || !k.isBezier() || k.rev) return
        val t = touches.firstOrNull() ?: return
        val pt = t.location(this)
        val d1 = hypot(pt.x - px(k.x1), pt.y - py(k.y1))
        val d2 = hypot(pt.x - px(k.x2), pt.y - py(k.y2))
        drag = if (minOf(d1, d2) > 40f) 0 else (if (d1 <= d2) 1 else 2)
        if (drag != 0) {
            onBeginCb?.invoke()
            disallowParentScrollInterception(this, true)
        }
    }

    override fun touchesMoved(touches: Set<UITouch>, event: UIEvent?) {
        val k = key ?: return
        if (drag == 0) return
        val t = touches.firstOrNull() ?: return
        val pt = t.location(this)
        if (k.ease != Ease.CUSTOM) k.ease = Ease.CUSTOM
        if (drag == 1) { k.x1 = ux(pt.x); k.y1 = uy(pt.y) } else { k.x2 = ux(pt.x); k.y2 = uy(pt.y) }
        onChange?.invoke()
        setNeedsDisplay()
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(this, false)
    }

    override fun touchesCancelled(touches: Set<UITouch>, event: UIEvent?) {
        drag = 0
        disallowParentScrollInterception(this, false)
    }
}

// MARK: - ValueGraphView

/// Read-only plot of a parameter over time with its keyframes; tap a keyframe to select it.
class ValueGraphView : UIControl() {
    var track: Track? = null
    var t0: Float = 0f
    var t1: Float = 1f
    var selIdx = 0
    var speedMode = false
    var onPick: ((Int) -> Unit)? = null
    private val pad: CGFloat = 14f

    private fun fv(tr: Track, t: Float): Float =
        if (speedMode) (tr.eval(t + 0.01f) - tr.eval(t - 0.01f)) / 0.02f else tr.eval(t)

    init {
        clipsToBounds = true
    }

    private fun xOf(t: Float): CGFloat =
        pad + ((t - t0) / (t1 - t0)) * (boundsRect.width - 2 * pad)

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        fillRoundRect(c, CGRect(0f, 0f, boundsRect.width, boundsRect.height), 10f, C.CARD)
        val tr = track ?: return
        var lo = Float.MAX_VALUE
        var hi = -Float.MAX_VALUE
        val vs = FloatArray(81)
        for (i in 0..80) {
            val v = fv(tr, t0 + (t1 - t0) * i.toFloat() / 80f)
            vs[i] = v
            lo = minOf(lo, v)
            hi = maxOf(hi, v)
        }
        if (hi - lo < 1e-4f) hi = lo + 1f
        fun yOf(v: Float): CGFloat =
            boundsRect.height - pad - ((v - lo) / (hi - lo)) * (boundsRect.height - 2 * pad)
        c.setStrokeColor(argbToUIColor(C.TEXT).cgColor)
        c.setLineWidth(2.5f)
        c.setLineCap(CGLineCap.round)
        c.setLineJoin(CGLineJoin.round)
        c.beginPath()
        for (i in 0..80) {
            val x = xOf(t0 + (t1 - t0) * i.toFloat() / 80f)
            val y = yOf(vs[i])
            if (i == 0) c.move(CGPoint(x, y)) else c.addLine(CGPoint(x, y))
        }
        c.strokePath()
        // playhead
        val pxv = xOf(Editor.time)
        if (pxv >= 0f && pxv <= boundsRect.width) {
            strokeLine(c, pxv, pad, pxv, boundsRect.height - pad, 1f, C.GREEN)
        }
        for ((i, k) in tr.keys.withIndex()) {
            val on = i == selIdx
            val col: Int = if (on) C.GREEN else C.TEXT
            if (on) {
                strokeCircle(c, xOf(k.t), yOf(fv(tr, k.t)), 8f, 2f, C.GREEN)
            }
            fillCircle(c, xOf(k.t), yOf(fv(tr, k.t)), if (on) 5.5f else 4.5f, col)
        }
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        val tr = track ?: return
        val t = touches.firstOrNull() ?: return
        val x = t.location(this).x
        var best = -1
        var bd: CGFloat = 32f
        for ((i, k) in tr.keys.withIndex()) {
            val dd = abs(xOf(k.t) - x)
            if (dd < bd) { bd = dd; best = i }
        }
        if (best >= 0) onPick?.invoke(best)
    }
}

// MARK: - CurveThumb

/// Small card showing the shape of an easing curve; used as a preset thumbnail.
class CurveThumb(val key: Key, val name: String) : TapView() {
    var sel = false
    /** Outline color (argb) or 0 for none — GraphPanel's category / preset selection ring. */
    var outline: Int = 0

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        fillRoundRect(c, CGRect(1f, 1f, boundsRect.width - 2f, boundsRect.height - 2f), 12f, C.CARD)
        if (sel) {
            c.setStrokeColor(argbToUIColor(C.GREEN).cgColor)
            c.setLineWidth(2f)
            val pth = com.saiki.motion.uikit.UIBezierPath(CGRect(1f, 1f, boundsRect.width - 2f, boundsRect.height - 2f), 12f)
            c.addPath(pth.cgPath)
            c.strokePath()
        }
        if (outline != 0) {
            c.setStrokeColor(argbToUIColor(outline).cgColor)
            c.setLineWidth(2f)
            val pth = com.saiki.motion.uikit.UIBezierPath(CGRect(1f, 1f, boundsRect.width - 2f, boundsRect.height - 2f), 12f)
            c.addPath(pth.cgPath)
            c.strokePath()
        }
        val px: CGFloat = 14f
        val top: CGFloat = 12f
        val bot = boundsRect.height - 24f
        c.setStrokeColor(argbToUIColor(if (sel) C.GREEN else C.TEXT).cgColor)
        c.setLineWidth(2.5f)
        c.setLineCap(CGLineCap.round)
        c.beginPath()
        for (i in 0..40) {
            val u = i.toFloat() / 40f
            val y = clamp(Track.easeAt(key, u), -0.4f, 1.4f)
            val xx = px + u * (boundsRect.width - 2 * px)
            val yy = bot - ((y + 0.4f) / 1.8f) * (bot - top)
            if (i == 0) c.move(CGPoint(xx, yy)) else c.addLine(CGPoint(xx, yy))
        }
        c.strokePath()
        drawText(name, boundsRect.width / 2, boundsRect.height - 8f, color = if (sel) C.GREEN else C.DIM, size = 10f, align = NSTextAlignment.center)
    }
}
