@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import com.saiki.motion.core.Editor
import com.saiki.motion.core.clamp
import com.saiki.motion.core.roundAway
import com.saiki.motion.core.Ease
import com.saiki.motion.core.Key
import com.saiki.motion.core.Track
import com.saiki.motion.core.Paths
import com.saiki.motion.app.Dlg
import com.saiki.motion.uikit.currentActivity
import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.CGLineCap
import com.saiki.motion.uikit.CGLineJoin
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UILongPressGestureRecognizer
import com.saiki.motion.uikit.UIGestureRecognizerState
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UIStackView
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIButton
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UIEdgeInsets
import com.saiki.motion.uikit.NSLayoutConstraintConstraintAxis
import com.saiki.motion.uikit.UIStackViewAlignment
import com.saiki.motion.uikit.UIStackViewDistribution
import com.saiki.motion.uikit.argbToUIColor
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

// Port of Sources/UI/GraphPanel.swift — the graph editor panel: tabs, curve-type dropdown,
// draggable knobs, preset column (UI).
//
//   [ icons ] [ Ease  Value  Speed          Position · ◆1 → ◆2 ] [ + ]
//   [  x    ] [ [Bounce ▾]                   bounce(8, 1.00, in)] [ preset ]
//   [ swap  ] [          the curve, with knobs on it             ] [ preset ]
//   [ paste ] [                                                  ] [ preset ]
//   [ reset ] [                                                  ] [ ...    ]
//
// Knobs: bezier = the two handles; bounce / elastic / wave = a green strength knob (drag up / down) and an
// orange count knob (drag up / down); steps = the orange count knob. Tapping the "bounce(8, 1.00, in)" label
// cycles in / out / in-out.

private val kGreen = 0xFF34D26B.toInt()
private val kOrange = 0xFFF5A623.toInt()
private val kPanel = 0xFF141416.toInt()

// MARK: - the curve

class CurveGraphView(val key: Key) : UiView(com.saiki.motion.uikit.appContext!!) {
    var onBeginCb: (() -> Unit)? = null       // Swift onBegin
    var onChange: (() -> Unit)? = null
    var onRefresh: (() -> Unit)? = null

    private class Knob(val id: String, val p: CGPoint, val color: Int, val text: String, val left: Boolean)
    private var drag = ""
    private val ins = UIEdgeInsets(14f, 30f, 16f, 22f)
    private val lo: Float get() = if (key.isBezier()) -0.5f else -0.1f
    private val hi: Float get() = if (key.isBezier()) 1.5f else 1.35f

    init {
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        isMultipleTouchEnabled = false
    }

    // coordinates
    private val w: CGFloat get() = boundsRect.width - ins.left - ins.right
    private val h: CGFloat get() = boundsRect.height - ins.top - ins.bottom
    private fun X(u: Float): CGFloat = ins.left + u * w
    private fun Y(v: Float): CGFloat = ins.top + ((hi - v) / (hi - lo)) * h
    private fun U(x: CGFloat): Float = clamp((x - ins.left) / w, 0f, 1f)
    private fun V(y: CGFloat): Float = hi - ((y - ins.top) / h) * (hi - lo)

    private fun y(u: Float): Float = Track.easeAt(key, u)

    /** Where the strength knob sits: the last peak before the end of the curve. */
    private fun peakU(): Float {
        var ymax = -10f
        for (i in 0..200) ymax = max(ymax, y(i.toFloat() / 200f * 0.99f))
        var best = 0.5f
        for (i in 0..400) { val u = i.toFloat() / 400f * 0.99f; if (y(u) >= ymax - 0.003f) best = u }
        return best
    }

    private val hasAmp: Boolean get() = key.ease == Ease.BOUNCE || key.ease == Ease.ELASTIC || key.ease == Ease.WAVE
    private val hasCount: Boolean get() = hasAmp || key.ease == Ease.STEPS

    private val countWord: String
        get() = when (key.ease) { Ease.BOUNCE -> "Bounces"; Ease.STEPS -> "Steps"; else -> "Cycles" }

    /// First peak and the trough right after it - the two knobs sit ON the curve like handles you can grab.
    private fun firstPeakTrough(): Pair<Float, Float?> {
        val n = 600
        var pk = 0.2f; var pkSet = false
        var prev = y(0f); var up = false
        for (i in 1..n) {
            val u = i.toFloat() / n.toFloat() * 0.99f; val v = y(u)
            if (!pkSet) { if (v > prev) up = true; else if (up && v < prev - 1e-5f) { pk = u; pkSet = true } }
            else if (v > prev + 1e-5f) return Pair(pk, u)
            prev = v
        }
        return Pair(if (pkSet) pk else peakU(), null)
    }

    private fun knobs(): List<Knob> {
        val out = ArrayList<Knob>()
        if (key.isBezier() && !key.rev) {
            out.add(Knob("b1", CGPoint(X(key.x1), Y(key.y1)), kGreen, "", false))
            out.add(Knob("b2", CGPoint(X(key.x2), Y(key.y2)), kGreen, "", false))
        }
        if (hasAmp) {
            val (pu, tu) = firstPeakTrough()
            out.add(Knob("amp", CGPoint(X(pu), Y(y(pu))), kGreen, "${roundAway(key.amp * 100f).toInt()}%", false))
            if (tu != null) {          // drag sideways: fewer / more cycles
                out.add(Knob("cnt", CGPoint(X(tu), Y(y(tu))), kOrange, "$countWord ${key.cn}", false))
            } else {
                out.add(Knob("cnt", CGPoint(X(1f), Y(0.1f * key.cn)), kOrange, "$countWord ${key.cn}", true))
            }
        } else if (key.ease == Ease.STEPS) {
            out.add(Knob("cnt", CGPoint(X(1f), Y(0.1f * key.cn)), kOrange, "$countWord ${key.cn}", true))
        }
        return out
    }
    private var cntStart: Pair<Int, Float>? = null

    /** "bounce(8, 1.00, in)" */
    val infoText: String
        get() {
            val mode = arrayOf("in", "out", "in-out")[min(max(key.bm, 0), 2)]
            return when (key.ease) {
                Ease.BOUNCE -> if (key.bm == 3) "bounce" else String.format(Locale.US, "bounce(%d, %.2f, %s)", key.cn, key.amp, mode)
                Ease.ELASTIC -> if (key.bm == 3) "elastic" else String.format(Locale.US, "elastic(%d, %.2f, %s)", key.cn, key.amp, mode)
                Ease.WAVE -> String.format(Locale.US, "wave(%d, %.2f)", key.cn, key.amp)
                Ease.STEPS -> "steps(${key.cn})"
                Ease.LINEAR -> "linear"
                else -> String.format(Locale.US, "cubic-bezier(%.2f, %.2f, %.2f, %.2f)", key.x1, key.y1, key.x2, key.y2)
            }
        }
    private val infoRect: CGRect get() = CGRect(boundsRect.width - 190f, 2f, 184f, 24f)

    private fun text(s: String, p: CGPoint, color: Int, size: CGFloat, right: Boolean = false, bold: Boolean = false) {
        // Swift: NSString.size/draw with font + foregroundColor, y = vertical CENTRE of the string.
        val pnt = (if (bold) boldFont(size) else sysFont(size)).toPaint()
        pnt.setColor(color)
        val wpt = pnt.measureText(s)
        val xx: CGFloat = if (right) p.x - wpt else p.x
        val fm = pnt.fontMetrics
        val baseline = p.y - (fm.ascent + fm.descent) / 2f
        val c = UIGraphics.getCurrentContext() ?: return
        c.canvas.drawText(s, xx, baseline, pnt)
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        fillRoundRect(c, boundsRect, 12f, 0xFF0F0F11.toInt())
        val grid = 0xFF26262B.toInt()
        for (i in 0..10) { strokeLine(c, X(i.toFloat() / 10f), Y(lo), X(i.toFloat() / 10f), Y(hi), 1f, if (i % 5 == 0) 0xFF2E2E34.toInt() else 0xFF1B1B1F.toInt()) }
        for (v in listOf(0f, 1f)) { strokeLine(c, X(0f), Y(v), X(1f), Y(v), 1f, grid) }
        text("1", CGPoint(12f, Y(1f)), 0xFF999999.toInt(), 11f)
        text("0", CGPoint(12f, Y(0f)), 0xFF999999.toInt(), 11f)
        // linear reference
        strokeLine(c, X(0f), Y(0f), X(1f), Y(1f), 1.5f, 0xFF3A3A40.toInt())
        // end marker: dashed green line
        c.saveGState()
        c.setStrokeColor(argbToUIColor(kGreen).withAlphaComponent(0.8f).cgColor)
        c.setLineWidth(1.2f); c.setLineDash(0f, floatArrayOf(3f, 3f))
        c.move(CGPoint(X(1f), Y(hi))); c.addLine(CGPoint(X(1f), Y(lo))); c.strokePath()
        c.restoreGState()
        // curve
        c.setStrokeColor(android.graphics.Color.WHITE)
        c.setLineWidth(2.6f); c.setLineCap(CGLineCap.round); c.setLineJoin(CGLineJoin.round)
        c.beginPath()
        val n = 480
        for (i in 0..n) {
            val u = i.toFloat() / n.toFloat()
            var v = y(u)
            if (key.rev) v = 1f - y(1f - u)
            val pt = CGPoint(X(u), Y(clamp(v, lo, hi)))
            if (i == 0) c.move(pt) else c.addLine(pt)
        }
        c.strokePath()
        fillCircle(c, X(0f), Y(0f), 3.5f, 0xFFDDDDDD.toInt())
        fillCircle(c, X(1f), Y(1f), 4f, kGreen)
        text(infoText, CGPoint(boundsRect.width - 8f, 14f), 0xFF9E9E9E.toInt(), 11f, right = true)
        // knobs
        for (k in knobs()) {
            if (key.isBezier()) {
                val anchor = if (k.id == "b1") CGPoint(X(0f), Y(0f)) else CGPoint(X(1f), Y(1f))
                strokeLine(c, anchor.x, anchor.y, k.p.x, k.p.y, 1.5f, kGreen)
            }
            if (key.isBezier() && (k.id == "b1" || k.id == "b2")) {
                fillCircle(c, k.p.x, k.p.y, 17f, 0xFFF2F2F4.toInt())          // white handle, green line (like the reference)
                strokeCircle(c, k.p.x, k.p.y, 13f, 2.5f, kGreen)
            } else {
                fillCircle(c, k.p.x, k.p.y, 13f, k.color)
                strokeCircle(c, k.p.x, k.p.y, 13f, 2.5f, 0xFFF2F2F4.toInt())
            }
            if (k.text.isNotEmpty()) {
                val col = k.color
                if (k.left) text(k.text, CGPoint(k.p.x - 19f, k.p.y), col, 12f, right = true)
                else text(k.text, CGPoint(min(k.p.x + 19f, boundsRect.width - 54f), k.p.y - (if (k.id == "cnt") -16f else 16f)), col, 12f)
            }
        }
    }

    // touches
    override fun touchesBegan(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val pt = t.location(this)
        if ((key.ease == Ease.BOUNCE || key.ease == Ease.ELASTIC) && key.bm != 3 && infoRect.contains(pt)) {
            onBeginCb?.invoke()
            key.bm = (key.bm + 1) % 3
            onChange?.invoke(); setNeedsDisplay()
            return
        }
        var best = ""; var bd: CGFloat = 46f
        for (k in knobs()) { val d = hypot(pt.x - k.p.x, pt.y - k.p.y); if (d < bd) { bd = d; best = k.id } }
        drag = best
        if (drag == "cnt" && hasAmp) { val tu = firstPeakTrough().second; cntStart = if (tu != null) Pair(key.cn, tu) else null } else cntStart = null
        if (drag.isNotEmpty()) { onBeginCb?.invoke(); disallowParentScrollInterception(this, true) }
    }

    override fun touchesMoved(touches: Set<UITouch>, event: UIEvent?) {
        if (drag.isEmpty()) return
        val t = touches.firstOrNull() ?: return
        val pt = t.location(this)
        when (drag) {
            "b1" -> { if (key.ease != Ease.CUSTOM) key.ease = Ease.CUSTOM; key.x1 = U(pt.x); key.y1 = clamp(V(pt.y), -0.5f, 1.5f) }
            "b2" -> { if (key.ease != Ease.CUSTOM) key.ease = Ease.CUSTOM; key.x2 = U(pt.x); key.y2 = clamp(V(pt.y), -0.5f, 1.5f) }
            "cnt" -> {
                val cs = cntStart
                if (cs != null) { val (c0, u0) = cs; key.cn = clamp(roundAway(c0.toFloat() * u0 / max(0.04f, U(pt.x))).toInt(), 1, 12) }
                else { key.cn = clamp(roundAway(V(pt.y) / 0.1f).toInt(), 1, 12) }
            }
            "amp" -> {
                if (key.bm == 3) key.bm = 0       // an old fixed curve becomes the adjustable one as soon as it is tuned
                val u = peakU(); val target = clamp(V(pt.y), lo, hi)
                for (q in 0 until 4) {            // solve amp so the curve passes through the finger at the knob's x
                    val cur = y(u); val a0 = key.amp
                    key.amp = a0 + 0.05f
                    val d = (y(u) - cur) / 0.05f
                    key.amp = a0
                    if (abs(d) < 0.02f) break
                    key.amp = clamp(a0 + (target - cur) / d, 0f, 2f)
                }
            }
        }
        onChange?.invoke()
        setNeedsDisplay()
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        if (drag.isNotEmpty()) { drag = ""; disallowParentScrollInterception(this, false); onRefresh?.invoke() }
    }
    override fun touchesCancelled(touches: Set<UITouch>, event: UIEvent?) {
        if (drag.isNotEmpty()) { drag = ""; disallowParentScrollInterception(this, false) }
    }
}

// MARK: - the panel

class GraphPanelView(val key: Key) : UiView(com.saiki.motion.uikit.appContext!!) {
    // data
    var tab = 0
    var title = ""
    var segText = "◆1 → ◆2"
    // callbacks
    var onBeginCb: (() -> Unit)? = null       // Swift onBegin
    var onChange: (() -> Unit)? = null
    var onRefresh: (() -> Unit)? = null
    var onTab: ((Int) -> Unit)? = null
    var onClose: (() -> Unit)? = null
    var onCycleSegment: (() -> Unit)? = null
    var onCopy: (() -> Unit)? = null
    var onPaste: (() -> Unit)? = null
    var makeValueView: ((Boolean) -> UiView)? = null

    init {
        setBackgroundColor(kPanel)
        clipsToBounds = true
    }

    fun build() {
        for (v in subviews) v.removeFromSuperview()
        val left = column()
        left.addArrangedSubview(iconButton("chevron.left") { onClose?.invoke() })
        left.addArrangedSubview(iconButton("arrow.left.arrow.right") {
            onBeginCb?.invoke(); key.rev = !key.rev; onChange?.invoke(); onRefresh?.invoke()
        })
        // == iOS UIMenu(showsMenuAsPrimaryAction) on the ellipsis button: a real popup menu
        // anchored at the button, same four items in the same order.
        val more = iconButtonAnchored("ellipsis") { anchor ->
            val act = currentActivity?.get() ?: return@iconButtonAnchored
            val popup = android.widget.PopupMenu(act, anchor)
            popup.menu.add("Copy curve")
            popup.menu.add("Paste curve")
            popup.menu.add("Save as preset")
            popup.menu.add("Reset curve")
            popup.setOnMenuItemClickListener { mi ->
                when (mi.title) {
                    "Copy curve" -> onCopy?.invoke()
                    "Paste curve" -> onPaste?.invoke()
                    "Save as preset" -> saveCustom()
                    else -> { onBeginCb?.invoke(); key.preset(Ease.EASE_IN_OUT); key.rev = false; onChange?.invoke(); onRefresh?.invoke() }
                }
                true
            }
            popup.show()
        }
        left.addArrangedSubview(more)

        // top row: tabs + title
        val tabs = UIStackView(); tabs.axis = NSLayoutConstraintConstraintAxis.horizontal; tabs.spacing = 18f
        for ((i, n) in listOf("Ease", "Value", "Speed").withIndex()) {
            val b = UIButton()
            b.title = n
            b.font = UIFont.semiboldSystemFont(15f)
            b.titleColor = if (i == tab) argbToUIColor(kGreen) else UIColor2(0.72f)
            b.onTouchUpInside = { onTab?.invoke(i) }
            tabs.addArrangedSubview(b)
        }
        val info = UIButton()
        info.title = segText
        info.font = UIFont.systemFont(12f, 600)
        info.titleColor = UIColor2(0.7f)
        info.onTouchUpInside = { onCycleSegment?.invoke() }
        val spacer = UiView()
        val top = UIStackView(listOf(tabs, spacer, info)); top.axis = NSLayoutConstraintConstraintAxis.horizontal; top.alignment = UIStackViewAlignment.center

        // centre: curve or value / speed plot
        val centre = UiView()
        if (tab == 0) {
            val g = CurveGraphView(key)
            g.onBeginCb = { onBeginCb?.invoke() }
            g.onChange = { onChange?.invoke() }
            g.onRefresh = { onRefresh?.invoke() }
            fill(g, centre)
        } else {
            val v = makeValueView?.invoke(tab == 2)
            if (v != null) fill(v, centre)
        }
        val midViews = ArrayList<UiView>(listOf(top, centre))
        if (tab == 0) midViews.add(nameRow())
        val mid = UIStackView(midViews); mid.axis = NSLayoutConstraintConstraintAxis.vertical; mid.spacing = 6f

        val cats = categoryColumn()
        val presets = presetColumn()

        val row = UIStackView(if (tab == 0) listOf(left, mid, presets, cats) else listOf(left, mid))
        row.axis = NSLayoutConstraintConstraintAxis.horizontal; row.spacing = 10f; row.alignment = UIStackViewAlignment.fill
        addSubview(row)
        // Auto-layout constants from the Swift code: 10pt margins, left col 40, top row 28pt tall,
        // preset + category columns 54pt wide each (tab 0 only).
        row.frame = CGRect(10f, 10f, rectWidth() - 20f, rectHeight() - 20f)
        left.frame = CGRect(0f, 0f, 40f, left.frame.height)
        top.frame = CGRect(0f, 0f, top.frame.width, 28f)
        presets.frame = CGRect(0f, 0f, 54f, presets.frame.height)
        cats.frame = CGRect(0f, 0f, 54f, cats.frame.height)
    }

    private fun fill(v: UiView, host: UiView) {
        host.addSubview(v)
        v.frame = CGRect(0f, 0f, host.rectWidth(), host.rectHeight())
    }

    private fun column(): UIStackView {
        val s = UIStackView(); s.axis = NSLayoutConstraintConstraintAxis.vertical; s.spacing = 6f; s.distribution = UIStackViewDistribution.equalSpacing; s.alignment = UIStackViewAlignment.center
        return s
    }

    private fun iconButton(symbol: String, f: () -> Unit): UIButton {
        val b = UIButton()
        b.image = Icons.sf(symbol)
        b.tintColor = UIColor2(0.92f)
        b.onTouchUpInside = { f() }
        b.frame = CGRect(0f, 0f, 40f, 40f)
        return b
    }
    /** iconButton variant whose tap handler receives the button itself (popup-menu anchor). */
    private fun iconButtonAnchored(symbol: String, f: (UIButton) -> Unit): UIButton {
        val b = UIButton()
        b.image = Icons.sf(symbol)
        b.tintColor = UIColor2(0.92f)
        b.onTouchUpInside = { f(b) }
        b.frame = CGRect(0f, 0f, 40f, 40f)
        return b
    }

    // curve-type name (shown in the [<] name [>] row)
    private fun typeName(): String {
        return when (key.ease) {
            Ease.LINEAR -> "Linear"
            Ease.EASE_IN -> "Ease In"
            Ease.EASE_OUT -> "Ease Out"
            Ease.EASE_IN_OUT -> "Ease In-Out"
            Ease.BOUNCE -> "Bounce"
            Ease.ELASTIC -> "Elastic"
            Ease.WAVE -> "Wave"
            Ease.STEPS -> "Steps"
            else -> {
                for ((n, k) in GraphPanelView.builtins())
                    if (k.ease == Ease.CUSTOM && abs(k.x1 - key.x1) < 0.005f && abs(k.y1 - key.y1) < 0.005f && abs(k.x2 - key.x2) < 0.005f && abs(k.y2 - key.y2) < 0.005f) return n
                "Bezier"
            }
        }
    }

    private fun apply(n: String) {
        onBeginCb?.invoke()
        fun bz(x1: Float, y1: Float, x2: Float, y2: Float) { key.ease = Ease.CUSTOM; key.x1 = x1; key.y1 = y1; key.x2 = x2; key.y2 = y2 }
        key.rev = false
        when (n) {
            "Linear" -> key.preset(Ease.LINEAR)
            "Ease In" -> key.preset(Ease.EASE_IN)
            "Ease Out" -> key.preset(Ease.EASE_OUT)
            "Ease In-Out" -> key.preset(Ease.EASE_IN_OUT)
            "Bezier" -> { if (!key.isBezier()) key.preset(Ease.EASE_IN_OUT); key.ease = Ease.CUSTOM }
            "Back" -> bz(0.34f, 1.56f, 0.64f, 1f)
            "Expo" -> bz(0.7f, 0f, 0.84f, 0f)
            "Snap" -> bz(1f, 0f, 0f, 1f)
            "Elastic" -> key.preset(Ease.ELASTIC)
            "Bounce" -> key.preset(Ease.BOUNCE)
            "Wave" -> { key.ease = Ease.WAVE; key.amp = 1f; key.cn = 2 }
            else -> { key.ease = Ease.STEPS; key.cn = 4 }
        }
        onChange?.invoke(); onRefresh?.invoke()
    }

    // presets
    companion object {
        private const val customKey = "graphCustomPresets"

        fun builtins(): List<Pair<String, Key>> {
            fun bz(x1: Float, y1: Float, x2: Float, y2: Float): Key { val k = Key(0f, 0f, Ease.CUSTOM); k.x1 = x1; k.y1 = y1; k.x2 = x2; k.y2 = y2; return k }
            val el = Key(0f, 0f, Ease.ELASTIC); el.preset(Ease.ELASTIC)
            val bo = Key(0f, 0f, Ease.BOUNCE); bo.preset(Ease.BOUNCE)
            val bo2 = Key(0f, 0f, Ease.BOUNCE); bo2.preset(Ease.BOUNCE); bo2.cn = 3; bo2.bm = 1
            val wv = Key(0f, 0f, Ease.WAVE); wv.cn = 2
            val st = Key(0f, 0f, Ease.STEPS); st.cn = 4
            return listOf(Pair("Linear", Key(0f, 0f, Ease.LINEAR)), Pair("Ease In", Key(0f, 0f, Ease.EASE_IN)), Pair("Ease Out", Key(0f, 0f, Ease.EASE_OUT)),
                    Pair("Ease In-Out", Key(0f, 0f, Ease.EASE_IN_OUT)), Pair("Back", bz(0.34f, 1.56f, 0.64f, 1f)), Pair("Expo", bz(0.7f, 0f, 0.84f, 0f)),
                    Pair("Snap", bz(1f, 0f, 0f, 1f)), Pair("Elastic", el), Pair("Bounce Out", bo2), Pair("Bounce", bo), Pair("Wave", wv), Pair("Steps", st))
        }

        private fun sp() = Paths.appContext.getSharedPreferences("saiki", android.content.Context.MODE_PRIVATE)

        fun customPresets(): List<Key> {
            val arr = runCatching { JSONArray(sp().getString(customKey, "[]") ?: "[]") }.getOrNull() ?: JSONArray()
            val out = ArrayList<Key>()
            for (i in 0 until arr.length()) {
                val d = arr.optJSONObject(i) ?: continue
                val k = Key(0f, 0f, Ease.of(d.optInt("e", 3)) ?: Ease.EASE_IN_OUT)
                k.x1 = d.optDouble("x1", 0.42).toFloat(); k.y1 = d.optDouble("y1", 0.0).toFloat(); k.x2 = d.optDouble("x2", 0.58).toFloat(); k.y2 = d.optDouble("y2", 1.0).toFloat()
                k.amp = d.optDouble("a", 1.0).toFloat(); k.cn = d.optInt("n", 3); k.bm = d.optInt("m", 0)
                out.add(k)
            }
            return out
        }
    }

    private fun saveCustom() {
        val sp = sp()
        val arr = runCatching { JSONArray(sp.getString(GraphPanelView.customKey, "[]") ?: "[]") }.getOrNull() ?: JSONArray()
        val o = JSONObject()
        o.put("e", key.ease.raw.toDouble()); o.put("x1", key.x1.toDouble()); o.put("y1", key.y1.toDouble()); o.put("x2", key.x2.toDouble()); o.put("y2", key.y2.toDouble())
        o.put("a", key.amp.toDouble()); o.put("n", key.cn.toDouble()); o.put("m", key.bm.toDouble())
        arr.put(o)
        sp.edit().putString(GraphPanelView.customKey, arr.toString()).apply()
        Toast.show("Curve saved to presets")
        onRefresh?.invoke()
    }

    // MARK: categories / presets

    private fun catOf(k: Key): Int {
        return when (k.ease) { Ease.BOUNCE -> 1; Ease.ELASTIC -> 2; Ease.WAVE -> 3; Ease.STEPS -> 4; else -> 0 }
    }

    private fun presetsIn(cat: Int): List<Key> {
        fun mk(e: Ease, cn: Int = 3, amp: Float = 1f, bm: Int = 0): Key {
            val k = Key(0f, 0f, e); if (e == Ease.BOUNCE || e == Ease.ELASTIC) k.preset(e); k.cn = cn; k.amp = amp; if (bm != 0 || e == Ease.BOUNCE || e == Ease.ELASTIC) k.bm = bm; return k
        }
        val out: ArrayList<Key>
        when (cat) {
            1 -> out = arrayListOf(builtins().first { it.first == "Bounce" }.second, builtins().first { it.first == "Bounce Out" }.second, mk(Ease.BOUNCE, 2, 1f, 1), mk(Ease.BOUNCE, 5, 0.8f, 1))
            2 -> out = arrayListOf(builtins().first { it.first == "Elastic" }.second, mk(Ease.ELASTIC, 3, 0.6f, 1), mk(Ease.ELASTIC, 6, 1f, 0))
            3 -> out = arrayListOf(mk(Ease.WAVE, 2), mk(Ease.WAVE, 3, 0.7f), mk(Ease.WAVE, 5, 0.5f), mk(Ease.WAVE, 1, 1.4f))
            4 -> out = arrayListOf(mk(Ease.STEPS, 3), mk(Ease.STEPS, 4), mk(Ease.STEPS, 6), mk(Ease.STEPS, 10))
            else -> out = ArrayList(builtins().filter { listOf("Linear", "Ease In", "Ease Out", "Ease In-Out", "Back", "Expo", "Snap").contains(it.first) }.map { it.second })
        }
        out.addAll(customPresets().filter { if (cat == 0) !(it.ease == Ease.BOUNCE || it.ease == Ease.ELASTIC || it.ease == Ease.WAVE || it.ease == Ease.STEPS) else (it.ease == listOf(Ease.LINEAR, Ease.BOUNCE, Ease.ELASTIC, Ease.WAVE, Ease.STEPS)[cat]) })
        return out
    }

    private fun same(a: Key, b: Key): Boolean {
        if (a.ease != b.ease) return false
        return when (a.ease) {
            Ease.BOUNCE, Ease.ELASTIC, Ease.WAVE -> a.cn == b.cn && abs(a.amp - b.amp) < 0.02f && (a.ease == Ease.WAVE || a.bm == b.bm)
            Ease.STEPS -> a.cn == b.cn
            Ease.CUSTOM -> abs(a.x1 - b.x1) < 0.005f && abs(a.y1 - b.y1) < 0.005f && abs(a.x2 - b.x2) < 0.005f && abs(a.y2 - b.y2) < 0.005f
            else -> true
        }
    }

    private fun pick(k: Key) {
        onBeginCb?.invoke(); key.copyCurveFrom(k); key.rev = false; onChange?.invoke(); onRefresh?.invoke()
    }

    /// [<]  Bounce  [>]  - steps through the presets of the current category.
    private fun nameRow(): UiView {
        val list = presetsIn(catOf(key))
        val idx = list.indexOfFirst { same(it, key) }.let { if (it < 0) null else it }
        fun arrow(sym: String, d: Int): UIButton {
            val b = UIButton()
            b.image = Icons.sf(sym)
            b.tintColor = UIColor2(0.85f)
            b.onTouchUpInside = {
                if (list.isNotEmpty()) {
                    val n = idx?.let { (it + d + list.size) % list.size } ?: (if (d > 0) 0 else list.size - 1)
                    pick(list[n])
                }
            }
            b.frame = CGRect(0f, 0f, 44f, 32f)
            return b
        }
        val name = UILabel(); name.text = typeName(); name.textAlignment = NSTextAlignment.center
        name.textColor = UIColor2(0.75f); name.font = UIFont.systemFont(14f, 600)
        val r = UIStackView(listOf(arrow("chevron.left", -1), name, arrow("chevron.right", 1)))
        r.axis = NSLayoutConstraintConstraintAxis.horizontal; r.alignment = UIStackViewAlignment.fill; r.spacing = 8f
        r.frame = CGRect(0f, 0f, r.frame.width, 32f)
        return r
    }

    private fun scrollColumn(items: List<UiView>): UiView {
        val scroll = UIScrollView()
        scroll.showsVerticalScrollIndicator = false
        val stack = UIStackView(items); stack.axis = NSLayoutConstraintConstraintAxis.vertical; stack.spacing = 6f
        scroll.addSubview(stack)
        return scroll
    }

    /// Right-most column: Bezier / Bounce / Elastic / Wave / Steps. The active one has an orange outline.
    private fun categoryColumn(): UiView {
        val cur = catOf(key)
        val items = ArrayList<UiView>()
        val reps = listOf(Key(0f, 0f, Ease.EASE_IN_OUT), presetsIn(1)[0], presetsIn(2)[0], presetsIn(3)[0], presetsIn(4)[1])
        for ((i, k) in reps.withIndex()) {
            val t = CurveThumb(k, "")
            t.outline = if (i == cur) 0xFFFF8C1A.toInt() else 0
            t.onClick = {
                if (i != cur) pick(if (i == 0) Key(0f, 0f, Ease.EASE_IN_OUT) else presetsIn(i)[0])
            }
            t.frame = CGRect(0f, 0f, 54f, 54f)
            items.add(t)
        }
        return scrollColumn(items)
    }

    /// Presets of the active category.
    private fun presetColumn(): UiView {
        val items = ArrayList<UiView>()
        for (k in presetsIn(catOf(key))) {
            val t = CurveThumb(k, "")
            t.outline = if (same(k, key)) kGreen else 0
            t.onClick = { pick(k) }
            t.frame = CGRect(0f, 0f, 54f, 54f)
            items.add(t)
        }
        return scrollColumn(items)
    }
}

/** Swift UIColor(white:alpha:) twin. */
private fun UIColor2(white: Float): com.saiki.motion.uikit.UIColor =
    com.saiki.motion.uikit.UIColor.rgb(white, white, white, 1f)
