@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.currentActivity
import com.saiki.motion.uikit.capScrollOf

private val EXPRESSION_DOC_PLACEHOLDER: String
    get() = "Expressions: combine tracks with + - * /, use t (seconds), markers by name, sin/cos/abs/min/max/pow/sqrt/random. Example: x * (1 + 0.2 * sin(t * 2 * PI))."

// Port of Sources/UI/HelpDocs.swift — in-app documentation (Settings > Help). Static text tables,
// rendered by DocView (DocVC twin) with StaticLayout.
object HelpDocs {
    val puppet: List<Pair<String, String>> = listOf(
        Pair("Puppet: overview", "Puppet bends an image layer by pinning points on it. Drag a pin and the picture warps around it; pins you don't touch hold their place. Open it from the layer's toolbar (Puppet). The panel has three tabs: Pin, Mesh and Sway."),
        Pair("Pin tab", "Add: tap the layer to drop a pin. Select: tap a pin to pick it. Multi: pick several pins and move them together. Drag a pin to deform the layer. With Auto-key on, every drag records a keyframe on that pin (tracks named pp<id>x / pp<id>y), so you can edit, ease and graph them like any other property. Fine mode slows dragging for small moves. Delete removes the selected pins; Clear removes all."),
        Pair("Mesh tab", "Density sets how many triangles cover the layer (low / medium / high / ultra). Higher density follows pins more smoothly but costs more to preview. Stiffness controls how local a pin's pull is: higher keeps the warp close to the pin, lower spreads it wide. Show Mesh draws the triangle grid on the preview."),
        Pair("Sway tab: Auto Sway", "Auto Sway animates the pins for you. The master switch turns every sway on the layer on or off. Lock root keeps the first pin of each chain fixed so the effect hangs from it, like hair from a scalp or a flag from a pole."),
        Pair("Sway: stacking effects", "A layer can have many sway effects. Tap + Wave or + Physics to add one; each shows as a chip (Wave 1, Physics 2 ...). Select a chip to edit it, disable it, or delete it. All enabled effects are added together, so you can run a slow Wave for the breeze plus Physics for reaction to movement. Each effect has its own pin chain."),
        Pair("Pin chain", "Tap pins from root to tip. The number on the pin button is its place in the chain. The root moves least and the tip moves most. All in order picks every pin in the order they were placed. At least 2 pins are needed."),
        Pair("Wave", "Procedural swinging that needs no animation. Speed: cycles per second. Strength: swing angle at the tip in degrees. Wave: delay between pins, which makes the motion ripple along the chain. Tip weight: how quickly the effect grows toward the tip. Randomness and Seed vary each pin. Light / Medium / Heavy are quick strength presets."),
        Pair("Physics", "Physics makes the chain react to movement. Move, rotate or scale the layer (or its parent, or animate its pins) and the chain lags behind, overshoots and settles like a real object. Light / Medium / Heavy sets the mass: light is bouncy, heavy is slow and sags. Stiffness is how hard the chain pulls back to its rest pose. Damping is how fast the swinging dies down. Gravity pulls the chain downward. Wind pushes it sideways in gusts (negative values blow left). Strength scales how far it may lag. Physics is calculated from the layer's recent motion, so it looks the same when scrubbing, playing and exporting."),
        Pair("Linking to keyframes and expressions", "On a Physics effect, tap Link stiffness / damping / gravity / wind. This creates a layer track named sw<n>stiff, sw<n>damp, sw<n>grav or sw<n>wind (n is the effect's position, starting at 0). Keyframe the track or add an expression to it in the graph editor, for example to make wind rise over time, or to drive gravity from a marker. Tap the button again to unlink and return to the slider value."),
        Pair("Tips", "Use two or three pins per limb or strand. Put pins outside the area you want to keep still, and one pin on a fixed spot to anchor it. For a character that walks or jumps, add Physics to hair and clothes, put the layer in a parent that moves, and keep Lock root on. If the warp looks stretched, add a pin near the stretched spot or raise density."))

    val gettingStarted: List<Pair<String, String>> = listOf(
        Pair("Projects", "Home > Projects lists your projects. Tap + to create one, tap a project to open the editor. Projects save automatically."),
        Pair("Adding media", "In the editor, import images, video, audio, text, 3D models and drawings as layers. Each layer has its own parameters, keyframes and effects."),
        Pair("Parameters", "Every parameter is a scrolling ruler: drag left or right to change it, hold still to type an exact value, tap the name to open its graph. On iPad the rulers are drawn larger automatically."))

    val timeline: List<Pair<String, String>> = listOf(
        Pair("Layers", "Layers stack in the timeline; drag the ends to trim, drag the body to move. Parent a layer to another to inherit its movement. Position, scale, rotation, anchor and opacity are all animatable."),
        Pair("Keyframes", "Turn Auto-key on, move the playhead and change a value: a keyframe is recorded. A diamond beside a parameter shows it has keyframes. Tap the name of a keyframed parameter to open the graph editor and shape the easing."),
        Pair("Anchor point", "Anchor X / Y set the pivot a layer rotates and scales around; changing them keeps the picture in place. 3D and model layers also have Anchor Z, which moves the pivot along the depth axis."),
        Pair("Expressions", "Long-press a parameter to add an expression. An orange outline means an expression is active."))

    val scene3d: List<Pair<String, String>> = listOf(
        Pair("Camera gestures", "One finger: orbit. Two fingers: pan. Pinch: dolly in and out. Three fingers: drag up or down to dolly fast. Keep all three fingers down together while dragging; two-finger pan and pinch pause while three fingers are down so they no longer fight the dolly. Double-tap an object to fly to it, double-tap empty space to return to the centre."),
        Pair("Moving objects", "Tap an object to select it, then use Move, Rotate or Scale. In Rotate, drag a ring to turn around one axis, or drag the object itself for yaw and pitch."),
        Pair("Extras", "Scene 3D + > Extras adds a plane or cube with a Poly Haven PBR material, water, or terrain."))

    val drawing: List<Pair<String, String>> = listOf(
        Pair("Tools", "Brush, Eraser, Smudge, Eyedropper, Transform and Magic Wand. Brush and eraser tips can be customised; eraser presets fade softly instead of cutting in one go."),
        Pair("Layers", "Add, duplicate, merge down, reorder, group in folders and clear layers from the layer panel. Transparent areas show a checkerboard; choose a white paper in the paper switch if you want a solid background."),
        Pair("Selection", "The Selection Layer holds the selection as a blue overlay. Paint on it, use the wand, invert it, or copy / cut / paste the selected pixels."),
        Pair("Navigating", "Two fingers pan, pinch zooms and twisting rotates the canvas. Undo and redo keep full history per stroke."))

    val effects: List<Pair<String, String>> = listOf(
        Pair("Adding effects", "Open a layer's Effects panel and pick from the gallery. Effects stack from the top of the list down; reorder them to change the result."),
        Pair("Looks", "Looks apply colour grades and LUTs. Combine with blend modes to layer them over footage."),
        Pair("Problem effects", "If an effect crashes or freezes, it is logged. See Extras > Crash reports."))

    val rendering: List<Pair<String, String>> = listOf(
        Pair("Export", "Use the Render button in the editor. The overlay shows progress and lets you cancel."),
        Pair("Live render cache", "Renders frames ahead so playback is smooth. Toggle it in Extras. Clear cache frees space and never touches projects."),
        Pair("Pre-render groups", "Bakes groups to frames to speed up heavy scenes. Turn it off in Extras if a group looks stale."))

    val extrasHelp: List<Pair<String, String>> = listOf(
        Pair("Crash reports", "Open crash logs lists reports saved by the app; send them with bug reports."),
        Pair("Language", "Pick the app language at the bottom of Extras; every tab updates immediately."))

    val topics: List<Pair<String, List<Pair<String, String>>>> = listOf(
        Pair("Getting started", gettingStarted), Pair("Layers, timeline & keyframes", timeline), Pair("3D scene & gestures", scene3d),
        Pair("Drawing editor", drawing), Pair("Effects & looks", effects), Pair("Rendering & cache", rendering), Pair("Puppet", puppet),
        Pair("Expression reference", listOf(Pair("Expressions", EXPRESSION_DOC_PLACEHOLDER))),
        Pair("Extras & settings", extrasHelp))

    fun show(title: String, sections: List<Pair<String, String>>) {
        val act = currentActivity?.get() ?: return
        val d = DocView(act, title, sections)
        act.setContentView(d)          // full-screen replace (modal fullScreen twin); back key handled by DocView
    }
}

/** DocVC twin: bar + scrolling attributed text. */
class DocView(context: android.content.Context, val docTitle: String, val sections: List<Pair<String, String>>) : UiView(context) {
    private val scroll = capScrollOf(context)
    private val content = object : UiView(context) {
        override fun draw(rect: CGRect) { /* handled in onDraw below */ }
    }

    private var _close: TapView? = null
    val closeButton: TapView? get() = _close

    init {
        setBackgroundColor(C.BG)
        addSubview(scroll)
        scroll.addSubview(content)
        // pre-build the static layouts
        var y = 14f
        val hp = TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = C.GREEN; textSize = 17f; isFakeBoldText = true }
        val bp = TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = C.TEXT; textSize = 15f }
        val built = ArrayList<Triple<StaticLayout, StaticLayout, Float>>()   // (head, body, y)
        val w = (context.resources.displayMetrics.widthPixels - 32f)
        for ((h, b) in sections) {
            val hl = StaticLayout.Builder.obtain(h, 0, h.length, hp, w.toInt()).setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(0f, 1f).build()
            val bl = StaticLayout.Builder.obtain(b, 0, b.length, bp, w.toInt()).setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(3f, 1f).build()
            built.add(Triple(hl, bl, y))
            y += hl.height + 6 + bl.height + 22
        }
        val totalH = y + 40f
        content.frame = CGRect(0f, 0f, context.resources.displayMetrics.widthPixels.toFloat(), totalH)
        scroll.contentSize = CGSize(context.resources.displayMetrics.widthPixels.toFloat(), totalH)
        val items = built
        content.drawBlock = { c ->
            for ((hl, bl, yy) in items) {
                c.save()
                c.translate(16f, yy)
                hl.draw(c)
                c.translate(0f, hl.height + 6f)
                bl.draw(c)
                c.restore()
            }
        }
        // close button
        val close = object : TapView() {
            override fun draw(rect: CGRect) {
                drawText("Close", rect.midX, rect.midY + 5f, color = C.GREEN, size = 15f, bold = true, align = NSTextAlignment.center)
            }
        }
        close.onClick = { (context as? android.app.Activity)?.finish() }
        addSubview(close)
        _close = close
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth(); val h = rectHeight()
        scroll.frame = CGRect(0f, 96f, w, if (h - 96f > 0f) h - 96f else 0f)
        closeButton?.frame = CGRect(w - 90f, 48f, 74f, 36f)
        setNeedsDisplay()
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        fillRect(c, CGRect(0f, 0f, rect.width, 96f), C.PANEL)
        drawText(docTitle, 16f, 60f, color = C.TEXT, size = 18f, bold = true, align = NSTextAlignment.left)
    }
}
