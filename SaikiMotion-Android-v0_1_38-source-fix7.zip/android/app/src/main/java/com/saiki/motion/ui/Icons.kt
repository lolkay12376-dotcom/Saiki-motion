// Icons.kt — the vector icon kit (24x24 path icons) + the IconView button.
// Port of iOS Sources/UI/Icons.swift.

package com.saiki.motion.ui

import android.graphics.DashPathEffect
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import com.saiki.motion.uikit.CGBlendMode
import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGLineCap
import com.saiki.motion.uikit.CGLineJoin
import com.saiki.motion.uikit.CGPath
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UIGestureRecognizerState
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIGraphicsImageRenderer
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.UILongPressGestureRecognizer
import com.saiki.motion.uikit.UITouch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// MARK: - Icons

/** Vector icons drawn with Paths on a 24x24 grid. No emoji or font glyphs are used anywhere in the UI. */
object Icons {
    fun draw(c: CGContext, name: String, cx: CGFloat, cy: CGFloat,
             size: CGFloat, color: Int) {
        c.saveGState()
        c.translateBy(cx - size / 2, cy - size / 2)
        c.scaleBy(size / 24, size / 24)

        var p = CGPath()

        fun strokePaint() {
            c.setStrokeColor(color)
            c.setLineWidth(2f)
            c.setLineCap(CGLineCap.round)
            c.setLineJoin(CGLineJoin.round)
        }
        fun fillPaint() { c.setFillColor(color) }
        fun strokePath() { c.addPath(p.path); c.strokePath(); p = CGPath() }
        fun fillPath() { c.addPath(p.path); c.fillPath(); p = CGPath() }
        fun circleFill(x: CGFloat, y: CGFloat, r: CGFloat) {
            fillPaint(); c.fillEllipse(CGRect(x - r, y - r, 2 * r, 2 * r))
        }
        fun circleStroke(x: CGFloat, y: CGFloat, r: CGFloat) {
            strokePaint(); c.strokeEllipse(CGRect(x - r, y - r, 2 * r, 2 * r))
        }
        fun rrStroke(rect: CGRect, rad: CGFloat) {
            strokePaint()
            c.addPath(CGPath.roundedRect(rect, rad, rad))
            c.strokePath()
        }
        fun rrFill(rect: CGRect, rad: CGFloat) {
            fillPaint()
            c.addPath(CGPath.roundedRect(rect, rad, rad))
            c.fillPath()
        }
        fun line(x0: CGFloat, y0: CGFloat, x1: CGFloat, y1: CGFloat) {
            strokePaint()
            c.move(CGPoint(x0, y0))
            c.addLine(CGPoint(x1, y1))
            c.strokePath()
        }
        fun rectFill(rect: CGRect) { fillPaint(); c.fill(rect) }
        fun mv(x: CGFloat, y: CGFloat) { p.move(CGPoint(x, y)) }
        fun lt(x: CGFloat, y: CGFloat) { p.addLine(CGPoint(x, y)) }
        fun closeP() { p.closeSubpath() }
        fun quad(cx1: CGFloat, cy1: CGFloat, x: CGFloat, y: CGFloat) {
            p.addQuadCurve(CGPoint(x, y), CGPoint(cx1, cy1))
        }
        fun cubic(c1x: CGFloat, c1y: CGFloat, c2x: CGFloat, c2y: CGFloat, x: CGFloat, y: CGFloat) {
            p.addCurve(CGPoint(x, y), CGPoint(c1x, c1y), CGPoint(c2x, c2y))
        }

        when (name) {
        "back" -> {
            strokePaint(); mv(15f, 5f); lt(8f, 12f); lt(15f, 19f); strokePath()
        }
        "cube" -> {
            strokePaint()
            mv(12f, 3f); lt(20f, 7.5f); lt(20f, 16.5f); lt(12f, 21f); lt(4f, 16.5f); lt(4f, 7.5f); closeP()
            mv(4f, 7.5f); lt(12f, 12f); lt(20f, 7.5f)
            mv(12f, 12f); lt(12f, 21f)
            strokePath()
        }
        "cmd" -> {
            rrStroke(CGRect(3f, 4f, 18f, 16f), 3f)
            strokePaint(); mv(7f, 9f); lt(11f, 12f); lt(7f, 15f); strokePath()
            mv(13f, 15.5f); lt(17f, 15.5f); strokePath()
        }
        "dots" -> {
            for (i in 0 until 3) { for (j in 0 until 3) { circleFill(6f + i * 6f, 6f + j * 6f, 1.5f) } }
        }
        "dup" -> {
            rrStroke(CGRect(3f, 3f, 11f, 11f), 2f)
            rrStroke(CGRect(10f, 10f, 11f, 11f), 2f)
        }
        "more" -> {
            circleFill(12f, 5f, 1.8f); circleFill(12f, 12f, 1.8f); circleFill(12f, 19f, 1.8f)
        }
        "grid" -> {
            rrStroke(CGRect(3f, 3f, 18f, 18f), 2f)
            strokePaint()
            mv(9f, 3f); lt(9f, 21f); mv(15f, 3f); lt(15f, 21f)
            mv(3f, 9f); lt(21f, 9f); mv(3f, 15f); lt(21f, 15f)
            strokePath()
        }
        "bookmark", "bookmark_f" -> {
            if (name == "bookmark_f") { fillPaint() } else { strokePaint() }
            mv(6f, 3f); lt(18f, 3f); lt(18f, 21f); lt(12f, 16.5f); lt(6f, 21f); closeP()
            if (name == "bookmark_f") { fillPath() } else { strokePath() }
        }
        "prev" -> {
            strokePaint()
            mv(18f, 5f); lt(8f, 12f); lt(18f, 19f); closeP()
            mv(5f, 5f); lt(5f, 19f)
            strokePath()
        }
        "next" -> {
            strokePaint()
            mv(6f, 5f); lt(16f, 12f); lt(6f, 19f); closeP()
            mv(19f, 5f); lt(19f, 19f)
            strokePath()
        }
        "play" -> {
            fillPaint(); mv(7f, 4f); lt(20f, 12f); lt(7f, 20f); closeP(); fillPath()
        }
        "pause" -> {
            rectFill(CGRect(6f, 4f, 4f, 16f))
            rectFill(CGRect(14f, 4f, 4f, 16f))
        }
        "layers" -> {
            fillPaint(); mv(12f, 3f); lt(22f, 9f); lt(12f, 15f); lt(2f, 9f); closeP(); fillPath()
            strokePaint(); mv(2f, 13f); lt(12f, 19f); lt(22f, 13f); strokePath()
        }
        "undo", "redo" -> {
            strokePaint()
            if (name == "redo") { c.translateBy(24f, 0f); c.scaleBy(-1f, 1f) }
            mv(9f, 5f); lt(4f, 10f); lt(9f, 15f)
            mv(4f, 10f); lt(14f, 10f)
            cubic(18.5f, 10f, 21f, 12.5f, 21f, 17f)
            strokePath()
        }
        "eye", "eye_off" -> {
            strokePaint()
            mv(2f, 12f); quad(12f, 3f, 22f, 12f); quad(12f, 21f, 2f, 12f); closeP()
            strokePath()
            circleFill(12f, 12f, 3f)
            if (name == "eye_off") {
                strokePaint(); mv(4f, 4f); lt(20f, 20f); strokePath()
            }
        }
        "chev_down" -> {
            strokePaint(); mv(6f, 9f); lt(12f, 15f); lt(18f, 9f); strokePath()
        }
        "chev_up" -> {
            strokePaint(); mv(6f, 15f); lt(12f, 9f); lt(18f, 15f); strokePath()
        }
        "trash" -> {
            fillPaint(); mv(6f, 8f); lt(18f, 8f); lt(17f, 21f); lt(7f, 21f); closeP(); fillPath()
            strokePaint()
            mv(4f, 6f); lt(20f, 6f)
            mv(9f, 6f); lt(9f, 3f); lt(15f, 3f); lt(15f, 6f)
            strokePath()
        }
        "close" -> {
            strokePaint(); mv(5f, 5f); lt(19f, 19f); mv(19f, 5f); lt(5f, 19f); strokePath()
        }
        "plus" -> {
            strokePaint(); mv(12f, 4f); lt(12f, 20f); mv(4f, 12f); lt(20f, 12f); strokePath()
        }
        "diamond", "diamond_f" -> {
            if (name == "diamond_f") { fillPaint() } else { strokePaint() }
            mv(12f, 3f); lt(21f, 12f); lt(12f, 21f); lt(3f, 12f); closeP()
            if (name == "diamond_f") { fillPath() } else { strokePath() }
        }
        "graph" -> {
            strokePaint(); mv(3f, 18f); lt(9f, 11f); lt(13f, 15f); lt(21f, 6f); strokePath()
        }
        "box" -> {
            rrStroke(CGRect(3f, 3f, 18f, 18f), 3f)
            strokePaint()
            mv(7f, 9f); lt(11f, 12f); lt(7f, 15f)
            mv(13f, 16f); lt(17f, 16f)
            strokePath()
        }
        "handle" -> {
            strokePaint(); mv(4f, 9f); lt(20f, 9f); mv(4f, 15f); lt(20f, 15f); strokePath()
        }
        "media" -> {
            rrStroke(CGRect(3f, 5f, 18f, 14f), 2f)
            strokePaint(); mv(5f, 17f); lt(10f, 11f); lt(14f, 15f); lt(16f, 13f); lt(19f, 17f); strokePath()
            circleFill(16.5f, 9.5f, 1.6f)
        }
        "text" -> {
            strokePaint()
            mv(5f, 6f); lt(19f, 6f)
            mv(12f, 6f); lt(12f, 19f)
            mv(9f, 19f); lt(15f, 19f)
            strokePath()
        }
        "shape" -> {
            circleStroke(9f, 9f, 5.5f)
            rrStroke(CGRect(11f, 11f, 9f, 9f), 1.5f)
        }
        "camera" -> {
            rrStroke(CGRect(3f, 7f, 13f, 10f), 2f)
            strokePaint(); mv(16f, 10f); lt(21f, 7f); lt(21f, 17f); lt(16f, 14f); strokePath()
        }
        "prerender" -> {      // a camera inside a frame: bake this group to frames
            rrStroke(CGRect(3f, 3f, 18f, 18f), 4f)
            rrStroke(CGRect(6.5f, 9f, 6f, 6f), 1f)
            strokePaint(); mv(12.5f, 11f); lt(17f, 9f); lt(17f, 15f); lt(12.5f, 13f); strokePath()
        }
        "nullobj" -> {
            circleStroke(12f, 12f, 5f)
            strokePaint()
            mv(12f, 2f); lt(12f, 7f); mv(12f, 17f); lt(12f, 22f)
            mv(2f, 12f); lt(7f, 12f); mv(17f, 12f); lt(22f, 12f)
            strokePath()
        }
        "particles" -> {
            circleFill(7f, 7f, 1.8f); circleFill(15f, 6f, 1.2f); circleFill(11f, 12f, 2.2f)
            circleFill(18f, 14f, 1.6f); circleFill(6f, 17f, 1.4f); circleFill(14f, 19f, 1.8f)
        }
        "edit" -> {
            strokePaint()
            mv(4f, 20f); lt(5f, 15f); lt(16f, 4f); lt(20f, 8f); lt(9f, 19f); closeP()
            mv(14f, 6f); lt(18f, 10f)
            strokePath()
        }
        "puppet" -> {
            strokePaint()
            mv(12f, 3f); lt(18f, 9f); lt(12f, 15f); lt(6f, 9f); closeP()
            mv(12f, 15f); lt(12f, 21f)
            strokePath()
        }
        "move" -> {
            strokePaint()
            mv(12f, 3f); lt(12f, 21f); mv(3f, 12f); lt(21f, 12f)
            mv(9f, 6f); lt(12f, 3f); lt(15f, 6f); mv(9f, 18f); lt(12f, 21f); lt(15f, 18f)
            mv(6f, 9f); lt(3f, 12f); lt(6f, 15f); mv(18f, 9f); lt(21f, 12f); lt(18f, 15f)
            strokePath()
        }
        "sparkle" -> {
            fillPaint()
            mv(12f, 3f); lt(14f, 10f); lt(21f, 12f); lt(14f, 14f); lt(12f, 21f)
            lt(10f, 14f); lt(3f, 12f); lt(10f, 10f); closeP()
            fillPath()
        }
        "drop" -> {
            strokePaint()
            mv(12f, 3f)
            cubic(12f, 3f, 5f, 10f, 5f, 15f)
            cubic(5f, 19f, 8f, 21f, 12f, 21f)
            cubic(16f, 21f, 19f, 19f, 19f, 15f)
            cubic(19f, 10f, 12f, 3f, 12f, 3f)
            closeP()
            strokePath()
        }
        "speed" -> {
            strokePaint()
            mv(5f, 5f); lt(12f, 12f); lt(5f, 19f)
            mv(13f, 5f); lt(20f, 12f); lt(13f, 19f)
            strokePath()
        }
        "import" -> {
            strokePaint()
            mv(12f, 3f); lt(12f, 15f)
            mv(7f, 10f); lt(12f, 15f); lt(17f, 10f)
            mv(4f, 19f); lt(20f, 19f)
            strokePath()
        }
        "export" -> {
            strokePaint()
            mv(12f, 15f); lt(12f, 3f)
            mv(7f, 8f); lt(12f, 3f); lt(17f, 8f)
            mv(4f, 19f); lt(20f, 19f)
            strokePath()
        }
        "check" -> {
            strokePaint(); mv(5f, 12f); lt(10f, 17f); lt(19f, 7f); strokePath()
        }
        "solid" -> {
            rrFill(CGRect(4f, 4f, 16f, 16f), 3f)
        }
        "anime" -> {
            // character pulled apart into hair, face and shoulders, with a sparkle
            strokePaint()
            mv(5f, 9.6f); cubic(5f, 3.2f, 19f, 3.2f, 19f, 9.6f)                 // hair cap
            lt(15.5f, 7.8f); lt(12f, 9.6f); lt(8.5f, 7.8f); closeP()
            strokePath()
            mv(6.6f, 12.4f); cubic(6.6f, 16.6f, 9f, 18.4f, 12f, 18.4f)         // face
            cubic(15f, 18.4f, 17.4f, 16.6f, 17.4f, 12.4f)
            strokePath()
            circleFill(9.7f, 14.6f, 1.05f)
            circleFill(14.3f, 14.6f, 1.05f)
            mv(3.5f, 22.8f); cubic(3.5f, 21.2f, 7f, 20.7f, 12f, 20.7f)         // shoulders
            cubic(17f, 20.7f, 20.5f, 21.2f, 20.5f, 22.8f)
            strokePath()
            fillPaint()
            mv(21f, 1.6f); lt(21.6f, 3.2f); lt(23.2f, 3.8f); lt(21.6f, 4.4f); lt(21f, 6f)
            lt(20.4f, 4.4f); lt(18.8f, 3.8f); lt(20.4f, 3.2f); closeP()
            fillPath()
        }
        "gear" -> {
            circleStroke(12f, 12f, 3.2f)
            circleStroke(12f, 12f, 7f)
            strokePaint()
            for (k in 0 until 8) {
                val a = k * PI.toFloat() / 4f
                mv(12f + 7.5f * cos(a), 12f + 7.5f * sin(a))
                lt(12f + 10f * cos(a), 12f + 10f * sin(a))
            }
            strokePath()
        }
        "adjust" -> {
            line(4f, 7f, 20f, 7f); line(4f, 12f, 20f, 12f); line(4f, 17f, 20f, 17f)
            circleFill(9f, 7f, 2.4f); circleFill(15f, 12f, 2.4f); circleFill(8f, 17f, 2.4f)
        }
        // ---- audio effect icons (one per effect, drawn as a tiny picture of what the effect does to the sound)
        "afx_flanger" -> {      // two sweeping, offset waves = moving comb
            strokePaint()
            mv(2f, 9f); cubic(5f, 3f, 9f, 3f, 12f, 9f); cubic(15f, 15f, 19f, 15f, 22f, 9f)
            mv(2f, 15f); cubic(5f, 9f, 9f, 9f, 12f, 15f); cubic(15f, 21f, 19f, 21f, 22f, 15f)
            strokePath()
        }
        "afx_chorus" -> {       // three detuned copies
            strokePaint()
            for (k in 0 until 3) {
                val y = (5 + k * 7).toFloat(); val sh = k.toFloat() * 2f
                mv(2f, y); quad(6f + sh, y - 4f, 11f, y); quad(16f - sh, y + 4f, 22f, y)
            }
            strokePath()
        }
        "afx_phaser" -> {       // notches
            strokePaint()
            mv(2f, 7f); lt(6f, 7f); quad(8f, 21f, 10f, 7f); lt(13f, 7f); quad(15f, 21f, 17f, 7f); lt(22f, 7f)
            strokePath()
        }
        "afx_modulator" -> {    // amplitude wobble
            strokePaint()
            mv(2f, 12f); lt(6f, 5f); lt(10f, 19f); lt(14f, 8f); lt(18f, 16f); lt(22f, 12f)
            strokePath()
        }
        "afx_pan" -> {
            strokePaint()
            mv(3f, 12f); lt(21f, 12f); mv(7f, 8f); lt(3f, 12f); lt(7f, 16f); mv(17f, 8f); lt(21f, 12f); lt(17f, 16f)
            strokePath()
            circleFill(12f, 12f, 2.2f)
        }
        "afx_reverb" -> {       // expanding rings
            strokePaint()
            mv(8f, 8f); quad(4f, 12f, 8f, 16f); mv(12f, 5f); quad(6f, 12f, 12f, 19f); mv(16f, 3f); quad(8f, 12f, 16f, 21f)
            strokePath()
            circleFill(19.5f, 12f, 2f)
        }
        "afx_muffle" -> {       // low-pass roll-off
            strokePaint()
            mv(2f, 7f); lt(10f, 7f); cubic(14f, 7f, 15f, 11f, 17f, 19f); lt(22f, 19f)
            strokePath()
        }
        "afx_tone" -> {         // tilt around a pivot
            strokePaint()
            mv(2f, 17f); lt(22f, 7f); mv(12f, 4f); lt(12f, 20f)
            strokePath()
            circleFill(12f, 12f, 2.2f)
        }
        "afx_eq" -> {           // faders
            strokePaint()
            mv(6f, 4f); lt(6f, 20f); mv(12f, 4f); lt(12f, 20f); mv(18f, 4f); lt(18f, 20f)
            strokePath()
            circleFill(6f, 15f, 2.4f); circleFill(12f, 8f, 2.4f); circleFill(18f, 13f, 2.4f)
        }
        "afx_echo" -> {         // fading repeats
            strokePaint()
            mv(4f, 5f); lt(4f, 19f); mv(9.5f, 7f); lt(9.5f, 17f); mv(15f, 9.5f); lt(15f, 14.5f); mv(20f, 11f); lt(20f, 13f)
            strokePath()
        }
        "afx_dist" -> {         // clipped wave
            strokePaint()
            mv(2f, 19f); cubic(5f, 19f, 6f, 6f, 9f, 6f); lt(15f, 6f); cubic(18f, 6f, 19f, 19f, 22f, 19f)
            strokePath()
        }
        "afx_wah" -> {          // moving band-pass peak
            strokePaint()
            mv(2f, 19f); cubic(7f, 19f, 8f, 5f, 12f, 5f); cubic(16f, 5f, 17f, 19f, 22f, 19f)
            mv(6f, 12f); lt(3f, 12f); mv(18f, 12f); lt(21f, 12f)
            strokePath()
        }
        "afx_crush" -> {        // staircase
            strokePaint()
            mv(2f, 20f); lt(2f, 16f); lt(7f, 16f); lt(7f, 11f); lt(12f, 11f); lt(12f, 7f); lt(17f, 7f); lt(17f, 3f); lt(22f, 3f)
            strokePath()
        }
        "afx_comp" -> {         // transfer curve with a knee
            strokePaint()
            mv(3f, 3f); lt(3f, 21f); lt(21f, 21f)
            mv(5f, 19f); lt(11f, 13f); quad(14f, 10f, 20f, 9f)
            strokePath()
        }
        "audio" -> {
            strokePaint()
            val hs = floatArrayOf(3f, 7f, 10f, 6f, 4f)
            for (k in 0 until 5) {
                val x = 4f + k * 4f
                mv(x, 12f - hs[k]); lt(x, 12f + hs[k])
            }
            strokePath()
        }
        "split" -> {
            strokePaint()
            mv(12f, 3f); lt(12f, 21f)
            mv(8f, 8f); lt(4f, 12f); lt(8f, 16f)
            mv(16f, 8f); lt(20f, 12f); lt(16f, 16f)
            strokePath()
        }
        "trimin" -> {
            strokePaint()
            mv(4f, 4f); lt(4f, 20f)
            mv(8f, 12f); lt(20f, 12f)
            mv(16f, 8f); lt(20f, 12f); lt(16f, 16f)
            strokePath()
        }
        "trimout" -> {
            strokePaint()
            mv(20f, 4f); lt(20f, 20f)
            mv(16f, 12f); lt(4f, 12f)
            mv(8f, 8f); lt(4f, 12f); lt(8f, 16f)
            strokePath()
        }
        "pipette" -> {
            circleStroke(17f, 7f, 3.2f)
            strokePaint(); mv(15f, 9f); lt(5f, 19f); lt(4f, 20f); strokePath()
        }
        "link" -> {
            rrStroke(CGRect(2f, 8.5f, 12f, 7f), 3.5f)
            rrStroke(CGRect(10f, 8.5f, 12f, 7f), 3.5f)
        }
        "unlink" -> {
            rrStroke(CGRect(1.5f, 8.5f, 8.5f, 7f), 3.5f)
            rrStroke(CGRect(14f, 8.5f, 8.5f, 7f), 3.5f)
            strokePaint(); mv(9f, 18.5f); lt(15f, 5.5f); strokePath()
        }
        "flare" -> {
            circleStroke(12f, 12f, 3.2f)
            strokePaint()
            mv(12f, 2.5f); lt(12f, 6.5f); mv(12f, 17.5f); lt(12f, 21.5f)
            mv(2.5f, 12f); lt(6.5f, 12f); mv(17.5f, 12f); lt(21.5f, 12f)
            mv(5.5f, 5.5f); lt(8.3f, 8.3f); mv(15.7f, 15.7f); lt(18.5f, 18.5f)
            mv(18.5f, 5.5f); lt(15.7f, 8.3f); mv(8.3f, 15.7f); lt(5.5f, 18.5f)
            strokePath()
        }
        "mask" -> {
            rrStroke(CGRect(4f, 4f, 16f, 16f), 3f)
            circleStroke(12f, 12f, 4.5f)
        }
        "mask_invert" -> {
            rrFill(CGRect(4f, 4f, 16f, 16f), 3f)
            c.setFillColor(UIColor.clear.toInt())
            // Swift setBlendMode(.clear): CGBlendMode has no CLEAR entry; use the PorterDuff xfermode directly.
            c.paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            c.fillEllipse(CGRect(7.5f, 7.5f, 9f, 9f))
            c.paint.xfermode = null
        }
        "chev_left" -> {
            strokePaint(); mv(15f, 5f); lt(8f, 12f); lt(15f, 19f); strokePath()
        }
        "chev_right" -> {
            strokePaint(); mv(9f, 5f); lt(16f, 12f); lt(9f, 19f); strokePath()
        }
        "minus" -> {
            line(5f, 12f, 19f, 12f)
        }
        "frame" -> {      // corner brackets + centre dot: frame the selection
            strokePaint()
            mv(4f, 9f); lt(4f, 4f); lt(9f, 4f); strokePath()
            mv(15f, 4f); lt(20f, 4f); lt(20f, 9f); strokePath()
            mv(20f, 15f); lt(20f, 20f); lt(15f, 20f); strokePath()
            mv(9f, 20f); lt(4f, 20f); lt(4f, 15f); strokePath()
            circleStroke(12f, 12f, 2.5f)
        }
        "circle" -> {
            circleStroke(12f, 12f, 8f)
        }
        "folder" -> {
            fillPaint()
            mv(3f, 6f); lt(10f, 6f); lt(12f, 8.5f); lt(21f, 8.5f); lt(21f, 19f); lt(3f, 19f); closeP(); fillPath()
        }
        "folder_open" -> {
            strokePaint()
            mv(3f, 18f); lt(3f, 6f); lt(10f, 6f); lt(12f, 8.5f); lt(20f, 8.5f); lt(20f, 11f)
            mv(3f, 18f); lt(6f, 11f); lt(22f, 11f); lt(19f, 18f); closeP(); strokePath()
        }
        "file" -> {
            strokePaint()
            mv(6f, 3f); lt(14f, 3f); lt(19f, 8f); lt(19f, 21f); lt(6f, 21f); closeP()
            mv(14f, 3f); lt(14f, 8f); lt(19f, 8f); strokePath()
        }
        "file_plus" -> {
            strokePaint()
            mv(6f, 3f); lt(14f, 3f); lt(19f, 8f); lt(19f, 21f); lt(6f, 21f); closeP()
            mv(12.5f, 12f); lt(12.5f, 18f); mv(9.5f, 15f); lt(15.5f, 15f); strokePath()
        }
        "folder_plus" -> {
            strokePaint()
            mv(3f, 18f); lt(3f, 6f); lt(10f, 6f); lt(12f, 8.5f); lt(21f, 8.5f); lt(21f, 18f); closeP()
            mv(12f, 11.5f); lt(12f, 16f); mv(9.75f, 13.75f); lt(14.25f, 13.75f); strokePath()
        }
        "save" -> {
            strokePaint()
            mv(4f, 4f); lt(17f, 4f); lt(20f, 7f); lt(20f, 20f); lt(4f, 20f); closeP()
            mv(8f, 4f); lt(8f, 9f); lt(15f, 9f); lt(15f, 4f); mv(8f, 20f); lt(8f, 14f); lt(16f, 14f); lt(16f, 20f); strokePath()
        }
        "align_l" -> {
            strokePaint(); mv(4f, 3f); lt(4f, 21f); strokePath()
            rectFill(CGRect(7f, 6f, 11f, 4f)); rectFill(CGRect(7f, 14f, 6f, 4f))
        }
        "align_hc" -> {
            strokePaint(); mv(12f, 3f); lt(12f, 21f); strokePath()
            rectFill(CGRect(5f, 6f, 14f, 4f)); rectFill(CGRect(8f, 14f, 8f, 4f))
        }
        "align_r" -> {
            strokePaint(); mv(20f, 3f); lt(20f, 21f); strokePath()
            rectFill(CGRect(6f, 6f, 11f, 4f)); rectFill(CGRect(11f, 14f, 6f, 4f))
        }
        "align_t" -> {
            strokePaint(); mv(3f, 4f); lt(21f, 4f); strokePath()
            rectFill(CGRect(6f, 7f, 4f, 11f)); rectFill(CGRect(14f, 7f, 4f, 6f))
        }
        "align_vc" -> {
            strokePaint(); mv(3f, 12f); lt(21f, 12f); strokePath()
            rectFill(CGRect(6f, 5f, 4f, 14f)); rectFill(CGRect(14f, 8f, 4f, 8f))
        }
        "align_b" -> {
            strokePaint(); mv(3f, 20f); lt(21f, 20f); strokePath()
            rectFill(CGRect(6f, 6f, 4f, 11f)); rectFill(CGRect(14f, 11f, 4f, 6f))
        }
        "brush" -> {
            fillPaint()
            mv(11f, 11f); lt(14f, 14f); quad(14f, 19.5f, 5f, 20.5f); quad(5.5f, 15.5f, 11f, 11f); closeP(); fillPath()
            strokePaint(); mv(20.5f, 3.5f); lt(13f, 12f); strokePath()
        }
        "eraser" -> {
            strokePaint()
            mv(4.5f, 15f); lt(13f, 6.5f); lt(19f, 12.5f); lt(12f, 19.5f); lt(8f, 19.5f); closeP()
            mv(9f, 10.5f); lt(15.5f, 17f); strokePath()
            line(12f, 19.5f, 21f, 19.5f)
        }
        "smudge" -> {
            strokePaint()
            mv(3.5f, 17f); cubic(7f, 8f, 11f, 22f, 15f, 13f); strokePath()
            mv(6f, 20.5f); cubic(9.5f, 15f, 12.5f, 23f, 17f, 17.5f); strokePath()
            circleFill(19f, 8f, 2.6f)
        }
        "wand" -> {
            strokePaint(); mv(4f, 20f); lt(14f, 10f); strokePath()
            fillPaint(); mv(17f, 3f); lt(18.2f, 5.8f); lt(21f, 7f); lt(18.2f, 8.2f); lt(17f, 11f); lt(15.8f, 8.2f); lt(13f, 7f); lt(15.8f, 5.8f); closeP(); fillPath()
            circleFill(6f, 6f, 1.3f)
        }
        "select" -> {
            strokePaint(); c.paint.pathEffect = DashPathEffect(floatArrayOf(3f, 3f), 0f)
            c.stroke(CGRect(4f, 4f, 16f, 16f)); c.paint.pathEffect = null
        }
        "copy" -> {
            rrStroke(CGRect(8.5f, 8.5f, 12f, 12f), 2f)
            strokePaint(); mv(15.5f, 5.5f); lt(15.5f, 4.5f); lt(4.5f, 4.5f); lt(4.5f, 15.5f); lt(5.5f, 15.5f); strokePath()
        }
        "paste" -> {
            rrStroke(CGRect(4.5f, 5.5f, 15f, 16f), 2f)
            rrFill(CGRect(8.5f, 2.5f, 7f, 5f), 1.5f)
        }
        "cut" -> {
            circleStroke(7f, 18f, 2.8f); circleStroke(17f, 18f, 2.8f)
            strokePaint(); mv(8.5f, 15.6f); lt(16f, 3.5f); mv(15.5f, 15.6f); lt(8f, 3.5f); strokePath()
        }
        "fit" -> {
            strokePaint()
            mv(4f, 9f); lt(4f, 4f); lt(9f, 4f)
            mv(15f, 4f); lt(20f, 4f); lt(20f, 9f)
            mv(20f, 15f); lt(20f, 20f); lt(15f, 20f)
            mv(9f, 20f); lt(4f, 20f); lt(4f, 15f)
            strokePath()
        }
        "pan" -> {        // open hand-ish: four fingers + palm
            strokePaint()
            mv(8f, 12f); lt(8f, 5f); mv(11f, 11f); lt(11f, 3.5f); mv(14f, 11f); lt(14f, 4.5f); mv(17f, 12f); lt(17f, 7f)
            mv(8f, 12f); quad(8f, 18f, 12f, 20f); quad(18f, 20f, 18f, 14f); lt(17f, 12f)
            strokePath()
        }
        "rotate" -> {     // circular arrow
            strokePaint()
            mv(19f, 12f); cubic(19f, 16f, 16f, 19f, 12f, 19f); cubic(8f, 19f, 5f, 16f, 5f, 12f); cubic(5f, 8f, 8f, 5f, 12f, 5f); cubic(14f, 5f, 16f, 6f, 17.5f, 7.5f)
            mv(18f, 3.5f); lt(18f, 8f); lt(13.5f, 8f)
            strokePath()
        }
        "scale" -> {      // box with diagonal expand arrow
            strokePaint()
            rrStroke(CGRect(3f, 10f, 11f, 11f), 1.5f)
            mv(13f, 11f); lt(21f, 3f); mv(15f, 3f); lt(21f, 3f); lt(21f, 9f)
            strokePath()
        }
        "timeline" -> {   // bars on a ruler
            strokePaint()
            mv(3f, 6f); lt(21f, 6f); mv(3f, 12f); lt(14f, 12f); mv(10f, 18f); lt(21f, 18f)
            strokePath()
            circleFill(17f, 12f, 1.8f)
        }
        "gizmo" -> {      // three axes from a point
            strokePaint()
            mv(12f, 12f); lt(12f, 3f); mv(12f, 12f); lt(20f, 16f); mv(12f, 12f); lt(4f, 16f)
            mv(10f, 5f); lt(12f, 3f); lt(14f, 5f)
            strokePath()
            circleFill(12f, 12f, 2f)
        }
        "terrain" -> {    // mountains
            strokePaint()
            mv(2f, 19f); lt(9f, 7f); lt(14f, 15f); lt(17f, 11f); lt(22f, 19f); closeP()
            strokePath()
        }
        "light" -> {      // bulb
            strokePaint()
            circleStroke(12f, 10f, 5.5f)
            mv(9.5f, 18f); lt(14.5f, 18f); mv(10.5f, 21f); lt(13.5f, 21f)
            strokePath()
        }
        "env" -> {        // sun + horizon
            strokePaint()
            circleStroke(12f, 12f, 3.5f)
            mv(12f, 3f); lt(12f, 5f); mv(12f, 19f); lt(12f, 21f); mv(3f, 12f); lt(5f, 12f); mv(19f, 12f); lt(21f, 12f)
            mv(5.6f, 5.6f); lt(7f, 7f); mv(17f, 17f); lt(18.4f, 18.4f); mv(18.4f, 5.6f); lt(17f, 7f); mv(7f, 17f); lt(5.6f, 18.4f)
            strokePath()
        }
        "sim" -> {        // wave + droplet
            strokePaint()
            mv(3f, 15f); quad(6f, 9f, 9f, 15f); quad(12f, 21f, 15f, 15f); quad(18f, 9f, 21f, 15f)
            strokePath()
            circleFill(12f, 6f, 2f)
        }
        "person" -> {
            strokePaint()
            circleStroke(12f, 7f, 3.5f)
            mv(5f, 21f); quad(5f, 13f, 12f, 13f); quad(19f, 13f, 19f, 21f)
            strokePath()
        }
        "bone" -> {       // two joints joined by a bone
            strokePaint()
            mv(7.5f, 16.5f); lt(16.5f, 7.5f)
            strokePath()
            circleStroke(6f, 18f, 2.5f); circleStroke(18f, 6f, 2.5f)
        }
        "xray" -> {       // see-through cube: outline, hidden edges drawn through the faces
            strokePaint()
            mv(12f, 2.5f); lt(20.5f, 7.25f); lt(20.5f, 16.75f); lt(12f, 21.5f); lt(3.5f, 16.75f); lt(3.5f, 7.25f); closeP()
            strokePath()
            mv(3.5f, 7.25f); lt(12f, 12f); lt(20.5f, 7.25f); mv(12f, 12f); lt(12f, 21.5f)
            strokePath()
            circleFill(12f, 12f, 1.6f)
        }
        "pose" -> {       // stick figure
            strokePaint()
            circleStroke(12f, 4.5f, 2f)
            mv(12f, 7f); lt(12f, 14f); mv(5f, 10f); lt(12f, 8.5f); lt(19f, 10f); mv(12f, 14f); lt(8f, 21f); mv(12f, 14f); lt(16f, 21f)
            strokePath()
        }
        else -> {}
        }
        c.restoreGState()
    }

    /** A vector icon as a UIImage (menus / alerts that need an image instead of a draw call). */
    fun image(name: String, size: CGFloat = 22f, color: Int = C.TEXT): UIImage {
        val sz = size.toInt().coerceAtLeast(1)
        return UIGraphicsImageRenderer(sz, sz).image { c ->
            Icons.draw(c, name, size / 2, size / 2, size, color)
        }
    }

    // MARK: - own replacements for the system (SF Symbols) icon set — no Apple icons anywhere

    /** Maps an old system symbol name to one of our own vector icons. */
    fun ownName(sf: String): String {
        val n = sf
        val table: List<Pair<String, String>> = listOf(
            Pair("arrow.uturn.backward", "undo"), Pair("arrow.uturn.forward", "redo"), Pair("scope", "frame"),
            Pair("xray", "xray"), Pair("hand", "pan"), Pair("rotate", "rotate"), Pair("arrow.up.left.and.arrow.down.right", "scale"), Pair("timeline", "timeline"),
            Pair("move.3d", "gizmo"), Pair("mountain", "terrain"), Pair("lightbulb", "light"), Pair("sun.max", "env"), Pair("cloud.sun", "sim"),
            Pair("person", "person"), Pair("figure", "pose"), Pair("bone", "bone"), Pair("cube.transparent", "cube"),
            Pair("xmark", "close"), Pair("plus.diamond", "plus"), Pair("plus.magnifyingglass", "plus"), Pair("plus.square.on.square", "dup"),
            Pair("plus", "plus"), Pair("minus", "minus"), Pair("trash", "trash"), Pair("eye.slash", "eye_off"), Pair("eye", "eye"),
            Pair("chevron.up", "chev_up"), Pair("chevron.down", "chev_down"), Pair("arrowtriangle.down", "chev_down"),
            Pair("chevron.left", "chev_left"), Pair("chevron.right", "chev_right"),
            Pair("backward.end", "prev"), Pair("forward.end", "next"), Pair("play", "play"), Pair("pause", "pause"),
            Pair("photo", "media"), Pair("square.grid", "grid"), Pair("grid", "grid"), Pair("cube", "cube"), Pair("folder", "folder"),
            Pair("gear", "gear"), Pair("pencil", "edit"), Pair("checkmark", "check"), Pair("bookmark", "bookmark"), Pair("camera", "camera"),
            Pair("diamond", "diamond"), Pair("drop", "drop"), Pair("waveform", "audio"), Pair("wave", "audio"),
            Pair("wand", "sparkle"), Pair("sun", "sparkle"), Pair("cloud", "sparkle"), Pair("lightbulb", "sparkle"), Pair("flashlight", "sparkle"),
            Pair("square.and.arrow", "export"), Pair("doc.on", "dup"), Pair("square.stack", "layers"), Pair("slider", "adjust"),
            Pair("circle", "circle"), Pair("hand", "move"), Pair("arrow", "move"))
        for ((k, v) in table) if (n.startsWith(k)) return v
        return "shape"
    }

    /** Drop-in for UIImage(systemName:): our own vector icon as a template image (tintColor works). */
    fun sf(name: String): UIImage? {
        val own = ownName(name)
        val size: CGFloat = 24f
        val sz = size.toInt().coerceAtLeast(1)
        return UIGraphicsImageRenderer(sz, sz).image { c ->
            Icons.draw(c, own, size / 2, size / 2, size, 0xFFFFFFFF.toInt())
        }
    }
}

// MARK: - IconView

/** Plain icon button. */
class IconView(_icon: String, _tint: Int = C.TEXT, _size: CGFloat = 22f) : TapView() {
    var icon: String = _icon
    var tint: Int = _tint
    private val sizePt: CGFloat = _size
    var onLong: (() -> Unit)? = null
    private var longFired = false

    init {
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        // PORT NOTE: Android long-click timeout is 400ms; the recognizer must not
        // cancel the touch stream so normal clicks still work when onLong == nil.
        val lp = UILongPressGestureRecognizer { g ->
            if (g.state == UIGestureRecognizerState.began && onLong != null) { longFired = true; onLong?.invoke() }
        }
        lp.minimumPressDuration = 0.4
        lp.cancelsTouchesInView = false
        addGestureRecognizer(lp)
    }

    fun set(color: Int, name: String? = null) {
        if (name != null) icon = name
        tint = color
        setNeedsDisplay()
    }

    fun set(name: String, color: Int) {
        icon = name; tint = color; setNeedsDisplay()
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        isHighlighted = false
        if (!longFired && touches.firstOrNull()?.let { boundsRect.contains(it.location(this)) } == true) { onClick?.invoke() }
        longFired = false
    }

    override fun touchesCancelled(touches: Set<UITouch>, event: UIEvent?) {
        isHighlighted = false
        longFired = false
    }

    override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        c.canvas.drawColor(android.graphics.Color.TRANSPARENT, PorterDuff.Mode.CLEAR)   // stale play-triangle pixels used to show under the pause bars
        val col: Int = if (isHighlighted)
            tint or 0x80000000.toInt()
        else
            tint
        Icons.draw(c, icon, boundsRect.width / 2, boundsRect.height / 2, sizePt, col)
    }
}
