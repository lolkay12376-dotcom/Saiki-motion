@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/LayersSheet.swift — the Layers popup: a clipboard row (Copy / Paste / Properties /
// Duplicate / Preset) on top, then a list of layer actions. Swipe sideways for page 2.

package com.saiki.motion.ui

import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import kotlin.math.min

class LayersSheet : UIViewController() {
    class Item(val title: String, val icon: String, val on: Boolean, val act: () -> Unit)

    var clipboardReady = false
    var clipTools: List<Item> = emptyList()          // exactly the 5 round buttons
    var pages: List<List<Item>> = emptyList()
    private val scroll = UIScrollView(appContext!!)
    private var dots = 0

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(0x59000000.toInt())
        view.onClick = { close() }
        val W = min(view.rectWidth() - 32f, 460f)
        val rowH = 52f
        val listH = rowH * 7
        val cardH = 28 + 86 + 1 + listH + 24
        val card = UiView(appContext!!)
        card.setBackgroundColor(C.CARD)
        view.addSubview(card)
        card.frame = CGRect((view.rectWidth() - W) / 2, (view.rectHeight() - cardH) / 2, W, cardH)

        val head = UILabel(appContext!!)
        head.text = if (clipboardReady) "Clipboard ready" else "Clipboard empty"
        head.font = UIFont.systemFont(15f); head.textColor = argbToUIColor(C.DIM)
        head.frame = CGRect(18f, 8f, W - 36f, 22f)
        card.addSubview(head)

        val cw = W / 5
        for ((i, it) in clipTools.withIndex()) {
            val col = if (it.on) C.TEXT else (argbToUIColor(C.DIM).withAlphaComponent(0.55f).toInt())
            val b = object : TapView() {
                public override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    Icons.draw(c, it.icon, rect.midX, rect.midY, 28f, col)
                    val tw = com.saiki.motion.uikit.measureText(it.title, 12f)
                    com.saiki.motion.uikit.drawText(it.title, rect.midX - tw / 2f, rect.height - 2f, color = col, size = 12f, bold = false, align = com.saiki.motion.uikit.NSTextAlignment.left)
                }
            }
            b.frame = CGRect(i * cw, 32f, cw, 82f)
            b.isUserInteractionEnabled = it.on
            b.onClick = { clipTap(i) }
            card.addSubview(b)
        }
        val line = UiView(appContext!!)
        line.setBackgroundColor(C.CARD2)
        line.frame = CGRect(0f, 116f, W, 1f)
        card.addSubview(line)

        scroll.frame = CGRect(0f, 117f, W, listH)
        scroll.showsHorizontalScrollIndicator = false
        card.addSubview(scroll)
        var x = 0f
        for ((pi, page) in pages.withIndex()) {
            for ((i, it) in page.withIndex()) {
                val b = object : TapView() {
                    public override fun draw(rect: CGRect) {
                        val c = UIGraphics.getCurrentContext() ?: return
                        Icons.draw(c, it.icon, 30f, rect.midY, 22f, if (it.on) C.GREEN else C.TEXT)
                        com.saiki.motion.uikit.drawText("  " + it.title, 58f, rect.midY + 5f, color = C.TEXT, size = 17f, bold = false, align = com.saiki.motion.uikit.NSTextAlignment.left)
                    }
                }
                b.frame = CGRect(x + W * pi, i * rowH, W, rowH)
                b.onClick = { rowTap(pi * 100 + i) }
                scroll.addSubview(b)
            }
        }
        scroll.contentSize = CGSize(W * maxOf(pages.size, 1), listH)
        dots = pages.size
        card.onLayout = { w ->
            scroll.contentSize = CGSize(w * maxOf(pages.size, 1), listH)
        }
        view.onLayout = { _ ->
            val W2 = min(view.rectWidth() - 32f, 460f)
            card.frame = CGRect((view.rectWidth() - W2) / 2, (view.rectHeight() - cardH) / 2, W2, cardH)
        }
    }

    fun scrollViewDidScroll(s: UIScrollView) { /* dots twin: pages tracked by scroll position */ }

    private fun close() { dismiss(animated = true) }
    private fun clipTap(i: Int) { val a = clipTools[i].act; dismiss(animated = true) { a() } }
    private fun rowTap(tag: Int) { val a = pages[tag / 100][tag % 100].act; dismiss(animated = true) { a() } }
}
