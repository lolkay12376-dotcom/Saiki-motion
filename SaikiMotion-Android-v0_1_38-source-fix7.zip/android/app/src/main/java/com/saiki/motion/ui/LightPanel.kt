@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/LightPanel.swift — Scene 3D "+" > Lighting. Full panel: add Directional / Spot /
// Point lights, any colour each, edit them all in one place.

package com.saiki.motion.ui

import com.saiki.motion.app.EditorViewController
import com.saiki.motion.app.addLight
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.Lights
import com.saiki.motion.core.R3D
import com.saiki.motion.app.refreshPanel
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIColorWell
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.measureText
import java.util.Locale
import kotlin.math.cbrt
import kotlin.math.max
import kotlin.math.min

class LightPanel(private val host: EditorViewController?) : UiView(appContext!!) {
    private val accent = 0xFFFF8C14.toInt()
    private val palette = listOf(0xFFFF3B30, 0xFFFF9500, 0xFFFFD60A, 0xFF34C759, 0xFF00C7BE, 0xFF0A84FF, 0xFFBF5AF2, 0xFFFF2D92, 0xFFFFF2D8, 0xFFFFFFFF).map { it.toInt() }
    private var nextHue = 0
    private val list = UiView(appContext!!)
    private val card = UiView(appContext!!)
    private val topArea = UiView(appContext!!)
    private val scroll = UIScrollView(appContext!!)

    companion object {
        fun present(host: EditorViewController, view: UiView) {
            if (view.subviews.any { it is LightPanel }) return
            val v = LightPanel(host)
            view.addSubview(v)
            v.frame = CGRect(0f, 0f, view.rectWidth(), view.rectHeight())
        }
    }

    init {
        setBackgroundColor(0x8C000000.toInt())
        build()
        reload()
    }

    private fun label(t: String, size: CGFloat = 13f, bold: Boolean = false, c: Int = 0xFFBFBFBF.toInt()): UILabel {
        val l = UILabel(appContext!!)
        l.text = t; l.textColor = UIColor(c); l.font = if (bold) UIFont.boldSystemFont(size) else UIFont.systemFont(size)
        l.numberOfLines = if (size <= 12f) 2 else 1
        l.frame = CGRect(0f, 0f, 300f, size + 10f)
        return l
    }

    private fun rgb(c: Int): UIColor = UIColor.rgb(((c shr 16) and 0xFF).toFloat() / 255f, ((c shr 8) and 0xFF).toFloat() / 255f, (c and 0xFF).toFloat() / 255f, 1f)

    private fun argb(col: UIColor): Int {
        val c = col.toInt()
        return (0xFF shl 24) or (c and 0xFFFFFF)
    }

    private fun changed() { host?.render() }

    private fun slider(title: String, lo: Float, hi: Float, v: Float, fmt: String = "%.2f", cb: (Float) -> Unit): UiView {
        val l = label(title)
        val valL = label(String.format(Locale.US, fmt, v), 12f)
        valL.textAlignment = NSTextAlignment.right
        val s = FlatUISlider()
        s.minimumValue = lo; s.maximumValue = hi; s.value = min(max(v, lo), hi)
        s.tintColor = accent
        s.onValueChanged = {
            valL.text = String.format(Locale.US, fmt, s.value)
            cb(s.value); changed()
        }
        val r = UiView(appContext!!)
        r.addSubview(l); r.addSubview(s); r.addSubview(valL)
        r.frame = CGRect(0f, 0f, 100f, 36f)
        r.onLayout = { w ->
            l.frame = CGRect(0f, 8f, 92f, 18f)
            s.frame = CGRect(96f, 2f, w - 96f - 56f, 32f)
            valL.frame = CGRect(w - 52f, 8f, 52f, 18f)
        }
        return r
    }

    private fun addButton(title: String, type: Int): UiView {
        val b = object : TapView() {
            public override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                com.saiki.motion.uikit.fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 14f, 0xFF2E2E2E.toInt())
                val icon = when (type) { 1 -> "sun.max"; 2 -> "spot"; else -> "lightbulb" }
                Icons.draw(c, icon, rect.midX, rect.height * 0.38f, 20f, C.TEXT)
                drawText(title, rect.midX, rect.height * 0.78f, color = C.TEXT, size = 12f, bold = false, align = NSTextAlignment.center)
            }
        }
        b.onClick = {
            val h = host
            if (h != null) {
                h.pushUndo()
                h.addLight(type, palette[nextHue % 8]); nextHue += 1      // each new light gets the next colour
                reload()
            }
        }
        b.frame = CGRect(0f, 0f, 100f, 70f)
        return b
    }

    private fun build() {
        card.setBackgroundColor(0xFF171717.toInt())
        addSubview(card)
        val x = PillButton("✕", null, C.CARD2, C.TEXT)
        x.onClick = { removeFromSuperview() }
        val head = UiView(appContext!!)
        val headL = label("Lighting", 22f, true, 0xFFFFFFFF.toInt())
        head.addSubview(headL); head.addSubview(x)
        val adds = UiView(appContext!!)
        adds.addSubview(addButton("Directional", 1))
        adds.addSubview(addButton("Spotlight", 2))
        adds.addSubview(addButton("Point", 0))
        val envS = slider("Env strength", 0f, 3f, R3D.g("env", 1f)) { R3D.set("env", it) }      // an HDRI can drown a light: turn it down here
        val hint = label("Every light can have its own colour. They light models, PBR, terrain, water and volumes.", 12f)
        topArea.addSubview(head); topArea.addSubview(adds); topArea.addSubview(envS); topArea.addSubview(hint)
        card.addSubview(topArea)
        card.addSubview(scroll)
        scroll.addSubview(list)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth(); val h = rectHeight()
        if (w < 10 || h < 10) return
        val top = safeAreaInsets.top
        card.frame = CGRect(12f, top + 40f, w - 24f, h - top - 52f)
        val cw = card.rectWidth()
        // top area
        var y = 16f
        val head = topArea.subviews[0]
        head.frame = CGRect(16f, y, cw - 32f, 30f)
        (head.subviews[0] as? UILabel)?.let { it.frame = CGRect(0f, 4f, 200f, 26f) }
        head.subviews[1].frame = CGRect(cw - 32f - 44f, 0f, 44f, 30f)
        y += 38f
        val adds = topArea.subviews[1]
        adds.frame = CGRect(16f, y, cw - 32f, 70f)
        var ax = 0f
        val aw = (cw - 32f - 16f) / 3f
        for (a in adds.subviews) { a.frame = CGRect(ax, 0f, aw, 70f); ax += aw + 8f }
        y += 78f
        for (i in 2 until topArea.subviews.size) {
            val v = topArea.subviews[i]
            val vh = if (v is UILabel) 34f else 36f
            v.frame = CGRect(16f, y, cw - 32f, vh)
            v.onLayout?.invoke(cw - 32f)
            y += vh + 10f
        }
        topArea.frame = CGRect(0f, 0f, cw, y)
        // scroll + list
        scroll.frame = CGRect(16f, y, cw - 32f, card.rectHeight() - y - 8f)
        layoutList()
    }

    private fun layoutList() {
        var y = 0f
        for (v in list.subviews) {
            val hgt = v.rectHeight().takeIf { it > 0f } ?: 60f
            v.frame = CGRect(0f, y, scroll.rectWidth(), hgt)
            v.onLayout?.invoke(scroll.rectWidth())
            y += hgt + 10f
        }
        list.frame = CGRect(0f, 0f, scroll.rectWidth(), y + 8f)
        scroll.contentSize = com.saiki.motion.uikit.CGSize(scroll.rectWidth(), y + 8f)
    }

    private fun reload() {
        list.subviews.toList().forEach { it.removeFromSuperview() }
        val ls = Editor.scene.layers.filter { it.isLight }
        if (ls.isEmpty()) list.addSubview(label("No lights yet. Add one above.", 14f))
        for (l in ls) list.addSubview(card(l))
        layoutList()
        host?.render()
    }

    private fun card(l: Layer): UiView {
        val box = UiView(appContext!!)
        box.setBackgroundColor(0xFF242424.toInt())
        val type = l.xf("lightType", 0f).toInt()
        val name = label(l.name, 15f, true, 0xFFFFFFFF.toInt())
        val well = UIColorWell(appContext!!)
        well.supportsAlpha = false
        well.selectedColor = rgb(l.vdbTint)
        well.onValueChanged = {
            host?.pushUndo()
            l.vdbTint = argb(well.selectedColor)
            changed()
        }
        val del = PillButton("🗑", null, 0x00000000.toInt(), 0xFFFF6666.toInt())
        del.onClick = {
            host?.pushUndo()
            Editor.scene.layers.removeAll { it === l }
            reload(); host?.refreshPanel()
        }
        val topRow = UiView(appContext!!)
        topRow.addSubview(name); topRow.addSubview(well); topRow.addSubview(del)
        val seg = FlatSegment(listOf("Point", "Directional", "Spot"), type)
        seg.onValueChanged = {
            host?.pushUndo()
            l.xset("lightType", seg.selectedSegmentIndex.toFloat())
            reload()
        }
        val sw = UiView(appContext!!)
        var sx = 0f
        for (c in palette) {
            val b = object : TapView() {
                public override fun draw(rect: CGRect) {
                    val c2 = UIGraphics.getCurrentContext() ?: return
                    com.saiki.motion.uikit.fillRoundRect(c2, CGRect(0.5f, 0.5f, rect.width - 1f, rect.height - 1f), 12f, c)
                    com.saiki.motion.uikit.strokeRoundRect(c2, CGRect(0.5f, 0.5f, rect.width - 1f, rect.height - 1f), 12f, 1f, 0x4DFFFFFF.toInt())
                }
            }
            b.onClick = {
                host?.pushUndo()
                l.vdbTint = c
                well.selectedColor = rgb(c)
                changed()
            }
            b.frame = CGRect(sx, 0f, 24f, 24f)
            sw.addSubview(b)
            sx += 32f
        }
        val rows = ArrayList<UiView>()
        rows.add(topRow)
        rows.add(seg)
        rows.add(sw)
        // intensity: cubic curve so the slider is fine near 0 and reaches 10000
        val cur = cbrt(max(l.xf("lightInt", 1f), 0f) / 10000f)
        rows.add(slider("Intensity", 0f, 1f, cur, "%.0f") { v -> l.xset("lightInt", v * v * v * 10000f) })
        val inf = FlatSwitch(Lights.infinite(l))
        inf.onValueChanged = {
            host?.pushUndo()
            l.xset("lightInf", if (inf.isOn) 1f else 0f)
            reload()
        }
        val infRow = UiView(appContext!!)
        infRow.addSubview(label("Infinite reach", 14f, false, 0xFFFFFFFF.toInt()))
        infRow.addSubview(inf)
        rows.add(infRow)
        if (type != 1 && !Lights.infinite(l)) rows.add(slider("Range", 0.5f, 200f, max(l.xf("lightRange", 20f), 0.5f), "%.1f") { l.xset("lightRange", it) })
        if (type == 1 || type == 2) {
            rows.add(slider("Pitch", -90f, 90f, l.xf("lightPitch", -60f), "%.0f") { l.xset("lightPitch", it) })
            rows.add(slider("Yaw", -180f, 180f, l.xf("lightYaw", 30f), "%.0f") { l.xset("lightYaw", it) })
        }
        if (type == 2) {
            rows.add(slider("Cone", 5f, 89f, l.xf("lightCone", 45f), "%.0f") { l.xset("lightCone", it) })
            rows.add(slider("Softness", 0f, 1f, l.xf("lightSoft", 0.3f)) { l.xset("lightSoft", it) })
        }
        rows.add(slider("Specular", 0f, 4f, l.xf("lightSpec", 1f)) { l.xset("lightSpec", it) })

        val st = UiView(appContext!!)
        for (r in rows) st.addSubview(r)
        var height = 0f
        for (r in rows) height += (r.rectHeight().takeIf { it > 0f } ?: 36f) + 8f
        box.addSubview(st)
        st.onLayout = { bw ->
            var y = 12f
            for (r in st.subviews) {
                val rh = when {
                    r === topRow -> 36f
                    r === seg -> 32f
                    r === sw -> 26f
                    else -> 36f
                }
                r.frame = CGRect(12f, y, bw - 24f, rh)
                r.onLayout?.invoke(bw - 24f)
                when (r) {
                    topRow -> {
                        (r.subviews[0] as? UILabel)?.let { it.frame = CGRect(0f, 8f, bw - 24f - 130f, 20f) }
                        r.subviews[1].frame = CGRect(bw - 24f - 84f, 3f, 44f, 28f)
                        r.subviews[2].frame = CGRect(bw - 24f - 32f, 4f, 28f, 28f)
                    }
                    seg -> {}
                    sw -> {}
                    infRow -> {
                        r.subviews[0].frame = CGRect(0f, 6f, bw - 24f - 60f, 20f)
                        r.subviews[1].frame = CGRect(bw - 24f - 52f, 2f, 50f, 32f)
                    }
                    else -> {}
                }
                y += rh + 8f
            }
        }
        box.frame = CGRect(0f, 0f, 100f, height + 12f)
        return box
    }
}
