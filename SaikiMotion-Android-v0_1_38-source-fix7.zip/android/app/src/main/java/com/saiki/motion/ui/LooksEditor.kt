@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/LooksEditor.swift — full-screen MB Looks editor: own live preview, a tool chain
// along the bottom (tap to select, x to remove, + to add), a Properties panel for the selected tool,
// portrait + landscape, .cube LUT import, Apply (keep) and Close (discard).

package com.saiki.motion.ui

import com.saiki.motion.app.Dlg
import com.saiki.motion.core.EffectDef
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LookLut
import com.saiki.motion.core.PropDef
import com.saiki.motion.core.Registry
import com.saiki.motion.core.looksCurveChannels
import com.saiki.motion.core.looksPresetNames
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIColorWell
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UISwitch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class LooksEditorViewController(private val lay: Layer, private val entry: String, private val onDone: () -> Unit) : UIViewController() {

    private val def: EffectDef? = Registry.get(entry)
    private val defs = HashMap<String, PropDef>()
    private val snap = HashMap<String, Float>()
    private var snapLut: String? = null
    private var snapMods: String? = null
    private val pv = PreviewView(appContext!!).apply { quality = 2 }   // half-res preview (LooksEditor.swift:21)
    private var curTab = "Presets"
    private var holdInt: Float? = null
    private val accent = argbToUIColor(C.GREEN)

    // tool chain: name -> params reset to neutral when removed
    private val allMods = listOf("Basic", "Wheels", "Color", "LUT", "Lens", "Post", "Diffusion", "Curves", "Streak", "Haze")
    private val defaultMods: List<String> = emptyList()      // chain starts empty
    private val neutral: Map<String, Map<String, Float>> = mapOf(
        "Basic" to mapOf("lkExpo" to 0f, "lkCon" to 0f, "lkHi" to 0f, "lkSh" to 0f, "lkWh" to 0f, "lkBl" to 0f, "lkTemp" to 0f, "lkTint" to 0f, "lkVib" to 0f, "lkSat" to 1f),
        "Wheels" to mapOf("lkLiftA" to 0f, "lkGamA" to 0f, "lkGainA" to 0f, "lkToneA" to 0f, "lkToneB" to 0f),
        "Color" to mapOf("lkSecAmt" to 0f),
        "LUT" to mapOf("lkLutAmt" to 1f),
        "Lens" to mapOf("lkBloom" to 0f, "lkHal" to 0f, "lkDif" to 0f, "lkSharp" to 0f, "lkDist" to 0f, "lkChroma" to 0f),
        "Post" to mapOf("lkVig" to 0f, "lkGrain" to 0f, "lkFade" to 0f, "lkLb" to 0f),
        "Diffusion" to mapOf("lkOD" to 0f),
        "Streak" to mapOf("lkStrk" to 0f),
        "Haze" to mapOf("lkHaze" to 0f))

    private var curveCh = "M"
    private val curveNeutral: Map<String, Float> by lazy {
        val d = HashMap<String, Float>()
        d["lkCurvAmt"] = 1f
        for (ch in looksCurveChannels) for (i in 0 until 7) d["lkCv$ch$i"] = i.toFloat() / 6f
        d
    }
    private fun neutralVals(m: String): Map<String, Float> = if (m == "Curves") curveNeutral else (neutral[m] ?: emptyMap())

    init {
        def?.props?.forEach { defs[it.key] = it }
        val pre = "${entry}__"
        for ((k, t) in lay.props) if (k.startsWith(pre)) snap[k] = t.base
        snapLut = lay.pbrMaps["lut:$entry"]
        snapMods = lay.pbrMaps["mods:$entry"]
    }

    // MARK: parameter access

    private fun key(k: String) = "${entry}__$k"

    private fun valx(k: String): Float {
        val kk = key(k)
        lay.props[kk]?.let { return it.eval(lay.editTime(kk, Editor.time)) }
        return defs[k]?.def ?: 0f
    }

    private fun set(k: String, v: Float) { lay.track(key(k)).base = v; pv.requestDraw() }

    private fun comp(k: String, s: String, d: Float): Float {
        val kk = "${key(k)}_$s"
        lay.props[kk]?.let { return it.eval(lay.editTime(kk, Editor.time)) }
        return d
    }

    // MARK: tool chain

    private var mods: List<String>
        get() = (lay.pbrMaps["mods:$entry"] ?: "").split(",").filter { allMods.contains(it) }.ifEmpty { defaultMods }
        set(v) { lay.pbrMaps["mods:$entry"] = v.joinToString(",") }

    private fun addMod(m: String) {
        val cur = mods.toMutableList()
        if (!cur.contains(m)) cur.add(m)
        mods = cur
        for ((k, v) in neutralVals(m)) set(k, v)      // added tools start neutral
        curTab = m
        pv.requestDraw(); showTab()
    }

    private fun removeMod(m: String) {
        mods = mods.filter { it != m }
        for ((k, v) in neutralVals(m)) set(k, v)
        if (m == "Curves") set("lkCurvAmt", 0f)
        if (m == "LUT") lay.pbrMaps.remove("lut:$entry")
        if (curTab == m) curTab = "Presets"
        pv.requestDraw(); showTab()
    }

    private fun showAddMenu() {
        val avail = allMods.filter { !mods.contains(it) }
        val blurb = mapOf("Basic" to "Exposure, contrast, color balance", "Wheels" to "Lift / gamma / gain, toning",
            "Color" to "Secondary hue select", "LUT" to ".cube LUTs", "Lens" to "Bloom, halation, diffusion, distortion",
            "Post" to "Vignette, grain, fade, letterbox", "Diffusion" to "Optical diffusion (soft glow)", "Curves" to "RGB curve graph",
            "Streak" to "Shutter streak light leak", "Haze" to "Haze / atmosphere")
        Dlg(this).setTitle(if (avail.isEmpty()) "All tools are in the chain." else "Add tool")
            .setItems(if (avail.isEmpty()) listOf("Cancel") else avail.map { "$it — ${blurb[it] ?: ""}" } + listOf("Cancel")) { _, i ->
                if (avail.isNotEmpty() && i < avail.size) addMod(avail[i])
            }.show()
    }

    // MARK: layout (manual frames; portrait: preview top / properties middle / chain bottom)

    private val bar = UiView(appContext!!)
    private val box = UiView(appContext!!)
    private val chainWrap = UiView(appContext!!)
    private val chainScroll = UIScrollView(appContext!!)
    private val chainRow = UiView(appContext!!)
    private val bodyScroll = UIScrollView(appContext!!)
    private val body = UiView(appContext!!)
    private val closeBtn = PillButton("  Close", "close", C.CARD2, C.TEXT)
    private val applyBtn = PillButton("Apply", null, C.GREEN, C.BG)
    private val titleL = UILabel(appContext!!)
    private val holdBtn = PillButton("Hold: before", null, 0x99000000.toInt(), C.TEXT)
    private val addChip = PillButton("＋ Add", null, C.CARD2, C.GREEN)
    private var isLandscapeLayout: Boolean? = null
    private var landScrollTopExtra = 0f

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(0x0F0F0F0F.toInt() and 0xFF0F0F0F.toInt())
        view.setBackgroundColor(0xFF0F0F0F.toInt())
        titleL.text = "Looks Editor"; titleL.font = UIFont.semiboldSystemFont(16f); titleL.textColor = argbToUIColor(C.TEXT)
        closeBtn.onClick = { finish(apply = false) }
        applyBtn.onClick = { finish(apply = true) }
        view.addSubview(bar); view.addSubview(box); view.addSubview(chainWrap); view.addSubview(bodyScroll)
        bar.addSubview(closeBtn); bar.addSubview(titleL); bar.addSubview(applyBtn)
        box.addSubview(pv); box.addSubview(holdBtn)
        chainWrap.addSubview(chainScroll); chainScroll.addSubview(chainRow); chainRow.addSubview(addChip)
        addChip.onClick = { showAddMenu() }
        bodyScroll.addSubview(body)
        pv.setBackgroundColor(0xFF000000.toInt())
        holdBtn.onClick = {   // Hold: before — press toggles the hold (touch-down/up pair on iOS)
            if (holdInt == null) { holdInt = valx("lkInt"); set("lkInt", 0f) } else { set("lkInt", holdInt!!); holdInt = null }
        }
        showTab()
    }

    private fun relayout() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w < 10 || h < 10) return
        val land = w > h
        if (isLandscapeLayout != land) { isLandscapeLayout = land; showTab() }
        var top = 0f
        if (land) {
            bar.frame = CGRect(0f, 0f, w, 52f)
            box.frame = CGRect(0f, 52f, w * 0.5f, h - 52f)
            bodyScroll.frame = CGRect(box.frame.maxX, 52f, w - box.frame.width, h - 52f - 64f)
            chainWrap.frame = CGRect(box.frame.maxX, h - 64f, w - box.frame.width, 64f)
        } else {
            bar.frame = CGRect(0f, 0f, w, 52f)
            box.frame = CGRect(0f, 52f, w, (h - 52f) * 0.36f + 0f)
            bodyScroll.frame = CGRect(0f, box.frame.maxY + 4f, w, h - box.frame.maxY - 4f - 64f)
            chainWrap.frame = CGRect(0f, h - 64f, w, 64f)
        }
        top = top
        closeBtn.frame = CGRect(12f, 9f, 92f, 34f)
        applyBtn.frame = CGRect(w - 84f, 9f, 72f, 34f)
        titleL.frame = CGRect(104f, 11f, w - 208f, 30f)
        titleL.textAlignment = NSTextAlignment.center
        holdBtn.frame = CGRect(box.rectWidth() - 118f, box.rectHeight() - 42f, 108f, 26f)
        // preview: fill the box as far as the aspect ratio allows
        val aspect = max(Editor.project.w, 1).toFloat() / max(Editor.project.h, 1).toFloat()
        var pw = box.rectWidth(); var ph = pw / aspect
        if (ph > box.rectHeight()) { ph = box.rectHeight(); pw = ph * aspect }
        pv.frame = CGRect((box.rectWidth() - pw) / 2, (box.rectHeight() - ph) / 2, pw, ph)
        // chain strip
        chainScroll.frame = CGRect(0f, 8f, chainWrap.rectWidth(), 48f)
        var x = 12f
        for (v in chainRow.subviews) { v.frame = CGRect(x, 6f, v.rectWidth().takeIf { it > 0f } ?: 92f, 36f); x += v.rectWidth() + 8f }
        chainRow.frame = CGRect(0f, 0f, max(x, chainScroll.rectWidth()), 48f)
        chainScroll.contentSize = CGSize(chainRow.rectWidth(), 48f)
        addChip.frame = CGRect(x, 6f, 92f, 36f)
        // body
        var y = 8f
        for (v in body.subviews) { v.frame = CGRect(16f, y, max(bodyScroll.rectWidth() - 32f, 10f), v.rectHeight().takeIf { it > 0f } ?: 30f); y += v.rectHeight() + 14f }
        body.frame = CGRect(0f, 0f, bodyScroll.rectWidth(), y + 24f)
        bodyScroll.contentSize = CGSize(bodyScroll.rectWidth(), y + 24f)
    }

    override fun viewDidLayoutSubviews() { super.viewDidLayoutSubviews(); relayout(); pv.requestDraw() }
    override fun viewDidAppear(animated: Boolean) { super.viewDidAppear(animated); pv.requestDraw() }

    // MARK: chain + properties

    private fun chip(text: String, on: Boolean, action: () -> Unit): PillButton {
        val b = PillButton(text, null, if (on) C.GREEN else 0xFF2B2B2B.toInt(), if (on) C.BG else C.TEXT)
        b.onClick = action
        return b
    }

    private fun rebuildChain() {
        chainRow.subviews.toList().forEach { it.removeFromSuperview() }
        chainRow.addSubview(chip("Presets", curTab == "Presets") { curTab = "Presets"; showTab() })
        for (m in mods) {
            val on = curTab == m
            val c = chip(m, on) { curTab = m; showTab() }
            chainRow.addSubview(c)
            val x = PillButton("✕", null, if (on) C.GREEN else 0xFF2B2B2B.toInt(), if (on) C.BG else C.DIM)
            x.onClick = { removeMod(m) }
            chainRow.addSubview(x)
        }
        chainRow.addSubview(addChip)
        addChip.setColors(C.GREEN)
        relayout()
    }

    private fun showTab() {
        rebuildChain()
        body.subviews.toList().forEach { it.removeFromSuperview() }
        fun add(v: UiView) { body.addSubview(v); v.frame = CGRect(16f, 0f, 100f, 30f) }
        val ph = UILabel(appContext!!); ph.text = "PROPERTIES  ·  " + curTab.uppercase(Locale.US)
        ph.font = UIFont.boldSystemFont(11f); ph.textColor = UIColor((0xFF8C8C8C).toInt())
        add(ph)
        when (curTab) {
            "Presets" -> { add(sliderRow("Intensity", "lkInt")); add(presetGrid()); add(sliderRow("Preset strength", "lkPStr")) }
            "Basic" -> for ((t, k) in listOf("Exposure (stops)" to "lkExpo", "Contrast" to "lkCon", "Contrast pivot" to "lkPivot", "Highlights" to "lkHi",
                "Shadows" to "lkSh", "Whites" to "lkWh", "Blacks" to "lkBl", "Temperature" to "lkTemp", "Tint" to "lkTint", "Vibrance" to "lkVib",
                "Saturation" to "lkSat")) add(sliderRow(t, k))
            "Wheels" -> {
                add(header("Lift (shadows)")); add(colorRow("Lift color", "lkLiftC")); add(sliderRow("Lift amount", "lkLiftA"))
                add(header("Gamma (midtones)")); add(colorRow("Gamma color", "lkGamC")); add(sliderRow("Gamma amount", "lkGamA"))
                add(header("Gain (highlights)")); add(colorRow("Gain color", "lkGainC")); add(sliderRow("Gain amount", "lkGainA"))
                add(header("Toning")); add(colorRow("Shadow tone", "lkShC")); add(colorRow("Highlight tone", "lkHiC"))
                add(sliderRow("Toning amount", "lkToneA")); add(sliderRow("Toning balance", "lkToneB"))
            }
            "Color" -> {
                add(header("Secondary: pick a hue and change only that"))
                for ((t, k) in listOf("Hue to select" to "lkSecHue", "Range" to "lkSecRange", "Softness" to "lkSecSoft",
                    "Hue shift" to "lkSecShift", "Saturation" to "lkSecSat", "Luminance" to "lkSecLum", "Amount" to "lkSecAmt")) add(sliderRow(t, k))
            }
            "LUT" -> lutTab()
            "Lens" -> {
                for ((t, k) in listOf("Bloom amount" to "lkBloom", "Bloom threshold" to "lkBThr", "Bloom radius" to "lkBRad", "Halation" to "lkHal")) add(sliderRow(t, k))
                add(colorRow("Halation color", "lkHalC"))
                for ((t, k) in listOf("Diffusion" to "lkDif", "Sharpen" to "lkSharp", "Distortion" to "lkDist", "Chromatic aberration" to "lkChroma")) add(sliderRow(t, k))
            }
            "Diffusion" -> {
                add(header("Optical diffusion: soft glow around highlights"))
                for ((t, k) in listOf("Density" to "lkOD", "Size" to "lkODSize", "Falloff" to "lkODFall", "Glow" to "lkODGlow", "Highlights only" to "lkODHi")) add(sliderRow(t, k))
                add(colorRow("Diffusion color", "lkODC"))
            }
            "Curves" -> curvesTab()
            "Streak" -> {
                add(header("Shutter streak: light leaking in at the top and bottom edges"))
                add(sliderRow("Boost", "lkStrk")); add(sliderRow("Size", "lkStrkSz")); add(sliderRow("Falloff", "lkStrkFall"))
                add(colorRow("Streak color", "lkStrkC"))
            }
            "Haze" -> {
                add(header("Haze: lifts blacks, softens contrast, tints the air"))
                add(sliderRow("Amount", "lkHaze")); add(sliderRow("Gradient (− top / + bottom)", "lkHazeSp"))
                add(sliderRow("Desaturation", "lkHazeSat")); add(colorRow("Haze color", "lkHazeC"))
            }
            else -> for ((t, k) in listOf("Vignette" to "lkVig", "Vignette midpoint" to "lkVigMid", "Vignette feather" to "lkVigF",
                "Vignette roundness" to "lkVigR", "Film grain" to "lkGrain", "Grain size" to "lkGrainSz",
                "Grain color" to "lkGrainC", "Faded blacks" to "lkFade", "Letterbox" to "lkLb")) add(sliderRow(t, k))
        }
        relayout()
    }

    // MARK: building blocks

    private fun header(t: String): UILabel {
        val l = UILabel(appContext!!); l.text = t.uppercase(Locale.US)
        l.font = UIFont.boldSystemFont(11f); l.textColor = argbToUIColor(C.GREEN); return l
    }

    private fun sliderRow(title: String, k: String): UiView {
        val pd = defs[k] ?: return UiView(appContext!!).apply { frame = CGRect(0f, 0f, 10f, 1f) }
        val fmt = if (pd.dec <= 0) "%.0f" else "%.${pd.dec}f"
        val col = UiView(appContext!!)
        col.frame = CGRect(0f, 0f, 100f, 62f)
        val t = UILabel(appContext!!); t.text = title; t.font = UIFont.systemFont(14f); t.textColor = argbToUIColor(C.TEXT)
        val v = UILabel(appContext!!); v.font = UIFont.monospacedDigitSystemFont(13f); v.textColor = argbToUIColor(C.GREEN)
        v.textAlignment = NSTextAlignment.right
        val s = UISlider(appContext!!); s.minValue = pd.min; s.maxValue = pd.max
        s.value = valx(k)
        v.text = String.format(Locale.US, fmt, s.value)
        s.onValueChanged = { x -> set(k, x); v.text = String.format(Locale.US, fmt, x) }
        val r = PillButton("↺", null, C.CARD2, C.DIM)
        r.onClick = { set(k, pd.def); s.value = pd.def; v.text = String.format(Locale.US, fmt, pd.def) }
        col.addSubview(t); col.addSubview(v); col.addSubview(r); col.addSubview(s)
        col.onLayout = { w ->
            t.frame = CGRect(0f, 0f, w * 0.6f, 22f)
            r.frame = CGRect(w - 34f, 0f, 30f, 22f)
            v.frame = CGRect(w * 0.6f, 0f, w * 0.4f - 40f, 22f)
            s.frame = CGRect(0f, 26f, w, 36f)
        }
        return col
    }

    private fun colorRow(title: String, k: String): UiView {
        val cp = def?.colors?.firstOrNull { it.key == k }
        val u = (cp?.def ?: 0xFF808080.toInt())
        val w = UIColorWell(appContext!!)
        w.supportsAlpha = false; w.title = title
        fun cur(): UIColor = UIColor.rgb(
            comp(k, "r", ((u shr 16) and 0xFF).toFloat() / 255f),
            comp(k, "g", ((u shr 8) and 0xFF).toFloat() / 255f),
            comp(k, "b", (u and 0xFF).toFloat() / 255f), 1f)
        w.selectedColor = cur()
        w.onValueChanged = {
            val c = w.selectedColor
            lay.track("${key(k)}_r").base = ((c.toInt() ushr 16) and 0xFF).toFloat() / 255f
            lay.track("${key(k)}_g").base = ((c.toInt() ushr 8) and 0xFF).toFloat() / 255f
            lay.track("${key(k)}_b").base = (c.toInt() and 0xFF).toFloat() / 255f
            lay.track("${key(k)}_a").base = 1f
            pv.requestDraw()
        }
        val row = UiView(appContext!!); row.frame = CGRect(0f, 0f, 100f, 40f)
        val t = UILabel(appContext!!); t.text = title; t.font = UIFont.systemFont(14f); t.textColor = argbToUIColor(C.TEXT)
        row.addSubview(t); row.addSubview(w)
        row.onLayout = { rw -> t.frame = CGRect(0f, 10f, rw - 56f, 20f); w.frame = CGRect(rw - 48f, 6f, 44f, 28f) }
        return row
    }

    private fun presetGrid(): UiView {
        val cur = (valx("lkPreset") + 0.5f).toInt()
        val col = UiView(appContext!!); col.frame = CGRect(0f, 0f, 100f, 40f)
        val cells = ArrayList<PillButton>()
        for ((i, n) in looksPresetNames.withIndex()) {
            val b = chip(n, i == cur) {
                set("lkPreset", if (i == cur) 0f else i.toFloat()); showTab()   // tap the active preset again to go back to Custom
            }
            col.addSubview(b); cells.add(b)
        }
        col.onLayout = { w ->
            val cw = (w - 8f) / 2f
            for ((i, b) in cells.withIndex()) b.frame = CGRect((i % 2) * (cw + 8f), (i / 2) * 44f, cw, 36f)
        }
        return col
    }

    // MARK: LUT

    private fun lutTab() {
        val cur = lay.pbrMaps["lut:$entry"]
        val imp = chip("Import LUT (.cube)", true) { pickLut() }
        body.addSubview(imp); imp.frame = CGRect(16f, 0f, 200f, 36f)
        val info = UILabel(appContext!!)
        info.font = UIFont.systemFont(12f); info.textColor = UIColor((0xFF999999).toInt()); info.numberOfLines = 0
        info.text = "Imported LUTs are kept on this device. Tap one to use it on this effect."
        body.addSubview(info)
        body.addSubview(chip("None", cur == null) {
            lay.pbrMaps.remove("lut:$entry"); pv.requestDraw(); showTab()
        })
        for (n in LookLut.shared.names()) {
            body.addSubview(chip((if (cur == n) "✓  " else "") + n, cur == n) {
                lay.pbrMaps["lut:$entry"] = n; pv.requestDraw(); showTab()
            })
        }
        body.addSubview(sliderRow("LUT strength", "lkLutAmt"))
    }

    private fun pickLut() {
        com.saiki.motion.app.DocPicker.pick { uri ->
            try {
                val bytes = appContext!!.contentResolver.openInputStream(uri)?.readBytes()
                val tmp = kotlin.io.path.createTempFile("lut", ".cube").toFile()
                tmp.writeBytes(bytes ?: return@pick)
                val name = LookLut.shared.importFile(tmp, uri.lastPathSegment ?: "lut.cube")
                tmp.delete()
                if (name != null) {
                    lay.pbrMaps["lut:$entry"] = name
                    pv.requestDraw(); showTab()
                } else {
                    Dlg(this).setTitle("Can't use this LUT").setMessage("Only 3D .cube files (LUT_3D_SIZE) are supported.")
                        .setPositiveButton("OK", null).show()
                }
            } catch (_: Exception) {
                Dlg(this).setTitle("Can't use this LUT").setMessage("Only 3D .cube files (LUT_3D_SIZE) are supported.")
                    .setPositiveButton("OK", null).show()
            }
        }
    }

    // MARK: curves

    private fun curvesTab() {
        add2(header("Curves: drag a dot up or down"))
        val names = listOf(Triple("M", "Master", C.TEXT), Triple("R", "Red", 0xFFFF4C4C.toInt()),
            Triple("G", "Green", 0xFF4CE64C.toInt()), Triple("B", "Blue", 0xFF6699FF.toInt()))
        val row = UiView(appContext!!); row.frame = CGRect(0f, 0f, 100f, 36f)
        for ((id, n, _) in names) {
            row.addSubview(chip(n, curveCh == id) { curveCh = id; showTab() })
        }
        row.onLayout = { w ->
            val cw = (w - 24f) / 4f
            for ((i, v) in row.subviews.withIndex()) v.frame = CGRect(i * (cw + 8f), 0f, cw, 32f)
        }
        add2(row)
        val ch = curveCh
        val g = LooksCurveGraphView(appContext!!)
        g.color = names.firstOrNull { it.first == ch }?.third ?: C.TEXT
        g.values = (0 until 7).map { valx("lkCv$ch$it") }.toFloatArray()
        g.onChange = { i, v -> set("lkCv$ch$i", v) }
        g.frame = CGRect(0f, 0f, 100f, 260f)
        add2(g)
        add2(chip("Reset this curve", false) {
            for (i in 0 until 7) set("lkCv$ch$i", i.toFloat() / 6f)
            showTab()
        })
        add2(sliderRow("Curves amount", "lkCurvAmt"))
    }

    private fun add2(v: UiView) { body.addSubview(v) }

    // MARK: finish

    private fun finish(apply: Boolean) {
        if (!apply) {
            val pre = "${entry}__"
            for (k in lay.props.keys.toList()) {
                if (!k.startsWith(pre)) continue
                val b = snap[k]
                if (b != null) lay.props[k]?.base = b else lay.props.remove(k)
            }
            val sl = snapLut; if (sl != null) lay.pbrMaps["lut:$entry"] = sl else lay.pbrMaps.remove("lut:$entry")
            val sm = snapMods; if (sm != null) lay.pbrMaps["mods:$entry"] = sm else lay.pbrMaps.remove("mods:$entry")
        }
        val done = onDone
        dismiss(animated = true) { done() }
    }
}

/** Draggable curve graph: 7 points at x = i/6, drawn as the same Catmull-Rom spline the shader uses. */
class LooksCurveGraphView(context: android.content.Context) : UiView(context) {
    var values: FloatArray = FloatArray(7) { it.toFloat() / 6f }
        set(v) { field = v; setNeedsDisplay() }
    var color: Int = C.TEXT
        set(v) { field = v; setNeedsDisplay() }
    var onChange: ((Int, Float) -> Unit)? = null
    private var active = -1

    init { setBackgroundColor(0xFF1F1F1F.toInt()) }

    private val area: CGRect get() = boundsRect.insetBy(16f, 16f)
    private fun pt(x: Float, y: Float): CGPoint =
        CGPoint(area.x + area.width * x, area.maxY - area.height * y)

    fun eval(v: FloatArray, x: Float): Float {
        val t = min(max(x, 0f), 1f) * 6f
        val seg = min(t.toInt(), 5); val f = t - seg
        val a = v[max(seg - 1, 0)]; val b = v[seg]; val c = v[seg + 1]; val d = v[min(seg + 2, 6)]
        return 0.5f * (2 * b + (c - a) * f + (2 * a - 5 * b + 4 * c - d) * f * f + (3 * b - a - 3 * c + d) * f * f * f)
    }

    public override fun draw(rect: CGRect) {
        val g = UIGraphics.getCurrentContext() ?: return
        if (values.size != 7) return
        g.setStrokeColor(0x1AFFFFFF.toInt()); g.setLineWidth(1f)
        for (i in 0..4) {
            val f = i.toFloat() / 4f
            g.beginPath(); g.move(pt(f, 0f)); g.addLine(pt(f, 1f)); g.strokePath()
            g.beginPath(); g.move(pt(0f, f)); g.addLine(pt(1f, f)); g.strokePath()
        }
        g.setStrokeColor(0x40FFFFFF.toInt())
        g.beginPath(); g.move(pt(0f, 0f)); g.addLine(pt(1f, 1f)); g.strokePath()
        g.setStrokeColor(color); g.setLineWidth(2.5f)
        g.beginPath()
        for (i in 0..120) {
            val x = i.toFloat() / 120f
            val p = pt(x, min(max(eval(values, x), 0f), 1f))
            if (i == 0) g.move(p) else g.addLine(p)
        }
        g.strokePath()
        for (i in 0 until 7) {
            val p = pt(i.toFloat() / 6f, values[i])
            g.setFillColor(if (i == active) color else 0xFF000000.toInt())
            g.setStrokeColor(color); g.setLineWidth(2f)
            val r = CGRect(p.x - 8f, p.y - 8f, 16f, 16f)
            g.fillEllipse(r); g.strokeEllipse(r)
        }
    }

    private fun drag(x: Float, y: Float, pick: Boolean) {
        if (pick) {
            val fx = (x - area.x) / max(area.width, 1f)
            active = min(max((fx * 6f).toInt(), 0), 6)
        }
        if (active < 0) return
        val v = (area.maxY - y) / max(area.height, 1f)
        values[active] = min(max(v, 0f), 1f)
        onChange?.invoke(active, values[active])
    }

    override fun touchesBegan(touches: Set<com.saiki.motion.uikit.UITouch>, event: com.saiki.motion.uikit.UIEvent?) {
        touches.first()?.let { drag(it.location(this).x, it.location(this).y, true) }
    }
    override fun touchesMoved(touches: Set<com.saiki.motion.uikit.UITouch>, event: com.saiki.motion.uikit.UIEvent?) {
        touches.first()?.let { drag(it.location(this).x, it.location(this).y, false) }
    }
    override fun touchesEnded(touches: Set<com.saiki.motion.uikit.UITouch>, event: com.saiki.motion.uikit.UIEvent?) {
        active = -1; setNeedsDisplay()
    }
    override fun touchesCancelled(touches: Set<com.saiki.motion.uikit.UITouch>, event: com.saiki.motion.uikit.UIEvent?) {
        active = -1; setNeedsDisplay()
    }
}
