@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/MBLEditor.swift — "Magic Bullet Looks" editor (mobile layout of the desktop UI):
// live preview, Controls panel for the selected tool, a tool chain grouped Subject / Matte / Lens /
// Camera / Post with icon cards, a Tools picker (icon grid with category tabs) and an Intensity
// slider. Parameters live on the layer (entry__mbXxx); Close discards, ✓ keeps.

package com.saiki.motion.ui

import com.saiki.motion.app.Dlg
import com.saiki.motion.core.EffectDef
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.PropDef
import com.saiki.motion.core.Registry
import com.saiki.motion.core.SceneRenderer
import com.saiki.motion.core.looksCurveChannels
import com.saiki.motion.core.mblHazePresets
import com.saiki.motion.core.mblHslHue
import com.saiki.motion.core.mblHslNames
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIColorWell
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UISwitch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIGraphicsImageRenderer
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.uikit.fillCircle
import com.saiki.motion.uikit.fillRoundRect
import com.saiki.motion.uikit.strokeRoundRect
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class MBLTool(val id: String, val name: String, val cat: String,
              val vals: List<Triple<String, Float, Float>>,                 // key, neutral, value when added
              val sliders: List<Pair<String, String>> = emptyList(),        // label, key
              val colors: List<Pair<String, String>> = emptyList())

val mblCats = listOf("Subject", "Matte", "Lens", "Camera", "Post")

val mblTools: List<MBLTool> = run {
    val hsl: MutableList<Triple<String, Float, Float>> = mutableListOf(Triple("mbHsl", 0f, 1f))
    for (i in 0 until 8) { hsl.add(Triple("mbH$i", 0f, 0f)); hsl.add(Triple("mbS$i", 0f, 0f)); hsl.add(Triple("mbL$i", 0f, 0f)) }
    val lgg: MutableList<Triple<String, Float, Float>> = mutableListOf(Triple("mbLg", 0f, 1f), Triple("mbLgSp", 1f, 1f), Triple("mbLgStr", 100f, 100f), Triple("mbLgExp", 0f, 0f))
    for (p in listOf("Li", "Ga", "Gn")) for (c in listOf("R", "G", "B")) lgg.add(Triple("mb$p$c", 1f, 1f))
    val colo: MutableList<Triple<String, Float, Float>> = mutableListOf(Triple("mbCo", 0f, 1f), Triple("mbCoExp", 0f, 0f), Triple("mbCoSat", 1f, 1f), Triple("mbCoStr", 1f, 1f))
    for (r in listOf("S", "M", "H")) { colo.add(Triple("mbCo${r}x", 0f, 0f)); colo.add(Triple("mbCo${r}y", 0f, 0f)); colo.add(Triple("mbCo${r}l", 0f, 0f)) }
    listOf(
        MBLTool("diffusion", "Diffusion", "Matte",
            listOf(Triple("mbDfSize", 0f, 30f), Triple("mbDfGrade", 3f, 3f), Triple("mbDfGlow", 50f, 50f), Triple("mbDfHi", 75f, 75f), Triple("mbDfBias", 0f, 0f), Triple("mbDfExp", 0f, 0f)),
            listOf("Size" to "mbDfSize", "Grade" to "mbDfGrade", "Glow" to "mbDfGlow", "Highlights Only" to "mbDfHi",
                "Highlight Bias" to "mbDfBias", "Exposure Compensation" to "mbDfExp"), listOf("Color" to "mbDfC")),
        MBLTool("edge", "Edge Softness", "Lens",
            listOf(Triple("mbEsBlur", 0f, 3f), Triple("mbEsQ", 3f, 3f), Triple("mbEsX", 0f, 0f), Triple("mbEsY", 0f, 0f), Triple("mbEsRad", 1f, 1f), Triple("mbEsAsp", 1f, 1f), Triple("mbEsSpr", 0.5f, 0.5f)),
            listOf("Blur Size" to "mbEsBlur", "Quality" to "mbEsQ", "Center X" to "mbEsX", "Center Y" to "mbEsY",
                "Radius" to "mbEsRad", "Aspect" to "mbEsAsp", "Spread" to "mbEsSpr")),
        MBLTool("hazeflare", "Haze/Flare", "Lens",
            listOf(Triple("mbHf", 0f, 1f), Triple("mbHfSp", 16.5f, 16.5f), Triple("mbHfSo", 49f, 49f), Triple("mbHfRe", 53.2f, 53.2f), Triple("mbHfEx", -1f, -1f), Triple("mbHfRx", 0f, 0f),
                Triple("mbHfRf", 1f, 1f), Triple("mbHfBx", 50f, 50f), Triple("mbHfSh", 75f, 75f), Triple("mbHfPre", 0f, 0f)),
            colors = listOf("Tint Color" to "mbHfC")),
        MBLTool("chroma", "Chromatic Aberration", "Lens",
            listOf(Triple("mbCaR", 0f, 1f), Triple("mbCaG", 0f, 0f), Triple("mbCaB", 0f, 0f)),
            listOf("Red/Cyan" to "mbCaR", "Green/Magenta" to "mbCaG", "Blue/Yellow" to "mbCaB")),
        MBLTool("exposure", "Exposure", "Post", listOf(Triple("mbExpo", 0f, 0.01f)), listOf("Exposure (stops)" to "mbExpo")),
        MBLTool("warmcool", "Warm/Cool", "Post", listOf(Triple("mbWarm", 0f, 0.2f)), listOf("Warm / Cool" to "mbWarm")),
        MBLTool("renoiser", "Renoiser", "Post", listOf(Triple("mbGrain", 0f, 0.3f), Triple("mbGrainSz", 1.5f, 1.5f)),
            listOf("Amount" to "mbGrain", "Grain size" to "mbGrainSz")),
        MBLTool("bleach", "Print Bleach Bypass", "Post", listOf(Triple("mbBB", 0f, 50f), Triple("mbBBe", 0f, 0f)), listOf("Silver Retention" to "mbBB", "Exposure Compensation" to "mbBBe")),
        MBLTool("contrast", "Contrast", "Post", listOf(Triple("mbCon", 0f, 0.2f), Triple("mbConPiv", 0.18f, 0.18f)),
            listOf("Contrast" to "mbCon", "Pivot" to "mbConPiv")),
        MBLTool("huesat", "Hue/Saturation", "Post", listOf(Triple("mbHue", 0f, 0f), Triple("mbSat", 1f, 1.01f)),
            listOf("Hue" to "mbHue", "Saturation" to "mbSat")),
        MBLTool("hsl", "HSL Colors", "Post", hsl),
        MBLTool("duotone", "Duotone", "Post", listOf(Triple("mbDuo", 0f, 1f), Triple("mbDuoSA", 1f, 1f), Triple("mbDuoSB", 1f, 1f), Triple("mbDuoLo", 0f, 0f), Triple("mbDuoHi", 1f, 1f)),
            listOf("Amount" to "mbDuo", "Highlights strength" to "mbDuoSA", "Shadows strength" to "mbDuoSB", "Low" to "mbDuoLo", "High" to "mbDuoHi"),
            listOf("Shadows" to "mbDuoS", "Highlights" to "mbDuoH")),
        MBLTool("nbby", "Neg Bleach Bypass", "Post", listOf(Triple("mbNB", 0f, 50f), Triple("mbNBe", 0f, 0f)), listOf("Silver Retention" to "mbNB", "Exposure Compensation" to "mbNBe")),
        MBLTool("lgg", "Lift/Gamma/Gain", "Post", lgg,
            listOf("Lift Red" to "mbLiR", "Lift Green" to "mbLiG", "Lift Blue" to "mbLiB", "Gamma Red" to "mbGaR", "Gamma Green" to "mbGaG", "Gamma Blue" to "mbGaB",
                "Gain Red" to "mbGnR", "Gain Green" to "mbGnG", "Gain Blue" to "mbGnB", "Gamma Space" to "mbLgSp", "Strength" to "mbLgStr", "Exposure Compensation" to "mbLgExp")),
        MBLTool("bw", "Black & White", "Post", listOf(Triple("mbBw", 0f, 1f), Triple("mbBwR", 0.3f, 0.3f), Triple("mbBwG", 0.59f, 0.59f), Triple("mbBwB", 0.11f, 0.11f)),
            listOf("Red Component" to "mbBwR", "Green Component" to "mbBwG", "Blue Component" to "mbBwB")),
        MBLTool("twostrip", "2-Strip Process", "Post", listOf(Triple("mbTsOn", 0f, 1f), Triple("mbTsE", 1f, 1f), Triple("mbTsS", 0.5f, 0.5f)), listOf("Gain" to "mbTsE", "Mix" to "mbTsS")),
        MBLTool("lightflex", "Lightflex", "Post", listOf(Triple("mbFl", 0f, 1f), Triple("mbFlB", 0f, 0f), Triple("mbFlE", 0f, 0f)),
            listOf("Boost" to "mbFlB", "Exposure Compensation" to "mbFlE"), listOf("Color" to "mbFlC")),
        MBLTool("shoulder", "Auto Shoulder", "Post", listOf(Triple("mbAs", 0f, 50f)), listOf("Strength" to "mbAs")),
        MBLTool("vignette", "Vignette", "Post",
            listOf(Triple("mbVgStr", 0f, 100f), Triple("mbVgExp", 0f, 0f), Triple("mbVgRad", 1f, 1f), Triple("mbVgSpr", 0.5f, 0.5f), Triple("mbVgFall", 0.5f, 0.5f), Triple("mbVgX", 0f, 0f), Triple("mbVgY", 0f, 0f), Triple("mbVgAsp", 1f, 1f)),
            listOf("Strength" to "mbVgStr", "Exposure Compensation" to "mbVgExp", "Radius" to "mbVgRad", "Spread" to "mbVgSpr", "Falloff" to "mbVgFall",
                "Center X" to "mbVgX", "Center Y" to "mbVgY", "Aspect" to "mbVgAsp"), listOf("Color" to "mbVgC")),
        MBLTool("spot", "Spot Exposure", "Post",
            listOf(Triple("mbSpOn", 0f, 1f), Triple("mbSpS", 0f, 1f), Triple("mbSpRad", 0.6f, 0.6f), Triple("mbSpSpr", 0.5f, 0.5f), Triple("mbSpFall", 0.5f, 0.5f), Triple("mbSpX", 0f, 0f), Triple("mbSpY", 0f, 0f), Triple("mbSpAsp", 1f, 1f), Triple("mbSpInv", 0f, 0f)),
            listOf("Stops" to "mbSpS", "Radius" to "mbSpRad", "Spread" to "mbSpSpr", "Falloff" to "mbSpFall", "Center X" to "mbSpX", "Center Y" to "mbSpY",
                "Aspect" to "mbSpAsp", "Invert" to "mbSpInv"), listOf("Color" to "mbSpC")),
        MBLTool("grad", "Grad Exposure", "Post",
            listOf(Triple("mbGxOn", 0f, 1f), Triple("mbGxStops", 0f, -1f), Triple("mbGxStr", 100f, 100f), Triple("mbGxFall", 0.5f, 0.5f), Triple("mbGxSx", 0.5f, 0.5f), Triple("mbGxSy", 0.25f, 0.25f), Triple("mbGxEx", 0.5f, 0.5f), Triple("mbGxEy", 0.75f, 0.75f)),
            listOf("Stops" to "mbGxStops", "Strength" to "mbGxStr", "Falloff" to "mbGxFall", "Start X" to "mbGxSx", "Start Y" to "mbGxSy", "End X" to "mbGxEx", "End Y" to "mbGxEy"),
            listOf("Color" to "mbGxC")),
        MBLTool("colorista", "Colorista", "Subject", colo),
        MBLTool("mojo", "Mojo II", "Post",
            listOf(Triple("mbMj", 0f, 1f), Triple("mbMjAmt", 0f, 0.8f), Triple("mbMjTO", 0f, 0.5f), Triple("mbMjWarm", 0f, 0f), Triple("mbMjCon", 0f, 0.2f), Triple("mbMjSat", 1f, 1.1f), Triple("mbMjFade", 0f, 0.15f)),
            listOf("Amount" to "mbMjAmt", "Teal / Orange" to "mbMjTO", "Warmth" to "mbMjWarm", "Contrast" to "mbMjCon", "Saturation" to "mbMjSat", "Fade" to "mbMjFade")),
        MBLTool("curves", "Curves", "Post", listOf(Triple("mbCurvAmt", 0f, 1f))),
    )
}

/// Icons redrawn to match the Magic Bullet tiles (UIGraphicsImageRenderer -> Canvas drawing).
fun mblIcon(id: String, s: Float = 64f): UIImage {
    val r = UIGraphicsImageRenderer(s.toInt(), s.toInt())
    return r.image { g ->
        val rect = CGRect(0f, 0f, s, s)
        val ctr = CGPoint(s / 2, s / 2)
        val cv = g
        fun rr(c: Int) { fillRoundRect(cv, rect, 6f, c) }
        fun grad(cols: List<Int>, a: CGPoint, b: CGPoint) {
            cv.saveGState()
            val p = com.saiki.motion.uikit.CGPath.roundedRect(rect, 6f, 6f)
            cv.addPath(p); cv.clipPath()
            cv.drawLinearGradient(cols.toIntArray(), a, b)
            cv.restoreGState()
        }
        fun wheel(inner: Float) {
            for (i in 0 until 72) {
                val a0 = i.toFloat() / 72f * (Math.PI * 2).toFloat()
                val a1 = (i + 1.2f) / 72f * (Math.PI * 2).toFloat()
                val col = UIColor.hsv(i.toFloat() / 72f, 0.85f, 1f, 1f)
                val path = com.saiki.motion.uikit.CGPath()
                path.move(ctr)
                path.addArc(ctr, s * 0.44f, a0, a1, true)
                cv.setFillColor(col.toInt())
                cv.addPath(path.path); cv.fillPath()
            }
            val innerCol = if (inner > 0) 0xFF000000.toInt() else 0xFFE6E6E6.toInt()
            cv.setFillColor(innerCol)
            cv.fillEllipse(CGRect(ctr.x - s * (if (inner > 0) inner else 0.1f), ctr.y - s * (if (inner > 0) inner else 0.1f),
                2 * s * (if (inner > 0) inner else 0.1f), 2 * s * (if (inner > 0) inner else 0.1f)))
        }
        val pi2 = (Math.PI * 2).toFloat()
        when (id) {
            "exposure" -> {
                rr(0xFF1A1A1A.toInt())
                cv.setFillColor(0xFF999999.toInt()); cv.fillEllipse(CGRect(ctr.x - s * 0.44f, ctr.y - s * 0.44f, s * 0.88f, s * 0.88f))
                cv.setFillColor(0xFFF2F2F2.toInt()); cv.fillEllipse(CGRect(ctr.x - s * 0.2f, ctr.y - s * 0.2f, s * 0.4f, s * 0.4f))
                cv.setStrokeColor(0xFF595959.toInt()); cv.setLineWidth(2f)
                for (i in 0 until 6) {
                    val a = i.toFloat() / 6f * pi2
                    cv.beginPath()
                    cv.move(CGPoint(ctr.x + cos(a) * s * 0.2f, ctr.y + sin(a) * s * 0.2f))
                    cv.addLine(CGPoint(ctr.x + cos(a + 0.9f) * s * 0.44f, ctr.y + sin(a + 0.9f) * s * 0.44f))
                    cv.strokePath()
                }
            }
            "hazeflare" -> {
                rr(0xFF000000.toInt())
                cv.setFillColor(0xFFFFFFFF.toInt())
                for (i in 0 until 9) {
                    val y = s * (0.1f + i * 0.07f)
                    val w = s * (if (i < 6) 0.44f else 0.44f - (i - 5) * 0.09f)
                    cv.fill(CGRect(s * 0.1f, y, w, s * 0.04f))
                }
                for (i in 0 until 3) cv.fill(CGRect(s * 0.74f + i * s * 0.07f, s * (0.12f + 0.05f * i), s * 0.03f, s * 0.2f))
                cv.setFillColor(0xFF663D1A.toInt())
                for (i in 0 until 4) cv.fill(CGRect(s * 0.1f + i * s * 0.05f, s * (0.78f + 0.045f * i), s * (0.5f - i * 0.06f), s * 0.025f))
            }
            "warmcool" -> {
                rr(0xFF1A1A1A.toInt())
                cv.setFillColor(0xFF8C8C8C.toInt()); cv.fillEllipse(CGRect(ctr.x - s * 0.44f, ctr.y - s * 0.44f, s * 0.88f, s * 0.88f))
            }
            "renoiser" -> {
                rr(0xFFBFBFBF.toInt())
                val rnd = java.util.Random(7)
                repeat(160) {
                    val w = 0.35f + rnd.nextFloat() * 0.65f
                    val c = (255 shl 24) or ((w * 255).toInt() shl 16) or ((w * 255).toInt() shl 8) or (w * 255).toInt()
                    cv.setFillColor(c)
                    cv.fill(CGRect(8f + rnd.nextFloat() * (s - 18f), 8f + rnd.nextFloat() * (s - 18f), 2f, 2f))
                }
            }
            "bleach" -> {
                grad(listOf(0xFFF2CC80.toInt(), 0xFF59401A.toInt()), CGPoint(0f, 0f), CGPoint(s, s))
                cv.setStrokeColor(0xFFD91A1A.toInt()); cv.setLineWidth(3f)
                cv.beginPath()
                cv.move(CGPoint(s * 0.5f, s * 0.18f)); cv.addLine(CGPoint(s * 0.82f, s * 0.78f)); cv.addLine(CGPoint(s * 0.18f, s * 0.78f)); cv.closeSubpath()
                cv.strokePath()
            }
            "contrast" -> grad(listOf(0xFFFFFFFF.toInt(), 0xFF0D0D0D.toInt()), CGPoint(0f, 0f), CGPoint(s, s))
            "huesat" -> { rr(0xFF1A1A1A.toInt()); wheel(0f) }
            "hsl" -> { rr(0xFF1A1A1A.toInt()); wheel(0.32f) }
            "duotone" -> grad(listOf(0xFFF2F2F2.toInt(), 0xFFCC9973.toInt(), 0xFF0D1940.toInt()), CGPoint(0f, 0f), CGPoint(0f, s))
            "curves" -> {
                rr(0xFF000000.toInt())
                cv.setStrokeColor(0xFFFFFFFF.toInt()); cv.setLineWidth(2.5f)
                cv.beginPath(); cv.move(CGPoint(4f, s - 4f)); cv.addLine(CGPoint(s - 4f, 4f)); cv.strokePath()
            }
            "chroma" -> {
                rr(0xFF000000.toInt())
                for (i in 0 until 72) {
                    val a0 = i.toFloat() / 72f * pi2; val a1 = (i + 1.5f) / 72f * pi2
                    for ((k, rd) in listOf(0.4f, 0.34f, 0.28f).withIndex()) {
                        cv.setStrokeColor(UIColor.hsv(((i.toFloat() / 72f + k * 0.08f) % 1f), 0.9f, 1f, if (k == 1) 0.55f else 1f).toInt())
                        cv.setLineWidth(s * 0.07f)
                        val p = com.saiki.motion.uikit.CGPath()
                        p.addArc(ctr, s * rd, a0, a1, true)
                        cv.addPath(p.path); cv.strokePath()
                    }
                }
            }
            "edge" -> {
                rr(0xFFFFFFFF.toInt())
                cv.setFillColor(0xFF000000.toInt())
                val n = 8; val q = s / n
                for (y in 0 until n) for (x in 0 until n) if ((x + y) % 2 == 0) cv.fill(CGRect(x * q, y * q, q, q))
            }
            "diffusion" -> {
                rr(0xFF000000.toInt())
                val p = UIFont.systemFont(s * 0.8f).toPaint()
                p.typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.ITALIC)
                p.isFakeBoldText = true
                p.color = 0xFFFFFFFF.toInt()
                cv.canvas.drawText("D", s * 0.26f, s * 0.86f, p)
            }
            "nbby" -> {
                grad(listOf(0xFFCCB280.toInt(), 0xFF1A1A1A.toInt()), CGPoint(0f, 0f), CGPoint(s, s))
                cv.setStrokeColor(0xFFFFFFFF.toInt()); cv.setLineWidth(3f)
                cv.beginPath(); cv.move(CGPoint(s * 0.5f, s * 0.2f)); cv.addLine(CGPoint(s * 0.8f, s * 0.76f)); cv.addLine(CGPoint(s * 0.2f, s * 0.76f)); cv.closeSubpath(); cv.strokePath()
            }
            "lgg" -> {
                rr(0xFF1A1A1A.toInt())
                val grays = listOf(0.15f, 0.5f, 0.9f)
                for ((i, gv) in grays.withIndex()) {
                    val c = (255 shl 24) or (((gv * 255).toInt()) shl 16) or (((gv * 255).toInt()) shl 8) or ((gv * 255).toInt())
                    cv.setFillColor(c)
                    cv.fillEllipse(CGRect(s * (0.22f + 0.28f * i) - s * 0.15f, s * (if (i == 1) 0.35f else 0.65f) - s * 0.15f, s * 0.3f, s * 0.3f))
                }
            }
            "colorista" -> {
                rr(0xFF121212.toInt())
                val gs = listOf(0.5f, 0.2f, 0.95f)
                val xs = listOf(0.5f, 0.3f, 0.7f); val ys = listOf(0.3f, 0.68f, 0.68f)
                for ((i, gv) in gs.withIndex()) {
                    val c = (255 shl 24) or (((gv * 255).toInt()) shl 16) or (((gv * 255).toInt()) shl 8) or ((gv * 255).toInt())
                    cv.setFillColor(c)
                    cv.fillEllipse(CGRect(s * xs[i] - s * 0.2f, s * ys[i] - s * 0.2f, s * 0.4f, s * 0.4f))
                }
            }
            "mojo" -> {
                rr(0xFF141414.toInt())
                cv.setStrokeColor(0xFFE6E6E6.toInt()); cv.setLineWidth(5f)
                cv.strokeEllipse(CGRect(ctr.x - s * 0.38f, ctr.y - s * 0.38f, s * 0.76f, s * 0.76f))
                cv.setFillColor(0xFFE6A680.toInt()); cv.fillEllipse(CGRect(ctr.x - s * 0.3f, ctr.y - s * 0.3f, s * 0.6f, s * 0.6f))
            }
            "bw" -> grad(listOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt()), CGPoint(0f, 0f), CGPoint(s, 0f))
            "twostrip" -> grad(listOf(0xFFFF0000.toInt(), 0xFF00FFFF.toInt()), CGPoint(0f, 0f), CGPoint(s, s))
            "lightflex" -> grad(listOf(0xFF1A1A1A.toInt(), 0xFFFFE699.toInt()), CGPoint(0f, s), CGPoint(s, 0f))
            "shoulder" -> {
                rr(0xFF000000.toInt())
                cv.setStrokeColor(0xFFFFFFFF.toInt()); cv.setLineWidth(2.5f)
                cv.beginPath(); cv.move(CGPoint(4f, s - 4f)); cv.addQuadCurve(to = CGPoint(s - 4f, s * 0.2f), control = CGPoint(s * 0.7f, s * 0.1f)); cv.strokePath()
            }
            "vignette", "spot" -> {
                rr(0xFF0D0D0D.toInt())
                val mid = if (id == "spot") 0xFFFFFFFF.toInt() else 0xFFD9D9D9.toInt()
                cv.saveGState()
                cv.paint.shader = android.graphics.RadialGradient(ctr.x, ctr.y, s * 0.55f, intArrayOf(mid, 0xFF0D0D0D.toInt()), null, android.graphics.Shader.TileMode.CLAMP)
                cv.addPath(com.saiki.motion.uikit.CGPath.roundedRect(rect, 6f, 6f)); cv.clipPath()
                cv.fill(rect)
                cv.restoreGState()
            }
            "grad" -> grad(listOf(0xFFF2F2F2.toInt(), 0xFF1A1A1A.toInt()), CGPoint(0f, 0f), CGPoint(0f, s))
            else -> rr(0xFF333333.toInt())
        }
    }
}

/** Ids of the tools added in an MBL instance (what the editor's chain shows). */
fun mblActiveTools(l: Layer, entry: String): List<String> =
    (l.pbrMaps["mbmods:$entry"] ?: "").split(",").filter { id -> mblTools.any { it.id == id } }

class MBLEditorViewController(private val lay: Layer, private val entry: String, private val onDone: () -> Unit) : UIViewController() {

    private val def: EffectDef? = Registry.get(entry)
    private val defs = HashMap<String, PropDef>()
    private val snap = HashMap<String, Float>()
    private var snapMods: String? = null
    private var snapFx: List<String> = emptyList()
    private var savedVideoCb: (() -> Unit)? = null
    private val pv by lazy {
        savedVideoCb = SceneRenderer.onVideoFrame
        PreviewView(appContext!!).apply { quality = 2 }   // half-res preview (MBLEditor.swift:193)
    }
    private var gizmo: MBLGizmoView? = null
    private var curTool: String? = null
    private var curveCh = "M"
    private var hslIdx = 0
    private var holdInt: Float? = null
    private var pickCat = "Post"
    private val gold = UIColor.rgb(0.96f, 0.65f, 0.14f, 1f)
    private var isLandscapeLayout: Boolean? = null

    init {
        def?.props?.forEach { defs[it.key] = it }
        val pre = "${entry}__"
        for ((k, t) in lay.props) if (k.startsWith(pre)) snap[k] = t.base
        snapMods = lay.pbrMaps["mbmods:$entry"]
        snapFx = lay.fx.toList()
    }

    // MARK: params

    private fun key(k: String) = "${entry}__$k"

    private fun valx(k: String): Float {
        val kk = key(k)
        lay.props[kk]?.let { return it.eval(lay.editTime(kk, Editor.time)) }
        return defs[k]?.def ?: 0f
    }

    private fun set(k: String, v: Float) {
        lay.track(key(k)).base = v; pv.requestDraw()
        if (k.startsWith("mbEs")) gizmo?.refresh()
    }

    private fun comp(k: String, s: String, d: Float): Float {
        val kk = "${key(k)}_$s"
        lay.props[kk]?.let { return it.eval(lay.editTime(kk, Editor.time)) }
        return d
    }

    private fun fmt(k: String, v: Float): String {
        if (k.length == 3 && k.startsWith("mb") && k.last().isDigit()) return String.format(Locale.US, "%.0f%%", v * 100f)
        if (k in listOf("mbDfSize", "mbDfGlow", "mbDfHi", "mbEsBlur")) return String.format(Locale.US, "%.2f%%", v)
        if (k in listOf("mbEsX", "mbEsY")) return String.format(Locale.US, "%.0f%%", v)
        if (k.startsWith("mbCa")) return String.format(Locale.US, "%+.3f", v)
        val d = defs[k]?.dec ?: 2
        return String.format(Locale.US, "%.${d}f", v)
    }

    // MARK: chain

    private var mods: List<String>
        get() = (lay.pbrMaps["mbmods:$entry"] ?: "").split(",").filter { id -> mblTools.any { it.id == id } }
        set(v) { lay.pbrMaps["mbmods:$entry"] = v.joinToString(",") }

    private fun tool(id: String): MBLTool = mblTools.first { it.id == id }

    private fun addMod(id: String) {
        val m = mods.toMutableList()
        if (!m.contains(id)) {
            m.add(id)
            for ((k, _, v) in tool(id).vals) set(k, v)
        }
        mods = m; curTool = id; pv.requestDraw(); showTab()
    }

    private fun removeMod(id: String) {
        mods = mods.filter { it != id }
        for ((k, n, _) in tool(id).vals) set(k, n)
        if (id == "curves") { for (ch in looksCurveChannels) for (i in 0 until 7) set("mbCv$ch$i", i.toFloat() / 6f) }
        if (curTool == id) curTool = mods.lastOrNull()
        pv.requestDraw(); showTab()
    }

    // MARK: layout (manual frames: bar / preview box / bottom intensity + chain / body scroll)

    private val bar = UiView(appContext!!)
    private val box = UiView(appContext!!)
    private val bottom = UiView(appContext!!)
    private val bodyScroll = UIScrollView(appContext!!)
    private val body = UiView(appContext!!)
    private val chainScroll = UIScrollView(appContext!!)
    private val chainStack = UiView(appContext!!)
    private val titleL = UILabel(appContext!!)
    private val holdBtn = PillButton("Hold: before", null, 0x99000000.toInt(), C.TEXT)
    private val toolsBtn = PillButton("＋ Tools", null, 0xFFF5A623.toInt(), 0xFF000000.toInt())
    private val presetsBtn = PillButton("Presets", null, 0xFF404040.toInt(), C.TEXT)
    private val closeBtn = PillButton("✕", null, C.CARD2, C.TEXT)
    private val okBtn = PillButton("✓", null, 0xFFF5A623.toInt(), 0xFF000000.toInt())
    private val orderL = PillButton("‹", null, C.CARD2, C.DIM)
    private val orderR = PillButton("›", null, C.CARD2, C.DIM)
    private var intenRow: UiView? = null

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(0xFF121212.toInt())
        titleL.text = "MAGIC BULLET LOOKS"
        titleL.font = UIFont.boldSystemFont(13f); titleL.textColor = UIColor(0xFFD9D9D9.toInt())
        titleL.textAlignment = NSTextAlignment.center
        closeBtn.onClick = { finish(apply = false) }
        okBtn.onClick = { finish(apply = true) }
        orderL.onClick = { moveInStack(-1) }
        orderR.onClick = { moveInStack(1) }
        toolsBtn.onClick = { showPicker(null) }
        presetsBtn.onClick = { showPicker("Presets") }
        view.addSubview(bar); view.addSubview(box); view.addSubview(bottom); view.addSubview(bodyScroll)
        bar.addSubview(closeBtn); bar.addSubview(orderL); bar.addSubview(orderR); bar.addSubview(titleL); bar.addSubview(okBtn)
        box.addSubview(pv)
        val gz = MBLGizmoView(appContext!!)
        gz.owner = this
        pv.addSubview(gz); gizmo = gz
        box.addSubview(holdBtn)
        // Hold: before — press toggles the hold (touch-down/up pair on iOS)
        holdBtn.onClick = {
            if (holdInt == null) { holdInt = valx("mbInt"); set("mbInt", 0f) } else { set("mbInt", holdInt!!); holdInt = null }
        }
        bottom.addSubview(chainScroll)
        chainScroll.addSubview(chainStack)
        intenRow = sliderRow("Intensity", "mbInt", pct = true)
        intenRow?.let { bottom.addSubview(it) }
        bottom.addSubview(presetsBtn); bottom.addSubview(toolsBtn)
        bodyScroll.addSubview(body)
        pv.setBackgroundColor(0xFF000000.toInt())
        curTool = mods.lastOrNull()
        updateLayoutMode(); showTab(); updateOrderButtons()
    }

    private fun relayout() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w < 10 || h < 10) return
        val land = w > h
        if (isLandscapeLayout != land) { isLandscapeLayout = land }
        bar.frame = CGRect(0f, 0f, w, 44f)
        closeBtn.frame = CGRect(14f, 6f, 32f, 32f)
        okBtn.frame = CGRect(w - 46f, 6f, 32f, 32f)
        orderR.frame = CGRect(w - 88f, 6f, 32f, 32f)
        orderL.frame = CGRect(w - 124f, 6f, 32f, 32f)
        titleL.frame = CGRect(60f, 9f, w - 190f, 26f)
        if (land) {
            box.frame = CGRect(0f, 44f, w * 0.5f, h - 44f)
            bottom.frame = CGRect(box.frame.maxX, h - 110f, w - box.frame.width, 110f)
            bodyScroll.frame = CGRect(box.frame.maxX, 44f, w - box.frame.width, h - 44f - 110f)
        } else {
            box.frame = CGRect(0f, 44f, w, h * 0.34f)
            bottom.frame = CGRect(0f, h - 110f, w, 110f)
            bodyScroll.frame = CGRect(0f, box.frame.maxY, w, h - box.frame.maxY - 110f)
        }
        // preview: fill the box as far as the aspect ratio allows
        val aspect = max(Editor.project.w, 1).toFloat() / max(Editor.project.h, 1).toFloat()
        var pw = box.rectWidth(); var ph = pw / aspect
        if (ph > box.rectHeight()) { ph = box.rectHeight(); pw = ph * aspect }
        pv.frame = CGRect((box.rectWidth() - pw) / 2, (box.rectHeight() - ph) / 2, pw, ph)
        gzFrame()
        holdBtn.frame = CGRect(box.rectWidth() - 118f, box.rectHeight() - 40f, 108f, 26f)
        // bottom: intensity row + tool chain
        intenRow?.let { it.frame = CGRect(14f, 8f, bottom.rectWidth() - 28f, 36f) }
        presetsBtn.frame = CGRect(14f, 50f, 96f, 30f)
        toolsBtn.frame = CGRect(118f, 50f, 96f, 30f)
        chainScroll.frame = CGRect(0f, 84f, bottom.rectWidth(), bottom.rectHeight() - 86f)
        layoutChain()
        // body
        var y = 10f
        for (v in body.subviews) {
            val hgt = v.rectHeight().takeIf { it > 0f } ?: 40f
            v.frame = CGRect(16f, y, max(bodyScroll.rectWidth() - 32f, 10f), hgt)
            y += hgt + 14f
        }
        body.frame = CGRect(0f, 0f, bodyScroll.rectWidth(), y + 24f)
        bodyScroll.contentSize = CGSize(bodyScroll.rectWidth(), y + 24f)
    }

    private fun gzFrame() {
        gizmo?.frame = CGRect(0f, 0f, pv.rectWidth(), pv.rectHeight())
    }

    private fun layoutChain() {
        var x = 14f
        val hh = chainScroll.rectHeight()
        for (v in chainStack.subviews) {
            val w = v.rectWidth().takeIf { it > 0f } ?: 60f
            v.frame = CGRect(x, 0f, w, hh)
            x += w + 14f
        }
        chainStack.frame = CGRect(0f, 0f, max(x, chainScroll.rectWidth()), hh)
        chainScroll.contentSize = CGSize(max(x, chainScroll.rectWidth()), hh)
    }

    private fun updateLayoutMode() { relayout() }

    override fun viewDidLayoutSubviews() { super.viewDidLayoutSubviews(); updateLayoutMode(); gzFrame(); pv.requestDraw() }
    override fun viewDidAppear(animated: Boolean) { super.viewDidAppear(animated); pv.requestDraw() }

    // MARK: chain strip

    private fun card(id: String): UiView {
        val t = tool(id)
        val on = curTool == id
        val w = UiView(appContext!!)
        w.frame = CGRect(0f, 0f, 60f, 76f)
        val b = object : TapView() {
            public override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                c.canvas.drawBitmap(mblIcon(id, 60f).bitmap, null, android.graphics.RectF(0f, 0f, rect.width, rect.height),
                    android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                if (on) strokeRoundRect(c, CGRect(0.5f, 0.5f, rect.width - 1f, rect.height - 1f), 8f, 2.5f, 0xFFF5A623.toInt())
            }
        }
        b.onClick = { curTool = id; showTab() }
        b.frame = CGRect(0f, 0f, 60f, 60f)
        b.clipsToBounds = true
        val x = PillButton("✕", null, if (on) C.GREEN else C.CARD2, if (on) C.BG else C.DIM)
        x.onClick = { removeMod(id) }
        x.frame = CGRect(38f, 0f, 24f, 24f)
        val l = UILabel(appContext!!)
        l.text = t.name; l.font = UIFont.systemFont(9f); l.textColor = if (on) UIColor.white else UIColor(0xFF999999.toInt())
        l.textAlignment = NSTextAlignment.center
        l.frame = CGRect(0f, 62f, 60f, 14f)
        w.addSubview(b); w.addSubview(x); w.addSubview(l)
        return w
    }

    private fun group(cat: String): UiView {
        val ids = mods.filter { tool(it).cat == cat }
        val col = UiView(appContext!!)
        val row = UiView(appContext!!)
        row.frame = CGRect(0f, 0f, 60f, 60f)
        var x = 0f
        if (ids.isEmpty()) {
            val e = UiView(appContext!!)
            e.setBackgroundColor(0xFF212121.toInt())
            e.frame = CGRect(0f, 0f, 60f, 60f)
            row.addSubview(e)
        } else for (id in ids) { val c = card(id); row.addSubview(c); c.frame = CGRect(x, 0f, 60f, 76f); x += 68f }
        row.frame = CGRect(0f, 0f, max(x, 60f), 76f)
        val lab = PillButton(cat, null, 0xFF292929.toInt(), 0xFFBFBFBF.toInt())
        lab.textSize = 11f
        lab.onClick = { showPicker(cat) }
        lab.frame = CGRect(0f, 78f, max(max(x, 60f), 74f), 22f)
        col.addSubview(row); col.addSubview(lab)
        col.frame = CGRect(0f, 0f, max(max(x, 60f), 74f), 102f)
        return col
    }

    private fun showTab() {
        gizmo?.refresh()
        chainStack.subviews.toList().forEach { it.removeFromSuperview() }
        for (c in mblCats) chainStack.addSubview(group(c))
        layoutChain()
        body.subviews.toList().forEach { it.removeFromSuperview() }
        val id = curTool
        if (id == null || !mods.contains(id)) {
            val l = UILabel(appContext!!)
            l.numberOfLines = 0; l.textColor = UIColor(0xFF8C8C8C.toInt()); l.font = UIFont.systemFont(14f)
            l.text = "No tool selected.\nTap ＋ Tools (or a category) and pick an effect. Nothing changes until you add one."
            l.frame = CGRect(0f, 0f, 100f, 64f)
            body.addSubview(l)
            relayout()
            return
        }
        val t = tool(id)
        val h = UILabel(appContext!!)
        h.text = t.name; h.font = UIFont.boldSystemFont(17f); h.textColor = UIColor.white
        h.frame = CGRect(0f, 0f, 200f, 26f)
        body.addSubview(h)
        val rs = PillButton("↺ Reset", null, C.CARD2, 0xFFF5A623.toInt())
        rs.onClick = {
            for ((k, _, v) in t.vals) set(k, v)
            if (id == "curves") { for (ch in looksCurveChannels) for (i in 0 until 7) set("mbCv$ch$i", i.toFloat() / 6f) }
            showTab()
        }
        rs.frame = CGRect(0f, 0f, 90f, 28f)
        body.addSubview(rs)
        if (id == "hazeflare") hazeFlarePanel()
        else if (id == "curves") curvesPanel()
        else if (id == "hsl") hslWheelPanel()
        else if (id == "colorista") coloristaPanel()
        else {
            for ((n, k) in t.sliders) body.addSubview(sliderRow(n, k))
            for ((n, k) in t.colors) body.addSubview(colorRow(n, k))
        }
        relayout()
    }

    // MARK: panels

    private fun curvesPanel() {
        val names = listOf(Triple("M", "RGB", 0xFFFFFFFF.toInt()), Triple("R", "Red", 0xFFFF4C4C.toInt()),
            Triple("G", "Green", 0xFF4CF2F2.toInt()), Triple("B", "Blue", 0xFF6699FF.toInt()))
        val row = UiView(appContext!!)
        row.frame = CGRect(0f, 0f, 100f, 32f)
        for ((id, n, _) in names) row.addSubview(chipBtn(n, curveCh == id, 0xFF2E2E2E.toInt()) { curveCh = id; showTab() })
        row.onLayout = { w ->
            val cw = (w - 24f) / 4f
            for ((i, v) in row.subviews.withIndex()) v.frame = CGRect(i * (cw + 8f), 0f, cw, 32f)
        }
        body.addSubview(row)
        val ch = curveCh
        val g = LooksCurveGraphView(appContext!!)
        g.color = names.firstOrNull { it.first == ch }?.third ?: C.TEXT
        g.values = (0 until 7).map { valx("mbCv$ch$it") }.toFloatArray()
        g.onChange = { i, v -> set("mbCv$ch$i", v) }
        g.frame = CGRect(0f, 0f, 100f, 260f)
        body.addSubview(g)
        body.addSubview(sliderRow("Amount", "mbCurvAmt", pct = true))
    }

    private fun hslPanel() {
        val cols = listOf(0xFFFF0000.toInt(), 0xFFFF9500.toInt(), 0xFFFFFF00.toInt(), 0xFF34C759.toInt(), 0xFF00C7BE.toInt(), 0xFF0A84FF.toInt(), 0xFFBF5AF2.toInt(), 0xFFFF2D92.toInt())
        val dots = UiView(appContext!!)
        dots.frame = CGRect(0f, 0f, 100f, 32f)
        for (i in 0 until 8) {
            val b = object : TapView() {
                public override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    fillRoundRect(c, rect, 16f, cols[i])
                    if (i == hslIdx) strokeRoundRect(c, rect.insetBy(1f, 1f), 16f, 3f, 0xFFFFFFFF.toInt())
                }
            }
            b.onClick = { hslIdx = i; showTab() }
            dots.addSubview(b)
        }
        dots.onLayout = { w ->
            val cw = (w - 70f) / 8f
            for ((i, v) in dots.subviews.withIndex()) v.frame = CGRect(10f + i * (cw + 10f), 0f, cw, 32f)
        }
        body.addSubview(dots)
        val n = UILabel(appContext!!)
        n.text = mblHslNames[hslIdx]; n.textColor = UIColor(0xFFB3B3B3.toInt()); n.font = UIFont.boldSystemFont(12f)
        n.frame = CGRect(0f, 0f, 200f, 20f)
        body.addSubview(n)
        body.addSubview(sliderRow("Hue", "mbH$hslIdx"))
        body.addSubview(sliderRow("Saturation", "mbS$hslIdx"))
        body.addSubview(sliderRow("Lightness", "mbL$hslIdx"))
    }

    /** MBLExtras.swift hslWheelPanel — the double-wheel UI with the value table. */
    private fun hslWheelPanel() {
        val w1 = MBLHSLWheel(appContext!!, MBLHSLWheel.Mode.sat)
        val w2 = MBLHSLWheel(appContext!!, MBLHSLWheel.Mode.light)
        fun cap(t: String): UILabel {
            val l = UILabel(appContext!!)
            l.text = t; l.font = UIFont.boldSystemFont(11f); l.textColor = UIColor(0xFFB3B3B3.toInt())
            l.textAlignment = NSTextAlignment.center
            l.frame = CGRect(0f, 0f, 100f, 16f)
            return l
        }
        val table = UiView(appContext!!)
        val cells = Array(8) { arrayOfNulls<UILabel>(3) }
        val rowViews = ArrayList<UiView>()
        fun pct(v: Float): String = String.format(Locale.US, "%.0f%%", v * 100f)
        fun refresh() {
            for (w in listOf(w1, w2)) {
                w.hue = FloatArray(8) { valx("mbH$it") }
                w.sel = hslIdx
                w.value = FloatArray(8) { valx((if (w.mode == MBLHSLWheel.Mode.sat) "mbS" else "mbL") + "$it") }
                w.setNeedsDisplay()
            }
            for (i in 0 until 8) {
                cells[i][0]?.text = pct(valx("mbH$i")); cells[i][1]?.text = pct(valx("mbS$i")); cells[i][2]?.text = pct(valx("mbL$i"))
                rowViews[i].setBackgroundColor(if (i == hslIdx) 0xFF333333.toInt() else 0x00000000)
            }
        }
        val hdr = UiView(appContext!!)
        hdr.addSubview(cap("Hue")); hdr.addSubview(cap("Saturation")); hdr.addSubview(cap("Lightness"))
        hdr.frame = CGRect(0f, 0f, 100f, 18f)
        table.addSubview(hdr)
        for (i in 0 until 8) {
            val row = UiView(appContext!!)
            row.frame = CGRect(0f, 0f, 100f, 26f)
            val dot = object : TapView() {
                public override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    val col = UIColor.hsv(mblHslHue[i] / 360f, 1f, 1f, 1f)
                    fillRoundRect(c, rect, 5f, col.toInt())
                }
            }
            dot.frame = CGRect(8f, 8f, 10f, 10f)
            row.addSubview(dot)
            for (j in 0 until 3) {
                val l = UILabel(appContext!!)
                l.font = UIFont.monospacedDigitSystemFont(12f); l.textColor = UIColor.white; l.textAlignment = NSTextAlignment.center
                row.addSubview(l)
                cells[i][j] = l
            }
            row.onClick = { hslIdx = i; refresh() }
            rowViews.add(row)
            table.addSubview(row)
        }
        table.onLayout = { tw ->
            hdr.frame = CGRect(0f, 0f, tw, 18f)
            var y = 18f
            val cw = (tw - 60f) / 3f
            for (r in rowViews) {
                r.frame = CGRect(0f, y, tw, 26f)
                var x = 60f
                for (sub in r.subviews) {
                    if (sub is UILabel) { sub.frame = CGRect(x, 3f, cw, 20f); x += cw }
                }
                y += 26f
            }
        }
        for (w in listOf(w1, w2)) {
            w.onSelect = { i -> hslIdx = i; refresh() }
            w.onChange = { i, dh, v ->
                set("mbH$i", dh)
                set((if (w.mode == MBLHSLWheel.Mode.sat) "mbS" else "mbL") + "$i", v)
                refresh()
            }
        }
        val wheels = UiView(appContext!!)
        // == iOS MBLExtras.swift:244-245: each wheel carries its "Hue / Saturation" / "Hue / Lightness" caption
        val cap1 = cap("Hue / Saturation")
        val cap2 = cap("Hue / Lightness")
        wheels.addSubview(cap1); wheels.addSubview(cap2)
        wheels.addSubview(w1); wheels.addSubview(w2)
        wheels.frame = CGRect(0f, 0f, 100f, 200f)
        wheels.onLayout = { ww ->
            val cw = (ww - 14f) / 2f
            cap1.frame = CGRect(0f, 0f, cw, 16f)
            cap2.frame = CGRect(cw + 14f, 0f, cw, 16f)
            w1.frame = CGRect(0f, 20f, cw, cw)
            w2.frame = CGRect(cw + 14f, 20f, cw, cw)
            wheels.frame = CGRect(0f, 0f, ww, cw + 20f)
        }
        body.addSubview(wheels)
        body.addSubview(table)
        refresh()
    }

    /** MBLExtras.swift coloristaPanel — 3-way wheels. */
    private fun coloristaPanel() {
        val pre = PillButton("Preset: None  ▾", null, C.CARD2, 0xFFF5A623.toInt())
        pre.onClick = {
            val items = listOf("None" to emptyMap<String, Float>(),
                "Teal & Orange" to mapOf("mbCoSx" to -0.4f, "mbCoHx" to 0.35f, "mbCoHy" to 0.2f),
                "Warm Skin" to mapOf("mbCoMx" to 0.15f, "mbCoMy" to 0.05f, "mbCoHx" to 0.2f, "mbCoHy" to 0.1f),
                "Cool Night" to mapOf("mbCoSx" to -0.2f, "mbCoSy" to -0.3f, "mbCoMx" to -0.1f, "mbCoMy" to -0.1f, "mbCoExp" to -0.2f),
                "Faded" to mapOf("mbCoSl" to 0.3f, "mbCoSat" to 0.8f))
            Dlg(this).setTitle("Preset").setItems(items.map { it.first }) { _, i ->
                val (_, vv) = items[i]
                for ((k, d, _) in tool("colorista").vals) if (k != "mbCo") set(k, d)
                for ((k, v) in vv) set(k, v)
                showTab()
            }.show()
        }
        pre.frame = CGRect(0f, 0f, 180f, 30f)
        body.addSubview(pre)
        body.addSubview(sliderRow("Exposure", "mbCoExp"))
        fun col(title: String, r: String): UiView {
            val t = UILabel(appContext!!)
            t.text = title; t.font = UIFont.boldSystemFont(12f); t.textColor = UIColor(0xFFCCCCCC.toInt())
            t.textAlignment = NSTextAlignment.center
            t.frame = CGRect(0f, 0f, 100f, 16f)
            val w = MBLWheelView(appContext!!)
            w.puckX = valx("mbCo${r}x"); w.puckY = valx("mbCo${r}y")
            w.onChange = { x, y -> set("mbCo${r}x", x); set("mbCo${r}y", y) }
            w.frame = CGRect(0f, 0f, 100f, 140f)
            val c = UiView(appContext!!)
            val lr = sliderRow("Luma", "mbCo${r}l")
            c.addSubview(t); c.addSubview(w); c.addSubview(lr)
            c.frame = CGRect(0f, 0f, 100f, 210f)
            c.onLayout = { cw ->
                t.frame = CGRect(0f, 0f, cw, 16f)
                w.frame = CGRect((cw - 140f) / 2, 18f, 140f, 140f)
                lr.frame = CGRect(0f, 162f, cw, 44f)
            }
            return c
        }
        body.addSubview(col("Midtones", "M"))
        body.addSubview(col("Shadows", "S"))
        body.addSubview(col("Highlights", "H"))
        body.addSubview(sliderRow("Saturation", "mbCoSat"))
        body.addSubview(sliderRow("Strength", "mbCoStr"))
    }

    /** MBLExtras.swift setTint. */
    private fun setTint(k: String, r: Float, g: Float, b: Float) {
        lay.track(key(k) + "_r").base = r
        lay.track(key(k) + "_g").base = g
        lay.track(key(k) + "_b").base = b
        lay.track(key(k) + "_a").base = 1f
        pv.requestDraw()
    }

    /** MBLExtras.swift hazeFlarePanel — preset popup, value rows, Reflection toggle, Tint Color wheel + RGB. */
    private fun hazeFlarePanel() {
        val dim = 0xFF9E9E9E.toInt()
        val curP = valx("mbHfPre").toInt()
        val pre = PillButton(mblHazePresets[min(max(curP, 0), mblHazePresets.size - 1)].name + "  ▾", null, 0xFF292929.toInt(), C.TEXT)
        pre.textSize = 13f
        pre.onClick = {
            Dlg(this).setTitle("Preset").setItems(mblHazePresets.map { it.name }) { _, i ->
                set("mbHfPre", i.toFloat())
                if (i > 0) {
                    for ((k, v) in mblHazePresets[i].v) set(k, v)
                    val t = mblHazePresets[i].tint
                    setTint("mbHfC", t.first, t.second, t.third)
                }
                showTab()
            }.show()
        }
        pre.frame = CGRect(0f, 0f, 200f, 30f)
        val pl = UILabel(appContext!!)
        pl.text = "Preset:"; pl.font = UIFont.systemFont(13f); pl.textColor = UIColor(dim)
        val prow = UiView(appContext!!)
        prow.addSubview(pl); prow.addSubview(pre)
        prow.frame = CGRect(0f, 0f, 100f, 30f)
        prow.onLayout = { w -> pl.frame = CGRect(0f, 7f, 60f, 18f); pre.frame = CGRect(66f, 0f, min(200f, w - 66f), 30f) }
        body.addSubview(prow)

        fun row(title: String, k: String, pct: Boolean) {
            val pd = defs[k] ?: return
            val t = UILabel(appContext!!)
            t.text = "$title:"; t.font = UIFont.systemFont(13f); t.textColor = UIColor(dim)
            t.frame = CGRect(0f, 0f, 128f, 18f)
            val v = UILabel(appContext!!)
            v.font = UIFont.monospacedDigitSystemFont(13f); v.textColor = UIColor.white; v.textAlignment = NSTextAlignment.right
            v.frame = CGRect(0f, 0f, 62f, 18f)
            val s = UISlider(appContext!!)
            s.minValue = pd.min; s.maxValue = pd.max; s.value = valx(k)
            fun show(x: Float): String = if (pct) String.format(Locale.US, "%.1f%%", x) else String.format(Locale.US, "%.2f", x)
            v.text = show(s.value)
            s.onValueChanged = { x -> set(k, x); set("mbHfPre", 0f); v.text = show(x) }
            val r = UiView(appContext!!)
            r.addSubview(t); r.addSubview(s); r.addSubview(v)
            r.frame = CGRect(0f, 0f, 100f, 36f)
            r.onLayout = { w ->
                t.frame = CGRect(0f, 9f, 128f, 18f)
                s.frame = CGRect(132f, 0f, w - 132f - 66f, 36f)
                v.frame = CGRect(w - 62f, 9f, 62f, 18f)
            }
            body.addSubview(r)
        }
        row("Spillage", "mbHfSp", true); row("Softness", "mbHfSo", true); row("Reach", "mbHfRe", true)
        row("Exposure", "mbHfEx", false); row("Reflection Exposure", "mbHfRx", false)

        // Reflection: On / Off check button
        val rl = UILabel(appContext!!)
        rl.text = "Reflection:"; rl.font = UIFont.systemFont(13f); rl.textColor = UIColor(dim)
        rl.frame = CGRect(0f, 0f, 128f, 18f)
        val tg = PillButton("", null, 0xFF292929.toInt(), C.TEXT)
        tg.textSize = 13f
        fun upd() { tg.text = if (valx("mbHfRf") > 0.5f) "✓ On" else "Off" }
        upd()
        tg.onClick = { set("mbHfRf", if (valx("mbHfRf") > 0.5f) 0f else 1f); set("mbHfPre", 0f); upd() }
        val trow = UiView(appContext!!)
        trow.addSubview(rl); trow.addSubview(tg)
        trow.frame = CGRect(0f, 0f, 100f, 30f)
        trow.onLayout = { w -> rl.frame = CGRect(0f, 7f, 128f, 18f); tg.frame = CGRect(132f, 0f, 90f, 30f) }
        body.addSubview(trow)

        row("Matte Box Size", "mbHfBx", true); row("Matte Box Shade", "mbHfSh", true)

        // Tint Color: wheel + RGB read-out
        val tl = UILabel(appContext!!)
        tl.text = "Tint Color"; tl.font = UIFont.boldSystemFont(13f); tl.textColor = UIColor.white
        tl.frame = CGRect(0f, 0f, 200f, 20f)
        body.addSubview(tl)
        val wheel = MBLTintWheel(appContext!!)
        wheel.rgb = Triple(comp("mbHfC", "r", 0.226f), comp("mbHfC", "g", 0.181f), comp("mbHfC", "b", 1.0f))
        wheel.frame = CGRect(0f, 0f, 130f, 130f)
        fun readout(n: String): UILabel {
            val l = UILabel(appContext!!)
            l.font = UIFont.monospacedDigitSystemFont(12f); l.textColor = UIColor.white; l.text = n
            l.frame = CGRect(0f, 0f, 120f, 16f)
            return l
        }
        val lr = readout(""); val lg = readout(""); val lb = readout("")
        fun refreshReadout(c: Triple<Float, Float, Float>) {
            lr.text = String.format(Locale.US, "R   %.3f", c.first)
            lg.text = String.format(Locale.US, "G   %.3f", c.second)
            lb.text = String.format(Locale.US, "B   %.3f", c.third)
        }
        refreshReadout(wheel.rgb)
        wheel.onChange = { r, g, b -> setTint("mbHfC", r, g, b); set("mbHfPre", 0f); refreshReadout(Triple(r, g, b)) }
        val rgbCol = UiView(appContext!!)
        rgbCol.addSubview(lr); rgbCol.addSubview(lg); rgbCol.addSubview(lb)
        rgbCol.frame = CGRect(0f, 0f, 120f, 60f)
        rgbCol.onLayout = { _ ->
            lr.frame = CGRect(0f, 8f, 120f, 16f); lg.frame = CGRect(0f, 26f, 120f, 16f); lb.frame = CGRect(0f, 44f, 120f, 16f)
        }
        val wr = UiView(appContext!!)
        wr.addSubview(wheel); wr.addSubview(rgbCol)
        wr.frame = CGRect(0f, 0f, 100f, 130f)
        wr.onLayout = { w ->
            val cw = (w - 130f - 36f) / 2
            wheel.frame = CGRect(cw, 0f, 130f, 130f)
            rgbCol.frame = CGRect(cw + 130f + 18f, 35f, 120f, 60f)
        }
        body.addSubview(wr)
    }

    /** MBLExtras.swift applyPreset. */
    fun applyPreset(p: MBLPreset) {
        for (id in mods) for ((k, n, _) in tool(id).vals) set(k, n)
        val v = mblResolve(p)
        mods = p.mods
        for (id in p.mods) for ((k, _, d) in tool(id).vals) set(k, v[k] ?: d)
        curTool = p.mods.firstOrNull()
        pv.requestDraw(); showTab()
    }

    // MARK: gizmo access (MBLGizmoView reads these)

    fun gizmoVal(k: String): Float = valx(k)
    fun gizmoSet(k: String, v: Float) { set(k, v) }
    fun gizmoCurTool(): String? = curTool
    fun gizmoMods(): List<String> = mods
    fun showTabPub() { showTab() }

    private fun sliderRow(title: String, k: String, pct: Boolean = false): UiView {
        val pd = defs[k] ?: return UiView(appContext!!).apply { frame = CGRect(0f, 0f, 10f, 1f) }
        val col = UiView(appContext!!)
        col.frame = CGRect(0f, 0f, 100f, if (pct) 40f else 62f)
        val t = UILabel(appContext!!)
        t.text = title; t.font = UIFont.systemFont(14f); t.textColor = UIColor.white
        val v = UILabel(appContext!!)
        v.font = UIFont.monospacedDigitSystemFont(13f); v.textColor = gold; v.textAlignment = NSTextAlignment.right
        val s = UISlider(appContext!!)
        s.minValue = pd.min; s.maxValue = pd.max
        s.value = valx(k)
        fun show(x: Float): String = if (pct) String.format(Locale.US, "%.0f%%", x * 100f) else fmt(k, x)
        v.text = show(s.value)
        s.onValueChanged = { x -> set(k, x); v.text = show(x) }
        col.addSubview(t); col.addSubview(v); col.addSubview(s)
        col.onLayout = { w ->
            if (pct) {
                t.frame = CGRect(0f, 9f, w * 0.5f, 22f)
                s.frame = CGRect(w * 0.5f - 40f, 2f, w * 0.5f + 20f, 36f)
                v.frame = CGRect(w - 58f, 9f, 58f, 22f)
            } else {
                t.frame = CGRect(0f, 0f, w * 0.6f, 22f)
                v.frame = CGRect(w * 0.6f, 0f, w * 0.4f, 22f)
                s.frame = CGRect(0f, 26f, w, 36f)
            }
        }
        return col
    }

    private fun colorRow(title: String, k: String): UiView {
        val cp = def?.colors?.firstOrNull { it.key == k }
        val u = (cp?.def ?: 0xFF808080.toInt())
        val w = UIColorWell(appContext!!)
        w.supportsAlpha = false; w.title = title
        w.selectedColor = UIColor.rgb(
            comp(k, "r", ((u shr 16) and 0xFF).toFloat() / 255f),
            comp(k, "g", ((u shr 8) and 0xFF).toFloat() / 255f),
            comp(k, "b", (u and 0xFF).toFloat() / 255f), 1f)
        w.onValueChanged = {
            val c = w.selectedColor.toInt()
            lay.track("${key(k)}_r").base = ((c ushr 16) and 0xFF).toFloat() / 255f
            lay.track("${key(k)}_g").base = ((c ushr 8) and 0xFF).toFloat() / 255f
            lay.track("${key(k)}_b").base = (c and 0xFF).toFloat() / 255f
            lay.track("${key(k)}_a").base = 1f
            pv.requestDraw()
        }
        val t = UILabel(appContext!!)
        t.text = title; t.font = UIFont.systemFont(14f); t.textColor = UIColor.white
        val row = UiView(appContext!!); row.frame = CGRect(0f, 0f, 100f, 40f)
        row.addSubview(t); row.addSubview(w)
        row.onLayout = { rw -> t.frame = CGRect(0f, 10f, rw - 56f, 20f); w.frame = CGRect(rw - 48f, 6f, 44f, 28f) }
        return row
    }

    private fun chipBtn(text: String, on: Boolean, offFill: Int, action: () -> Unit): PillButton {
        val b = PillButton(text, null, if (on) 0xFFF5A623.toInt() else offFill, if (on) 0xFF000000.toInt() else C.TEXT)
        b.onClick = action
        return b
    }

    // MARK: tools picker (icon grid + category tabs)

    private fun showPicker(cat: String?) {
        if (cat != null) pickCat = cat
        val vc = object : UIViewController() {
            override fun viewDidLoad() {
                super.viewDidLoad()
                view.setBackgroundColor(0xFF141414.toInt())
                val tabs = UiView(appContext!!)
                val grid = UIScrollView(appContext!!)
                val ttl = UILabel(appContext!!)
                ttl.text = "TOOLS"; ttl.font = UIFont.boldSystemFont(13f); ttl.textColor = UIColor.white
                ttl.textAlignment = NSTextAlignment.center
                view.addSubview(ttl); view.addSubview(tabs); view.addSubview(grid)
                fun layoutGrid(sc: UIScrollView) {
                    val w = view.rectWidth()
                    val cells = sc.subviews
                    var y = 8f
                    var i = 0
                    while (i < cells.size) {
                        var x = 16f
                        for (c in 0 until 3) {
                            if (i >= cells.size) break
                            cells[i].frame = CGRect(x, y, (w - 32f - 24f) / 3f, 128f)
                            for (sub in cells[i].subviews) {
                                if (sub is UILabel) sub.frame = CGRect(0f, 100f, cells[i].rectWidth(), 28f)
                                else sub.frame = CGRect(0f, 0f, cells[i].rectWidth(), 100f)
                            }
                            x += (w - 32f - 24f) / 3f + 12f
                            i++
                        }
                        y += 132f
                    }
                    sc.frame = CGRect(0f, 84f, w, view.rectHeight() - 84f)
                    sc.contentSize = CGSize(w, y + 24f)
                    sc.setNeedsDisplay()
                }
                fun fill() {
                    tabs.subviews.toList().forEach { it.removeFromSuperview() }
                    grid.subviews.toList().forEach { it.removeFromSuperview() }
                    val catList = mblCats + "Presets"
                    var x = 8f
                    for (c in catList) {
                        val b = PillButton(c, null, if (c == pickCat) 0xFFF5A623.toInt() else 0xFF232323.toInt(),
                            if (c == pickCat) 0xFF000000.toInt() else 0xFFA6A6A6.toInt())
                        b.textSize = 12f
                        b.onClick = { pickCat = c; fill() }
                        tabs.addSubview(b)
                        val bw = com.saiki.motion.uikit.measureText(c, 12f, true) + 28f
                        b.frame = CGRect(x, 0f, bw, 30f)
                        x += bw + 6f
                    }
                    tabs.frame = CGRect(0f, 44f, view.rectWidth(), 34f)
                    tabs.setNeedsDisplay()
                    if (pickCat == "Presets") { fillPresets(grid, this); layoutGrid(grid); return }
                    val list = mblTools.filter { it.cat == pickCat }
                    if (list.isEmpty()) {
                        val l = UILabel(appContext!!)
                        l.text = "More $pickCat tools are coming soon."
                        l.textColor = UIColor(0xFF808080.toInt()); l.font = UIFont.systemFont(14f)
                        l.frame = CGRect(16f, 8f, 280f, 30f)
                        grid.addSubview(l)
                        layoutGrid(grid); return
                    }
                    for (t in list) {
                        val cell = UiView(appContext!!)
                        cell.frame = CGRect(0f, 0f, 100f, 110f)
                        val b = object : TapView() {
                            public override fun draw(rect: CGRect) {
                                val c = UIGraphics.getCurrentContext() ?: return
                                c.canvas.drawBitmap(mblIcon(t.id, 96f).bitmap, null, android.graphics.RectF(0f, 0f, rect.width, rect.height),
                                    android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                                c.paint.alpha = if (mods.contains(t.id)) 100 else 255
                            }
                        }
                        b.onClick = { addMod(t.id); dismiss(animated = true) }
                        b.frame = CGRect(0f, 0f, 100f, 100f)
                        b.clipsToBounds = true
                        val l = UILabel(appContext!!)
                        l.text = t.name; l.font = UIFont.systemFont(11f); l.textColor = UIColor(0xFFBFBFBF.toInt())
                        l.textAlignment = NSTextAlignment.center; l.numberOfLines = 0
                        l.frame = CGRect(0f, 100f, 100f, 28f)
                        cell.addSubview(b); cell.addSubview(l)
                        cell.setBackgroundColor(0x00000000)
                        grid.addSubview(cell)
                    }
                    layoutGrid(grid)
                }
                ttl.frame = CGRect(0f, 16f, view.rectWidth(), 22f)
                fill()
                view.onLayout = { _ -> fill() }
            }
        }
        present(vc, animated = true)
    }

    private fun fillPresets(grid: UIScrollView, vc: UIViewController) {
        for (p in mblPresets) {
            val cell = UiView(appContext!!)
            val b = object : TapView() {
                public override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    val img = MBLThumbs.image(p)
                    c.canvas.drawBitmap(img.bitmap, null, android.graphics.RectF(0f, 0f, rect.width, rect.height),
                        android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                }
            }
            b.onClick = { applyPreset(p); vc.dismiss(animated = true) }
            b.frame = CGRect(0f, 0f, 100f, 74f)
            b.clipsToBounds = true
            val l = UILabel(appContext!!)
            l.text = p.name; l.font = UIFont.systemFont(11f); l.textColor = UIColor(0xFFBFBFBF.toInt())
            l.textAlignment = NSTextAlignment.center; l.numberOfLines = 0
            l.frame = CGRect(0f, 74f, 100f, 28f)
            cell.addSubview(b); cell.addSubview(l)
            grid.addSubview(cell)
        }
    }

    // MARK: finish

    private fun finish(apply: Boolean) {
        if (!apply) {
            val pre = "${entry}__"
            for (k in lay.props.keys.toList()) {
                if (!k.startsWith(pre)) continue
                val b = snap[k]
                if (b != null) lay.props[k]?.base = b else lay.props.remove(k)
            }
            val sm = snapMods
            if (sm != null) lay.pbrMaps["mbmods:$entry"] = sm else lay.pbrMaps.remove("mbmods:$entry")
            lay.fx = snapFx.toMutableList()
        }
        SceneRenderer.onVideoFrame = savedVideoCb
        val done = onDone
        dismiss(animated = true) { done() }
    }

    // MARK: layer order (move this Looks effect left / right in the layer's effect stack)

    fun moveInStack(d: Int) {
        val i = lay.fx.indexOf(entry)
        if (i < 0 || !lay.fx.indices.contains(i + d)) return
        java.util.Collections.swap(lay.fx, i, i + d)
        pv.requestDraw(); updateOrderButtons()
    }

    fun updateOrderButtons() {
        val i = lay.fx.indexOf(entry).takeIf { it >= 0 } ?: 0
        orderL.alpha = if (i > 0) 1f else 0.3f
        orderR.alpha = if (i < lay.fx.size - 1) 1f else 0.3f
    }

    companion object {
        /** MBLExtras.swift applyPreset keeps Source Point / Masking / Shape Mask sections (Shine); MBL resets all. */
        val hidden: Set<String> = emptySet()
    }
}

/** Tiny closure holder for gesture recognizers (iOS BlockTarget). */
class BlockTarget(val cb: () -> Unit) {
    fun fire() { cb() }
}
