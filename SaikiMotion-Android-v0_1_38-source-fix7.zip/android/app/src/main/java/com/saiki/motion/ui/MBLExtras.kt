@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/MBLExtras.swift — Magic Bullet Looks additions: Colourista 3-way wheels,
// HSL double-wheel UI, preset tab with thumbnails of the colour applied, the Haze/Flare tint wheel,
// and the Edge Softness on-screen gizmo. (The editor panel methods themselves are members of
// MBLEditorViewController in MBLEditor.kt.)

package com.saiki.motion.ui

import com.saiki.motion.core.mblHslHue
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UITapGestureRecognizer
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.UIGraphicsImageRenderer
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.fillRoundRect
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

// MARK: - Colourista wheel (puck on a hue ring; x/y in -1...1, y up)

class MBLWheelView(context: android.content.Context) : UiView(context) {
    var puckX: Float = 0f
        set(v) { field = v; setNeedsDisplay() }
    var puckY: Float = 0f
        set(v) { field = v; setNeedsDisplay() }
    var onChange: ((Float, Float) -> Unit)? = null

    init {
        setBackgroundColor(0x00000000)
        val t = UITapGestureRecognizer { puckX = 0f; puckY = 0f; setNeedsDisplay(); onChange?.invoke(0f, 0f) }
        t.numberOfTapsRequired = 2
        addGestureRecognizer(t)
    }

    public override fun draw(r: CGRect) {
        val g = UIGraphics.getCurrentContext() ?: return
        val c = CGPoint(boundsRect.midX, boundsRect.midY)
        val R = min(rectWidth(), rectHeight()) / 2 - 4
        val ringW = R * 0.17f
        for (i in 0 until 90) {
            val a0 = i.toFloat() / 90f * (Math.PI * 2).toFloat()
            val a1 = (i + 1.6f) / 90f * (Math.PI * 2).toFloat()
            val col = com.saiki.motion.uikit.UIColor.hsv(i.toFloat() / 90f, 0.85f, 0.95f, 1f)
            g.setStrokeColor(col.toInt()); g.setLineWidth(ringW)
            val p = com.saiki.motion.uikit.CGPath()
            p.addArc(c, R - ringW / 2, -a1, -a0, false)
            g.addPath(p.path); g.strokePath()
        }
        g.setFillColor(0xFF1A1A1A.toInt())
        val ir = R - ringW - 2
        g.fillEllipse(CGRect(c.x - ir, c.y - ir, 2 * ir, 2 * ir))
        g.setStrokeColor(0xFF4D4D4D.toInt()); g.setLineWidth(0.5f)
        g.beginPath()
        g.move(CGPoint(c.x - R * 0.7f, c.y)); g.addLine(CGPoint(c.x + R * 0.7f, c.y))
        g.move(CGPoint(c.x, c.y - R * 0.7f)); g.addLine(CGPoint(c.x, c.y + R * 0.7f))
        g.strokePath()
        val pr = R - ringW - 6
        val pt = CGPoint(c.x + puckX * pr, c.y - puckY * pr)
        g.setStrokeColor(0xFFFFFFFF.toInt()); g.setFillColor(0xFF1A1A1A.toInt())
        g.setLineWidth(2f)
        g.fillEllipse(CGRect(pt.x - 6, pt.y - 6, 12f, 12f))
        g.strokeEllipse(CGRect(pt.x - 6, pt.y - 6, 12f, 12f))
    }

    private fun move(t: UITouch) {
        val c = CGPoint(boundsRect.midX, boundsRect.midY)
        val R = min(rectWidth(), rectHeight()) / 2 - 4
        val pr = R - R * 0.17f - 6
        val l = t.location(this)
        var vx = (l.x - c.x) / pr
        var vy = -(l.y - c.y) / pr
        val n = hypot(vx, vy)
        if (n > 1) { vx /= n; vy /= n }
        puckX = vx; puckY = vy
        setNeedsDisplay(); onChange?.invoke(puckX, puckY)
    }

    override fun touchesBegan(t: Set<UITouch>, e: UIEvent?) { t.firstOrNull()?.let { move(it) } }
    override fun touchesMoved(t: Set<UITouch>, e: UIEvent?) { t.firstOrNull()?.let { move(it) } }
}

// MARK: - HSL wheel: 8 draggable dots. angle = hue shift, distance from centre = saturation / lightness (centre ring = 0)

class MBLHSLWheel(context: android.content.Context, val mode: Mode) : UiView(context) {
    enum class Mode { sat, light }

    var hue = FloatArray(8)
    var value = FloatArray(8)
    var sel = 0
    var onChange: ((Int, Float, Float) -> Unit)? = null
    var onSelect: ((Int) -> Unit)? = null

    init { setBackgroundColor(0x00000000) }

    private val R: Float get() = min(rectWidth(), rectHeight()) / 2 - 4

    private fun pos(i: Int): CGPoint {
        val a = (mblHslHue[i] + hue[i] * 30f - 90f) * Math.PI.toFloat() / 180f
        val rho = 0.09f + 0.91f * (0.5f + 0.5f * value[i])
        return CGPoint(boundsRect.midX + cos(a) * rho * R * 0.95f, boundsRect.midY + sin(a) * rho * R * 0.95f)
    }

    public override fun draw(r: CGRect) {
        val g = UIGraphics.getCurrentContext() ?: return
        val c = CGPoint(boundsRect.midX, boundsRect.midY)
        for (i in 0 until 72) {
            val a0 = i.toFloat() / 72f * (Math.PI * 2).toFloat() - (Math.PI / 2).toFloat()
            val a1 = (i + 1.3f) / 72f * (Math.PI * 2).toFloat() - (Math.PI / 2).toFloat()
            val col = com.saiki.motion.uikit.UIColor.hsv(i.toFloat() / 72f, 0.85f, if (mode == Mode.light) 0.75f else 0.9f, 1f)
            g.setFillColor(col.toInt())
            val p = com.saiki.motion.uikit.CGPath()
            p.move(c)
            p.addArc(c, R, a0, a1, true)
            g.addPath(p.path); g.fillPath()
        }
        // centre radial fade: sat -> grey ring edge fade, light -> dark centre
        g.saveGState()
        g.paint.shader = android.graphics.RadialGradient(c.x, c.y, R,
            if (mode == Mode.sat) 0xFF737373.toInt() else 0xE6000000.toInt(), 0x00000000, android.graphics.Shader.TileMode.CLAMP)
        g.fillEllipse(CGRect(c.x - R, c.y - R, 2 * R, 2 * R))
        g.restoreGState()
        g.setStrokeColor(0x99808080.toInt()); g.setLineWidth(0.5f)
        g.setLineDash(0f, floatArrayOf(3f, 3f))
        val midR = R * 0.95f * 0.545f
        g.strokeEllipse(CGRect(c.x - midR, c.y - midR, 2 * midR, 2 * midR))
        g.setLineDash(0f, FloatArray(0))
        for (i in 0 until 8) {
            val p = pos(i)
            val rad = if (i == sel) 6f else 4.5f
            g.setFillColor(com.saiki.motion.uikit.UIColor.hsv(mblHslHue[i] / 360f, 1f, 1f, 1f).toInt())
            g.setStrokeColor(if (i == sel) 0xFFFFFFFF.toInt() else 0xB3000000.toInt())
            g.setLineWidth(1.6f)
            g.fillEllipse(CGRect(p.x - rad, p.y - rad, 2 * rad, 2 * rad))
            g.strokeEllipse(CGRect(p.x - rad, p.y - rad, 2 * rad, 2 * rad))
        }
    }

    private var active = 0

    override fun touchesBegan(t: Set<UITouch>, e: UIEvent?) {
        val l = t.firstOrNull()?.location(this) ?: return
        active = (0 until 8).minByOrNull { hypot((pos(it).x - l.x).toDouble(), (pos(it).y - l.y).toDouble()) } ?: 0
        sel = active; onSelect?.invoke(active); move(l)
    }

    override fun touchesMoved(t: Set<UITouch>, e: UIEvent?) { t.firstOrNull()?.location(this)?.let { move(it) } }

    private fun move(l: CGPoint) {
        val dx = l.x - boundsRect.midX
        val dy = l.y - boundsRect.midY
        var deg = (atan2(dy, dx) * 180f / Math.PI.toFloat()) + 90f
        var d = deg - mblHslHue[active]
        while (d > 180) d -= 360
        while (d < -180) d += 360
        deg = max(-30f, min(30f, d)) / 30f
        val rho = hypot(dx, dy) / (R * 0.95f)
        val v = max(-1f, min(1f, (rho - 0.09f) / 0.91f * 2f - 1f))
        hue[active] = deg; value[active] = v
        setNeedsDisplay(); onChange?.invoke(active, deg, v)
    }
}

// MARK: - Presets

class MBLPreset(val name: String, val mods: List<String>, val v: Map<String, Float>)

val mblPresets: List<MBLPreset> = listOf(
    MBLPreset("Original", emptyList(), emptyMap()),
    MBLPreset("Teal & Orange", listOf("colorista", "mojo"), mapOf("mbCoSx" to -0.4f, "mbCoHx" to 0.35f, "mbCoHy" to 0.2f, "mbMjAmt" to 0.8f, "mbMjTO" to 0.6f)),
    MBLPreset("Warm Skin Glow", listOf("mojo", "exposure"), mapOf("mbMjAmt" to 0.7f, "mbMjWarm" to 0.4f, "mbMjTO" to 0f, "mbMjFade" to 0.1f, "mbMjSat" to 1.05f, "mbExpo" to 0.1f)),
    MBLPreset("Cool Night", listOf("colorista", "contrast"), mapOf("mbCoSx" to -0.2f, "mbCoSy" to -0.3f, "mbCoMx" to -0.1f, "mbCoMy" to -0.1f, "mbCoExp" to -0.2f, "mbCoSat" to 0.9f, "mbCon" to 0.2f)),
    MBLPreset("Faded Film", listOf("mojo"), mapOf("mbMjAmt" to 1f, "mbMjFade" to 0.5f, "mbMjCon" to -0.1f, "mbMjSat" to 0.85f, "mbMjWarm" to 0.15f, "mbMjTO" to 0.2f)),
    MBLPreset("Vivid Pop", listOf("huesat", "contrast"), mapOf("mbSat" to 1.4f, "mbCon" to 0.25f)),
    MBLPreset("Pastel Anime", listOf("colorista", "mojo"), mapOf("mbCoHx" to 0.2f, "mbCoHy" to 0.1f, "mbCoSat" to 1.1f, "mbCoExp" to 0.2f, "mbMjAmt" to 0.8f, "mbMjFade" to 0.25f, "mbMjCon" to -0.15f, "mbMjSat" to 1f, "mbMjTO" to 0f)),
    MBLPreset("Moody Teal", listOf("colorista"), mapOf("mbCoSx" to -0.45f, "mbCoSy" to -0.1f, "mbCoMx" to -0.2f, "mbCoHx" to 0.1f, "mbCoHy" to 0.05f, "mbCoSat" to 0.85f, "mbCoSl" to -0.1f)),
    MBLPreset("Golden Hour", listOf("warmcool", "colorista", "contrast"), mapOf("mbWarm" to 0.5f, "mbCoHx" to 0.3f, "mbCoHy" to 0.15f, "mbCoExp" to 0.15f, "mbCon" to 0.15f)),
)

/** Parameter values a preset results in (tool "added" defaults, then the preset's overrides). */
fun mblResolve(p: MBLPreset): Map<String, Float> {
    val d = HashMap<String, Float>()
    for (id in p.mods) {
        val t = mblTools.firstOrNull { it.id == id } ?: continue
        for ((k, _, v) in t.vals) d[k] = v
    }
    for ((k, v) in p.v) d[k] = v
    return d
}

/** CPU port of the shader maths (Exposure, Warm/Cool, Contrast, Saturation, Colourista, Mojo II) for the thumbnails. */
private fun mblApply(v: Map<String, Float>, c0: FloatArray): FloatArray {
    fun g(k: String, d: Float = 0f): Float = v[k] ?: d
    fun ss(a: Float, b: Float, x: Float): Float { val t = max(0f, min(1f, (x - a) / (b - a))); return t * t * (3 - 2 * t) }
    fun lum(c: FloatArray, w: FloatArray): Float = c[0] * w[0] + c[1] * w[1] + c[2] * w[2]
    fun off(x: Float, y: Float): FloatArray = floatArrayOf(x, -0.5f * x + 0.866f * y, -0.5f * x - 0.866f * y)
    fun exp2(x: Float): Float = 2f.pow(x)
    var c = c0.copyOf()
    for (i in 0 until 3) c[i] *= exp2(g("mbExpo"))
    val w = g("mbWarm")
    c[0] *= exp2(-w * 0.5f) * exp2(-w * 0.25f); c[1] *= exp2(w * 0.5f); c[2] *= exp2(w * 0.25f)
    val pv = g("mbConPiv", 0.18f)
    for (i in 0 until 3) c[i] = (c[i] - pv) * (1 + g("mbCon")) + pv
    val sat = g("mbSat", 1f)
    val l0 = lum(c, floatArrayOf(0.299f, 0.587f, 0.114f))
    for (i in 0 until 3) c[i] = l0 + (c[i] - l0) * sat
    if (g("mbCo") > 0.5f) {
        val co0 = c.copyOf()
        val cl = lum(c, floatArrayOf(0.2126f, 0.7152f, 0.0722f))
        val wS = 1 - ss(0f, 0.5f, cl); val wH = ss(0.5f, 1f, cl); val wM = max(0f, min(1f, 1 - wS - wH))
        for (i in 0 until 3) c[i] *= exp2(g("mbCoExp"))
        val oS = off(g("mbCoSx"), g("mbCoSy")); val oM = off(g("mbCoMx"), g("mbCoMy")); val oH = off(g("mbCoHx"), g("mbCoHy"))
        for (i in 0 until 3) c[i] += wS * (oS[i] + g("mbCoSl")) * 0.3f
        for (i in 0 until 3) c[i] *= 1 + wM * (oM[i] + g("mbCoMl")) * 0.8f
        for (i in 0 until 3) c[i] *= 1 + wH * (oH[i] + g("mbCoHl")) * 0.8f
        val l2 = lum(c, floatArrayOf(0.2126f, 0.7152f, 0.0722f))
        for (i in 0 until 3) c[i] = l2 + (c[i] - l2) * g("mbCoSat", 1f)
        val s = g("mbCoStr", 1f)
        for (i in 0 until 3) c[i] = co0[i] + (c[i] - co0[i]) * s
    }
    if (g("mbMj") > 0.5f) {
        val m0 = c.copyOf()
        val ml = lum(c, floatArrayOf(0.299f, 0.587f, 0.114f))
        val to = g("mbMjTO")
        val lo = floatArrayOf(-0.05f, 0.03f, 0.06f); val hi = floatArrayOf(0.07f, 0.02f, -0.06f)
        for (i in 0 until 3) c[i] += to * (lo[i] * (1 - ss(0f, 0.6f, ml)) + hi[i] * ss(0.4f, 1f, ml))
        val wm = g("mbMjWarm")
        c[0] *= exp2(wm * 0.2f); c[2] *= exp2(-wm * 0.2f)
        for (i in 0 until 3) c[i] = (c[i] - 0.18f) * (1 + g("mbMjCon") * 0.6f) + 0.18f
        val l2 = lum(c, floatArrayOf(0.299f, 0.587f, 0.114f))
        for (i in 0 until 3) c[i] = l2 + (c[i] - l2) * g("mbMjSat", 1f)
        val f = g("mbMjFade")
        for (i in 0 until 3) c[i] = c[i] * (1 - f * 0.3f) + f * 0.08f
        for (i in 0 until 3) c[i] = m0[i] + (c[i] - m0[i]) * g("mbMjAmt")
    }
    return floatArrayOf(max(0f, min(1f, c[0])), max(0f, min(1f, c[1])), max(0f, min(1f, c[2])))
}

object MBLThumbs {
    private var base: Triple<Int, Int, IntArray>? = null
    private val cache = HashMap<String, UIImage>()
    private val lock = Object()

    private fun loadBase(): Triple<Int, Int, IntArray>? {
        synchronized(lock) {
            base?.let { return it }
            val names = listOf("fx_girl", "anime_portrait", "fx_woman")
            var img: android.graphics.Bitmap? = null
            for (n in names) {
                val id = appContext!!.resources.getIdentifier(n, "drawable", appContext!!.packageName)
                if (id != 0) { img = android.graphics.BitmapFactory.decodeResource(appContext!!.resources, id); if (img != null) break }
            }
            if (img == null) {
                // shared/resources/img carries the sample jpgs (iOS bundle twins)
                for (n in names) {
                    val f = java.io.File(com.saiki.motion.core.Paths.root, "../img/$n.jpg")
                    if (f.exists()) { img = android.graphics.BitmapFactory.decodeFile(f.path); if (img != null) break }
                }
            }
            if (img == null) return null
            val w = 132; val h = 88
            val out = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
            val cv = android.graphics.Canvas(out)
            val sc = max(w.toFloat() / img.width, h.toFloat() / img.height)
            val dw = img.width * sc; val dh = img.height * sc
            val p = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
            cv.drawBitmap(img, null, android.graphics.RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), p)
            val px = IntArray(w * h)
            out.getPixels(px, 0, w, 0, 0, w, h)
            val t = Triple(w, h, px)
            base = t
            return t
        }
    }

    fun image(p: MBLPreset): UIImage {
        synchronized(lock) {
            cache[p.name]?.let { return it }
            val b = loadBase() ?: return mblIcon(p.mods.firstOrNull() ?: "colorista", 96f)
            val v = mblResolve(p)
            val (w, h, src) = b
            val out = IntArray(w * h)
            for (i in 0 until w * h) {
                val c = mblApply(v, floatArrayOf((src[i] ushr 16 and 0xFF) / 255f, (src[i] ushr 8 and 0xFF) / 255f, (src[i] and 0xFF) / 255f))
                out[i] = (0xFF shl 24) or ((c[0] * 255).toInt() shl 16) or ((c[1] * 255).toInt() shl 8) or (c[2] * 255).toInt()
            }
            val bm = android.graphics.Bitmap.createBitmap(out, w, h, android.graphics.Bitmap.Config.ARGB_8888)
            val u = UIImage(bm)
            cache[p.name] = u
            return u
        }
    }
}

// MARK: - Edge Softness on-screen gizmo (yellow dashed inner circle = Radius, solid outer ellipse = Spread, centre dot = Centre X/Y)

class MBLGizmoView(context: android.content.Context) : UiView(context) {
    var owner: MBLEditorViewController? = null
    private val gold = 0xFFFCB826.toInt()
    private var hp = arrayOf(CGPoint(0f, 0f), CGPoint(0f, 0f), CGPoint(0f, 0f))
    private var drag = -1

    init {
        setBackgroundColor(0x00000000)
        isHidden = true
    }

    private class M(val c: CGPoint, val H: Float, val W: Float, val A: Float, val r0: Float, val r1: Float, val rad: Float, val spr: Float)

    private fun m(): M? {
        val o = owner ?: return null
        val H = rectHeight(); val W = rectWidth()
        val A = max(o.gizmoVal("mbEsAsp"), 0.2f)
        val rad = o.gizmoVal("mbEsRad")
        val spr = o.gizmoVal("mbEsSpr")
        val r0 = 0.45f * rad * (1 - 0.6f * spr)
        val r1 = r0 + 0.9f * rad * (0.3f + spr)
        return M(CGPoint(W / 2 + o.gizmoVal("mbEsX") * 0.005f * W, H / 2 - o.gizmoVal("mbEsY") * 0.005f * H), H, W, A, r0, r1, rad, spr)
    }

    fun refresh() {
        val o = owner
        if (o == null || o.gizmoCurTool() != "edge" || !o.gizmoMods().contains("edge")) { isHidden = true; return }
        val g = m() ?: return
        if (g.H <= 1) { isHidden = true; return }
        isHidden = false
        hp = arrayOf(g.c,
            CGPoint(g.c.x + g.r0 * g.A * g.H * 0.7071f, g.c.y + g.r0 * g.H * 0.7071f),
            CGPoint(g.c.x + g.r1 * g.A * g.H, g.c.y))
        setNeedsDisplay()
    }

    public override fun draw(rect: CGRect) {
        val g = UIGraphics.getCurrentContext() ?: return
        val o = owner ?: return
        if (o.gizmoCurTool() != "edge" || !o.gizmoMods().contains("edge")) return
        val mm = m() ?: return
        fun ell(r: Float): CGRect = CGRect(mm.c.x - r * mm.A * mm.H, mm.c.y - r * mm.H, 2 * r * mm.A * mm.H, 2 * r * mm.H)
        // inner dashed (Radius), outer solid (Spread)
        g.setStrokeColor(gold); g.setLineWidth(1.3f)
        g.setLineDash(0f, floatArrayOf(5f, 4f))
        g.strokeEllipse(ell(mm.r0))
        g.setLineDash(0f, FloatArray(0))
        g.strokeEllipse(ell(mm.r1))
        // dots
        g.setFillColor(0x59000000.toInt())
        g.fillEllipse(CGRect(mm.c.x - 5, mm.c.y - 5, 10f, 10f))
        g.fillEllipse(CGRect(hp[1].x - 4, hp[1].y - 4, 8f, 8f))
        g.fillEllipse(CGRect(hp[2].x - 4, hp[2].y - 4, 8f, 8f))
    }

    private fun nearest(l: CGPoint): Int? {
        if (isHidden) return null
        val d = hp.map { hypot((it.x - l.x).toDouble(), (it.y - l.y).toDouble()) }
        val i = d.indices.minByOrNull { d[it] } ?: return null
        return if (d[i] < 30) i else null
    }

    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        val l = CGPoint(e.x, e.y)
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { drag = nearest(l) ?: -1 }
            android.view.MotionEvent.ACTION_MOVE -> {
                val o = owner; val g = m()
                if (o != null && g != null && drag >= 0) {
                    fun cl(v: Float, a: Float, b: Float): Float = max(a, min(b, v))
                    when (drag) {
                        0 -> { o.gizmoSet("mbEsX", cl((l.x - g.W / 2) / (0.005f * g.W), -100f, 100f)); o.gizmoSet("mbEsY", cl(-(l.y - g.H / 2) / (0.005f * g.H), -100f, 100f)) }
                        1 -> {
                            val r0 = hypot(((l.x - g.c.x) / (g.A * g.H)).toDouble(), ((l.y - g.c.y) / g.H).toDouble()).toFloat()
                            o.gizmoSet("mbEsRad", cl(r0 / (0.45f * (1 - 0.6f * g.spr)), 0.1f, 3f))
                        }
                        else -> {
                            val r1 = kotlin.math.abs(l.x - g.c.x) / (g.A * g.H)
                            o.gizmoSet("mbEsSpr", cl((r1 - g.r0) / (0.9f * g.rad) - 0.3f, 0f, 1f))
                        }
                    }
                    refresh()
                }
            }
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> { if (drag >= 0) { drag = -1; owner?.showTabPub() } }
        }
        return true
    }
}

// MARK: - Haze/Flare tint wheel (hue / saturation disc with a draggable puck; onChange gives the tint as RGB 0...1, value stays 1)

class MBLTintWheel(context: android.content.Context) : UiView(context) {
    var rgb: Triple<Float, Float, Float> = Triple(0.226f, 0.181f, 1.0f)
        set(v) { field = v; setNeedsDisplay() }
    var onChange: ((Float, Float, Float) -> Unit)? = null
    private var disc: UIImage? = null

    init { setBackgroundColor(0x00000000) }

    private fun hsv(): Pair<Float, Float> {
        val mx = max(rgb.first, max(rgb.second, rgb.third))
        val mn = min(rgb.first, min(rgb.second, rgb.third))
        val d = mx - mn
        if (d < 0.0001f) return Pair(0f, 0f)
        var h: Float = when {
            mx == rgb.first -> ((rgb.second - rgb.third) / d) % 6f
            mx == rgb.second -> (rgb.third - rgb.first) / d + 2f
            else -> (rgb.first - rgb.second) / d + 4f
        }
        if (h < 0) h += 6f
        return Pair(h / 6f, d / max(mx, 0.0001f))
    }

    private fun makeDisc(n: Int): UIImage {
        val r = UIGraphicsImageRenderer(n, n)
        return r.image { g ->
            val c = n.toFloat() / 2
            val p = android.graphics.Paint()
            for (y in 0 until n) for (x in 0 until n) {
                val dx = (x - c) / c; val dy = (y - c) / c; val d = hypot(dx, dy)
                if (d > 1) continue
                var h = atan2(-dy, dx) / ((Math.PI * 2).toFloat())
                if (h < 0) h += 1f
                val col = com.saiki.motion.uikit.UIColor.hsv(h, d, 1f, 1f)
                p.color = col.toInt()
                g.canvas.drawRect(android.graphics.RectF(x.toFloat(), y.toFloat(), x + 1f, y + 1f), p)
            }
        }
    }

    public override fun draw(rect: CGRect) {
        val g = UIGraphics.getCurrentContext() ?: return
        val R = min(rectWidth(), rectHeight()) / 2 - 3
        val c = CGPoint(boundsRect.midX, boundsRect.midY)
        g.setStrokeColor(0xFF8C8C8C.toInt()); g.setLineWidth(3f)
        g.strokeEllipse(CGRect(c.x - (R + 1), c.y - (R + 1), 2 * (R + 1), 2 * (R + 1)))
        val ir = R - 5
        if (disc == null || kotlin.math.abs((disc?.size?.width ?: 0f) - ir * 2) > 1) disc = makeDisc(ir.toInt())
        disc?.let { d ->
            g.canvas.drawBitmap(d.bitmap, null, android.graphics.RectF(c.x - ir, c.y - ir, c.x + ir, c.y + ir),
                android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
        }
        val (h, s) = hsv()
        val a = h * (Math.PI * 2).toFloat()
        val p = CGPoint(c.x + cos(a) * s * ir, c.y - sin(a) * s * ir)
        g.setStrokeColor(0xFFFFFFFF.toInt()); g.setLineWidth(1.5f)
        g.strokeEllipse(CGRect(p.x - 4, p.y - 4, 8f, 8f))
    }

    private fun move(t: UITouch) {
        val l = t.location(this)
        val c = CGPoint(boundsRect.midX, boundsRect.midY)
        val ir = min(rectWidth(), rectHeight()) / 2 - 8
        val dx = (l.x - c.x) / ir
        val dy = -(l.y - c.y) / ir
        var h = atan2(dy, dx) / ((Math.PI * 2).toFloat())
        if (h < 0) h += 1f
        val s = min(hypot(dx, dy), 1f)
        val col = com.saiki.motion.uikit.UIColor.hsv(h, s, 1f, 1f).toInt()
        rgb = Triple(((col ushr 16) and 0xFF) / 255f, ((col ushr 8) and 0xFF) / 255f, (col and 0xFF) / 255f)
        onChange?.invoke(rgb.first, rgb.second, rgb.third)
    }

    override fun touchesBegan(t: Set<UITouch>, e: UIEvent?) { t.firstOrNull()?.let { move(it) } }
    override fun touchesMoved(t: Set<UITouch>, e: UIEvent?) { t.firstOrNull()?.let { move(it) } }
}
