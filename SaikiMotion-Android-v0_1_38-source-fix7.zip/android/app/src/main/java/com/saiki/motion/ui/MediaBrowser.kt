@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")
// Port of Sources/UI/MediaBrowser.swift — custom photo/video browser in the editor's own style
// (orange accent). Compact grid inside the Media panel + a full-screen version with preview.
// iOS PHPhotoLibrary: the Android twin is the MediaStore image/video tables queried through the
// system picker API surface available to this app (content URIs act as PHAsset ids).

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.provider.MediaStore
import com.saiki.motion.core.Projects
import com.saiki.motion.core.nowMs
import com.saiki.motion.app.addMedia
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.UIImpactFeedbackGenerator
import com.saiki.motion.uikit.UILongPressGestureRecognizer
import com.saiki.motion.uikit.UIGestureRecognizer
import com.saiki.motion.uikit.UIGestureRecognizerState
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.currentActivity
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.uikit.fillRoundRect
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.min
private fun mt(t: String, size: Float): Float = com.saiki.motion.uikit.measureText(t, size, true)
private fun dtext(t: String, x: Float, y: Float, size: Float, align: NSTextAlignment) {
    drawText(t, x, y, color = C.TEXT, size = size, bold = true, align = align)
}
private val ACC = C.GREEN
private val C_ONDARK = 0xFF0D0D0F.toInt()

enum class MediaFilter(val raw: Int) { all(0), photos(1), videos(2) }

/** PHAsset twin: a MediaStore row (uri id + kind + duration). */
class PHAssetTwin(val id: Long, val isVideo: Boolean, val duration: Double, val date: Long)

// MARK: - Grid + album/filter header

class MediaBrowserView(val columns: Int, val showExpand: Boolean) : UiView(appContext!!) {
    var onPick: ((Any?) -> Unit)? = null
    var onExpand: (() -> Unit)? = null
    /** Hold a thumbnail to start multi-select; tap more to add / remove; "Add N" imports them in order. */
    var onPickMany: ((List<Any?>) -> Unit)? = null
    var onMultiChange: ((Int) -> Unit)? = null
    var highlighted: String? = null
    var multi: MutableList<String> = ArrayList()
        private set          // ordered localIdentifiers (MediaStore ids)
    private var multiMode = false
    private val multiBtn = PillButton("Add", null, ACC, C_ONDARK)

    private var assets: List<PHAssetTwin> = emptyList()
    private val albumBtn = PillButton("All ▾", null, C.CARD2, C.TEXT)
    /** == iOS albums: (title, MediaStore bucket id or null = All). Order: All, smart, user albums. */
    private var albums: List<Pair<String, Long?>> = listOf(Pair("All", null))
    private var albumIdx = 0
    private val chips = ArrayList<PillButton>()
    private val grid = UIScrollView(appContext!!)
    private val empty = UILabel(appContext!!)
    private var filter = MediaFilter.all
    private val exec = Executors.newSingleThreadExecutor()
    private val thumbs = HashMap<Long, Bitmap>()
    private val cells = ArrayList<UiView>()
    private val haptic = UIImpactFeedbackGenerator()

    init {
        setBackgroundColor(0x00000000)
        albumBtn.textSize = 14f
        albumBtn.onClick = { showAlbumMenu() }   // == iOS UIMenu on albumBtn (loadAlbums)
        val bar = UiView(appContext!!)
        bar.addSubview(albumBtn)
        for ((i, n) in listOf("All", "Photos", "Videos").withIndex()) {
            val b = PillButton(n, null, C.CARD2, C.TEXT)
            b.textSize = 13f
            b.onClick = { filter = MediaFilter.entries[i]; restyleChips(); reload() }
            chips.add(b)
            bar.addSubview(b)
        }
        if (showExpand) {
            val ex = PillButton("⤢", null, C.GREEN, C.ONDARK)
            ex.onClick = { onExpand?.invoke() }
            bar.addSubview(ex)
        }
        addSubview(bar)
        grid.showsHorizontalScrollIndicator = false
        grid.showsVerticalScrollIndicator = false
        addSubview(grid)
        // long-press on a thumbnail (0.35s) starts multi-select
        val lp = UILongPressGestureRecognizer { g -> longPressed(g) }
        lp.minimumPressDuration = 0.35
        grid.addGestureRecognizer(lp)
        multiBtn.textSize = 15f
        multiBtn.isHidden = true
        multiBtn.onClick = { multiTap() }
        addSubview(multiBtn)
        empty.textColor = argbToUIColor(C.DIM); empty.font = UIFont.systemFont(13f); empty.textAlignment = NSTextAlignment.center
        empty.numberOfLines = 0
        addSubview(empty)
        restyleChips()
        authorizeAndLoad()
        onLayout = { _ -> layoutAll() }
    }

    private fun restyleChips() {
        for (b in chips) {
            val on = chips.indexOf(b) == filter.raw
            b.fillColor = if (on) C.GREEN else C.CARD2
            b.setColors(if (on) C.ONDARK else C.TEXT)
        }
    }

    private fun authorizeAndLoad() {
        // Android 13+: READ_MEDIA_IMAGES/VIDEO (no permission dialog from inside this custom grid,
        // so a denied state shows the same hint iOS gives).
        val ctx = appContext
        if (ctx != null && android.os.Build.VERSION.SDK_INT >= 33) {
            val im = ctx.checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES)
            val vd = ctx.checkSelfPermission(android.Manifest.permission.READ_MEDIA_VIDEO)
            if (im != android.content.pm.PackageManager.PERMISSION_GRANTED && vd != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                empty.text = "Allow photo access in Settings to browse your library."
                return
            }
        }
        loadAlbums(); reload()
    }

    /** == iOS loadAlbums (MediaBrowser.swift:133): All + smart albums + user albums, "Album" fallback title. */
    private fun loadAlbums() {
        val list = ArrayList<Pair<String, Long?>>()
        list.add(Pair("All", null))
        try {
            val ctx = appContext ?: return
            // smart albums first, in iOS's order: Favorites, Videos, Screenshots, Selfies
            val smart = listOf(
                Pair(MediaStore.Images.Media.BUCKET_ID, "favorites"),
                Pair("videos", null),
                Pair(MediaStore.Images.Media.BUCKET_ID, "screenshots"),
                Pair(MediaStore.Images.Media.BUCKET_ID, "selfies"))
            val cr = ctx.contentResolver
            fun bucketName(bucket: Long, like: String? = null): String? {
                // display name of a bucket; `like` matches the folder name (Screenshots, DCIM/Camera…)
                val p = arrayOf(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                val sel = if (like != null) "${MediaStore.Images.Media.BUCKET_DISPLAY_NAME} LIKE ?" else "${MediaStore.Images.Media.BUCKET_ID}=?"
                val args = if (like != null) arrayOf(like) else arrayOf(bucket.toString())
                val seen = HashSet<String>()
                cr.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, p, sel, args, null)?.use { c ->
                    while (c.moveToNext()) { val n = c.getString(0); if (n != null) seen.add(n) }
                }
                return seen.firstOrNull()
            }
            // Favorites: MediaStore does not flag favourites portably; skip like iOS would skip empty ones.
            for ((kind, like) in smart) {
                when {
                    like == "videos" -> list.add(Pair("Videos", -2L))       // synthetic: video-only view
                    like == "screenshots" -> bucketName(0, "Screenshots")?.let { list.add(Pair(it, 0L)) }
                    like == "selfies" -> bucketName(0, "Selfies")?.let { list.add(Pair(it, 0L)) }
                }
            }
            // user albums = every other bucket (Camera, Download, Pictures…), alphabetical
            val names = HashSet<String>()
            cr.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                     arrayOf(MediaStore.Images.Media.BUCKET_ID, MediaStore.Images.Media.BUCKET_DISPLAY_NAME),
                     null, null, "${MediaStore.Images.Media.BUCKET_DISPLAY_NAME} ASC")?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0); val n = c.getString(1) ?: "Album"
                    if (names.contains(n)) continue
                    names.add(n)
                    if (list.any { it.first == n }) continue
                    list.add(Pair(n, id))
                }
            }
        } catch (_: Exception) {}
        albums = list
        albumBtn.text = albums[min(albumIdx, albums.size - 1)].first + " ▾"
    }

    /** The album picker (== iOS albumBtn.menu). */
    private fun showAlbumMenu() {
        val act = currentActivity?.get() ?: return
        val popup = android.widget.PopupMenu(act, albumBtn)
        for ((i, a) in albums.withIndex()) {
            val it = popup.menu.add(a.first)
            it.isCheckable = true
            it.isChecked = i == albumIdx
        }
        popup.setOnMenuItemClickListener { mi ->
            val idx = albums.indexOfFirst { it.first == mi.title }
            if (idx >= 0) { albumIdx = idx; loadAlbums(); reload() }
            true
        }
        popup.show()
    }

    private fun reload() {
        exec.execute {
            val list = ArrayList<PHAssetTwin>()
            try {
                val ctx = appContext ?: return@execute
                val alb = albums[min(albumIdx, albums.size - 1)]
                val bucketSel: String?
                val bucketArgs: Array<String>?
                if (alb.second == null) { bucketSel = null; bucketArgs = null }
                else if (alb.second == -2L) { bucketSel = "1=1"; bucketArgs = null }      // Videos smart album
                else if (alb.second == 0L) { bucketSel = "${MediaStore.Images.Media.BUCKET_DISPLAY_NAME}=?"; bucketArgs = arrayOf(alb.first) }
                else { bucketSel = "${MediaStore.Images.Media.BUCKET_ID}=?"; bucketArgs = arrayOf(alb.second.toString()) }
                val proj = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED)
                if (filter != MediaFilter.videos && alb.second != -2L) {
                    ctx.contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj, bucketSel, bucketArgs, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
                        while (c.moveToNext()) list.add(PHAssetTwin(c.getLong(0), false, 0.0, c.getLong(1)))
                    }
                }
                if (filter != MediaFilter.photos) {
                    val vproj = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATE_ADDED)
                    val vsel = if (alb.second == -2L) null else if (bucketSel != null && alb.second != null && alb.second != -2L) "${MediaStore.Video.Media.BUCKET_DISPLAY_NAME}=?" else null
                    val vargs = if (vsel != null && alb.second != -2L && bucketArgs != null) bucketArgs else null
                    ctx.contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, vproj, vsel, vargs, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
                        while (c.moveToNext()) list.add(PHAssetTwin(c.getLong(0), true, c.getLong(1) / 1000.0, c.getLong(2)))
                    }
                }
                list.sortByDescending { it.date }
            } catch (_: Exception) { }
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                assets = list
                empty.text = if (assets.isEmpty()) "Nothing here yet" else ""
                buildGrid()
            }
        }
    }

    private fun uri(a: PHAssetTwin) =
        (if (a.isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            .buildUpon().appendPath(a.id.toString()).build()

    private fun buildGrid() {
        cells.forEach { it.removeFromSuperview() }
        cells.clear()
        for ((i, a) in assets.withIndex()) {
            val k = multi.indexOf(a.id.toString())       // multi-select order badge (nil when not selected)
            val ord = if (multiMode && k >= 0) k + 1 else null
            val sel = if (multiMode) k >= 0 else a.id.toString() == highlighted
            val cell = object : UiView(appContext!!) {
                public override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    com.saiki.motion.uikit.fillRoundRect(c, CGRect(0.5f, 0.5f, rect.width - 1f, rect.height - 1f), 4f, C.CARD)
                    if (sel) {
                        c.setStrokeColor(ACC)
                        c.setLineWidth(3f)
                        c.stroke(CGRect(1.5f, 1.5f, rect.width - 3f, rect.height - 3f))
                    }
                    val th = thumbs[a.id]
                    if (th != null) {
                        c.canvas.drawBitmap(th, null, android.graphics.RectF(1f, 1f, rect.width - 1f, rect.height - 1f),
                            android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                    }
                    if (a.isVideo) {
                        val dur = String.format(java.util.Locale.US, "%d:%02d", (a.duration / 60).toInt(), (a.duration % 60).toInt())
                        dtext(dur, rect.width - 6f, rect.height - 8f, 11f, NSTextAlignment.right)
                    }
                    if (ord != null) {
                        // order badge: accent circle with the pick number
                        com.saiki.motion.uikit.fillCircle(c, 16f, 16f, 11f, ACC)
                        drawText("$ord", 16f, 20.5f, color = C_ONDARK, size = 12f, bold = true, align = NSTextAlignment.center)
                    }
                }
            }
            cell.setBackgroundColor(0x00000000)
            cell.onClick = onClick@{
                if (multiMode) { toggleMulti(a); return@onClick }
                highlighted = a.id.toString()
                loadThumb(a)
                onPick?.invoke(uri(a))
            }
            cells.add(cell)
            grid.addSubview(cell)
            loadThumb(a)
        }
        layoutAll()
    }

    private fun longPressed(g: com.saiki.motion.uikit.UIGestureRecognizer) {
        if (g.state != com.saiki.motion.uikit.UIGestureRecognizerState.began) return
        // grid.indexPathForItem(at:) twin: the recogniser reports viewport coords, cells live in
        // content coords — add the scroll offset before hit-testing.
        val loc = g.location(grid)
        val cx = loc.x + grid.scrollX
        val cy = loc.y + grid.scrollY
        val cell = cells.firstOrNull { cx >= it.frame.minX && cx <= it.frame.maxX && cy >= it.frame.minY && cy <= it.frame.maxY } ?: return
        val idx = cells.indexOf(cell)
        if (idx < 0 || idx >= assets.size) return
        val a = assets[idx]
        haptic.impactOccurred()
        if (!multiMode) {
            multiMode = true; multi.clear()
            val h = highlighted
            if (h != null && h != a.id.toString()) multi.add(h)
        }
        if (!multi.contains(a.id.toString())) multi.add(a.id.toString())
        refreshMulti()
    }

    private fun toggleMulti(a: PHAssetTwin) {
        val k = multi.indexOf(a.id.toString())
        if (k >= 0) multi.removeAt(k) else multi.add(a.id.toString())
        if (multi.isEmpty()) multiMode = false
        refreshMulti()
    }

    private fun refreshMulti() {
        multiBtn.isHidden = !multiMode
        multiBtn.text = "Add ${multi.size}"
        buildGrid()
        onMultiChange?.invoke(multi.size)
    }

    fun clearMulti() { multi.clear(); multiMode = false; refreshMulti() }

    private fun multiTap() {
        val list = ArrayList<Any?>()
        for (id in multi) {
            val a = assets.firstOrNull { it.id.toString() == id } ?: continue
            list.add(uri(a))
        }
        clearMulti()
        if (list.isNotEmpty()) onPickMany?.invoke(list)
    }

    private fun loadThumb(a: PHAssetTwin) {
        if (thumbs.containsKey(a.id)) { grid.setNeedsDisplay(); return }
        exec.execute {
            try {
                val bm = appContext!!.contentResolver.loadThumbnail(uri(a), android.util.Size(140, 140), null)
                thumbs[a.id] = bm
                android.os.Handler(android.os.Looper.getMainLooper()).post { grid.setNeedsDisplay() }
            } catch (_: Exception) { }
        }
    }

    private fun layoutAll() {
        val w = rectWidth().coerceAtLeast(1f)
        val h = rectHeight().coerceAtLeast(1f)
        val bar = subviews[0]
        var x = 0f
        for (b in bar.subviews) {
            val bw = mt((b as PillButton).text ?: "", b.textSize) + 24f
            b.frame = CGRect(x, 0f, bw, 32f)
            x += bw + 6f
        }
        bar.frame = CGRect(0f, 0f, kotlin.math.max(x, w), 32f)
        grid.frame = CGRect(0f, 40f, w, h - 40f)
        val gw = grid.rectWidth()
        val cw = ((gw - 2f * (columns - 1)) / columns).toInt().coerceAtLeast(1)
        var gx = 0f; var gy = 0f
        for (c in cells) {
            c.frame = CGRect(gx, gy, cw.toFloat(), cw.toFloat())
            gx += cw + 2f
            if (gx + cw > gw) { gx = 0f; gy += cw + 2f }
        }
        grid.contentSize = CGSize(gw, gy + cw + 4f)
        empty.frame = CGRect(20f, 40f + grid.rectHeight() / 2 - 20f, kotlin.math.max(w - 40f, 10f), 40f)
        val bw = mt(multiBtn.text, 15f) + 32f
        multiBtn.frame = CGRect(w - 10f - bw, h - 10f - 38f, bw, 38f)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        layoutAll()
    }

}

// MARK: - Full-screen browser with preview

class MediaBrowserViewController : UIViewController() {
    var onAdd: ((Any?) -> Unit)? = null
    var onAddMany: ((List<Any?>) -> Unit)? = null
    private var selected: android.net.Uri? = null
    private var isVideo = false
    private var player: android.media.MediaPlayer? = null
    private val preview = object : UiView(appContext!!) {
        var bmp: Bitmap? = null
        public override fun draw(rect: CGRect) {
            val c = UIGraphics.getCurrentContext() ?: return
            c.setFillColor(0xFF000000.toInt())
            c.fill(CGRect(0f, 0f, rect.width, rect.height))
            val b = bmp ?: return
            val s = kotlin.math.min(rect.width / b.width.toFloat(), rect.height / b.height.toFloat())
            val dw = b.width * s
            val dh = b.height * s
            val pnt = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
            c.canvas.drawBitmap(b, null, android.graphics.RectF((rect.width - dw) / 2f, (rect.height - dh) / 2f, (rect.width + dw) / 2f, (rect.height + dh) / 2f), pnt)
        }
    }
    private val playBtn = PillButton("▶", null, 0x00000000.toInt(), C.GREEN)
    private val addBtn = PillButton("Add", null, C.GREEN, 0xFF0D0D0F.toInt())
    private val title_ = UILabel(appContext!!)
    private var browser: MediaBrowserView? = null

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        val x = PillButton("✕", null, C.CARD2, C.TEXT)
        x.onClick = { close() }
        title_.text = "Media"; title_.textColor = argbToUIColor(C.TEXT); title_.font = UIFont.boldSystemFont(17f)
        addBtn.textSize = 15f
        addBtn.alpha = 0.4f
        addBtn.isUserInteractionEnabled = false
        addBtn.onClick = { add() }
        playBtn.textSize = 24f
        playBtn.isHidden = true
        playBtn.onClick = { togglePlay() }
        val b = MediaBrowserView(4, false)
        browser = b
        b.onPick = { a -> select(a) }
        b.onPickMany = { list ->
            player?.release(); player = null
            dismiss(animated = true) { onAddMany?.invoke(list) }
        }
        view.addSubview(x); view.addSubview(title_); view.addSubview(addBtn)
        view.addSubview(preview); view.addSubview(playBtn); view.addSubview(b)
        view.onLayout = { _ -> relayout() }
        relayout()
    }

    private fun relayout() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w < 10 || h < 10) return
        val top = view.safeAreaInsets.top
        val x = view.subviews[0]
        x.frame = CGRect(12f, top + 8f, 40f, 34f)
        title_.frame = CGRect(w / 2 - 60f, top + 8f, 120f, 34f)
        addBtn.frame = CGRect(w - 84f, top + 8f, 72f, 34f)
        preview.frame = CGRect(0f, top + 48f, w, h * 0.36f)
        playBtn.frame = CGRect(w / 2 - 28f, top + 48f + h * 0.36f / 2 - 28f, 56f, 56f)
        browser?.frame = CGRect(8f, preview.frame.maxY + 10f, w - 16f, h - preview.frame.maxY - 20f)
    }

    private fun select(a: Any?) {
        val u = a as? android.net.Uri ?: return
        selected = u
        addBtn.alpha = 1f; addBtn.isUserInteractionEnabled = true
        player?.release(); player = null
        isVideo = u.path?.let { MediaStore.Video.Media.EXTERNAL_CONTENT_URI.path == File(u.path).parentFile?.path } ?: (u.toString().contains("video"))
        isVideo = u.toString().startsWith(MediaStore.Video.Media.EXTERNAL_CONTENT_URI.toString())
        preview.bmp = null
        Thread {
            try {
                val src = android.graphics.ImageDecoder.createSource(appContext!!.contentResolver, u)
                val bm = android.graphics.ImageDecoder.decodeBitmap(src) { d, _, _ -> d.setTargetSampleSize(4) }
                android.os.Handler(android.os.Looper.getMainLooper()).post { preview.bmp = bm.copy(android.graphics.Bitmap.Config.ARGB_8888, false); preview.setNeedsDisplay() }
            } catch (_: Exception) { }
        }.start()
        playBtn.isHidden = !isVideo
        playBtn.text = "▶"
        title_.text = if (isVideo) "Video" else "Photo"
    }

    private fun togglePlay() {
        val u = selected ?: return
        val p = player
        if (p != null) {
            if (p.isPlaying) { p.pause(); playBtn.text = "▶" } else { p.start(); playBtn.text = "❚❚" }
            return
        }
        try {
            val np = android.media.MediaPlayer()
            np.setDataSource(appContext!!, u)
            np.prepare()
            np.setOnCompletionListener { playBtn.text = "▶" }
            np.start()
            player = np
            playBtn.text = "❚❚"
        } catch (_: Exception) { }
    }

    private fun add() {
        val u = selected ?: return
        player?.release(); player = null
        dismiss(animated = true) { onAdd?.invoke(u) }
    }

    private fun close() {
        player?.release(); player = null
        dismiss(animated = true)
    }
}

// MARK: - Editor glue

fun com.saiki.motion.app.EditorViewController.openFullMediaBrowser() {
    val vc = MediaBrowserViewController()
    vc.onAdd = { a -> importPHAsset(a) }
    vc.onAddMany = { l -> importPHAssets(l) }
    present(vc, animated = true)
}

// MARK: - Import3DSheet (iOS MediaBrowser.swift:322 — bottom sheet with the four 3D imports)

/** One row of the sheet: icon, title, subtitle, chevron. */
private class Import3DRow(icon: String, title: String, sub: String, tap: () -> Unit) : TapView() {
    init { onClick = tap }
    private val sym = icon
    private val t = title
    private val s = sub
    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width; val h = rect.height
        if (isHighlighted) fillRoundRect(c, CGRect(0f, 0f, w, h), 14f, C.CARD2)
        else fillRoundRect(c, CGRect(0f, 0f, w, h), 14f, C.CARD)
        Icons.draw(c, sym, 30f, h / 2, 28f, ACC)
        drawText(t, 66f, h / 2 - 11f, color = C.TEXT, size = 15f, bold = true)
        drawText(s, 66f, h / 2 + 8f, color = C.DIM, size = 12f, bold = false)
        Icons.draw(c, "chevron.right", w - 26f, h / 2, 16f, ACC)
    }
}

/** The 3D import bottom sheet: dim background, card with 4 rows + Cancel, animated in/out. */
class Import3DSheet private constructor() : UiView() {
    var onModel: (() -> Unit)? = null
    var onVdb: (() -> Unit)? = null
    var onMmd: (() -> Unit)? = null
    var onVrm: (() -> Unit)? = null
    private val dim = UiView()
    private val card = UiView()

    companion object {
        fun show(inHost: UiView, model: () -> Unit, vdb: () -> Unit, mmd: (() -> Unit)? = null, vrm: (() -> Unit)? = null) {
            val s = Import3DSheet()
            s.onModel = model; s.onVdb = vdb; s.onMmd = mmd; s.onVrm = vrm
            inHost.addView(s)
            s.layoutView(inHost.width.toFloat(), inHost.height.toFloat())
            s.animateIn()
        }
    }

    init {
        dim.setBackgroundColor(0x8C000000.toInt())
        dim.addGestureRecognizer(com.saiki.motion.uikit.UITapGestureRecognizer { dismissSheet() })
        addView(dim)
        addView(card)
    }

    fun layoutView(w: Float, h: Float) {
        layoutParams = android.view.ViewGroup.LayoutParams(w.toInt(), h.toInt())
        dim.layoutParams = android.view.ViewGroup.LayoutParams(w.toInt(), h.toInt())
        val ch = (18 + 24 + 10 + (4 * (64 + 10)) + 44 + 34).toFloat()
        card.layoutParams = android.view.ViewGroup.LayoutParams(w.toInt(), ch.toInt())
        card.x = 0f; card.y = h - ch
        card.setBackgroundColor(C.PANEL)
        // title
        val t = com.saiki.motion.uikit.UILabel()
        t.text = "3D"; t.textColor = argbToUIColor(C.TEXT)
        t.font = com.saiki.motion.uikit.UIFont.boldSystemFont(17f)
        t.frame = CGRect(16f, 18f, 100f, 24f)
        card.addView(t)
        // four import rows
        val specs = listOf(
            Triple("cube", "Import 3D model", ".glb  .gltf  .fbx  .obj  .abc  .ply  .spz (point maps)") to { tapModel() },
            Triple("person", "Import MikuMikuDance", ".pmx  .mmd model + .vmd motion (zip with textures)") to { tapMmd() },
            Triple("person", "Import VRM", "VRM avatar (.vrm)") to { tapVrm() },
            Triple("cloud", "Import VDB", "OpenVDB volume (.vdb)") to { tapVdb() })
        var y = 18f + 24f + 10f
        for ((spec, tap) in specs) {
            val r = Import3DRow(spec.first, spec.second, spec.third, tap)
            r.frame = CGRect(16f, y, w - 32f, 64f)
            card.addView(r)
            y += 64f + 10f
        }
        // Cancel
        val cancel = object : com.saiki.motion.ui.TapView() {
            public override fun draw(rect: CGRect) {
                drawText("Cancel", rect.width / 2, 22f, color = C.DIM, size = 15f, bold = true, align = NSTextAlignment.center)
            }
        }
        cancel.onClick = { dismissSheet() }
        cancel.frame = CGRect(16f, y, w - 32f, 44f)
        card.addView(cancel)
    }

    fun animateIn() {
        alpha = 0f
        com.saiki.motion.uikit.UIViewAnimator.animate(0.25f) { alpha = 1f }
    }
    fun dismissSheet() {
        com.saiki.motion.uikit.UIViewAnimator.animate(0.2f) { alpha = 0f }
        removeFromSuperview()
    }
    private fun tapModel() { removeFromSuperview(); onModel?.invoke() }
    private fun tapMmd() { removeFromSuperview(); onMmd?.invoke() }
    private fun tapVrm() { removeFromSuperview(); onVrm?.invoke() }
    private fun tapVdb() { removeFromSuperview(); onVdb?.invoke() }
}

/// Imports several assets one after another (keeps the picked order, no racing layer inserts).
fun com.saiki.motion.app.EditorViewController.importPHAssets(list: List<Any?>) {
    val rest = ArrayList(list)
    fun next() {
        if (rest.isEmpty()) return
        val a = rest.removeAt(0)
        importPHAsset(a) { next() }
    }
    if (list.size > 1) toast("Importing ${list.size} items...")
    next()
}

fun com.saiki.motion.app.EditorViewController.importPHAsset(a: Any?, done: (() -> Unit)? = null) {
    toast("Importing...")
    val u = a as? android.net.Uri ?: run { toast("Could not read the asset"); done?.invoke(); return }
    val isVideo = u.toString().startsWith(MediaStore.Video.Media.EXTERNAL_CONTENT_URI.toString())
    Thread {
        try {
            if (isVideo) {
                // iOS importPickedVideo: copy synchronously, then "Video imported" / copy-failure toast
                val f = File(Projects.mediaDir(), "${nowMs()}_video.mp4")
                try { if (f.exists()) f.delete() } catch (_: Exception) {}
                var ok = false
                try { appContext!!.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }; ok = f.length() > 0 } catch (_: Exception) { ok = false }
                if (!ok) {
                    android.os.Handler(android.os.Looper.getMainLooper()).post { toast("Import failed — could not copy the video"); done?.invoke() }
                    return@Thread
                }
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    addMedia(f.path, com.saiki.motion.core.LayerType.VIDEO)
                    toast("Video imported")
                    // iOS waits 0.35s after the video copy before the next import
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ done?.invoke() }, 350)
                }
            } else {
                val bmp = try {
                    android.graphics.ImageDecoder.decodeBitmap(android.graphics.ImageDecoder.createSource(appContext!!.contentResolver, u)) { d, _, _ -> d.setTargetSampleSize(1) }
                } catch (_: Exception) { null }
                if (bmp == null) {
                    android.os.Handler(android.os.Looper.getMainLooper()).post { toast("Could not read the photo"); done?.invoke() }
                    return@Thread
                }
                val b2 = bmp.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                val hasAlpha = b2.hasAlpha()
                val f = File(Projects.mediaDir(), "${nowMs()}_photo.${if (hasAlpha) "png" else "jpg"}")
                val wrote = try { f.outputStream().use { o ->
                    if (hasAlpha) b2.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, o)
                    else b2.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, o)
                }; true } catch (_: Exception) { false }
                if (!wrote) {
                    android.os.Handler(android.os.Looper.getMainLooper()).post { toast("Import failed"); done?.invoke() }
                    return@Thread
                }
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    addMedia(f.path, com.saiki.motion.core.LayerType.IMAGE)
                    done?.invoke()
                }
            }
        } catch (_: Exception) {
            android.os.Handler(android.os.Looper.getMainLooper()).post { toast("Import failed"); done?.invoke() }
        }
    }.start()
}
