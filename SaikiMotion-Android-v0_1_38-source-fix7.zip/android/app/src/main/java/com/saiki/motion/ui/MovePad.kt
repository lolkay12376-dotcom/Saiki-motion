@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import com.saiki.motion.uikit.CADisplayLink
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIControl
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UILongPressGestureRecognizer
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

// Port of Sources/UI/MovePad.swift — MovePadView (trackpad), GridPick (3x3 anchors), FlareThumb,
// IrisThumb/IrisPreview, FlareDriver, FlareEditorView.

/// Drag anywhere inside to move X and Y together (relative movement, like a trackpad).
class MovePadView : UIControl(com.saiki.motion.uikit.appContext!!) {
    var px: Float = 0f
    var py: Float = 0f
    var onBeginDrag: (() -> Unit)? = null
    var onMove: ((Float, Float) -> Unit)? = null
    private var lx: CGFloat = 0f
    private var ly: CGFloat = 0f

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 12f, C.CARD)
        val cx = rect.width / 2
        val cy = rect.height / 2
        strokeLine(c, cx, 0f, cx, rect.height, 1f, 0xFF3A3A42.toInt())
        strokeLine(c, 0f, cy, rect.width, cy, 1f, 0xFF3A3A42.toInt())
        val ox = (px / 3f * 160f).coerceIn(-cx + 14f, cx - 14f)
        val oy = (-py / 3f * 160f).coerceIn(-cy + 14f, cy - 14f)
        fillCircle(c, cx + ox, cy + oy, 9f, C.GREEN)
        drawText("X " + String.format(Locale.US, "%.2f", px) + "   Y " + String.format(Locale.US, "%.2f", py),
                 12f, 20f, color = C.DIM, size = 12f, bold = false, align = NSTextAlignment.left)
    }

    override fun touchesBegan(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        lx = t.location(this).x
        ly = t.location(this).y
        disallowParentScrollInterception(this, true)
        onBeginDrag?.invoke()
    }

    override fun touchesMoved(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val p = t.location(this)
        val k = 3f / 160f
        onMove?.invoke((p.x - lx) * k, -(p.y - ly) * k)
        lx = p.x
        ly = p.y
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        disallowParentScrollInterception(this, false)
    }

    override fun touchesCancelled(touches: Set<UITouch>, event: UIEvent?) {
        disallowParentScrollInterception(this, false)
    }
}

/// 3x3 anchor preset picker. Index 0..8, row-major from top-left.
class GridPick : TapView() {
    var sel = -1
    var onPick: ((Int) -> Unit)? = null

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 12f, C.CARD)
        val padX = 28f
        val padY = 22f
        for (i in 0 until 9) {
            val x = padX + (rect.width - 2 * padX) * (i % 3) / 2
            val y = padY + (rect.height - 2 * padY) * (i / 3) / 2
            fillCircle(c, x, y, if (i == sel) 10f else 5f, if (i == sel) C.GREEN else C.DIM)
        }
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val p = t.location(this)
        val col = (p.x / (rectWidth() / 3)).toInt().coerceIn(0, 2)
        val row = (p.y / (rectHeight() / 3)).toInt().coerceIn(0, 2)
        onPick?.invoke(row * 3 + col)
    }
}

/// A card showing a pre-rendered flare; picks the picture up from FlareThumbs once it exists.
class FlareThumb(val key: String, val label: String) : TapView() {
    private val handler = Handler(Looper.getMainLooper())

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width
        val h = rect.height
        fillRoundRect(c, CGRect(0f, 0f, w, h), 14f, 0xFF0B0B10.toInt())
        val b = com.saiki.motion.core.FlareThumbs.cache[key]
        val th = h - 26f
        if (b != null) {
            c.saveGState()
            val clip = com.saiki.motion.uikit.CGPath.roundedRect(CGRect(0f, 0f, w, h), 14f, 14f)
            c.addPath(clip)
            c.clipPath()
            val s = max(w / b.width, (th + 8) / b.height)
            val dw = b.width * s
            val dh = b.height * s
            val p = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            c.canvas.drawBitmap(b, null, RectF((w - dw) / 2, (th + 8 - dh) / 2, (w - dw) / 2 + dw, (th + 8 - dh) / 2 + dh), p)
            c.restoreGState()
        } else {
            handler.postDelayed({ setNeedsDisplay() }, 300)
        }
        fillRect(c, CGRect(0f, h - 26f, w, 26f), 0xCC000000.toInt())
        drawText(label, w / 2, h - 9f, color = 0xFFFFFFFF.toInt(), size = 12f, bold = true, align = NSTextAlignment.center)
    }
}

/// A card showing one procedural iris shape (preset browser).
class IrisThumb(var def: com.saiki.motion.core.IrisDef) : TapView() {
    var picked = false
        set(v) { field = v; setNeedsDisplay() }
    var onLongPress: (() -> Unit)? = null

    init {
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        val lp = UILongPressGestureRecognizer { }
        addGestureRecognizer(lp)
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width; val h = rect.height
        fillRoundRect(c, CGRect(0f, 0f, w, h), 12f, if (picked) 0xFF3A2812.toInt() else 0xFF0B0B10.toInt())
        if (picked) {
            c.setStrokeColor(C.GREEN)
            c.setLineWidth(2f)
            c.addPath(com.saiki.motion.uikit.CGPath.roundedRect(CGRect(1f, 1f, w - 2, h - 2), 12f, 12f))
            c.strokePath()
        }
        IrisPreview.drawIris(c, def, CGPoint(w / 2, (h - 16) / 2 + 2), (h - 24) / 2 * 0.9f)
        drawText(def.name, w / 2, h - 5f, color = C.DIM, size = 10f, bold = false, align = NSTextAlignment.center)
    }
}

/// Large live preview of the iris being edited (drawn with the same maths as the flare shader).
class IrisPreview : UiView(com.saiki.motion.uikit.appContext!!) {
    var def = com.saiki.motion.core.IrisDef()
        set(v) { field = v; setNeedsDisplay() }
    var tint: Int = 0xFFFFD999.toInt()
        set(v) { field = v; setNeedsDisplay() }

    companion object {
        fun drawIris(c: CGContext, d: com.saiki.motion.core.IrisDef, centre: CGPoint, r: CGFloat,
                     col: Int = 0xFFFFE0A6.toInt()) {
            c.saveGState()
            c.translateBy(centre.x, centre.y)
            val path = com.saiki.motion.core.FlareThumbs.irisPath(d, r)
            // plusLighter blend
            c.paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.ADD)
            if (d.thick >= 0.95f) {
                // filled: soft edge glow stacked from big to small
                for (i in 0 until 6) {
                    val k = 1f - i * 0.06f * (1f - d.grad * 0.6f)
                    c.saveGState()
                    c.scaleBy(k, k)
                    c.addPath(path)
                    c.setFillColor(((0.1f + 0.05f * d.grad) * 255).toInt().let { a -> (a shl 24) or (col and 0xFFFFFF) })
                    c.fillPath()
                    c.restoreGState()
                }
            }
            val lw = max(1.5f, r * min(d.thick, 0.5f) * 0.35f + r * 0.03f)
            if (d.chroma > 0.02f) {
                val cols = intArrayOf(0xFFFF0000.toInt(), 0xFF00FF00.toInt(), 0xFF0000FF.toInt())
                for ((i, cc) in cols.withIndex()) {
                    val k = 1f + (i - 1f) * -d.chroma * 0.07f
                    c.saveGState(); c.scaleBy(k, k)
                    c.addPath(path); c.setStrokeColor((0xCC shl 24) or (cc and 0xFFFFFF))
                    c.setLineWidth(lw); c.strokePath(); c.restoreGState()
                }
            } else {
                c.addPath(path); c.setStrokeColor((0xE6 shl 24) or (col and 0xFFFFFF))
                c.setLineWidth(lw); c.strokePath()
            }
            c.paint.xfermode = null
            c.restoreGState()
        }
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width; val h = rect.height
        fillRoundRect(c, CGRect(0f, 0f, w, h), 14f, 0xFF08080C.toInt())
        drawIris(c, def, CGPoint(w / 2, h / 2), min(w, h) * 0.38f, tint)
    }
}

/// Drives the "Animate light" preview.
class FlareDriver {
    private var link: CADisplayLink? = null
    private var t0 = System.nanoTime() / 1e9
    var tick: ((Double) -> Unit)? = null

    fun start() {
        t0 = System.nanoTime() / 1e9
        val l = CADisplayLink(this, "step")
        link = l
    }

    fun stop() { link?.invalidate(); link = null }

    fun step() { tick?.invoke(System.nanoTime() / 1e9 - t0) }
}

/// Full-screen flare editor container: bar, live preview, tools, tabs and the scrolling panel.
class FlareEditorView(context: android.content.Context) : UiView(context) {
    val bar = UiView(context)
    val holder = UiView(context)
    val tools = UiView(context)
    var tabs: UiView? = null
    var preview: UiView? = null       // the live editor preview, hosted in `holder` while the flare editor is open
    val scroll = com.saiki.motion.uikit.CapScroll(context)
    val content = com.saiki.motion.app.EVStack()

    init {
        addSubview(bar); addSubview(holder); addSubview(tools); addSubview(scroll)
        scroll.addSubview(content)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth(); val h = rectHeight()
        val ins = safeAreaInsets
        bar.frame = CGRect(0f, ins.top, w, 54f)
        val ph = max(200f, min(h * 0.36f, w * 1.05f))
        holder.frame = CGRect(0f, bar.frame.maxY, w, ph)
        tools.frame = CGRect(0f, holder.frame.maxY, w, 50f)
        tabs?.frame = CGRect(0f, tools.frame.maxY, w, 44f)
        val top = tabs?.frame?.maxY ?: tools.frame.maxY
        scroll.frame = CGRect(0f, top, w, max(0f, h - top - ins.bottom))
        val p = preview
        if (p != null && p.superview === holder && p.frame != holder.frame) {
            p.frame = holder.frame; p.requestLayout(); p.layoutSubviews()
        }
    }
}
