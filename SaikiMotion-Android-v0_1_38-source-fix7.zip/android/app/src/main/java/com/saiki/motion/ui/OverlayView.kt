@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.PuppetEdit
import com.saiki.motion.core.PuppetMath
import com.saiki.motion.core.PuppetPin
import com.saiki.motion.core.SceneRenderer
import com.saiki.motion.core.Xf
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// Port of Sources/UI/OverlayView.swift — selection, handles, guides, eyedropper.
// Sits transparently over the preview; draws the selected layer's world quad (same math the
// renderer uses), corner scale handles, a rotate handle and optional thirds guides.
// Touch: tap selects the top-most hit layer, drag moves (auto-key aware), corner handles scale,
// the rotate handle spins, and while `pick` is set a tap reports the preview pixel instead.

interface EditHost {
    fun selectedLayer(): Layer?
    fun isSelected(id: Int): Boolean
    fun onSelect(id: Int)
    fun beginEdit()
    fun onEdited()
    fun autoKey(): Boolean
    fun puppetPanelOpen(): Boolean
    fun gradientKnobsOn(): Boolean
}

interface TimelineHost

class OverlayView(private val editHost: EditHost, private val timelineHost: TimelineHost?) : UiView(com.saiki.motion.uikit.appContext!!) {

    /** True while the Scene dialog's guides toggle is on. */
    var guides = false
        set(v) { field = v; setNeedsDisplay() }

    /** Eyedropper: preview-pixel coordinates (top-left origin). */
    var pick: ((Float, Float) -> Unit)? = null

    private var dragMode = 0          // 0 none, 1 move, 2 scale, 3 rotate
    private var dragLayer: Layer? = null
    private var dragStart = CGPoint(0f, 0f)
    private var startDist = 0f
    private var startScale = 1f
    private var startRot = 0f
    private var startCenter = CGPoint(0f, 0f)

    private val ext = PuppetExtView()

    init {
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        isMultipleTouchEnabled = false
        clipsToBounds = false               // the ext helper draws outside our bounds (UIKit never clips subviews)
        ext.owner = this; ext.isUserInteractionEnabled = false
        ext.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        ext.isHidden = true
        addSubview(ext)
    }

    // ---- puppet pins outside the comp: while the Puppet panel is open, a helper view covers the whole visible
    // preview area (not just the comp rectangle) so pins can be drawn, tapped and dragged anywhere on screen.
    private val extOn: Boolean
        get() = editHost.puppetPanelOpen() && (editHost.selectedLayer()?.puppet?.on == true)

    fun syncExt() {
        val on = extOn
        ext.isHidden = !on
        if (!on) return
        val sv = superview ?: return
        // convert(sv.bounds, from: sv).union(bounds).integral — the twin's transform is draw-only, so plain frame math
        val r = CGRect(-frame.x, -frame.y, sv.rectWidth(), sv.rectHeight())
        val x = kotlin.math.floor(min(0f, r.x)); val y = kotlin.math.floor(min(0f, r.y))
        val mx = kotlin.math.ceil(max(rectWidth(), r.x + r.width)); val my = kotlin.math.ceil(max(rectHeight(), r.y + r.height))
        val nr = CGRect(x, y, mx - x, my - y)
        if (ext.frame.x != nr.x || ext.frame.y != nr.y || ext.frame.width != nr.width || ext.frame.height != nr.height) ext.frame = nr
        // the ext content must land exactly where our own (transformed) drawing does: its canvas is pre-translated
        // by nr.origin, so T_ext = T followed by -origin (UIKit applies the superview transform to subviews for free).
        val t = transform
        ext.transform = if (t != null) android.graphics.Matrix(t).apply { postTranslate(-nr.x, -nr.y) } else null
        ext.setNeedsDisplay()
    }

    override fun setNeedsDisplay() { super.setNeedsDisplay(); syncExt() }
    override fun layoutSubviews() { super.layoutSubviews(); syncExt() }

    /** iOS point(inside:) twin: touches anywhere on the covered preview area belong to this overlay. */
    override fun pointInside(p: CGPoint): Boolean {
        if (extOn && ext.frame.contains(p)) return true
        return super.pointInside(p)
    }

    /** AspectLayout routes touches here while the puppet panel is open (Android dispatches by bounds only). */
    fun wantsExtTouch(p: CGPoint): Boolean = extOn && pointInside(p)

    fun drawExt(c: CGContext, origin: CGPoint) {
        val l = editHost.selectedLayer() ?: return
        val pp = l.puppet ?: return
        // iOS translates by -origin here; the twin folds that offset into the ext's transform (see syncExt),
        // so the puppet is drawn straight in overlay coordinates.
        drawPuppet(c, l, pp)
    }

    // MARK: - geometry

    private val worldAr: Float
        get() = Editor.project.w.toFloat() / max(Editor.project.h, 1).toFloat()

    /// world (x, y) → view point
    private fun toScreen(x: Float, y: Float): CGPoint {
        val nx = (x / worldAr + 1) / 2
        val ny = (1 - y) / 2
        return CGPoint(nx * rectWidth(), ny * rectHeight())
    }

    /// view point → world (x, y)
    private fun toWorld(p: CGPoint): Pair<Float, Float> {
        val nx = p.x / max(rectWidth(), 1f)
        val ny = p.y / max(rectHeight(), 1f)
        return Pair(nx * 2 * worldAr - worldAr, 1 - ny * 2)
    }

    /// Layer-local quad points → view points, through the camera for 3D layers (same math as the renderer).
    private fun proj(l: Layer, pts: List<Pair<Float, Float>>): List<CGPoint> {
        val w: List<Pair<Float, Float>> =
            if (l.is3d) {
                val r = SceneRenderer.gizmoSource
                r?.gizmoProject(l, Editor.time, pts) ?: pts.map { Xf.apply(Xf.matrix(l, Editor.time), it.first, it.second) }
            } else {
                val m = Xf.matrix(l, Editor.time)
                pts.map { Xf.apply(m, it.first, it.second) }
            }
        return w.map { toScreen(it.first, it.second) }
    }

    private fun screenQuad(l: Layer): List<CGPoint> {
        val (qw, qh) = Xf.quadSize(l)
        val hw = qw / 2; val hh = qh / 2
        return proj(l, listOf(Pair(-hw, hh), Pair(hw, hh), Pair(hw, -hh), Pair(-hw, -hh)))
    }

    /// Where the layer's anchor point (its pivot) is on screen.
    private fun anchorScreen(l: Layer): CGPoint {
        val (qw, qh) = Xf.quadSize(l)
        val lt = l.editTime("x", Editor.time)
        val ax = l.p("anchorX", lt); val ay = l.p("anchorY", lt)
        return proj(l, listOf(Pair((ax - 50) / 100 * qw, -(ay - 50) / 100 * qh)))[0]
    }

    /** Every layer that shows a gizmo: the primary selection plus the rest of a multi-selection. */
    private fun gizmoLayers(l: Layer): List<Layer> {
        val out = ArrayList<Layer>()
        out.add(l)
        for (g in Editor.scene.layers) {
            if (g === l || !editHost.isSelected(g.id) || !g.visible) continue
            if (Editor.time < g.start - 0.001f || Editor.time > g.end + 0.001f) continue
            out.add(g)
        }
        return out
    }

    private fun hitLayer(l: Layer, p: CGPoint): Boolean {
        if (!l.is3d) {
            val w = toWorld(p)
            return Xf.hit(l, w.first, w.second, Editor.time)
        }
        val q = screenQuad(l)
        var pos = false; var neg = false
        for (i in 0 until 4) {
            val a = q[i]; val b = q[(i + 1) % 4]
            val cr = (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x)
            if (cr > 0) pos = true else if (cr < 0) neg = true
        }
        return !(pos && neg)
    }

    /** On-screen size of a 3D layer relative to its flat size (perspective), so a finger drag moves it 1:1. */
    private fun depthScale(l: Layer): Float {
        val q = screenQuad(l)
        val f = Xf.quadCorners(l, Editor.time).map { toScreen(it.first, it.second) }
        val a = hypot((q[1].x - q[0].x).toDouble(), (q[1].y - q[0].y).toDouble())
        val b = hypot((f[1].x - f[0].x).toDouble(), (f[1].y - f[0].y).toDouble())
        if (b <= 1.0) return 1f
        return max(0.05f, min((a / b).toFloat(), 20f))
    }

    private var dragGroup: List<Layer> = emptyList()

    // MARK: - drawing

    private var gDrag = 0          // shape gradient knob being dragged (1 = start, 2 = end)

    private fun gradLayer(): Layer? {
        val l = editHost.selectedLayer() ?: return null
        if (l.type != LayerType.SHAPE || l.gradMode <= 0 || l.shape == com.saiki.motion.core.ShapeKind.PATH) return null
        if (!editHost.gradientKnobsOn()) return null
        return l
    }

    private fun drawGradientKnobs(c: CGContext, l: Layer) {
        val a = quadToScreen(l, l.gradX1, l.gradY1); val b = quadToScreen(l, l.gradX2, l.gradY2)
        val white = 0xFFFFFFFF.toInt()
        strokeLine(c, a.x, a.y, b.x, b.y, 2f, white)
        if (l.gradMode == 2) {
            val r = hypot((b.x - a.x).toDouble(), (b.y - a.y).toDouble()).toFloat()
            c.setStrokeColor(0xCCFFFFFF.toInt()); c.setLineWidth(1.5f)
            c.strokeEllipse(CGRect(a.x - r, a.y - r, r * 2, r * 2))
        }
        for ((i, p) in listOf(a, b).withIndex()) {
            val fill = if (i == 0) l.color else l.color2
            c.setFillColor(fill)
            c.fillEllipse(CGRect(p.x - 13, p.y - 13, 26f, 26f))
            c.setStrokeColor(0xFFFFFFFF.toInt()); c.setLineWidth(3f)
            c.strokeEllipse(CGRect(p.x - 13, p.y - 13, 26f, 26f))
        }
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return

        if (guides) {
            val col = 0x66FFFFFF
            for (i in 1 until 3) {
                val x = rect.width * i / 3
                strokeLine(c, x, 0f, x, rect.height, 1f, col)
                val y = rect.height * i / 3
                strokeLine(c, 0f, y, rect.width, y, 1f, col)
            }
            strokeLine(c, rect.width / 2, 0f, rect.width / 2, rect.height, 1f, col)
            strokeLine(c, 0f, rect.height / 2, rect.width, rect.height / 2, 1f, col)
        }

        if (pick != null) {
            // eyedropper crosshair
            val col = 0xFFFFFFFF.toInt()
            strokeLine(c, rect.width / 2 - 14, rect.height / 2, rect.width / 2 + 14, rect.height / 2, 1.5f, col)
            strokeLine(c, rect.width / 2, rect.height / 2 - 14, rect.width / 2, rect.height / 2 + 14, 1.5f, col)
        }

        val l = editHost.selectedLayer() ?: return
        if (editHost.puppetPanelOpen()) {
            val pp = l.puppet
            if (pp != null) {
                if (!(pp.on && !ext.isHidden)) drawPuppet(c, l, pp)   // the helper view draws it (also outside the comp)
                return
            }
        }
        val group = gizmoLayers(l)
        for (g in group) drawGizmo(c, g, g === l, group.size == 1)
        val gl = gradLayer()
        if (gl != null) drawGradientKnobs(c, gl)
    }

    private fun drawGizmo(c: CGContext, l: Layer, primary: Boolean, handles: Boolean = true) {
        val q = screenQuad(l)

        // selection box
        val sel = if (primary) C.GREEN else 0xFF8FE3A8.toInt()
        c.saveGState()
        c.paint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(6f, 5f), 0f)
        for (i in 0 until 4) {
            val a = q[i]; val b = q[(i + 1) % 4]
            strokeLine(c, a.x, a.y, b.x, b.y, 1.5f, sel)
        }
        c.paint.pathEffect = null
        c.restoreGState()
        // corner handles (skip for camera/null/audio/adjust, and in a multi-selection: highlight only)
        if (handles && (l.isRenderable() || l.type == LayerType.GROUP)) {
            for (p in q) {
                fillCircle(c, p.x, p.y, 7f, 0xFFFFFFFF.toInt())
                fillCircle(c, p.x, p.y, 4f, sel)
            }
            // rotate handle above the top edge midpoint
            val mid = CGPoint((q[0].x + q[1].x) / 2, (q[0].y + q[1].y) / 2)
            val dx = q[1].x - q[0].x; val dy = q[1].y - q[0].y
            val len = max(sqrt(dx * dx + dy * dy), 0.001f)
            // outward = away from the quad centre (never inward)
            var nx = -dy / len; var ny = dx / len
            val cx = (q[0].x + q[1].x + q[2].x + q[3].x) / 4
            val cy = (q[0].y + q[1].y + q[2].y + q[3].y) / 4
            if ((mid.x - cx) * nx + (mid.y - cy) * ny < 0) { nx = -nx; ny = -ny }
            val hp = CGPoint(mid.x + nx * 34, mid.y + ny * 34)
            c.saveGState()
            c.paint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(4f, 4f), 0f)
            strokeLine(c, mid.x, mid.y, hp.x, hp.y, 1.5f, sel)
            c.paint.pathEffect = null
            c.restoreGState()
            fillCircle(c, hp.x, hp.y, 6f, sel)

            // anchor point: ring + crosshair where the layer pivots / rotates / scales from
            val ap = anchorScreen(l)
            val orange = 0xFF00E5FF.toInt()
            strokeLine(c, ap.x - 11, ap.y, ap.x + 11, ap.y, 1.5f, 0xFFFFFFFF.toInt())
            strokeLine(c, ap.x, ap.y - 11, ap.x, ap.y + 11, 1.5f, 0xFFFFFFFF.toInt())
            fillCircle(c, ap.x, ap.y, 6.5f, 0xFFFFFFFF.toInt())
            fillCircle(c, ap.x, ap.y, 4f, orange)
        }
    }

    // MARK: - touches

    override fun touchesBegan(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val p = t.location(this)
        if ((event?.allTouches?.size ?: 1) > 1) { pupPending = null; pupDrag = false; return }

        val pk = pick
        if (pk != null) {
            pk(p.x, p.y)
            pick = null
            setNeedsDisplay()
            return
        }

        val gl = gradLayer()
        if (gl != null) {
            val a = quadToScreen(gl, gl.gradX1, gl.gradY1); val b = quadToScreen(gl, gl.gradX2, gl.gradY2)
            val da = distance(p, a); val db = distance(p, b)
            if (min(da, db) < 34f) {
                gDrag = if (da <= db) 1 else 2
                editHost.beginEdit()
                return
            }
        }
        val pl = editHost.selectedLayer()
        if (pl != null && editHost.puppetPanelOpen()) {
            val pp = pl.puppet
            if (pp != null && pp.on) { puppetBegan(pl, pp, p); return }
        }

        var l = editHost.selectedLayer()
        if (l == null) {
            // tap-select: top-most hit layer (reverse draw order)
            for (layer in Editor.scene.layers.reversed()) {
                if (!layer.visible) continue
                if (!(layer.isRenderable() || layer.type == LayerType.GROUP || layer.type == LayerType.CAMERA
                        || layer.type == LayerType.NULL || layer.type == LayerType.ADJUST)) continue
                if (Editor.time < layer.start - 0.001f || Editor.time > layer.end + 0.001f) continue
                if (hitLayer(layer, p)) {
                    editHost.onSelect(layer.id)
                    setNeedsDisplay()
                    return
                }
            }
            editHost.onSelect(-1)
            setNeedsDisplay()
            return
        }

        val multi = gizmoLayers(l).size > 1
        for (g2 in gizmoLayers(l)) {
            val q = screenQuad(g2)

            // rotate / scale handles only exist for a single selection
            if (!multi && (g2.isRenderable() || g2.type == LayerType.GROUP)) {
                val mid = CGPoint((q[0].x + q[1].x) / 2, (q[0].y + q[1].y) / 2)
                val dx = q[1].x - q[0].x; val dy = q[1].y - q[0].y
                val len = max(sqrt(dx * dx + dy * dy), 0.001f)
                var hx = -dy / len; var hy = dx / len
                val qcx = (q[0].x + q[1].x + q[2].x + q[3].x) / 4
                val qcy = (q[0].y + q[1].y + q[2].y + q[3].y) / 4
                if ((mid.x - qcx) * hx + (mid.y - qcy) * hy < 0) { hx = -hx; hy = -hy }
                val hp = CGPoint(mid.x + hx * 34, mid.y + hy * 34)
                if (distance(p, hp) < 22f) {
                    beginDrag(3, g2, p)
                    startRot = g2.p("rotZ", g2.editTime("rotZ", Editor.time))
                    startCenter = anchorScreen(g2)
                    return
                }
                // corner handle?
                for (cc in q) {
                    if (distance(p, cc) < 24f) {
                        beginDrag(2, g2, p)
                        // measure from the finger (not the corner) so the layer doesn't jump
                        startCenter = anchorScreen(g2)
                        val wc = toWorld(p)
                        val wl = toWorld(startCenter)
                        startDist = max(0.02f, hypot((wc.first - wl.first).toDouble(), (wc.second - wl.second).toDouble()).toFloat())
                        startScale = abs(g2.p("scale", Editor.time))
                        return
                    }
                }
            }
        }

        // inside the quad → move (every selected layer moves together)
        if (gizmoLayers(l).any { hitLayer(it, p) }) {
            beginDrag(1, l, p)
            dragGroup = gizmoLayers(l)
        } else {
            // tap outside: re-select whatever is under the finger
            for (layer in Editor.scene.layers.reversed()) {
                if (!layer.visible) continue
                if (Editor.time < layer.start - 0.001f || Editor.time > layer.end + 0.001f) continue
                if (hitLayer(layer, p)) {
                    editHost.onSelect(layer.id)
                    setNeedsDisplay()
                    return
                }
            }
            editHost.onSelect(-1)
        }
        setNeedsDisplay()
    }

    override fun touchesMoved(touches: Set<UITouch>, event: UIEvent?) {
        val pd = pupPending
        val t0 = touches.firstOrNull()
        if (pd != null && t0 != null) {
            if ((event?.allTouches?.size ?: 1) > 1 || distance(t0.location(this), pd) > 12f) pupPending = null
        }
        if (gDrag != 0) {
            val gl = gradLayer()
            val t = touches.firstOrNull()
            if (gl != null && t != null) {
                val q = screenToQuad(gl, t.location(this))
                if (q != null) {
                    val x = max(-1.5f, min(1.5f, q.first)); val y = max(-1.5f, min(1.5f, q.second))
                    if (gDrag == 1) { gl.gradX1 = x; gl.gradY1 = y } else { gl.gradX2 = x; gl.gradY2 = y }
                    editHost.onEdited()
                    setNeedsDisplay()
                    return
                }
            }
        }
        if (pupDrag) { puppetMoved(touches); return }
        val t = touches.firstOrNull() ?: return
        val l = dragLayer ?: return
        if (dragMode == 0) return
        val p = t.location(this)
        val autoKey = editHost.autoKey()

        when (dragMode) {
            1 -> {   // move — dx/dy in world units
                val w0 = toWorld(dragStart)
                val w1 = toWorld(p)
                val group = if (dragGroup.isEmpty()) listOf(l) else dragGroup
                for (g in group) {
                    val lt = g.editTime("x", Editor.time)
                    var dx = w1.first - w0.first; var dy = w1.second - w0.second
                    if (g.is3d) { val k = depthScale(g); dx /= k; dy /= k }
                    val d = Xf.toParentSpace(g, Editor.time, dx, dy)
                    g.track("x").setMove(lt, g.p("x", lt) + d.first, autoKey)
                    g.track("y").setMove(lt, g.p("y", lt) + d.second, autoKey)
                }
                dragStart = p
                editHost.onEdited()
            }
            2 -> {   // scale by distance from center
                val wc = toWorld(p)
                val wl = toWorld(startCenter)
                val d = max(0.02f, hypot((wc.first - wl.first).toDouble(), (wc.second - wl.second).toDouble()).toFloat())
                val lt = l.editTime("scale", Editor.time)
                // damped so the gizmo is gentle: 1.0 = exactly follows the finger, lower = calmer
                val sens = 0.5f
                val ratio = max(0.02f, 1 + (d / startDist - 1) * sens)
                l.track("scale").setMove(lt, startScale * ratio, autoKey, mul = true)
                editHost.onEdited()
            }
            3 -> {   // rotate around the layer center
                val wc = toWorld(p)
                val wl = toWorld(startCenter)
                val a0 = atan2(dragStartWorld.second - wl.second, dragStartWorld.first - wl.first)
                val a1 = atan2(wc.second - wl.second, wc.first - wl.first)
                val delta = (a1 - a0) * 180f / Math.PI.toFloat()
                val lt = l.editTime("rotZ", Editor.time)
                l.track("rotZ").setMove(lt, startRot + delta, autoKey)
                editHost.onEdited()
            }
        }
        setNeedsDisplay()
    }

    private var dragStartWorld = Pair(0f, 0f)

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        val pd = pupPending
        if (pd != null) {
            pupPending = null
            val active = event?.allTouches?.count { it.phase != com.saiki.motion.uikit.UITouchPhase.ended && it.phase != com.saiki.motion.uikit.UITouchPhase.cancelled } ?: 0
            val l = editHost.selectedLayer()
            val pp = l?.puppet
            if (active == 0 && l != null && pp != null) puppetAddPin(l, pp, pd)
        }
        pupDrag = false
        gDrag = 0
        dragMode = 0
        dragLayer = null
        dragGroup = emptyList()
        setNeedsDisplay()
    }

    override fun touchesCancelled(touches: Set<UITouch>, event: UIEvent?) {
        pupPending = null
        pupDrag = false
        gDrag = 0
        dragMode = 0
        dragLayer = null
        dragGroup = emptyList()
        setNeedsDisplay()
    }

    private fun beginDrag(mode: Int, l: Layer, p: CGPoint) {
        editHost.beginEdit()
        dragMode = mode
        dragLayer = l
        dragStart = p
        dragStartWorld = toWorld(p)
    }

    // MARK: - puppet pins (viewport)

    private var pupDrag = false
    private var pupLast = CGPoint(0f, 0f)
    private var pupMoved = false

    /** quad space (-1...1) → view point */
    private fun quadToScreen(l: Layer, ax: Float, ay: Float): CGPoint {
        val (qw, qh) = Xf.puppetQuad(l)
        val w = Xf.apply(Xf.puppetMatrix(l, Editor.time), ax * qw / 2, ay * qh / 2)
        return toScreen(w.first, w.second)
    }

    /** view point → quad space (-1...1) */
    private fun screenToQuad(l: Layer, p: CGPoint): Pair<Float, Float>? {
        val inv = Xf.invert(Xf.puppetMatrix(l, Editor.time)) ?: return null
        val w = toWorld(p)
        val q = Xf.apply(inv, w.first, w.second)
        val (qw, qh) = Xf.puppetQuad(l)
        if (qw <= 0 || qh <= 0) return null
        return Pair(q.first / (qw / 2), q.second / (qh / 2))
    }

    /** 1 / viewport zoom: multiply any on-screen pin size by this (UIKit transform.a/b = the AspectLayout zoom). */
    private val pinUnit: Float
        get() {
            val sv = superview as? com.saiki.motion.ui.AspectLayout ?: return 1f
            return 1f / max(1f, sv.zoom)
        }

    private fun drawPuppet(c: CGContext, l: Layer, pp: com.saiki.motion.core.Puppet) {
        val acc = C.GREEN
        val m = Xf.puppetMatrix(l, Editor.time)
        val qs = Xf.puppetQuad(l)
        fun scr(ax: Float, ay: Float): CGPoint {
            val w = Xf.apply(m, ax * qs.first / 2, ay * qs.second / 2)
            return toScreen(w.first, w.second)
        }
        val q = listOf(scr(-1f, 1f), scr(1f, 1f), scr(1f, -1f), scr(-1f, -1f))
        c.saveGState()
        c.paint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(6f, 5f), 0f)
        for (i in 0 until 4) strokeLine(c, q[i].x, q[i].y, q[(i + 1) % 4].x, q[(i + 1) % 4].y, 1f, (0x88 shl 24))
        c.paint.pathEffect = null
        c.restoreGState()

        if (pp.showMesh && pp.on && pp.pins.isNotEmpty()) {
            val n = PuppetMath.segs[pp.density]
            val g = PuppetMath.gridPositions(l, pp, Editor.time)
            val pts = ArrayList<CGPoint>((n + 1) * (n + 1))
            for (i in 0 until (n + 1) * (n + 1)) pts.add(scr(g[2 * i], g[2 * i + 1]))
            c.setStrokeColor((acc and 0x00FFFFFF) or (0xCC shl 24))
            c.setLineWidth(1f)
            c.beginPath()
            for (j in 0..n) {
                c.move(pts[j * (n + 1)])
                for (i in 1..n) c.addLine(pts[j * (n + 1) + i])
            }
            for (i in 0..n) {
                c.move(pts[i])
                for (j in 1..n) c.addLine(pts[j * (n + 1) + i])
            }
            c.strokePath()
        }

        val white = 0xFFFFFFFF.toInt()
        val k = pinUnit      // pins keep the same on-screen size at any viewport zoom (the overlay itself is scaled by the zoom)
        val aps = PuppetMath.activePins(l, pp, Editor.time)       // all pins in one pass (physics solved once)
        for ((i, pin) in pp.pins.withIndex()) {
            val pos = Pair(aps[i][0] + aps[i][2], aps[i][1] + aps[i][3])
            val s = scr(pos.first, pos.second)
            if (PuppetEdit.sel.contains(pin.id)) {
                fillCircle(c, s.x, s.y, 16f * k, (acc and 0x00FFFFFF) or (0x66 shl 24))
                fillCircle(c, s.x, s.y, 10f * k, white)
                fillCircle(c, s.x, s.y, 6f * k, acc)
            } else {
                fillCircle(c, s.x, s.y, 9f * k, white)
                fillCircle(c, s.x, s.y, 5f * k, C.BG)
            }
            drawText("${i + 1}", s.x, s.y - 20f * k, color = white, size = 11f * k, bold = true, align = NSTextAlignment.center)
        }
    }

    private fun puppetBegan(l: Layer, pp: com.saiki.motion.core.Puppet, p: CGPoint) {
        pupLast = p; pupMoved = false; pupDrag = false
        var hit: PuppetPin? = null
        var best = 22f * pinUnit
        val m = Xf.puppetMatrix(l, Editor.time)
        val qs = Xf.puppetQuad(l)
        val aps = PuppetMath.activePins(l, pp, Editor.time)
        for ((qi, q) in pp.pins.withIndex()) {
            val pos = Pair(aps[qi][0] + aps[qi][2], aps[qi][1] + aps[qi][3])
            val w = Xf.apply(m, pos.first * qs.first / 2, pos.second * qs.second / 2)
            val d = distance(toScreen(w.first, w.second), p)
            if (d < best) { best = d; hit = q }
        }
        when (PuppetEdit.mode) {
            2 -> {   // multi: tap toggles, drag moves everything selected
                val h = hit
                if (h != null) {
                    val i = PuppetEdit.sel.indexOf(h.id)
                    if (i >= 0) PuppetEdit.sel.removeAt(i) else PuppetEdit.sel.add(h.id)
                    pupDrag = PuppetEdit.sel.contains(h.id)
                    PuppetEdit.onChange?.invoke()
                }
            }
            1 -> {   // select
                val h = hit
                if (h != null) {
                    if (!PuppetEdit.sel.contains(h.id)) { PuppetEdit.sel = mutableListOf(h.id); PuppetEdit.onChange?.invoke() }
                    pupDrag = true
                } else if (PuppetEdit.sel.isNotEmpty()) {
                    PuppetEdit.sel = mutableListOf(); PuppetEdit.onChange?.invoke()
                }
            }
            else -> { // add
                val h = hit
                if (h != null) {
                    if (!PuppetEdit.sel.contains(h.id)) { PuppetEdit.sel = mutableListOf(h.id); PuppetEdit.onChange?.invoke() }
                    pupDrag = true
                } else {
                    pupPending = p   // pin is added on finger-up, only for a clean one-finger tap
                }
            }
        }
    }

    private var pupPending: CGPoint? = null

    private fun puppetAddPin(l: Layer, pp: com.saiki.motion.core.Puppet, p: CGPoint) {
        val a = screenToQuad(l, p) ?: return
        if (abs(a.first) > 6f || abs(a.second) > 6f) return
        editHost.beginEdit()
        val d = PuppetMath.disp(PuppetMath.activePins(l, pp, Editor.time), pp.stiffness, a.first, a.second)
        val q = PuppetPin(pp.nextId, a.first - d.first, a.second - d.second)
        pp.nextId += 1
        pp.pins.add(q)
        l.track("pp${q.id}x").base = d.first
        l.track("pp${q.id}y").base = d.second
        PuppetEdit.sel = mutableListOf(q.id)
        PuppetEdit.onChange?.invoke()
        editHost.onEdited()
    }

    private fun puppetMoved(touches: Set<UITouch>) {
        val t = touches.firstOrNull() ?: return
        val l = editHost.selectedLayer() ?: return
        l.puppet ?: return
        val p = t.location(this)
        val a0 = screenToQuad(l, pupLast) ?: return
        val a1 = screenToQuad(l, p) ?: return
        if (!pupMoved) { editHost.beginEdit(); pupMoved = true }
        val k = if (PuppetEdit.fine) 0.25f else 1f
        val dx = (a1.first - a0.first) * k; val dy = (a1.second - a0.second) * k
        val ak = editHost.autoKey()
        val lt = Editor.time
        for (id in PuppetEdit.sel.toList()) {
            val tx = l.track("pp${id}x"); val ty = l.track("pp${id}y")
            tx.set(lt, tx.eval(lt) + dx, ak)
            ty.set(lt, ty.eval(lt) + dy, ak)
        }
        pupLast = p
        editHost.onEdited()
    }

    private fun distance(a: CGPoint, b: CGPoint): CGFloat =
        hypot((a.x - b.x).toDouble(), (a.y - b.y).toDouble()).toFloat()
}

/** Draws the puppet pins / mesh over the whole visible preview area so pins can live outside the comp. */
class PuppetExtView : UiView(com.saiki.motion.uikit.appContext!!) {
    var owner: OverlayView? = null
    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        owner?.drawExt(c, CGPoint(frame.x, frame.y))
    }
}
