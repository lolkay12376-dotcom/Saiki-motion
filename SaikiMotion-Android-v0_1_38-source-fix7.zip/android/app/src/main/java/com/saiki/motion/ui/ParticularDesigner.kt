@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName", "PropertyName")

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import com.saiki.motion.app.PanelScroll
import com.saiki.motion.app.showColorPicker
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.MetalCam
import com.saiki.motion.core.PtCurve
import com.saiki.motion.core.PtGradient
import com.saiki.motion.core.PtGroup
import com.saiki.motion.core.PtImages
import com.saiki.motion.core.PtParams
import com.saiki.motion.core.PtPath
import com.saiki.motion.core.PtPreset
import com.saiki.motion.core.PtPresetStore
import com.saiki.motion.core.PtBuiltins
import com.saiki.motion.core.PtSprites
import com.saiki.motion.core.ParticularSim
import com.saiki.motion.core.V3
import com.saiki.motion.core.Xf
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.argbToUIColor
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

// Port of Sources/UI/ParticularDesigner.swift — full-screen Particle Designer for the Particular effect.
// Own preview viewport (orbit camera, CPU drawn from the same ParticularSim the renderer uses), a block strip
// (Emitter / Particle / Physics / Displace) and a properties panel. All custom drawn, no system icons.

private val ptAcc = C.GREEN
private val ptOpenFolders = mutableSetOf("Signature")

private val ptBaseKeys: List<String> get() = PtParams.allKeys.filter { !it.startsWith("ptCv") && !it.startsWith("ptPath") && !it.startsWith("ptG") }

private fun ptArgb(l: Layer, k: String, d: Int): Int {
    fun comp(s: String, sh: Int): Int {
        val t = l.props[k + s]
        return if (t != null) max(0, min(255, (t.eval(Editor.time) * 255 + 0.5f).toInt())) else ((d shr sh) and 0xFF)
    }
    return (comp("_a", 24) shl 24) or (comp("_r", 16) shl 16) or (comp("_g", 8) shl 8) or comp("_b", 0)
}

private fun ptStopFrom(argb: Int, p: Float) = com.saiki.motion.core.PtStop(p,
    ((argb shr 16) and 0xFF) / 255f, ((argb shr 8) and 0xFF) / 255f, (argb and 0xFF) / 255f, ((argb shr 24) and 0xFF) / 255f)
private fun ptStopArgb(s: com.saiki.motion.core.PtStop): Int =
    (((s.a * 255 + 0.5f).toInt()) shl 24) or (((s.r * 255 + 0.5f).toInt()) shl 16) or (((s.g * 255 + 0.5f).toInt()) shl 8) or ((s.b * 255 + 0.5f).toInt())

/** One panel item (iOS private enum PtItem). */
private sealed class PtItem {
    class slider(val k: String, val name: String, val lo: Float, val hi: Float, val dec: Int) : PtItem()
    class choice(val k: String, val name: String, val opts: List<String>) : PtItem()
    class color(val k: String, val name: String, val def: Int) : PtItem()
    class graph(val id: String, val title: String) : PtItem()
    class action(val title: String, val id: String) : PtItem()
    object gradient : PtItem()
}

private class PtBlock(val id: String, val title: String, val items: List<PtItem>, val presets: List<Triple<String, Int, Map<String, Float>>>)

private val ptColorPresets: List<Triple<String, Int, Int>> = listOf(
    Triple("Warm", ParticularSim.defA, ParticularSim.defB), Triple("White", 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt()), Triple("Fire", 0xFFFFF2B0.toInt(), 0xFFFF3B00.toInt()), Triple("Ice", 0xFFFFFFFF.toInt(), 0xFF38BDF8.toInt()),
    Triple("Aqualight", 0xFFB6E3C2.toInt(), 0xFF1E9BD7.toInt()), Triple("Autumn", 0xFF3CBF3C.toInt(), 0xFFE8401C.toInt()), Triple("Basic Red", 0xFFFF0000.toInt(), 0xFFFF0000.toInt()),
    Triple("Blue Ramp", 0xFF4B4BFF.toInt(), 0xFF2A2AA0.toInt()), Triple("Neon", 0xFFFF2BD6.toInt(), 0xFF2BFFE0.toInt()), Triple("Gold", 0xFFFFE27A.toInt(), 0xFFC77700.toInt()))

private val ptEmitterPresets: List<Triple<String, Int, Map<String, Float>>> =
    ParticularSim.emitterNames.mapIndexed { i, n -> Triple(n, i, mapOf("ptEmType" to i.toFloat())) }
private val ptMotionPresets: List<Triple<String, Int, Map<String, Float>>> =
    ParticularSim.motionNames.mapIndexed { i, n -> Triple(n, i, mapOf("ptMotion" to i.toFloat())) }

private fun m(vararg pairs: Pair<String, Float>): Map<String, Float> = pairs.toMap()

private val ptBlocks: List<PtBlock> = listOf(
    PtBlock("emitter", "EMITTER TYPE", listOf(
        PtItem.choice("ptEmType", "Emitter Type", ParticularSim.emitterNames),
        PtItem.slider("ptModelLayer", "Model Layer ID (0 = first)", 0f, 100000f, 0),
        PtItem.action("Draw Path in 3D View", "pathDraw"), PtItem.action("Add Stroke to Path", "pathAdd"), PtItem.action("Clear Path", "pathClr"),
        PtItem.choice("ptPathMode", "Path Mode", listOf("Spread along path", "Travelling head")), PtItem.slider("ptPathFlow", "Flow Speed", -2f, 2f, 2),
        PtItem.slider("ptPathSpeed", "Head Speed", 0f, 4f, 2), PtItem.choice("ptPathClosed", "Path Loop", listOf("Open", "Closed")),
        PtItem.choice("ptBehavior", "Emitter Behavior", ParticularSim.behaviorNames),
        PtItem.slider("ptRate", "Particles/sec", 1f, 2000f, 0),
        PtItem.slider("ptPosX", "Position X", -3f, 3f, 2), PtItem.slider("ptPosY", "Position Y", -3f, 3f, 2), PtItem.slider("ptPosZ", "Position Z", -4f, 4f, 2),
        PtItem.slider("ptSizeX", "Radius X", 0f, 4f, 2), PtItem.slider("ptSizeY", "Radius Y", 0f, 4f, 2), PtItem.slider("ptSizeZ", "Radius Z", 0f, 4f, 2),
        PtItem.slider("ptGridN", "Grid cells", 2f, 16f, 0), PtItem.slider("ptSeed", "Random Seed", 0f, 100f, 0)),
        ptEmitterPresets),
    PtBlock("motion", "MOTION", listOf(
        PtItem.choice("ptMotion", "Motion", ParticularSim.motionNames),
        PtItem.slider("ptVel", "Velocity", 0f, 3f, 2), PtItem.slider("ptVelRand", "Velocity Random", 0f, 1f, 2), PtItem.slider("ptSpread", "Spread", 0f, 2f, 2),
        PtItem.slider("ptDirX", "Direction X", -1f, 1f, 2), PtItem.slider("ptDirY", "Direction Y", -1f, 1f, 2), PtItem.slider("ptDirZ", "Direction Z", -1f, 1f, 2),
        PtItem.slider("ptLife", "Particle Life (s)", 0.2f, 20f, 2), PtItem.slider("ptLifeRand", "Life Random", 0f, 1f, 2),
        PtItem.graph("Sp", "Speed over life")),
        ptMotionPresets),
    PtBlock("source", "IMAGE / VIDEO", listOf(
        PtItem.action("Import Image as Emitter", "emImg"), PtItem.action("Import Video as Emitter", "emVid"), PtItem.action("Remove Emitter Media", "emClr"),
        PtItem.slider("ptImgColor", "Use Media Colour", 0f, 1f, 2), PtItem.slider("ptEmFps", "Video Emitter FPS", 0.1f, 60f, 1)),
        emptyList()),
    PtBlock("type", "PARTICLE TYPE", listOf(
        PtItem.choice("ptSprite", "Particle Shape", PtSprites.names),
        PtItem.slider("ptVolume", "Volumetric Shading", 0f, 1f, 2), PtItem.slider("ptVolLight", "Light Angle", -180f, 180f, 0),
        PtItem.action("Import Shape from Image", "spImg"), PtItem.action("Import Shape (black bg → clear)", "spKeyImg"), PtItem.action("Import Shape from Video", "spVid"),
        PtItem.slider("ptBump", "Bump Strength", 0f, 3f, 2), PtItem.action("Import Bump Map", "bpImg"), PtItem.action("Remove Custom Bump Map", "bpClr"), PtItem.slider("ptTumble", "3D Tumble", 0f, 1f, 2),
        PtItem.slider("ptGlow", "Glow", 0f, 3f, 2), PtItem.slider("ptGlowSize", "Glow Size", 0.5f, 6f, 2),
        PtItem.choice("ptSpriteAnim", "Animate Shape (video)", listOf("Off", "On")), PtItem.slider("ptSpriteTint", "Shape Tint", 0f, 1f, 2),
        PtItem.slider("ptSize", "Particle Size", 0.002f, 0.2f, 3), PtItem.slider("ptSoft", "Softness", 0f, 1f, 2),
        PtItem.slider("ptDof", "Depth of Field", 0f, 2f, 2), PtItem.slider("ptFocus", "Focus Depth", -4f, 4f, 2)),
        listOf(Triple("Dot", 0, m("ptSprite" to 0f, "ptSoft" to 0f)), Triple("Sphere", 1, m("ptSprite" to 0f, "ptSoft" to 0.5f)), Triple("Glow Sphere", 2, m("ptSprite" to 0f, "ptSoft" to 1f)),
            Triple("Square", 3, m("ptSprite" to 1f, "ptSpriteTint" to 1f, "ptSoft" to 0f)), Triple("Star", 4, m("ptSprite" to 2f, "ptSpriteTint" to 1f)),
            Triple("Glyph", 5, m("ptSprite" to 3f, "ptSpriteTint" to 1f)), Triple("Petal", 6, m("ptSprite" to 4f, "ptSpriteTint" to 0f)), Triple("Bokeh", 7, m("ptSprite" to 5f, "ptSpriteTint" to 1f)),
            Triple("Cloud", 8, m("ptSprite" to 8f, "ptSpriteTint" to 1f, "ptVolume" to 0.8f, "ptSoft" to 0.4f)), Triple("Leaf", 9, m("ptSprite" to 9f, "ptSpriteTint" to 0f)),
            Triple("Maple Leaf", 10, m("ptSprite" to 10f, "ptSpriteTint" to 0f, "ptBump" to 1.3f, "ptTumble" to 0.8f)))),
    PtBlock("size", "SIZE / ROTATION", listOf(
        PtItem.graph("Sz", "Size over life"),
        PtItem.slider("ptSizeRand", "Size Random", 0f, 1f, 2), PtItem.slider("ptSizeStart", "Size at Birth", 0f, 3f, 2), PtItem.slider("ptSizeEnd", "Size at Death", 0f, 3f, 2)),
        listOf(Triple("Default", 0, m("ptSizeStart" to 1f, "ptSizeEnd" to 1f)), Triple("Grow", 1, m("ptSizeStart" to 0.2f, "ptSizeEnd" to 1.6f)),
            Triple("Shrink", 2, m("ptSizeStart" to 1.6f, "ptSizeEnd" to 0.1f)))),
    PtBlock("opacity", "OPACITY", listOf(
        PtItem.graph("Op", "Opacity over life"),
        PtItem.slider("ptOpacity", "Opacity", 0f, 1f, 2), PtItem.slider("ptFadeIn", "Fade In", 0.001f, 1f, 3), PtItem.slider("ptFadeOut", "Fade Out", 0.001f, 1f, 3)),
        listOf(Triple("Default", 0, m("ptFadeIn" to 0.05f, "ptFadeOut" to 0.3f)), Triple("Bell Curve", 1, m("ptFadeIn" to 0.35f, "ptFadeOut" to 0.35f)),
            Triple("Ease Opacity Mid", 2, m("ptFadeIn" to 0.1f, "ptFadeOut" to 0.6f)), Triple("Linear Fade", 3, m("ptFadeIn" to 0.001f, "ptFadeOut" to 1f)))),
    PtBlock("color", "COLOR", listOf(
        PtItem.color("ptColA", "Birth color", ParticularSim.defA), PtItem.color("ptColB", "Death color", ParticularSim.defB)), emptyList()),
    PtBlock("gradient", "GRADIENT", listOf(
        PtItem.choice("ptGrOn", "Colour over life", listOf("Birth / Death", "Gradient")), PtItem.choice("ptGrBy", "Gradient by", listOf("Life", "Random per particle")), PtItem.gradient),
        emptyList()),
    PtBlock("env", "ENVIRONMENT", listOf(
        PtItem.slider("ptGravity", "Gravity", -3f, 3f, 2), PtItem.slider("ptAir", "Air Resistance", 0f, 1f, 2),
        PtItem.slider("ptWindX", "Wind X", -3f, 3f, 2), PtItem.slider("ptWindY", "Wind Y", -3f, 3f, 2), PtItem.slider("ptWindZ", "Wind Z", -3f, 3f, 2),
        PtItem.slider("ptSwirl", "Swirl (rad/s)", -6f, 6f, 2), PtItem.slider("ptSwirlPull", "Swirl Pull", 0f, 1f, 2),
        PtItem.slider("ptAttract", "Attractor Strength", 0f, 1f, 2), PtItem.slider("ptAttX", "Attractor X", -3f, 3f, 2),
        PtItem.slider("ptAttY", "Attractor Y", -3f, 3f, 2), PtItem.slider("ptAttZ", "Attractor Z", -3f, 3f, 2),
        PtItem.choice("ptFloorOn", "Floor", listOf("Off", "On")), PtItem.slider("ptFloorY", "Floor Y", -3f, 3f, 2), PtItem.slider("ptBounce", "Bounce", 0f, 1f, 2)),
        listOf(Triple("Off", 0, m("ptGravity" to 0f, "ptWindX" to 0f, "ptWindY" to 0f, "ptWindZ" to 0f, "ptAir" to 0f, "ptSwirl" to 0f, "ptSwirlPull" to 0f, "ptAttract" to 0f, "ptFloorOn" to 0f)),
            Triple("Gravity", 1, m("ptGravity" to 1f, "ptAir" to 0.2f)), Triple("Wind", 1, m("ptWindX" to 1.2f)),
            Triple("Vortex", 1, m("ptSwirl" to 2.5f, "ptSwirlPull" to 0.3f)), Triple("Black Hole", 1, m("ptAttract" to 0.9f, "ptSwirl" to 3f)),
            Triple("Floor Bounce", 2, m("ptGravity" to 1.5f, "ptFloorOn" to 1f, "ptFloorY" to -1f, "ptBounce" to 0.6f)))),
    PtBlock("curl", "CURL NOISE", listOf(
        PtItem.slider("ptCurl", "Curl Strength", 0f, 3f, 2), PtItem.slider("ptCurlScale", "Curl Scale", 0.05f, 5f, 2), PtItem.slider("ptCurlSpeed", "Curl Speed", 0f, 5f, 2)),
        listOf(Triple("Off", 0, m("ptCurl" to 0f)), Triple("Soft", 1, m("ptCurl" to 0.6f, "ptCurlScale" to 1f)), Triple("Strong", 2, m("ptCurl" to 1.6f, "ptCurlScale" to 1.2f)),
            Triple("Wild", 3, m("ptCurl" to 2.6f, "ptCurlScale" to 2.2f, "ptCurlSpeed" to 1.5f)), Triple("Slow Swirl", 4, m("ptCurl" to 1.2f, "ptCurlScale" to 0.4f, "ptCurlSpeed" to 0.2f)))),
    PtBlock("wave", "FLUID WAVE", listOf(
        PtItem.slider("ptWaveAmp", "Wave Height", 0f, 2f, 2), PtItem.slider("ptWaveFreq", "Wave Frequency", 0f, 10f, 2),
        PtItem.slider("ptWaveSpeed", "Wave Speed", -8f, 8f, 2), PtItem.slider("ptWaveFlow", "Wave Flow", -3f, 3f, 2)),
        listOf(Triple("Off", 0, m("ptWaveAmp" to 0f, "ptWaveFlow" to 0f)), Triple("Ripple", 1, m("ptWaveAmp" to 0.08f, "ptWaveFreq" to 6f, "ptWaveSpeed" to 3f)),
            Triple("Ocean", 2, m("ptWaveAmp" to 0.25f, "ptWaveFreq" to 3f, "ptWaveSpeed" to 2f)), Triple("Flag", 3, m("ptWaveAmp" to 0.15f, "ptWaveFreq" to 4f, "ptWaveSpeed" to 4f, "ptWaveFlow" to 0.5f)),
            Triple("Tsunami", 4, m("ptWaveAmp" to 0.6f, "ptWaveFreq" to 1.5f, "ptWaveSpeed" to 1.5f)))),
    PtBlock("flutter", "FLUTTER / SPIN", listOf(
        PtItem.slider("ptFlutter", "Flutter", 0f, 3f, 2), PtItem.slider("ptFlutterFreq", "Flutter Speed", 0.1f, 10f, 2),
        PtItem.slider("ptSpin", "Spin (rad/s)", -10f, 10f, 2), PtItem.slider("ptSpinRand", "Spin Random", 0f, 1f, 2)),
        listOf(Triple("Off", 0, m("ptFlutter" to 0f, "ptSpin" to 0f, "ptSpinRand" to 0f)), Triple("Petal Sway", 1, m("ptFlutter" to 1.2f, "ptFlutterFreq" to 2.2f, "ptSpin" to 1.6f, "ptSpinRand" to 1f)),
            Triple("Leaf", 2, m("ptFlutter" to 2f, "ptFlutterFreq" to 1.2f, "ptSpin" to 1f, "ptSpinRand" to 1f)), Triple("Tumble", 3, m("ptFlutter" to 0.3f, "ptFlutterFreq" to 3f, "ptSpin" to 5f, "ptSpinRand" to 1f)))),
    PtBlock("trail", "TRAILS", listOf(
        PtItem.slider("ptTrail", "Trail Copies", 0f, 10f, 0), PtItem.slider("ptTrailLen", "Trail Length (s)", 0.02f, 2f, 2),
        PtItem.slider("ptMBlur", "Motion Blur", 0f, 4f, 2), PtItem.slider("ptMBSamples", "Blur Samples", 3f, 10f, 0)),
        listOf(Triple("Off", 0, m("ptTrail" to 0f)), Triple("Short", 1, m("ptTrail" to 3f, "ptTrailLen" to 0.15f)), Triple("Long", 2, m("ptTrail" to 8f, "ptTrailLen" to 0.7f)), Triple("Comet", 3, m("ptTrail" to 10f, "ptTrailLen" to 1.2f)))),
    PtBlock("shock", "SHOCKWAVE", listOf(
        PtItem.slider("ptShockAmp", "Push Strength", 0f, 3f, 2), PtItem.slider("ptShockSpeed", "Wave Speed", 0f, 6f, 2), PtItem.slider("ptShockWidth", "Wave Width", 0.02f, 1f, 2),
        PtItem.slider("ptShockPeriod", "Repeat every (s, 0 = once)", 0f, 10f, 2), PtItem.slider("ptShockGlow", "Glow in the wave", 0f, 4f, 2)),
        listOf(Triple("Off", 0, m("ptShockAmp" to 0f)), Triple("Pulse", 1, m("ptShockAmp" to 0.3f, "ptShockSpeed" to 1.2f, "ptShockWidth" to 0.12f, "ptShockPeriod" to 2f, "ptShockGlow" to 2f)),
            Triple("Ripple", 2, m("ptShockAmp" to 0.15f, "ptShockSpeed" to 0.8f, "ptShockWidth" to 0.2f, "ptShockPeriod" to 1.2f, "ptShockGlow" to 1f)),
            Triple("Blast", 3, m("ptShockAmp" to 1.2f, "ptShockSpeed" to 2f, "ptShockWidth" to 0.08f, "ptShockPeriod" to 3f, "ptShockGlow" to 3f)),
            Triple("Slow Ring", 4, m("ptShockAmp" to 0.5f, "ptShockSpeed" to 0.5f, "ptShockWidth" to 0.3f, "ptShockPeriod" to 4f, "ptShockGlow" to 2f)))),
    PtBlock("field", "FIELDS", listOf(
        PtItem.slider("ptTurb", "Turbulence", 0f, 3f, 2), PtItem.slider("ptTurbFreq", "Turbulence Scale", 0.05f, 5f, 2), PtItem.slider("ptTurbSpeed", "Turbulence Speed", 0f, 5f, 2)),
        listOf(Triple("Off", 0, m("ptTurb" to 0f)), Triple("Turbulence", 1, m("ptTurb" to 1f)))),
    PtBlock("scatter", "DISSOLVE", listOf(
        PtItem.choice("ptBehavior", "Emitter Behavior (pick Dissolve)", ParticularSim.behaviorNames),
        PtItem.slider("ptScatter", "Scatter", 0f, 4f, 2), PtItem.slider("ptDissStart", "Dissolve Start (s)", 0f, 10f, 2),
        PtItem.slider("ptDissDur", "Dissolve Duration (s)", 0.05f, 10f, 2), PtItem.slider("ptDissSweep", "Sweep (0 random, 1 left to right)", 0f, 1f, 2)),
        listOf(Triple("Off", 0, m("ptScatter" to 0f)), Triple("Dust", 1, m("ptScatter" to 1.2f)), Triple("Blow Away", 2, m("ptScatter" to 0.6f, "ptWindX" to 1.2f)),
            Triple("Sweep", 3, m("ptDissSweep" to 1f, "ptScatter" to 0.8f)))),
    PtBlock("quant", "GRID SNAP", listOf(PtItem.slider("ptQuant", "Cell Size", 0f, 0.5f, 3)),
        listOf(Triple("Off", 0, m("ptQuant" to 0f)), Triple("Fine", 1, m("ptQuant" to 0.04f)), Triple("Coarse", 2, m("ptQuant" to 0.1f)), Triple("Chunky", 3, m("ptQuant" to 0.2f)))),
    PtBlock("twinkle", "TWINKLE", listOf(PtItem.slider("ptTwinkle", "Twinkle", 0f, 1f, 2), PtItem.slider("ptTwinkleRate", "Twinkle Rate", 0.1f, 20f, 2)),
        listOf(Triple("Off", 0, m("ptTwinkle" to 0f)), Triple("Soft", 1, m("ptTwinkle" to 0.4f, "ptTwinkleRate" to 2f)), Triple("Strong", 2, m("ptTwinkle" to 0.9f, "ptTwinkleRate" to 6f))))
)
private val ptTabs: List<Pair<String, List<String>>> = listOf(Pair("Presets", listOf("presets")), Pair("Emitter", listOf("emitter", "motion", "source")),
    Pair("Particle", listOf("type", "size", "opacity", "color", "gradient")),
    Pair("Physics", listOf("env", "curl", "wave", "flutter", "trail", "shock")), Pair("Displace", listOf("field", "scatter", "quant", "twinkle")))
private val ptThumbBlocks = setOf("emitter", "motion", "source", "type", "env", "curl", "wave", "flutter", "trail", "shock", "field", "scatter", "quant", "twinkle")

/// Thumbnail recipe for a block tile: a small demo emitter that shows what the block's settings do.
private class PtThumbSpec(val key: String, val p: Map<String, Float>, val t: Float, val yaw: CGFloat, val pitch: CGFloat, val dist: CGFloat)

private fun ptThumbSpec(id: String, over: Map<String, Float>): PtThumbSpec? {
    var t = 2f
    var yaw = 0.25f; var pitch = 0.12f; var dist = 3.3f
    val stream = m("ptEmType" to 1f, "ptSizeX" to 0.5f, "ptSizeY" to 0.02f, "ptSizeZ" to 0.2f, "ptPosY" to -0.6f, "ptMotion" to 2f, "ptDirY" to 1f, "ptVel" to 0.7f,
        "ptSpread" to 0.15f, "ptRate" to 50f, "ptLife" to 3f, "ptSize" to 0.012f, "ptSoft" to 0.5f)
    var p: Map<String, Float> = emptyMap()
    var tt = 2f
    when (id) {
        "emitter" -> {
            val ty = Math.round(over["ptEmType"] ?: 0f).toInt()
            return PtThumbSpec("e$ty", PtThumb.emitterParams(ty), 1f, 0.55f, 0.35f, 2.2f)
        }
        "motion" -> {
            p = m("ptEmType" to 0f, "ptVel" to 0.6f, "ptRate" to 120f, "ptLife" to 2.5f, "ptSize" to 0.014f, "ptSpread" to 0.6f, "ptVelRand" to 0.3f, "ptSoft" to 0.5f, "ptDirY" to 1f)
            p = p + m("ptMotion" to (over["ptMotion"] ?: 0f)); tt = 1.5f; dist = 2.6f
            return PtThumbSpec("m${Math.round(p["ptMotion"] ?: 0f).toInt()}", p, tt, 0.4f, 0.25f, dist)
        }
        "type" -> { p = m("ptEmType" to 6f, "ptSizeX" to 0.6f, "ptVel" to 0f, "ptRate" to 2f, "ptLife" to 2f, "ptSize" to 0.12f, "ptSizeRand" to 0f, "ptBehavior" to 1f, "ptFadeIn" to 0.001f, "ptFadeOut" to 0.001f); tt = 1f; dist = 2.4f }
        "wave" -> { p = m("ptEmType" to 1f, "ptSizeX" to 1.2f, "ptSizeY" to 0.01f, "ptSizeZ" to 0.6f, "ptVel" to 0f, "ptRate" to 300f, "ptLife" to 4f, "ptLifeRand" to 0f, "ptSize" to 0.01f, "ptSoft" to 0.5f,
            "ptWaveFreq" to 3f, "ptFadeIn" to 0.1f, "ptFadeOut" to 0.1f); pitch = 0.3f }
        "shock" -> { p = m("ptEmType" to 16f, "ptSizeX" to 0.9f, "ptSizeY" to 0.9f, "ptVel" to 0f, "ptRate" to 700f, "ptLife" to 4f, "ptLifeRand" to 0f, "ptSize" to 0.008f, "ptFadeIn" to 0.2f, "ptFadeOut" to 0.2f, "ptShockPeriod" to 2f); tt = 1.2f }
        "scatter" -> { p = m("ptEmType" to 11f, "ptBehavior" to 2f, "ptSizeX" to 0.6f, "ptSizeY" to 0.6f, "ptRate" to 600f, "ptLife" to 2f, "ptVel" to 0.1f, "ptDissStart" to 0.2f, "ptDissDur" to 1.5f, "ptSize" to 0.008f, "ptSoft" to 0.3f); tt = 1.2f }
        "source" -> { p = m("ptEmType" to 11f, "ptSizeX" to 0.8f, "ptSizeY" to 0.8f, "ptVel" to 0f, "ptRate" to 400f, "ptLife" to 2f, "ptSize" to 0.012f, "ptSoft" to 0.3f, "ptBehavior" to 1f, "ptFadeIn" to 0.001f, "ptFadeOut" to 0.001f); tt = 1f; dist = 2.6f }
        "env", "curl", "flutter", "trail", "field", "quant", "twinkle" -> p = stream
        else -> return null
    }
    if (p.isEmpty()) p = stream
    val merged = p + over
    val key = id + ":" + over.toSortedMap().map { "${it.key}=${it.value}" }.joinToString(",")
    t = tt
    return PtThumbSpec(key, merged, t, yaw, pitch, dist)
}

// MARK: - Block art (custom drawn)

private fun ptArt(c: com.saiki.motion.uikit.CGContext, kind: String, v: Int, r: CGRect, ca: Int? = null, cb: Int? = null) {
    c.saveGState(); c.clip(to = r)
    c.setFillColor(0xFF0A0A0A.toInt()); c.fill(r)
    val cx = r.midX; val cy = r.midY; val s = min(r.width, r.height)
    val w = 0xFFFFFFFF.toInt(); val a = ptAcc
    fun dot(x: Float, y: Float, d: Float, col: Int = w) {
        c.setFillColor(col); c.fillEllipse(CGRect(x - d / 2f, y - d / 2f, d, d))
    }
    fun line(x0: Float, y0: Float, x1: Float, y1: Float, col: Int = w, lw: Float = 1.2f) {
        c.setStrokeColor(col); c.setLineWidth(lw); c.move(CGPoint(x0, y0)); c.addLine(CGPoint(x1, y1)); c.strokePath()
    }
    fun rnd(i: Int): Float = (((i * 7919 + 13) % 1000).toFloat()) / 1000f
    when (kind) {
        "emitter" -> for (i in 0 until 46) {
            val u = rnd(i); val q = rnd(i + 99)
            when (v) {
                1 -> dot(cx + (u - 0.5f) * s * 0.7f, cy + (q - 0.5f) * s * 0.7f, 2f)
                2 -> { val an = u * 6.283f; val rr = sqrt(q) * s * 0.36f; dot(cx + cos(an) * rr, cy + sin(an) * rr, 2f) }
                3 -> dot(cx + ((i % 7) - 3) * s * 0.1f, cy + ((i / 7 % 6) - 2.5f) * s * 0.1f, 2f)
                else -> { val an = u * 6.283f; val rr = q * s * 0.1f; dot(cx + cos(an) * rr, cy + sin(an) * rr, 2.4f, a) }
            }
        }
        "motion" -> for (i in 0 until 18) {
            val an = i / 18f * 6.283f
            when (v) {
                1 -> if (abs(cos(an)) > 0.8f) line(cx, cy, cx + cos(an) * s * 0.42f, cy + sin(an) * s * 0.42f * 0.3f, a)
                2 -> if (cos(an) > 0.5f) line(cx - s * 0.3f, cy, cx - s * 0.3f + cos(an) * s * 0.7f, cy + sin(an) * s * 0.5f, a)
                3 -> line(cx + cos(an) * s * 0.12f, cy + sin(an) * s * 0.04f, cx + cos(an) * s * 0.42f, cy + sin(an) * s * 0.14f, a)
                4 -> line(cx + cos(an) * s * 0.42f, cy + sin(an) * s * 0.42f, cx + cos(an) * s * 0.1f, cy + sin(an) * s * 0.1f, a)
                else -> line(cx + cos(an) * s * 0.06f, cy + sin(an) * s * 0.06f, cx + cos(an) * s * 0.42f, cy + sin(an) * s * 0.42f, a)
            }
        }
        "type" -> {
            val hard: Float = if (v == 0) 0.92f else (if (v == 1) 0.5f else 0f)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = android.graphics.RadialGradient(cx, cy, s * 0.4f, intArrayOf(w, w, 0),
                floatArrayOf(0f, min(1f, hard), 1f), Shader.TileMode.CLAMP)
            c.canvas.drawCircle(cx, cy, s * 0.4f, p)
        }
        "size" -> {
            val sz = if (v == 1) listOf(0.06f, 0.1f, 0.15f, 0.21f) else (if (v == 2) listOf(0.21f, 0.15f, 0.1f, 0.06f) else listOf(0.12f, 0.12f, 0.12f, 0.12f))
            for ((i, d) in sz.withIndex()) dot(r.minX + s * (0.2f + i * 0.2f), cy, d * s * 1.6f, if (i % 2 == 0) w else a)
        }
        "opacity", "color" -> {
            if (kind == "color") {
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.shader = LinearGradient(0f, 0f, r.width, 0f, ca ?: w, cb ?: w, Shader.TileMode.CLAMP)
                val b = r.insetBy(s * 0.2f, s * 0.2f)
                c.saveGState(); c.clip(to = b); c.canvas.drawRect(0f, 0f, r.width, r.height, p); c.restoreGState()
            } else {
                val b = r.insetBy(s * 0.15f, s * 0.22f)
                c.beginPath()
                c.move(CGPoint(b.minX, b.maxY))
                when (v) {
                    1 -> { c.addLine(CGPoint(b.minX + b.width * 0.3f, b.minY)); c.addLine(CGPoint(b.minX + b.width * 0.7f, b.minY)) }
                    2 -> { c.addLine(CGPoint(b.minX + b.width * 0.15f, b.minY)); c.addLine(CGPoint(b.minX + b.width * 0.5f, b.minY)) }
                    3 -> c.addLine(CGPoint(b.minX, b.minY))
                    else -> { c.addLine(CGPoint(b.minX, b.minY)); c.addLine(CGPoint(b.maxX, b.minY)) }
                }
                c.addLine(CGPoint(b.maxX, if (v == 0) b.minY else (if (v == 3) b.maxY else b.maxY))); c.addLine(CGPoint(b.maxX, b.maxY)); c.closeSubpath()
                c.setFillColor(0xD9FF8A1F.toInt()); c.fillPath()
            }
        }
        "env" -> for (i in 0 until 5) {
            val x0 = r.minX + s * (0.2f + i * 0.15f)
            c.setStrokeColor(0xCCFFFFFF.toInt()); c.setLineWidth(1.2f)
            c.move(CGPoint(x0, r.minY + s * 0.15f))
            c.addQuadCurve(CGPoint(x0 + s * 0.2f, r.maxY - s * 0.1f), CGPoint(x0 + s * 0.02f, cy)); c.strokePath()
        }
        "act_import", "act_export" -> {
            val up = kind == "act_export"
            val top = cy - s * 0.28f; val bot = cy + s * 0.14f
            line(cx, top, cx, bot, a, 2.4f)
            val tip = if (up) top else bot; val dir = if (up) 1f else -1f
            line(cx, tip, cx - s * 0.13f, tip + dir * s * 0.13f, a, 2.4f); line(cx, tip, cx + s * 0.13f, tip + dir * s * 0.13f, a, 2.4f)
            line(cx - s * 0.3f, cy + s * 0.3f, cx + s * 0.3f, cy + s * 0.3f, w, 2f); line(cx - s * 0.3f, cy + s * 0.2f, cx - s * 0.3f, cy + s * 0.3f, w, 2f); line(cx + s * 0.3f, cy + s * 0.2f, cx + s * 0.3f, cy + s * 0.3f, w, 2f)
        }
        "act_save" -> { line(cx - s * 0.25f, cy, cx + s * 0.25f, cy, a, 3f); line(cx, cy - s * 0.25f, cx, cy + s * 0.25f, a, 3f) }
        else -> for (i in 0 until 5) {   // field
            val t = r.minY + s * (0.2f + i * 0.15f)
            c.setStrokeColor(0xE6FF8A1F.toInt()); c.setLineWidth(1f)
            c.move(CGPoint(r.minX + s * 0.12f, t))
            c.addCurve(CGPoint(r.maxX - s * 0.12f, t), CGPoint(cx - s * 0.1f, t - s * 0.14f), CGPoint(cx + s * 0.1f, t + s * 0.14f)); c.strokePath()
        }
    }
    c.restoreGState()
}

// MARK: - Tiles

private class PtTile : TapView() {
    var kind = "emitter"; var variant = 0; var title = ""; var value = ""; var picked = false
    var ca: Int? = null; var cb: Int? = null
    var thumb: UIImage? = null
    var stops: List<com.saiki.motion.core.PtStop>? = null

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val art = CGRect(0f, 0f, rect.width, rect.height - 34f)
        val st = stops
        if (st != null && st.count() >= 2) {
            c.setFillColor(0xFF0A0A0A.toInt()); c.fill(art)
            val cols = IntArray(st.size) { i -> (((st[i].a * 255).toInt()) shl 24) or (((st[i].r * 255).toInt()) shl 16) or (((st[i].g * 255).toInt()) shl 8) or ((st[i].b * 255).toInt()) }
            val loc = FloatArray(st.size) { i -> st[i].p }
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = LinearGradient(0f, 0f, art.width, 0f, cols, loc, Shader.TileMode.CLAMP)
            val b = art.insetBy(art.width * 0.12f, art.height * 0.28f)
            c.saveGState(); c.clip(to = b)
            c.canvas.drawRect(0f, 0f, art.width, art.height, p)
            c.restoreGState()
        } else if (thumb != null) {
            c.saveGState(); c.clip(to = art)
            val s2 = max(art.width, art.height)
            c.canvas.drawBitmap(thumb!!.bitmap, null, RectF(art.midX - s2 / 2f, art.midY - s2 / 2f, art.midX + s2 / 2f, art.midY + s2 / 2f),
                Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
            c.restoreGState()
        } else {
            ptArt(c, kind, variant, art, ca, cb)
        }
        c.setFillColor(if (picked) 0xFFFFFFFF.toInt() else 0xFF9E9E9E.toInt())
        c.fill(CGRect(0f, art.maxY, rect.width, 34f))
        drawText(title, rect.width / 2f, art.maxY + 13f, color = 0xFF000000.toInt(), size = 10.5f, align = NSTextAlignment.center)
        if (value.isNotEmpty()) drawText(value, rect.width / 2f, art.maxY + 26f, color = 0xFF333333.toInt(), size = 10f, align = NSTextAlignment.center)
        if (picked) { c.setStrokeColor(ptAcc); c.setLineWidth(2.5f); c.stroke(rect.insetBy(1.25f, 1.25f)) }
    }
}

/// Big preset tile: a real render of the particle with its name underneath.
private class PtPresetTile : TapView() {
    var title = ""; var sub = ""
    var thumb: UIImage? = null
    var onLong: (() -> Unit)? = null

    init {
        val lp = com.saiki.motion.uikit.UILongPressGestureRecognizer { g ->
            if (g.state == com.saiki.motion.uikit.UIGestureRecognizerState.began) { isHighlighted = false; onLong?.invoke() }
        }
        addGestureRecognizer(lp)
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val art = CGRect(0f, 0f, rect.width, rect.height - 34f)
        c.setFillColor(0xFF070707.toInt()); c.fill(art)
        if (thumb != null) {
            c.saveGState(); c.clip(to = art)
            val s2 = max(art.width, art.height)
            c.canvas.drawBitmap(thumb!!.bitmap, null, RectF(art.midX - s2 / 2f, art.midY - s2 / 2f, art.midX + s2 / 2f, art.midY + s2 / 2f),
                Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
            c.restoreGState()
        }
        c.setFillColor(C.CARD2); c.fill(CGRect(0f, art.maxY, rect.width, 34f))
        drawText(title, rect.width / 2f, art.maxY + 14f, color = C.TEXT, size = 12f, bold = true, align = NSTextAlignment.center)
        drawText(sub, rect.width / 2f, art.maxY + 27f, color = C.DIM, size = 10f, align = NSTextAlignment.center)
        if (isHighlighted) { c.setStrokeColor(ptAcc); c.setLineWidth(2.5f); c.stroke(rect.insetBy(1.25f, 1.25f)) }
    }
}

private class PtPresetGrid : UiView(com.saiki.motion.uikit.appContext!!) {
    var cols = 3; var tileH: Float = 100f

    override fun layoutSubviews() {
        super.layoutSubviews()
        val tw = (rectWidth() - 8f * (cols - 1)) / cols
        for ((i, v) in subviews.withIndex()) {
            v.frame = CGRect((i % cols) * (tw + 8f), (i / cols) * (tileH + 8f), tw, tileH)
        }
    }
}

private class PtGlyph : TapView() {
    var kind = "play"
    /** Transport slot (back/play/next) — iOS used view.tag; this layer has no tag storage. */
    var ptGlyphIndex = -1

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val m = rect.midX; val n = rect.midY; val s = 8f
        c.setFillColor(if (isHighlighted) ptAcc else 0xFFFFFFFF.toInt())
        when (kind) {
            "pause" -> { c.fill(CGRect(m - s * 0.8f, n - s, s * 0.55f, s * 2f)); c.fill(CGRect(m + s * 0.25f, n - s, s * 0.55f, s * 2f)) }
            "back", "next" -> {
                val d = if (kind == "back") -1f else 1f
                c.move(CGPoint(m - d * s * 0.5f, n - s)); c.addLine(CGPoint(m + d * s * 0.8f, n)); c.addLine(CGPoint(m - d * s * 0.5f, n + s)); c.fillPath()
                c.fill(CGRect(m - d * s * 0.8f - 1f, n - s, 2f, s * 2f))
            }
            else -> { c.move(CGPoint(m - s * 0.6f, n - s)); c.addLine(CGPoint(m + s, n)); c.addLine(CGPoint(m - s * 0.6f, n + s)); c.fillPath() }
        }
    }
}

// MARK: - Custom life graph (add / move / remove points)

private class PtGraphView : com.saiki.motion.uikit.UIControl(com.saiki.motion.uikit.appContext!!) {
    var cid = "Op"; var range: Float = 1f
    var lay: Layer? = null
    var onEdit: (() -> Unit)? = null
    var pts: List<Pair<Float, Float>> = emptyList()
        private set
    private var sel = -1
    var pre = ""
    private var lastTap = 0L

    fun load() {
        val l = lay ?: return
        pts = PtCurve.read({ l.p(pre + it, Editor.time) }, cid)
        if (pts.count() < 2) pts = PtCurve.defaults[cid] ?: listOf(Pair(0f, 0.5f), Pair(1f, 0.5f))
        sel = -1; setNeedsDisplay()
    }
    private val plot: CGRect get() = boundsRect.insetBy(34f, 16f)
    private fun toPt(p: Pair<Float, Float>): CGPoint = CGPoint(plot.minX + p.first * plot.width, plot.maxY - p.second * plot.height)
    private fun fromPt(q: CGPoint): Pair<Float, Float> =
        Pair(min(1f, max(0f, (q.x - plot.minX) / plot.width)), min(1f, max(0f, (plot.maxY - q.y) / plot.height)))
    private fun commit() { lay?.let { PtCurve.write(it, cid, pts, pre) }; onEdit?.invoke() }
    fun removeSelected() { if (sel > 0 && sel < pts.count() - 1) { pts = pts.toMutableList().also { it.removeAt(sel) }; sel = -1; commit(); setNeedsDisplay() } }
    fun reset() { pts = PtCurve.defaults[cid] ?: pts; sel = -1; commit(); setNeedsDisplay() }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        c.setFillColor(0xFF0D0D0D.toInt()); c.fill(boundsRect)
        val pl = plot
        c.setStrokeColor(0x17FFFFFF.toInt()); c.setLineWidth(1f)
        for (i in 0..4) {
            val x = pl.minX + pl.width * i / 4f; val y = pl.minY + pl.height * i / 4f
            c.move(CGPoint(x, pl.minY)); c.addLine(CGPoint(x, pl.maxY))
            c.move(CGPoint(pl.minX, y)); c.addLine(CGPoint(pl.maxX, y))
        }
        c.strokePath()
        drawText(String.format(Locale.US, "%.1f", range), 6f, pl.minY - 6f + 8f, color = 0xFF8C8C8C.toInt(), size = 10f)
        drawText("0", 6f, pl.maxY - 6f + 8f, color = 0xFF8C8C8C.toInt(), size = 10f)
        drawText("Birth", pl.minX, pl.maxY + 12f, color = 0xFF8C8C8C.toInt(), size = 10f)
        drawText("Death", pl.maxX - 28f, pl.maxY + 12f, color = 0xFF8C8C8C.toInt(), size = 10f)
        c.beginPath()
        for ((i, p) in pts.withIndex()) { val q = toPt(p); if (i == 0) c.move(q) else c.addLine(q) }
        val strokePath = com.saiki.motion.uikit.CGPath()
        for ((i, p) in pts.withIndex()) { val q = toPt(p); if (i == 0) strokePath.move(q) else strokePath.addLine(q) }
        val fill = com.saiki.motion.uikit.CGPath()
        for ((i, p) in pts.withIndex()) { val q = toPt(p); if (i == 0) fill.move(q) else fill.addLine(q) }
        val f = pts.firstOrNull(); val l = pts.lastOrNull()
        if (f != null && l != null) { fill.addLine(CGPoint(toPt(l).x, pl.maxY)); fill.addLine(CGPoint(toPt(f).x, pl.maxY)); fill.closeSubpath() }
        c.setFillColor(0x29FF8A1F.toInt()); c.addPath(fill.path); c.fillPath()
        c.setStrokeColor(ptAcc); c.setLineWidth(2f); c.addPath(strokePath.path); c.strokePath()
        for ((i, p) in pts.withIndex()) {
            val q = toPt(p); val r = if (i == sel) 8f else 6f
            c.setFillColor(if (i == sel) 0xFFFFFFFF.toInt() else ptAcc)
            c.fillEllipse(CGRect(q.x - r, q.y - r, r * 2f, r * 2f))
        }
        if (sel >= 0 && sel < pts.count()) {
            val p = pts[sel]
            val txt = String.format(Locale.US, "life %.0f%%   value %.2f", p.first * 100f, p.second * range)
            drawText(txt, pl.minX + 6f, pl.minY + 12f, color = 0xFFFFFFFF.toInt(), size = 11f, bold = true)
        }
    }

    override fun touchesBegan(touches: Set<com.saiki.motion.uikit.UITouch>, with: com.saiki.motion.uikit.UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val q = t.location(this)
        val now = android.os.SystemClock.uptimeMillis()
        val doubleTap = now - lastTap < 320
        lastTap = now
        var best = -1; var bd = 28f
        for ((i, p) in pts.withIndex()) { val c2 = toPt(p); val d = hypot((c2.x - q.x).toDouble(), (c2.y - q.y).toDouble()).toFloat(); if (d < bd) { bd = d; best = i } }
        if (best >= 0) {
            sel = best
            if (doubleTap) { removeSelected(); return }
        } else if (pts.count() < PtCurve.cap) {
            val n = fromPt(q)
            pts = pts + n
            pts = pts.sortedBy { it.first }
            sel = pts.indexOfFirst { it.first == n.first && it.second == n.second }
            commit()
        }
        setNeedsDisplay()
    }
    override fun touchesMoved(touches: Set<com.saiki.motion.uikit.UITouch>, with: com.saiki.motion.uikit.UIEvent?) {
        val t = touches.firstOrNull() ?: return
        if (sel < 0 || sel >= pts.count()) return
        var n = fromPt(t.location(this))
        if (sel == 0) n = Pair(0f, n.second)
        else if (sel == pts.count() - 1) n = Pair(1f, n.second)
        else n = Pair(min(max(n.first, pts[sel - 1].first + 0.01f), pts[sel + 1].first - 0.01f), n.second)
        pts = pts.toMutableList().also { it[sel] = n }; commit(); setNeedsDisplay()
    }
}

// MARK: - Gradient editor (tap the bar to add a stop, drag to move, double-tap to remove)

private class PtGradView : com.saiki.motion.uikit.UIControl(com.saiki.motion.uikit.appContext!!) {
    var lay: Layer? = null
    var onEdit: (() -> Unit)? = null
    var onEnd: (() -> Unit)? = null
    var onPick: ((Int, (Int) -> Unit) -> Unit)? = null
    var stops: List<com.saiki.motion.core.PtStop> = emptyList()
        private set
    private var sel = 0
    var pre = ""
    private var lastTap = 0L

    fun load() {
        val l = lay ?: return
        stops = PtGradient.read({ l.p(pre + it, Editor.time) })
        if (stops.count() < 2) stops = listOf(ptStopFrom(ptArgb(l, pre + "ptColA", ParticularSim.defA), 0f), ptStopFrom(ptArgb(l, pre + "ptColB", ParticularSim.defB), 1f))
        sel = 0; setNeedsDisplay()
    }
    private val bar: CGRect get() = CGRect(18f, 10f, rectWidth() - 36f, 40f)
    private fun xFor(p: Float): Float = bar.minX + p * bar.width
    private fun commit() { lay?.let { PtGradient.write(it, stops, pre) }; onEdit?.invoke(); setNeedsDisplay() }
    fun removeSelected() { if (stops.count() > 2 && sel >= 0 && sel < stops.count()) { stops = stops.toMutableList().also { it.removeAt(sel) }; sel = 0; commit(); onEnd?.invoke() } }
    fun editColor() {
        if (sel < 0 || sel >= stops.count()) return
        val i = sel
        onPick?.invoke(ptStopArgb(stops[i])) { c ->
            if (i < stops.count()) {
                val p = stops[i].p
                stops = stops.toMutableList().also { it[i] = ptStopFrom(c, p) }
                commit(); onEnd?.invoke()
            }
        }
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val b = bar
        c.setFillColor(0xFF292929.toInt()); c.fill(b)
        var chk = false
        var y = b.minY
        while (y < b.maxY) {
            var x = b.minX
            while (x < b.maxX) {
                if (chk) { c.setFillColor(0xFF424242.toInt()); c.fill(CGRect(x, y, 10f, 10f)) }
                chk = !chk; x += 10f
            }
            chk = !chk; y += 10f
        }
        val cols = IntArray(stops.size) { i -> ptStopArgb(stops[i]) }
        val loc = FloatArray(stops.size) { i -> stops[i].p }
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(b.minX, 0f, b.maxX, 0f, cols, loc, Shader.TileMode.CLAMP)
        c.saveGState(); c.clip(to = b)
        c.canvas.drawRect(0f, 0f, rect.width, rect.height, p)
        c.restoreGState()
        c.setStrokeColor(0x40FFFFFF.toInt()); c.setLineWidth(1f); c.stroke(b)
        for ((i, s2) in stops.withIndex()) {
            val x = xFor(s2.p); val y2 = b.maxY + 22f; val r = if (i == sel) 13f else 10f
            c.setStrokeColor(0xFFFFFFFF.toInt()); c.setLineWidth(if (i == sel) 3f else 1.5f)
            c.move(CGPoint(x, b.maxY)); c.addLine(CGPoint(x, y2 - r)); c.strokePath()
            c.setFillColor(ptStopArgb(s2))
            c.fillEllipse(CGRect(x - r, y2 - r, r * 2f, r * 2f))
            c.strokeEllipse(CGRect(x - r, y2 - r, r * 2f, r * 2f))
        }
    }

    override fun touchesBegan(touches: Set<com.saiki.motion.uikit.UITouch>, with: com.saiki.motion.uikit.UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val q = t.location(this)
        val now = android.os.SystemClock.uptimeMillis()
        val doubleTap = now - lastTap < 320
        lastTap = now
        var best = -1; var bd = 26f
        for ((i, s2) in stops.withIndex()) { val d = hypot((xFor(s2.p) - q.x).toDouble(), (bar.maxY + 22f - q.y).toDouble()).toFloat(); if (d < bd) { bd = d; best = i } }
        if (best >= 0) {
            sel = best
            if (doubleTap) { removeSelected(); return }
        } else if (stops.count() < PtGradient.cap && q.y < bar.maxY + 6f) {
            val p = min(1f, max(0f, (q.x - bar.minX) / bar.width))
            val v = PtGradient.eval(stops, p)
            stops = stops + com.saiki.motion.core.PtStop(p, v[0], v[1], v[2], v[3])
            stops = stops.sortedBy { it.p }
            sel = stops.indexOfFirst { it.p == p }; if (sel < 0) sel = 0
            commit()
        }
        setNeedsDisplay()
    }
    override fun touchesMoved(touches: Set<com.saiki.motion.uikit.UITouch>, with: com.saiki.motion.uikit.UIEvent?) {
        val t = touches.firstOrNull() ?: return
        if (sel < 0 || sel >= stops.count()) return
        var p = min(1f, max(0f, (t.location(this).x - bar.minX) / bar.width))
        if (sel > 0) p = max(p, stops[sel - 1].p + 0.005f)
        if (sel < stops.count() - 1) p = min(p, stops[sel + 1].p - 0.005f)
        stops = stops.toMutableList().also { it[sel] = com.saiki.motion.core.PtStop(p, it[sel].r, it[sel].g, it[sel].b, it[sel].a) }
        commit()
    }
    override fun touchesEnded(touches: Set<com.saiki.motion.uikit.UITouch>, with: com.saiki.motion.uikit.UIEvent?) { onEnd?.invoke() }
}

// MARK: - Viewport (draws with the renderer's own camera and sprite maths)

class ParticularViewport : UiView(com.saiki.motion.uikit.appContext!!) {
    var lay: Layer? = null
    var time: Float = 0f; var t0: Float = 0f
    var playing = true
    var loop: Float = 6f
    var compRatio: Float = 9f / 16f
    var compMode = true
        set(v) { field = v; modeBtn.text = if (compMode) "Comp View" else "Orbit"; setNeedsDisplay() }
    var onTick: ((Float) -> Unit)? = null
    private var yaw: Float = 0f; private var pitch: Float = 0.15f; private var dist: Float = 3f
    /// Path drawing: one finger draws on the plane through the origin facing the camera; two fingers orbit.
    var drawMode = false
        set(v) { field = v; drawBtn.isHidden = !v; setNeedsDisplay() }
    var pathAppend = false
    var onPathDrawn: ((List<V3>, Boolean) -> Unit)? = null
    private var stroke = ArrayList<CGPoint>()
    private var drawing = false
    private val drawBtn = PillButton("Stop Drawing", null, C.CARD2, C.TEXT)
    private val modeBtn = PillButton("Comp View", null, C.CARD2, C.TEXT)
    private var link: android.os.Handler? = null
    private var tickRun: Runnable? = null
    private var lastTs = 0.0

    fun beginDrawing(append: Boolean) {
        if (compMode) { yaw = 0f; pitch = 0.15f; dist = 3f; compMode = false }
        pathAppend = append; drawMode = true
    }
    private fun unproject(p: CGPoint): V3 {
        val f = 1f / tan(Editor.scene.fov * Math.PI.toFloat() / 360f)
        val k = rectHeight() * 0.5f * f / dist
        val x1 = (p.x - rectWidth() / 2f) / k; val y2 = -(p.y - rectHeight() / 2f) / k
        val cy = cos(yaw); val sy = sin(yaw); val cp = cos(pitch); val sp = sin(pitch)
        val Y = y2 * cp; val z1 = -y2 * sp
        return V3(x1 * cy - z1 * sy, Y, x1 * sy + z1 * cy)
    }

    init {
        setBackgroundColor(android.graphics.Color.BLACK); clipsToBounds = true; isMultipleTouchEnabled = true
        modeBtn.onClick = {
            if (!compMode) { yaw = 0f; pitch = 0.15f; dist = 3f }
            compMode = !compMode
        }
        addSubview(modeBtn)
        drawBtn.isHidden = true; drawBtn.onClick = { drawMode = false }; addSubview(drawBtn)
    }

    override fun layoutSubviews() {
        super.layoutSubviews()
        modeBtn.frame = CGRect(rectWidth() - 104f, 8f, 96f, 30f)
        drawBtn.frame = CGRect(8f, 8f, 120f, 30f)
    }

    fun start() {
        stop()
        val h = android.os.Handler(android.os.Looper.getMainLooper())
        val t = object : Runnable {
            override fun run() {
                val now = System.nanoTime() / 1e9
                if (lastTs == 0.0) lastTs = now
                val dt = (now - lastTs).toFloat(); lastTs = now
                if (playing) { time += dt; if (time > t0 + loop) time = t0; onTick?.invoke(time) }
                setNeedsDisplay()
                h.postDelayed(this, 1000L / 24L)
            }
        }
        tickRun = t
        h.postDelayed(t, 1000L / 24L)
        link = h
    }
    fun stop() {
        tickRun?.let { link?.removeCallbacks(it) }
        link = null; tickRun = null; lastTs = 0.0
    }

    // raw multi-touch: one finger = pan (or draw), two fingers = pinch zoom
    private val ptrs = HashMap<Int, Pair<Float, Float>>()
    private var navBaseDist = 0f
    private var lastOne: Pair<Float, Float>? = null

    public override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        super.onTouchEvent(e)
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN, android.view.MotionEvent.ACTION_POINTER_DOWN -> {
                ptrs[e.getPointerId(e.actionIndex)] = Pair(e.getX(e.actionIndex), e.getY(e.actionIndex))
                if (ptrs.size == 1) {
                    lastOne = ptrs.values.first()
                    if (drawMode && !compMode) { drawing = true; stroke = ArrayList() }
                }
                if (ptrs.size >= 2) {
                    drawing = false
                    val ps = ptrs.values.toList()
                    navBaseDist = max(1f, hypot((ps[0].first - ps[1].first).toDouble(), (ps[0].second - ps[1].second).toDouble()).toFloat())
                }
            }
            android.view.MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) ptrs[e.getPointerId(i)] = Pair(e.getX(i), e.getY(i))
                if (drawing && ptrs.size == 1) {
                    stroke.add(CGPoint(ptrs.values.first().first, ptrs.values.first().second)); setNeedsDisplay()
                } else if (ptrs.size == 1) {
                    val p = ptrs.values.first(); val l = lastOne ?: p
                    if (compMode) compMode = false
                    yaw += (p.first - l.first) * 0.01f
                    pitch = min(1.4f, max(-1.4f, pitch + (p.second - l.second) * 0.01f))
                    lastOne = p; setNeedsDisplay()
                } else if (ptrs.size >= 2) {
                    if (compMode) compMode = false
                    val ps = ptrs.values.toList()
                    val d = max(1f, hypot((ps[0].first - ps[1].first).toDouble(), (ps[0].second - ps[1].second).toDouble()).toFloat())
                    if (navBaseDist > 0f) dist = min(12f, max(1.2f, dist / max(d / navBaseDist, 0.01f)))
                    navBaseDist = d
                    setNeedsDisplay()
                }
            }
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_POINTER_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                ptrs.remove(e.getPointerId(e.actionIndex))
                if (drawing && ptrs.isEmpty()) {
                    drawing = false
                    if (stroke.count() >= 3) {
                        val pts = PtPath.resample(stroke.map { unproject(it) }, PtPath.cap)
                        onPathDrawn?.invoke(pts, pathAppend)
                    }
                    stroke = ArrayList(); setNeedsDisplay()
                }
                if (ptrs.size < 2) navBaseDist = 0f
                if (ptrs.size == 1) lastOne = ptrs.values.first()
            }
        }
        return true
    }

    private fun frameRect(): CGRect {
        val m = 4f
        var w = rectWidth() - m * 2f; var h = w / compRatio
        if (h > rectHeight() - m * 2f) { h = rectHeight() - m * 2f; w = h * compRatio }
        return CGRect((rectWidth() - w) / 2f, (rectHeight() - h) / 2f, w, h)
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val l = lay ?: return
        val et = Editor.time
        val g: (String) -> Float = { l.p(it, et) }
        fun colFor(q: String): PtColorFn {
            return { k, d ->
                fun comp(s: String, sh: Int): Float {
                    val t = l.props[q + k + s]
                    return if (t != null) t.eval(et) else (((d shr sh) and 0xFF).toFloat()) / 255f
                }
                floatArrayOf(comp("_r", 16), comp("_g", 8), comp("_b", 0), comp("_a", 24))
            }
        }
        val fr = if (compMode) frameRect() else boundsRect
        c.saveGState(); c.clip(to = fr); c.translateBy(fr.minX, fr.minY)
        c.setFillColor(android.graphics.Color.BLACK); c.fill(CGRect(0f, 0f, fr.width, fr.height))
        var cam: PtProject
        var lo = 1f
        if (compMode) {
            val w = (compRatio * 1000f).toInt(); val h = 1000
            val hasCam = MetalCam.vp(l, et, w, h) != null
            val vp = MetalCam.vpForModel(l, Editor.scene.fov, et, w, h)
            val m = Xf.matrix(l, et)
            if (vp.size == 16 && m.size >= 6) {
                cam = PtDraw.comp(vp, m, Xf.worldZ(l, et), l.p("rotX", et), l.p("rotY", et),
                    hasCam || l.is3d, compRatio, fr.size)
            } else cam = PtDraw.orbit(0f, 0f, 3f, Editor.scene.fov, fr.size)
            lo = min(max(l.p("opacity", et), 0f), 1f)
        } else {
            cam = PtDraw.orbit(yaw, pitch, dist, Editor.scene.fov, fr.size)
            drawGizmos(c, g, cam)
        }
        val n = PtGroup.count(g)
        for (gi in 0 until n) {
            PtDraw.render(c, fr.size, PtGroup.reader(g, gi), colFor(PtGroup.pre(gi)), time, cam, lo, 1400 / n, 1080f, adaptive = true)
        }
        c.restoreGState()
        if (stroke.count() > 1) {
            c.setStrokeColor(ptAcc); c.setLineWidth(2.5f); c.setLineCap(com.saiki.motion.uikit.CGLineCap.round); c.setLineJoin(com.saiki.motion.uikit.CGLineJoin.round)
            c.move(stroke[0]); for (p in stroke.drop(1)) c.addLine(p); c.strokePath()
        }
        if (compMode) { c.setStrokeColor(0x2EFFFFFF.toInt()); c.setLineWidth(1f); c.stroke(fr) }
    }

    private fun drawGizmos(c: com.saiki.motion.uikit.CGContext, g: (String) -> Float, cam: PtProject) {
        fun line(pts: List<Triple<Float, Float, Float>>, col: Int) {
            c.setStrokeColor(col); c.setLineWidth(1f)
            var first = true
            for (p in pts) {
                val q = cam(p.first, p.second, p.third)
                if (q != null) { val pt = CGPoint(q.x, q.y); if (first) { c.move(pt); first = false } else c.addLine(pt) } else first = true
            }
            c.strokePath()
        }
        val gc = 0x12FFFFFF.toInt()
        for (i in -4..4) { val v = i * 0.5f; line(listOf(Triple(v, -1.2f, -2f), Triple(v, -1.2f, 2f)), gc); line(listOf(Triple(-2f, -1.2f, v), Triple(2f, -1.2f, v)), gc) }
        line(listOf(Triple(0f, 0f, 0f), Triple(0.5f, 0f, 0f)), 0xE6E64C4C.toInt())
        line(listOf(Triple(0f, 0f, 0f), Triple(0f, 0.5f, 0f)), 0xE666CC66.toInt())
        line(listOf(Triple(0f, 0f, 0f), Triple(0f, 0f, 0.5f)), 0xE66680FF.toInt())
        val ex = g("ptPosX"); val ey = g("ptPosY"); val ez = g("ptPosZ"); val sx = g("ptSizeX"); val sy = g("ptSizeY"); val sz = g("ptSizeZ")
        val em = Math.round(g("ptEmType")).toInt(); val wc = 0xB3FF8A1F.toInt()
        fun circ(y: Float, rx: Float, rz: Float): List<Triple<Float, Float, Float>> =
            (0..32).map { val a = it / 32f * 6.2831853f; Triple(ex + cos(a) * rx, ey + y, ez + sin(a) * rz) }
        fun ell(ax: Int): List<Triple<Float, Float, Float>> =
            (0..32).map { val a = it / 32f * 6.2831853f; val ca = cos(a); val sa = sin(a)
                if (ax == 0) Triple(ex + ca * sx, ey + sa * sy, ez) else (if (ax == 1) Triple(ex + ca * sx, ey, ez + sa * sz) else Triple(ex, ey + ca * sy, ez + sa * sz)) }
        when (em) {
            18 -> {
                val lut = PtPath.lut(g)
                if (lut.count() > 1) {
                    line(lut.map { Triple(it.x, it.y, it.z) }, ptAcc)
                    for (q in PtPath.read(g)) {
                        val s2 = cam(q.x, q.y, q.z)
                        if (s2 != null) { c.setFillColor(0xFFFFFFFF.toInt()); c.fillEllipse(CGRect(s2.x - 3f, s2.y - 3f, 6f, 6f)) }
                    }
                }
            }
            1, 3 -> for (i in 0 until 8) for (b in listOf(1, 2, 4)) if (i and b == 0) {
                val j = i or b
                fun cn(k: Int) = Triple(ex + (if (k and 1 == 0) -sx else sx), ey + (if (k and 2 == 0) -sy else sy), ez + (if (k and 4 == 0) -sz else sz))
                line(listOf(cn(i), cn(j)), wc)
            }
            2, 12 -> for (ax in 0 until 3) line(ell(ax), wc)
            4, 5 -> line(circ(0f, sx, sz), wc)
            8 -> { line(circ(-sy, sx, sz), wc); line(circ(sy, sx, sz), wc) }
            7 -> { line(circ(sy, sx, sz), wc); line(listOf(Triple(ex, ey - sy, ez), Triple(ex + sx, ey + sy, ez)), wc); line(listOf(Triple(ex, ey - sy, ez), Triple(ex - sx, ey + sy, ez)), wc) }
            9 -> { line(circ(0f, sx + sy, sx + sy), wc); line(circ(0f, max(0f, sx - sy), max(0f, sx - sy)), wc) }
            10 -> line((0..60).map { val a = it / 60f * 6.2831853f * 3f; Triple(ex + cos(a) * sx, ey + (it / 30f - 1f) * sy, ez + sin(a) * sz) }, wc)
            6 -> line(listOf(Triple(ex - sx, ey, ez), Triple(ex + sx, ey, ez)), wc)
            11, 13, 14 -> line(listOf(Triple(ex - sx, ey - sy, ez), Triple(ex + sx, ey - sy, ez), Triple(ex + sx, ey + sy, ez), Triple(ex - sx, ey + sy, ez), Triple(ex - sx, ey - sy, ez)), wc)
            else -> { line(listOf(Triple(ex - 0.08f, ey, ez), Triple(ex + 0.08f, ey, ez)), wc); line(listOf(Triple(ex, ey - 0.08f, ez), Triple(ex, ey + 0.08f, ez)), wc); line(listOf(Triple(ex, ey, ez - 0.08f), Triple(ex, ey, ez + 0.08f)), wc) }
        }
    }
}

// MARK: - Designer screen

class ParticularDesignerViewController(private val lay: Layer, private val ed: com.saiki.motion.app.EditorViewController?, private val onDone: () -> Unit) : com.saiki.motion.uikit.UIViewController() {
    private var snapKeys: List<String> = emptyList()
    private val snapVals = HashMap<String, Float?>()
    private val vp = ParticularViewport()
    private val bar = UiView(com.saiki.motion.uikit.appContext!!)
    private val transport = UiView(com.saiki.motion.uikit.appContext!!)
    private val strip = com.saiki.motion.uikit.UIScrollView(com.saiki.motion.uikit.appContext!!)
    private val props = PanelScroll()
    private val stack = com.saiki.motion.app.EVStack()
    private val timeLbl = UILabel(com.saiki.motion.uikit.appContext!!)
    private lateinit var tabs: TabBar
    private var tabIdx = 0; private var blockId = "presets"
    private val play = PtGlyph()
    private var pendingPick = ""
    private var lastW: Float = 0f
    private var curGroup = 0
    private val pre: String get() = PtGroup.pre(curGroup)

    private class PDRoot(val vc: ParticularDesignerViewController) : UiView(com.saiki.motion.uikit.appContext!!) {
        override fun layoutSubviews() { super.layoutSubviews(); vc.layoutRoot() }
    }
    override val view: UiView = PDRoot(this)

    private fun raw(k: String): Float = lay.p(k, Editor.time)
    private fun val_(k: String): Float = lay.p(pre + k, Editor.time)
    private fun set(k: String, v: Float) { lay.track(pre + k).base = v }
    private fun argb(k: String, d: Int): Int = ptArgb(lay, pre + k, d)
    private fun setColor(k: String, c: Int) {
        set(k + "_a", ((c shr 24) and 0xFF).toFloat() / 255f); set(k + "_r", ((c shr 16) and 0xFF).toFloat() / 255f)
        set(k + "_g", ((c shr 8) and 0xFF).toFloat() / 255f); set(k + "_b", (c and 0xFF).toFloat() / 255f)
    }

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        snapKeys = PtParams.allKeys.distinct()
        for (k in snapKeys) snapVals[k] = lay.props[k]?.base
        bar.setBackgroundColor(C.PANEL); view.addSubview(bar)
        val titleLbl = UILabel(com.saiki.motion.uikit.appContext!!)
        titleLbl.text = "Particle Designer"; titleLbl.textColor = argbToUIColor(C.TEXT); titleLbl.font = boldFont(15f)
        titleLbl.textAlignment = NSTextAlignment.center; bar.addSubview(titleLbl)
        val cancel = PillButton("Cancel", null, C.CARD2, C.TEXT); cancel.onClick = { cancelDialog() }; bar.addSubview(cancel)
        val apply = PillButton("Apply", null, C.GREEN, C.ONDARK); apply.onClick = { applyDialog() }; bar.addSubview(apply)
        vp.lay = lay; vp.t0 = Editor.time; vp.time = Editor.time
        vp.compRatio = ed?.aspect?.ratio ?: 9f / 16f
        vp.onTick = { t -> updateTime(t) }; view.addSubview(vp)
        vp.onPathDrawn = { pts, append -> applyPath(pts, append) }
        transport.setBackgroundColor(C.PANEL); view.addSubview(transport)
        val glyphs = ArrayList<PtGlyph>()
        for ((i, k) in listOf("back", "play", "next").withIndex()) {
            val g = if (k == "play") play else PtGlyph(); g.kind = k; g.ptGlyphIndex = i; transport.addSubview(g)
            g.onClick = { transportTap(k) }
            glyphs.add(g)
        }
        play.kind = "pause"
        timeLbl.textColor = argbToUIColor(ptAcc); timeLbl.font = com.saiki.motion.uikit.UIFont.monospacedDigitSystemFont(13f, 600); transport.addSubview(timeLbl)
        tabs = TabBar(ptTabs.map { it.first }, 0) { i -> pickTab(i) }; view.addSubview(tabs)
        strip.showsHorizontalScrollIndicator = false; strip.setBackgroundColor(C.PANEL); view.addSubview(strip)
        props.setBackgroundColor(C.BG)
        view.addSubview(props)
        props.content.addSubview(stack)
        rebuildStrip(); rebuildProps(); updateTime(vp.time)
    }

    override fun viewDidAppear(animated: Boolean) { super.viewDidAppear(animated); vp.start() }
    override fun viewWillDisappear(animated: Boolean) { super.viewWillDisappear(animated); vp.stop() }

    fun layoutRoot() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w <= 1f || h <= 1f) return
        val sa = view.safeAreaInsets
        val top = sa.top; val bw = w - sa.left - sa.right; val x0 = sa.left
        bar.frame = CGRect(0f, 0f, w, top + 46f)
        for (v in bar.subviews) {
            when (v) {
                is UILabel -> v.frame = CGRect(x0 + 120f, top, bw - 240f, 46f)
                is PillButton -> {
                    val b = v
                    if (b.text == "Cancel") b.frame = CGRect(x0 + 10f, top + 5f, 100f, 36f)
                    else if (b.text == "Apply") b.frame = CGRect(x0 + bw - 110f, top + 5f, 100f, 36f)
                }
            }
        }
        val landscape = w > h
        val bottom = h - sa.bottom
        val leftW = if (landscape) bw * 0.5f else bw
        val vpH = if (landscape) bottom - bar.frame.maxY - 40f else (bottom - bar.frame.maxY) * 0.4f
        vp.frame = CGRect(x0, bar.frame.maxY, leftW, vpH)
        transport.frame = CGRect(x0, vp.frame.maxY, leftW, 40f)
        for (v in transport.subviews) { val gi = (v as? PtGlyph)?.ptGlyphIndex ?: -1; if (gi >= 0) v.frame = CGRect(6f + gi * 44f, 0f, 44f, 40f) }
        timeLbl.frame = CGRect(150f, 0f, leftW - 160f, 40f)
        val rx = if (landscape) x0 + leftW else x0; val rw = if (landscape) bw - leftW else bw
        val ry = if (landscape) bar.frame.maxY else transport.frame.maxY
        tabs.frame = CGRect(rx, ry, rw, 40f)
        strip.frame = CGRect(rx, ry + 40f, rw, 112f)
        // lay out the strip tiles
        var sx = 8f
        for (t in strip.subviews) { if (t !is PtTile) continue; t.frame = CGRect(sx, 6f, 92f, 100f); sx += 98f }
        strip.contentSize = com.saiki.motion.uikit.CGSize(sx + 8f, 112f)
        props.frame = CGRect(rx, strip.frame.maxY, rw, bottom - strip.frame.maxY)
        if (tabIdx == 0 && abs(props.rectWidth() - lastW) > 1f) { lastW = props.rectWidth(); rebuildProps() }
        relayoutStack()
    }

    private fun relayoutStack() {
        val w = props.rectWidth() - 20f
        val h = stackHeight(w)
        stack.frame = CGRect(10f, 8f, w, h)
        props.content.totalH   // read so a custom setter stays meaningful; layout is driven by PanelScroll
    }

    private fun stackHeight(w: Float): Float {
        var y = 0f
        for (c in stack.arranged) {
            val hh = when (c) {
                is com.saiki.motion.app.EBox -> c.boxH(w)
                is com.saiki.motion.app.PLabel -> c.height(w) + 10f
                is RulerSlider -> 52f * Dev.k
                is PtGraphView -> 190f
                is PtGradView -> 96f
                else -> if (c.rectHeight() > 0f) c.rectHeight() else 44f
            }
            c.frame = CGRect(0f, y, w, hh)
            y += hh + 6f
        }
        return y
    }

    private fun updateTime(t: Float) {
        val f = (t * 30).toInt(); val s = f / 30
        timeLbl.text = String.format(Locale.US, "00:%02d:%02d:%02d   Loop %.1fs", s / 60, s % 60, f % 30, vp.loop)
        timeLbl.setNeedsDisplay()
    }
    private fun transportTap(k: String) {
        when (k) {
            "play" -> vp.playing = !vp.playing
            "back" -> { vp.time = max(vp.t0, vp.time - 1f / 30f); vp.playing = false; updateTime(vp.time) }
            else -> { vp.time += 1f / 30f; vp.playing = false; updateTime(vp.time) }
        }
        play.kind = if (vp.playing) "pause" else "play"; play.setNeedsDisplay()
    }

    private fun pickTab(i: Int) { tabIdx = i; blockId = ptTabs[i].second[0]; rebuildStrip(); rebuildProps() }

    private fun valueText(b: PtBlock): String {
        fun on(v: Boolean) = if (v) "On" else "Off"
        return when (b.id) {
            "emitter" -> ParticularSim.emitterNames[min(ParticularSim.emitterNames.count() - 1, max(0, Math.round(val_("ptEmType")).toInt()))]
            "motion" -> ParticularSim.motionNames[min(ParticularSim.motionNames.count() - 1, max(0, Math.round(val_("ptMotion")).toInt()))]
            "source" -> if (val_("ptEmType") >= 12.5f) (if (val_("ptEmImgId") > 0f) "Media" else "Empty") else "None"
            "color" -> { val a = argb("ptColA", ParticularSim.defA); val c = argb("ptColB", ParticularSim.defB); ptColorPresets.firstOrNull { it.second == a && it.third == c }?.first ?: "Custom" }
            "gradient" -> on(val_("ptGrOn") >= 0.5f)
            "type" -> {
                val sp = Math.round(val_("ptSprite")).toInt()
                if (sp == 6) "Custom"
                else b.presets.firstOrNull { p -> p.third.all { (k, v) -> abs(val_(k) - v) < 0.011f } }?.first ?: "Custom"
            }
            "env" -> on(abs(val_("ptSwirl")) + val_("ptAttract") + val_("ptFloorOn") + abs(val_("ptGravity")) + abs(val_("ptWindX")) + abs(val_("ptWindY")) + abs(val_("ptWindZ")) + val_("ptAir") > 0.001f)
            "field" -> on(val_("ptTurb") > 0.001f)
            "curl" -> on(val_("ptCurl") > 0.001f)
            "wave" -> on(val_("ptWaveAmp") > 0.001f || abs(val_("ptWaveFlow")) > 0.001f)
            "flutter" -> on(val_("ptFlutter") > 0.001f || abs(val_("ptSpin")) > 0.001f)
            "trail" -> on(val_("ptTrail") > 0.5f)
            "scatter" -> on(val_("ptScatter") > 0.001f || Math.round(val_("ptBehavior")).toInt() == 2)
            "quant" -> on(val_("ptQuant") > 0.001f)
            "twinkle" -> on(val_("ptTwinkle") > 0.001f)
            else -> b.presets.firstOrNull { p -> p.third.all { (k, v) -> abs(val_(k) - v) < 0.011f } }?.first ?: "Custom"
        }
    }

    private fun attach(t: PtTile, id: String, over: Map<String, Float>) {
        val s2 = ptThumbSpec(id, over) ?: return
        PtThumb.make(s2.key, s2.p, time = s2.t, yaw = s2.yaw, pitch = s2.pitch, dist = s2.dist) { img -> t.thumb = img; t.setNeedsDisplay() }
    }
    private fun currentStops(): List<com.saiki.motion.core.PtStop> {
        val l = lay; val p2 = pre
        val s2 = PtGradient.read { l.p(p2 + it, Editor.time) }
        if (val_("ptGrOn") >= 0.5f && s2.count() >= 2) return s2
        return listOf(ptStopFrom(argb("ptColA", ParticularSim.defA), 0f), ptStopFrom(argb("ptColB", ParticularSim.defB), 1f))
    }

    private fun rebuildStrip() {
        for (t in strip.subviews.toList()) t.removeFromSuperview()
        if (blockId == "presets") {
            for ((i, triple) in listOf(Triple("IMPORT", "act_import", ".saikiparticle"), Triple("SAVE", "act_save", "to My presets"), Triple("EXPORT", "act_export", "share file")).withIndex()) {
                val title = triple.first; val kind = triple.second; val value = triple.third
                val act = listOf("import", "save", "export")[i]
                val t = PtTile(); t.kind = kind; t.title = title; t.value = value
                t.onClick = { presetAction(act) }
                strip.addSubview(t)
            }
            return
        }
        for (id in ptTabs[tabIdx].second) {
            val b = ptBlocks.firstOrNull { it.id == id } ?: continue
            val t = PtTile()
            t.kind = if (b.id == "type") "type" else b.id
            t.variant = if (b.id == "emitter") Math.round(val_("ptEmType")).toInt() else (if (b.id == "motion") Math.round(val_("ptMotion")).toInt() else 1)
            t.title = b.title; t.value = valueText(b); t.picked = b.id == blockId
            if (b.id == "color") { t.ca = argb("ptColA", ParticularSim.defA); t.cb = argb("ptColB", ParticularSim.defB) }
            if (b.id == "gradient") t.stops = currentStops()
            if (ptThumbBlocks.contains(b.id)) {
                val over = HashMap<String, Float>()
                for (it in b.items) when (it) {
                    is PtItem.slider -> over[it.k] = val_(it.k)
                    is PtItem.choice -> over[it.k] = val_(it.k)
                    else -> {}
                }
                if (b.id == "source") over["ptEmImgId"] = val_("ptEmImgId")
                attach(t, b.id, over)
            }
            t.onClick = { blockId = id; rebuildStrip(); rebuildProps() }
            strip.addSubview(t)
        }
        layoutRoot()
    }

    private fun label(s: String): com.saiki.motion.app.PLabel {
        val l = com.saiki.motion.app.PLabel()
        l.text = s; l.color = C.DIM; l.size = 12f; l.bold = true
        return l
    }

    // MARK: presets tab

    private fun buildPresets() {
        stack.add(com.saiki.motion.app.EBox(label("BUILT-IN PRESETS  ·  tap a folder to open"), 0f, 0f, 0f, 4f, 0f, 4f))
        val cats = ArrayList<String>()
        for (p in PtBuiltins.all) if (!cats.contains(p.cat)) cats.add(p.cat)
        for (cat in cats) {
            val items = PtBuiltins.all.filter { it.cat == cat }
            val open = ptOpenFolders.contains(cat)
            val b = PillButton("${if (open) "▾" else "▸"}  $cat  ·  ${items.count()}", null, 0x12FFFFFF.toInt(), C.TEXT)
            b.onClick = {
                if (ptOpenFolders.contains(cat)) ptOpenFolders.remove(cat) else ptOpenFolders.add(cat)
                rebuildProps()
            }
            b.frame = CGRect(0f, 0f, 300f, 36f)
            stack.add(com.saiki.motion.app.EBox(b, 0f, 36f, 0f, 0f, 0f, 0f))
            if (open) stack.add(presetGrid(items))
        }
        stack.add(com.saiki.motion.app.EBox(label("MY PRESETS  ·  long-press to delete"), 0f, 0f, 0f, 4f, 0f, 4f))
        val mine = PtPresetStore.list()
        if (mine.isEmpty()) stack.add(com.saiki.motion.app.EBox(label("Nothing saved yet. Tap SAVE to keep the current look, or IMPORT a .saikiparticle file."), 0f, 0f, 0f, 4f, 0f, 4f))
        else stack.add(presetGrid(mine))
    }
    private fun presetGrid(items: List<PtPreset>): UiView {
        val w = max(300f, props.rectWidth() - 20f); val cols = max(2, ((w + 8f) / 116f).toInt())
        val tw = (w - 8f * (cols - 1)) / cols; val th = tw * 0.78f + 34f
        val v = PtPresetGrid(); v.cols = cols; v.tileH = th
        v.frame = CGRect(0f, 0f, w, ((items.count() + cols - 1) / cols) * (th + 8f))
        for (p in items) {
            val t = PtPresetTile(); t.title = p.name; t.sub = if (p.custom) "Saved" else p.cat
            t.onClick = { applyPreset(p) }
            if (p.custom) t.onLong = { confirmDelete(p) }
            PtThumb.make("p:" + p.id, p.params, time = p.thumbT) { img -> t.thumb = img; t.setNeedsDisplay() }
            v.addSubview(t)
        }
        return v
    }
    private fun applyPreset(p: PtPreset) {
        val skip = setOf("ptOcclude", "ptShowSrc")
        for (k in PtParams.allKeys.distinct()) if (!skip.contains(k)) lay.track(k).base = PtParams.def(k)
        for ((k, v) in p.params) lay.track(k).base = v
        curGroup = 0; vp.time = vp.t0
        afterEdit(true); com.saiki.motion.app.Snack.show("Applied ${p.name}")
    }
    private fun confirmDelete(p: PtPreset) {
        val a = com.saiki.motion.uikit.UIAlertController()
        a.title = "Delete \"${p.name}\"?"
        a.addAction(com.saiki.motion.uikit.UIAlertAction("Delete", com.saiki.motion.uikit.UIAlertActionStyle.destructive) { PtPresetStore.delete(p); rebuildProps() })
        a.addAction(com.saiki.motion.uikit.UIAlertAction("Cancel", com.saiki.motion.uikit.UIAlertActionStyle.cancel, null))
        a.showOver(this)
    }
    private fun currentParams(): Map<String, Float> {
        val d = HashMap<String, Float>()
        for (k in PtParams.allKeys.distinct()) d[k] = raw(k)
        for (gi in 0 until PtGroup.count { raw(it) }) {
            val q = PtGroup.pre(gi)
            d.putAll(PtParams.color(q + "ptColA", ptArgb(lay, q + "ptColA", ParticularSim.defA)))
            d.putAll(PtParams.color(q + "ptColB", ptArgb(lay, q + "ptColB", ParticularSim.defB)))
        }
        return d
    }
    private fun presetAction(act: String) {
        when (act) {
            "import" -> {
                com.saiki.motion.app.DocPicker.pick { uri ->
                    val f = java.io.File(com.saiki.motion.core.Paths.cache, "imp.${PtPresetStore.ext}")
                    try {
                        com.saiki.motion.uikit.appContext!!.contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { out -> input.copyTo(out) } }
                        val p = PtPresetStore.importFile(f)
                        if (p != null) applyPreset(p) else com.saiki.motion.app.Snack.show("Not a valid .saikiparticle file")
                    } catch (_: Exception) { com.saiki.motion.app.Snack.show("Not a valid .saikiparticle file") }
                }
            }
            "save" -> {
                val a = com.saiki.motion.uikit.UIAlertController()
                a.title = "Save Preset"
                a.message = "Saved to My presets with a thumbnail."
                a.addTextField { it.placeholder = "Preset name" }
                a.addAction(com.saiki.motion.uikit.UIAlertAction("Save", com.saiki.motion.uikit.UIAlertActionStyle.default) {
                    if (PtPresetStore.save(name = a.textFields.firstOrNull()?.text ?: "", params = currentParams()) != null) {
                        com.saiki.motion.app.Snack.show("Saved"); rebuildProps()
                    }
                })
                a.addAction(com.saiki.motion.uikit.UIAlertAction("Cancel", com.saiki.motion.uikit.UIAlertActionStyle.cancel, null))
                a.showOver(this)
            }
            else -> {
                val u = PtPresetStore.exportURL("Particle", currentParams()) ?: return
                com.saiki.motion.app.Snack.show("Exported ${u.name}")
                // == iOS ParticularDesigner.swift:972-977 UIActivityViewController: the Android share sheet
                val act = com.saiki.motion.uikit.currentActivity?.get() ?: return
                val share = android.content.Intent(android.content.Intent.ACTION_SEND)
                share.type = if (u.extension.lowercase() == "json") "application/json" else "application/octet-stream"
                share.putExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri.fromFile(u))
                share.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                act.startActivity(android.content.Intent.createChooser(share, null).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    // MARK: particle groups (extra emitters on the same layer, each with its own full parameter set)

    private fun groupRow(): List<UiView> {
        val n = PtGroup.count { raw(it) }
        val names = (0 until n).map { if (it == 0) "Main" else "Group ${it + 1}" }.toMutableList()
        if (n < 1 + PtGroup.maxExtra) names.add("+ Add Group")
        val row = chipRow(names, min(curGroup, n - 1)) { i -> groupTap(i, n) }
        row.frame = CGRect(0f, 0f, 400f, 46f)
        val out = ArrayList<UiView>()
        out.add(com.saiki.motion.app.EBox(label("PARTICLE GROUP  ·  each group is its own emitter, shape, colour and physics"), 0f, 0f, 0f, 4f, 0f, 4f))
        out.add(row)
        if (n > 1) {
            val rm = PillButton("Remove this group", null, C.CARD2, C.TEXT)
            rm.onClick = { removeGroup(n) }
            rm.frame = CGRect(0f, 0f, 300f, 38f)
            out.add(rm)
        }
        return out
    }
    private fun groupTap(i: Int, n: Int) {
        if (i >= n) {
            for (k in ptBaseKeys) lay.track(PtGroup.pre(n) + k).base = raw(pre + k)   // new group starts as a copy of the current one
            lay.track("ptGroups").base = n.toFloat()
            curGroup = n
        } else curGroup = i
        afterEdit(true)
    }
    private fun removeGroup(n: Int) {
        for (j in curGroup until (n - 1)) for (k in ptBaseKeys) lay.track(PtGroup.pre(j) + k).base = raw(PtGroup.pre(j + 1) + k)
        lay.track("ptGroups").base = (n - 2).toFloat()
        curGroup = min(curGroup, n - 2)
        afterEdit(true)
    }

    // MARK: media import (sprite shapes and image / video emitters)

    private fun applyPath(pts: List<V3>, append: Boolean) {
        var all = pts
        if (append) all = PtPath.resample(PtPath.read { val_(it) } + pts, PtPath.cap)
        PtPath.write(lay, all, pre)
        set("ptEmType", 18f)
        afterEdit(true)
    }

    private fun runAction(id: String) {
        when (id) {
            "pathDraw", "pathAdd" -> {
                vp.beginDrawing(append = id == "pathAdd")
                com.saiki.motion.app.Snack.show("Drag one finger to draw the path · two fingers rotate the view")
            }
            "pathClr" -> { set("ptPathN", 0f); vp.drawMode = false; afterEdit(true) }
            "bpClr" -> { set("ptBumpId", 0f); afterEdit(true) }
            "emClr" -> { set("ptEmImgId", 0f); if (val_("ptEmType") >= 12.5f) set("ptEmType", 11f); afterEdit(true) }
            else -> {
                // == iOS ParticularDesigner.swift:1027-1039 PHPickerViewController (photo library) +
                //   file fallback: Android shows the system photo picker when the action wants a picture,
                //   the document picker for every other media kind.
                pendingPick = id
                val photoActions = setOf("spShape", "emImg", "spKeyImg", "spSeq")
                if (id in photoActions) {
                    com.saiki.motion.app.DocPicker.pickImages { uri -> mediaReady(id, uri) }
                } else {
                    com.saiki.motion.app.DocPicker.pick { uri -> mediaReady(id, uri) }
                }
            }
        }
    }
    private fun mediaReady(act: String, uri: android.net.Uri) {
        val id: Int? = try {
            val bmp = com.saiki.motion.uikit.appContext!!.contentResolver.openInputStream(uri)?.let { s -> BitmapFactory.decodeStream(s) }
            val fixed: Bitmap? = if (act == "spKeyImg") bmp?.let { PtImages.keyBlack(it) } else bmp
            if (fixed != null) PtImages.addImage(fixed) else null
        } catch (_: Exception) { null }
        if (id == null) { com.saiki.motion.app.Snack.show("Couldn't import that file"); return }
        if (act == "bpImg") { set("ptBumpId", id.toFloat()); set("ptBump", max(val_("ptBump"), 1f)) }
        else if (act.startsWith("sp")) { set("ptSprite", 6f); set("ptSpriteId", id.toFloat()); set("ptSpriteAnim", if (act == "spVid") 1f else 0f); set("ptSpriteTint", 0f) }
        else { set("ptEmImgId", id.toFloat()); set("ptEmType", if (act == "emVid") 14f else 13f) }
        afterEdit(true)
    }

    // MARK: property panel

    private fun rebuildProps() {
        stack.clear()
        if (blockId == "presets") { buildPresets(); relayoutStack(); return }
        val b = ptBlocks.firstOrNull { it.id == blockId } ?: return
        for (v in groupRow()) stack.add(v)
        stack.add(com.saiki.motion.app.EBox(label(b.title), 0f, 0f, 0f, 4f, 0f, 4f))
        val presetCount = if (b.id == "color") ptColorPresets.count() else (if (b.id == "gradient") PtGradient.presets.count() else b.presets.count())
        if (presetCount > 0) {
            stack.add(com.saiki.motion.app.EBox(label("Presets"), 0f, 0f, 0f, 4f, 0f, 2f))
            val sc = com.saiki.motion.uikit.UIScrollView(com.saiki.motion.uikit.appContext!!)
            sc.showsHorizontalScrollIndicator = false
            sc.frame = CGRect(0f, 0f, 400f, 84f)
            var x = 0f
            for (i in 0 until presetCount) {
                val t = PtTile()
                if (b.id == "color") {
                    val p = ptColorPresets[i]; t.kind = "color"; t.title = p.first
                    t.ca = p.second; t.cb = p.third
                    t.onClick = { setColor("ptColA", p.second); setColor("ptColB", p.third); set("ptGrOn", 0f); afterEdit(true) }
                } else if (b.id == "gradient") {
                    val p = PtGradient.presets[i]; t.title = p.first; t.stops = PtGradient.evenly(p.second)
                    t.onClick = { PtGradient.write(lay, PtGradient.evenly(p.second), pre); afterEdit(true) }
                } else {
                    val p = b.presets[i]; t.kind = b.id; t.variant = p.second; t.title = p.first
                    if (ptThumbBlocks.contains(b.id)) attach(t, b.id, p.third)
                    t.onClick = { for ((k, v) in p.third) set(k, v); afterEdit(true) }
                }
                t.frame = CGRect(x, 0f, 74f, 82f)
                sc.addSubview(t); x += 80f
            }
            sc.contentSize = com.saiki.motion.uikit.CGSize(x, 82f)
            stack.add(sc)
        }
        stack.add(com.saiki.motion.app.EBox(label("Properties"), 0f, 0f, 0f, 4f, 0f, 2f))
        for (it in b.items) {
            when (it) {
                is PtItem.slider -> {
                    val s = RulerSlider(); s.label = it.name; s.lo = it.lo; s.hi = it.hi; s.dec = it.dec; s.canKey = false; s.value = val_(it.k)
                    s.onChange = { v -> set(it.k, v); vp.setNeedsDisplay() }
                    stack.add(s)
                }
                is PtItem.choice -> {
                    stack.add(com.saiki.motion.app.EBox(label(it.name), 0f, 0f, 0f, 4f, 0f, 2f))
                    val row = chipRow(it.opts, min(it.opts.count() - 1, max(0, Math.round(val_(it.k)).toInt()))) { i -> set(it.k, i.toFloat()); afterEdit(false) }
                    row.frame = CGRect(0f, 0f, 400f, 46f)
                    stack.add(row)
                }
                is PtItem.action -> {
                    val pb = PillButton(it.title, null, C.CARD2, C.TEXT); pb.onClick = { runAction(it.id) }
                    pb.frame = CGRect(0f, 0f, 300f, 44f)
                    stack.add(pb)
                }
                PtItem.gradient -> {
                    val gv = PtGradView(); gv.lay = lay; gv.pre = pre; gv.load()
                    gv.onEdit = { vp.setNeedsDisplay() }
                    gv.onEnd = { rebuildStrip() }
                    gv.onPick = { cur, apply -> ed?.showColorPicker(cur) { c -> apply(c) } }
                    stack.add(gv)
                    val ec = PillButton("Edit stop colour", null, C.CARD2, C.TEXT); ec.onClick = { gv.editColor() }
                    val rm = PillButton("Remove stop", null, C.CARD2, C.TEXT); rm.onClick = { gv.removeSelected() }
                    ec.frame = CGRect(0f, 0f, 180f, 40f); rm.frame = CGRect(0f, 0f, 180f, 40f)
                    val br = PtPresetGrid(); br.cols = 2; br.tileH = 40f
                    br.addSubview(ec); br.addSubview(rm)
                    stack.add(br)
                    stack.add(com.saiki.motion.app.EBox(label("Tap the bar to add a stop (up to 8), drag a handle to move it, double-tap a handle to remove it. Editing turns the gradient on."), 0f, 0f, 0f, 4f, 0f, 4f))
                }
                is PtItem.graph -> {
                    stack.add(com.saiki.motion.app.EBox(label(it.title), 0f, 0f, 0f, 4f, 0f, 2f))
                    val gv = PtGraphView(); gv.cid = it.id; gv.range = if (it.id == "Op") 1f else 2f; gv.lay = lay; gv.pre = pre; gv.load()
                    gv.onEdit = { vp.setNeedsDisplay() }
                    val on = SwitchRow(); on.label = "Use custom graph"; on.on = val_("ptCv${it.id}On") >= 0.5f
                    gv.alpha = if (on.on) 1f else 0.45f; gv.isUserInteractionEnabled = on.on
                    on.onToggle = { v ->
                        set("ptCv${it.id}On", if (v) 1f else 0f)
                        if (v) PtCurve.write(lay, it.id, gv.pts, pre)
                        gv.alpha = if (v) 1f else 0.45f; gv.isUserInteractionEnabled = v; afterEdit(false)
                    }
                    on.frame = CGRect(0f, 0f, 300f, 52f)
                    stack.add(on)
                    stack.add(gv)
                    val rm = PillButton("Remove point", null, C.CARD2, C.TEXT); rm.onClick = { gv.removeSelected() }
                    val rs = PillButton("Reset graph", null, C.CARD2, C.TEXT); rs.onClick = { gv.reset() }
                    rm.frame = CGRect(0f, 0f, 180f, 40f); rs.frame = CGRect(0f, 0f, 180f, 40f)
                    val br = PtPresetGrid(); br.cols = 2; br.tileH = 40f
                    br.addSubview(rm); br.addSubview(rs)
                    stack.add(br)
                    stack.add(com.saiki.motion.app.EBox(label("Tap empty space to add a point, drag to move, double-tap a point to remove it."), 0f, 0f, 0f, 4f, 0f, 4f))
                }
                is PtItem.color -> {
                    val row = TapView(); row.setBackgroundColor(C.CARD)
                    row.frame = CGRect(0f, 0f, 300f, 46f)
                    val tv = UILabel(com.saiki.motion.uikit.appContext!!)
                    tv.text = it.name; tv.textColor = argbToUIColor(C.TEXT); tv.font = boldFont(15f)
                    tv.frame = CGRect(14f, 0f, 200f, 46f); row.addSubview(tv)
                    val sw = UiView(com.saiki.motion.uikit.appContext!!)
                    sw.setBackgroundColor(argb(it.k, it.def))
                    sw.frame = CGRect(238f, 8f, 48f, 30f); row.addSubview(sw)
                    row.onClick = {
                        ed?.showColorPicker(argb(it.k, it.def)) { col -> setColor(it.k, col); set("ptGrOn", 0f); afterEdit(true) }
                    }
                    stack.add(row)
                }
            }
        }
        relayoutStack()
    }

    private fun afterEdit(rebuildProperties: Boolean) {
        vp.setNeedsDisplay(); rebuildStrip()
        if (rebuildProperties) rebuildProps()
    }

    private fun applyDialog() { vp.stop(); dismiss(animated = true) { onDone() } }
    private fun cancelDialog() {
        for (k in snapKeys) {
            val v = snapVals[k]
            if (v != null) lay.track(k).base = v else lay.props.remove(k)
        }
        vp.stop(); dismiss(animated = true) { onDone() }
    }
}
