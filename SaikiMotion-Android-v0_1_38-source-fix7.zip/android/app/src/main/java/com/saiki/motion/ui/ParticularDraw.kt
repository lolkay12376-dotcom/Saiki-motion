@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName", "PropertyName")

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import com.saiki.motion.core.Particle
import com.saiki.motion.core.ParticularSim
import com.saiki.motion.core.PtGradient
import com.saiki.motion.core.PtGroup
import com.saiki.motion.core.PtParams
import com.saiki.motion.core.PtSprites
import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIGraphicsImageRenderer
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tan

// Port of Sources/UI/ParticularDraw.swift — CPU drawing of a Particular field (UI). One routine draws
// the designer viewport, the preset thumbnails and the tile art, using the same sprite-size, fade,
// gradient and falloff maths as the Metal point-sprite shader (MetalParticles.swift), so what the
// designer shows is what the viewport renders.

/** Projected particle: (x, y) in view space, size factor k, camera depth. */
class PtProj(val x: CGFloat, val y: CGFloat, val k: Float, val depth: Float)

typealias PtProject = (Float, Float, Float) -> PtProj?

/** Reads a colour parameter into RGBA components (0…1 each). */
typealias PtColorFn = (String, Long) -> FloatArray

object PtDraw {
    private val dots = HashMap<Int, Bitmap>()
    private var adapt = 1.0
    private val tinted = HashMap<String, Bitmap>()
    private val lock = Object()

    /** Cell image pre-tinted with a 4-bit colour (a clip-mask per particle is far slower than one cached draw). */
    private fun tintedCell(im: Bitmap, key: String, r: Int, g: Int, b: Int): Bitmap? {
        val k = "$key|$r$g$b"
        synchronized(lock) { tinted[k]?.let { return it } }
        val w = im.width; val h = im.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.argb(255, r * 255 / 15, g * 255 / 15, b * 255 / 15)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.xfermode = PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN)
        c.drawBitmap(im, 0f, 0f, p)
        synchronized(lock) { if (tinted.size > 500) tinted.clear(); tinted[k] = out }
        return out
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        if (e1 <= e0) return if (x < e0) 0f else 1f
        val t = min(1f, max(0f, (x - e0) / (e1 - e0)))
        return t * t * (3 - 2 * t)
    }

    /** Soft round sprite tinted with `rgb` (5 bits per channel) — falloff matches the fragment shader (`soft` 0…5 buckets). */
    private fun dot(r: Int, g: Int, b: Int, soft: Int): Bitmap? {
        val key = ((r * 32 + g) * 32 + b) * 8 + soft
        synchronized(lock) { dots[key]?.let { return it } }
        val s = soft / 5f
        val r0 = (1 - s) * 0.47f
        val img = UIGraphicsImageRenderer(40, 40).image { ctx ->
            val stops = floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f)
            val al = floatArrayOf(1f, 0.84f, 0.5f, 0.16f, 0f)
            val base = Color.argb(255, r * 255 / 31, g * 255 / 31, b * 255 / 31)
            val colors = IntArray(5) { i -> (base and 0x00FFFFFF) or (((al[i] * 255).toInt()) shl 24) }
            val loc = FloatArray(5) { i -> min(1f, r0 * 2f + (1 - r0 * 2f) * stops[i]) }
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = RadialGradient(20f, 20f, 20f, colors, loc, android.graphics.Shader.TileMode.CLAMP)
            ctx.canvas.drawCircle(20f, 20f, 20f, p)
        }
        synchronized(lock) { if (dots.size > 700) dots.clear(); dots[key] = img.bitmap }
        return img.bitmap
    }

    /** Draws the field into `c` (a `size`-sized area). `col` returns RGBA components of a colour parameter. */
    fun render(c: CGContext, size: CGSize, g: (String) -> Float, col: PtColorFn,
               time: Float, cam: PtProject, layerOpacity: Float = 1f, cap: Int = 2200, compH: CGFloat = 1920f, adaptive: Boolean = false) {
        val t0 = System.nanoTime() / 1e9
        fun deferAdapt() {
            if (adaptive) {   // keep the viewport smooth: shed particles when a frame is slow, win them back when fast
                val ms = (System.nanoTime() / 1e9 - t0) * 1000
                synchronized(lock) { adapt = if (ms > 14) max(0.2, adapt * 0.8) else (if (ms < 6) min(1.0, adapt * 1.08) else adapt) }
            }
        }
        val ad = if (adaptive) synchronized(lock) { adapt } else 1.0
        val hasSprite = PtSprites.set(g) != null
        val cap2 = max(120, (cap * ad * (if (hasSprite) 0.45 else 1.0)).toInt())
        val step = max(1, ParticularSim.total(g) / cap2)
        val field = ParticularSim.field(g, time, step)
        val stride = 1
        val fd = ParticularSim.fades(g); val fin = fd.first; val fout = fd.second
        val op = g("ptOpacity") * layerOpacity; val psz = g("ptSize")
        val grad = PtGradient.active(g); val byRand = g("ptGrBy") >= 0.5f
        val ca = col("ptColA", ParticularSim.defA.toLong() and 0xFFFFFFFFL)
        val cb = col("ptColB", ParticularSim.defB.toLong() and 0xFFFFFFFFL)
        val sprite = PtSprites.set(g); val tint = g("ptSpriteTint"); val anim = g("ptSpriteAnim") >= 0.5f; val imgCol = g("ptImgColor")
        val emT = Math.round(g("ptEmType")).toInt(); val useImgCol = emT == 13 || emT == 14
        val minPx = 4f * size.height / compH
        val glow = g("ptGlow"); val glowSize = g("ptGlowSize")

        class Item(val x: CGFloat, val y: CGFloat, val depth: Float, val ps: CGFloat, val q: Particle)
        val list = ArrayList<Item>(field.size / stride + 1)
        for ((i, q) in field.withIndex()) if (i % stride == 0) {
            val p = cam(q.x, q.y, q.z) ?: continue
            val ps = max(minPx, psz * size.height * 0.5f * q.size * p.k * (1 + q.soft * 0.35f))
            list.add(Item(p.x, p.y, p.depth, ps, q))
        }
        list.sortByDescending { it.depth }
        for (it in list) {
            val q = it.q
            val life = min(max(q.life, 0f), 1f)
            val fade = smooth(0f, fin, life) * (1 - smooth(1 - fout, 1f, life))
            var rgba: FloatArray
            if (grad != null) {
                val v = PtGradient.eval(grad, if (byRand) q.vari else life)
                rgba = floatArrayOf(v[0], v[1], v[2], v[3])
            } else {
                val l = life
                rgba = FloatArray(4) { i -> ca[i] + (cb[i] - ca[i]) * l }
            }
            if (useImgCol && imgCol > 0f) {
                rgba[0] += (q.cr - rgba[0]) * imgCol; rgba[1] += (q.cg - rgba[1]) * imgCol; rgba[2] += (q.cb - rgba[2]) * imgCol
            }
            val a = (fade * op * q.alpha) * rgba[3]
            if (a < 0.004f) continue
            val r = CGRect(-it.ps / 2f, -it.ps / 2f, it.ps, it.ps)
            c.saveGState()
            c.translateBy(it.x, it.y)
            if (glow > 0.001f) {
                val d5 = dot((min(1f, max(0f, rgba[0])) * 31 + 0.5f).toInt(), (min(1f, max(0f, rgba[1])) * 31 + 0.5f).toInt(), (min(1f, max(0f, rgba[2])) * 31 + 0.5f).toInt(), 5)
                if (d5 != null) {
                    val big = it.ps * (1 + glowSize)
                    c.setAlpha(min(1f, a * glow * 0.5f))
                    c.canvas.drawBitmap(d5, null, RectF(-big / 2f, -big / 2f, big / 2f, big / 2f), c.paint)
                    c.setAlpha(1f)
                }
            }
            if (sprite != null && sprite.cells > 0) {
                c.rotate(q.rot); c.scaleBy(1f, -1f)
                val idx = min(sprite.cells - 1, floor((if (anim) min(life, 0.999f) else q.vari) * sprite.cells).toInt())
                if (idx >= 0 && idx < sprite.cells) {
                    // the atlas is a grid*grid sheet of cells
                    val gcol = if (sprite.grid > 0) sprite.grid else sprite.cells
                    val cw = sprite.bmp.width.toFloat() / gcol
                    val chh = sprite.bmp.height.toFloat() / gcol
                    val sx = (idx % gcol) * cw; val sy = (idx / gcol) * chh
                    val cellBmp = Bitmap.createBitmap(sprite.bmp, sx.toInt(), sy.toInt(), cw.toInt().coerceAtLeast(1), chh.toInt().coerceAtLeast(1))
                    val draw: Bitmap? = if (tint > 0.5f) {
                        fun q4(v: Float): Int = (min(1f, max(0f, v)) * 15 + 0.5f).toInt()
                        tintedCell(cellBmp, "${sprite.key}#$idx", q4(rgba[0]), q4(rgba[1]), q4(rgba[2]))
                    } else cellBmp
                    if (draw != null) {
                        c.setAlpha(min(1f, a))
                        c.canvas.drawBitmap(draw, null, r.toRectF(), c.paint)
                    }
                }
            } else {
                val rr = (min(1f, max(0f, rgba[0])) * 31 + 0.5f).toInt()
                val gg = (min(1f, max(0f, rgba[1])) * 31 + 0.5f).toInt()
                val bb = (min(1f, max(0f, rgba[2])) * 31 + 0.5f).toInt()
                val d = dot(rr, gg, bb, min(5, (q.soft * 5 + 0.5f).toInt()))
                if (d != null) {
                    c.setAlpha(min(1f, a))
                    val e = r.insetBy(-it.ps * 0.02f, -it.ps * 0.02f)
                    c.canvas.drawBitmap(d, null, e.toRectF(), c.paint)
                }
            }
            c.restoreGState()
        }
        deferAdapt()
    }

    /** Free orbit camera (also the preset-thumbnail camera). Sizes use the real camera's size law (3 / depth). */
    fun orbit(yaw: CGFloat, pitch: CGFloat, dist: CGFloat, fovDeg: Float, size: CGSize): PtProject {
        val cy = cos(yaw); val sy = sin(yaw); val cp = cos(pitch); val sp = sin(pitch)
        val f = 1f / tan(fovDeg * Math.PI.toFloat() / 360f)
        return { x, y, z ->
            val X = x.toFloat(); val Y = y.toFloat(); val Z = z.toFloat()
            val x1 = X * cy + Z * sy; val z1 = -X * sy + Z * cy
            val y2 = Y * cp - z1 * sp; val z2 = Y * sp + z1 * cp
            val d = dist - z2
            if (d < 0.2f) null
            else {
                val k = size.height * 0.5f * f / d
                PtProj(size.width / 2f + x1 * k, size.height / 2f - y2 * k, 3f / d, d)
            }
        }
    }

    /** The real comp camera: layer transform, layer rotation / depth and the comp view-projection
     *  (same steps as MetalParticleRenderer.draw). */
    fun comp(vp: FloatArray, m: FloatArray, layerZ: Float, rotXDeg: Float, rotYDeg: Float, use3D: Boolean, aspect: Float, size: CGSize): PtProject {
        val pd = Math.PI.toFloat() / 180f
        val prx = rotXDeg * pd; val pry = -rotYDeg * pd
        val pcx = cos(prx); val psx = sin(prx); val pcy = cos(pry); val psy = sin(pry)
        val pRot = prx != 0f || pry != 0f
        return project@{ x0, y0, z0 ->
            var x = x0; var y = y0; var z = z0
            if (pRot) {
                val x1 = x * pcy + z * psy; val z1 = -x * psy + z * pcy
                val y2 = y * pcx - z1 * psx; val z2 = y * psx + z1 * pcx
                x = x1; y = y2; z = z2
            }
            z += layerZ
            var wx = m[0] * x + m[2] * y + m[4]; var wy = m[1] * x + m[3] * y + m[5]
            if (use3D) {
                val cx = vp[0] * wx + vp[4] * wy + vp[8] * z + vp[12]
                val cy = vp[1] * wx + vp[5] * wy + vp[9] * z + vp[13]
                val cw = vp[3] * wx + vp[7] * wy + vp[11] * z + vp[15]
                if (cw <= 0.05f) return@project null
                val nx = cx / max(abs(cw), 0.0001f); val ny = cy / max(abs(cw), 0.0001f)
                PtProj((nx * 0.5f + 0.5f) * size.width, (0.5f - ny * 0.5f) * size.height, 3f / max(cw, 0.05f), cw)
            } else {
                val pf = 1f / max(0.2f, 1f - z / 3f)
                wx *= pf; wy *= pf
                val nx = wx / aspect; val ny = wy
                PtProj((nx * 0.5f + 0.5f) * size.width, (0.5f - ny * 0.5f) * size.height, pf, 1f / pf)
            }
        }
    }
}

// MARK: - Thumbnails (a real render of the particle, cached)

object PtThumb {
    private val cache = HashMap<String, UIImage>()
    private val lock = Object()

    fun cached(key: String): UIImage? = synchronized(lock) { cache[key] }

    fun color(d: Map<String, Float>, pre: String = ""): PtColorFn {
        return { k, _ ->
            val suf = listOf("_r", "_g", "_b", "_a")
            FloatArray(4) { i -> d[pre + k + suf[i]] ?: PtParams.def(pre + k + suf[i]) }
        }
    }

    fun render(params: Map<String, Float>, time: Float, yaw: CGFloat = 0.25f, pitch: CGFloat = 0.12f, dist: CGFloat = 3.3f, size: CGFloat = 96f): UIImage {
        val S = 420f
        return UIGraphicsImageRenderer(size.toInt().coerceAtLeast(1), size.toInt().coerceAtLeast(1)).image { ctx ->
            val c = ctx
            c.canvas.scale(size / S, size / S)
            c.setFillColor(0xFF070707.toInt())
            c.fill(CGRect(0f, 0f, S, S))
            val g = PtParams.reader(params)
            val n = PtGroup.count(g)
            for (gi in 0 until n) {
                PtDraw.render(c, size = CGSize(S, S), g = PtGroup.reader(g, gi), col = color(params, PtGroup.pre(gi)), time = time,
                    cam = PtDraw.orbit(yaw = yaw, pitch = pitch, dist = dist, fovDeg = 55f, size = CGSize(S, S)), cap = 450 / n, compH = 1000f)
            }
        }
    }

    /// Renders on a background thread; `done` runs on main. Same key → cached image.
    fun make(key: String, params: Map<String, Float>, time: Float, yaw: CGFloat = 0.25f, pitch: CGFloat = 0.12f, dist: CGFloat = 3.3f, done: (UIImage) -> Unit) {
        cached(key)?.let { i -> done(i); return }
        Thread {
            val img = render(params, time, yaw, pitch, dist)
            synchronized(lock) { cache[key] = img }
            android.os.Handler(android.os.Looper.getMainLooper()).post { done(img) }
        }.start()
    }

    /// Params for a small "what does this emitter look like" snapshot.
    fun emitterParams(type: Int): Map<String, Float> {
        val p = HashMap<String, Float>()
        p["ptEmType"] = type.toFloat(); p["ptBehavior"] = 1f; p["ptVel"] = 0f; p["ptLife"] = 2f; p["ptRate"] = 260f; p["ptSize"] = 0.03f
        p["ptSoft"] = 0.3f; p["ptSizeX"] = 0.6f; p["ptSizeY"] = 0.6f; p["ptSizeZ"] = 0.6f; p["ptFadeIn"] = 0.001f
        p["ptFadeOut"] = 0.001f; p["ptSizeRand"] = 0.2f; p["ptSwirl"] = 0f; p["ptGravity"] = 0f; p["ptTurb"] = 0f
        if (type == 9) p["ptSizeY"] = 0.22f
        if (type == 6) p["ptSizeX"] = 0.8f
        if (type == 0) { p["ptSize"] = 0.05f; p["ptRate"] = 40f }
        p.putAll(PtParams.color("ptColA", 0xFFFFFFFF.toInt()))
        p.putAll(PtParams.color("ptColB", 0xFF9DDCFF.toInt()))
        return p
    }
}
