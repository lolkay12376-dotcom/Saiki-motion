@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/PlyQualitySheet.swift — asks Low / Balanced / Full when a point cloud is too
// big for a phone.

package com.saiki.motion.ui

import com.saiki.motion.core.PlyImport
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import java.util.Locale
import kotlin.math.min

class PlyQualitySheet(context: android.content.Context) : UiView(context) {
    private var done: ((Int) -> Unit)? = null
    private var answered = false
    private var countAll = 0
    private val card = UiView(appContext!!)

    companion object {
        fun show(host: UiView, count: Int, pick: (Int) -> Unit) {
            val s = PlyQualitySheet(appContext!!)
            s.frame = CGRect(0f, 0f, host.rectWidth(), host.rectHeight())
            s.done = pick
            s.build(count)
            host.addSubview(s)
            s.onLayout = { _ ->
                s.frame = CGRect(0f, 0f, host.rectWidth(), host.rectHeight())
                s.layoutCard()
            }
            s.layoutCard()
        }
    }

    private fun answer(n: Int) {
        if (answered) return
        answered = true
        done?.invoke(n)
        removeFromSuperview()
    }

    private fun layoutCard() {
        val w = rectWidth().coerceAtLeast(1f)
        val cw = min(w * 0.88f, 420f)
        card.frame = CGRect((w - cw) / 2, (rectHeight() - 300f) / 2, cw, 300f)
        var y = 20f
        for (v in card.subviews) {
            val vh = if (v is UILabel) (if (v.numberOfLines == 0) 40f else 24f) else 48f
            v.frame = CGRect(18f, y, cw - 36f, vh)
            y += vh + 10f
        }
    }

    private fun build(count: Int) {
        countAll = count
        val dim = UiView(appContext!!)
        dim.setBackgroundColor(0x8C000000.toInt())
        dim.frame = boundsRect
        dim.onClick = { }      // no dismiss on tap: a choice is required
        addSubview(dim)
        card.setBackgroundColor(C.PANEL)
        addSubview(card)
        fun label(t: String, size: CGFloat, bold: Boolean, col: Int) {
            val l = UILabel(appContext!!)
            l.text = t; l.numberOfLines = 0
            l.font = if (bold) UIFont.boldSystemFont(size) else UIFont.systemFont(size)
            l.textColor = argbToUIColor(col)
            card.addSubview(l)
        }
        fun button(title: String, sub: String, fill: Int, tc: Int, act: () -> Unit) {
            val b = PillButton("$title  ·  $sub", null, fill, tc)
            b.textSize = 15f
            b.onClick = act
            card.addSubview(b)
        }
        fun fmt(n: Int): String = if (n >= 1_000_000) String.format(Locale.US, "%.1fM", n / 1e6) else "${n / 1000}k"
        label("This point cloud is large", 18f, true, C.TEXT)
        label("${fmt(count)} points. More points look better but are slower and use more memory.", 13f, false, C.DIM)
        button("Low", "${fmt(PlyImport.low)} points, fastest", C.CARD2, C.TEXT) { answer(PlyImport.low) }
        button("Balanced", "${fmt(PlyImport.balanced)} points, recommended", C.GREEN, C.ONDARK) { answer(PlyImport.balanced) }
        button("Full", "${fmt(min(count, PlyImport.fullCap))} points, heavy", C.CARD2, C.TEXT) { answer(min(countAll, PlyImport.fullCap)) }
    }
}
