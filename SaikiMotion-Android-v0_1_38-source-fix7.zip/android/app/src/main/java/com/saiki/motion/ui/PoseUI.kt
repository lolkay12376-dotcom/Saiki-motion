@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName", "PropertyName")

// Port of Sources/UI/PoseUI.swift — the app's own flat controls for the 3D editor panels (no
// UISwitch / UISlider / UISegmentedControl / system buttons) plus the bone tree used by the Bones tab.

package com.saiki.motion.ui

import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIControl
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.fillRoundRect
import kotlin.math.max
import kotlin.math.min

/** PoseUI.swift enum Flat — palette + centered text helper for the flat controls. */
object Flat {
    const val accent: Int = 0xFFFF8C14.toInt()          // UIColor(red: 1, green: 0.55, blue: 0.08, alpha: 1)
    const val card: Int = 0xFF2B2B2B.toInt()            // white 0.17
    const val card2: Int = 0xFF3D3D3D.toInt()           // white 0.24
    const val dim: Int = 0xFF9E9E9E.toInt()             // white 0.62
    const val danger: Int = 0xFFD94740.toInt()          // UIColor(red: 0.85, green: 0.28, blue: 0.25, alpha: 1)

    /** Flat.text: vertically centered, truncating single line. */
    fun text(s: String, size: CGFloat, color: Int, bold: Boolean = false, inR: CGRect, align: NSTextAlignment = NSTextAlignment.center) {
        val h = size * 1.21f
        drawTextLine(s, inR.minX, inR.midY - h / 2f + h * 0.78f, inR.width, color, size, bold, align)
    }

    /** Draw with horizontal clipping + truncation inside `w` (NSString.draw(in:) truncating tail). */
    fun drawTextLine(s: String, x: CGFloat, baseline: CGFloat, w: CGFloat, color: Int, size: CGFloat, bold: Boolean, align: NSTextAlignment) {
        val c = UIGraphics.getCurrentContext() ?: return
        var txt = s
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color; typeface = if (bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
        }
        while (txt.isNotEmpty() && p.measureText(txt) > w && txt.length > 1) txt = txt.dropLast(1)
        if (txt != s && txt.isNotEmpty()) txt = txt.dropLast(1) + "…"
        val tw = p.measureText(txt)
        var px = x
        if (align == NSTextAlignment.center) px += (w - tw) / 2f else if (align == NSTextAlignment.right) px += w - tw
        c.canvas.drawText(txt, px, baseline, p)
    }
}

/** On / off switch (PoseUI.swift:23). */
class FlatSwitch(on: Boolean) : UIControl(appContext!!) {
    var isOn = on
        set(v) { field = v; setNeedsDisplay() }
    /** Kept so old call sites compile; the on colour is the app accent (PoseUI.swift bottom extension). */
    var onTintColor: Int? get() = Flat.accent; set(@Suppress("UNUSED_PARAMETER") _) {}

    init { onClick = { isOn = !isOn; onValueChanged?.invoke(isOn) } }

    var onValueChanged: ((Boolean) -> Unit)? = null

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val y = (rect.height - 26f) / 2f
        fillRoundRect(c, CGRect(0f, y, 46f, 26f), 13f, if (isOn) Flat.accent else Flat.card2)
        c.setFillColor(0xFFFFFFFF.toInt())
        val x = if (isOn) 46f - 23f else 0f + 3f
        c.fillEllipse(CGRect(x, y + 3f, 20f, 20f))
    }
}

/// Flat rounded button (PoseUI.swift:43).
class FlatButton(title: String, fill: Int = Flat.card, height: CGFloat = 40f, textColor: Int = 0xFFFFFFFF.toInt()) : UIControl(appContext!!) {
    var onTap: (() -> Unit)? = null
    var title = title
        set(v) { field = v; setNeedsDisplay() }
    private val fillCol = fill
    private val txtCol = textColor
    val btnH = height

    init { onClick = { onTap?.invoke() } }

    fun setMenu(items: List<Pair<String, () -> Unit>>) {
        // iOS sets a UIButton menu (popup); on this layer a small popover rides below the button.
        onTap = menu@{
            val win = appKeyWindow() ?: return@menu
            val m = UiView(appContext!!)
            m.setBackgroundColor(0xF2242428.toInt())
            win.addSubview(m)
            var y = 6f
            for ((t, act) in items) {
                val rowH = 40f
                val rowT = t
                val row = object : TapView() {
                    public override fun draw(rect: CGRect) {
                        Flat.text(rowT, 14f, 0xFFFFFFFF.toInt(), inR = CGRect(10f, 0f, rect.width - 20f, rect.height), align = NSTextAlignment.left)
                    }
                }
                row.frame = CGRect(0f, y, 240f, rowH)
                row.onClick = { act(); m.removeFromSuperview() }
                m.addSubview(row)
                y += rowH
            }
            val a = convertBoundsTo(win)
            m.frame = CGRect(a.right - 246f, a.bottom + 4f, 246f, y + 6f)
            val out = object : TapView() {
                public override fun draw(rect: CGRect) {}
            }
            out.frame = CGRect(0f, 0f, win.rectWidth(), win.rectHeight())
            out.onClick = { out.removeFromSuperview(); m.removeFromSuperview() }
            out.setBackgroundColor(0x01000000)
            win.addSubview(out)
        }
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val alphaSave = if (isHighlighted) 0.6f else 1f
        c.paint.alpha = (alphaSave * 255).toInt()
        fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 10f, fillCol)
        c.paint.alpha = 255
        Flat.text(title, 14f, txtCol, bold = true, inR = CGRect(8f, 0f, max(0f, rect.width - 16f), rect.height))
    }
}

/// Segmented selector (PoseUI.swift:75, same API as the parts of UISegmentedControl the panels use).
class FlatSegment(val items: List<String>, sel: Int = 0) : UIControl(appContext!!) {
    var selectedSegmentIndex = sel
        set(v) { field = v; setNeedsDisplay() }
    /** Kept so old call sites compile (PoseUI.swift bottom extension). */
    var selectedSegmentTintColor: Int? get() = Flat.accent; set(@Suppress("UNUSED_PARAMETER") _) {}

    var onValueChanged: (() -> Unit)? = null

    init { setNeedsDisplay() }

    override fun touchesEnded(touches: Set<UITouch>, with: com.saiki.motion.uikit.UIEvent?) {
        val t = touches.firstOrNull() ?: return
        if (items.isEmpty()) return
        val w = rectWidth() / items.count().toFloat()
        val i = min(max((t.location(this).x / w).toInt(), 0), items.count() - 1)
        if (i != selectedSegmentIndex) { selectedSegmentIndex = i; onValueChanged?.invoke() }
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 9f, Flat.card)
        if (items.isEmpty()) return
        val w = rect.width / items.count().toFloat()
        for ((i, t) in items.withIndex()) {
            val r = CGRect(w * i, 0f, w, rect.height)
            if (i == selectedSegmentIndex) fillRoundRect(c, r.insetBy(2f, 2f), 7f, Flat.accent)
            Flat.text(t, if (items.count() > 4) 10f else 13f, if (i == selectedSegmentIndex) 0xFF000000.toInt() else 0xFFFFFFFF.toInt(),
                bold = true, inR = r)
        }
    }
}

/// Drag track (PoseUI.swift:102). Fills from the left, or from the centre for ranges around zero. Double tap resets to `def`.
class FlatTrack(lo: Float, hi: Float, v: Float, val def: Float = 0f) : UIControl(appContext!!) {
    var lo = lo
    var hi = hi
    var value = v
        set(v) { field = v; setNeedsDisplay() }
    var bipolar = lo < 0f && hi > 0f
    var onDragBegin: (() -> Unit)? = null
    var onChange: ((Float) -> Unit)? = null
    var onEnd: (() -> Unit)? = null
    private var dragging = false

    init {
        val dt = com.saiki.motion.uikit.UITapGestureRecognizer { if (lastTapForDouble()) { onDragBegin?.invoke(); set(def); onEnd?.invoke() } }
        dt.numberOfTapsRequired = 2
        addGestureRecognizer(dt)
    }

    private var lastTapT = 0L
    private fun lastTapForDouble(): Boolean {
        val now = android.os.SystemClock.uptimeMillis()
        val dbl = now - lastTapT < 320
        lastTapT = now
        return dbl
    }

    fun set(v: Float) { value = min(max(v, lo), hi); onChange?.invoke(value) }

    private fun at(x: CGFloat) { set(lo + min(max(x / max(rectWidth(), 1f), 0f), 1f) * (hi - lo)) }

    override fun touchesBegan(touches: Set<UITouch>, with: com.saiki.motion.uikit.UIEvent?) {
        val t = touches.firstOrNull() ?: return
        onDragBegin?.invoke(); dragging = true; at(t.location(this).x)
    }
    override fun touchesMoved(touches: Set<UITouch>, with: com.saiki.motion.uikit.UIEvent?) {
        val t = touches.firstOrNull() ?: return
        if (dragging) at(t.location(this).x)
    }
    override fun touchesEnded(touches: Set<UITouch>, with: com.saiki.motion.uikit.UIEvent?) { dragging = false; onEnd?.invoke() }
    override fun touchesCancelled(touches: Set<UITouch>, with: com.saiki.motion.uikit.UIEvent?) { dragging = false; onEnd?.invoke() }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val r = CGRect(0f, rect.midY - 8f, rect.width, 16f)
        fillRoundRect(c, r, 8f, Flat.card)
        val f = (value - lo) / max(hi - lo, 1e-9f)
        val zero = if (bipolar) (0f - lo) / (hi - lo) else 0f
        val a = min(f, zero) * r.width; val b = max(f, zero) * r.width
        fillRoundRect(c, CGRect(a, r.minY, max(b - a, 2f), r.height), 8f, Flat.accent)
        c.setFillColor(0xFFFFFFFF.toInt())
        val kx = min(max(f * r.width - 9f, 0f), r.width - 18f)
        c.fillEllipse(CGRect(kx, rect.midY - 9f, 18f, 18f))
        if (bipolar) { c.setFillColor(Flat.dim); c.fill(CGRect(zero * r.width - 0.5f, r.minY - 2f, 1f, r.height + 4f)) }
    }
}

/** Labelled slider row: name, value, [-] track [+] (nudge by `step`) (PoseUI.swift:140). */
class FlatSlider(name: String, lo: Float, hi: Float, v: Float, step: Float, fmt: String, def: Float = 0f,
                 onBegin: () -> Unit, onChange: (Float) -> Unit, onEnd: () -> Unit) : UiView(appContext!!) {
    private val track = FlatTrack(lo, hi, v, def)
    private var valText: String = String.format(java.util.Locale.US, fmt, v)
    private val nudgeMinus = TapView()
    private val nudgePlus = TapView()

    var label: String = name

    /** Re-reads the current value (call sites that keep their own state). */
    fun set(v: Float) = track.set(v)

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        com.saiki.motion.uikit.drawText(label, 0f, 14f, color = 0xFFFFFFFF.toInt(), size = 14f)
        com.saiki.motion.uikit.drawText(valText, rect.width, 14f, color = Flat.dim, size = 13f, align = NSTextAlignment.right)
        // nudge buttons
        fillRoundRect(c, CGRect(0f, rect.height - 30f, 34f, 30f), 10f, Flat.card)
        Flat.text("-", 14f, 0xFFFFFFFF.toInt(), bold = true, inR = CGRect(0f, rect.height - 30f, 34f, 30f))
        fillRoundRect(c, CGRect(rect.width - 34f, rect.height - 30f, 34f, 30f), 10f, Flat.card)
        Flat.text("+", 14f, 0xFFFFFFFF.toInt(), bold = true, inR = CGRect(rect.width - 34f, rect.height - 30f, 34f, 30f))
    }

    init {
        track.onDragBegin = onBegin
        track.onEnd = onEnd
        track.onChange = { x -> valText = String.format(java.util.Locale.US, fmt, x); onChange(x); setNeedsDisplay() }
        addSubview(track)
        nudgeMinus.onClick = { onBegin(); track.set(track.value - step); onEnd() }
        nudgePlus.onClick = { onBegin(); track.set(track.value + step); onEnd() }
        addSubview(nudgeMinus); addSubview(nudgePlus)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        track.frame = CGRect(40f, rectHeight() - 34f, max(0f, rectWidth() - 80f), 34f)
        nudgeMinus.frame = CGRect(0f, rectHeight() - 30f, 34f, 30f)
        nudgePlus.frame = CGRect(rectWidth() - 34f, rectHeight() - 30f, 34f, 30f)
    }
}

/** Small text field for the bone search (flat, no system chrome) (PoseUI.swift:165). */
class FlatField : com.saiki.motion.uikit.UITextField(appContext!!) {
    init {
        setBackgroundColor(Flat.card)
        placeholder = "Search bones"
        backing.setPadding(24, 0, 24, 0)
    }
}

/** One row of the bone tree (PoseUI.swift:179). */
class BoneRow(name: String, depth: Int, selected: Boolean, physics: Boolean, posed: Boolean) : UIControl(appContext!!) {
    var onTap: (() -> Unit)? = null
    private val nm = name
    private val ind = min(depth, 12) * 10 + 10
    private val dotCol = if (physics) 0xFFFF4DE6.toInt() else (if (posed) Flat.accent else 0xFF33D9FF.toInt())

    init { if (selected) setBackgroundColor(0x59FF8C14.toInt()) else setBackgroundColor(Flat.card); onClick = { onTap?.invoke() } }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        if (rect.width > 40f) {
            c.setFillColor(dotCol)
            c.fillEllipse(CGRect(ind.toFloat() + 8f, rect.midY - 4f, 8f, 8f))
            Flat.text(nm, 13f, 0xFFFFFFFF.toInt(), bold = false, inR = CGRect(ind.toFloat() + 24f, 0f, rect.width - ind - 32f, rect.height), align = NSTextAlignment.left)
        }
    }
}

/** Same API as the parts of UISlider the older panels use (PoseUI.swift:205 FlatUISlider). */
class FlatUISlider : UIControl(appContext!!) {
    var minimumValue = 0f
        set(v) { field = v; setNeedsDisplay() }
    var maximumValue = 1f
        set(v) { field = v; setNeedsDisplay() }
    var value = 0f
        set(v) { field = v; setNeedsDisplay() }
    var tintColor: Int? = null
    var onValueChanged: (() -> Unit)? = null

    private fun at(x: CGFloat) {
        val v = minimumValue + min(max(x / max(rectWidth(), 1f), 0f), 1f) * (maximumValue - minimumValue)
        if (v != value) { value = v; onValueChanged?.invoke() }
    }

    override fun touchesBegan(touches: Set<UITouch>, with: com.saiki.motion.uikit.UIEvent?) { val t = touches.firstOrNull() ?: return; at(t.location(this).x) }
    override fun touchesMoved(touches: Set<UITouch>, with: com.saiki.motion.uikit.UIEvent?) { val t = touches.firstOrNull() ?: return; at(t.location(this).x) }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val r = CGRect(0f, rect.midY - 8f, rect.width, 16f)
        fillRoundRect(c, r, 8f, Flat.card)
        val f = (value - minimumValue) / max(maximumValue - minimumValue, 1e-9f)
        fillRoundRect(c, CGRect(0f, r.minY, max(f * r.width, 4f), r.height), 8f, tintColor ?: Flat.accent)
        c.setFillColor(0xFFFFFFFF.toInt())
        val kx = min(max(f * r.width - 9f, 0f), r.width - 18f)
        c.fillEllipse(CGRect(kx, rect.midY - 9f, 18f, 18f))
    }
}
