@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/PreRenderOverlay.swift — full-screen progress for baking a group (UI).
// Same look as the Render screen (ring, bar, frames + ETA, Cancel). Frames are baked one per
// run-loop turn on the main thread, so the ring keeps animating and Cancel always responds.

package com.saiki.motion.ui

import android.graphics.BitmapFactory
import com.saiki.motion.app.Snack
import com.saiki.motion.core.Layer
import com.saiki.motion.core.PreRender
import com.saiki.motion.core.Project
import com.saiki.motion.core.Scene
import com.saiki.motion.core.SceneRenderer
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor

class PreRenderProgressViewController(
    private val group: Layer, private val project: Project, private val scene: Scene, private val quality: Int,
    private val bake: (Layer, Int) -> Boolean,
    private val onDone: (Boolean) -> Unit) : UIViewController() {

    private val size: IntArray = SceneRenderer.size(project, quality)
    private val ring = RenderRingView(appContext!!)
    private val bar = RenderBarView(appContext!!)
    private val titleL = UILabel(appContext!!)
    private val sub = UILabel(appContext!!)
    private val etaL = UILabel(appContext!!)
    private val girl = object : UiView(appContext!!) {
        var frames: List<android.graphics.Bitmap> = emptyList()
        var t0 = android.os.SystemClock.uptimeMillis()
        public override fun draw(rect: CGRect) {
            if (frames.isEmpty()) return
            val c = com.saiki.motion.uikit.UIGraphics.getCurrentContext() ?: return
            val dur = 1600f
            val i = (((android.os.SystemClock.uptimeMillis() - t0) % dur.toLong()) / dur * frames.size).toInt().coerceIn(0, frames.size - 1)
            c.canvas.drawBitmap(frames[i], null, android.graphics.RectF(0f, 0f, rect.width, rect.height),
                android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
            postInvalidateOnAnimation()
        }
    }
    private val cancelB = PillButton("Cancel", "close", C.CARD2, C.TEXT)
    private var cancelled = false
    private var finished = false
    private var failures = 0
    private var startedAt = System.currentTimeMillis()
    private var startDone = 0
    private val stepHandler = android.os.Handler(android.os.Looper.getMainLooper())

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(0xFF0B0B10.toInt())
        // sleeping girl frames
        val frames = ArrayList<android.graphics.Bitmap>()
        for (i in 0 until 7) {
            val rid = appContext!!.resources.getIdentifier("render_f$i", "drawable", appContext!!.packageName)
            if (rid != 0) frames.add(BitmapFactory.decodeResource(appContext!!.resources, rid))
        }
        girl.frames = frames
        view.addSubview(girl)
        titleL.text = "Pre-rendering"
        titleL.textColor = argbToUIColor(C.TEXT); titleL.font = boldFont(20f); titleL.textAlignment = NSTextAlignment.center
        view.addSubview(titleL)
        view.addSubview(ring)
        sub.text = group.name
        sub.textColor = argbToUIColor(C.DIM); sub.font = sysFont(13f); sub.textAlignment = NSTextAlignment.center
        view.addSubview(sub)
        view.addSubview(bar)
        etaL.text = " "
        etaL.textColor = argbToUIColor(C.DIM); etaL.font = sysFont(12f); etaL.textAlignment = NSTextAlignment.center
        view.addSubview(etaL)
        cancelB.onClick = {
            cancelled = true
            etaL.text = "Cancelling…"
            cancelB.isUserInteractionEnabled = false
        }
        view.addSubview(cancelB)
        relayout()
        view.onLayout = { _ -> relayout() }
        ring.startAnimating(); bar.startAnimating()
        val sig = PreRender.signature(group, project, scene)
        PreRender.purgeStaleOnce(project.id, group.id, sig)
        startDone = PreRender.progress(group, project, scene, size[0], size[1]).first
        startedAt = System.currentTimeMillis()
        // let the screen appear first, then start baking
        stepHandler.postDelayed({ step() }, 350)
    }

    private fun relayout() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w < 10 || h < 10) return
        titleL.frame = CGRect(0f, h / 2 - 172f, w, 24f)
        girl.frame = CGRect(w / 2 - 60f, titleL.frame.minY - 128f, 120f, 120f)
        ring.frame = CGRect(w / 2 - 84f, h / 2 - 84f, 168f, 168f)
        sub.frame = CGRect(0f, ring.frame.maxY + 22f, w, 18f)
        bar.frame = CGRect(w / 2 - 130f, sub.frame.maxY + 18f, 260f, 8f)
        etaL.frame = CGRect(0f, bar.frame.maxY + 10f, w, 18f)
        cancelB.frame = CGRect(w / 2 - 66f, etaL.frame.maxY + 22f, 132f, 42f)
    }

    private fun step() {
        if (finished) return
        if (cancelled) { finish(false); return }
        val idx = PreRender.nextMissing(group, project, scene, size[0], size[1], group.start)
        if (idx == null) { finish(true); return }
        if (!bake(group, idx)) {
            failures += 1
            if (failures >= 3) { finish(false, error = "Could not render this group."); return }
        }
        val (done, total) = PreRender.progress(group, project, scene, size[0], size[1])
        val p = done.toFloat() / maxOf(total, 1).toFloat()
        ring.progress = p
        bar.progress = p
        val n = done - startDone
        if (n > 3) {
            val eta = (System.currentTimeMillis() - startedAt) / 1000.0 / n * maxOf(0, total - done)
            etaL.text = "$done / $total frames  ·  ~${eta.toInt()} s left"
        } else {
            etaL.text = "$done / $total frames"
        }
        stepHandler.postDelayed({ step() }, 2)
    }

    private fun finish(ok: Boolean, error: String? = null) {
        if (finished) return
        finished = true
        ring.stopAnimating(); bar.stopAnimating()
        dismiss(animated = true) { onDone(ok) }
        if (error != null) Snack.show(error)
    }
}
