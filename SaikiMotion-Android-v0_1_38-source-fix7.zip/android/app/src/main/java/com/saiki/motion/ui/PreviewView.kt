@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import com.saiki.motion.core.Editor
import com.saiki.motion.core.FrameCache
import com.saiki.motion.core.Layer
import com.saiki.motion.core.Rig
import com.saiki.motion.core.SceneRenderer
import com.saiki.motion.core.VideoFrames
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import kotlin.math.max
import kotlin.math.min

// Port of Sources/UI/PreviewView.swift — the preview surface.
// iOS: GLKView with its own GLES context + a Metal overlay view. Android: a plain UiView whose
// draw renders the scene through the Vulkan SceneRenderer (SceneRendererInstance) and blits the
// frame bitmap; the VideoSource role keeps per-layer async samplers and a fresh frame triggers a redraw.

class PreviewView(context: android.content.Context) : UiView(context) {

    var quality = 1
        set(v) { field = v; setNeedsDisplay() }

    private var renderer: com.saiki.motion.core.SceneRendererInstance? = null
    private val samplers = HashMap<Int, VideoFrames.Sampler>()

    // Freeze guard: if playback is running but no frame was drawn for >1s (a lag spike swallowed the
    // redraw), kick it. Timer twin = repeating Handler tick (iOS Timer.scheduledTimer 0.6s).
    private var lastDrawTs = android.os.SystemClock.uptimeMillis().toDouble()
    private val kickHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val kick: Runnable = object : Runnable {
        override fun run() {
            if (window != null) {
                val now = android.os.SystemClock.uptimeMillis().toDouble()
                if (now - lastDrawTs > 1000.0 && (FrameCache.playing || FrameCache.scrubbing)) {
                    // PARITY-NOTE(PreviewView.swift:45): iOS hides the separate metalView layer so the GL view underneath shows;
                    // the Android preview is a single Canvas surface, so there is no second view to hide — setNeedsDisplay() alone redraws.
                    setNeedsDisplay()
                } else if (now - lastDrawTs > 2500.0) {
                    setNeedsDisplay()
                }
            }
            kickHandler.postDelayed(this, 600)
        }
    }

    init {
        setBackgroundColor(android.graphics.Color.BLACK)
        SceneRenderer.onVideoFrame = { setNeedsDisplay() }
        SceneRenderer.onFault = { setNeedsDisplay() }
        kickHandler.postDelayed(kick, 600)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        kickHandler.removeCallbacks(kick)
    }

    /** Kotlin: preview.onResume() — redraw. */
    fun requestDraw() {
        setNeedsDisplay()
    }

    /** Kotlin: preview.onPause() — drop the async video samplers. */
    fun releaseVideos() {
        samplers.clear()
        SceneRenderer.shared?.releaseVideos()
    }

    /** Memory warning: also drop the cached image-layer textures (they reload on demand). */
    fun trimMemory() {
        samplers.clear()
        SceneRenderer.shared?.trimMemory()
        renderer?.trimMemory()
    }

    /** Identity of a cached frame: view size + quality. */
    val cacheKey: Triple<Int, Int, Int> get() = Triple(rectWidth().toInt(), rectHeight().toInt(), quality)

    /** Renders one frame at `t` straight into the frame cache, off screen: the on-screen picture,
     *  Editor.time and the playhead are not touched. Used by the idle live cache. */
    fun cacheFrame(t: Float): Boolean {
        if (rectWidth() <= 1f || rectHeight() <= 1f) return false
        val r = ensureRenderer() ?: return false
        r.quality = quality
        r.isExport = false
        val img = r.thumbnail(Editor.project, Editor.scene, t, quality) ?: return false
        val k = cacheKey
        FrameCache.store(Editor.project.id, k.first, k.second, k.third, t, img)
        return true
    }

    /** Bakes frame `idx` of a pre-rendered group into the pre-render cache (off screen). */
    fun warm(path: String) {
        // SceneRenderer.swift:1208: parse the freshly imported model / volume now (import toast),
        // not on the first frame.
        ensureRenderer()?.warm(path)
    }

    fun preRenderFrame(g: Layer, idx: Int): Boolean {
        if (rectWidth() <= 1f || rectHeight() <= 1f) return false
        val r = ensureRenderer() ?: return false
        r.quality = quality
        r.isExport = true
        if (!r.renderFrame(Editor.project, Editor.scene, idx / max(1, Editor.project.fps).toFloat())) return false
        val bmp = r.snapshotFrame() ?: return false
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val rgba = ByteArray(px.size * 4)
        for (i in px.indices) {
            val c = px[i]
            rgba[i * 4] = ((c shr 16) and 0xFF).toByte(); rgba[i * 4 + 1] = ((c shr 8) and 0xFF).toByte()
            rgba[i * 4 + 2] = (c and 0xFF).toByte(); rgba[i * 4 + 3] = ((c ushr 24) and 0xFF).toByte()
        }
        com.saiki.motion.core.PreRender.store(Editor.project.id.toString(), g.id,
            com.saiki.motion.core.PreRender.signature(g, Editor.project, Editor.scene),
            bmp.width, bmp.height, idx, rgba)
        return true
    }

    private fun ensureRenderer(): com.saiki.motion.core.SceneRendererInstance? {
        if (renderer == null) {
            renderer = SceneRenderer.shared
            SceneRenderer.gizmoSource = renderer
        }
        return renderer
    }

    // Adaptive preview quality: while playing, if frames take too long (many effects, 4K video) the
    // preview renders at lower resolution; it goes back up when playback stops or the load drops.
    private var govLevel = 0
    private var govLast = 0.0
    private var govSlow = 0
    private var govFast = 0
    private val govQuality: Int get() = quality + govLevel

    private fun govern() {
        if (!FrameCache.playing && !FrameCache.scrubbing) {
            if (govLevel != 0) { govLevel = 0; govSlow = 0; govFast = 0; postInvalidateCompat() }
            govLast = 0.0
            return
        }
        val now = System.nanoTime() / 1e9
        val dt = now - govLast
        govLast = now
        if (dt <= 0.0 || dt >= 0.5) return
        val target = 1.0 / max(1, min(Editor.project.fps, 30))
        if (dt > target * 1.3) { govSlow++; govFast = 0 } else if (dt < target * 1.15) { govFast++; govSlow = 0 }
        if (govSlow >= 2 && govLevel < 3) { govLevel++; govSlow = 0 }
        if (govFast >= 120 && govLevel > 0) { govLevel--; govFast = 0 }
    }

    private fun postInvalidateCompat() { post { setNeedsDisplay() } }

    public override fun draw(rect: CGRect) {
        lastDrawTs = android.os.SystemClock.uptimeMillis().toDouble()
        val c = UIGraphics.getCurrentContext() ?: return
        govern()
        // Not laid out yet — drawing now would just fail.
        if (rectWidth() <= 1f || rectHeight() <= 1f) return
        val r = ensureRenderer() ?: return
        SceneRenderer.gizmoSource = r      // 3D gizmo projects through this exact renderer
        r.quality = govQuality
        r.isExport = false
        // Frames with real-time physics must never come from the cache: a cached frame skips Rig.apply, so nothing sways.
        val useCache = FrameCache.enabled && (FrameCache.playing || FrameCache.scrubbing) && !Rig.hasLivePhysics(Editor.scene.layers)
        val pid = Editor.project.id
        if (useCache) {
            val sw = rectWidth().toInt(); val sh = rectHeight().toInt()
            val img = FrameCache.lookup(pid.toString(), sw, sh, quality, Editor.time)
            if (img != null) {
                blit(c, img, flipY = false)
                return
            }
        }
        val t0 = System.nanoTime() / 1e9
        if (!r.renderFrame(Editor.project, Editor.scene, Editor.time)) return
        val bmp = r.snapshotFrame() ?: return
        // Only frames that were slow to build are worth caching; reading back cheap frames costs
        // more than re-rendering them (this was causing playback lag).
        if (useCache && govLevel == 0 && System.nanoTime() / 1e9 - t0 > 0.012) {
            val sw = rectWidth().toInt(); val sh = rectHeight().toInt()
            if (!FrameCache.has(pid.toString(), sw, sh, quality, Editor.time)) {
                FrameCache.store(pid.toString(), sw, sh, quality, Editor.time, bmp)
            }
        }
        blit(c, bmp, flipY = false)
    }

    private fun blit(c: com.saiki.motion.uikit.CGContext, img: android.graphics.Bitmap, flipY: Boolean) {
        val p = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
        if (flipY) {
            c.saveGState()
            c.translateBy(0f, rectHeight())
            c.scaleBy(1f, -1f)
            c.canvas.drawBitmap(img, null, android.graphics.RectF(0f, 0f, rectWidth(), rectHeight()), p)
            c.restoreGState()
        } else {
            c.canvas.drawBitmap(img, null, android.graphics.RectF(0f, 0f, rectWidth(), rectHeight()), p)
        }
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        setNeedsDisplay()
    }

    // MARK: - VideoSource

    fun videoTexture(layerId: Int, path: String, srcTime: Float): Long {
        val s = samplers[layerId]
        if (s != null) return s.texture(srcTime)
        val ns = VideoFrames.Sampler(path)
        ns.onUploaded = { setNeedsDisplay() }
        samplers[layerId] = ns
        return ns.texture(srcTime)
    }

    fun videoFrameArrived(): Boolean = false
}
