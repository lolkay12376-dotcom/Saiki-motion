@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/RenderOverlay.swift — the render flow UI: the settings dialog (RenderUi) and
// the full-screen animated progress screen (RenderProgressViewController with RenderRingView /
// RenderBarView). CADisplayLink -> the uikit CADisplayLink twin (tick by reflection-free lambda).

package com.saiki.motion.ui

import android.graphics.BitmapFactory
import com.saiki.motion.app.Dlg
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Exporter
import com.saiki.motion.core.ExporterProgress
import com.saiki.motion.core.Project
import com.saiki.motion.core.ProjectArchive
import com.saiki.motion.core.RenderSettings
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.uikit.fillRoundRect
import java.io.File
import kotlin.math.max
import kotlin.math.min

// MARK: - RenderUi

/** The render flow the editor launches: a settings dialog, then a full-screen progress controller with cancel. */
object RenderUi {

    fun settings(vc: UIViewController, project: Project, done: (RenderSettings) -> Unit) {
        val st = RenderSettings()
        val box = UiView(appContext!!)
        st.fps = max(1, min(project.fps, 120))
        val title = UILabel(appContext!!)
        title.text = "Resolution  ${project.w} x ${project.h}"
        title.textColor = argbToUIColor(C.TEXT)
        title.font = boldFont(15f)
        box.addSubview(title)
        box.addSubview(chipRow(listOf("Half", "Full", "1.5x"), 1) { i ->
            st.scale = if (i == 0) 0.5f else (if (i == 1) 1f else 1.5f)
        })
        fun label(t: String) {
            val l = UILabel(appContext!!)
            l.text = t
            l.textColor = argbToUIColor(C.DIM); l.font = sysFont(13f)
            box.addSubview(l)
        }
        label("Quality")
        box.addSubview(chipRow(listOf("Draft (fast)", "Final"), 1) { i -> st.draft = i == 0 })
        label("Frames per second")
        val fpsSlider = RulerSlider()
        fpsSlider.label = "FPS"; fpsSlider.lo = 1f; fpsSlider.hi = 120f; fpsSlider.dec = 0; fpsSlider.canKey = false
        fpsSlider.value = st.fps.toFloat()
        fpsSlider.onChange = { v -> st.fps = max(1, Math.round(v).toInt()) }
        box.addSubview(fpsSlider)
        label("FPS preset")
        box.addSubview(chipRow(listOf("24", "30", "60"), -1) { i ->
            st.fps = listOf(24, 30, 60)[i]
            fpsSlider.value = st.fps.toFloat()
            fpsSlider.setNeedsDisplay()
        })
        label("Bitrate (Mbps, 0 = auto)")
        val br = RulerSlider()
        br.label = "Bitrate"; br.lo = 0f; br.hi = 100f; br.dec = 0; br.canKey = false; br.value = 0f
        br.onChange = { v -> st.bitrateMbps = max(0f, Math.round(v).toFloat()) }
        box.addSubview(br)
        val audio = SwitchRow()
        audio.label = "Include audio"
        audio.on = true
        audio.onToggle = { v -> st.withAudio = v }
        box.addSubview(audio)
        val pf = SwitchRow()
        pf.label = "Export project file"
        pf.on = false
        pf.onToggle = { v -> st.exportProjectFile = v }
        box.addSubview(pf)
        val scroll = UIScrollView(appContext!!)
        scroll.addSubview(box)
        Dlg(vc).setTitle("Export").setView(scroll)
            .setPositiveButton("Export") { _, _ ->
                if (st.exportProjectFile) {
                    val url = ProjectArchive.export(project.id)
                    if (url != null) {
                        // share sheet twin: hand the file to the system share via the current activity
                        val act = com.saiki.motion.uikit.currentActivity?.get()
                        if (act != null) {
                            val i = android.content.Intent(android.content.Intent.ACTION_SEND)
                            i.type = "application/zip"
                            i.putExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri.fromFile(url))
                            act.startActivity(android.content.Intent.createChooser(i, url.name))
                        }
                        done(st)
                    } else done(st)
                } else done(st)
            }
            .setNegativeButton("Cancel", null).show()
    }

    fun show(vc: UIViewController, project: Project, st: RenderSettings) {
        val progress = RenderProgressViewController(project, st)
        vc.present(progress, animated = true)
    }
}

// MARK: - the animated ring

/** The spinning progress ring: a dashed circle that rotates continuously and fills with a green arc as the render advances. */
class RenderRingView(context: android.content.Context) : UiView(context) {

    var progress: Float = 0f
        set(v) { field = v; setNeedsDisplay() }

    private var spin = 0f
    private var link: com.saiki.motion.uikit.CADisplayLink? = null

    fun startAnimating() {
        if (link != null) return
        val l = com.saiki.motion.uikit.CADisplayLink(this, "tick")
        l.add(Any(), Any())
        link = l
    }

    fun stopAnimating() {
        link?.invalidate(); link = null
    }

    @Suppress("unused") fun tick() {
        spin += 0.023f * 1.4f   // ~1/60 s * 1.4 rad/s
        setNeedsDisplay()
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val side = min(rectWidth(), rectHeight())
        val r = side / 2 - 10
        val cx = rectWidth() / 2
        val cy = rectHeight() / 2
        // pulsing glow behind the ring (radial gradient)
        val pulse = 0.5f + 0.5f * kotlin.math.sin(System.nanoTime() / 1e9.toFloat() * 2.2f)
        val glowR = r * (0.72f + 0.08f * pulse)
        c.saveGState()
        c.paint.shader = android.graphics.RadialGradient(cx, cy, glowR, 0x26FF8A1F.toInt(), 0x00000000, android.graphics.Shader.TileMode.CLAMP)
        c.fill(CGRect(cx - glowR, cy - glowR, glowR * 2, glowR * 2))
        c.restoreGState()
        // track
        c.setStrokeColor(0xFF2A2A30.toInt()); c.setLineWidth(7f)
        c.strokeEllipse(CGRect(cx - r, cy - r, 2 * r, 2 * r))
        // spinning dashed ring
        c.saveGState()
        c.translateBy(cx, cy)
        c.rotate(spin)
        c.setStrokeColor(0xFFD96A00.toInt()); c.setLineWidth(3f)
        c.setLineCap(com.saiki.motion.uikit.CGLineCap.round)
        c.setLineDash(0f, floatArrayOf(2f, 10f))
        c.strokeEllipse(CGRect(-r + 7, -r + 7, 2 * (r - 7), 2 * (r - 7)))
        c.setLineDash(0f, FloatArray(0))
        c.restoreGState()
        // progress arc
        val p = min(max(progress, 0f), 1f)
        if (p > 0.001f) {
            c.setStrokeColor(C.GREEN); c.setLineWidth(7f)
            c.setLineCap(com.saiki.motion.uikit.CGLineCap.round)
            c.saveGState()
            c.translateBy(cx, cy)
            c.rotate(-(Math.PI / 2).toFloat())
            val path = com.saiki.motion.uikit.CGPath()
            path.addArc(CGPoint(0f, 0f), r, 0f, (Math.PI * 2).toFloat() * p, true)
            c.addPath(path.path)
            c.strokePath()
            c.restoreGState()
        }
        // percentage in the middle
        val s = String.format(java.util.Locale.US, "%.0f%%", p * 100f)
        drawText(s, cx, cy + 12f, color = C.TEXT, size = side * 0.22f, bold = true, align = NSTextAlignment.center)
    }
}

// MARK: - the shimmering bar

/** Slim progress bar with a moving light band (the classic "encoding" shimmer). */
class RenderBarView(context: android.content.Context) : UiView(context) {

    var progress: Float = 0f
        set(v) { field = v; setNeedsDisplay() }
    private var phase = 0f
    private var link: com.saiki.motion.uikit.CADisplayLink? = null

    fun startAnimating() {
        if (link != null) return
        val l = com.saiki.motion.uikit.CADisplayLink(this, "tick")
        l.add(Any(), Any())
        link = l
    }

    fun stopAnimating() {
        link?.invalidate(); link = null
    }

    @Suppress("unused") fun tick() {
        phase += 0.015f
        setNeedsDisplay()
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val h = rectHeight()
        fillRoundRect(c, boundsRect, h / 2, C.CARD2)
        val p = min(max(progress, 0f), 1f)
        if (p > 0.001f) {
            c.saveGState()
            c.clip(to = CGRect(0f, 0f, rectWidth() * p, h))
            fillRoundRect(c, boundsRect, h / 2, C.GREEN)
            // moving highlight band
            val bandW = 42f
            val x = ((phase * 160f) % (rectWidth() + bandW)) - bandW
            val g = android.graphics.LinearGradient(x, 0f, x + bandW, 0f,
                intArrayOf(0x00000000, 0x8CFFFFFF.toInt(), 0x00000000), null, android.graphics.Shader.TileMode.CLAMP)
            c.paint.shader = g
            c.setBlendMode(com.saiki.motion.uikit.CGBlendMode.plusLighter)
            c.fill(CGRect(x, 0f, bandW, h))
            c.setBlendMode(com.saiki.motion.uikit.CGBlendMode.normal)
            c.restoreGState()
        }
    }
}

// MARK: - the progress screen

class RenderProgressViewController(private val project: Project, private val settings: RenderSettings) : UIViewController() {
    private val ring = RenderRingView(appContext!!)
    private val bar = RenderBarView(appContext!!)
    private val titleL = UILabel(appContext!!)
    private val girl = object : UiView(appContext!!) {
        var frames: List<android.graphics.Bitmap> = emptyList()
        var t0 = android.os.SystemClock.uptimeMillis()
        public override fun draw(rect: CGRect) {
            if (frames.isEmpty()) return
            val c = UIGraphics.getCurrentContext() ?: return
            val dur = 1600f
            val i = (((android.os.SystemClock.uptimeMillis() - t0) % dur.toLong()) / dur * frames.size).toInt().coerceIn(0, frames.size - 1)
            c.canvas.drawBitmap(frames[i], null, android.graphics.RectF(0f, 0f, rect.width, rect.height),
                android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
            postInvalidateOnAnimationCompat()
        }
        private fun postInvalidateOnAnimationCompat() { postInvalidateOnAnimation() }
    }
    private val sub = UILabel(appContext!!)
    private val etaL = UILabel(appContext!!)
    private val cancelB = PillButton("Cancel", "close", C.CARD2, C.TEXT)
    private var cancelled = false
    private var startedAt = System.currentTimeMillis()
    private var timer: android.os.Handler? = null
    private var timerRun: Runnable? = null
    private var result: Exporter.Result? = null

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(0xEE0B0B10.toInt())
        // sleeping girl: render_f0...render_f6 looped while the export runs
        val frames = ArrayList<android.graphics.Bitmap>()
        for (i in 0 until 7) {
            val rid = appContext!!.resources.getIdentifier("render_f$i", "drawable", appContext!!.packageName)
            if (rid != 0) frames.add(BitmapFactory.decodeResource(appContext!!.resources, rid))
        }
        girl.frames = frames
        view.addSubview(girl)
        titleL.text = "Rendering"
        titleL.textColor = argbToUIColor(C.TEXT); titleL.font = boldFont(20f); titleL.textAlignment = NSTextAlignment.center
        view.addSubview(titleL)
        view.addSubview(ring)
        sub.text = project.name
        sub.textColor = argbToUIColor(C.DIM); sub.font = sysFont(13f); sub.textAlignment = NSTextAlignment.center
        view.addSubview(sub)
        view.addSubview(bar)
        etaL.text = " "
        etaL.textColor = argbToUIColor(C.DIM); etaL.font = sysFont(12f); etaL.textAlignment = NSTextAlignment.center
        view.addSubview(etaL)
        cancelB.onClick = {
            cancelled = true
            etaL.text = "Cancelling…"
            cancelB.isUserInteractionEnabled = false
        }
        view.addSubview(cancelB)
        relayout()
        view.onLayout = { _ -> relayout() }
        ring.startAnimating(); bar.startAnimating()
        start()
    }

    private fun relayout() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w < 10 || h < 10) return
        titleL.frame = CGRect(0f, h / 2 - 172f, w, 24f)
        girl.frame = CGRect(w / 2 - 60f, titleL.frame.minY - 128f, 120f, 120f)
        ring.frame = CGRect(w / 2 - 84f, h / 2 - 84f, 168f, 168f)
        sub.frame = CGRect(0f, ring.frame.maxY + 22f, w, 18f)
        bar.frame = CGRect(w / 2 - 130f, sub.frame.maxY + 18f, 260f, 8f)
        etaL.frame = CGRect(0f, bar.frame.maxY + 10f, w, 18f)
        cancelB.frame = CGRect(w / 2 - 66f, etaL.frame.maxY + 22f, 132f, 42f)
    }

    private fun start() {
        val st = settings
        val scene = Editor.scene
        val total = max(1, (scene.duration * st.fps.toFloat()).toInt())
        startedAt = System.currentTimeMillis()
        Thread {
            val res = Exporter.export(project, scene, st)
            android.os.Handler(android.os.Looper.getMainLooper()).post { finished(res) }
        }.start()
        val h = android.os.Handler(android.os.Looper.getMainLooper())
        val run = object : Runnable {
            override fun run() {
                if (cancelled) return
                val done = ExporterProgress.done
                val p = done.toFloat() / total.toFloat()
                ring.progress = p
                bar.progress = p
                val elapsed = (System.currentTimeMillis() - startedAt) / 1000.0
                if (done > 6 && p > 0.01f) {
                    val eta = elapsed / done * max(0, total - done)
                    etaL.text = "$done / $total frames  ·  ~${eta.toInt()} s left"
                } else {
                    etaL.text = "$done / $total frames"
                }
                h.postDelayed(this, 200)
            }
        }
        timerRun = run
        h.post(run)
        timer = h
    }

    private fun finished(res: Exporter.Result) {
        ring.stopAnimating(); bar.stopAnimating()
        timer?.removeCallbacks(timerRun!!)
        if (cancelled) {
            res.url?.let { u -> try { u.delete() } catch (_: Exception) {} }
            dismiss(animated = true)
            return
        }
        val err = res.error
        if (err != null) {
            Dlg(this).setTitle("Render failed").setMessage(err).setPositiveButton("OK") { _, _ -> dismiss(animated = true) }.show()
            return
        }
        val url = res.url ?: run { dismiss(animated = true); return }
        Dlg(this).setTitle("Render complete").setMessage(url.name)
            .setItems(listOf("Save to Photos", "Share", "Close")) { _, i ->
                when (i) {
                    0 -> {
                        saveToGallery(url)
                        com.saiki.motion.app.Snack.show("Saved to Photos")
                        dismiss(animated = true)
                    }
                    1 -> {
                        val act = com.saiki.motion.uikit.currentActivity?.get()
                        if (act != null) {
                            val sh = android.content.Intent(android.content.Intent.ACTION_SEND)
                            sh.type = "video/mp4"
                            sh.putExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri.fromFile(url))
                            act.startActivity(android.content.Intent.createChooser(sh, url.name))
                        }
                    }
                    else -> dismiss(animated = true)
                }
            }.show()
    }

    private fun saveToGallery(url: File) {
        try {
            val act = com.saiki.motion.uikit.currentActivity?.get() ?: return
            val values = android.content.ContentValues()
            values.put(android.provider.MediaStore.Video.Media.DISPLAY_NAME, url.name)
            values.put(android.provider.MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            val uri = act.contentResolver.insert(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return
            act.contentResolver.openOutputStream(uri)?.use { o -> url.inputStream().use { it.copyTo(o) } }
        } catch (_: Exception) { }
    }
}
