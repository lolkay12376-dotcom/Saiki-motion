@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName", "PropertyName")

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.app.PLabel
import com.saiki.motion.app.setAnchorKeepVisual
import com.saiki.motion.app.refreshPanel
import com.saiki.motion.core.PhysGroup
import com.saiki.motion.core.PhysIn
import com.saiki.motion.core.PhysOut
import com.saiki.motion.core.PhysPend
import com.saiki.motion.core.Puppet
import com.saiki.motion.core.PuppetMath
import com.saiki.motion.core.PuppetPin
import com.saiki.motion.core.Rig
import com.saiki.motion.core.RigFolder
import com.saiki.motion.core.RigLink
import com.saiki.motion.core.RigParam
import com.saiki.motion.core.Warp
import com.saiki.motion.core.Xf
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UITouchPhase
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.argbToUIColor
import com.saiki.motion.uikit.UITapGestureRecognizer
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.cos

// Port of Sources/UI/RigEditor.swift — "Cubism Editor": live 2D rig editor for a rig group.
//
// Tabs: Params · Layers (folders + parenting) · Folder (mesh deformer + paint brush
// for every layer in a folder) · Mesh (per-layer points, brush, add/delete) · Rotate.
// Keying: pick a parameter value (slider / key bar), then drag or paint — the result is
// stored as a keyform at that value. Drags are previewed live (RigCanvas.live) and committed
// on finger-up, so the preview is never wiped by a redraw.
//
// iOS uses Auto Layout; the port follows the project convention: manual frames laid out by
// the editor's own layoutSubviews-driven RigEditorRoot, and the UIKit twin of the layer tree
// table is the UITableView shim (RigRowCell). Layout glue lives in the app package
// (RigEditorViewController) — this file carries the views (KeyBar, RigCanvas, RigRowCell,
// PendulumView, LinkPad) as the iOS file does, plus the VC (same class name) since the
// file must stand alone.

private fun UiView.add(v: UiView) { addSubview(v) }

// MARK: - key bar (shows keyforms of the active parameter, tap/scrub to jump)

class KeyBar : UiView(com.saiki.motion.uikit.appContext!!) {
    var lo: Float = 0f
    var hi: Float = 1f
    var value: Float = 0f
    var keys: List<Float> = emptyList()
    var onPick: ((Float) -> Unit)? = null

    init { setBackgroundColor(android.graphics.Color.TRANSPARENT) }

    private fun x(v: Float): CGFloat {
        val w = rectWidth() - 24f
        return 12f + w * ((v - lo) / max(hi - lo, 0.0001f))
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val y = rect.midY - 4f
        c.setStrokeColor(C.CARD2); c.setLineWidth(4f); c.setLineCap(com.saiki.motion.uikit.CGLineCap.round)
        c.move(CGPoint(12f, y)); c.addLine(CGPoint(rectWidth() - 12f, y)); c.strokePath()
        for (k in keys) {
            val cx = x(k); val on = abs(k - value) < 0.002f
            c.setFillColor(if (on) C.TEXT else C.GREEN)
            c.move(CGPoint(cx, y - 9f)); c.addLine(CGPoint(cx + 8f, y))
            c.addLine(CGPoint(cx, y + 9f)); c.addLine(CGPoint(cx - 8f, y)); c.fillPath()
        }
        val vx = x(min(hi, max(lo, value)))
        c.setStrokeColor(0xFFFFFFFF.toInt()); c.setLineWidth(2f)
        c.move(CGPoint(vx, y - 13f)); c.addLine(CGPoint(vx, y + 13f)); c.strokePath()
        drawText(String.format(Locale.US, "%g", lo), 8f, rect.height - 16f + 11f, color = C.DIM, size = 11f)
        val h = String.format(Locale.US, "%g", hi)
        val hw = measureText(h, 11f)
        drawText(h, rectWidth() - 8f - hw, rect.height - 16f + 11f, color = C.DIM, size = 11f)
    }

    private fun pick(t: UITouch) {
        val px = t.location(this).x
        var v = lo + (px - 12f) / max(rectWidth() - 24f, 1f) * (hi - lo)
        v = min(hi, max(lo, v))
        val near = keys.minByOrNull { abs(x(it) - px) }
        if (near != null && abs(x(near) - px) < 18f) v = near
        value = v; setNeedsDisplay(); onPick?.invoke(v)
    }

    override fun touchesBegan(t: Set<UITouch>, e: com.saiki.motion.uikit.UIEvent?) { t.firstOrNull()?.let { pick(it) } }
    override fun touchesMoved(t: Set<UITouch>, e: com.saiki.motion.uikit.UIEvent?) { t.firstOrNull()?.let { pick(it) } }
}

// MARK: - canvas

class RigCanvas : UiView(com.saiki.motion.uikit.appContext!!) {
    var group: Layer? = null
    var selId = -1
    var mode = 0                                  // 0 params, 1 layers, 2 folder, 3 mesh, 4 rotate
    var tool = 0                                  // mesh tab: 0 move, 1 paint, 2 add, 3 delete
    var targets: List<Int> = emptyList()          // layers the pins / brush act on
    var brushR: Float = 0.25f                     // world units
    var brushK: Float = 1f
    var onSelect: ((Int) -> Unit)? = null
    var onBeginEdit: (() -> Unit)? = null
    var onCommit: ((Map<Int, Map<String, Float>>, Map<Int, Map<String, Float>>) -> Unit)? = null   // live, start
    var onAdd: ((Layer, Float, Float) -> Unit)? = null
    var onDel: ((Layer, PuppetPin) -> Unit)? = null
    var pen = 0                                   // warp tab pen: 1 add a lattice point, 2 remove one
    var onPenAdd: ((Layer, Float, Float) -> Unit)? = null
    var onPenDel: ((Layer, Int) -> Unit)? = null
    var onPivot: ((Layer, Float, Float) -> Unit)? = null
    var warpId = -1                               // warp deformer shown in mode 2
    var softR: Float = 1.5f                       // warp drag falloff, in grid cells
    private var dragWarp = -1
    private var warpStartQ = Pair(0f, 0f)
    private var warpStartOff = FloatArray(0)

    private var zoom: CGFloat = 1f
    private var pan = CGPoint.zero
    private var dragPin: Pair<Layer, PuppetPin>? = null
    private var dragPivot = false
    private var brushing = false
    private var brushPt: CGPoint? = null
    private var lastW = Pair(0f, 0f)
    private var live = HashMap<Int, HashMap<String, Float>>()
    private var start = HashMap<Int, HashMap<String, Float>>()

    init {
        setBackgroundColor(C.BG)
        clipsToBounds = true
        isMultipleTouchEnabled = true
    }

    // two fingers: pan and pinch-zoom together, around the fingers (works in full screen too)
    private var multi = false
    // raw pointer tracking for the two-finger navigation (pinch zoom + pan)
    private val ptrs = HashMap<Int, Pair<Float, Float>>()
    private var navBaseDist = 0f
    private var navBaseMid = Pair(0f, 0f)

    private fun pinch(scale: Float, fx: Float, fy: Float) {
        val old = zoom
        val nz = min(8f, max(0.3f, zoom * scale))
        val k = nz / old
        pan = CGPoint(pan.x + (fx - cx) * (1 - k), pan.y + (fy - cy) * (1 - k))
        zoom = nz; setNeedsDisplay()
    }
    private fun panned(tx: Float, ty: Float) {
        pan = CGPoint(pan.x + tx, pan.y + ty)
        setNeedsDisplay()
    }

    // MARK: geometry
    private val members: List<Layer>
        get() {
            val r = group?.rig ?: return emptyList()
            return Editor.scene.layers.filter { r.members.contains(it.id) }
        }
    private fun lay(id: Int): Layer? = Editor.scene.layers.firstOrNull { it.id == id }
    private val pinLayers: List<Layer>
        get() {
            if (mode != 3) return emptyList()
            return targets.mapNotNull { lay(it) }.filter { !(it.puppet?.pins.isNullOrEmpty()) }
        }
    private val ar: Float get() = Editor.project.w.toFloat() / max(Editor.project.h, 1).toFloat()
    private val sc: Float get() = min(rectHeight() / 2f, rectWidth() / (2f * ar)) * 0.92f * zoom
    private val cx: Float get() = rectWidth() / 2f + pan.x
    private val cy: Float get() = rectHeight() / 2f + pan.y
    private fun scr(x: Float, y: Float): CGPoint = CGPoint(cx + x * sc, cy - y * sc)
    private fun world(p: CGPoint): Pair<Float, Float> = Pair((p.x - cx) / sc, -(p.y - cy) / sc)
    private fun toScr(m: FloatArray, x: Float, y: Float): CGPoint { val w = Xf.apply(m, x, y); return scr(w.first, w.second) }
    private fun local(l: Layer, p: CGPoint): Pair<Float, Float>? {
        val inv = Xf.invert(Xf.matrix(l, Editor.time)) ?: return null
        val w = world(p); return Xf.apply(inv, w.first, w.second)
    }

    private fun cg(l: Layer): Bitmap? {
        if (l.type != LayerType.IMAGE) return null
        val path = l.imagePath ?: return null
        imgCache[path]?.let { return it }
        val ui = try {
            BitmapFactory.decodeFile(path) ?: return null
        } catch (_: Exception) { return null }
        val mx = 256f
        val k = min(1f, mx / max(ui.width, ui.height).toFloat())
        val w = max(1f, ui.width * k).toInt(); val h = max(1f, ui.height * k).toInt()
        val out = Bitmap.createScaledBitmap(ui, w, h, true)
        imgCache[path] = out
        return out
    }
    private fun setLive(l: Layer, key: String, v: Float) {
        val st = start.get(l.id)
        if (st == null || st.get(key) == null) {
            val m = st ?: HashMap<String, Float>().also { start.put(l.id, it) }
            m.put(key, (l.rigOff.get(key) ?: 0f) - (l.warpOff.get(key) ?: 0f))
        }
        val lv = live.get(l.id) ?: HashMap<String, Float>().also { live.put(l.id, it) }
        lv.put(key, v)
    }
    private fun curOff(l: Layer, key: String): Float = live.get(l.id)?.get(key) ?: ((l.rigOff.get(key) ?: 0f) - (l.warpOff.get(key) ?: 0f))

    // MARK: draw
    public override fun draw(rect: CGRect) {
        val ctx = UIGraphics.getCurrentContext() ?: return
        if (group?.rig == null) return
        val liveMap = live.mapValues { it.value as Map<String, Float> }
        Rig.apply(Editor.scene.layers, Editor.time, liveMap)      // live drag preview included
        val t = Editor.time
        val a = ar
        val tl = scr(-a, 1f); val br = scr(a, -1f)
        // same frame as the main viewport: project background colour, every visible layer, clipped to the frame
        val frame = CGRect(tl.x, tl.y, br.x - tl.x, br.y - tl.y)
        ctx.setFillColor(Editor.scene.bg)
        ctx.fill(frame)
        ctx.saveGState(); ctx.clip(to = frame)
        // the canvas is small: draw meshes at reduced density (lowest while interacting) so dragging stays smooth
        val busy = live.isNotEmpty() || dragWarp >= 0 || dragPin != null || brushing
        val savedDens = ArrayList<Pair<Puppet, Int>>()
        val all = Editor.scene.layers
        for (l in all) { l.puppet?.let { pp -> savedDens.add(Pair(pp, pp.density)); pp.density = min(pp.density, if (busy) 0 else 1) } }
        for (l in all) if (l.type == LayerType.IMAGE && shown(l)) drawLayer(ctx, l, t)
        for ((pp, d) in savedDens) pp.density = d
        ctx.restoreGState()
        ctx.setStrokeColor(0x40FFFFFF.toInt()); ctx.setLineWidth(1f); ctx.stroke(frame)

        // selection outline(s)
        ctx.setStrokeColor(C.GREEN); ctx.setLineWidth(1.5f)
        val outlined = members.filter { it.id == selId && it.type != LayerType.GROUP }
        for (s in outlined) {
            val m = Xf.matrix(s, t); val (qw, qh) = Xf.quadSize(s)
            val q = listOf(Pair(-qw / 2f, -qh / 2f), Pair(qw / 2f, -qh / 2f), Pair(qw / 2f, qh / 2f), Pair(-qw / 2f, qh / 2f)).map { toScr(m, it.first, it.second) }
            ctx.move(q[0]); for (i in 1 until q.size) ctx.addLine(q[i]); ctx.addLine(q[0]); ctx.strokePath()
        }
        // mesh overlay + points
        for (s in pinLayers) {
            val pp = s.puppet ?: continue
            val m = Xf.matrix(s, t); val (qw, qh) = Xf.quadSize(s)
            if (pp.showMesh && pp.on) {
                val n = PuppetMath.segs[min(pp.density, PuppetMath.segs.size - 1)]
                val g = PuppetMath.gridPositions(s, pp, t)
                val step = max(1, n / 14)
                fun pt(i: Int, j: Int): CGPoint {
                    val k = (j * (n + 1) + i) * 2
                    return toScr(m, g[k] * qw / 2f, g[k + 1] * qh / 2f)
                }
                ctx.setStrokeColor(0x8C00FFFF.toInt()); ctx.setLineWidth(0.8f)
                var j = 0
                while (j <= n) { ctx.move(pt(0, j)); for (i in 1..n) ctx.addLine(pt(i, j)); j += step }
                var i = 0
                while (i <= n) { ctx.move(pt(i, 0)); for (j2 in 1..n) ctx.addLine(pt(i, j2)); i += step }
                ctx.strokePath()
            }
            val r: CGFloat = if (mode == 3 && tool == 1) 4f else 7f
            for (pin in pp.pins) {
                val o = pinOffset(s, pin, t)
                val c = toScr(m, (pin.rx + o.first) * qw / 2f, (pin.ry + o.second) * qh / 2f)
                ctx.setFillColor(if (pin === dragPin?.second) C.TEXT else C.GREEN)
                ctx.fillEllipse(CGRect(c.x - r, c.y - r, r * 2f, r * 2f))
            }
        }
        if (mode == 2) { val w = lay(warpId); val wp = w?.warp; if (w != null && wp != null) drawWarp(ctx, w, wp, t) }
        if (mode == 4) {
            val s = members.firstOrNull { it.id == selId }
            if (s != null) {
                val c = pivotScreen(s)
                ctx.setStrokeColor(0xFF00FFFF.toInt()); ctx.setLineWidth(2f)
                ctx.strokeEllipse(CGRect(c.x - 11f, c.y - 11f, 22f, 22f))
                ctx.move(CGPoint(c.x - 16f, c.y)); ctx.addLine(CGPoint(c.x + 16f, c.y))
                ctx.move(CGPoint(c.x, c.y - 16f)); ctx.addLine(CGPoint(c.x, c.y + 16f))
                ctx.strokePath()
            }
        }
        if (brushing) {
            val b = brushPt
            if (b != null) {
                val r = brushR * sc
                ctx.setStrokeColor(0xD9FFFFFF.toInt()); ctx.setLineWidth(1.5f)
                ctx.strokeEllipse(CGRect(b.x - r, b.y - r, r * 2f, r * 2f))
            }
        }
    }

    private fun shown(l: Layer): Boolean {
        var cur: Layer? = l; var n = 0
        while (cur != null && n < 32) {
            // same rules as the main viewport: hidden layers and layers outside their time range are not drawn
            if (!cur.visible || Editor.time < cur.start - 0.001f || Editor.time > cur.end + 0.001f) return false
            if (cur.id == group!!.id) break
            cur = lay(cur.parentId); n += 1
        }
        return true
    }
    private fun warpPoint(w: Layer, wp: Warp, k: Int, t: Float): CGPoint {
        val r = wp.rest(k)
        return toScr(Xf.matrix(w, t), r.first + w.p("wx$k", t), r.second + w.p("wy$k", t))
    }
    private fun drawWarp(ctx: com.saiki.motion.uikit.CGContext, w: Layer, wp: Warp, t: Float) {
        val n = wp.n
        ctx.setStrokeColor(0xB3FF8A1F.toInt()); ctx.setLineWidth(1f)
        for (j in 0 until n) for (i in 0 until n) {
            val p = warpPoint(w, wp, j * n + i, t)
            if (i + 1 < n) { ctx.move(p); ctx.addLine(warpPoint(w, wp, j * n + i + 1, t)) }
            if (j + 1 < n) { ctx.move(p); ctx.addLine(warpPoint(w, wp, (j + 1) * n + i, t)) }
        }
        ctx.strokePath()
        for (k in 0 until (n * n)) {
            val p = warpPoint(w, wp, k, t)
            ctx.setFillColor(if (k == dragWarp) C.TEXT else C.GREEN)
            ctx.fillEllipse(CGRect(p.x - 6f, p.y - 6f, 12f, 12f))
        }
    }
    private fun nearestWarp(p: CGPoint): Int? {
        val w = lay(warpId) ?: return null
        val wp = w.warp ?: return null
        var best: Pair<Int, Float>? = null
        for (k in 0 until (wp.n * wp.n)) {
            val c = warpPoint(w, wp, k, Editor.time); val d = hypot((c.x - p.x).toDouble(), (c.y - p.y).toDouble()).toFloat()
            if (d < 36f && d < (best?.second ?: Float.MAX_VALUE)) best = Pair(k, d)
        }
        return best?.first
    }

    private fun pinOffset(l: Layer, pin: PuppetPin, t: Float): Pair<Float, Float> =
        Pair((l.props["pp${pin.id}x"]?.eval(t) ?: 0f) + (l.rigOff["pp${pin.id}x"] ?: 0f),
             (l.props["pp${pin.id}y"]?.eval(t) ?: 0f) + (l.rigOff["pp${pin.id}y"] ?: 0f))
    private fun pivotScreen(l: Layer): CGPoint {
        val (qw, qh) = Xf.quadSize(l)
        val ax = l.p("anchorX", Editor.time); val ay = l.p("anchorY", Editor.time)
        return toScr(Xf.matrix(l, Editor.time), (ax - 50f) / 100f * qw, -(ay - 50f) / 100f * qh)
    }

    private fun drawLayer(ctx: com.saiki.motion.uikit.CGContext, l: Layer, t: Float) {
        val m = Xf.matrix(l, t); val (qw, qh) = Xf.quadSize(l)
        ctx.saveGState()
        ctx.translateBy(cx, cy); ctx.scaleBy(sc, -sc)
        // CGAffineTransform(a,b,c,d,tx,ty) → Android row-major (a c e / b d f)
        ctx.canvas.concat(android.graphics.Matrix().apply { setValues(floatArrayOf(m[0], m[2], m[4], m[1], m[3], m[5], 0f, 0f, 1f)) })
        ctx.setAlpha(max(0f, min(1f, l.p("opacity", t))))
        val hw = qw / 2f; val hh = qh / 2f
        val img = cg(l)
        if (img != null) {
            val mesh = PuppetMath.mesh(l, t)
            if (mesh != null) {
                val W = img.width.toFloat(); val H = img.height.toFloat()
                var i = 0
                while (i + 2 < mesh.idx.size) {
                    val ids = listOf(mesh.idx[i].toInt(), mesh.idx[i + 1].toInt(), mesh.idx[i + 2].toInt()); i += 3
                    val d = ids.map { Pair(mesh.pos[2 * it] * hw, mesh.pos[2 * it + 1] * hh) }
                    val s = ids.map { Pair(mesh.uv[2 * it] * W, mesh.uv[2 * it + 1] * H) }
                    val e1x = s[1].first - s[0].first; val e1y = s[1].second - s[0].second
                    val e2x = s[2].first - s[0].first; val e2y = s[2].second - s[0].second
                    val f1x = d[1].first - d[0].first; val f1y = d[1].second - d[0].second
                    val f2x = d[2].first - d[0].first; val f2y = d[2].second - d[0].second
                    val det = e1x * e2y - e1y * e2x
                    if (abs(det) < 1e-6f) continue
                    val ma = (f1x * e2y - f2x * e1y) / det
                    val mc = (f2x * e1x - f1x * e2x) / det
                    val mb = (f1y * e2y - f2y * e1y) / det
                    val md = (f2y * e1x - f1y * e2x) / det
                    val tx = d[0].first - (ma * s[0].first + mc * s[0].second)
                    val ty = d[0].second - (mb * s[0].first + md * s[0].second)
                    ctx.saveGState()
                    ctx.move(CGPoint(d[0].first, d[0].second)); ctx.addLine(CGPoint(d[1].first, d[1].second)); ctx.addLine(CGPoint(d[2].first, d[2].second)); ctx.closeSubpath(); ctx.clipPath()
                    ctx.canvas.concat(android.graphics.Matrix().apply { setValues(floatArrayOf(ma, mc, tx, mb, md, ty, 0f, 0f, 1f)) })
                    ctx.canvas.drawBitmap(img, null, android.graphics.RectF(0f, 0f, W, H), ctx.paint)
                    ctx.restoreGState()
                }
            } else {
                ctx.canvas.drawBitmap(img, null, android.graphics.RectF(-hw, -hh, hw * 2f, hh * 2f), ctx.paint)
            }
        } else {
            ctx.setFillColor(C.CARD2)
            ctx.fill(CGRect(-hw, -hh, hw * 2f, hh * 2f))
        }
        ctx.restoreGState()
    }

    // MARK: touch
    private fun nearestPin(p: CGPoint): Pair<Layer, PuppetPin>? {
        var best: Triple<Layer, PuppetPin, Float>? = null
        for (s in pinLayers) {
            val pp = s.puppet ?: continue
            val m = Xf.matrix(s, Editor.time); val (qw, qh) = Xf.quadSize(s)
            for (pin in pp.pins) {
                val o = pinOffset(s, pin, Editor.time)
                val c = toScr(m, (pin.rx + o.first) * qw / 2f, (pin.ry + o.second) * qh / 2f)
                val d = hypot((c.x - p.x).toDouble(), (c.y - p.y).toDouble()).toFloat()
                if (d < 30f && d < (best?.third ?: Float.MAX_VALUE)) best = Triple(s, pin, d)
            }
        }
        return best?.let { Pair(it.first, it.second) }
    }

    private fun brush(from: Pair<Float, Float>, to: Pair<Float, Float>) {
        val dx = to.first - from.first; val dy = to.second - from.second
        val t = Editor.time
        for (l in pinLayers) {
            val pp = l.puppet ?: continue
            val inv = Xf.invert(Xf.matrix(l, t)) ?: continue
            val m = Xf.matrix(l, t); val (qw, qh) = Xf.quadSize(l)
            val o0 = Xf.apply(inv, 0f, 0f); val o1 = Xf.apply(inv, dx, dy)
            val lx = o1.first - o0.first; val ly = o1.second - o0.second
            for (pin in pp.pins) {
                val kx = "pp${pin.id}x"; val ky = "pp${pin.id}y"
                // use the same live value the brush writes (the last drawn frame can be several touch events behind → in/out flicker)
                val o = Pair((l.props[kx]?.eval(t) ?: 0f) + curOff(l, kx) + (l.warpOff[kx] ?: 0f),
                             (l.props[ky]?.eval(t) ?: 0f) + curOff(l, ky) + (l.warpOff[ky] ?: 0f))
                val w = Xf.apply(m, (pin.rx + o.first) * qw / 2f, (pin.ry + o.second) * qh / 2f)
                val d = hypot((w.first - (from.first + to.first) / 2f).toDouble(), (w.second - (from.second + to.second) / 2f).toDouble()).toFloat()   // falloff around the stroke's midpoint → no jump at the rim
                if (d >= brushR) continue
                val f = (1f - d / brushR); val k = f * f * brushK
                setLive(l, kx, curOff(l, kx) + lx / (qw / 2f) * k)
                setLive(l, ky, curOff(l, ky) + ly / (qh / 2f) * k)
            }
        }
    }

    override fun touchesBegan(touches: Set<UITouch>, event: com.saiki.motion.uikit.UIEvent?) {
        if ((event?.allTouches?.size ?: 1) > 1) { multi = true; finish(commit = false); return }   // 2nd finger: navigate, don't edit
        if (multi || touches.size != 1) return
        val tc = touches.first()
        val p = tc.location(this)
        val sel = members.firstOrNull { it.id == selId }
        if (mode == 2 && pen != 0) {
            val w = lay(warpId)
            val wp = w?.warp
            if (w != null && wp != null) {
                if (pen == 1) {
                    val q = local(w, p)
                    if (q != null) {
                        val ru = (q.first - wp.bx) / max(wp.bw, 1e-4f); val rv = (q.second - wp.by) / max(wp.bh, 1e-4f)
                        if (ru > 0f && ru < 1f && rv > 0f && rv < 1f) onPenAdd?.invoke(w, ru, rv)
                    }
                } else if (pen == 2) {
                    val k = nearestWarp(p)
                    if (k != null) onPenDel?.invoke(w, k)
                }
                return
            }
        }
        if (mode == 2) {
            val w = lay(warpId); val wp = w?.warp
            val k = nearestWarp(p); val q = if (w != null) local(w, p) else null
            if (w != null && wp != null && k != null && q != null) {
                dragWarp = k; warpStartQ = q; onBeginEdit?.invoke()
                val offs = ArrayList<Float>()
                for (i in 0 until (wp.n * wp.n)) { offs.add(w.p("wx$i", Editor.time)); offs.add(w.p("wy$i", Editor.time)) }
                warpStartOff = offs.toFloatArray()
                setNeedsDisplay(); return
            }
        }
        val paint = (mode == 3 && tool == 1)
        if (paint && pinLayers.isNotEmpty()) {
            brushing = true; brushPt = p; lastW = world(p); onBeginEdit?.invoke(); setNeedsDisplay(); return
        }
        if (mode == 3) {
            if (tool == 2 && sel != null) {
                val q = local(sel!!, p)
                if (q != null) {
                    val (qw, qh) = Xf.quadSize(sel!!)
                    val rx = q.first / (qw / 2f); val ry = q.second / (qh / 2f)
                    if (abs(rx) <= 1f && abs(ry) <= 1f) onAdd?.invoke(sel!!, rx, ry)
                }
                return
            }
            if (tool == 3) { nearestPin(p)?.let { onDel?.invoke(it.first, it.second) }; return }
            nearestPin(p)?.let { dragPin = it; onBeginEdit?.invoke(); setNeedsDisplay(); return }
        }
        if (mode == 4 && sel != null && hypot((pivotScreen(sel!!).x - p.x).toDouble(), (pivotScreen(sel!!).y - p.y).toDouble()) < 30.0) {
            dragPivot = true; onBeginEdit?.invoke(); return
        }
        // Keep the layer you picked: a tap inside it must not jump to whatever overlaps it on top (back hair etc.).
        if (sel != null && (sel!!.deformer == 1 || sel!!.type == LayerType.GROUP)) {
            for (l in Rig.descendants(sel!!, members)) if (l.type == LayerType.IMAGE) {
                val (qw, qh) = Xf.quadSize(l)
                val q = local(l, p)
                if (q != null && abs(q.first) <= qw / 2f && abs(q.second) <= qh / 2f) return
            }
        }
        if (sel != null && sel!!.type == LayerType.IMAGE) {
            val (qw, qh) = Xf.quadSize(sel!!)
            val q = local(sel!!, p)
            if (q != null && abs(q.first) <= qw / 2f && abs(q.second) <= qh / 2f) return
        }
        for (l in members.asReversed()) if (l.type == LayerType.IMAGE && shown(l)) {
            val (qw, qh) = Xf.quadSize(l)
            val q = local(l, p)
            if (q != null && abs(q.first) <= qw / 2f && abs(q.second) <= qh / 2f) { onSelect?.invoke(l.id); return }
        }
        if ((mode == 3 || mode == 4) && sel != null) return   // empty tap in mesh/transform must not drop the selection
        onSelect?.invoke(-1)
    }

    override fun touchesMoved(touches: Set<UITouch>, event: com.saiki.motion.uikit.UIEvent?) {
        if ((event?.allTouches?.size ?: 1) > 1) { multi = true; return }
        if (multi || touches.size != 1) return
        val p = touches.first().location(this)
        if (dragWarp >= 0) {
            val w = lay(warpId); val wp = w?.warp; val q = if (w != null) local(w, p) else null
            if (w != null && wp != null && q != null) {
                val n = wp.n; val t = Editor.time
                val dx = q.first - warpStartQ.first; val dy = q.second - warpStartQ.second
                val ki = dragWarp % n; val kj = dragWarp / n
                for (j in 0 until (n * n)) {
                    val dist = hypot(((j % n) - ki).toDouble(), ((j / n) - kj).toDouble()).toFloat()
                    val f: Float = if (j == dragWarp) 1f else (if (softR > 0.01f) max(0f, 1f - dist / softR) else 0f)
                    if (f <= 0f) continue
                    val w2 = f * f
                    setLive(w, "wx$j", warpStartOff[2 * j] + dx * w2 - (w.props["wx$j"]?.eval(t) ?: 0f))
                    setLive(w, "wy$j", warpStartOff[2 * j + 1] + dy * w2 - (w.props["wy$j"]?.eval(t) ?: 0f))
                }
                setNeedsDisplay(); return
            }
        }
        if (brushing) {
            val raw = world(p)
            // smooth the finger path + ignore sub-pixel jitter so the mesh doesn't twitch while painting
            val w = Pair(lastW.first + (raw.first - lastW.first) * 0.55f, lastW.second + (raw.second - lastW.second) * 0.55f)
            if (hypot((w.first - lastW.first).toDouble(), (w.second - lastW.second).toDouble()).toFloat() * sc < 0.6f) { brushPt = p; setNeedsDisplay(); return }
            brush(lastW, w); lastW = w; brushPt = p; setNeedsDisplay(); return
        }
        val dp = dragPin
        if (dp != null) {
            val (s, pin) = dp
            val q = local(s, p)
            if (q != null) {
                val (qw, qh) = Xf.quadSize(s)
                val t = Editor.time
                val bx = s.props["pp${pin.id}x"]?.eval(t) ?: 0f
                val by = s.props["pp${pin.id}y"]?.eval(t) ?: 0f
                setLive(s, "pp${pin.id}x", q.first / (qw / 2f) - pin.rx - bx)
                setLive(s, "pp${pin.id}y", q.second / (qh / 2f) - pin.ry - by)
            }
        } else if (dragPivot) {
            val s = members.firstOrNull { it.id == selId }
            val q = if (s != null) local(s, p) else null
            if (s != null && q != null) {
                val (qw, qh) = Xf.quadSize(s)
                onPivot?.invoke(s, min(100f, max(0f, q.first / qw * 100f + 50f)), min(100f, max(0f, 50f - q.second / qh * 100f)))
            }
        }
        setNeedsDisplay()
    }

    private fun finish(commit: Boolean) {
        val l = live.toMap().mapValues { it.value.toMap() }
        val s = start.toMap().mapValues { it.value.toMap() }
        live.clear(); start.clear(); dragPin = null; dragWarp = -1; dragPivot = false; brushing = false; brushPt = null
        if (commit && l.isNotEmpty()) onCommit?.invoke(l, s)
        setNeedsDisplay()
    }

    override fun touchesEnded(touches: Set<UITouch>, event: com.saiki.motion.uikit.UIEvent?) {
        val left = event?.allTouches?.count { it.phase != UITouchPhase.ended && it.phase != UITouchPhase.cancelled } ?: 0
        if (multi) { finish(commit = false); if (left == 0) multi = false; return }
        finish(commit = true)
    }
    override fun touchesCancelled(touches: Set<UITouch>, event: com.saiki.motion.uikit.UIEvent?) {
        val left = event?.allTouches?.count { it.phase != UITouchPhase.ended && it.phase != UITouchPhase.cancelled } ?: 0
        finish(commit = false); if (left == 0) multi = false
    }

    // MARK: two-finger navigation (pinch zoom + pan) — raw pointer tracking, UIKit twin of
    // the simultaneous UIPinchGestureRecognizer + 2-finger UIPanGestureRecognizer pair
    // (the uikit shim only forwards single-touch sets, so the canvas tracks pointers itself).

    public override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        super.onTouchEvent(e)
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN, android.view.MotionEvent.ACTION_POINTER_DOWN -> {
                ptrs[e.getPointerId(e.actionIndex)] = Pair(e.getX(e.actionIndex), e.getY(e.actionIndex))
                if (ptrs.size >= 2) {
                    multi = true
                    finish(commit = false)
                    val ps = ptrs.values.toList()
                    navBaseDist = max(1f, hypot((ps[0].first - ps[1].first).toDouble(), (ps[0].second - ps[1].second).toDouble()).toFloat())
                    navBaseMid = Pair((ps[0].first + ps[1].first) / 2f, (ps[0].second + ps[1].second) / 2f)
                }
            }
            android.view.MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) ptrs[e.getPointerId(i)] = Pair(e.getX(i), e.getY(i))
                if (ptrs.size >= 2) {
                    val ps = ptrs.values.toList()
                    val d = max(1f, hypot((ps[0].first - ps[1].first).toDouble(), (ps[0].second - ps[1].second).toDouble()).toFloat())
                    val mid = Pair((ps[0].first + ps[1].first) / 2f, (ps[0].second + ps[1].second) / 2f)
                    // pinch around the fingers
                    pinch(d / max(navBaseDist, 0.01f), mid.first, mid.second)
                    // pan by the fingers' travel
                    panned(mid.first - navBaseMid.first, mid.second - navBaseMid.second)
                    navBaseDist = d; navBaseMid = mid
                }
            }
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_POINTER_UP, android.view.MotionEvent.ACTION_CANCEL -> {
                ptrs.remove(e.getPointerId(e.actionIndex))
                if (ptrs.size < 2) { navBaseDist = 0f; if (ptrs.isEmpty()) multi = false }
            }
        }
        return true
    }

    companion object {
        private val imgCache = HashMap<String, Bitmap>()
    }
}

// MARK: - pendulum chain diagram (live, no angle limits; drag = duration of pendulum 1)

class PendulumView : UiView(com.saiki.motion.uikit.appContext!!) {
    var pg: PhysGroup? = null
    var rig: Rig? = null
    var groupId = -1
    var onBegin: (() -> Unit)? = null
    var onEdit: ((Boolean) -> Unit)? = null

    init { setBackgroundColor(C.CARD2) }

    private val pivot: CGPoint get() = CGPoint(rectWidth() / 2f, 22f)
    private val full: Float get() = max(rectHeight() - 44f, 10f)

    /** Real chain: every pendulum of the group, hanging from the previous one, at its true (unlimited) angle. */
    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val p0 = pg ?: return
        val g = Editor.scene.layers.firstOrNull { it.id == groupId }
        val r = rig
        if (g != null && r != null) { p0.angles(g, r, Editor.time) }
        val n = 1 + p0.pends.size
        val raw = if (p0.lastRaw.size == n) p0.lastRaw else FloatArray(n)
        var p = pivot; var ang: Float = 0f
        c.setStrokeColor(0x668C8C96.toInt()); c.setLineWidth(1f)
        c.move(p); c.addLine(CGPoint(p.x, p.y + full)); c.strokePath()
        c.setLineWidth(2.5f)
        for (k in 0 until n) {
            val len = if (k == 0) p0.length else p0.pends[k - 1].length
            val rr = full / n * min(1f, max(0.25f, len / 2f + 0.25f))
            ang += raw[k]
            val q = CGPoint(p.x + rr * sin(ang), p.y + rr * cos(ang))
            c.setStrokeColor(0xFFFFFFFF.toInt()); c.move(p); c.addLine(q); c.strokePath()
            c.setFillColor(C.GREEN)
            val br: Float = if (k == n - 1) 9f + 5f * min(2f, p0.weight) else 6f
            c.fillEllipse(CGRect(q.x - br, q.y - br, br * 2f, br * 2f))
            p = q
        }
        c.setFillColor(0xFFFFFFFF.toInt())
        c.fillEllipse(CGRect(pivot.x - 5f, pivot.y - 5f, 10f, 10f))
        drawText(String.format(Locale.US, "%d pendulum%s   duration %.2f   convergence %.2f",
            n, if (n == 1) "" else "s", p0.length, p0.damping), 10f, rect.height - 18f + 11f, color = C.DIM, size = 11f)
    }

    private fun drag(t: UITouch, end: Boolean) {   // drag anywhere: distance from the pivot = duration of pendulum 1
        val q = t.location(this); val p = pivot
        pg?.length = min(2f, max(0.1f, hypot((q.x - p.x).toDouble(), (max(q.y - p.y, 1f)).toDouble()).toFloat() / full * 2f))
        setNeedsDisplay(); onEdit?.invoke(end)
    }
    override fun touchesBegan(t: Set<UITouch>, e: com.saiki.motion.uikit.UIEvent?) { onBegin?.invoke(); t.firstOrNull()?.let { drag(it, end = false) } }
    override fun touchesMoved(t: Set<UITouch>, e: com.saiki.motion.uikit.UIEvent?) { t.firstOrNull()?.let { drag(it, end = false) } }
    override fun touchesEnded(t: Set<UITouch>, e: com.saiki.motion.uikit.UIEvent?) { t.firstOrNull()?.let { drag(it, end = true) } }
}

/// 2D parameter pad: a grid with a dot. Dragging sets two linked parameters at once; key positions show as diamonds.
class LinkPad : UiView(com.saiki.motion.uikit.appContext!!) {
    var xlo: Float = -30f; var xhi: Float = 30f; var ylo: Float = -30f; var yhi: Float = 30f
    var vx: Float = 0f; var vy: Float = 0f
    var keysX: List<Float> = emptyList()
    var keysY: List<Float> = emptyList()
    var onChange: ((Float, Float) -> Unit)? = null

    private val area: CGRect get() = boundsRect.insetBy(14f, 14f)
    private fun px(v: Float): Float = area.minX + area.width * ((v - xlo) / max(xhi - xlo, 1e-4f))
    private fun py(v: Float): Float = area.maxY - area.height * ((v - ylo) / max(yhi - ylo, 1e-4f))

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        c.setStrokeColor(0x2EFFFFFF.toInt()); c.setLineWidth(1f)
        for (i in 0..4) {
            val f = i / 4f
            c.move(CGPoint(area.minX + area.width * f, area.minY)); c.addLine(CGPoint(area.minX + area.width * f, area.maxY))
            c.move(CGPoint(area.minX, area.minY + area.height * f)); c.addLine(CGPoint(area.maxX, area.minY + area.height * f))
        }
        c.strokePath()
        c.setFillColor(0xCCFF8A1F.toInt())
        for (kx in keysX) for (ky in keysY) {
            val p = CGPoint(px(kx), py(ky))
            c.move(CGPoint(p.x, p.y - 5f)); c.addLine(CGPoint(p.x + 5f, p.y))
            c.addLine(CGPoint(p.x, p.y + 5f)); c.addLine(CGPoint(p.x - 5f, p.y)); c.fillPath()
        }
        val d = CGPoint(px(min(xhi, max(xlo, vx))), py(min(yhi, max(ylo, vy))))
        c.setStrokeColor(0x80FFFFFF.toInt())
        c.move(CGPoint(d.x, area.minY)); c.addLine(CGPoint(d.x, area.maxY))
        c.move(CGPoint(area.minX, d.y)); c.addLine(CGPoint(area.maxX, d.y)); c.strokePath()
        c.setFillColor(0xFFFFFFFF.toInt()); c.fillEllipse(CGRect(d.x - 9f, d.y - 9f, 18f, 18f))
        c.setFillColor(C.GREEN); c.fillEllipse(CGRect(d.x - 5f, d.y - 5f, 10f, 10f))
    }
    private fun pick(t: UITouch) {
        val q = t.location(this)
        var x = xlo + (q.x - area.minX) / max(area.width, 1f) * (xhi - xlo)
        var y = ylo + (area.maxY - q.y) / max(area.height, 1f) * (yhi - ylo)
        x = min(xhi, max(xlo, x)); y = min(yhi, max(ylo, y))
        val nx = keysX.minByOrNull { abs(px(it) - q.x) }
        if (nx != null && abs(px(nx) - q.x) < 12f) x = nx
        val ny = keysY.minByOrNull { abs(py(it) - q.y) }
        if (ny != null && abs(py(ny) - q.y) < 12f) y = ny
        vx = x; vy = y; setNeedsDisplay(); onChange?.invoke(x, y)
    }
    override fun touchesBegan(t: Set<UITouch>, e: com.saiki.motion.uikit.UIEvent?) { t.firstOrNull()?.let { pick(it) } }
    override fun touchesMoved(t: Set<UITouch>, e: com.saiki.motion.uikit.UIEvent?) { t.firstOrNull()?.let { pick(it) } }
}

// MARK: - layer tree row (iOS RigRowCell: UITableView drag & drop twin)

class RigRowCell : com.saiki.motion.uikit.UITableViewCell() {
    val chev = PillButton("", "chev_down", C.CARD2, C.TEXT)
    val icon = IconView("photo", C.DIM, 18f)
    val name = UILabel(com.saiki.motion.uikit.appContext!!)
    val eye = PillButton("", "eye", C.CARD2, C.TEXT)
    val more = PillButton("", "more", C.CARD2, C.TEXT)
    var indent: Float = 6f
    var onChev: (() -> Unit)? = null
    var onEye: (() -> Unit)? = null
    var onMore: (() -> Unit)? = null
    /** Drag-to-reparent (iOS UITableView drag & drop twin): cell reports drag travel to the table. */
    var onDragRow: ((RigRowCell, Float, Boolean) -> Unit)? = null   // (cell, y in table, ended)
    private val iconBox = UiView(com.saiki.motion.uikit.appContext!!)
    private var downY = 0f
    private var dragging = false

    init {
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        name.font = com.saiki.motion.uikit.UIFont.systemFont(14f)
        name.lineBreakMode = com.saiki.motion.uikit.NSLineBreakMode.byTruncatingTail
        chev.onClick = { onChev?.invoke() }
        eye.onClick = { onEye?.invoke() }
        more.onClick = { onMore?.invoke() }
        contentView.addSubview(chev)
        contentView.addSubview(iconBox); iconBox.addSubview(icon)
        contentView.addSubview(name)
        contentView.addSubview(eye)
        contentView.addSubview(more)
    }

    override fun layoutSubviews() {
        super.layoutSubviews()
        val h = rectHeight()
        val x0 = indent
        chev.frame = CGRect(x0, (h - 34f) / 2f, 26f, 34f)
        iconBox.frame = CGRect(x0 + 28f, 0f, 18f, h)
        icon.frame = CGRect(0f, (h - 18f) / 2f, 18f, 18f)
        val mx = rectWidth() - 6f
        more.frame = CGRect(mx - 34f, (h - 34f) / 2f, 34f, 34f)
        eye.frame = CGRect(more.frame.x - 34f, (h - 34f) / 2f, 34f, 34f)
        name.frame = CGRect(iconBox.frame.maxX + 6f, 0f, max(10f, eye.frame.x - 4f - (iconBox.frame.maxX + 6f)), h)
    }

    override fun touchesBegan(t: Set<UITouch>, e: com.saiki.motion.uikit.UIEvent?) {
        super.touchesBegan(t, e)
        downY = t.firstOrNull()?.location(this)?.y ?: 0f
        dragging = false
    }

    override fun touchesMoved(t: Set<UITouch>, e: com.saiki.motion.uikit.UIEvent?) {
        super.touchesMoved(t, e)
        val p = t.firstOrNull()?.location(this) ?: return
        if (!dragging && abs(p.y - downY) > 14f) dragging = true
        if (dragging) {
            val ty = frame.y + p.y
            onDragRow?.invoke(this, ty, false)
        }
    }

    override fun touchesEnded(t: Set<UITouch>, e: com.saiki.motion.uikit.UIEvent?) {
        super.touchesEnded(t, e)
        if (dragging) {
            val p = t.firstOrNull()?.location(this)
            if (p != null) onDragRow?.invoke(this, frame.y + p.y, true)
            dragging = false
        }
    }
}

// MARK: - controller

/** iOS RigEditorViewController. Auto Layout is replaced by the root layout pass below (project convention). */
class RigEditorViewController(private val inGroup: Layer, private val host: com.saiki.motion.app.EditorViewController) : com.saiki.motion.uikit.UIViewController() {

    private val groupId = inGroup.id
    private val fallbackGroup = inGroup
    private val group: Layer get() = Editor.scene.layers.firstOrNull { it.id == groupId } ?: fallbackGroup
    private var curTab = 0                        // 0 layers, 1 warp, 2 mesh, 3 transform
    private var selId = -1
    private var selWarp = -1
    private var activeParam: Int = inGroup.rig?.params?.firstOrNull()?.id ?: -1
    private var tool = 0
    private var penMode = 0                       // full mode warp pen: 0 off, 1 add point, 2 remove point
    private var gridN = 4
    private var softR: Float = 1.5f
    private var brushR: Float = 0.25f
    private var brushK: Float = 1f
    private val canvas = RigCanvas()
    private val stack = VStack()                  // the scrolling parameter panel (iOS UIStackView in scroll)
    private val scroll = com.saiki.motion.uikit.CapScroll(com.saiki.motion.uikit.appContext!!)
    private val layerTable = com.saiki.motion.uikit.UITableView(com.saiki.motion.uikit.appContext!!)
    private val addBar = HStack()
    private var treeRows: List<Pair<Layer, Int>> = emptyList()
    private val collapsed = HashSet<Int>()
    private var dragId = -1
    private var tabButtons: List<PillButton> = emptyList()
    private var paramSlider: RulerSlider? = null
    private var keyBar: KeyBar? = null
    private val rig: Rig get() = group.rig!!
    private var isFull = false
    private val topBar = HStack()
    private val tabsRow = HStack()
    private val stripBack = UiView(com.saiki.motion.uikit.appContext!!)
    private val fullBarView = UiView(com.saiki.motion.uikit.appContext!!)
    private val fullStack = VStack()
    private var settingsCard: UiView? = null

    // strip (always visible, Live2D style)
    private val strip = VStack()
    private var keyBtn: PillButton? = null
    private var keyInfo: PLabel? = null

    // physics
    private var previewTimer: android.os.Handler? = null
    private var previewTick: Runnable? = null
    private var previewT0: Float = 0f
    private var pendViews: List<PendulumView> = emptyList()
    private var physSel = 0
    private var physPend = 0
    private var physTab = 0
    private var hostRenderPending = false

    /** Root view whose Android layout pass drives the manual frames (Auto Layout twin). */
    private class RigRoot(val vc: RigEditorViewController) : UiView(com.saiki.motion.uikit.appContext!!) {
        override fun layoutSubviews() { super.layoutSubviews(); vc.layoutRoot() }
    }
    override val view: UiView = RigRoot(this)

    override fun viewDidAppear(animated: Boolean) {
        super.viewDidAppear(animated)
        Rig.onLiveTick = {
            canvas.setNeedsDisplay()
            for (v in pendViews) v.setNeedsDisplay()
            host.render()
        }
    }
    override fun viewWillDisappear(animated: Boolean) {
        super.viewWillDisappear(animated)
        Rig.onLiveTick = { host.render() }
    }

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(C.BG)
        val done = btn("Done", C.GREEN, C.BG) { close() }
        val undo = iconBtn("arrow.uturn.backward") { host.doUndo(); afterRestore() }
        val redo = iconBtn("arrow.uturn.forward") { host.doRedo(); afterRestore() }
        val fullBtn = iconBtn("arrow.up.left.and.arrow.down.right") { toggleFull() }
        val title = UILabel(com.saiki.motion.uikit.appContext!!)
        title.text = "Cubism — ${group.name}"
        title.textColor = argbToUIColor(C.TEXT)
        title.font = boldFont(15f)
        for (v in listOf(title, spacer(), fullBtn, undo, redo, done)) topBar.add(v)
        val names = listOf("Layers", "Warp", "Mesh", "Move", "Physics")
        val tbs = ArrayList<PillButton>()
        for ((i, n) in names.withIndex()) {
            val b = btn(n) { curTab = i; reload() }
            b.textSize = 13f
            tbs.add(b); tabsRow.add(b)
        }
        tabButtons = tbs
        canvas.group = group
        canvas.onSelect = { id ->
            selId = id
            if (isFull && curTab == 2) ensureMesh()
            reload()
        }
        canvas.onBeginEdit = { host.pushUndo() }
        canvas.onCommit = { live, startS -> commit(live, startS) }
        canvas.onAdd = { l, rx, ry -> addPin(l, rx, ry) }
        canvas.onDel = { l, pin -> delPin(l, pin) }
        canvas.onPenAdd = { w, u, v -> penAdd(w, u, v) }
        canvas.onPenDel = { w, k -> penDel(w, k) }
        canvas.onPivot = { l, ax, ay -> host.setAnchorKeepVisual(l, ax, ay); host.render() }
        layerTable.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        layerTable.rowHeight = 38f
        layerTable.dataSource = object : com.saiki.motion.uikit.UITableViewDataSource {
            override fun numberOfRows(t: com.saiki.motion.uikit.UITableView, section: Int): Int = treeRows.size
            override fun cellForRow(t: com.saiki.motion.uikit.UITableView, row: Int): com.saiki.motion.uikit.UITableViewCell = cellFor(treeRows[row])
        }
        layerTable.delegate = object : com.saiki.motion.uikit.UITableViewDelegate {
            override fun didSelectRow(t: com.saiki.motion.uikit.UITableView, row: Int) {
                val l = treeRows[row].first
                selId = l.id; if (l.deformer == 1) selWarp = l.id
                reload()
            }
        }
        for ((t, k) in listOf(Pair("+ Folder", 0), Pair("+ Warp Deformer", 1), Pair("+ Rotate Deformer", 2))) {
            val b = btn(t, if (k == 0) C.CARD2 else C.GREEN, if (k == 0) C.TEXT else C.BG) { newContainer(k) }
            b.textSize = 12f
            addBar.add(b)
        }
        scroll.addSubview(stack)
        stripBack.setBackgroundColor(0xEB0E0E10.toInt())
        fullBarView.setBackgroundColor(0xE00E0E10.toInt())
        for (v in listOf(topBar, tabsRow, canvas, strip, addBar, layerTable, scroll)) view.addSubview(v)
        view.addSubview(stripBack); view.addSubview(fullBarView); fullBarView.addSubview(fullStack)
        stripBack.isHidden = true; fullBarView.isHidden = true
        reload()
    }

    /** Manual frame pass (iOS NSLayoutConstraint set twin). */
    fun layoutRoot() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w <= 1f || h <= 1f) return
        val ins = view.safeAreaInsets
        if (isFull) {
            topBar.isHidden = true; tabsRow.isHidden = true
            layerTable.isHidden = true; addBar.isHidden = true; scroll.isHidden = true
            stripBack.isHidden = false; fullBarView.isHidden = false
            canvas.frame = CGRect(0f, 0f, w, h)
            val sh = stripHeight(w - 24f)
            stripBack.frame = CGRect(0f, h - sh - 8f - ins.bottom, w, sh + 8f + ins.bottom)
            strip.frame = CGRect(12f, h - sh - ins.bottom, w - 24f, sh)
            layoutStackV(strip, w - 24f)
            fullBarView.frame = CGRect(8f, ins.top + 4f, w - 16f, fullStackHeight(w - 28f))
            fullStack.frame = CGRect(6f, 6f, fullBarView.rectWidth() - 12f, fullBarView.rectHeight() - 12f)
            layoutStackV(fullStack, fullStack.rectWidth())
        } else {
            stripBack.isHidden = true; fullBarView.isHidden = true
            topBar.isHidden = false; tabsRow.isHidden = false
            topBar.frame = CGRect(12f, ins.top + 6f, w - 24f, 44f)
            layoutStackH(topBar, topBar.rectWidth(), 44f, 8f)
            canvas.frame = CGRect(0f, topBar.frame.maxY + 8f, w, h * 0.30f)
            val stripH = stripHeight(w - 24f)
            strip.frame = CGRect(12f, canvas.frame.maxY + 6f, w - 24f, stripH)
            tabsRow.frame = CGRect(12f, strip.frame.maxY + 8f, w - 24f, 38f)
            layoutStackH(tabsRow, tabsRow.rectWidth(), 38f, 5f)
            addBar.frame = CGRect(12f, tabsRow.frame.maxY + 6f, w - 24f, 38f)
            layoutStackH(addBar, addBar.rectWidth(), 38f, 6f)
            layerTable.isHidden = curTab != 0
            addBar.isHidden = curTab != 0
            scroll.isHidden = curTab == 0
            layerTable.frame = CGRect(0f, addBar.frame.maxY + 4f, w, max(0f, h - addBar.frame.maxY - 4f - ins.bottom))
            scroll.frame = CGRect(0f, tabsRow.frame.maxY + 8f, w, max(0f, h - tabsRow.frame.maxY - 8f - ins.bottom))
            val sh2 = stackHeight(w - 24f)
            stack.frame = CGRect(12f, 0f, w - 24f, sh2)
            scroll.contentSize = com.saiki.motion.uikit.CGSize(w - 24f, sh2 + 30f)
        }
        val sc = settingsCard
        if (sc != null) {
            layoutStackV(sc, w - 24f)
            sc.frame = CGRect(12f, strip.frame.y - 10f - sc.rectHeight(), w - 24f, sc.rectHeight())
        }
    }

    private fun stripHeight(w: Float): Float { layoutStackV(strip, w); return stackContentH(strip) }
    private fun fullStackHeight(w: Float): Float { layoutStackV(fullStack, w); return stackContentH(fullStack) + 12f }
    private fun stackHeight(w: Float): Float { layoutStackV(stack, w); return stackContentH(stack) }

    // simple vertical / horizontal stack twins (iOS UIStackView roles used by this screen)
    private class VStack : UiView(com.saiki.motion.uikit.appContext!!)
    private class HStack : UiView(com.saiki.motion.uikit.appContext!!)
    private fun spacer(): UiView { val v = UiView(com.saiki.motion.uikit.appContext!!); v.tag = SPACER_TAG; return v }
    private fun layoutStackV(s: UiView, w: Float) {
        var y = 0f
        for (c in s.subviews) {
            val hh = if (c.tag == SPACER_TAG) 0f else childH(c, w)
            c.frame = CGRect(0f, y, w, hh)
            y += hh + 4f
        }
    }
    private fun stackContentH(s: UiView): Float {
        var y = 0f
        for (c in s.subviews) y += (if (c.tag == SPACER_TAG) 0f else c.rectHeight()) + 4f
        return max(0f, y - 4f)
    }
    private fun layoutStackH(s: UiView, w: Float, h: Float, spacing: Float) {
        val kids = s.subviews
        val spacers = kids.count { it.tag == SPACER_TAG }
        val fixed = kids.filter { it.tag != SPACER_TAG }.sumOf { it.rectWidth().toDouble() }.toFloat() + spacing * max(0, kids.size - 1)
        val free = max(0f, w - fixed)
        var x = 0f
        for (c in kids) {
            val cw = if (c.tag == SPACER_TAG) (if (spacers > 0) free / spacers else 0f) else c.rectWidth()
            c.frame = CGRect(x, 0f, cw, h)
            x += cw + spacing
        }
    }
    private fun childH(c: UiView, w: Float): Float = when (c) {
        is PLabel -> c.height(w)
        is RulerSlider -> 60f * Dev.k
        is KeyBar -> 40f
        is LinkPad -> 170f
        is PendulumView -> 120f
        is VStack -> stackContentH(c)
        else -> if (c.rectHeight() > 0f) c.rectHeight() else 38f
    }

    private fun close() {
        stopPreview()
        dismiss(animated = true) {
            host.refreshToolbar(); host.refreshPanel(); host.render()
        }
    }

    /// After host undo/redo the whole project was rebuilt: re-resolve everything by id.
    private fun afterRestore() {
        if (Editor.scene.layers.none { it.id == groupId && it.rig != null }) { close(); return }
        if (rig.param(activeParam) == null) activeParam = rig.params.firstOrNull()?.id ?: -1
        if (layer(selId) == null) selId = -1
        reload(); redraw()
    }

    // MARK: helpers
    private fun btn(title: String, fill: Int = C.CARD2, tc: Int = C.TEXT, act: () -> Unit): PillButton {
        val b = PillButton(title, null, fill, tc)
        b.onClick = act
        return b
    }
    private fun iconBtn(sym: String, act: () -> Unit): UiView {
        val v = IconView(Icons.ownName(sym), C.TEXT, 20f)
        v.setBackgroundColor(C.CARD2)
        v.onClick = act
        v.frame = CGRect(0f, 0f, 40f, 38f)
        return v
    }
    private fun lbl(s: String, size: Float = 14f, color: Int = C.TEXT, bold: Boolean = false): PLabel {
        val l = PLabel()
        l.text = s; l.color = color; l.size = size; l.bold = bold
        return l
    }
    private fun slider(name: String, lo: Float, hi: Float, v: Float, dec: Int = 2, change: (Float) -> Unit): RulerSlider {
        val s = RulerSlider()
        s.label = name; s.lo = lo; s.hi = hi; s.dec = dec; s.value = v; s.canKey = false
        s.onBeginDrag = { host.pushUndo() }
        s.onChange = change
        return s
    }
    private fun chips(names: List<String>, sel: Int, act: (Int) -> Unit): HStack {
        val s = HStack()
        for ((i, n) in names.withIndex()) { s.add(btn(n, if (i == sel) C.GREEN else C.CARD2, if (i == sel) C.BG else C.TEXT) { act(i) }) }
        return s
    }
    private fun toggleRow(title: String, on: Boolean, change: (Boolean) -> Unit): HStack {
        val sw = SwitchRow()
        sw.label = title; sw.on = on; sw.onToggle = change
        sw.frame = CGRect(0f, 0f, 220f, 52f)
        val r = HStack(); r.add(lbl(title, 14f)); r.add(spacer()); r.add(sw)
        return r
    }
    private fun ask(title: String, items: List<String>, pick: (Int) -> Unit) {
        com.saiki.motion.app.Dlg(this).setTitle(title).setItems(items) { _, i -> pick(i) }.show()
    }
    private fun confirm(title: String, msg: String, ok: () -> Unit) {
        com.saiki.motion.app.Dlg(this).setTitle(title).setMessage(msg)
            .setPositiveButton("Yes") { _, _ -> ok() }.setNegativeButton("Cancel", null).show()
    }
    private fun textField(ph: String, text: String): com.saiki.motion.uikit.UITextField {
        val f = com.saiki.motion.uikit.UITextField()
        f.placeholder = ph; f.text = text
        f.textColor = argbToUIColor(C.TEXT)
        f.backing.setBackgroundColor(C.CARD2)
        f.backing.setPadding(24, 12, 24, 12)
        f.backing.setTextColor(C.TEXT)
        f.frame = CGRect(0f, 0f, 300f, 40f)
        return f
    }
    private fun textDialog(title: String, initial: String, ok: (String) -> Unit) {
        val f = textField("Name", initial)
        com.saiki.motion.app.Dlg(this).setTitle(title).setView(f)
            .setPositiveButton("OK") { _, _ -> ok(if (f.text.isEmpty()) initial else f.text) }
            .setNegativeButton("Cancel", null).show()
    }
    private fun fmt(v: Float): String = String.format(Locale.US, "%.2f", v)
    private fun card(views: List<UiView>): VStack {
        val c = VStack()
        c.setBackgroundColor(C.CARD)
        for (v in views) c.add(v)
        return c
    }
    private fun members(): List<Layer> = Editor.scene.layers.filter { rig.members.contains(it.id) }
    private fun layer(id: Int): Layer? = Editor.scene.layers.firstOrNull { it.id == id }
    private val sel: Layer? get() = if (rig.members.contains(selId)) layer(selId) else null
    private val active: RigParam? get() = rig.param(activeParam)
    private val warpLayer: Layer?
        get() {
            val s = sel
            if (s != null && s.deformer == 1) return s
            if (s != null) { var cid = s.id; var n = 0
                while (n < 64) { val c2 = layer(cid) ?: break; if (c2.parentId == 0) break; val par = layer(c2.parentId) ?: break; if (par.deformer == 1) return par; cid = par.id; n++ } }
            val w = layer(selWarp)
            if (w != null && w.deformer == 1 && rig.members.contains(w.id)) return w
            return members().firstOrNull { it.deformer == 1 }
        }

    private fun redraw() {
        canvas.setNeedsDisplay()
        if (hostRenderPending) return                      // coalesce the expensive main-preview render
        hostRenderPending = true
        Handler(Looper.getMainLooper()).postDelayed({
            hostRenderPending = false; host.render()
        }, 120)
    }

    companion object {
        private const val SPACER_TAG = -981
        val propList: List<Pair<String, String>> = listOf(Pair("Position X", "x"), Pair("Position Y", "y"),
            Pair("Rotate", "rotZ"), Pair("Scale", "scale"), Pair("Opacity", "opacity"))
        val keyedProps = listOf("opacity", "x", "y", "rotZ", "scale")
        val fullTools = listOf("Warp", "Drag", "Paint", "Add", "Delete", "Pivot", "Pen+", "Pen−")
    }
    private fun propRange(k: String): Pair<Float, Float> =
        when (k) { "rotZ" -> Pair(-180f, 180f); "opacity", "scale" -> Pair(-1f, 1f); else -> Pair(-2f, 2f) }

    // MARK: panel
    private fun autoMeshWarpChildren() {
        for (w in Editor.scene.layers) if (w.deformer == 1 && rig.members.contains(w.id)) {
            for (l in Rig.descendants(w, Editor.scene.layers)) if (l.type == LayerType.IMAGE && (l.puppet?.pins?.isEmpty() ?: true)) buildGrid(l, gridN)
        }
    }

    private fun reload() {
        if (Editor.scene.layers.none { it.id == groupId && it.rig != null }) return
        if (curTab == 1 || curTab == 2) autoMeshWarpChildren()
        Rig.syncMembers(Editor.scene.layers)
        canvas.group = group
        for ((i, b) in tabButtons.withIndex()) {
            b.fillColor = if (i == curTab) C.GREEN else C.CARD2
            b.setColors(if (i == curTab) C.BG else C.TEXT)
        }
        if (curTab != 4) stopPreview()
        canvas.mode = curTab + 1                  // canvas: 1 layers, 2 warp, 3 mesh, 4 transform, 5 physics
        canvas.selId = selId
        canvas.pen = if (isFull && curTab == 1) penMode else 0
        canvas.tool = tool; canvas.brushR = brushR; canvas.brushK = brushK; canvas.softR = softR
        canvas.warpId = warpLayer?.id ?: -1
        canvas.targets = if (curTab == 2) {
            val s = sel
            if (s != null) (if (s.type == LayerType.IMAGE) listOf(s.id) else Rig.descendants(s, Editor.scene.layers).filter { it.type == LayerType.IMAGE }.map { it.id }) else emptyList()
        } else emptyList()
        rebuildStrip()
        if (isFull) rebuildFullBar() else reloadPanel()
        canvas.setNeedsDisplay()
        layoutRoot()
    }

    private fun reloadPanel() {
        for (v in stack.subviews) v.removeFromSuperview()
        when (curTab) {
            0 -> buildLayers()
            1 -> buildWarp()
            2 -> buildMesh()
            3 -> buildTransform()
            else -> buildPhysics()
        }
        layoutRoot()
    }

    // ---- parameter strip (always visible, Live2D style: pick a pose, then edit anything)

    /// Layers whose keys the strip shows / edits: folder layers, the selected layer, or everything.
    private fun keyTargets(): List<Int> {
        if (curTab == 1) { val w = warpLayer; if (w != null) return listOf(w.id) }
        val l = sel
        if (l != null) return listOf(l.id)
        return members().map { it.id }
    }

    private fun keyValues(p: RigParam, ids: List<Int>): List<Float> {
        val out = ArrayList<Float>()
        for (b in rig.bindings) if (b.paramId == p.id && ids.contains(b.layerId)) {
            for (k in b.keys) if (out.none { abs(it - k.v) < 1e-3f }) out.add(k.v)
        }
        return out.sorted()
    }

    private fun rebuildStrip() {
        for (v in strip.subviews) v.removeFromSuperview()
        paramSlider = null; keyBar = null; keyBtn = null; keyInfo = null
        val p = active
        val pick = btn(p?.let { "Parameter: ${it.name}  ▾" } ?: "＋ Add a parameter") { paramMenu() }
        if (p == null) {
            strip.add(pick)
            strip.add(lbl("Start here: add a parameter (Eye open/close, Mouth, Angle X…). Then pick a pose on it and edit — keys are created for you.", 12f, C.DIM))
            return
        }
        val kbtn = btn("+ Key", C.GREEN, C.BG) { toggleKey(null) }
        kbtn.frame = CGRect(0f, 0f, 92f, 38f)
        keyBtn = kbtn
        val del = iconBtn("trash") { deleteParam(p) }
        val row = HStack(); row.add(pick); row.add(kbtn); row.add(del)
        strip.add(row)
        val s = slider(p.name, p.lo, p.hi, rig.value(p, group, Editor.time)) { v ->
            group.track(p.key).set(Editor.time, v, false)
            refreshKeyState()
            if (curTab == 3) reloadPanel()
            redraw()
        }
        paramSlider = s; strip.add(s)
        val kb = KeyBar()
        kb.lo = p.lo; kb.hi = p.hi
        kb.onPick = { v -> setParam(p, v) }
        keyBar = kb; strip.add(kb)
        val info = lbl("", 12f, C.DIM); keyInfo = info; strip.add(info)
        val lk = rig.links.firstOrNull { it.xId == p.id || it.yId == p.id }
        if (lk != null) {
            val px = rig.param(lk.xId) ?: return
            val py = rig.param(lk.yId) ?: return
            val pad = LinkPad()
            pad.xlo = px.lo; pad.xhi = px.hi; pad.ylo = py.lo; pad.yhi = py.hi
            pad.vx = rig.value(px, group, Editor.time); pad.vy = rig.value(py, group, Editor.time)
            pad.keysX = keyValues(px, keyTargets()); pad.keysY = keyValues(py, keyTargets())
            pad.onChange = { x, y ->
                group.track(px.key).set(Editor.time, x, false)
                group.track(py.key).set(Editor.time, y, false)
                active?.let { a -> paramSlider?.value = rig.value(a, group, Editor.time) }
                refreshKeyState()
                if (curTab == 3) reloadPanel()
                redraw()
            }
            val kk = btn("＋/− Key both axes", C.CARD2, C.TEXT) { toggleKey(px); toggleKey(py) }
            strip.add(lbl("Pad: ${lk.name} — drag the dot", 12f, C.DIM))
            strip.add(pad); strip.add(kk)
        }
        refreshKeyState()
    }

    private fun refreshKeyState() {
        val p = active ?: return
        val ids = keyTargets()
        val pv = rig.value(p, group, Editor.time)
        val keys = keyValues(p, ids)
        val on = keys.any { abs(it - pv) < 1e-3f }
        keyBar?.value = pv; keyBar?.keys = keys; keyBar?.setNeedsDisplay()
        keyBtn?.text = if (on) "− Key" else "+ Key"
        keyBtn?.fillColor = if (on) C.CARD2 else C.GREEN
        keyBtn?.setColors(if (on) C.TEXT else C.BG)
        val hint = if (p.lo == 0f && p.hi == 1f) "  (0 = closed, 1 = open)" else ""
        keyInfo?.text = (if (on) "◇ Key selected at ${fmt(pv)} — edit below to change it." else "No key at ${fmt(pv)} — edit below or press + Key to create one.") + hint
    }

    private fun setParam(p: RigParam, v: Float) {
        group.track(p.key).set(Editor.time, v, false)
        paramSlider?.value = v
        refreshKeyState()
        if (curTab == 3) reloadPanel()
        redraw()
    }

    private fun toggleKey(given: RigParam?) {
        val p = given ?: active ?: return
        val ids = keyTargets()
        val pv = rig.value(p, group, Editor.time)
        host.pushUndo()
        if (keyValues(p, ids).any { abs(it - pv) < 1e-3f }) {
            for (b in rig.bindings) if (b.paramId == p.id && ids.contains(b.layerId)) {
                b.keys.removeAll { abs(it.v - pv) < 1e-3f }
            }
            rig.bindings.removeAll { it.keys.isEmpty() }
        } else {
            for (id in ids) {
                var keys = keyedProps
                val w = layer(id)
                if (w != null && w.deformer == 1) {
                    val wp = w.warp
                    if (wp != null) { keys = (0 until (wp.n * wp.n)).flatMap { listOf("wx$it", "wy$it") } }
                }
                val pp = layer(id)?.puppet
                if (pp != null) for (pin in pp.pins) { keys = keys + listOf("pp${pin.id}x", "pp${pin.id}y") }
                for (k in keys) { val b = rig.binding(p, id, k, create = true); b?.setKey(pv, b.eval(pv)) }
            }
        }
        reload(); redraw()
    }

    /// Canvas drag / brush finished: store the change as a keyform at the current parameter value.
    private fun commit(live: Map<Int, Map<String, Float>>, startM: Map<Int, Map<String, Float>>) {
        val p = active
        if (p == null) { host.toast("Add a parameter first"); redraw(); return }
        val pv = rig.value(p, group, Editor.time)
        for ((lid, d) in live) {
            for ((k, v) in d) {
                val delta = v - (startM.get(lid)?.get(k) ?: 0f)
                if (abs(delta) < 1e-5f) continue
                val b = rig.binding(p, lid, k, create = true) ?: continue
                b.setKey(pv, b.eval(pv) + delta)
            }
        }
        refreshKeyState()
        if (curTab == 3) reloadPanel()
        redraw()
    }

    private fun paramMenu() {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun add(t: String, a: () -> Unit) { labels.add(t); acts.add(a) }
        val fids = rig.pfolders.map { it.id }.toSet()
        for (p in rig.params) if (p.folder == 0 || !fids.contains(p.folder)) {
            add(p.name) { activeParam = p.id; reload() }
        }
        for (f in rig.pfolders) {
            add("Folder · ${f.name}  (${rig.params.count { it.folder == f.id }})") { folderMenu(f) }
        }
        add("＋ New parameter") { addParamPreset() }
        add("＋ New folder") {
            textDialog("New folder", "Folder") { name ->
                host.pushUndo()
                rig.pfolders.add(RigFolder(rig.nextId, name)); rig.nextId += 1
                reload()
            }
        }
        add("Link 2 parameters (2D pad)…") { linkDialog() }
        val p = active
        if (p != null) {
            add("Move “${p.name}” to folder…") { moveParam(p) }
            val lk = rig.links.firstOrNull { it.xId == p.id || it.yId == p.id }
            if (lk != null) {
                add("Remove pad “${lk.name}”") {
                    host.pushUndo(); rig.links.removeAll { it.id == lk.id }; reload()
                }
            }
            add("Rename current") { textDialog("Rename parameter", p.name) { p.name = it; reload() } }
            add("Delete current") { deleteParam(p) }
        }
        ask("Parameters", labels) { i -> if (acts.indices.contains(i)) acts[i]() }
    }

    private fun folderMenu(f: RigFolder) {
        val ps = rig.params.filter { it.folder == f.id }
        ask("Folder · ${f.name}", ps.map { it.name } + listOf("Rename folder", "Delete folder (keep parameters)")) { i ->
            if (i < ps.size) { activeParam = ps[i].id; reload(); return@ask }
            if (i == ps.size) { textDialog("Rename folder", f.name) { f.name = it; reload() }; return@ask }
            host.pushUndo()
            for (p in rig.params) if (p.folder == f.id) p.folder = 0
            rig.pfolders.removeAll { it.id == f.id }
            reload()
        }
    }

    private fun moveParam(p: RigParam) {
        ask("Move ${p.name} to", listOf("Root") + rig.pfolders.map { it.name }) { i ->
            host.pushUndo()
            p.folder = if (i == 0) 0 else rig.pfolders[i - 1].id
            reload()
        }
    }

    /// Two parameters on one pad: drag the dot to drive both (head Angle X / Angle Y).
    private fun linkDialog() {
        val ps = rig.params
        if (ps.size < 2) { host.toast("Add two parameters first"); return }
        ask("Pad horizontal axis (X)", ps.map { it.name }) { i ->
            val rest = ps.filter { it.id != ps[i].id }
            ask("Pad vertical axis (Y)", rest.map { it.name }) { j ->
                host.pushUndo()
                val k = RigLink(rig.nextId, "${ps[i].name} + ${rest[j].name}", ps[i].id, rest[j].id); rig.nextId += 1
                rig.links.add(k); activeParam = ps[i].id; reload()
            }
        }
    }

    private fun deleteParam(p: RigParam) {
        confirm("Delete ${p.name}?", "Its keys are removed too. You can undo this.") {
            host.pushUndo()
            rig.params.removeAll { it.id == p.id }
            rig.bindings.removeAll { it.paramId == p.id }; rig.removeParam(p.id)
            group.props.remove(p.key)
            activeParam = rig.params.firstOrNull()?.id ?: -1
            reload(); redraw()
        }
    }

    private fun addParamPreset() {
        val presets = listOf(
            listOf("Eye L open/close", 0f, 1f, 1f), listOf("Eye R open/close", 0f, 1f, 1f), listOf("Mouth open/close", 0f, 1f, 0f),
            listOf("Angle X", -30f, 30f, 0f), listOf("Angle Y", -30f, 30f, 0f), listOf("Angle Z", -30f, 30f, 0f), listOf("Breath", 0f, 1f, 0f))
        ask("New parameter", presets.map { it[0] as String } + listOf("Custom…")) { i ->
            if (i >= presets.size) { addParamDialog(); return@ask }
            val q = presets[i]
            host.pushUndo()
            activeParam = rig.addParam(q[0] as String, q[1] as Float, q[2] as Float, q[3] as Float, group).id
            reload()
        }
    }

    private fun addParamDialog() {
        val n = textField("Name", "Param ${rig.nextId}")
        val lo = textField("Min", "-30"); val hi = textField("Max", "30"); val df = textField("Default", "0")
        val sv = VStack()
        for (f in listOf(n, lo, hi, df)) sv.add(f)
        com.saiki.motion.app.Dlg(this).setTitle("New parameter").setView(sv)
            .setPositiveButton("Add") { _, _ ->
                var a = lo.text.toFloatOrNull() ?: -30f
                var b = hi.text.toFloatOrNull() ?: 30f
                if (a > b) { val t = a; a = b; b = t }
                if (b - a < 0.001f) b = a + 1f
                val d = min(b, max(a, df.text.toFloatOrNull() ?: 0f))
                host.pushUndo()
                val p = rig.addParam(if (n.text.isEmpty()) "Param" else n.text, a, b, d, group)
                activeParam = p.id
                reload()
            }.setNegativeButton("Cancel", null).show()
    }

    // ---- layers tab: compact tree, drag a row onto a folder / deformer to move it in
    private fun isContainer(l: Layer): Boolean = l.type == LayerType.GROUP
    private fun isInside(x: Layer?, anc: Layer): Boolean {
        var cur = x; var n = 0
        while (cur != null && n < 64) { if (cur.id == anc.id) return true; cur = layer(cur.parentId); n += 1 }
        return false
    }
    private fun rebuildTree() {
        val rows = ArrayList<Pair<Layer, Int>>()
        fun walk(pid: Int, d: Int) {
            for (l in Editor.scene.layers.reversed()) if (l.parentId == pid && l.id != groupId) {
                rows.add(Pair(l, d))
                if (isContainer(l) && !collapsed.contains(l.id) && d < 12) walk(l.id, d + 1)
            }
        }
        walk(groupId, 0)
        treeRows = rows
        layerTable.reloadData()
        // == iOS: the empty tree shows a centred hint as the table background
        layerTable.backgroundView = if (rows.isEmpty()) {
            com.saiki.motion.uikit.UILabel().apply {
                text = "Empty. Add a folder or deformer above, or put layers under this rig group in the timeline."
                textColor = com.saiki.motion.uikit.UIColor(C.DIM); font = com.saiki.motion.uikit.UIFont.systemFont(13f)
                textAlignment = com.saiki.motion.uikit.NSTextAlignment.center
            }
        } else null
    }
    private fun buildLayers() { rebuildTree() }

    private fun newContainer(kind: Int) {
        host.pushUndo()
        val s = Editor.scene; val p = Editor.project
        val id = p.nextId; p.nextId += 1
        val nm = listOf("Folder", "Warp Deformer", "Rotate Deformer")[kind]
        val n = s.layers.count { it.type == LayerType.GROUP && it.rig == null && it.deformer == kind } + 1
        val l = Layer(id, "$nm $n", LayerType.GROUP)
        l.end = s.duration; l.deformer = kind
        if (kind == 1) l.warp = Warp()
        var par = groupId
        val sl = sel
        if (sl != null) par = if (sl.type == LayerType.GROUP) sl.id else (if (rig.members.contains(sl.parentId)) sl.parentId else groupId)
        l.parentId = par
        s.layers.add(l)
        collapsed.remove(par); selId = l.id
        if (kind == 1) { selWarp = l.id; fitWarp(l) }
        reload(); redraw()
    }

    private fun fitWarp(w: Layer) {
        val wp = w.warp ?: return
        val inv = Xf.invert(Xf.matrix(w, Editor.time)) ?: return
        var x0 = Float.POSITIVE_INFINITY; var y0 = Float.POSITIVE_INFINITY
        var x1 = Float.NEGATIVE_INFINITY; var y1 = Float.NEGATIVE_INFINITY
        for (l in Rig.descendants(w, Editor.scene.layers)) if (l.type == LayerType.IMAGE) {
            val m = Xf.matrix(l, Editor.time); val (qw, qh) = Xf.quadSize(l)
            for ((cx, cy) in listOf(Pair(-1f, -1f), Pair(1f, -1f), Pair(1f, 1f), Pair(-1f, 1f))) {
                val wp2 = Xf.apply(m, cx * qw / 2f, cy * qh / 2f); val q = Xf.apply(inv, wp2.first, wp2.second)
                x0 = min(x0, q.first); x1 = max(x1, q.first); y0 = min(y0, q.second); y1 = max(y1, q.second)
            }
        }
        if (!x0.isFinite()) return
        val pad = 0.04f * max(x1 - x0, y1 - y0)
        wp.bx = x0 - pad; wp.by = y0 - pad; wp.bw = max(x1 - x0 + 2 * pad, 0.05f); wp.bh = max(y1 - y0 + 2 * pad, 0.05f)
    }

    /// Image layers inside a warp deformer need a mesh to be bent; build one and fit the grid.
    private fun prepareWarps(forL: Layer) {
        var curId = forL.id; var n = 0
        while (n < 32) {
            val cur: Layer? = layer(curId) ?: break
            if (cur != null) {
                if (cur.deformer == 1) {
                    for (i in Rig.descendants(cur, Editor.scene.layers)) if (i.type == LayerType.IMAGE && (i.puppet?.pins?.isEmpty() ?: true)) buildGrid(i, 9)
                    if (!rig.bindings.any { it.layerId == cur.id }) fitWarp(cur)
                }
                if (cur.parentId == curId) break
                curId = cur.parentId
            }
            n += 1
        }
    }

    private fun layerMenu(l: Layer) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun add(t: String, a: () -> Unit) { labels.add(t); acts.add(a) }
        add("Rename") { textDialog("Rename", l.name) { l.name = it; reload() } }
        add("Move to…") {
            val c = members().filter { isContainer(it) && !isInside(it, l) }
            ask("Move ${l.name} to", listOf("Rig root") + c.map { it.name }) { j ->
                host.pushUndo()
                l.parentId = if (j == 0) groupId else c[j - 1].id
                if (j > 0) collapsed.remove(c[j - 1].id)
                prepareWarps(l); reload(); redraw()
            }
        }
        add("Take out of rig") {
            host.pushUndo(); l.parentId = -1
            if (selId == l.id) selId = -1
            reload(); redraw()
        }
        if (isContainer(l)) {
            add("Delete (keep contents)") {
                host.pushUndo()
                for (c in Editor.scene.layers) if (c.parentId == l.id) c.parentId = l.parentId
                rig.removeLayer(l.id)
                Editor.scene.layers.removeAll { it.id == l.id }
                if (selId == l.id) selId = -1
                reload(); redraw()
            }
        } else if (l.type == LayerType.IMAGE) {
            add(if (l.clipIds.isEmpty()) "Clipping mask…" else "Clipping mask… (${l.clipIds.count()} mask${if (l.clipIds.count() == 1) "" else "s"}${if (l.clipInv) ", inverted" else ""})") { clipMenu(l) }
        }
        ask(l.name, labels) { i -> if (acts.indices.contains(i)) acts[i]() }
    }

    /// Cubism-style clipping: pick which layer(s) mask this one (several masks combine), optionally inverted.
    private fun clipMenu(l: Layer) {
        val cands = members().filter { it.type == LayerType.IMAGE && it.id != l.id }
        if (cands.isEmpty()) { host.toast("No other image layer to use as a mask"); return }
        val labels = cands.map { (if (l.clipIds.contains(it.id)) "✓ " else "") + it.name }.toMutableList()
        labels.add("Invert mask: " + if (l.clipInv) "ON" else "off")
        labels.add("Clear clipping")
        ask("Clip “${l.name}” by… (tap to select masks)", labels) { i ->
            host.pushUndo()
            if (i < cands.size) {
                val id = cands[i].id
                val k = l.clipIds.indexOf(id)
                if (k >= 0) l.clipIds.removeAt(k) else l.clipIds.add(id)
            } else if (i == cands.size) l.clipInv = !l.clipInv
            else { l.clipIds.clear(); l.clipInv = false }
            reload(); redraw()
            if (i <= cands.size) Handler(Looper.getMainLooper()).postDelayed({ clipMenu(l) }, 350)
        }
    }

    // ---- mesh building blocks

    private fun hasKeys(l: Layer): Boolean = rig.bindings.any { it.layerId == l.id && it.key.startsWith("pp") }

    private fun buildGrid(l: Layer, n: Int) {
        val pu = l.puppet ?: Puppet()
        for (pin in pu.pins) { l.props.remove("pp${pin.id}x"); l.props.remove("pp${pin.id}y") }
        rig.bindings.removeAll { it.layerId == l.id && it.key.startsWith("pp") }
        pu.pins.clear(); pu.on = true
        val d = max(n - 1, 1)
        for (j in 0 until n) for (i in 0 until n) {
            pu.pins.add(PuppetPin(pu.nextId, -1f + 2f * i / d, -1f + 2f * j / d)); pu.nextId += 1
        }
        l.puppet = pu
    }

    private fun gridStepper(apply: (Int) -> Unit): HStack {
        val r = HStack()
        r.add(lbl("Mesh points: $gridN×$gridN", 14f, C.TEXT, bold = true))
        r.add(spacer())
        r.add(iconBtn("minus") { gridN = max(2, gridN - 1); apply(gridN) })
        r.add(iconBtn("plus") { gridN = min(14, gridN + 1); apply(gridN) })
        return r
    }

    private fun detailChips(pp: Puppet): UiView {
        val c = card(listOf(lbl("Smoothness (render detail)", 13f, C.DIM),
            chips(listOf("Low", "Medium", "High", "Ultra"), pp.density) { i ->
                host.pushUndo(); pp.density = i; reload(); redraw() }))
        return c
    }

    private fun brushSection() {
        stack.add(slider("Brush size", 0.05f, 1f, brushR, 2) { v -> brushR = v; canvas.brushR = v })
        stack.add(slider("Brush strength", 0.2f, 2f, brushK, 1) { v -> brushK = v; canvas.brushK = v })
    }

    // ---- full screen: canvas fills the screen, tools on top, parameter at the bottom
    private fun toggleFull() {
        isFull = !isFull; if (!isFull) penMode = 0
        dismissSettings()
        if (isFull) {
            if (curTab == 0 || curTab == 4) curTab = 2
            ensureMesh()
        }
        reload()
    }

    private fun ensureMesh() {
        val l = sel
        if (l != null && l.type == LayerType.IMAGE && (l.puppet?.pins?.isEmpty() ?: true)) {
            host.pushUndo(); buildGrid(l, gridN)
        }
    }

    private fun pickFullTool(i: Int) {
        when (i) {
            0 -> { curTab = 1; penMode = 0 }
            5 -> { curTab = 3; penMode = 0 }
            6, 7 -> { curTab = 1; penMode = i - 5 }
            else -> { penMode = 0; curTab = 2; tool = i - 1; ensureMesh() }
        }
        dismissSettings(); reload(); redraw()
    }

    private fun rebuildFullBar() {
        for (v in fullStack.subviews) v.removeFromSuperview()
        val exit = btn("Exit", C.CARD2, C.TEXT) { toggleFull() }
        val name = lbl(sel?.name ?: "Tap a layer on the canvas", 13f, C.DIM)
        val r1 = HStack()
        r1.add(exit); r1.add(name); r1.add(spacer())
        r1.add(iconBtn("arrow.uturn.backward") { host.doUndo(); afterRestore() })
        r1.add(iconBtn("arrow.uturn.forward") { host.doRedo(); afterRestore() })
        val r2 = HStack()
        for ((i, n) in fullTools.withIndex()) {
            val on = (i == 0 && curTab == 1 && penMode == 0) || (i == 5 && curTab == 3) || (i == 6 && curTab == 1 && penMode == 1) || (i == 7 && curTab == 1 && penMode == 2) || (i in 1..4 && curTab == 2 && tool == i - 1)
            val b = btn(n, if (on) C.GREEN else C.CARD2, if (on) C.BG else C.TEXT) { pickFullTool(i) }
            b.textSize = 12f
            val lp = com.saiki.motion.uikit.UILongPressGestureRecognizer { g ->
                if (g.state == com.saiki.motion.uikit.UIGestureRecognizerState.began) {
                    when {
                        i in 1..4 -> { penMode = 0; curTab = 2; tool = i - 1; ensureMesh() }
                        i == 5 -> { penMode = 0; curTab = 3 }
                        else -> { curTab = 1; penMode = if (i == 0) 0 else i - 5 }
                    }
                    reload(); openToolSettings(i)
                }
            }
            lp.minimumPressDuration = 0.4
            b.addGestureRecognizer(lp)
            r2.add(b)
        }
        fullStack.add(r1); fullStack.add(r2)
    }

    private fun dismissSettings() { settingsCard?.removeFromSuperview(); settingsCard = null }

    /// Hold a tool → settings for it, floating above the parameter bar.
    /// (Android twin: tools open their settings via a press-and-hold long-press gesture in
    ///  rebuildFullBar — see fullToolBtn below; the card floats above the parameter bar.)
    private fun openToolSettings(i: Int) {
        dismissSettings()
        val rows = ArrayList<UiView>()
        rows.add(lbl(fullTools[i] + " settings", 14f, C.TEXT, bold = true))
        if (i >= 6) {
            val w = warpLayer
            rows.add(lbl(if (i == 6) "Tap inside the warp deformer to add a point: a new row and column of the lattice is inserted there. ${w?.warp?.let { "${it.n}×${it.n}" } ?: ""}" else "Tap a green point to remove its row and column. Edge points stay.", 12f, C.DIM))
            rows.add(btn("Done", C.GREEN, C.BG) { dismissSettings() })
            val c = card(rows); c.setBackgroundColor(0xF71C1C21.toInt())
            view.addSubview(c); settingsCard = c
            layoutRoot(); return
        }
        val reopen: (Int) -> Unit = { _ -> openToolSettings(i) }
        if (i == 0) {
            val w = warpLayer
            val wp = w?.warp
            if (w != null && wp != null) {
                val r = HStack()
                r.add(lbl("Grid: ${wp.n}×${wp.n}", 14f, C.TEXT, bold = true)); r.add(spacer())
                r.add(iconBtn("minus") { setWarpN(w, wp.n - 1); openToolSettings(0) })
                r.add(iconBtn("plus") { setWarpN(w, wp.n + 1); openToolSettings(0) })
                rows.add(r)
                rows.add(slider("Soft drag (cells)", 0f, 3f, softR, 1) { v -> softR = v; canvas.softR = v })
                rows.add(btn("Fit to layers") { host.pushUndo(); fitWarp(w); redraw() })
            } else rows.add(lbl("No warp deformer yet — add one in the Layers tab.", 12f, C.DIM))
        } else if (i == 5) {
            val l = sel
            if (l != null) rows.add(btn("Reset pivot to center") { host.pushUndo(); host.setAnchorKeepVisual(l, 50f, 50f); redraw() })
            else rows.add(lbl("Tap a layer, then drag the cyan dot.", 12f, C.DIM))
        } else {
            val l = sel
            val pp = l?.puppet
            if (l != null && pp != null) {
                rows.add(toggleRow("Show mesh", pp.showMesh) { v -> pp.showMesh = v; redraw() })
                if (i == 1) {
                    rows.add(slider("Softness (falloff)", 0.5f, 6f, pp.stiffness, 1) { v -> pp.stiffness = v; redraw() })
                } else if (i == 2) {
                    rows.add(slider("Brush size", 0.05f, 1f, brushR, 2) { v -> brushR = v; canvas.brushR = v })
                    rows.add(slider("Brush strength", 0.2f, 2f, brushK, 1) { v -> brushK = v; canvas.brushK = v })
                    rows.add(btn("Clear keys of this parameter", C.CARD2, C.DIM) {
                        val p = active ?: return@btn
                        host.pushUndo()
                        rig.bindings.removeAll { it.paramId == p.id && it.layerId == l.id && it.key.startsWith("pp") }
                        reload(); redraw() })
                } else if (i == 3) {
                    rows.add(lbl("Tap the image to add a point. Or rebuild the whole mesh:", 12f, C.DIM))
                    rows.add(gridStepper(reopen))
                    rows.add(btn("Rebuild mesh ($gridN×$gridN)", C.GREEN, C.BG) {
                        val go = { host.pushUndo(); buildGrid(l, gridN); reload(); redraw(); openToolSettings(3) }
                        if (hasKeys(l)) confirm("Rebuild mesh?", "This removes this layer's mesh keys.", go) else go() })
                } else {
                    rows.add(lbl("Tap a point to delete it. ${pp.pins.count()} points.", 12f, C.DIM))
                }
            } else rows.add(lbl("Tap an image layer on the canvas first.", 12f, C.DIM))
        }
        rows.add(btn("Done", C.GREEN, C.BG) { dismissSettings() })
        val c = card(rows)
        c.setBackgroundColor(0xF71C1C21.toInt())
        view.addSubview(c); settingsCard = c
        layoutRoot()
    }

    // ---- physics (pendulums)
    private fun startPreview() {
        if (previewTimer != null) return
        previewT0 = Editor.time
        val h = Handler(Looper.getMainLooper())
        val t = object : Runnable {
            override fun run() {
                var t2 = Editor.time + 1f / 30f
                if (t2 >= Editor.scene.duration) t2 = 0f
                Editor.time = t2; canvas.setNeedsDisplay()
                for (v in pendViews) v.setNeedsDisplay()
                h.postDelayed(this, 1000L / 30L)
            }
        }
        previewTick = t
        h.postDelayed(t, 1000L / 30L)
        previewTimer = h
    }
    private fun stopPreview() {
        val h = previewTimer ?: return
        previewTick?.let { h.removeCallbacks(it) }
        previewTimer = null; previewTick = null
        Editor.time = previewT0; canvas.setNeedsDisplay(); host.render()
    }

    private fun renamePhys(q: PhysGroup) {
        val a = com.saiki.motion.uikit.UIAlertController()
        a.title = "Rename"
        a.addTextField { it.text = q.name }
        a.addAction(com.saiki.motion.uikit.UIAlertAction("Cancel", com.saiki.motion.uikit.UIAlertActionStyle.cancel, null))
        a.addAction(com.saiki.motion.uikit.UIAlertAction("OK", com.saiki.motion.uikit.UIAlertActionStyle.default) {
            val t = a.textFields.firstOrNull()?.text ?: ""
            if (t.trim().isNotEmpty()) { host.pushUndo(); q.name = t; reloadPanel() } })
        a.showOver(this)
    }
    private fun dupPhys(q: PhysGroup) {
        host.pushUndo()
        val n = PhysGroup(rig.nextId, q.name + " copy"); rig.nextId += 1
        n.on = q.on; n.length = q.length; n.damping = q.damping; n.ease = q.ease; n.reaction = q.reaction
        n.follow = q.follow; n.strength = q.strength; n.maxDeg = q.maxDeg; n.weight = q.weight; n.gravity = q.gravity; n.delay = q.delay
        for (i in q.ins) { val c = PhysIn(i.paramId, i.influence); c.invert = i.invert; c.useRange = i.useRange; c.nmin = i.nmin; c.ncen = i.ncen; c.nmax = i.nmax; n.ins.add(c) }
        for (o in q.outs) { val c = PhysOut(o.paramId, o.scale); c.invert = o.invert; c.limit = o.limit; c.pend = o.pend; n.outs.add(c) }
        for (x in q.pends) { val c = PhysPend(); c.length = x.length; c.damping = x.damping; c.reaction = x.reaction; n.pends.add(c) }
        rig.phys.add(n); physSel = rig.phys.count() - 1; reloadPanel(); redraw()
    }

    private fun buildPhysics() {
        pendViews = emptyList()
        val on = previewTimer != null
        stack.add(btn(if (on) "■ Stop preview" else "▶ Preview physics", if (on) C.CARD2 else C.GREEN, if (on) C.TEXT else C.BG) {
            if (previewTimer != null) stopPreview() else { rig.phys.forEach { it.outs.forEach { o -> o.peak = 0f } }; startPreview() }
            reloadPanel()
        })
        stack.add(lbl("Nothing swings by itself. When an input parameter moves, the pendulum swings and drives the output parameters.", 12f, C.DIM))
        if (physSel >= rig.phys.count()) physSel = max(0, rig.phys.count() - 1)
        val gr = HStack()
        for ((i, q) in rig.phys.withIndex()) {
            val b = btn(q.name, if (i == physSel) C.GREEN else C.CARD2, if (i == physSel) C.BG else C.TEXT) { physSel = i; reloadPanel() }
            gr.add(b)
        }
        gr.add(btn("＋ New", C.GREEN, C.BG) { addPendulum() })
        stack.add(gr)
        stack.add(btn("Open pendulum editor (full screen)", C.GREEN, C.BG) {
            if (!rig.phys.indices.contains(physSel)) { host.toast("Tap ＋ New first"); return@btn }
            val vc = com.saiki.motion.ui.PhysicsScreenViewController(group, rig, rig.phys[physSel])
            vc.pushUndo = { host.pushUndo() }
            vc.onChange = { reloadPanel(); redraw() }
            present(vc, animated = true)
        })
        if (rig.phys.isEmpty()) stack.add(lbl("No physics groups yet. Tap ＋ New — add as many as you need (hair, ribbon, chest…).", 12f, C.DIM))
        else stack.add(chips(listOf("Input", "Model", "Output"), physTab) { i -> physTab = i; reloadPanel() })
        if (rig.phys.indices.contains(physSel)) {
            val q = rig.phys[physSel]
            val head = HStack()
            head.add(lbl(q.name, 15f, C.TEXT, bold = true)); head.add(spacer())
            head.add(toggleSw(q.on) { v -> host.pushUndo(); q.on = v; redraw() })
            head.add(iconBtn("pencil") { renamePhys(q) })
            head.add(iconBtn("plus.square.on.square") { dupPhys(q) })
            head.add(iconBtn("trash") {
                confirm("Delete ${q.name}?", "This physics group is removed.") {
                    host.pushUndo(); rig.phys.removeAll { it.id == q.id }
                    physSel = max(0, min(physSel, rig.phys.count() - 1)); reloadPanel(); redraw() } })
            val pv = PendulumView()
            pv.pg = q; pv.rig = rig; pv.groupId = groupId
            pv.onBegin = { host.pushUndo() }
            pv.onEdit = { end -> canvas.setNeedsDisplay(); if (end) { reloadPanel(); redraw() } }
            pendViews = pendViews + pv
            fun sl(n: String, lo: Float, hi: Float, v: Float, d: Int, set: (Float) -> Unit): UiView =
                slider(n, lo, hi, v, d) { x -> set(x); canvas.setNeedsDisplay(); pv.setNeedsDisplay() }
            val rows = ArrayList<UiView>()
            rows.add(head); rows.add(pv)
            when (physTab) {
                0 -> {   // INPUT — the cause
                    val tot = q.ins.fold(0f) { acc, it -> acc + it.influence }
                    rows.add(lbl("Inputs — what moves the pendulum. Total influence ${tot.toInt()}%" + if (tot > 100f) " (scaled down to 100%)" else "", 12f, if (tot > 100f) C.GREEN else C.DIM))
                    for (i in q.ins) {
                        val pr = rig.param(i.paramId)
                        val nm = pr?.name ?: "(missing)"
                        val hr = HStack()
                        hr.add(lbl(nm, 14f, C.GREEN, bold = true)); hr.add(spacer())
                        hr.add(iconBtn("trash") {
                            host.pushUndo(); q.ins.removeAll { it === i }; reloadPanel(); redraw() })
                        rows.add(hr)
                        rows.add(sl("Influence (%)", 0f, 100f, i.influence, 0) { i.influence = it })
                        rows.add(toggleRow("Invert input", i.invert) { v -> host.pushUndo(); i.invert = v; canvas.setNeedsDisplay() })
                        rows.add(toggleRow("Custom normalization", i.useRange) { v ->
                            host.pushUndo(); i.useRange = v
                            if (v && pr != null) { i.nmin = pr.lo; i.ncen = pr.def; i.nmax = pr.hi }
                            reloadPanel() })
                        if (i.useRange && pr != null) {
                            val lo = min(pr.lo, i.nmin); val hi = max(pr.hi, i.nmax)
                            rows.add(sl("Min", lo, hi, i.nmin, 1) { i.nmin = it })
                            rows.add(sl("Center", lo, hi, i.ncen, 1) { i.ncen = it })
                            rows.add(sl("Max", lo, hi, i.nmax, 1) { i.nmax = it })
                        }
                    }
                    rows.add(btn("＋ Add input parameter", C.CARD2, C.TEXT) { pickPhysParam(q, input = true) })
                }
                1 -> {   // MODEL — the pendulum
                    if (physPend > q.pends.count()) physPend = 0
                    val pn = (0..q.pends.count()).map { "Pendulum ${it + 1}" }
                    rows.add(chips(pn, physPend) { i -> physPend = i; reloadPanel() })
                    rows.add(btn("＋ Add pendulum (chains after #${q.pends.count() + 1})", C.CARD2, C.TEXT) {
                        host.pushUndo(); q.pends.add(PhysPend()); physPend = q.pends.count(); reloadPanel(); redraw() })
                    if (physPend == 0) {
                        rows.add(sl("Duration (short = snappy)", 0.1f, 2f, q.length, 2) { q.length = it })
                        rows.add(sl("Reaction time", 0f, 1f, q.reaction, 2) { q.reaction = it })
                        rows.add(sl("Convergence speed (damping)", 0f, 1f, q.damping, 2) { q.damping = it })
                    } else {
                        val pd = q.pends[physPend - 1]
                        rows.add(sl("Duration (short = snappy)", 0.1f, 2f, pd.length, 2) { pd.length = it })
                        rows.add(sl("Reaction time", 0f, 1f, pd.reaction, 2) { pd.reaction = it })
                        rows.add(sl("Convergence speed (damping)", 0f, 1f, pd.damping, 2) { pd.damping = it })
                        rows.add(btn("Delete this pendulum", C.CARD2, C.TEXT) {
                            host.pushUndo(); val k = physPend - 1; q.pends.removeAt(k)
                            for (o in q.outs) { if (o.pend == k + 1) o.pend = 0 else if (o.pend > k + 1) o.pend -= 1 }
                            physPend = 0; reloadPanel(); redraw() })
                    }
                    rows.add(sl("Ease of swinging", 0.5f, 0.99f, q.ease, 2) { q.ease = it })
                    rows.add(sl("Max angle (°)", 5f, 90f, q.maxDeg, 0) { q.maxDeg = it })
                    rows.add(sl("Gravity (pull to rest)", 0.1f, 3f, q.gravity, 2) { q.gravity = it })
                    rows.add(sl("Input delay (s)", 0f, 0.5f, q.delay, 2) { q.delay = it })
                    rows.add(sl("Inertia (input gain)", 0f, 4f, q.strength, 2) { q.strength = it })
                    rows.add(lbl("Tip: drag the weight in the diagram — farther = longer duration, sideways = bigger swing.", 11f, C.DIM))
                }
                else -> {  // OUTPUT — the effect
                    rows.add(lbl("Outputs — parameters the pendulum drives.", 12f, C.DIM))
                    for (o in q.outs) {
                        val nm = rig.param(o.paramId)?.name ?: "(missing)"
                        val pct = Math.round(o.peak * 100).toInt()
                        val hr = HStack()
                        hr.add(lbl(nm, 14f, C.GREEN, bold = true)); hr.add(spacer())
                        hr.add(lbl("Max $pct%", 12f, if (pct > 100) C.GREEN else C.DIM, bold = pct > 100))
                        hr.add(iconBtn("trash") {
                            host.pushUndo(); q.outs.removeAll { it === o }; reloadPanel(); redraw() })
                        rows.add(hr)
                        if (q.pends.isNotEmpty()) {
                            rows.add(chips((0..q.pends.count()).map { "P${it + 1}" }, min(o.pend, q.pends.count())) { i -> host.pushUndo(); o.pend = i; reloadPanel(); redraw() })
                        }
                        rows.add(sl("Scale", 0f, 3f, o.scale, 2) { o.scale = it })
                        rows.add(sl("Limit (%)", 10f, 100f, o.limit * 100f, 0) { o.limit = it / 100f })
                        rows.add(toggleRow("Reflect (invert)", o.invert) { v -> host.pushUndo(); o.invert = v; canvas.setNeedsDisplay() })
                        if (pct > 100) rows.add(lbl("Over 100% — lower Scale or Max angle so it stops hitting the limit.", 11f, C.GREEN))
                    }
                    rows.add(btn("＋ Add output parameter", C.CARD2, C.TEXT) { pickPhysParam(q, input = false) })
                }
            }
            stack.add(card(rows))
        }
    }

    private fun toggleSw(on: Boolean, change: (Boolean) -> Unit): SwitchRow {
        val sw = SwitchRow()
        sw.label = ""; sw.on = on; sw.onToggle = change
        sw.frame = CGRect(0f, 0f, 92f, 52f)
        return sw
    }

    private fun addPendulum() {
        if (rig.params.isEmpty()) { host.toast("Add a parameter first"); return }
        host.pushUndo()
        val q = PhysGroup(rig.nextId, "Physics ${rig.phys.count() + 1}"); rig.nextId += 1
        rig.phys.add(q)
        physTab = 0; physSel = rig.phys.count() - 1
        reloadPanel(); redraw()
        pickPhysParam(q, input = true)
    }

    private fun pickPhysParam(q: PhysGroup, input: Boolean) {
        val ps = rig.params
        ask(if (input) "Input parameter" else "Output parameter", ps.map { it.name }) { i ->
            host.pushUndo()
            if (input) q.ins.add(PhysIn(ps[i].id, if (q.ins.isEmpty()) 100f else 50f)) else q.outs.add(PhysOut(ps[i].id, 1f))
            reloadPanel(); redraw()
        }
    }

    // ---- warp deformer
    private fun buildWarp() {
        val ws = members().filter { it.deformer == 1 }
        val w = warpLayer
        val wp = w?.warp
        if (w == null || wp == null) {
            stack.add(lbl("No warp deformer yet. In the Layers tab tap “+ Warp Deformer”, then drag layers onto it.", 13f, C.DIM))
            stack.add(btn("Go to Layers", C.GREEN, C.BG) { curTab = 0; reload() })
            return
        }
        stack.add(btn("Deformer: ${w.name}  ▾") {
            ask("Warp deformer", ws.map { it.name }) { i -> selWarp = ws[i].id; selId = ws[i].id; reload() } })
        stack.add(lbl("Pick a pose above, then drag the green points on the canvas. Nearby points follow softly.", 12f, C.DIM))
        val r = HStack()
        r.add(lbl("Grid: ${wp.n}×${wp.n}", 14f, C.TEXT, bold = true)); r.add(spacer())
        r.add(iconBtn("minus") { setWarpN(w, wp.n - 1) })
        r.add(iconBtn("plus") { setWarpN(w, wp.n + 1) })
        stack.add(r)
        stack.add(slider("Soft drag (cells)", 0f, 3f, softR, 1) { v -> softR = v; canvas.softR = v })
        val row = HStack()
        row.add(btn("Fit to layers") {
            host.pushUndo(); fitWarp(w); redraw() })
        row.add(btn("Flatten this pose", C.CARD2, C.DIM) {
            val p = active ?: return@btn
            host.pushUndo()
            val pv = rig.value(p, group, Editor.time)
            for (b in rig.bindings) if (b.paramId == p.id && b.layerId == w.id) b.setKey(pv, 0f)
            reload(); redraw() })
        stack.add(row)
        stack.add(lbl("Layers inside get a mesh automatically. Tip: Rotate Deformers bend nothing — they spin their contents (Transform tab → Rotate).", 12f, C.DIM))
    }

    /// Re-lays the warp lattice on new lines (0...1), carrying every stored offset over by bilinear sampling of the old lattice.
    private fun remapWarp(w: Layer, wp: Warp, newU: List<Float>, newV: List<Float>) {
        val n = wp.n; val m = newU.count()
        fun isW(b: com.saiki.motion.core.RigBinding): Boolean = b.layerId == w.id && (b.key.startsWith("wx") || b.key.startsWith("wy"))
        val byParam = HashMap<Int, MutableList<com.saiki.motion.core.RigBinding>>()
        for (b in rig.bindings) if (isW(b)) { val m = byParam.get(b.paramId); if (m != null) m.add(b) else byParam.put(b.paramId, mutableListOf(b)) }
        val tables = ArrayList<Triple<RigParam, List<Float>, List<Pair<FloatArray, FloatArray>>>>()
        for ((pid, bs) in byParam) {
            val p = rig.param(pid) ?: continue
            val pvs = sortedSetOf(p.def)
            for (b in bs) for (k in b.keys) pvs.add(k.v)
            val rows = ArrayList<Pair<FloatArray, FloatArray>>()
            for (v in pvs.toList()) {
                val ox = FloatArray(n * n); val oy = FloatArray(n * n)
                for (b in bs) {
                    val k = b.key.drop(2).toIntOrNull()
                    if (k != null && k < n * n) { if (b.key.startsWith("wx")) ox[k] = b.eval(v) else oy[k] = b.eval(v) }
                }
                rows.add(Pair(ox, oy))
            }
            tables.add(Triple(p, pvs.toList(), rows))
        }
        rig.bindings.removeAll { isW(it) }
        val iu = newU.map { wp.index(it, v = false) }
        val iv = newV.map { wp.index(it, v = true) }
        wp.cu = newU.toMutableList(); wp.cv = newV.toMutableList(); wp.n = m
        fun samp(a: FloatArray, fu: Float, fv: Float): Float {
            val i0 = min(n - 2, fu.toInt()); val j0 = min(n - 2, fv.toInt()); val du = fu - i0.toFloat(); val dv = fv - j0.toFloat()
            return a[j0 * n + i0] * (1 - du) * (1 - dv) + a[j0 * n + i0 + 1] * du * (1 - dv)
                + a[(j0 + 1) * n + i0] * (1 - du) * dv + a[(j0 + 1) * n + i0 + 1] * du * dv
        }
        for ((p, pvs, rows) in tables) {
            for (b in 0 until m) for (a in 0 until m) {
                val k = b * m + a
                val xs = rows.map { samp(it.first, iu[a], iv[b]) }
                val ys = rows.map { samp(it.second, iu[a], iv[b]) }
                for ((key, vals) in listOf(Pair("wx$k", xs), Pair("wy$k", ys))) {
                    if (vals.any { abs(it) > 1e-6f }) {
                        val bd = rig.binding(p, w.id, key, create = true)
                        if (bd != null) for ((ri, v) in vals.withIndex()) bd.setKey(pvs[ri], v)
                    }
                }
            }
        }
        for (key in w.props.keys.filter { it.startsWith("wx") || it.startsWith("wy") }) w.props.remove(key)
    }

    private fun penAdd(w: Layer, ru: Float, rv: Float) {
        val wp = w.warp ?: return
        if (wp.n >= 12) { host.toast("Lattice is at its maximum (12×12)"); return }
        val n = wp.n
        val u = (0 until n).map { wp.lineU(it) }.toMutableList()
        val v = (0 until n).map { wp.lineV(it) }.toMutableList()
        if (u.any { abs(it - ru) < 0.03f } && v.any { abs(it - rv) < 0.03f }) { host.toast("A point is already there"); return }
        host.pushUndo()
        if (!u.any { abs(it - ru) < 0.03f }) { u.add(ru); u.sort() }
        if (!v.any { abs(it - rv) < 0.03f }) { v.add(rv); v.sort() }
        // keep the lattice square (n × n): if only one axis grew, add the other at the midpoint of its widest gap
        fun widest(a: List<Float>): Float { var bestI = 0; var bestD = 0f; for (i in 0 until a.size - 1) if (a[i + 1] - a[i] > bestD) { bestI = i; bestD = a[i + 1] - a[i] }; return (a[bestI] + a[bestI + 1]) / 2f }
        while (u.count() < v.count()) { u.add(widest(u)); u.sort() }
        while (v.count() < u.count()) { v.add(widest(v)); v.sort() }
        remapWarp(w, wp, u, v)
        reload(); redraw()
    }

    private fun penDel(w: Layer, k: Int) {
        val wp = w.warp ?: return
        val n = wp.n; val i = k % n; val j = k / n
        if (i == 0 || j == 0 || i == n - 1 || j == n - 1) { host.toast("Edge points can't be removed"); return }
        host.pushUndo()
        val u = (0 until n).map { wp.lineU(it) }.toMutableList()
        val v = (0 until n).map { wp.lineV(it) }.toMutableList()
        u.removeAt(i); v.removeAt(j)
        remapWarp(w, wp, u, v)
        reload(); redraw()
    }

    private fun setWarpN(w: Layer, n: Int) {
        val wp = w.warp ?: return
        val m = min(8, max(2, n)); if (m == wp.n) return
        host.pushUndo(); wp.n = m; wp.cu.clear(); wp.cv.clear()
        rig.bindings.removeAll { it.layerId == w.id && (it.key.startsWith("wx") || it.key.startsWith("wy")) }
        reload(); redraw()
    }

    // ---- mesh
    private fun buildMesh() {
        val imgs = members().filter { it.type == LayerType.IMAGE }
        if (imgs.isEmpty()) { stack.add(lbl("Import an image layer into this rig first.", 13f, C.DIM)); return }
        val l = sel
        if (l == null || l.type != LayerType.IMAGE) {
            stack.add(lbl("Select an image layer: tap it in the canvas or pick it here.", 13f, C.DIM))
            stack.add(btn("Pick layer  ▾") { pickLayer(imgs) })
            return
        }
        stack.add(btn("Layer: ${l.name}  ▾") { pickLayer(imgs) })
        stack.add(gridStepper { _ -> reload() })
        val pp = l.puppet
        if (pp == null || pp.pins.isEmpty()) {
            stack.add(btn("Create mesh ($gridN×$gridN points)", C.GREEN, C.BG) {
                host.pushUndo(); buildGrid(l, gridN); reload(); redraw() })
            return
        }
        stack.add(btn("Rebuild with $gridN×$gridN points") {
            val go = { host.pushUndo(); buildGrid(l, gridN); reload(); redraw() }
            if (hasKeys(l)) confirm("Rebuild mesh?", "This removes this layer's mesh keys.", go) else go()
        })
        stack.add(toggleRow("Show mesh", pp.showMesh) { v -> pp.showMesh = v; redraw() })
        stack.add(detailChips(pp))
        stack.add(chips(listOf("Move", "Paint", "Add", "Delete"), tool) { i -> tool = i; reload() })
        val tips = listOf("Drag a point to move it.", "Paint: drag over the image; points inside the brush circle follow your finger.",
            "Tap the image to add a point there (it starts pinned until you move it at a pose).", "Tap a point to delete it.")
        stack.add(lbl(tips[tool], 12f, C.DIM))
        if (tool == 1) brushSection()
        stack.add(slider("Softness (falloff)", 0.5f, 6f, pp.stiffness, 1) { v -> pp.stiffness = v; redraw() })
        val row = HStack()
        row.add(btn("Clear keys of this parameter") {
            val p = active ?: return@btn
            host.pushUndo()
            rig.bindings.removeAll { it.paramId == p.id && it.layerId == l.id && it.key.startsWith("pp") }
            reload(); redraw() })
        row.add(btn("Remove mesh", C.CARD2, C.DIM) {
            host.pushUndo()
            rig.bindings.removeAll { it.layerId == l.id && it.key.startsWith("pp") }
            l.puppet = null; reload(); redraw() })
        stack.add(row)
    }

    private fun pickLayer(imgs: List<Layer>) {
        ask("Layer", imgs.map { it.name }) { i -> selId = imgs[i].id; reload() }
    }

    private fun addPin(l: Layer, rx: Float, ry: Float) {
        val pu = l.puppet ?: return
        host.pushUndo()
        pu.pins.add(PuppetPin(pu.nextId, rx, ry)); pu.nextId += 1
        reload(); redraw()
    }

    private fun delPin(l: Layer, pin: PuppetPin) {
        val pu = l.puppet
        if (pu == null || pu.pins.count() <= 1) { host.toast("A mesh needs at least one point"); return }
        host.pushUndo()
        pu.pins.removeAll { it.id == pin.id }
        rig.bindings.removeAll { it.layerId == l.id && (it.key == "pp${pin.id}x" || it.key == "pp${pin.id}y") }
        reload(); redraw()
    }

    // ---- transform (opacity / position / rotate / scale — all keyed at the pose above)
    /// Time keyframes for the selected layer (and its puppet pins): tap a name to key / unkey at the playhead,
    /// hold a ruler to type a value, Graph opens the curve editor.
    private fun buildTimelineKeys(l: Layer) {
        stack.add(lbl("Timeline keyframes (at the playhead)", 14f, C.TEXT, bold = true))
        stack.add(lbl("Move the playhead, drag a ruler (or hold it to type a value). Tap a name to add / remove a key.", 12f, C.DIM))
        val rows = propList.toMutableList()
        val pp = l.puppet
        if (pp != null) for (pin in pp.pins) { rows.add(Pair("Mesh pin ${pin.id}x", "pp${pin.id}x")); rows.add(Pair("Mesh pin ${pin.id}y", "pp${pin.id}y")) }
        val t = Editor.time
        for ((name, key) in rows) {
            val tr = l.track(key)
            val s = slider(name, -4f, 4f, tr.eval(t), if (key == "rotZ") 1 else 3) { v ->
                l.track(key).set(Editor.time, v, host.autoKey())
                redraw(); host.render()
            }
            s.canKey = true; s.infinite = true; s.span = if (key == "rotZ") 180f else 2f
            s.hasKey = tr.keyAt(t) != null; s.hasAnim = tr.keys.isNotEmpty()
            s.onLabelTap = {
                host.pushUndo()
                val tk = l.track(key)
                if (tk.keyAt(Editor.time) != null) tk.keys.removeAll { abs(it.t - Editor.time) < 0.02f }
                else tk.set(Editor.time, tk.eval(Editor.time), true)
                reloadPanel(); redraw(); host.render()
            }
            stack.add(s)
        }
        stack.add(btn("Open graph editor  ▸") {
            val animated = rows.filter { l.track(it.second).keys.count() >= 2 }
            if (animated.isEmpty()) { host.toast("Add two keys to a property first (tap its name)"); return@btn }
            ask("Graph which property?", animated.map { it.first }) { i ->
                val key = animated[i].second
                dismiss(animated = true) { host.onKeyTap(l, key, 0) }
            }
        })
    }

    private fun buildTransform() {
        val ms = members()
        if (ms.isEmpty()) { stack.add(lbl("Import a layer into this rig first.", 13f, C.DIM)); return }
        val l = sel
        if (l == null) {
            stack.add(lbl("Select a layer: tap it in the canvas or pick it here.", 13f, C.DIM))
            stack.add(btn("Pick layer  ▾") { pickLayer(ms) })
            return
        }
        stack.add(btn("Layer: ${l.name}  ▾") { pickLayer(ms) })
        val p = active
        if (p == null) { stack.add(lbl("Add a parameter above first.", 13f, C.DIM)); return }
        stack.add(lbl("Everything here is saved as a key at the pose above. Values are changes (+/−) from the normal pose.", 12f, C.DIM))
        val pv = rig.value(p, group, Editor.time)
        for ((name, key) in propList) {
            val r = propRange(key)
            val cur = rig.binding(p, l.id, key, create = false)?.eval(pv) ?: 0f
            stack.add(slider(name, r.first, r.second, cur, if (key == "rotZ") 1 else 2) { v ->
                val now = rig.value(p, group, Editor.time)
                rig.binding(p, l.id, key, create = true)?.setKey(now, v)
                refreshKeyState(); redraw()
            })
        }
        buildTimelineKeys(l)
        stack.add(lbl("Rotation pivot: drag the cyan dot in the canvas.", 12f, C.DIM))
        stack.add(btn("Reset pivot to center") {
            host.pushUndo(); host.setAnchorKeepVisual(l, 50f, 50f); redraw() })
    }

    // MARK: layer tree cells (data source + drag & drop twin)

    private fun cellFor(row: Pair<Layer, Int>): com.saiki.motion.uikit.UITableViewCell {
        val (l, d) = row
        val c = RigRowCell()
        val box = isContainer(l); val on = l.id == selId
        c.indent = 6f + d * 16f
        c.chev.isHidden = !box
        c.chev.icon = if (collapsed.contains(l.id)) "chev_right" else "chev_down"
        c.chev.setNeedsDisplay()
        val ic = if (l.deformer == 1) "grid" else (if (l.deformer == 2) "rotate" else (if (box) "folder" else "media"))
        c.icon.set(if (l.deformer != 0) C.GREEN else C.DIM, ic)
        c.name.text = l.name; c.name.textColor = argbToUIColor(if (on) C.GREEN else C.TEXT)
        c.name.font = com.saiki.motion.uikit.UIFont.systemFont(14f, if (on) 700 else 0)
        c.contentView.setBackgroundColor(if (on) C.CARD else android.graphics.Color.TRANSPARENT)
        c.eye.icon = if (l.visible) "eye" else "eye_off"
        c.eye.setNeedsDisplay()
        c.onChev = {
            if (collapsed.contains(l.id)) collapsed.remove(l.id) else collapsed.add(l.id)
            rebuildTree()
        }
        c.onEye = { l.visible = !l.visible; rebuildTree(); redraw() }
        c.onMore = { layerMenu(l) }
        c.onDragRow = { cell, y, ended ->
            if (ended) performDrag(cell, y) else dragId = l.id
        }
        return c
    }

    /** iOS performDropWith twin: move the dragged row into / after the row under the finger. */
    private fun performDrag(cell: RigRowCell, y: Float) {
        val dl = layer(dragId)
        dragId = -1
        if (dl == null) return
        val idx = (y / 38f).toInt().coerceIn(0, (treeRows.size - 1).coerceAtLeast(0))
        var par = groupId
        var after: Layer? = null
        if (treeRows.indices.contains(idx)) {
            val t = treeRows[idx].first
            if (isContainer(t) && !isInside(t, dl)) par = t.id
            else { par = t.parentId; after = t }
        }
        if (isInside(layer(par), dl)) return
        host.pushUndo()
        dl.parentId = par
        val a = after
        if (a != null && a.id != dl.id) {                      // list shows front-most first, so "above" = later in array
            Editor.scene.layers.removeAll { it.id == dl.id }
            val i = Editor.scene.layers.indexOfFirst { it.id == a.id }
            if (i >= 0) Editor.scene.layers.add(i + 1, dl) else Editor.scene.layers.add(dl)
        }
        collapsed.remove(par)
        prepareWarps(dl)
        reload(); redraw()
    }
}
