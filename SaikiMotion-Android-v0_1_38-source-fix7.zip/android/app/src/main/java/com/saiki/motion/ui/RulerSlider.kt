@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import android.os.Handler
import android.os.Looper
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIAlertController
import com.saiki.motion.uikit.UIControl
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.currentActivity
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow

// Port of Sources/UI/RulerSlider.swift — the scrolling-ruler value control used for every parameter.
// Drag horizontally to change the value, tap the label to toggle a keyframe, hold still to type
// an exact number (promptValue via UIAlertController shim).
class RulerSlider : UIControl(com.saiki.motion.uikit.appContext!!) {
    var label = ""
    var lo: Float = 0f
    var hi: Float = 1f
    var value: Float = 0f
    var dec = 2
    var hasKey = false
    var hasAnim = false
    var canKey = true
    var onChange: ((Float) -> Unit)? = null
    var onBeginDrag: (() -> Unit)? = null
    var onLabelTap: (() -> Unit)? = null
    var onLabelLong: (() -> Unit)? = null
    var onKeyTap: (() -> Unit)? = null
    private var onKey = false
    var hasExpr = false
    var infinite = false
    var span: Float = 1f
    var onExprIcon: (() -> Unit)? = null
    var rowSelected = false

    private var onIcon = false
    private var longFired = false
    private var raw: Float = 0f
    private var downX: CGFloat = 0f
    private var lastX: CGFloat = 0f
    private var dragging = false
    private var onLabel = false
    private var longWork: Runnable? = null
    private val handler = Handler(Looper.getMainLooper())

    private fun fmt(v: Float): String {
        val q: Float = if (abs(v) < 0.5f * 10f.pow(-dec.toFloat())) 0f else v
        return String.format(Locale.US, "%." + dec + "f", q)
    }

    /** Hold-to-type: every ruler slider lets you enter an exact number. */
    fun promptValue() {
        val act = currentActivity?.get() ?: return
        val a = UIAlertController(act, label, if (infinite) null else "Range ${fmt(lo)} to ${fmt(hi)}")
        a.addTextField { tf ->
            tf.text = fmt(value)
            tf.numeric = true
        }
        a.addAction(com.saiki.motion.uikit.UIAlertAction("Cancel", com.saiki.motion.uikit.UIAlertActionStyle.cancel, null))
        a.addAction(com.saiki.motion.uikit.UIAlertAction("Set", com.saiki.motion.uikit.UIAlertActionStyle.default) {
            val txt = (a.textFields.firstOrNull()?.text ?: "").replace(",", ".").trim()
            var v = txt.toFloatOrNull() ?: return@UIAlertAction
            if (!infinite) v = v.coerceIn(lo, hi)
            if (dec == 0) v = kotlin.math.round(v)
            onBeginDrag?.invoke()
            value = v; raw = v
            onChange?.invoke(v)
            setNeedsDisplay()
        })
        a.present()
    }

    private val k: CGFloat get() = Dev.k
    private val bw: CGFloat get() = boundsRect.width / k
    private val bh: CGFloat get() = boundsRect.height / k
    private fun loc(t: UITouch): CGPoint { val p = t.location(this); return CGPoint(p.x / k, p.y / k) }
    private fun labelW(): CGFloat = bw * 0.36f
    private fun ppu(): CGFloat {
        // guard: a degenerate range (min == max) must not divide by zero
        val range = if (infinite) max(span, 0.001f) else max(hi - lo, 0.001f)
        return (bw - labelW()) / (range * 0.6f)
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = bw; val h = bh
        c.scaleBy(k, k)
        val bd = CGRect(0f, 0f, w, h)
        fillRoundRect(c, bd, 10f, C.CARD)
        if (hasExpr) {
            // expression on: outline fades orange → red
            c.saveGState()
            c.addPath(com.saiki.motion.uikit.CGPath.roundedRect(bd.insetBy(1.5f, 1.5f), 10f, 10f))
            c.setLineWidth(3f)
            c.setStrokeColor(0xFFFF6A2A.toInt()); c.strokePath()
            c.restoreGState()
        } else if (rowSelected) {
            strokeRoundRect(c, bd.insetBy(1f, 1f), 10f, 2f, C.GREEN)
        }

        val lw = labelW()
        drawText(label, 14f, h / 2 + 5f, color = if (hasExpr) 0xFFFF6A2A.toInt() else C.TEXT, size = 15f, bold = true, align = NSTextAlignment.left)
        if (canKey) {
            Icons.draw(c, if (hasKey) "diamond_f" else "diamond", lw - 18f, 18f, 16f,
                       if (hasKey) C.GREEN else 0xFF7A7A84.toInt())
        }

        // ruler
        val cxv = lw + (w - lw) / 2
        val ppuVal = ppu()
        c.saveGState()
        c.clip(CGRect(lw, 0f, w - lw, h))
        val range = if (infinite) span else hi - lo
        val rawStep = range * 0.1f
        val mag = 10f.pow(floor(log10(rawStep.toDouble())).toFloat())
        val f = rawStep / mag
        val nice: Float = if (f < 1.5f) 1f else (if (f < 3.5f) 2f else (if (f < 7.5f) 5f else 10f))
        val major = nice * mag
        val minor = major / 5
        val k0 = ceil(((value - (cxv - lw) / ppuVal) / minor).toDouble()).toInt()
        val k1 = floor(((value + (w - cxv) / ppuVal) / minor).toDouble()).toInt()
        if (k1 >= k0) {
            for (kk in k0..k1) {
                val v = kk * minor
                if (v < lo - 0.0001f || v > hi + 0.0001f) continue
                val x = cxv + (v - value) * ppuVal
                val isMajor = kk % 5 == 0
                val top = if (isMajor) h - 18f else h - 11f
                strokeLine(c, x, top, x, h - 4f, 1.2f, 0xFF6B6B75.toInt())
                if (isMajor) {
                    val s = String.format(Locale.US, if (major >= 1f) "%.0f" else "%.1f", v)
                    drawText(s, x, h - 22f, color = 0xFF8C8C96.toInt(), size = 11f, bold = false, align = NSTextAlignment.center)
                }
            }
        }
        // boundary markers at min and max
        val xl = cxv + (lo - value) * ppuVal
        val xh = cxv + (hi - value) * ppuVal
        if (xl >= lw && xl <= w) strokeLine(c, xl, 8f, xl, h - 4f, 2f, 0xFFFFFFFF.toInt())
        if (xh >= lw && xh <= w) strokeLine(c, xh, 8f, xh, h - 4f, 2f, 0xFFFFFFFF.toInt())
        // centre line
        strokeLine(c, cxv, 30f, cxv, h, 2f, C.GREEN)
        c.restoreGState()

        // value bubble
        val s = fmt(value)
        val bbw = max(44f, measureText(s, 15f, true) + 20f)
        val r = CGRect(cxv - bbw / 2, 6f, bbw, 28f)
        fillRoundRect(c, r, 8f, C.GREEN)
        drawText(s, cxv, 26f, color = C.ONDARK, size = 15f, bold = true, align = NSTextAlignment.center)
    }

    override fun touchesBegan(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val pt = loc(t)
        downX = pt.x; lastX = pt.x; dragging = false
        onLabel = pt.x < labelW()
        onIcon = onLabel && onExprIcon != null && pt.x > labelW() - 42 && pt.y > bh * 0.45f
        onKey = onLabel && onKeyTap != null && canKey && pt.x > labelW() - 44 && pt.y < bh * 0.5f
        if (onKey) onIcon = false
        longFired = false
        raw = value
        if (!onLabel) {
            onBeginDrag?.invoke()
            disallowParentScrollInterception(this, true)
            // hold still on the ruler → type an exact value
            longWork = Runnable {
                if (!dragging) { longFired = true; promptValue() }
            }
            handler.postDelayed(longWork!!, 550)
        } else if (!onIcon && !onKey) {
            longWork = Runnable {
                if (!dragging) {
                    longFired = true
                    val f = onLabelLong
                    if (f != null) f() else promptValue()
                }
            }
            handler.postDelayed(longWork!!, 450)
        }
    }

    override fun touchesMoved(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val x = loc(t).x
        if (onLabel) return
        if (abs(x - downX) > 4) dragging = true
        val dx = x - lastX
        lastX = x
        raw = raw - dx / ppu()
        if (!infinite) raw = raw.coerceIn(lo, hi)
        val v = if (dec == 0) kotlin.math.round(raw) else raw
        if (v != value) { value = v; onChange?.invoke(v); setNeedsDisplay() }
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull()
        if (t == null) {
            longWork?.let { handler.removeCallbacks(it) }; longWork = null
            disallowParentScrollInterception(this, false)
            return
        }
        val x = loc(t).x
        longWork?.let { handler.removeCallbacks(it) }; longWork = null
        if (onKey && abs(x - downX) < 12) onKeyTap?.invoke()
        else if (onIcon && abs(x - downX) < 10) onExprIcon?.invoke()
        else if (onLabel && !longFired && abs(x - downX) < 8) onLabelTap?.invoke()
        disallowParentScrollInterception(this, false)
    }

    override fun touchesCancelled(touches: Set<UITouch>, event: UIEvent?) {
        longWork?.let { handler.removeCallbacks(it) }; longWork = null
        disallowParentScrollInterception(this, false)
    }
}
