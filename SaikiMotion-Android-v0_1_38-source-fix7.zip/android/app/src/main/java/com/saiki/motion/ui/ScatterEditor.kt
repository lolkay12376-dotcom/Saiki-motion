@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/ScatterEditor.swift — full-screen Scatter editor. One scatter GROUP = every
// model in the scatter list: they share a target surface, a master frequency and an overlap-avoid
// switch; each model keeps its own frequency, count, scale, rotation, filters, noise clumps and
// animation. Settings are the same x3s "sc*" keys the renderer already reads.

package com.saiki.motion.ui

import android.os.Handler
import android.os.Looper
import com.saiki.motion.app.Dlg
import com.saiki.motion.app.EditorViewController
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UISwitch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.measureText
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class ScatterEditor(private val host: EditorViewController) : UiView(appContext!!) {

    private var sel = -1
    private val accent = 0xFFFF8C14.toInt()
    private val panel = UiView(appContext!!)
    private val chips = UiView(appContext!!)
    private val chipScroll = UIScrollView(appContext!!)
    private val top = UiView(appContext!!)
    private val scroll = UIScrollView(appContext!!)
    private val stack = UiView(appContext!!)
    private val titleL = UILabel(appContext!!)
    private val closeBtn = PillButton("✕", null, C.CARD2, C.TEXT)
    private val peekBtn = PillButton("Hold: peek", null, 0x00000000.toInt(), 0xFFFF8C14.toInt())
    private var renderPending = false
    private val renderHandler = Handler(Looper.getMainLooper())

    companion object {
        fun present(host: EditorViewController, view: UiView, select: Int) {
            if (view.subviews.any { it is ScatterEditor }) return
            val v = ScatterEditor(host)
            v.sel = select
            view.addSubview(v)
            v.frame = CGRect(0f, 0f, view.rectWidth(), view.rectHeight())
        }
    }

    init {
        setBackgroundColor(0xFF0F0F0F.toInt())
        addSubview(panel)
        titleL.text = "Scatter editor"; titleL.textColor = UIColor.white; titleL.font = UIFont.boldSystemFont(18f)
        titleL.frame = CGRect(0f, 0f, 200f, 24f)
        closeBtn.onClick = { removeFromSuperview() }
        peekBtn.onClick = { setPeek(!peekOn) }
        panel.addSubview(titleL); panel.addSubview(closeBtn); panel.addSubview(peekBtn)
        chipScroll.showsHorizontalScrollIndicator = false
        chipScroll.addSubview(chips)
        panel.addSubview(chipScroll)
        panel.addSubview(top)
        scroll.addSubview(stack)
        panel.addSubview(scroll)
        rebuild()
    }

    private var peekOn = false

    private fun setPeek(on: Boolean) {
        peekOn = on
        panel.alpha = if (on) 0f else 1f
        panel.isHidden = false
        if (on) {
            // keep the panel present but fully transparent so coming back works
            panel.alpha = 0.05f
        }
    }

    private val members: List<Layer>
        get() = Editor.scene.layers.filter { it.type == LayerType.MODEL && it.xf("scList", 0f) > 0.5f }

    private val cur: Layer? get() = members.firstOrNull { it.id == sel }

    private fun apply(f: (Layer) -> Unit) = members.forEach(f)

    private fun rerender(now: Boolean = false) {
        if (now) { host.render(); renderPending = false; return }
        renderPending = true
        renderHandler.postDelayed({
            if (renderPending) { renderPending = false; host.render() }
        }, 120)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth(); val h = rectHeight()
        if (w < 10 || h < 10) return
        val top = safeAreaInsets.top
        titleL.frame = CGRect(16f, top + 8f, 180f, 24f)
        peekBtn.frame = CGRect(w - 220f, top + 4f, 108f, 28f)
        closeBtn.frame = CGRect(w - 56f, top + 4f, 32f, 28f)
        panel.frame = CGRect(0f, top + 40f, w, h - top - 40f)
        layoutTop(panel.rectWidth())
        chipScroll.frame = CGRect(0f, topH, panel.rectWidth(), 40f)
        layoutChips()
        scroll.frame = CGRect(0f, topH + 48f, panel.rectWidth(), panel.rectHeight() - topH - 48f)
        layoutStack()
    }

    private var topH = 0f

    private fun layoutTop(w: Float) {
        var y = 0f
        for (v in top.subviews) {
            val hgt = v.rectHeight().takeIf { it > 0f } ?: 40f
            v.frame = CGRect(16f, y, max(w - 32f, 10f), hgt)
            y += hgt + 8f
        }
        topH = y
        top.frame = CGRect(0f, 0f, w, y)
    }

    private fun layoutChips() {
        var x = 0f
        for (c in chips.subviews) {
            val cw = c.rectWidth().takeIf { it > 0f } ?: 90f
            c.frame = CGRect(x, 4f, cw, 32f)
            x += cw + 8f
        }
        chips.frame = CGRect(0f, 0f, max(x, chipScroll.rectWidth()), 40f)
        chipScroll.contentSize = CGSize(max(x, chipScroll.rectWidth()), 40f)
    }

    private fun layoutStack() {
        var y = 4f
        for (v in stack.subviews) {
            val hgt = v.rectHeight().takeIf { it > 0f } ?: 40f
            v.frame = CGRect(16f, y, max(scroll.rectWidth() - 32f, 10f), hgt)
            y += hgt + 10f
        }
        stack.frame = CGRect(0f, 0f, scroll.rectWidth(), y + 40f)
        scroll.contentSize = CGSize(scroll.rectWidth(), y + 40f)
    }

    // MARK: build

    private fun rebuild() {
        if (cur == null) sel = members.firstOrNull()?.id ?: -1
        // chips
        chips.subviews.toList().forEach { it.removeFromSuperview() }
        var x = 0f
        for (o in members) {
            val b = PillButton(o.name + (if (o.xf("scOn", 0f) > 0.5f) "" else " (off)"), null,
                if (o.id == sel) accent else 0xFF2E2E2E.toInt(), if (o.id == sel) 0xFF000000.toInt() else C.TEXT)
            b.textSize = 14f
            b.onClick = { sel = o.id; rebuild() }
            chips.addSubview(b)
            val cw = measureText(b.text, 14f, true) + 28f
            b.frame = CGRect(x, 4f, cw, 32f)
            x += cw + 8f
        }
        val free = Editor.scene.layers.filter { it.type == LayerType.MODEL && it.xf("scList", 0f) < 0.5f }
        val add = PillButton("+ Add model", null, 0x00000000.toInt(), accent)
        add.textSize = 14f
        add.onClick = {
            if (free.isEmpty()) { Dlg(host).setTitle("").setItems(listOf("No other 3D models in the project")) { _, _ -> }.show() }
            else Dlg(host).setTitle("Add model").setItems(free.map { it.name }) { _, i -> addToGroup(free[i]) }.show()
        }
        chips.addSubview(add)
        add.frame = CGRect(x, 4f, measureText("+ Add model", 14f, true) + 28f, 32f)
        // group header
        top.subviews.toList().forEach { it.removeFromSuperview() }
        val first = members.firstOrNull()
        if (first != null) {
            top.addSubview(head("Group · ${members.count()} model${if (members.count() == 1) "" else "s"}"))
            top.addSubview(slider("Group frequency", first.xf("scMaster", 1f), 0f, 3f, "%.2f×") { v ->
                apply { it.xset("scMaster", v) }; rerender()
            })
            top.addSubview(toggle("Models avoid each other", first.xf("scAvoid", 0f) > 0.5f) { v ->
                apply { it.xset("scAvoid", if (v) 1f else 0f) }; rerender(now = true)
            })
        }
        // body
        stack.subviews.toList().forEach { it.removeFromSuperview() }
        val l = cur
        if (l == null) {
            stack.addSubview(note("No scatter models yet. Tap \"+ Add model\" to put a 3D model in the group (or select a model in Scene 3D and use Add to scatter list)."))
            layoutSubviews()
            return
        }
        build(l)
        layoutSubviews()
    }

    private fun addToGroup(m: Layer) {
        host.pushUndo()
        val ref = members.firstOrNull()
        m.xset("scList", 1f); m.xset("scOn", 1f)
        m.xset("scTarget", ref?.xf("scTarget", -3f) ?: -3f)
        for (k in listOf("scGroundSize", "scGroundY", "scAirH", "scMaster", "scAvoid")) {
            if (ref != null && ref.xf(k, -9999f) != -9999f) m.xset(k, ref.xf(k, 0f))
        }
        if (m.xf("scCount", 0f) == 0f) m.xset("scCount", 30f)
        m.xset("scSeed", Random.nextInt(1, 1000).toFloat())
        sel = m.id; rebuild(); rerender(now = true)
    }

    private fun build(l: Layer) {
        fun f(n: String, k: String, lo: Float, hi: Float, d: Float, fmt: String = "%.2f") {
            stack.addSubview(slider(n, l.xf(k, d), lo, hi, fmt) { v -> l.xset(k, v); rerender() })
        }
        fun t(n: String, k: String) {
            stack.addSubview(toggle(n, l.xf(k, 0f) > 0.5f) { v -> l.xset(k, if (v) 1f else 0f); rerender(now = true) })
        }
        // target surface (shared by the group)
        stack.addSubview(head("Surface"))
        val tv = l.xf("scTarget", -1f).toInt()
        val tgts = Editor.scene.layers.filter { t ->
            (t.type == LayerType.MODEL || t.type == LayerType.CAMERA || t.is3d) &&
                !members.any { m -> m === t } && !(t.imagePath ?: "").lowercase().endsWith(".vdb")
        }
        val curName = when (tv) {
            -2 -> "Ground plane"
            -3 -> "Air (random volume)"
            else -> Editor.scene.layers.firstOrNull { it.id == tv }?.name ?: "None"
        }
        val opts = listOf("Ground plane" to -2, "Air (random volume)" to -3) + tgts.map { it.name to it.id }
        stack.addSubview(menuButton("Target: $curName", opts))
        if (tv == -2 || tv == -3) {
            fun g(n: String, k: String, lo: Float, hi: Float, d: Float, fmt: String) {
                stack.addSubview(slider(n, l.xf(k, d), lo, hi, fmt) { v -> apply { it.xset(k, v) }; rerender() })
            }
            if (tv == -3) g("Air height", "scAirH", 0.5f, 30f, 4f, "%.1f")
            g("Area size", "scGroundSize", 1f, 120f, 10f, "%.0f")
            g(if (tv == -3) "Air centre height" else "Ground height", "scGroundY", -5f, 5f, 0f, "%.2f")
        }
        t("Scatter on", "scOn"); t("Keep the original model too", "scKeep")
        stack.addSubview(head("Amount · frequency"))
        f("Frequency (this model)", "scFreq", 0f, 3f, 1f, "%.2f×")
        f("Count", "scCount", 1f, 3000f, 60f, "%.0f")
        f("Seed", "scSeed", 1f, 999f, 1f, "%.0f")
        f("Jitter", "scJitter", 0f, 1f, 0f)
        stack.addSubview(button("Re-roll seed") {
            host.pushUndo()
            l.xset("scSeed", Random.nextInt(1, 1000).toFloat())
            rerender(now = true); rebuild()
        })
        stack.addSubview(head("Distribution"))
        stack.addSubview(segment(listOf("Random", "Even spacing"), l.xf("scMode", 0f).toInt()) { i -> l.xset("scMode", i.toFloat()); rerender(now = true) })
        f("Minimum distance", "scMinDist", 0.01f, 3f, 0.2f)
        stack.addSubview(head("Scale"))
        f("Scale", "scScale", 0.02f, 4f, 1f)
        f("Random scale", "scScaleRnd", 0f, 1f, 0.3f)
        f("Squash / stretch", "scSquash", 0f, 1f, 0f)
        stack.addSubview(head("Rotation"))
        f("Align to surface", "scAlign", 0f, 1f, 1f)
        f("Random yaw", "scYaw", 0f, 360f, 360f, "%.0f")
        f("Random tilt", "scTilt", 0f, 90f, 0f, "%.0f")
        f("Offset X", "scRotX", -180f, 180f, 0f, "%.0f")
        f("Offset Y", "scRotY", -180f, 180f, 0f, "%.0f")
        f("Offset Z", "scRotZ", -180f, 180f, 0f, "%.0f")
        stack.addSubview(head("Placement"))
        f("Lift along normal", "scLift", -2f, 2f, 0f)
        f("Random lift", "scLiftRnd", 0f, 2f, 0f)
        t("Flip surface normals", "scFlip")
        stack.addSubview(head("Filters"))
        f("Min slope", "scSlopeMin", 0f, 180f, 0f, "%.0f")
        f("Max slope", "scSlopeMax", 0f, 180f, 180f, "%.0f")
        f("Min height", "scHMin", -20f, 20f, -10f)
        f("Max height", "scHMax", -20f, 20f, 10f)
        stack.addSubview(head("Noise mask (clumps)"))
        f("Noise scale", "scNoiseScale", 0.2f, 30f, 3f)
        f("Noise threshold", "scNoiseThr", 0f, 1f, 0f)
        stack.addSubview(head("Animation"))
        f("Grow-in duration (s)", "scGrow", 0f, 5f, 0f)
        f("Grow stagger", "scStagger", 0f, 1f, 0.5f)
        f("Sway angle", "scSway", 0f, 30f, 0f, "%.1f")
        f("Sway speed", "scSwaySpeed", 0f, 4f, 1f)
        stack.addSubview(button("Reset this model's scatter settings") {
            host.pushUndo()
            l.x3s = l.x3s.split(";").filter { !it.startsWith("sc") || it.startsWith("scList") || it.startsWith("scTarget") || it.startsWith("scOn") }.joinToString(";")
            rerender(now = true); rebuild()
        })
        val rm = button("Remove from group") {
            host.pushUndo(); l.xset("scList", 0f); l.xset("scOn", 0f)
            rerender(now = true); sel = -1; rebuild()
        }
        stack.addSubview(rm)
    }

    // MARK: widgets

    private fun head(t: String): UILabel {
        val l = UILabel(appContext!!)
        l.text = t.uppercase(Locale.US); l.font = UIFont.boldSystemFont(12f); l.textColor = UIColor(accent)
        l.frame = CGRect(0f, 0f, 200f, 18f)
        return l
    }

    private fun note(t: String): UILabel {
        val l = UILabel(appContext!!)
        l.text = t; l.font = UIFont.systemFont(13f); l.textColor = UIColor(0xFF9E9E9E.toInt()); l.numberOfLines = 0
        l.frame = CGRect(0f, 0f, 280f, 80f)
        return l
    }

    private fun button(t: String, f: () -> Unit): PillButton {
        val b = PillButton(t, null, 0xFF2E2E2E.toInt(), C.TEXT)
        b.onClick = { f() }
        b.frame = CGRect(0f, 0f, 240f, 42f)
        return b
    }

    private fun menuButton(t: String, opts: List<Pair<String, Int>>): PillButton {
        val b = PillButton("$t  ▾", null, 0x59FF8C14.toInt(), C.TEXT)
        b.onClick = {
            Dlg(host).setTitle("Target").setItems(opts.map { it.first }) { _, i ->
                host.pushUndo(); apply { it.xset("scTarget", opts[i].second.toFloat()) }
                rerender(now = true); rebuild()
            }.show()
        }
        b.frame = CGRect(0f, 0f, 240f, 42f)
        return b
    }

    private fun toggle(t: String, on: Boolean, f: (Boolean) -> Unit): UiView {
        val l = UILabel(appContext!!)
        l.text = t; l.textColor = UIColor.white; l.font = UIFont.systemFont(15f)
        l.frame = CGRect(0f, 0f, 200f, 22f)
        val s = UISwitch(appContext!!)
        s.isOn = on
        s.onValueChanged = { host.pushUndo(); f(s.isOn) }
        val r = UiView(appContext!!)
        r.addSubview(l); r.addSubview(s)
        r.frame = CGRect(0f, 0f, 100f, 32f)
        r.onLayout = { w -> l.frame = CGRect(0f, 5f, w - 60f, 22f); s.frame = CGRect(w - 54f, 0f, 50f, 32f) }
        return r
    }

    private fun segment(items: List<String>, selIdx: Int, f: (Int) -> Unit): FlatSegment {
        val s = FlatSegment(items, selIdx)
        s.onValueChanged = { f(s.selectedSegmentIndex) }
        s.frame = CGRect(0f, 0f, 240f, 32f)
        return s
    }

    private fun slider(t: String, v: Float, lo: Float, hi: Float, fmt: String, f: (Float) -> Unit): UiView {
        val name = UILabel(appContext!!)
        name.text = t; name.textColor = UIColor.white; name.font = UIFont.systemFont(14f)
        name.frame = CGRect(0f, 0f, 200f, 20f)
        val value = UILabel(appContext!!)
        value.textColor = UIColor(0xFFABABAB.toInt()); value.font = UIFont.monospacedDigitSystemFont(13f)
        value.textAlignment = NSTextAlignment.right
        value.text = String.format(Locale.US, fmt, v)
        value.frame = CGRect(0f, 0f, 90f, 20f)
        val s = UISlider(appContext!!)
        s.minValue = lo; s.maxValue = hi; s.value = min(max(v, lo), hi)
        s.onBegin = { host.pushUndo() }
        s.onValueChanged = { f(s.value); value.text = String.format(Locale.US, fmt, s.value) }
        val c = UiView(appContext!!)
        c.addSubview(name); c.addSubview(value); c.addSubview(s)
        c.frame = CGRect(0f, 0f, 100f, 58f)
        c.onLayout = { w ->
            name.frame = CGRect(0f, 0f, w * 0.6f, 20f)
            value.frame = CGRect(w * 0.6f, 0f, w * 0.4f, 20f)
            s.frame = CGRect(0f, 24f, w, 34f)
        }
        return c
    }
}
