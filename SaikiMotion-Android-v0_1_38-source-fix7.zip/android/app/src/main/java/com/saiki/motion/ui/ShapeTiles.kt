@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import com.saiki.motion.core.ShapeKind
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIControl
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// Port of Sources/UI/ShapeTiles.swift — shape picker grid with real shape previews.

object ShapeGlyph {
    /** Outline of a shape kind inside `r` (preview only; the renderer draws the real shape). */
    fun path(k: ShapeKind, r: CGRect, rnd: CGFloat = 0.12f): android.graphics.Path {
        val cx = r.midX; val cy = r.midY; val w = r.width; val h = r.height; val m = min(w, h) / 2
        fun poly(n: Int, rot: Float = -Math.PI.toFloat() / 2f): android.graphics.Path {
            val p = android.graphics.Path()
            for (i in 0 until n) {
                val a = rot + i * 2f * Math.PI.toFloat() / n
                val pt = PointF2(cx + cos(a) * m, cy + sin(a) * m)
                if (i == 0) p.moveTo(pt.x, pt.y) else p.lineTo(pt.x, pt.y)
            }
            p.close()
            return p
        }
        fun polygon(pts: List<Pair<Float, Float>>): android.graphics.Path {
            val p = android.graphics.Path()
            for ((i, q) in pts.withIndex()) {
                val x = r.x + q.first * w; val y = r.y + q.second * h
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            p.close()
            return p
        }
        return when (k) {
            ShapeKind.RECT -> android.graphics.Path().apply { addRect(r.x, r.y, r.x + w, r.y + h, android.graphics.Path.Direction.CW) }
            ShapeKind.ROUND -> android.graphics.Path().apply {
                addRoundRect(r.toRectF(),
                             min(m * 0.9f, max(2f, rnd * m * 2.5f)), min(m * 0.9f, max(2f, rnd * m * 2.5f)),
                             android.graphics.Path.Direction.CW) }
            ShapeKind.CIRCLE -> android.graphics.Path().apply {
                addCircle(cx, cy, m, android.graphics.Path.Direction.CW) }
            ShapeKind.ELLIPSE -> android.graphics.Path().apply {
                addOval(android.graphics.RectF(r.x, r.y, r.x + w, r.y + h), android.graphics.Path.Direction.CW) }
            ShapeKind.TRIANGLE -> polygon(listOf(Pair(0f, 1f), Pair(1f, 1f), Pair(0.5f, 0f)))
            ShapeKind.DIAMOND -> poly(4)
            ShapeKind.PENTAGON -> poly(5)
            ShapeKind.HEXAGON -> poly(6)
            ShapeKind.OCTAGON -> poly(8, -Math.PI.toFloat() / 2f + Math.PI.toFloat() / 8f)
            ShapeKind.PATH -> android.graphics.Path().apply { addRect(r.x, r.y, r.x + w, r.y + h, android.graphics.Path.Direction.CW) }
            ShapeKind.STAR -> {
                val p = android.graphics.Path()
                for (i in 0 until 10) {
                    val a = -Math.PI.toFloat() / 2f + i * Math.PI.toFloat() / 5f
                    val rad = if (i % 2 == 0) m else m * 0.45f
                    val x = cx + cos(a) * rad; val y = cy + sin(a) * rad
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                p
            }
            ShapeKind.ARROW -> polygon(listOf(Pair(0f, 0.32f), Pair(0.6f, 0.32f), Pair(0.6f, 0.05f), Pair(1f, 0.5f),
                                              Pair(0.6f, 0.95f), Pair(0.6f, 0.68f), Pair(0f, 0.68f)))
            ShapeKind.CHEVRON -> polygon(listOf(Pair(0f, 0f), Pair(0.55f, 0f), Pair(1f, 0.5f), Pair(0.55f, 1f), Pair(0f, 1f), Pair(0.45f, 0.5f)))
            ShapeKind.PLUS -> polygon(listOf(Pair(0.33f, 0f), Pair(0.67f, 0f), Pair(0.67f, 0.33f), Pair(1f, 0.33f), Pair(1f, 0.67f),
                                             Pair(0.67f, 0.67f), Pair(0.67f, 1f), Pair(0.33f, 1f), Pair(0.33f, 0.67f), Pair(0f, 0.67f),
                                             Pair(0f, 0.33f), Pair(0.33f, 0.33f)))
            ShapeKind.HEART -> {
                val p = android.graphics.Path()
                p.moveTo(cx, r.y + h)
                p.cubicTo(cx - w * 0.15f, r.y + h - h * 0.15f, r.x, cy + h * 0.1f, r.x, r.y + h * 0.32f)
                p.cubicTo(r.x, r.y - h * 0.05f, cx - w * 0.1f, r.y, cx, r.y + h * 0.28f)
                p.cubicTo(cx + w * 0.1f, r.y, r.x + w, r.y - h * 0.05f, r.x + w, r.y + h * 0.32f)
                p.cubicTo(r.x + w, cy + h * 0.1f, cx + w * 0.15f, r.y + h - h * 0.15f, cx, r.y + h)
                p.close()
                p
            }
            ShapeKind.RING -> android.graphics.Path().apply {
                addCircle(cx, cy, m, android.graphics.Path.Direction.CW)
                addCircle(cx, cy, m * 0.55f, android.graphics.Path.Direction.CCW)   // even-odd hole
                fillType = android.graphics.Path.FillType.EVEN_ODD
            }
        }
    }

    private class PointF2(val x: Float, val y: Float)
}

class ShapeTile(val kind: ShapeKind, chosen: Boolean) : UIControl(com.saiki.motion.uikit.appContext!!) {
    var chosen = chosen
        set(v) { field = v; setNeedsDisplay() }
    var onPick: ((ShapeKind) -> Unit)? = null

    init {
        setBackgroundColor(android.graphics.Color.TRANSPARENT)
        onClick = { onPick?.invoke(kind) }
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        paint.color = if (chosen) C.GREEN else C.CARD2
        val card = android.graphics.RectF(rect.x + 2, rect.y + 2, rect.x + rect.width - 2, rect.y + rect.height - 2)
        c.canvas.drawRoundRect(card, 10f, 10f, paint)
        val area = CGRect(rect.x, rect.y, rect.width, rect.height - 12).insetBy(14f, 12f)
        paint.color = if (chosen) C.ONDARK else C.TEXT
        c.canvas.drawPath(ShapeGlyph.path(kind, area), paint)
        drawText(kindTitle(kind), rect.midX, rect.height - 15f, color = if (chosen) C.ONDARK else C.DIM, size = 9f,
                 bold = false, align = NSTextAlignment.center)
    }

    private fun kindTitle(k: ShapeKind): String = k.title
}

/** Grid of shape tiles (5 per row). `selected` highlights the current shape. */
fun shapeGrid(selected: ShapeKind?, onPick: (ShapeKind) -> Unit): UiView {
    val ctx = com.saiki.motion.uikit.appContext!!
    val kinds = ShapeKind.allKinds
    val rows = ArrayList<List<ShapeTile>>()
    var start = 0
    while (start < kinds.size) {
        val end = min(start + 5, kinds.size)
        val row = (start until end).map { i -> ShapeTile(kinds[i], kinds[i] == selected).also { it.onPick = onPick } }
        rows.add(row)
        start += 5
    }
    val totalRows = rows.size
    return object : UiView(ctx) {
        override fun layoutSubviews() {
            val rh = 64f
            val cw = rectWidth() / 5
            for ((ri, row) in rows.withIndex()) {
                for ((ci, t) in row.withIndex()) {
                    t.frame = CGRect(ci * cw + 2f, ri * (rh + 4f), cw - 4f, rh)
                }
            }
        }
        public override fun draw(rect: CGRect) { /* tiles draw themselves */ }
    }.also { v ->
        for (row in rows) for (t in row) v.addSubview(t)
        v.setBackgroundColor(android.graphics.Color.TRANSPARENT)
    }
}
