@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/ShineDashboard.swift — full-screen dashboard for the Shine effect ("Open
// Dashboard…"): live preview with a yellow on-screen gizmo (source point, shape mask + feather),
// preset chips and every parameter in collapsible sections, including the Mask Layer picker. The
// gizmo always sits where the renderer puts things (ShineCam.resolve): in 3D (Camera-aware) mode
// that is the world source projected through the scene camera, and in either mode it follows the
// layer's own transform; dragging solves back for the stored value. Close reverts everything, ✓ keeps it.

package com.saiki.motion.ui

import com.saiki.motion.core.ColorParam
import com.saiki.motion.core.EffectDef
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.PropDef
import com.saiki.motion.core.Registry
import com.saiki.motion.core.SceneRenderer
import com.saiki.motion.core.ShineCam
import com.saiki.motion.app.Dlg
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIColorWell
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UISwitch
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** BuiltinsShine.swift:18 — preset: name, parameter values, gradient colours (Highlights, Mid High, Midtones, Mid Low, Shadows as 0xRRGGBB). */
class ShinePreset(val name: String, val v: Map<String, Float>, val cols: List<Long>)

val shinePresets: List<ShinePreset> = listOf(
    ShinePreset("Default", emptyMap(), listOf(0xFFFFFFL, 0xFFE066L, 0x00C8F0L, 0xFFA060L, 0x0A5CFFL)),
    ShinePreset("Sunbeam", mapOf("shRay" to 6f, "shBoost" to 5f, "shShAmt" to 25f, "shFnAmt" to 30f, "shCol" to 3f, "shThr" to 60f), listOf(0xFFFFFFL, 0xFFF1B0L, 0xFFC857L, 0xFF9A3CL, 0xC2410CL)),
    ShinePreset("Fire", mapOf("shRay" to 5f, "shBoost" to 8f, "shShAmt" to 40f, "shFnAmt" to 45f, "shCol" to 3f, "shThr" to 58f), listOf(0xFFFFE0L, 0xFFD23CL, 0xFF7A00L, 0xD01C00L, 0x420000L)),
    ShinePreset("Ice", mapOf("shRay" to 4f, "shBoost" to 0f, "shShAmt" to 15f, "shFnAmt" to 20f, "shCol" to 2f), listOf(0xFFFFFFL, 0xD6F4FFL, 0x7FD4FFL, 0x3A8CFFL, 0x0A2A8AL)),
    ShinePreset("Electric", mapOf("shRay" to 7f, "shBoost" to 10f, "shThr" to 62f, "shShAmt" to 55f, "shShDet" to 40f, "shFnAmt" to 10f, "shCol" to 2f), listOf(0xFFFFFFL, 0xE0D0FFL, 0xA070FFL, 0x6030FFL, 0x1A0A6AL)),
    ShinePreset("Underwater", mapOf("shRay" to 8f, "shBoost" to 0f, "shShAmt" to 25f, "shFnAmt" to 45f, "shFnScale" to 18f, "shCol" to 2f, "shThr" to 62f), listOf(0xE8FFFFL, 0xA0F0E0L, 0x40C8D0L, 0x1890B0L, 0x063A60L)),
    ShinePreset("Headlights in Fog", mapOf("shRay" to 9f, "shBoost" to 5f, "shFnAmt" to 55f, "shFnScale" to 25f, "shCol" to 1f, "shThr" to 65f), listOf(0xFFF8E8L, 0xFFF8E8L, 0xFFF8E8L, 0xFFF8E8L, 0xFFF8E8L)),
)

class ShineDashboardViewController(private val lay: Layer, private val entry: String, private val onDone: () -> Unit) : UIViewController() {
    private val def: EffectDef? = Registry.get(entry)
    private val snap = HashMap<String, Float>()
    private var snapInputs: Map<String, Int> = emptyMap()
    private var savedVideoCb: (() -> Unit)? = null
    private val pv by lazy {
        savedVideoCb = SceneRenderer.onVideoFrame
        PreviewView(appContext!!).apply { quality = 2 }
    }
    private val gold = 0xFFFAF033.toInt()
    private val rows = UiView(appContext!!)
    private val rowViews = HashMap<String, UiView>()
    private val refreshers = ArrayList<() -> Unit>()
    private var gizmo: ShineGizmoView? = null
    private var expanded: MutableSet<String> = HashSet(listOf("Source Point", "Rays"))

    init {
        for ((k, t) in lay.props) if (k.startsWith(entry + "__")) snap[k] = t.base
        snapInputs = lay.inputs.toMap()
    }

    companion object {
        val hidden: Set<String> = setOf("shSc", "shVis")
        private val sections: List<Pair<String, List<String>>> = listOf(
            "Source Point" to listOf("shType", "shFollow", "shX", "shY", "shWX", "shWY", "shWZ", "@hint"),
            "Rays" to listOf("shThr", "shRay", "shFall", "shQ", "shBoost"),
            "Shimmer" to listOf("shShAmt", "shShDet", "shShInf", "shShRad", "shShPh", "shShRed"),
            "Colorize" to listOf("shCol", "shBase"),
            "Fractal Noise" to listOf("shFnAmt", "shFnScale", "shFnDet", "shFnEvo", "shFnPar"),
            "Blend" to listOf("shSrcOp", "shOp", "shBlend"),
            "Masking" to listOf("shMApply", "@layer", "shLMSrc", "shLMFe", "shLMEx", "shLMInv", "shLMOp"),
            "Shape Mask" to listOf("shMask", "shMShape", "shMX", "shMY", "shMW", "shMH", "shMFe", "shMOp", "shMEx", "shMInv"))
    }

    // MARK: params

    private fun key(k: String) = "${entry}__$k"

    fun valx(k: String): Float {
        val t = lay.props[key(k)]
        if (t != null) return t.eval(lay.editTime(key(k), Editor.time))
        return def?.props?.firstOrNull { it.key == k }?.def ?: 0f
    }

    fun set(k: String, v: Float) {
        lay.track(key(k)).base = v
        pv.requestDraw(); gizmo?.refresh()
    }

    private fun comp(k: String, s: String, d: Float): Float {
        val kk = "${key(k)}_$s"
        val t = lay.props[kk]
        if (t != null) return t.eval(lay.editTime(kk, Editor.time))
        return d
    }

    private fun setColor(k: String, rgb: Long) {
        lay.track(key(k) + "_r").base = ((rgb shr 16) and 0xFF).toFloat() / 255f
        lay.track(key(k) + "_g").base = ((rgb shr 8) and 0xFF).toFloat() / 255f
        lay.track(key(k) + "_b").base = (rgb and 0xFF).toFloat() / 255f
        lay.track(key(k) + "_a").base = 1f
    }

    // MARK: layout

    private val bar = UiView(appContext!!)
    private val box = UiView(appContext!!)
    private val chipScroll = UIScrollView(appContext!!)
    private val chips = UiView(appContext!!)
    private val scroll = UIScrollView(appContext!!)
    private val titleL = UILabel(appContext!!)
    private val closeBtn = PillButton("✕", null, C.CARD2, C.TEXT)
    private val okBtn = PillButton("✓", null, gold, 0xFF000000.toInt())

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(0xFF121212.toInt())
        titleL.text = "SHINE"; titleL.font = UIFont.boldSystemFont(14f); titleL.textColor = UIColor(0xFFE6E6E6.toInt())
        titleL.textAlignment = NSTextAlignment.center
        closeBtn.onClick = { finish(apply = false) }
        okBtn.onClick = { finish(apply = true) }
        view.addSubview(bar); view.addSubview(box); view.addSubview(chipScroll); view.addSubview(scroll)
        bar.addSubview(closeBtn); bar.addSubview(titleL); bar.addSubview(okBtn)
        chipScroll.addSubview(chips)
        var cx = 0f
        for (p in shinePresets) {
            val b = PillButton(p.name, null, 0xFF2E2E2E.toInt(), C.TEXT)
            b.textSize = 13f
            b.onClick = { applyPreset(p) }
            chips.addSubview(b)
            b.frame = CGRect(cx, 3f, measureTextWidth(b.text, 13f) + 28f, 32f)
            cx += measureTextWidth(b.text, 13f) + 36f
        }
        box.setBackgroundColor(0xFF000000.toInt())
        box.addSubview(pv)
        val gz = ShineGizmoView(appContext!!)
        gz.owner = this
        pv.addSubview(gz); gizmo = gz
        scroll.addSubview(rows)
        buildRows()
        updateVisibility()
        relayout()
        view.onLayout = { _ -> relayout() }
    }

    private fun measureTextWidth(t: String, size: Float): Float = com.saiki.motion.uikit.measureText(t, size, true)

    private fun relayout() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w < 10 || h < 10) return
        bar.frame = CGRect(0f, 0f, w, 44f)
        closeBtn.frame = CGRect(14f, 6f, 32f, 32f)
        okBtn.frame = CGRect(w - 46f, 6f, 32f, 32f)
        titleL.frame = CGRect(60f, 11f, w - 120f, 22f)
        box.frame = CGRect(0f, 44f, w, h * 0.36f)
        val aspect = max(Editor.project.w, 1).toFloat() / max(Editor.project.h, 1).toFloat()
        var pw = box.rectWidth(); var ph = pw / aspect
        if (ph > box.rectHeight()) { ph = box.rectHeight(); pw = ph * aspect }
        pv.frame = CGRect((box.rectWidth() - pw) / 2, (box.rectHeight() - ph) / 2, pw, ph)
        gizmo?.frame = CGRect(0f, 0f, pv.rectWidth(), pv.rectHeight())
        chipScroll.frame = CGRect(0f, box.frame.maxY + 8f, w, 38f)
        chips.frame = CGRect(0f, 0f, max(cxWidth(), w), 38f)
        chipScroll.contentSize = CGSize(max(cxWidth(), w), 38f)
        scroll.frame = CGRect(0f, box.frame.maxY + 48f, w, h - box.frame.maxY - 48f)
        layoutRows()
    }

    private var chipsWidth = 0f
    private fun cxWidth(): Float {
        var x = 14f
        for (c in chips.subviews) x += c.rectWidth() + 8f
        return x
    }

    private fun layoutRows() {
        var y = 0f
        for (v in rows.subviews) {
            val vh = v.rectHeight().takeIf { it > 0f } ?: 40f
            v.frame = CGRect(16f, y, max(scroll.rectWidth() - 32f, 10f), vh)
            v.onLayout?.invoke(max(scroll.rectWidth() - 32f, 10f))
            y += if (v.isHidden) 0f else vh + 10f
        }
        rows.frame = CGRect(0f, 0f, scroll.rectWidth(), y + 20f)
        scroll.contentSize = CGSize(scroll.rectWidth(), y + 20f)
    }

    override fun viewDidAppear(animated: Boolean) {
        super.viewDidAppear(animated)
        pv.requestDraw(); gizmo?.refresh()
        uikitMain { pv.requestDraw() }
    }

    private fun uikitMain(f: () -> Unit) = android.os.Handler(android.os.Looper.getMainLooper()).post(f)

    // MARK: resolved values (what the renderer feeds the shader)

    private val pw: Int get() = max(Editor.project.w, 1)
    private val ph: Int get() = max(Editor.project.h, 1)

    // gizmo accessors
    fun defForGizmo(): EffectDef = def ?: EffectDef(entry)
    fun layerForGizmo(): Layer = lay

    fun inputValues(): FloatArray = def?.props?.map { valx(it.key) }?.toFloatArray() ?: FloatArray(0)

    fun resolvedProps(): FloatArray {
        val d = def ?: return FloatArray(0)
        val arr = inputValues()
        ShineCam.resolve(d, arr, lay, Editor.time, pw, ph)
        return arr
    }

    fun rv(k: String, arr: FloatArray): Float {
        val i = def?.props?.indexOfFirst { it.key == k } ?: -1
        return if (i >= 0 && i < arr.size) arr[i] else 0f
    }

    fun clampKey(k: String, v: Float): Float {
        val pd = def?.props?.firstOrNull { it.key == k } ?: return v
        return min(max(v, pd.min), pd.max)
    }

    /** Scale the shape mask picks up from the layer (1 when Follow Layer Transform is off). */
    fun maskFollowScale(): Float = if (valx("shFollow") > 0.5f) ShineCam.layerScale(lay, Editor.time) else 1f

    // MARK: mask layer picker

    private fun layerPickerRow(): UiView {
        val name = UILabel(appContext!!)
        name.text = "Mask Layer"; name.textColor = UIColor.white; name.font = UIFont.systemFont(14f)
        val b = PillButton("None  ▾", null, 0x00000000.toInt(), gold)
        b.textSize = 13f
        val ik = "$entry:Mask Layer"
        fun rebuild() {
            val cands = Editor.scene.layers.filter { it.id != lay.id && it.isRenderable() && it.type != LayerType.MODEL && it.type != LayerType.PARTICLES }
            val cur = lay.inputs[ik]
            val curName = Editor.scene.layers.firstOrNull { it.id == cur }?.name ?: "None"
            b.text = "$curName  ▾"
            b.onClick = {
                Dlg(this).setTitle("Mask Layer").setItems(listOf("None") + cands.map { it.name }) { _, i ->
                    if (i == 0) pickMask(null) else pickMask(cands[i - 1].id)
                    rebuild()
                }.show()
            }
        }
        rebuild(); refreshers.add { rebuild() }
        val r = UiView(appContext!!)
        r.addSubview(name); r.addSubview(b)
        r.onLayout = { w ->
            name.frame = CGRect(0f, 8f, w - 140f, 20f)
            b.frame = CGRect(w - 140f, 2f, 140f, 30f)
        }
        return r
    }

    private fun pickMask(id: Int?) {
        val ik = "$entry:Mask Layer"
        if (id != null) lay.inputs[ik] = id else lay.inputs.remove(ik)
        updateVisibility(); pv.requestDraw()
    }

    // MARK: rows

    private fun buildRows() {
        rows.subviews.toList().forEach { it.removeFromSuperview() }
        rowViews.clear(); refreshers.clear()
        for (sec in sections) {
            val (name, keys) = sec
            val bodyV = UiView(appContext!!)
            for (k in keys) {
                if (k == "@layer") {
                    val r = layerPickerRow(); rowViews[k] = r; bodyV.addSubview(r)
                } else if (k == "@hint") {
                    val h = UILabel(appContext!!)
                    h.font = UIFont.systemFont(12f); h.textColor = UIColor(0xFF999999.toInt()); h.numberOfLines = 0
                    rowViews[k] = h; bodyV.addSubview(h)
                } else {
                    val pd = def?.props?.firstOrNull { it.key == k }
                    if (pd != null) {
                        val r = row(pd); rowViews[k] = r; bodyV.addSubview(r)
                    }
                }
            }
            if (name == "Colorize") {
                for (cp in def?.colors ?: emptyList()) {
                    val r = colorRow(cp); rowViews[cp.key] = r; bodyV.addSubview(r)
                }
            }
            bodyV.isHidden = !expanded.contains(name)
            val h = PillButton((if (expanded.contains(name)) "▾  " else "▸  ") + name.uppercase(Locale.US), null, 0x00000000.toInt(), gold)
            h.textSize = 12f
            h.onClick = {
                if (expanded.contains(name)) expanded.remove(name) else expanded.add(name)
                bodyV.isHidden = !expanded.contains(name)
                h.text = (if (expanded.contains(name)) "▾  " else "▸  ") + name.uppercase(Locale.US)
                layoutRows()
            }
            val secV = UiView(appContext!!)
            secV.addSubview(h); secV.addSubview(bodyV)
            secV.onLayout = { w ->
                h.frame = CGRect(0f, 0f, w, 26f)
                var y = 32f
                for (v in bodyV.subviews) {
                    if (v.isHidden) continue
                    val vh = when {
                        v is UILabel -> v.font.size * 3f + 6f
                        v.subviews.size == 2 && v.subviews[1] is UISwitch -> 32f
                        v.subviews.size == 2 && v.subviews[1] is UIColorWell -> 34f
                        v.subviews.size == 2 && v.subviews[1] is PillButton -> 34f
                        else -> 64f
                    }
                    v.frame = CGRect(0f, y, w, vh)
                    v.onLayout?.invoke(w)
                    y += vh + 8f
                }
                bodyV.frame = CGRect(0f, 32f, w, if (bodyV.isHidden) 0f else y)
                secV.frame = CGRect(secV.frame.x, secV.frame.y, w, if (bodyV.isHidden) 32f else y)
            }
            rows.addSubview(secV)
        }
    }

    private fun row(pd: PropDef): UiView {
        val name = UILabel(appContext!!)
        name.text = pd.label; name.textColor = UIColor.white; name.font = UIFont.systemFont(14f)
        val opts = pd.options
        if (opts != null) {
            if (opts.size == 2) {
                val sw = UISwitch(appContext!!)
                sw.isOn = valx(pd.key) >= 0.5f
                sw.onValueChanged = { set(pd.key, if (sw.isOn) 1f else 0f); updateVisibility() }
                refreshers.add { sw.isOn = valx(pd.key) >= 0.5f }
                val r = UiView(appContext!!)
                r.addSubview(name); r.addSubview(sw)
                r.onLayout = { w -> name.frame = CGRect(0f, 6f, w - 60f, 20f); sw.frame = CGRect(w - 54f, 0f, 50f, 32f) }
                return r
            }
            val b = PillButton("", null, 0x00000000.toInt(), gold)
            b.textSize = 13f
            fun rebuild() {
                val cur = min(max(valx(pd.key).toInt(), 0), opts.size - 1)
                b.text = opts[cur] + "  ▾"
                b.onClick = {
                    Dlg(this).setTitle(pd.label).setItems(opts) { _, i ->
                        set(pd.key, i.toFloat()); rebuild(); updateVisibility()
                    }.show()
                }
            }
            rebuild(); refreshers.add { rebuild() }
            val r = UiView(appContext!!)
            r.addSubview(name); r.addSubview(b)
            r.onLayout = { w -> name.frame = CGRect(0f, 8f, w - 150f, 20f); b.frame = CGRect(w - 150f, 2f, 150f, 30f) }
            return r
        }
        val v = UILabel(appContext!!)
        v.font = UIFont.monospacedDigitSystemFont(13f); v.textColor = argbToUIColor(gold); v.textAlignment = NSTextAlignment.right
        val s = UISlider(appContext!!)
        s.minValue = pd.min; s.maxValue = pd.max; s.value = valx(pd.key)
        fun show(x: Float): String = String.format(Locale.US, "%.${pd.dec}f", x)
        v.text = show(s.value)
        s.onValueChanged = { x -> set(pd.key, x); v.text = show(x) }
        refreshers.add { s.value = valx(pd.key); v.text = show(s.value) }
        val col = UiView(appContext!!)
        col.addSubview(name); col.addSubview(v); col.addSubview(s)
        col.onLayout = { w ->
            name.frame = CGRect(0f, 0f, w * 0.6f, 20f)
            v.frame = CGRect(w * 0.6f, 0f, w * 0.4f, 20f)
            s.frame = CGRect(0f, 24f, w, 34f)
        }
        return col
    }

    private fun colorRow(cp: ColorParam): UiView {
        val u = cp.def.toLong() and 0xFFFFFFFFL
        val w = UIColorWell(appContext!!)
        w.supportsAlpha = false; w.title = cp.label
        fun current(): UIColor = UIColor.rgb(
            comp(cp.key, "r", ((u shr 16) and 0xFF).toFloat() / 255f),
            comp(cp.key, "g", ((u shr 8) and 0xFF).toFloat() / 255f),
            comp(cp.key, "b", (u and 0xFF).toFloat() / 255f), 1f)
        w.selectedColor = current()
        w.onValueChanged = {
            val c = w.selectedColor.toInt()
            lay.track(key(cp.key) + "_r").base = ((c ushr 16) and 0xFF).toFloat() / 255f
            lay.track(key(cp.key) + "_g").base = ((c ushr 8) and 0xFF).toFloat() / 255f
            lay.track(key(cp.key) + "_b").base = (c and 0xFF).toFloat() / 255f
            lay.track(key(cp.key) + "_a").base = 1f
            pv.requestDraw()
        }
        refreshers.add { w.selectedColor = current() }
        val t = UILabel(appContext!!)
        t.text = cp.label; t.font = UIFont.systemFont(14f); t.textColor = UIColor.white
        val r = UiView(appContext!!)
        r.addSubview(t); r.addSubview(w)
        r.onLayout = { rw -> t.frame = CGRect(0f, 10f, rw - 56f, 20f); w.frame = CGRect(rw - 48f, 6f, 44f, 28f) }
        return r
    }

    /// 2D shows the frame X/Y; 3D shows the world X/Y/Z. Mask fields fade out while the mask is off.
    fun updateVisibility() {
        val three = valx("shType") > 0.5f
        val mask = valx("shMask") > 0.5f
        val hasLM = lay.inputs["$entry:Mask Layer"] != null
        for (k in listOf("shX", "shY")) rowViews[k]?.isHidden = three
        for (k in listOf("shWX", "shWY", "shWZ")) rowViews[k]?.isHidden = !three
        for (k in listOf("shMShape", "shMX", "shMY", "shMW", "shMH", "shMFe", "shMOp", "shMEx", "shMInv")) rowViews[k]?.isHidden = !mask
        for (k in listOf("shLMSrc", "shLMFe", "shLMEx", "shLMInv", "shLMOp")) rowViews[k]?.isHidden = !hasLM
        rowViews["shMApply"]?.isHidden = !(mask || hasLM)
        val h = rowViews["@hint"] as? UILabel
        if (h != null) {
            h.isHidden = !three
            val seen = lay.type == LayerType.ADJUST || lay.is3d || lay.type == LayerType.MODEL
            if (!seen) h.text = "Camera-aware needs this effect on an Adjustment layer (or a 3D layer) so the scene camera can move the source."
            else if (ShineCam.camera(lay) == null && SceneRenderer.editCam == null) h.text = "No Camera layer found. Add one and the source will follow its moves, orbits and zoom."
            else h.text = "Following the scene camera: rotate, move or zoom it and the rays stay locked to the source."
        }
        val hasGrad = valx("shCol") > 1.5f
        val five = valx("shCol") > 2.5f
        rowViews["shBase"]?.isHidden = valx("shCol") < 0.5f
        rowViews["shCHi"]?.isHidden = valx("shCol") < 0.5f
        for (k in listOf("shCMid", "shCSh")) rowViews[k]?.isHidden = !hasGrad
        for (k in listOf("shCMH", "shCML")) rowViews[k]?.isHidden = !five
        gizmo?.refresh()
    }

    private fun applyPreset(p: ShinePreset) {
        val keep: Set<String> = sections.filter { listOf("Source Point", "Masking", "Shape Mask").contains(it.first) }.flatMap { it.second }.toSet()
        for (pd in def?.props ?: emptyList()) {
            if (!keep.contains(pd.key) && pd.key !in hidden) set(pd.key, pd.def)
        }
        for ((k, v) in p.v) set(k, v)
        val names = listOf("shCHi", "shCMH", "shCMid", "shCML", "shCSh")
        for ((i, n) in names.withIndex()) {
            if (i < p.cols.size) setColor(n, p.cols[i])
        }
        refreshers.forEach { it() }
        updateVisibility(); pv.requestDraw()
    }

    // MARK: finish

    private fun finish(apply: Boolean) {
        if (!apply) {
            for (k in lay.props.keys.toList()) {
                if (!k.startsWith(entry + "__")) continue
                val b = snap[k]
                if (b != null) lay.props[k]?.base = b else lay.props.remove(k)
            }
            lay.inputs.clear()
            lay.inputs.putAll(snapInputs)
        }
        SceneRenderer.onVideoFrame = savedVideoCb
        val done = onDone
        dismiss(animated = true) { done() }
    }
}

// MARK: - viewport gizmo (yellow): source point + shape mask (ellipse / rectangle) with feather rings

class ShineGizmoView(context: android.content.Context) : UiView(context) {
    var owner: ShineDashboardViewController? = null
    private val gold = 0xFFFAF033.toInt()
    private var handles = ArrayList<Pair<Int, CGPoint>>()     // 0 source, 1 mask centre, 2 mask width, 3 mask height
    private var drag = -1

    init { setBackgroundColor(0x00000000) }

    private val pw: Int get() = max(Editor.project.w, 1)
    private val ph: Int get() = max(Editor.project.h, 1)

    fun refresh() {
        val o = owner ?: return
        if (rectWidth() <= 1f) return
        handles = ArrayList()
        val W = rectWidth(); val H = rectHeight(); val k = H / 1080f
        val r = o.resolvedProps()                       // camera + layer transform already applied
        if (o.rv("shVis", r) > 0.5f) {
            val c = CGPoint(o.rv("shX", r) * 0.01f * W, o.rv("shY", r) * 0.01f * H)
            handles.add(Pair(0, c))
        }
        setNeedsDisplay()
    }

    public override fun draw(rect: CGRect) {
        val g = UIGraphics.getCurrentContext() ?: return
        val o = owner ?: return
        if (rectWidth() <= 1f) return
        val W = rectWidth(); val H = rectHeight(); val k = H / 1080f
        val r = o.resolvedProps()
        if (o.rv("shVis", r) > 0.5f) {
            val c = CGPoint(o.rv("shX", r) * 0.01f * W, o.rv("shY", r) * 0.01f * H)
            // source circle + cross
            g.setStrokeColor(gold); g.setLineWidth(1.5f)
            g.strokeEllipse(CGRect(c.x - 11f, c.y - 11f, 22f, 22f))
            g.beginPath()
            for ((dx, dy) in listOf(1f to 0f, -1f to 0f, 0f to 1f, 0f to -1f)) {
                g.move(CGPoint(c.x + dx * 6f, c.y + dy * 6f)); g.addLine(CGPoint(c.x + dx * 18f, c.y + dy * 18f))
            }
            g.strokePath()
        }
        if (o.valx("shMask") > 0.5f) {
            val rectMask = o.valx("shMShape") > 0.5f
            val mc = CGPoint(o.rv("shMX", r) * 0.01f * W, o.rv("shMY", r) * 0.01f * H)
            val ex = o.valx("shMEx") * k
            val hx = max(o.rv("shMW", r) * 0.005f * W + ex, 2f)
            val hy = max(o.rv("shMH", r) * 0.005f * H + ex, 2f)
            fun shape(dx: Float, dy: Float) {
                val b = CGRect(mc.x - dx, mc.y - dy, dx * 2, dy * 2)
                if (rectMask) g.stroke(b) else g.strokeEllipse(b)
            }
            g.setStrokeColor(gold); g.setLineWidth(1.5f)
            g.setLineDash(0f, floatArrayOf(6f, 4f))
            shape(hx, hy)
            g.setLineDash(0f, FloatArray(0))
            val f = o.valx("shMFe") * k * 0.5f          // the soft edge spans +-feather/2 around the outline
            g.setStrokeColor(0x8CFAF033.toInt())
            g.setLineDash(0f, floatArrayOf(2f, 4f))
            shape(hx + f, hy + f)
            if (f > 2f) shape(max(hx - f, 2f), max(hy - f, 2f))
            g.setLineDash(0f, FloatArray(0))
            handles.add(Pair(1, mc))
            handles.add(Pair(2, CGPoint(mc.x + hx, mc.y)))
            handles.add(Pair(3, CGPoint(mc.x, mc.y + hy)))
        }
        // handle dots
        for ((id, p) in handles) {
            if (id == 0) continue
            g.setFillColor(0x66000000.toInt())
            g.fillEllipse(CGRect(p.x - 5f, p.y - 5f, 10f, 10f))
        }
    }

    private fun nearest(l: CGPoint): Int? {
        val best = handles.minByOrNull { hypot((it.second.x - l.x).toDouble(), (it.second.y - l.y).toDouble()) } ?: return null
        return if (hypot((best.second.x - l.x).toDouble(), (best.second.y - l.y).toDouble()) < 32) best.first else null
    }

    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        val l = CGPoint(e.x, e.y)
        val o = owner
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> { drag = nearest(l) ?: -1 }
            android.view.MotionEvent.ACTION_MOVE -> {
                if (o != null && drag >= 0 && rectWidth() > 1f) {
                    val W = rectWidth(); val H = rectHeight(); val k = H / 1080f
                    val tgt = Pair(l.x / W * 100f, l.y / H * 100f)
                    val d = o.defForGizmo()
                    if (drag == 0) {                                          // source: solve for the stored value that lands under the finger
                        val three = o.valx("shType") > 0.5f
                        val kx = if (three) "shWX" else "shX"
                        val ky = if (three) "shWY" else "shY"
                        val v = ShineCam.solve(d, o.inputValues(), o.layerForGizmo(), Editor.time, pw, ph,
                            kx, ky, "shX", "shY", tgt, if (three) 0.05f else 1f)
                        if (v != null) {
                            o.set(kx, o.clampKey(kx, v.first)); o.set(ky, o.clampKey(ky, v.second))
                        }
                    } else if (drag == 1) {
                        val v = ShineCam.solve(d, o.inputValues(), o.layerForGizmo(), Editor.time, pw, ph,
                            "shMX", "shMY", "shMX", "shMY", tgt, 1f, needVis = false)
                        if (v != null) {
                            o.set("shMX", o.clampKey("shMX", v.first)); o.set("shMY", o.clampKey("shMY", v.second))
                        }
                    } else {
                        val r = o.resolvedProps()
                        val fs = max(o.maskFollowScale(), 0.0001f)
                        val ex = o.valx("shMEx") * k
                        if (drag == 2) {
                            val mc = o.rv("shMX", r) * 0.01f * W
                            o.set("shMW", o.clampKey("shMW", (abs(l.x - mc) - ex) / W / 0.005f / fs))
                        } else {
                            val mc = o.rv("shMY", r) * 0.01f * H
                            o.set("shMH", o.clampKey("shMH", (abs(l.y - mc) - ex) / H / 0.005f / fs))
                        }
                    }
                    o.updateVisibility()
                }
            }
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> { drag = -1 }
        }
        return true
    }
}
