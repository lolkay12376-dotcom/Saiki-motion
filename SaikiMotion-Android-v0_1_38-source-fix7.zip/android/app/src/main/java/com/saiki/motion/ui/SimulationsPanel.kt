@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/SimulationsPanel.swift — full-screen "Simulations" window: Water + volumetric
// Clouds (CloudsPanel, CloudSettings).

package com.saiki.motion.ui

import com.saiki.motion.app.EditorViewController
import com.saiki.motion.app.addMedia
import com.saiki.motion.app.refreshPanel
import com.saiki.motion.core.CloudGen
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.ExtrasGLB
import com.saiki.motion.core.MistGen
import com.saiki.motion.core.MistSettings
import com.saiki.motion.core.ProjectIO
import com.saiki.motion.core.VdbVolume
import com.saiki.motion.core.nowMs
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIColorWell
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.measureText
import kotlin.math.max
import kotlin.math.min

private val simAccent = 0xFFFF8C14.toInt()

private fun simLabel(t: String, size: CGFloat = 13f, bold: Boolean = false, c: Int = 0xFFB3B3B3.toInt()): UILabel {
    val l = UILabel(appContext!!)
    l.text = t; l.font = if (bold) UIFont.boldSystemFont(size) else UIFont.systemFont(size)
    l.textColor = UIColor(c); l.numberOfLines = 0
    l.frame = CGRect(0f, 0f, 280f, size + 8f)
    return l
}

class SimulationsPanel(private val host: EditorViewController) : UiView(appContext!!) {

    private val content = UiView(appContext!!)

    companion object {
        fun present(host: EditorViewController, view: UiView) {
            if (view.subviews.any { it is SimulationsPanel }) return
            val v = SimulationsPanel(host)
            view.addSubview(v)
            v.frame = CGRect(0f, 0f, view.rectWidth(), view.rectHeight())
        }
    }

    init {
        setBackgroundColor(0xFF0D0D0D.toInt())
        val title = simLabel("Simulations", 24f, true, 0xFFFFFFFF.toInt())
        val x = PillButton("✕", null, C.CARD2, C.TEXT)
        x.onClick = { removeFromSuperview() }
        val rows = UiView(appContext!!)
        rows.addSubview(row("Water", "Waves, foam, refraction, depth") { addWater() })
        rows.addSubview(row("Clouds", "Photorealistic volumetric clouds") { openClouds() })
        rows.addSubview(row("Ground Mist", "Low mist hugging the ground, patchy and drifting") { addGroundMist() })
        rows.addSubview(row("Mist", "Mist bank, valley fog or haze, lit by your lights") { addMistBank() })
        addSubview(rows)
        rows.onLayout = { w ->
            var y = 0f
            for (r in rows.subviews) { r.frame = CGRect(0f, y, w, 84f); y += 84f + 12f }
            rows.frame = CGRect(0f, 0f, w, y)
        }
        publicRowLayout(rows)
    }

    private fun publicRowLayout(rows: UiView) {
        // rows laid out via onLayout above; placeholder for symmetric API
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth(); val h = rectHeight()
        if (w < 10 || h < 10) return
        val top = safeAreaInsets.top
        var y = top + 16f
        for (r in subviews) {
            r.frame = CGRect(18f, y, w - 36f, r.rectHeight().takeIf { it > 0f } ?: 84f)
            y += r.rectHeight() + 12f
            if (r is UiView && r.subviews.isNotEmpty()) {
                // row container relayout of children handled by its own onLayout
                r.onLayout?.invoke(r.rectWidth())
            }
        }
    }

    private fun row(t: String, sub: String, a: () -> Unit): UiView {
        val b = object : TapView() {
            public override fun draw(rect: CGRect) {
                val c = UIGraphics.getCurrentContext() ?: return
                com.saiki.motion.uikit.fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 16f, 0xFF1F1F1F.toInt())
                Icons.draw(c, "drop", 32f, rect.midY, 17f, simAccent)
                drawText(t, 66f, 34f, color = C.TEXT, size = 18f, bold = true, align = NSTextAlignment.left)
                drawText(sub, 66f, 56f, color = C.DIM, size = 12f, bold = false, align = NSTextAlignment.left)
                Icons.draw(c, "chevron.right", rect.width - 22f, rect.midY, 16f, C.DIM)
            }
        }
        b.onClick = { a() }
        b.frame = CGRect(0f, 0f, 320f, 84f)
        return b
    }

    private fun addWater() {
        val path = ProjectIO.writeDataIntoSandbox(com.saiki.motion.ui.ExtrasGLB.water(), "extras_water_${nowMs()}.glb") ?: return
        host.addMedia(path, LayerType.MODEL)
        val l = Editor.scene.layers.lastOrNull { it.imagePath == path }
        if (l != null) {
            l.name = "Water"
            l.xset("water", 1f); l.xset("wAmp", 0.03f); l.xset("wFreq", 6f); l.xset("wSpeed", 1f)
            l.xset("wChop", 0.5f); l.xset("wFoam", 0.5f); l.xset("wDepth", 0.5f)
            host.render(); host.refreshPanel()
        }
        removeFromSuperview()
    }

    private fun addGroundMist() = addMist(0)
    private fun addMistBank() = addMist(1)

    private fun addMist(kind: Int) {
        val tmp = Layer(-1, "tmp", LayerType.NULL)
        MistSettings.setup(tmp, kind)
        val path = MistSettings.writeFile(tmp) ?: return
        host.addMedia(path, LayerType.MODEL)
        val l = Editor.scene.layers.lastOrNull { it.imagePath == path } ?: return
        l.name = MistGen.kinds[kind]
        MistSettings.setup(l, kind)
        l.track("scale").base = 5f
        host.render(); host.refreshPanel()
        removeFromSuperview()
    }

    private fun openClouds() {
        val c = CloudsPanel(host, this)
        addSubview(c)
        c.frame = CGRect(0f, 0f, rectWidth(), rectHeight())
    }
}

class CloudsPanel(private val host: EditorViewController, private val parentPanel: SimulationsPanel?) : UiView(appContext!!) {
    private val typeSeg = FlatSegment(CloudGen.types)
    private val dayNight = FlatUISlider()
    private val density = FlatUISlider()
    private val edgeAmt = FlatUISlider()
    private val scatter = FlatSwitch(false)
    private val envLight = FlatSwitch(false)
    private val tintWell = UIColorWell(appContext!!)
    private val edgeWell = UIColorWell(appContext!!)
    private val body = UiView(appContext!!)
    private val addBtn = PillButton("Add clouds", null, simAccent, 0xFF000000.toInt())

    init {
        setBackgroundColor(0xFF0D0D0D.toInt())
        val back = PillButton("‹", null, C.CARD2, C.TEXT)
        back.onClick = { removeFromSuperview() }
        val title = simLabel("Clouds", 24f, true, 0xFFFFFFFF.toInt())
        typeSeg.selectedSegmentIndex = 0
        for (s in listOf(dayNight, density, edgeAmt)) s.tintColor = simAccent
        dayNight.value = 0f
        density.minimumValue = 0.5f; density.maximumValue = 8f; density.value = 3f
        edgeAmt.value = 0.4f
        tintWell.selectedColor = UIColor.white; tintWell.supportsAlpha = false
        edgeWell.selectedColor = UIColor.rgb(1f, 0.85f, 0.7f, 1f); edgeWell.supportsAlpha = false
        envLight.isOn = true

        addBtn.textSize = 17f
        addBtn.onClick = { addClouds() }
        addBtn.frame = CGRect(0f, 0f, 240f, 50f)
        val note = simLabel("Day ← slider → Night. “Light from environment” lights the clouds with your Environment image/sky.", 12f)
        note.frame = CGRect(0f, 0f, 280f, 40f)

        fun r(t: String, v: UiView): UiView {
            val l = simLabel(t, 14f, false, 0xFFFFFFFF.toInt())
            l.frame = CGRect(0f, 0f, 110f, 20f)
            val s = UiView(appContext!!)
            s.addSubview(l); s.addSubview(v)
            s.frame = CGRect(0f, 0f, 100f, 36f)
            s.onLayout = { w ->
                l.frame = CGRect(0f, 8f, max(96f, w * 0.42f), 20f)
                v.frame = CGRect(w - v.rectWidth().coerceAtLeast(120f) - 4f, 2f, max(120f, w * 0.55f), 32f)
            }
            return s
        }

        body.addSubview(title)
        body.addSubview(simLabel("Type", 13f))
        body.addSubview(typeSeg)
        body.addSubview(r("Day / Night", dayNight))
        body.addSubview(r("Density", density))
        body.addSubview(r("Tint", tintWell))
        body.addSubview(r("Edge colour", edgeWell))
        body.addSubview(r("Edge amount", edgeAmt))
        body.addSubview(r("Procedural scatter", scatter))
        body.addSubview(r("Light from environment", envLight))
        body.addSubview(note)
        body.addSubview(addBtn)
        addSubview(back)
        addSubview(body)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth(); val h = rectHeight()
        if (w < 10 || h < 10) return
        val top = safeAreaInsets.top
        (subviews[0] as? com.saiki.motion.ui.TapView)?.let { }
        var y = top + 16f
        var x = 18f
        for (s in subviews) {
            if (s === body) continue
            s.frame = CGRect(x, y, 44f, 34f)
            x += 52f
        }
        var by = top + 16f
        for (v in body.subviews) {
            val vh = when {
                v === typeSeg -> 32f
                v === tintWell || v === edgeWell -> 36f
                v === addBtn -> 50f
                v is FlatSwitch -> 32f
                v is FlatUISlider -> 36f
                v === body.subviews[0] -> 30f
                v is UILabel -> v.font.size + 10f
                else -> 40f
            }
            v.frame = CGRect(18f, by, w - 36f, vh)
            if (v is FlatUISlider) v.frame = CGRect(18f + max(96f, (w - 36f) * 0.42f), by, max(120f, (w - 36f) * 0.55f), 36f)
            if (v is FlatSwitch) v.frame = CGRect(w - 90f, by, 60f, 32f)
            if (v === tintWell || v === edgeWell) v.frame = CGRect(w - 90f, by, 44f, 30f)
            if (v is UiView && v.subviews.isNotEmpty() && v.subviews[0] is UILabel && v.subviews.size > 1) {
                v.frame = CGRect(18f, by, w - 36f, 36f)
                v.onLayout?.invoke(w - 36f)
            }
            by += vh + 16f
        }
    }

    private fun rgb(c: UIColor): Triple<Float, Float, Float> {
        val i = c.toInt()
        return Triple(((i shr 16) and 0xFF) / 255f, ((i shr 8) and 0xFF) / 255f, (i and 0xFF) / 255f)
    }

    private fun addClouds() {
        val t = typeSeg.selectedSegmentIndex
        val path = CloudSettings.writeFile(t, (nowMs() % 9973).toInt(), scatter.isOn) ?: return
        host.addMedia(path, LayerType.MODEL)
        val l = Editor.scene.layers.lastOrNull { it.imagePath == path } ?: return
        l.name = "Clouds · ${CloudGen.types[t]}"
        val tc = rgb(tintWell.selectedColor)
        val ec = rgb(edgeWell.selectedColor)
        l.xset("cloud", 1f); l.xset("cType", t.toFloat()); l.xset("cScatter", if (scatter.isOn) 1f else 0f)
        l.xset("cDay", dayNight.value); l.xset("cDens", density.value); l.xset("cEdge", edgeAmt.value)
        l.xset("cTint", CloudSettings.pack24(tc.first, tc.second, tc.third))
        l.xset("cEdgeCol", CloudSettings.pack24(ec.first, ec.second, ec.third))
        l.xset("cEnv", if (envLight.isOn) 1f else 0f); l.xset("vdbSteps", 30f); l.xset("vdbShadow", 1f)
        CloudSettings.apply(l)
        host.render(); host.refreshPanel()
        parentPanel?.removeFromSuperview()
    }
}

/** All cloud settings live on the layer (x3s keys) so the Properties panel and the Simulations screen share them. */
object CloudSettings {
    fun pack24(r: CGFloat, g: CGFloat, b: CGFloat): Float =
        (((max(0f, min(1f, r)) * 255).toInt() shl 16) or ((max(0f, min(1f, g)) * 255).toInt() shl 8) or (max(0f, min(1f, b)) * 255).toInt()).toFloat()

    fun unpack(v: Float): Triple<Float, Float, Float> {
        val i = v.toInt()
        return Triple(((i shr 16) and 255) / 255f, ((i shr 8) and 255) / 255f, (i and 255) / 255f)
    }

    fun writeFile(type: Int, seed: Int, scatter: Boolean): String? {
        val d = "SAIKICLOUD $type $seed ${if (scatter) 1 else 0}".toByteArray(Charsets.UTF_8)
        return ProjectIO.writeDataIntoSandbox(d, "clouds_${nowMs()}.vdb")
    }

    /** Day/night, tint, density, edge colour and environment light -> the volume layer's render values. */
    fun apply(l: Layer) {
        val n = l.xf("cDay", 0f)
        val u = unpack(l.xf("cTint", 16777215f))
        val e = unpack(l.xf("cEdgeCol", 16777215f))
        fun mix(a: Float, b: Float): Float = a + (b - a) * n
        l.vdbTint = (0xFF shl 24) or
            ((mix(u.first, u.first * 0.22f) * 255).toInt() shl 16) or
            ((mix(u.second, u.second * 0.28f) * 255).toInt() shl 8) or
            (mix(u.third, u.third * 0.5f) * 255).toInt()
        l.vdbBright = (1.0f - 0.8f * n) * l.xf("cBright", 1f)
        l.vdbDens = l.xf("cDens", 3f)
        l.vdbEnv = l.xf("cEnv", 1f) > 0.5f
        l.vdbSurround = l.vdbEnv
        l.xset("cEdgeOut", (((mix(e.first, e.first * 0.3f) * 255).toInt() shl 16) or
            ((mix(e.second, e.second * 0.4f) * 255).toInt() shl 8) or
            (mix(e.third, e.third * 0.7f) * 255).toInt()).toFloat())
    }

    /** New shape (type / scatter / reseed): a fresh generated volume file on the same layer. */
    fun rebuild(l: Layer) {
        val p = writeFile(l.xf("cType", 0f).toInt(), l.xf("cSeed", (nowMs() % 9973).toFloat()).toInt(), l.xf("cScatter", 0f) > 0.5f) ?: return
        l.imagePath = p
        VdbVolume.load(p)
    }
}
