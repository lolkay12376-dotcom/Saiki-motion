@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/SkyPanel.swift — Environment > Custom gradient sky: pick colours, it becomes the
// lighting / reflection environment AND a visible sky dome.

package com.saiki.motion.ui

import android.graphics.Bitmap
import com.saiki.motion.app.EditorViewController
import com.saiki.motion.app.addMedia
import com.saiki.motion.app.refreshPanel
import com.saiki.motion.core.Editor
import com.saiki.motion.core.GlobalEnv
import com.saiki.motion.core.ProjectIO
import com.saiki.motion.core.R3D
import com.saiki.motion.core.nowMs
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIColorWell
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UISwitch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.pow

class SkyPanel(private val host: EditorViewController?) : UiView(appContext!!) {
    private val accent = 0xFFFF8C14.toInt()
    private val cols = mutableListOf(
        UIColor.rgb(0.10f, 0.25f, 0.75f, 1f), UIColor.rgb(0.45f, 0.70f, 1.0f, 1f),
        UIColor.rgb(1.0f, 0.75f, 0.50f, 1f), UIColor.rgb(0.20f, 0.18f, 0.16f, 1f))
    private var sunOn = true
    private var bright = 2.5f
    private val status = UILabel(appContext!!)
    private val names = listOf("Top (zenith)", "Upper sky", "Horizon", "Ground")
    private val card = UiView(appContext!!)
    private val rowsBox = UiView(appContext!!)

    companion object {
        fun present(host: EditorViewController, view: UiView) {
            if (view.subviews.any { it is SkyPanel }) return
            val v = SkyPanel(host)
            view.addSubview(v)
            v.frame = CGRect(0f, 0f, view.rectWidth(), view.rectHeight())
        }
    }

    init {
        setBackgroundColor(0x8C000000.toInt())
        build()
    }

    private fun label(t: String, size: CGFloat = 14f, bold: Boolean = false, c: Int = 0xFFFFFFFF.toInt()): UILabel {
        val l = UILabel(appContext!!)
        l.text = t; l.textColor = UIColor(c); l.font = if (bold) UIFont.boldSystemFont(size) else UIFont.systemFont(size)
        l.numberOfLines = 0
        l.frame = CGRect(0f, 0f, 300f, size + 8f)
        return l
    }

    private fun build() {
        card.setBackgroundColor(0xFF171717.toInt())
        addSubview(card)
        val x = PillButton("✕", null, C.CARD2, C.TEXT)
        x.onClick = { removeFromSuperview() }
        val head = UiView(appContext!!)
        head.addSubview(label("Custom sky", 22f, true))
        head.addSubview(x)
        rowsBox.addSubview(head)
        val blurb = label("Four colours blend from the top of the sky down to the ground. It lights and reflects everything 3D and shows as the sky.", 12f, false, 0xFFB3B3B3.toInt())
        blurb.numberOfLines = 3
        rowsBox.addSubview(blurb)
        for ((i, n) in names.withIndex()) {
            val w = UIColorWell(appContext!!)
            w.supportsAlpha = false; w.selectedColor = cols[i]
            w.onValueChanged = { cols[i] = w.selectedColor }
            val r = UiView(appContext!!)
            r.addSubview(label(n))
            r.addSubview(w)
            rowsBox.addSubview(r)
        }
        val sw = UISwitch(appContext!!)
        sw.isOn = sunOn
        sw.onValueChanged = { sunOn = sw.isOn }
        val sunRow = UiView(appContext!!)
        sunRow.addSubview(label("Sun glow at the horizon"))
        sunRow.addSubview(sw)
        rowsBox.addSubview(sunRow)
        val bl = label("Light strength")
        val valL = label(String.format(Locale.US, "%.1f", bright), 12f, false, 0xFFB3B3B3.toInt())
        valL.textAlignment = NSTextAlignment.right
        val s = UISlider(appContext!!)
        s.minValue = 0.3f; s.maxValue = 8f; s.value = bright
        s.onValueChanged = {
            bright = s.value
            valL.text = String.format(Locale.US, "%.1f", s.value)
        }
        val blRow = UiView(appContext!!)
        blRow.addSubview(bl); blRow.addSubview(s); blRow.addSubview(valL)
        rowsBox.addSubview(blRow)
        val ap = PillButton("Apply sky", null, accent, 0xFF000000.toInt())
        ap.onClick = { apply() }
        rowsBox.addSubview(ap)
        status.textColor = UIColor(0xFFB3B3B3.toInt()); status.font = UIFont.systemFont(12f); status.numberOfLines = 0
        rowsBox.addSubview(status)
        card.addSubview(rowsBox)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth(); val h = rectHeight()
        if (w < 10 || h < 10) return
        card.frame = CGRect(12f, 0f, w - 24f, h)
        card.setNeedsDisplay()
        var y = 24f
        for (r in rowsBox.subviews) {
            val rh = when {
                r.subviews.size == 2 && r.subviews[1] is UIColorWell -> 36f
                r.subviews.size == 2 && r.subviews[1] is UISwitch -> 32f
                r.subviews.size == 3 -> 36f
                r is UILabel -> 44f
                r is PillButton -> 44f
                else -> 36f
            }
            r.frame = CGRect(16f, y, card.rectWidth() - 32f, rh)
            when {
                r.subviews.size == 2 && r.subviews[1] is UIColorWell -> {
                    r.subviews[0].frame = CGRect(0f, 8f, r.rectWidth() - 60f, 20f)
                    r.subviews[1].frame = CGRect(r.rectWidth() - 48f, 4f, 44f, 28f)
                }
                r.subviews.size == 2 && r.subviews[1] is UISwitch -> {
                    r.subviews[0].frame = CGRect(0f, 6f, r.rectWidth() - 60f, 20f)
                    r.subviews[1].frame = CGRect(r.rectWidth() - 52f, 0f, 50f, 32f)
                }
                r.subviews.size == 3 -> {
                    r.subviews[0].frame = CGRect(0f, 8f, 110f, 20f)
                    r.subviews[1].frame = CGRect(114f, 2f, r.rectWidth() - 114f - 44f, 32f)
                    r.subviews[2].frame = CGRect(r.rectWidth() - 42f, 8f, 42f, 18f)
                }
                r.subviews.size == 2 -> {   // header
                    r.subviews[0].frame = CGRect(0f, 4f, 240f, 26f)
                    r.subviews[1].frame = CGRect(r.rectWidth() - 44f, 0f, 44f, 30f)
                }
            }
            y += rh + 12f
        }
        rowsBox.frame = CGRect(0f, 0f, card.rectWidth(), y)
        // vertically centered
        card.frame = CGRect(12f, (h - y) / 2, w - 24f, y + 8f)
    }

    private fun rgba(c: UIColor): FloatArray {
        val i = c.toInt()
        return floatArrayOf(((i shr 16) and 0xFF) / 255f, ((i shr 8) and 0xFF) / 255f, (i and 0xFF) / 255f)
    }

    /** Equirect picture: row 0 = zenith, middle = horizon, last = ground. */
    private fun image(): Bitmap? {
        val W = 1024; val H = 512
        val px = IntArray(W * H)
        val c = cols.map { rgba(it) }
        for (yy in 0 until H) {
            val v = yy.toFloat() / (H - 1).toFloat()       // 0 top, 1 bottom
            val col: FloatArray = when {
                v < 0.25f -> mix3(c[0], c[1], v / 0.25f)
                v < 0.5f -> mix3(c[1], c[2], (v - 0.25f) / 0.25f)
                v < 0.55f -> mix3(c[2], c[3], (v - 0.5f) / 0.05f)
                else -> c[3]
            }
            for (x in 0 until W) {
                var p = col.copyOf()
                if (sunOn) {
                    val u = x.toFloat() / W
                    val dx = min(abs(u - 0.25f), 1f - abs(u - 0.25f)) * 4f
                    val dy = (v - 0.45f) * 3f
                    val g = exp(-(dx * dx + dy * dy) * 6f)
                    p[0] += 1.0f * g * 0.8f; p[1] += 0.85f * g * 0.8f; p[2] += 0.6f * g * 0.8f
                }
                val o = (yy * W + x)
                px[o] = (0xFF shl 24) or
                    (min(255f, max0(p[0] * 255f)).toInt() shl 16) or
                    (min(255f, max0(p[1] * 255f)).toInt() shl 8) or
                    min(255f, max0(p[2] * 255f)).toInt()
            }
        }
        return Bitmap.createBitmap(px, W, H, Bitmap.Config.ARGB_8888)
    }

    private fun max0(v: Float): Float = if (v < 0f) 0f else v
    private fun mix3(a: FloatArray, b: FloatArray, t: Float): FloatArray =
        floatArrayOf(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)

    private fun apply() {
        val h = host
        val img = image()
        if (h == null || img == null) { status.text = "Could not build the sky."; return }
        val jpg = ByteArrayOutputStream().let { bo ->
            if (!img.compress(Bitmap.CompressFormat.JPEG, 95, bo)) null else bo.toByteArray()
        }
        val png = ByteArrayOutputStream().let { bo ->
            if (!img.compress(Bitmap.CompressFormat.PNG, 100, bo)) null else bo.toByteArray()
        }
        if (jpg == null || png == null) { status.text = "Could not build the sky."; return }
        val stamp = nowMs()
        val envPath = ProjectIO.writeDataIntoSandbox(png, "env_custom_$stamp.png")
        if (envPath == null) { status.text = "Could not save the sky."; return }
        GlobalEnv.path = envPath
        R3D.set("envGain", bright)
        val glb = EnvPanel.skyGLB(jpg)
        if (glb != null) {
            val sp = ProjectIO.writeDataIntoSandbox(glb, "sky_custom_$stamp.glb")
            if (sp != null) {
                for (old in Editor.scene.layers.filter { it.name.startsWith("Sky · ") }) Editor.scene.layers.removeAll { o -> o === old }
                h.addMedia(sp, com.saiki.motion.core.LayerType.MODEL)
                val l = Editor.scene.layers.lastOrNull { it.imagePath == sp }
                if (l != null) {
                    l.name = "Sky · Custom"
                    l.track("scale").base = 40f
                    l.m3Env = false
                }
            }
        }
        h.refreshPanel(); h.render()
        status.text = "Custom sky applied."
    }
}
