@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/TerrainNodeEditor.swift — wire-based terrain node graph: drag nodes, drag wires
// from an output dot to an input dot, live 3D preview and a "Render PBR" button that builds the
// terrain layer like the Terrain panel. The graph is stored on the layer (Layer.tgraph) so
// Properties > Terrain > Edit node reopens it.
// The graph model (TGraph/TGNode/TGWire) lives in core/Terrain.kt. SCNView is replaced by a small
// software-rendered mesh viewport (the app has no SceneKit; same camera + lambert shading).

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.saiki.motion.app.Dlg
import com.saiki.motion.app.EditorViewController
import com.saiki.motion.app.addMedia
import com.saiki.motion.app.refreshPanel
import com.saiki.motion.core.Editor
import com.saiki.motion.core.PLayer
import com.saiki.motion.core.PolyHaven
import com.saiki.motion.core.ProjectIO
import com.saiki.motion.core.TGraph
import com.saiki.motion.core.TKind
import com.saiki.motion.core.TNode
import com.saiki.motion.core.TerrainGraph
import com.saiki.motion.core.TerrainPBR
import com.saiki.motion.core.nowMs
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UISegmentedControl
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UISwitch
import com.saiki.motion.uikit.UITableView
import com.saiki.motion.uikit.UITableViewCell
import com.saiki.motion.uikit.UITableViewDataSource
import com.saiki.motion.uikit.UITableViewDelegate
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.fillRoundRect
import com.saiki.motion.uikit.measureText
import com.saiki.motion.uikit.strokeRoundRect
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// MARK: - canvas (nodes + wires drawn directly; touches handled here)

class TGCanvas(context: android.content.Context) : UiView(context) {
    var g: TGraph = TGraph.make()
    var selected = -1
    var offset = CGPoint(10f, 10f)
    var onChange: (() -> Unit)? = null
    var onSelect: ((Int) -> Unit)? = null

    private enum class Mode { none, pan, drag, wire }

    private class DragInfo(val id: Int, val dx: Float, val dy: Float)
    private class PanInfo(val dx: Float, val dy: Float)
    private class WireInfo(val id: Int, var pt: CGPoint)

    private var mode = Mode.none
    private var dragInfo: DragInfo? = null
    private var panInfo: PanInfo? = null
    private var wireInfo: WireInfo? = null
    private val accent = 0xFFFF8C14.toInt()

    companion object {
        const val W = 138f
        const val HEAD = 26f
        const val ROW = 24f
    }

    init {
        setBackgroundColor(0xFF171717.toInt())
        isMultipleTouchEnabled = false
        clipsToBounds = true
    }

    private fun size(n: com.saiki.motion.core.TGNode): com.saiki.motion.uikit.CGSize =
        com.saiki.motion.uikit.CGSize(W, HEAD + ROW * max(g.inputs(n), 1) + 6f)

    private fun rect(n: com.saiki.motion.core.TGNode): CGRect =
        CGRect((n.x + offset.x).toFloat(), (n.y + offset.y).toFloat(), size(n).width, size(n).height)

    private fun inPort(n: com.saiki.motion.core.TGNode, i: Int): CGPoint {
        val r = rect(n)
        return CGPoint(r.minX, r.minY + HEAD + ROW * (i + 0.5f))
    }

    private fun outPort(n: com.saiki.motion.core.TGNode): CGPoint {
        val r = rect(n)
        return CGPoint(r.maxX, r.minY + HEAD + ROW * 0.5f)
    }

    private fun dist(a: CGPoint, b: CGPoint): Float = sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y))

    private fun wirePath(a: CGPoint, b: CGPoint) {
        val c = UIGraphics.getCurrentContext() ?: return
        val k = max(40f, kotlin.math.abs(b.x - a.x) * 0.5f)
        c.beginPath()
        c.move(a)
        c.addCurve(to = b, control1 = CGPoint(a.x + k, a.y), control2 = CGPoint(b.x - k, b.y))
    }

    public override fun draw(rect0: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        // grid
        c.setStrokeColor(0x0AFFFFFF.toInt()); c.setLineWidth(1f)
        var gx = offset.x % 40f
        c.beginPath()
        while (gx < rectWidth()) { c.move(CGPoint(gx, 0f)); c.addLine(CGPoint(gx, rectHeight())); gx += 40f }
        var gy = offset.y % 40f
        while (gy < rectHeight()) { c.move(CGPoint(0f, gy)); c.addLine(CGPoint(rectWidth(), gy)); gy += 40f }
        c.strokePath()
        // wires
        for (w in g.wires) {
            val a = g.node(w.from) ?: continue
            val b = g.node(w.to) ?: continue
            wirePath(outPort(a), inPort(b, w.port))
            c.setStrokeColor(if (a.on) 0xFF73CCFF.toInt() else 0xFF737373.toInt())
            c.setLineWidth(3f)
            c.strokePath()
        }
        val wi = wireInfo
        if (wi != null) {
            val a = g.node(wi.id)
            if (a != null) {
                wirePath(outPort(a), wi.pt)
                c.setStrokeColor(accent); c.setLineWidth(3f); c.strokePath()
            }
        }
        // nodes
        for (n in g.nodes) {
            val r = rect(n)
            val k = TKind.fromRaw(n.kind)
            fillRoundRect(c, r, 9f, if (n.on) 0xFF2B2B2B.toInt() else 0xFF1C1C1C.toInt())
            // header
            c.saveGState()
            val head = CGRect(r.minX, r.minY, r.width, HEAD)
            val hp = com.saiki.motion.uikit.CGPath.roundedRect(head, 9f, 9f)
            c.addPath(hp); c.clipPath()
            val hc = if (n.kind < 0) 0xFF338C4D.toInt() else (if (k?.isGen == true) accent else 0xFF4D80D9.toInt())
            c.setFillColor(if (n.on) hc else (hc and 0x66FFFFFF.toInt()))
            c.fill(head)
            c.restoreGState()
            val nm = if (n.kind < 0) "Output" else (k?.title ?: "?")
            val p = UIFont.boldSystemFont(12f).toPaint()
            p.color = 0xFFFFFFFF.toInt()
            c.canvas.drawText(nm, r.minX + 8f, r.minY + 17f, p)
            if (n.id == selected) {
                c.setStrokeColor(accent); c.setLineWidth(2.5f)
                strokeRoundRect(c, r, 9f, 2.5f, accent)
            }
            for (i in 0 until g.inputs(n)) {
                val port = inPort(n, i)
                val label = if (n.kind < 0) (if (i == 0) "Height" else "Materials") else (if (g.inputs(n) == 2) (if (i == 0) "A" else "B") else "In")
                val sp = UIFont.systemFont(10f).toPaint()
                sp.color = 0xFFB3B3B3.toInt()
                c.canvas.drawText(label, port.x + 9f, port.y + 4f, sp)
                c.setFillColor(0xFFFFFFFF.toInt())
                c.fillEllipse(CGRect(port.x - 6f, port.y - 6f, 12f, 12f))
                c.setFillColor(if (g.source(n.id, i) != null) 0xFF73CCFF.toInt() else 0xFF4D4D4D.toInt())
                c.fillEllipse(CGRect(port.x - 3.5f, port.y - 3.5f, 7f, 7f))
            }
            if (g.hasOutput(n)) {
                val port = outPort(n)
                c.setFillColor(0xFFFFFFFF.toInt())
                c.fillEllipse(CGRect(port.x - 6f, port.y - 6f, 12f, 12f))
                c.setFillColor(accent)
                c.fillEllipse(CGRect(port.x - 3.5f, port.y - 3.5f, 7f, 7f))
            }
        }
    }

    // touches: output dot → new wire · input dot (wired) → pick the wire up · node → move · empty → pan the graph
    override fun touchesBegan(t: Set<UITouch>, e: UIEvent?) {
        val pt = t.firstOrNull()?.location(this) ?: return
        for (n in g.nodes.reversed()) {
            if (g.hasOutput(n) && dist(outPort(n), pt) < 24f) {
                mode = Mode.wire; wireInfo = WireInfo(n.id, pt)
                setNeedsDisplay(); return
            }
        }
        for (n in g.nodes.reversed()) {
            for (i in 0 until g.inputs(n)) {
                if (dist(inPort(n, i), pt) < 24f) {
                    val wi = g.wires.indexOfFirst { it.to == n.id && it.port == i }
                    if (wi >= 0) {
                        val from = g.wires[wi].from
                        g.wires.removeAt(wi)
                        mode = Mode.wire; wireInfo = WireInfo(from, pt)
                        onChange?.invoke(); setNeedsDisplay(); return
                    }
                }
            }
        }
        for (n in g.nodes.reversed()) {
            if (rect(n).contains(pt)) {
                selected = n.id; onSelect?.invoke(n.id)
                mode = Mode.drag
                dragInfo = DragInfo(n.id, pt.x - rect(n).minX, pt.y - rect(n).minY)
                setNeedsDisplay(); return
            }
        }
        mode = Mode.pan
        panInfo = PanInfo(pt.x - offset.x, pt.y - offset.y)
    }

    override fun touchesMoved(t: Set<UITouch>, e: UIEvent?) {
        val pt = t.firstOrNull()?.location(this) ?: return
        when (mode) {
            Mode.pan -> { val p = panInfo; if (p != null) offset = CGPoint(pt.x - p.dx, pt.y - p.dy) }
            Mode.drag -> {
                val d = dragInfo
                if (d != null) {
                    val i = g.nodes.indexOfFirst { it.id == d.id }
                    if (i >= 0) { g.nodes[i].x = (pt.x - d.dx - offset.x).toDouble(); g.nodes[i].y = (pt.y - d.dy - offset.y).toDouble() }
                }
            }
            Mode.wire -> { wireInfo?.pt = pt }
            Mode.none -> {}
        }
        setNeedsDisplay()
    }

    override fun touchesEnded(t: Set<UITouch>, e: UIEvent?) {
        val pt = t.firstOrNull()?.location(this)
        if (pt != null) {
            when (mode) {
                Mode.wire -> {
                    val wi = wireInfo
                    if (wi != null) {
                        var best: Triple<com.saiki.motion.core.TGNode, Int, Float>? = null
                        val srcPBR = g.node(wi.id)?.kind == TKind.pbr.raw
                        for (n in g.nodes) {
                            if (n.id == wi.id || g.feeds(n.id, wi.id)) continue      // never into itself or something that feeds it
                            for (i in 0 until g.inputs(n)) {
                                if ((n.kind < 0 && i == 1) != srcPBR) continue       // PBR nodes only plug into Output > Materials
                                val d = dist(inPort(n, i), pt)
                                if (d < 34f && (best == null || d < best!!.third)) best = Triple(n, i, d)
                            }
                        }
                        if (best != null) {
                            val (bn, bi, _) = best
                            if (bn.kind < 0 && bi == 1) g.wires.removeAll { it.from == wi.id && it.to == 0 && it.port == 1 }      // Materials takes many wires
                            else g.wires.removeAll { it.to == bn.id && it.port == bi }
                            g.wires.add(com.saiki.motion.core.TGWire(wi.id, bn.id, bi))
                        }
                        onChange?.invoke()
                    }
                }
                Mode.pan -> {
                    val p = panInfo
                    if (p != null && dist(CGPoint(pt.x - offset.x, pt.y - offset.y), CGPoint(p.dx, p.dy)) < 4f) {
                        selected = -1; onSelect?.invoke(-1)
                    }
                }
                Mode.drag -> onChange?.invoke()
                Mode.none -> {}
            }
        }
        mode = Mode.none; dragInfo = null; panInfo = null; wireInfo = null
        setNeedsDisplay()
    }

    override fun touchesCancelled(t: Set<UITouch>, e: UIEvent?) {
        mode = Mode.none; dragInfo = null; panInfo = null; wireInfo = null
        setNeedsDisplay()
    }
}

// MARK: - editor

class TerrainNodeEditor(private val host: EditorViewController, graph: TGraph, private val layer3: com.saiki.motion.core.Layer?, private val parentPanel: TerrainPanel?) : UiView(appContext!!) {
    private val canvas = TGCanvas(appContext!!)
    private val scn = object : UiView(appContext!!) {
        var mesh: Triple<FloatArray, FloatArray, IntArray>? = null      // pos, col(rgba), idx
        var camYaw = 0.6f
        var camPitch = -0.55f
        public override fun draw(rect: CGRect) {
            val c = UIGraphics.getCurrentContext() ?: return
            c.setFillColor(0xFF1A2129.toInt())
            c.fill(CGRect(0f, 0f, rect.width, rect.height))
            val m = mesh ?: return
            // software: rotate + ortho project + painter sort + flat lambert
            val (pos, col, idx) = m
            val cy = cos(camYaw); val sy = sin(camYaw)
            val cp = cos(camPitch); val sp = sin(camPitch)
            val s = min(rect.width, rect.height) * 0.8f
            val pts = arrayOfNulls<FloatArray>(pos.size / 3)
            for (i in 0 until pos.size / 3) {
                val x = pos[i * 3]; val y = pos[i * 3 + 1]; val z = pos[i * 3 + 2]
                val x1 = x * cy - z * sy; val z1 = x * sy + z * cy
                val y1 = y * cp - z1 * sp; val z2 = y * sp + z1 * cp
                pts[i] = floatArrayOf(rect.width / 2 + x1 * s, rect.height / 2 - y1 * s, z2)
            }
            val order = (0 until idx.size / 3).sortedByDescending { k ->
                val a = pts[idx[k * 3]]; val b = pts[idx[k * 3 + 1]]; val d = pts[idx[k * 3 + 2]]
                ((a?.get(2) ?: 0f) + (b?.get(2) ?: 0f) + (d?.get(2) ?: 0f)) / 3f
            }
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            val path = android.graphics.Path()
            for (k in order) {
                val ia = idx[k * 3]; val ib = idx[k * 3 + 1]; val ic = idx[k * 3 + 2]
                val a = pts[ia] ?: continue; val b = pts[ib] ?: continue; val d = pts[ic] ?: continue
                // face colour from vertex colour (TerrainGraph.colour already lit on iOS; here flat)
                val r = ((col[ia * 4] + col[ib * 4] + col[ic * 4]) / 3f * 255).toInt()
                val gg = ((col[ia * 4 + 1] + col[ib * 4 + 1] + col[ic * 4 + 1]) / 3f * 255).toInt()
                val bb = ((col[ia * 4 + 2] + col[ib * 4 + 2] + col[ic * 4 + 2]) / 3f * 255).toInt()
                paint.color = (0xFF shl 24) or (r shl 16) or (gg shl 8) or bb
                paint.style = android.graphics.Paint.Style.FILL
                path.reset()
                path.moveTo(a[0], a[1]); path.lineTo(b[0], b[1]); path.lineTo(d[0], d[1]); path.close()
                c.canvas.drawPath(path, paint)
            }
        }

        override fun touchesMoved(touches: Set<UITouch>, with: UIEvent?) {
            val t = touches.firstOrNull() ?: return
            camYaw += (t.location(this).x - lastDrag.x) * 0.01f
            camPitch = max(-1.4f, min(1.4f, camPitch + (t.location(this).y - lastDrag.y) * 0.01f))
            lastDrag = t.location(this)
            setNeedsDisplay()
        }

        override fun touchesBegan(touches: Set<UITouch>, with: UIEvent?) {
            lastDrag = touches.firstOrNull()?.location(this) ?: CGPoint(0f, 0f)
        }

        private var lastDrag = CGPoint(0f, 0f)
    }
    private val params = UiView(appContext!!)
    private val paramScroll = UIScrollView(appContext!!)
    private val status = UILabel(appContext!!)
    private var work: Runnable? = null
    private val workHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var timer: java.util.Timer? = null
    private var panel: TerrainPanel? = null
    private var rendering = false
    private val body = UiView(appContext!!)
    private val left = UiView(appContext!!)
    private val right = UiView(appContext!!)
    private var lastLand: Boolean? = null
    private val accent = 0xFFFF8C14.toInt()

    companion object {
        fun present(host: EditorViewController, view: UiView, graph: TGraph, layer: com.saiki.motion.core.Layer?, parent: TerrainPanel?) {
            if (view.subviews.any { it is TerrainNodeEditor }) return
            val v = TerrainNodeEditor(host, graph, layer, parent)
            view.addSubview(v)
            v.frame = CGRect(0f, 0f, view.rectWidth(), view.rectHeight())
        }
    }

    init {
        setBackgroundColor(0xFF0D0D0D.toInt())
        canvas.g = graph
        canvas.onChange = { changed() }
        canvas.onSelect = { rebuildParams() }
        build(); rebuildParams(); updatePreview()
    }

    private fun build() {
        val title = UILabel(appContext!!)
        title.text = "Terrain nodes"; title.textColor = UIColor(0xFFFFFFFF.toInt()); title.font = UIFont.boldSystemFont(16f)
        title.frame = CGRect(0f, 0f, 180f, 22f)
        val close = PillButton("✕", null, 0x00000000.toInt(), 0xFF999999.toInt())
        close.onClick = { removeFromSuperview() }
        val add = PillButton("＋ Node", null, 0x00000000.toInt(), accent)
        add.onClick = { showPalette() }
        val render = PillButton("Render PBR", null, accent, 0xFF000000.toInt())
        render.onClick = { renderPBR() }
        val bar = UiView(appContext!!)
        bar.addSubview(title); bar.addSubview(add); bar.addSubview(render); bar.addSubview(close)
        status.textColor = UIColor(0xFFB3B3B3.toInt()); status.font = UIFont.systemFont(11f)
        status.text = "Drag a node's orange dot onto another node's input dot to wire. Drag empty space to move around."
        status.numberOfLines = 0
        status.frame = CGRect(0f, 0f, 300f, 30f)
        paramScroll.setBackgroundColor(0xFF1A1A1A.toInt())
        paramScroll.addSubview(params)
        body.addSubview(scn)
        body.addSubview(status)
        body.addSubview(canvas)
        body.addSubview(paramScroll)
        addSubview(bar)
        addSubview(body)
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth(); val h = rectHeight()
        if (w < 10 || h < 10) return
        val top = safeAreaInsets.top
        val bar = subviews[0]
        bar.frame = CGRect(14f, top + 4f, w - 28f, 40f)
        var bx = 0f
        for (b in bar.subviews) {
            if (b is UILabel) { b.frame = CGRect(0f, 9f, 150f, 22f); continue }
            val bw = com.saiki.motion.uikit.measureText((b as PillButton).text, 14f, true) + 30f
            b.frame = CGRect(bar.rectWidth() - bx - bw, 4f, bw, 32f)
            bx += bw + 8f
        }
        body.frame = CGRect(0f, top + 46f, w, h - top - 46f)
        val land = w > h
        if (land == lastLand) return
        lastLand = land
        if (land) {
            // 3D preview + properties on the left, the wire canvas on the right
            val lw = body.rectWidth() * 0.42f
            scn.frame = CGRect(0f, 0f, lw, body.rectHeight() - 190f)
            paramScroll.frame = CGRect(0f, body.rectHeight() - 190f, lw, 190f)
            status.frame = CGRect(lw + 6f, 0f, body.rectWidth() - lw - 6f, 30f)
            canvas.frame = CGRect(lw + 6f, 32f, body.rectWidth() - lw - 6f, body.rectHeight() - 32f)
        } else {
            scn.frame = CGRect(0f, 0f, body.rectWidth(), body.rectHeight() * 0.30f)
            status.frame = CGRect(8f, body.rectHeight() * 0.30f + 2f, body.rectWidth() - 16f, 30f)
            canvas.frame = CGRect(0f, body.rectHeight() * 0.30f + 34f, body.rectWidth(), body.rectHeight() * 0.70f - 224f)
            paramScroll.frame = CGRect(0f, body.rectHeight() - 190f, body.rectWidth(), 190f)
        }
        layoutParams()
    }

    private fun layoutParams() {
        var y = 10f
        for (v in params.subviews) {
            val vh = when (v) {
                is UILabel -> v.font.size + 10f
                is UISlider -> 34f
                is UISegmentedControl -> 32f
                is UISwitch -> 32f
                else -> 32f
            }
            v.frame = CGRect(14f, y, max(paramScroll.rectWidth() - 28f, 10f), vh)
            v.onLayout?.invoke(max(paramScroll.rectWidth() - 28f, 10f))
            if (v.subviews.size == 2 && v.subviews[1] is UISegmentedControl) {
                v.subviews[0].frame = CGRect(0f, 8f, 110f, 18f)
                v.subviews[1].frame = CGRect(116f, 0f, v.rectWidth() - 116f, 32f)
            }
            y += vh + 8f
        }
        params.frame = CGRect(0f, 0f, paramScroll.rectWidth(), y + 10f)
        paramScroll.contentSize = com.saiki.motion.uikit.CGSize(paramScroll.rectWidth(), y + 10f)
    }

    // MARK: graph edits

    private fun addNode(k: TKind) {
        val x = -canvas.offset.x + canvas.rectWidth() / 2 - 70 + (canvas.g.nodes.size % 4) * 14
        val y = -canvas.offset.y + 40 + (canvas.g.nodes.size % 5) * 14
        val id = canvas.g.add(k, x.toDouble(), y.toDouble())
        canvas.selected = id
        canvas.setNeedsDisplay(); rebuildParams(); changed()
    }

    private fun showPalette() {
        if (subviews.any { it is TGPalette }) return
        val v = TGPalette(appContext!!)
        addSubview(v)
        v.frame = CGRect(0f, 0f, rectWidth(), rectHeight())
        v.onPick = { k -> addNode(k) }
    }

    // MARK: image import (files)

    private var pickDone: ((Bitmap) -> Unit)? = null

    private fun importImage(done: (Bitmap) -> Unit) {
        pickDone = done
        com.saiki.motion.app.DocPicker.pick { uri ->
            try {
                val bytes = appContext!!.contentResolver.openInputStream(uri)?.readBytes()
                val im = bytes?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                if (im != null) pickDone?.invoke(im)
            } catch (_: Exception) { }
        }
    }

    /** saves the image into the project's media folder (max 2048 px) and returns its path */
    private fun store(im: Bitmap): String? {
        val k = min(1f, 2048f / max(im.width.toFloat(), im.height.toFloat()))
        var out = im
        if (k < 1f) {
            val w = (im.width * k).toInt(); val h = (im.height * k).toInt()
            out = Bitmap.createScaledBitmap(im, w, h, true)
        }
        val bo = java.io.ByteArrayOutputStream()
        if (!out.compress(Bitmap.CompressFormat.PNG, 100, bo)) return null
        return ProjectIO.writeDataIntoSandbox(bo.toByteArray(), "terrain_tex_${nowMs()}.png")
    }

    private fun setNode(id: Int, f: (com.saiki.motion.core.TGNode) -> Unit) {
        val i = canvas.g.nodes.indexOfFirst { it.id == id }
        if (i >= 0) f(canvas.g.nodes[i])
        rebuildParams(); changed()
    }

    private fun changed() {
        canvas.setNeedsDisplay(); updatePreview()
    }

    private fun rebuildParams() {
        params.subviews.toList().forEach { it.removeFromSuperview() }
        fun lab(t: String, c: Int = 0xFFFFFFFF.toInt(), s: Float = 13f, bold: Boolean = false): UILabel {
            val l = UILabel(appContext!!)
            l.text = t; l.textColor = UIColor(c); l.font = if (bold) UIFont.boldSystemFont(s) else UIFont.systemFont(s)
            l.numberOfLines = 0
            return l
        }
        fun slider(name: String, lo: Float, hi: Float, v: Float, whole: Boolean, set: (Float) -> Unit) {
            val l = lab(String.format(Locale.US, if (whole) "%s: %.0f" else "%s: %.2f", name, v), 0xFFCCCCCC.toInt(), 12f)
            val s = UISlider(appContext!!)
            s.minValue = lo; s.maxValue = hi; s.value = v
            s.onValueChanged = {
                val x = if (whole) s.value.toInt().toFloat() else s.value
                l.text = String.format(Locale.US, if (whole) "%s: %.0f" else "%s: %.2f", name, x)
                set(x); changed()
            }
            params.addSubview(l); params.addSubview(s)
        }
        val id = canvas.selected
        val n = canvas.g.node(id)
        if (id < 0 || n == null) {
            params.addSubview(lab("Select a node to edit it. Tap Output for height, edges, sea level and scale.", 0xFF999999.toInt(), 12f))
            layoutParams()
            return
        }
        if (n.kind < 0) {
            params.addSubview(lab("Output", accent, 13f, true))
            slider("Height", 0.05f, 1f, canvas.g.height, false) { canvas.g.height = it }
            slider("Edge fade", 0f, 1f, canvas.g.edge, false) { canvas.g.edge = it }
            slider("Sea level", 0f, 0.6f, canvas.g.sea, false) { canvas.g.sea = it }
            slider("Feature scale", 0.3f, 3f, canvas.g.scale, false) { canvas.g.scale = it }
            slider("Seed", 1f, 99f, canvas.g.seed, true) { canvas.g.seed = it }
            layoutParams()
            return
        }
        val k = TKind.fromRaw(n.kind) ?: return
        params.addSubview(lab(k.title, accent, 13f, true))
        for ((pi, d) in k.params.withIndex()) {
            if (pi >= n.p.size) continue
            if (d.opts != null) {
                val seg = UISegmentedControl(d.opts)
                seg.selectedSegmentIndex = n.p[pi].toInt()
                seg.onValueChanged = {
                    val i2 = canvas.g.nodes.indexOfFirst { it.id == id }
                    if (i2 >= 0) canvas.g.nodes[i2].p[pi] = seg.selectedSegmentIndex.toFloat()
                    changed()
                }
                params.addSubview(lab(d.name, 0xFFCCCCCC.toInt(), 12f))
                params.addSubview(seg)
            } else {
                val whole = d.hi - d.lo >= 8f
                slider(d.name, d.lo, d.hi, n.p[pi], whole) { v ->
                    val i2 = canvas.g.nodes.indexOfFirst { it.id == id }
                    if (i2 >= 0) canvas.g.nodes[i2].p[pi] = v
                }
            }
        }
        fun fileRow(title: String, path: String?, set: (String?) -> Unit) {
            val has = !path.isNullOrEmpty()
            val b = PillButton(if (has) "$title  ✓  Replace" else "$title  — import", null, 0x00000000.toInt(), if (has) 0xFF66D980.toInt() else accent)
            b.textSize = 13f
            b.onClick = {
                importImage { im ->
                    val p = store(im)
                    if (p != null) set(p)
                }
            }
            b.frame = CGRect(0f, 0f, 200f, 30f)
            val r = UiView(appContext!!)
            r.addSubview(b)
            if (has) {
                val x = PillButton("✕", null, 0x00000000.toInt(), 0xFF999999.toInt())
                x.onClick = { set(null) }
                x.frame = CGRect(0f, 0f, 28f, 28f)
                r.addSubview(x)
                r.onLayout = { w -> b.frame = CGRect(0f, 0f, w - 34f, 30f); x.frame = CGRect(w - 30f, 2f, 28f, 28f) }
            }
            params.addSubview(r)
        }
        if (k == TKind.heightTex) fileRow("Height map image", n.img) { p -> setNode(id) { it.img = p } }
        if (k == TKind.pbr) {
            val ph = PillButton(if (n.tex != null && (n.files ?: listOf("")).all { it.isEmpty() }) "Poly Haven: ${n.texName ?: n.tex ?: ""}" else "Pick a Poly Haven texture…", null, 0x00000000.toInt(), accent)
            ph.textSize = 13f
            ph.onClick = {
                val tp = TGTexPicker(appContext!!)
                addSubview(tp)
                tp.frame = CGRect(0f, 0f, rectWidth(), rectHeight())
                tp.onPick = { id2, name -> setNode(id) { it.tex = id2; it.texName = name; it.files = null } }
            }
            params.addSubview(ph)
            params.addSubview(lab("…or import your own maps (Diffuse is required):", 0xFF999999.toInt(), 11f))
            for ((si, nm) in listOf("Diffuse", "Normal", "Roughness", "AO", "Height").withIndex()) {
                val cur = n.files?.getOrNull(si) ?: ""
                fileRow(nm, cur) { p ->
                    setNode(id) { nd ->
                        val f = (nd.files ?: List(5) { "" }).toMutableList()
                        f[si] = p ?: ""
                        nd.files = f
                        if (p != null) nd.tex = null
                    }
                }
            }
        }
        val on = UISwitch(appContext!!)
        on.isOn = n.on
        on.onValueChanged = {
            val i2 = canvas.g.nodes.indexOfFirst { it.id == id }
            if (i2 >= 0) canvas.g.nodes[i2].on = on.isOn
            changed()
        }
        val onRow = UiView(appContext!!)
        onRow.addSubview(lab("Enabled (off = bypass)"))
        onRow.addSubview(on)
        onRow.onLayout = { w ->
            onRow.subviews[0].frame = CGRect(0f, 8f, w - 60f, 20f)
            onRow.subviews[1].frame = CGRect(w - 54f, 0f, 50f, 32f)
        }
        params.addSubview(onRow)
        val dup = PillButton("Duplicate", null, 0x00000000.toInt(), accent)
        dup.textSize = 13f
        dup.onClick = {
            val o = canvas.g.node(id)
            val kk = if (o != null) TKind.fromRaw(o.kind) else null
            if (o != null && kk != null) {
                val nid = canvas.g.add(kk, o.x + 24, o.y + 34)
                val i2 = canvas.g.nodes.indexOfFirst { it.id == nid }
                if (i2 >= 0) canvas.g.nodes[i2].p = o.p.copyOf()
                canvas.selected = nid; rebuildParams(); changed()
            }
        }
        val del = PillButton("Delete", null, 0x00000000.toInt(), 0xFFFF6666.toInt())
        del.textSize = 13f
        del.onClick = {
            canvas.g.nodes.removeAll { it.id == id }
            canvas.g.wires.removeAll { it.from == id || it.to == id }
            canvas.selected = -1; rebuildParams(); changed()
        }
        val row = UiView(appContext!!)
        row.addSubview(dup); row.addSubview(del)
        row.onLayout = { w -> dup.frame = CGRect(0f, 0f, (w - 8f) / 2f, 30f); del.frame = CGRect((w - 8f) / 2f + 8f, 0f, (w - 8f) / 2f, 30f) }
        params.addSubview(row)
        layoutParams()
    }

    // MARK: 3D preview

    private fun updatePreview() {
        work?.let { workHandler.removeCallbacks(it) }
        val g = canvas.g.copy()
        val r = Runnable {
            val res = 72
            val R = res + 1
            val f = g.field(res)
            val amp = g.height * 0.5f
            val pos = FloatArray(R * R * 3); val col = FloatArray(R * R * 4)
            val idx = IntArray(res * res * 6)
            val step = 1f / res
            var q = 0
            for (j in 0 until R) for (i in 0 until R) {
                val y = f[i + j * R] * amp
                pos[q * 3] = i * step - 0.5f; pos[q * 3 + 1] = y; pos[q * 3 + 2] = j * step - 0.5f
                val dx = f[min(i + 1, res) + j * R] - f[max(i - 1, 0) + j * R]
                val dz = f[i + min(j + 1, res) * R] - f[i + max(j - 1, 0) * R]
                val nx = -dx * amp / ((min(i + 1, res) - max(i - 1, 0)).toFloat() * step)
                val nz = -dz * amp / ((min(j + 1, res) - max(j - 1, 0)).toFloat() * step)
                val len = sqrt(nx * nx + 1f + nz * nz)
                val ny = 1f / len
                val c = TerrainGraph.colour(f[i + j * R], 1f - ny, g.sea)
                // lambert with L = normalize(-0.5, 0.7, -0.5)
                val Lx = -0.5f / 0.9950f; val Ly = 0.7f / 0.9950f; val Lz = -0.5f / 0.9950f
                val sh = 0.35f + 0.75f * max(0f, (nx / len) * Lx + ny * Ly + (nz / len) * Lz)
                col[q * 4] = c.x * sh; col[q * 4 + 1] = c.y * sh; col[q * 4 + 2] = c.z * sh; col[q * 4 + 3] = 1f
                q++
            }
            var t = 0
            for (j in 0 until res) for (i in 0 until res) {
                val a = i + j * R
                idx[t++] = a; idx[t++] = a + R; idx[t++] = a + 1
                idx[t++] = a + 1; idx[t++] = a + R; idx[t++] = a + R + 1
            }
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                scn.mesh = Triple(pos, col, idx)
                scn.setNeedsDisplay()
            }
        }
        work = r
        workHandler.postDelayed(r, 100)
    }

    // MARK: render with PBR

    private fun renderPBR() {
        if (rendering) return
        rendering = true
        status.text = "Preparing PBR layers…"
        work?.let { workHandler.removeCallbacks(it) }
        scn.mesh = null; scn.setNeedsDisplay()
        isUserInteractionEnabled = false
        val g = canvas.g.copy()
        TerrainGraph.bakedEval = { res, sc, sd -> g.raw(res, sc, sd) }
        TerrainPanel.nodes = arrayListOf(TNode(TKind.baked))
        TerrainPanel.height = g.height; TerrainPanel.edge = g.edge; TerrainPanel.sea = g.sea
        TerrainPanel.genScale = g.scale; TerrainPanel.genSeed = g.seed
        TerrainPanel.pendingGraph = g.json(); TerrainPanel.replacing = layer3
        // PBR material nodes wired into Output > Materials become the terrain's PBR layers
        val nodeLayers = ArrayList<PLayer>()
        val local = HashMap<String, PolyHaven.Maps>()
        for (n in g.nodes) {
            if (n.kind != TKind.pbr.raw || !n.on) continue
            if (!g.wires.any { it.from == n.id && it.to == 0 && it.port == 1 }) continue
            val l = PLayer(TerrainPanel.nextLayer)
            TerrainPanel.nextLayer += 1
            val qq = n.p
            if (qq.size >= 7) {
                l.tiling = qq[0]; l.strength = qq[1]; l.hLo = qq[2]; l.hHi = max(qq[3], qq[2] + 0.02f)
                l.hSoft = qq[4]; l.sLo = qq[5]; l.sHi = max(qq[6], qq[5] + 0.02f)
            }
            val files = n.files
            if (files != null && files.indices.contains(0) && files[0].isNotEmpty()) {
                fun im(i: Int): Bitmap? = if (files.indices.contains(i) && files[i].isNotEmpty()) BitmapFactory.decodeFile(files[i]) else null
                val key = "local:${n.id}"
                local[key] = PolyHaven.Maps(im(0), im(1), im(2), null, im(3), im(4))
                l.tex = key; l.texName = "Imported"
            } else if (n.tex != null) {
                val t: String = n.tex!!
                l.tex = t; l.texName = n.texName ?: t
            } else continue
            nodeLayers.add(l)
        }
        TerrainPanel.localSets = local
        if (nodeLayers.isNotEmpty()) TerrainPanel.layers = nodeLayers.toMutableList()
        val p = TerrainPanel(host)
        panel = p
        val go = {
            p.addTap()
            timer = java.util.Timer()
            timer?.scheduleAtFixedRate(object : java.util.TimerTask() {
                override fun run() {
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        status.text = p.statusText
                        if (!p.isBusy) {
                            timer?.cancel()
                            parentPanel?.removeFromSuperview()
                            removeFromSuperview()
                        }
                    }
                }
            }, 350L, 350L)
        }
        if (TerrainPanel.layers.isNotEmpty()) { go(); return }
        // no PBR layers set up yet: pick sand / grass / rock / snow from Poly Haven by height and slope
        PolyHavenNet.list { list ->
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                fun pickx(keys: List<String>): Pair<String, String>? {
                    for (k in keys) {
                        val m = list.firstOrNull { it.name.lowercase().contains(k) }
                        if (m != null) return m.id to m.name
                    }
                    return null
                }
                // keys, height lo/hi, slope lo/hi
                val defs = listOf(
                    listOf("sand") to floatArrayOf(0f, 0.22f, 0f, 0.5f),
                    listOf("grass", "forest", "ground") to floatArrayOf(0.12f, 0.65f, 0f, 0.5f),
                    listOf("rock", "cliff") to floatArrayOf(0.5f, 1f, 0f, 1f),
                    listOf("rock", "cliff") to floatArrayOf(0f, 1f, 0.4f, 1f),
                    listOf("snow") to floatArrayOf(0.82f, 1f, 0f, 0.45f))
                for (d in defs) {
                    val m = pickx(d.first) ?: continue
                    val l = PLayer(TerrainPanel.nextLayer)
                    TerrainPanel.nextLayer += 1
                    l.tex = m.first; l.texName = m.second
                    l.hLo = d.second[0]; l.hHi = d.second[1]; l.sLo = d.second[2]; l.sHi = d.second[3]
                    TerrainPanel.layers.add(l)
                }
                go()
            }
        }
    }
}

// MARK: - add-node palette (organised by category, searchable)

private val tgAccent = 0xFFFF8C14.toInt()

class TGPalette(context: android.content.Context) : UiView(context) {
    class Cat(val name: String, val color: Int, val kinds: List<TKind>)

    val cats = listOf(
        Cat("Generate", 0xFFFF8C14.toInt(), listOf(TKind.noise, TKind.ridged, TKind.billow, TKind.hills, TKind.voronoi, TKind.waves, TKind.dunes, TKind.gradient, TKind.craters, TKind.constant)),
        Cat("Shape", 0xFF4D8CF2.toInt(), listOf(TKind.warp, TKind.terrace, TKind.curve, TKind.level, TKind.smooth, TKind.erode, TKind.island, TKind.invert, TKind.slope, TKind.sharpen)),
        Cat("Combine", 0xFFB373F2.toInt(), listOf(TKind.blend)),
        Cat("Import", 0xFF4DBF73.toInt(), listOf(TKind.heightTex, TKind.pbr)))

    var onPick: ((TKind) -> Unit)? = null
    private val sheet = UiView(appContext!!)
    private val grid = UIScrollView(appContext!!)
    private val search = com.saiki.motion.uikit.UITextField(appContext!!)
    private val chipRow = UiView(appContext!!)
    private var cat = 0
    private val cards = ArrayList<UiView>()

    init {
        setBackgroundColor(0x80000000.toInt())
        onClick = { dismiss() }
        sheet.setBackgroundColor(0xFF1A1A1A.toInt())
        addSubview(sheet)
        val title = UILabel(appContext!!)
        title.text = "Add node"; title.textColor = UIColor(0xFFFFFFFF.toInt()); title.font = UIFont.boldSystemFont(17f)
        val x = PillButton("✕", null, 0x00000000.toInt(), 0xFF999999.toInt())
        x.onClick = { dismiss() }
        search.placeholder = "Search nodes"
        search.backing.setTextColor(android.graphics.Color.WHITE)
        search.backing.setBackgroundColor(0xFF2E2E2E.toInt())
        search.onTextChanged = { rebuild() }
        search.onReturn = { search.backing.clearFocus() }
        val head = UiView(appContext!!)
        head.addSubview(title); head.addSubview(x)
        val chipScroll = UIScrollView(appContext!!)
        chipScroll.showsHorizontalScrollIndicator = false
        chipScroll.addSubview(chipRow)
        val col = UiView(appContext!!)
        col.addSubview(head); col.addSubview(search); col.addSubview(chipScroll); col.addSubview(grid)
        sheet.addSubview(col)
        var cx = 0f
        for ((i, c) in cats.withIndex()) {
            val b = PillButton(c.name, null, 0xFF2E2E2E.toInt(), C.TEXT)
            b.textSize = 13f
            b.onClick = { cat = i; search.text = ""; rebuild() }
            chipRow.addSubview(b)
            val bw = com.saiki.motion.uikit.measureText(c.name, 13f, true) + 28f
            b.frame = CGRect(cx, 2f, bw, 30f)
            cx += bw + 8f
        }
        rebuild()
        onLayout = { _ -> layoutAll() }
    }

    private fun dismiss() { removeFromSuperview() }

    private fun rebuild() {
        val q = search.text.lowercase()
        for ((i, v) in chipRow.subviews.withIndex()) {
            val b = v as? PillButton ?: continue
            val on = q.isEmpty() && i == cat
            b.fillColor = if (on) cats[i].color else 0xFF2E2E2E.toInt()
            // title colour: black on the accent chip, white otherwise
            b.setColors(if (on) 0xFF000000.toInt() else C.TEXT)
        }
        cards.forEach { it.removeFromSuperview() }
        cards.clear()
        val list: List<Pair<TKind, Int>> = if (q.isEmpty()) cats[cat].kinds.map { it to cats[cat].color }
        else cats.flatMap { c -> c.kinds.map { it to c.color } }.filter { it.first.title.lowercase().contains(q) || it.first.desc.lowercase().contains(q) }
        for ((k, color) in list) {
            val b = object : TapView() {
                public override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), 12f, 0xFF2B2B2B.toInt())
                    c.setFillColor(color)
                    c.fill(CGRect(0f, 0f, rect.width, 3f))
                    Icons.draw(c, "waveform", 22f, 26f, 20f, color)
                    drawText(k.title, 10f, 52f, color = C.TEXT, size = 13f, bold = true, align = NSTextAlignment.left)
                    drawText(k.desc, 10f, 70f, color = C.DIM, size = 10f, bold = false, align = NSTextAlignment.left)
                }
            }
            b.setBackgroundColor(0x00000000)
            b.onClick = { removeFromSuperview(); onPick?.invoke(k) }
            b.frame = CGRect(0f, 0f, 160f, 92f)
            grid.addSubview(b)
            cards.add(b)
        }
        layoutAll()
    }

    private fun layoutAll() {
        val w = rectWidth(); val h = rectHeight()
        if (w < 10 || h < 10) return
        sheet.frame = CGRect(0f, h * 0.3f, w, h * 0.7f)
        val col = sheet.subviews.firstOrNull() ?: return
        var y = 14f
        val head = col.subviews[0]
        head.frame = CGRect(14f, y, w - 28f, 30f)
        head.subviews[0].frame = CGRect(0f, 4f, 200f, 24f)
        head.subviews[1].frame = CGRect(w - 28f - 40f, 0f, 40f, 30f)
        y += 38f
        search.frame = CGRect(14f, y, w - 28f, 36f)
        y += 44f
        val chipScroll = col.subviews[2]
        chipScroll.frame = CGRect(0f, y, w, 34f)
        y += 40f
        grid.frame = CGRect(0f, y, w, sheet.rectHeight() - y - 8f)
        // cards grid
        val gw = grid.rectWidth()
        val cols = max(2, (gw / 150f).toInt())
        val gap = 10f
        val cw = (gw - gap * (cols - 1)) / cols
        val ch = 92f
        for ((i, b) in cards.withIndex()) {
            b.frame = CGRect((i % cols) * (cw + gap), (i / cols) * (ch + gap), cw, ch)
        }
        grid.contentSize = com.saiki.motion.uikit.CGSize(gw, ((cards.size + cols - 1) / cols) * (ch + gap))
    }
}

// MARK: - Poly Haven texture picker

class TGTexPicker(context: android.content.Context) : UiView(context) {
    var onPick: ((String, String) -> Unit)? = null
    private val table = UITableView(appContext!!)
    private val search = com.saiki.motion.uikit.UITextField(appContext!!)
    private var all: List<Pair<String, String>> = emptyList()
    private var shown: List<Pair<String, String>> = emptyList()

    init {
        setBackgroundColor(0xF20D0D0D.toInt())
        val title = UILabel(appContext!!)
        title.text = "Poly Haven textures"; title.textColor = UIColor(0xFFFFFFFF.toInt()); title.font = UIFont.boldSystemFont(17f)
        val x = PillButton("✕", null, 0x00000000.toInt(), 0xFF999999.toInt())
        x.onClick = { removeFromSuperview() }
        search.backing.setTextColor(android.graphics.Color.WHITE)
        search.backing.setBackgroundColor(0xFF2E2E2E.toInt())
        search.placeholder = "Search (rock, sand, grass, snow…)"
        search.onTextChanged = { filter() }
        table.dataSource = object : UITableViewDataSource {
            override fun numberOfRows(t: UITableView, section: Int): Int = shown.size
            override fun cellForRow(t: UITableView, row: Int): UITableViewCell {
                val c = UITableViewCell(appContext!!)
                c.setBackgroundColor(0x00000000)
                c.textLabel?.text = shown[row].second
                c.textLabel?.textColor = UIColor(0xFFFFFFFF.toInt())
                return c
            }
        }
        table.delegate = object : UITableViewDelegate {
            override fun didSelectRow(t: UITableView, row: Int) {
                val m = shown[row]
                removeFromSuperview()
                onPick?.invoke(m.first, m.second)
            }
        }
        table.rowHeight = 48f
        val head = UiView(appContext!!)
        head.addSubview(title); head.addSubview(x)
        val col = UiView(appContext!!)
        col.addSubview(head); col.addSubview(search); col.addSubview(table)
        addSubview(col)
        onLayout = { _ ->
            val w = rectWidth(); val h = rectHeight()
            if (w >= 10 && h >= 10) {
            val top = safeAreaInsets.top
            var y = top + 8f
            head.frame = CGRect(14f, y, w - 28f, 30f)
            head.subviews[0].frame = CGRect(0f, 4f, 240f, 24f)
            head.subviews[1].frame = CGRect(w - 28f - 40f, 0f, 40f, 30f)
            y += 38f
            search.frame = CGRect(14f, y, w - 28f, 36f)
            y += 44f
            table.frame = CGRect(0f, y, w, h - y)
            table.reloadData()
            }
        }
        PolyHavenNet.list { l ->
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                all = l.map { it.id to it.name }
                filter()
            }
        }
    }

    private fun filter() {
        val q = search.text.lowercase()
        shown = if (q.isEmpty()) all else all.filter { it.second.lowercase().contains(q) || it.first.lowercase().contains(q) }
        table.reloadData()
    }
}
