@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/TerrainPanel.swift — Scene 3D "+" > Terrain. Tabs: Shape (output, presets) ·
// Nodes (a stack of generator/modifier nodes that builds the heightfield) · Material (optional Poly
// Haven PBR). Built as a .glb and imported like Extras. The model half (TKind, TNode, TerrainGraph,
// PLayer, TerrainPBR, TerrainGLB) lives in core/Terrain.kt.

package com.saiki.motion.ui

import android.graphics.Bitmap
import com.saiki.motion.app.EditorViewController
import com.saiki.motion.app.addMedia
import com.saiki.motion.app.refreshPanel
import com.saiki.motion.core.Editor
import com.saiki.motion.core.PLayer
import com.saiki.motion.core.PolyHaven
import com.saiki.motion.core.ProjectIO
import com.saiki.motion.core.TGraph
import com.saiki.motion.core.TKind
import com.saiki.motion.core.TNode
import com.saiki.motion.core.TerrainGLB
import com.saiki.motion.core.TerrainGraph
import com.saiki.motion.core.TerrainPBR
import com.saiki.motion.core.nowMs
import com.saiki.motion.app.Dlg
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UISearchBar
import com.saiki.motion.uikit.UISegmentedControl
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UITableView
import com.saiki.motion.uikit.UITableViewCell
import com.saiki.motion.uikit.UITableViewDataSource
import com.saiki.motion.uikit.UITableViewDelegate
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.setThumb
import com.saiki.motion.uikit.strokeRoundRect
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class TerrainPanel(private val host: EditorViewController) : UiView(appContext!!), UITableViewDataSource, UITableViewDelegate {
    private val accent = 0xFFFF8C14.toInt()
    private val tabs = UISegmentedControl(listOf("Shape", "Nodes", "Material"))
    private val resSeg = UISegmentedControl(listOf("Low", "Medium", "High"))
    private val texRes = UISegmentedControl(listOf("1k (fast)", "2k"))
    private val search = UISearchBar(appContext!!)
    private val table = UITableView(appContext!!)
    private val status = UILabel(appContext!!)
    private val addBtn = PillButton("Add terrain", null, accent, 0xFF000000.toInt())
    private val previewView = object : UiView(appContext!!) {
        var bmp: Bitmap? = null
        public override fun draw(rect: CGRect) {
            val b = bmp ?: run { setBackgroundColor(0xFF242424.toInt()); return }
            val c = UIGraphics.getCurrentContext() ?: return
            c.canvas.drawBitmap(b, null, android.graphics.RectF(0f, 0f, rect.width, rect.height),
                android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
        }
    }
    private val nodeStack = UiView(appContext!!)
    private var pages = ArrayList<UiView>()
    private var all: List<Pair<String, String>> = emptyList()      // (id, name)
    private var shown: List<Pair<String, String>> = emptyList()
    private var busy = false
    private var previewRunnable: Runnable? = null
    private val previewHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val viewSeg = UISegmentedControl(listOf("Shaded", "PBR weights"))
    private val layerStack = UiView(appContext!!)
    private val layerEditor = UiView(appContext!!)
    private val layerSliders = UiView(appContext!!)
    private val assignBtn = PillButton("◎ One PBR layer", null, 0x00000000.toInt(), accent)
    private val card = UiView(appContext!!)
    private val headBox = UiView(appContext!!)
    private val scroll = UIScrollView(appContext!!)
    private val body = UiView(appContext!!)
    private val shapeBox = UiView(appContext!!)
    private val nodesBox = UiView(appContext!!)
    private val matBox = UiView(appContext!!)
    private var presetRef: UiView? = null

    private val curLayer: PLayer?
        get() { val i = TerrainPanel.selLayer; return if (TerrainPanel.layers.indices.contains(i)) TerrainPanel.layers[i] else null }

    private val pick: Int
        get() { val id = curLayer?.tex ?: return -1; return shown.indexOfFirst { it.first == id }.takeIf { it >= 0 } ?: -1 }

    // remembered between openings
    companion object {
        var nodes: MutableList<TNode> = TerrainGraph.presets[1].nodes.toMutableList()
        var height = 0.35f
        var edge = 0.25f
        var sea = 0f
        var genScale = 1f
        var genSeed = 1f
        var relief = 0.8f
        var pendingGraph: String? = null
        var replacing: com.saiki.motion.core.Layer? = null
        var localSets: MutableMap<String, PolyHaven.Maps> = HashMap()
        var procOpen = false
        var layers: MutableList<PLayer> = ArrayList()
        var selNodes: MutableSet<Int> = HashSet()
        var selLayer = -1
        var viewMode = 0
        var nextLayer = 1

        fun present(host: EditorViewController, view: UiView) {
            if (view.subviews.any { it is TerrainPanel }) return
            val v = TerrainPanel(host)
            view.addSubview(v)
            v.frame = CGRect(0f, 0f, view.rectWidth(), view.rectHeight())
        }
    }

    init {
        setBackgroundColor(0x8C000000.toInt())
        build(); rebuildNodes(); rebuildMaterial(); updatePreview()
        PolyHavenNet.list { l ->
            uikitMain {
                all = l.map { it.id to it.name }
                filter("")
                if (l.isEmpty()) status.text = "Could not reach Poly Haven. Check your connection."
            }
        }
    }

    private fun uikitMain(f: () -> Unit) {
        android.os.Handler(android.os.Looper.getMainLooper()).post(f)
    }

    // MARK: ui helpers

    private fun label(t: String, size: CGFloat = 13f, bold: Boolean = false, c: Int = 0xFFB3B3B3.toInt()): UILabel {
        val l = UILabel(appContext!!)
        l.text = t; l.textColor = UIColor(c); l.font = if (bold) UIFont.boldSystemFont(size) else UIFont.systemFont(size)
        l.numberOfLines = 0
        l.frame = CGRect(0f, 0f, 300f, size + 8f)
        return l
    }

    private fun slider(title: String, lo: Float, hi: Float, v: Float, fmt: String = "%.2f", cb: (Float) -> Unit): UiView {
        val l = label(title)
        val valL = label(String.format(Locale.US, fmt, v), 12f)
        valL.textAlignment = NSTextAlignment.right
        val s = UISlider(appContext!!)
        s.minValue = lo; s.maxValue = hi; s.value = v
        s.onValueChanged = { valL.text = String.format(Locale.US, fmt, s.value); cb(s.value) }
        val r = UiView(appContext!!)
        r.addSubview(l); r.addSubview(s); r.addSubview(valL)
        r.frame = CGRect(0f, 0f, 100f, 36f)
        r.onLayout = { w ->
            l.frame = CGRect(0f, 8f, 84f, 18f)
            s.frame = CGRect(88f, 2f, w - 88f - 44f, 32f)
            valL.frame = CGRect(w - 42f, 8f, 42f, 18f)
        }
        return r
    }

    private fun iconBtn(name: String, tint: Int = 0xFFFFFFFF.toInt(), h: () -> Unit): PillButton {
        val b = PillButton(iconGlyph(name), null, 0x00000000.toInt(), tint)
        b.onClick = { h() }
        b.frame = CGRect(0f, 0f, 30f, 30f)
        return b
    }

    private fun iconGlyph(sf: String): String = when {
        sf == "trash" -> "🗑"
        sf.startsWith("chevron.up") -> "▲"
        sf.startsWith("chevron.down") -> "▼"
        sf.startsWith("eye") && sf.contains("slash") -> "◌"
        sf.startsWith("eye") -> "◉"
        else -> "•"
    }

    private fun build() {
        card.setBackgroundColor(0xFF171717.toInt())
        addSubview(card)
        val title = label("Terrain", 22f, true, 0xFFFFFFFF.toInt())
        val x = PillButton("✕", null, C.CARD2, C.TEXT)
        x.onClick = { removeFromSuperview() }
        headBox.addSubview(title); headBox.addSubview(x)
        viewSeg.selectedSegmentIndex = TerrainPanel.viewMode
        viewSeg.onValueChanged = {
            TerrainPanel.viewMode = viewSeg.selectedSegmentIndex
            updatePreview()
        }
        tabs.selectedSegmentIndex = 0
        resSeg.selectedSegmentIndex = 1
        texRes.selectedSegmentIndex = 0
        tabs.onValueChanged = { showTab() }

        // Shape
        val presetBtn = PillButton("Start from a preset…", null, 0x00000000.toInt(), accent)
        presetBtn.onClick = {
            Dlg(host).setTitle("Preset").setItems(TerrainGraph.presets.map { it.name }) { _, i ->
                val pr = TerrainGraph.presets[i]
                TerrainPanel.nodes = pr.nodes.toMutableList()
                TerrainPanel.edge = pr.edge; TerrainPanel.sea = pr.sea
                TerrainPanel.layers = ArrayList(); TerrainPanel.selLayer = -1; TerrainPanel.selNodes = HashSet()
                rebuildShape(); rebuildNodes(); rebuildMaterial(); updatePreview()
            }.show()
        }
        shapeBox.addSubview(presetBtn)
        presetRef = presetBtn
        rebuildShape()

        // Nodes
        val addNode = PillButton("＋ Add node", null, 0x00000000.toInt(), accent)
        addNode.onClick = { showAddNodeMenu() }
        val hint = label("Nodes run top to bottom. Generators build height, modifiers reshape what's above them.", 11f)
        assignBtn.onClick = {
            val ids = TerrainPanel.nodes.map { it.id }.filter { TerrainPanel.selNodes.contains(it) }
            if (ids.isNotEmpty()) newLayer(ids)
        }
        val graphBtn = PillButton("◇ Open node graph (wires + 3D preview)", null, 0x00000000.toInt(), accent)
        graphBtn.onClick = {
            TerrainNodeEditor.present(host, this, TGraph.fromStack(TerrainPanel.nodes.toList(), TerrainPanel.edge, TerrainPanel.sea), null, this)
        }
        nodesBox.addSubview(graphBtn); nodesBox.addSubview(addNode); nodesBox.addSubview(hint); nodesBox.addSubview(assignBtn); nodesBox.addSubview(nodeStack)

        // Material
        search.placeholder = "Search Poly Haven textures (rock, sand, grass…)"
        search.onTextChanged = { q -> filter(q) }
        table.dataSource = this
        table.delegate = this
        table.rowHeight = 56f
        val addLayer = PillButton("＋ PBR layer for the whole terrain", null, 0x00000000.toInt(), accent)
        addLayer.onClick = { newLayer(emptyList()) }
        layerEditor.addSubview(label("Poly Haven material (selected layer)", 15f, true, 0xFFFFFFFF.toInt()))
        layerEditor.addSubview(search)
        layerEditor.addSubview(table)
        layerEditor.addSubview(layerSliders)
        matBox.addSubview(label("PBR layers", 15f, true, 0xFFFFFFFF.toInt()))
        matBox.addSubview(layerStack)
        matBox.addSubview(addLayer)
        matBox.addSubview(layerEditor)
        matBox.addSubview(slider("Relief", 0f, 1f, TerrainPanel.relief) { TerrainPanel.relief = it })
        val texQ = UiView(appContext!!)
        texQ.addSubview(label("Tex quality"))
        texQ.addSubview(texRes)
        matBox.addSubview(texQ)

        pages = arrayListOf(shapeBox, nodesBox, matBox)
        status.textColor = UIColor(0xFFB3B3B3.toInt()); status.font = UIFont.systemFont(12f); status.numberOfLines = 0
        addBtn.textSize = 17f
        addBtn.onClick = { addTap() }
        addBtn.frame = CGRect(0f, 0f, 240f, 48f)

        body.addSubview(headBox)
        body.addSubview(previewView)
        body.addSubview(viewSeg)
        body.addSubview(tabs)
        body.addSubview(scroll)
        for (p in pages) scroll.addSubview(p)
        body.addSubview(status)
        body.addSubview(addBtn)
        card.addSubview(body)
        showTab()
    }

    public override fun layoutSubviews() {
        super.layoutSubviews()
        val w = rectWidth(); val h = rectHeight()
        if (w < 10 || h < 10) return
        val top = safeAreaInsets.top
        card.frame = CGRect(12f, top + 40f, w - 24f, h - top - 52f)
        val cw = card.rectWidth()
        var y = 16f
        headBox.frame = CGRect(16f, y, cw - 32f, 30f)
        headBox.subviews[0].frame = CGRect(0f, 4f, 200f, 26f)
        headBox.subviews[1].frame = CGRect(cw - 32f - 44f, 0f, 44f, 30f)
        y += 38f
        previewView.frame = CGRect(16f, y, cw - 32f, 150f)
        y += 158f
        viewSeg.frame = CGRect(16f, y, cw - 32f, 32f); y += 40f
        tabs.frame = CGRect(16f, y, cw - 32f, 32f); y += 40f
        val scrollH = card.rectHeight() - y - 34f - 56f - 8f
        scroll.frame = CGRect(16f, y, cw - 32f, max(scrollH, 60f))
        y += max(scrollH, 60f) + 8f
        status.frame = CGRect(16f, y, cw - 32f, 32f); y += 36f
        addBtn.frame = CGRect(16f, y, cw - 32f, 48f)
        layoutPages()
    }

    private fun layoutPages() {
        val pw = scroll.rectWidth()
        for (p in pages) {
            if (p.isHidden) continue
            when (p) {
                shapeBox -> layoutVStack(shapeBox, pw)
                nodesBox -> layoutVStack(nodesBox, pw)
                matBox -> layoutVStack(matBox, pw)
            }
        }
        var maxH = 0f
        for (p in pages) if (!p.isHidden) maxH = max(maxH, p.rectHeight())
        for (p in pages) p.frame = CGRect(0f, 0f, pw, maxH)
        scroll.contentSize = CGSize(pw, maxH)
    }

    private fun layoutVStack(v: UiView, w: Float) {
        var y = 0f
        for (s in v.subviews) {
            if (s.isHidden) continue
            val vh = when (s) {
                nodeStack -> nodeStackHeight()
                layerStack -> layerStackHeight()
                layerEditor -> layerEditorHeight()
                table -> 220f
                search -> 40f
                is UILabel -> s.font.size + 10f
                is PillButton -> if (s === presetRef || s.text.contains("＋") || s.text.contains("◇")) 32f else 32f
                else -> 36f
            }
            s.frame = CGRect(0f, y, w, vh)
            s.onLayout?.invoke(w)
            if (s.subviews.size == 2 && s.subviews[1] === texRes) {
                s.subviews[0].frame = CGRect(0f, 10f, 90f, 18f)
                s.subviews[1].frame = CGRect(100f, 4f, w - 100f, 32f)
            }
            when (s) {
                nodeStack -> layoutNodeCards(w)
                layerStack -> layoutLayerRows(w)
                layerEditor -> layoutLayerEditor(w)
                table -> { table.frame = CGRect(0f, y, w, 220f); table.reloadData() }
                else -> {}
            }
            y += vh + 10f
        }
        v.frame = CGRect(0f, 0f, w, y)
        v.setNeedsDisplay()
    }

    private fun nodeStackHeight(): Float {
        var y = 0f
        for (c in nodeStack.subviews) if (!c.isHidden) y += (c.rectHeight().takeIf { it > 0f } ?: 120f) + 10f
        return y
    }

    private fun layerStackHeight(): Float = layerStack.subviews.filter { !it.isHidden }.size * 44f
    private fun layerEditorHeight(): Float = if (curLayer == null) 0f else 40f + 48f + 220f + layerSliders.subviews.size * 44f

    private fun layoutNodeCards(w: Float) {
        var y = 0f
        for (c in nodeStack.subviews) {
            if (c.isHidden) continue
            val ch = c.rectHeight().takeIf { it > 0f } ?: 120f
            c.frame = CGRect(0f, y, w, ch)
            c.onLayout?.invoke(w)
            y += ch + 10f
        }
        nodeStack.frame = CGRect(0f, 0f, w, y)
    }

    private fun layoutLayerRows(w: Float) {
        var y = 0f
        for (r in layerStack.subviews) {
            if (r.isHidden) continue
            r.frame = CGRect(0f, y, w, 40f)
            r.onLayout?.invoke(w)
            y += 44f
        }
        layerStack.frame = CGRect(0f, 0f, w, y)
    }

    private fun layoutLayerEditor(w: Float) {
        var y = 0f
        for (s in layerEditor.subviews) {
            if (s.isHidden) continue
            val vh = when (s) {
                search -> 40f
                table -> 220f
                layerSliders -> layerSliders.subviews.size * 44f
                else -> 24f
            }
            s.frame = CGRect(0f, y, w, vh)
            s.onLayout?.invoke(w)
            if (s === table) { table.reloadData() }
            if (s === layerSliders) {
                var sy = 0f
                for (sl in layerSliders.subviews) { sl.frame = CGRect(0f, sy, w, 36f); sl.onLayout?.invoke(w); sy += 44f }
                layerSliders.frame = CGRect(0f, y, w, sy)
            }
            y += vh + 8f
        }
        layerEditor.frame = CGRect(0f, 0f, w, y)
    }

    private fun rebuildShape() {
        shapeBox.subviews.toList().forEach { if (it !== presetRef) it.removeFromSuperview() }
        shapeBox.addSubview(slider("Height", 0f, 1f, TerrainPanel.height) { TerrainPanel.height = it; updatePreview() })
        shapeBox.addSubview(slider("Edge fade", 0f, 1f, TerrainPanel.edge) { TerrainPanel.edge = it; updatePreview() })
        shapeBox.addSubview(slider("Sea level", 0f, 0.6f, TerrainPanel.sea) { TerrainPanel.sea = it; updatePreview() })
        val disc = PillButton((if (TerrainPanel.procOpen) "▾ " else "▸ ") + "Procedural generation", null, 0x00000000.toInt(), accent)
        disc.textSize = 15f
        disc.onClick = { TerrainPanel.procOpen = !TerrainPanel.procOpen; rebuildShape() }
        shapeBox.addSubview(disc)
        if (TerrainPanel.procOpen) {
            shapeBox.addSubview(slider("Scale", 0.25f, 4f, TerrainPanel.genScale) { TerrainPanel.genScale = it; updatePreview() })
            shapeBox.addSubview(slider("Seed", 1f, 999f, TerrainPanel.genSeed, "%.0f") { TerrainPanel.genSeed = it; updatePreview() })
            val rnd = PillButton("Randomize", null, 0x00000000.toInt(), accent)
            rnd.onClick = { TerrainPanel.genSeed = Random.nextInt(1, 1000).toFloat(); rebuildShape(); updatePreview() }
            shapeBox.addSubview(rnd)
        }
        val r = UiView(appContext!!)
        r.addSubview(label("Mesh detail"))
        r.addSubview(resSeg)
        shapeBox.addSubview(r)
        layoutVStack(shapeBox, scroll.rectWidth().takeIf { it > 0f } ?: 300f)
    }

    private fun rebuildNodes() {
        nodeStack.subviews.toList().forEach { it.removeFromSuperview() }
        for ((idx, nd) in TerrainPanel.nodes.withIndex()) {
            val cardV = UiView(appContext!!)
            cardV.setBackgroundColor(0xFF262626.toInt())
            val ic = IconView(nd.kind.icon, if (nd.kind.isGen) accent else 0xFF66B3FF.toInt(), 20f)
            ic.frame = CGRect(12f, 8f, 22f, 22f)
            cardV.addSubview(ic)
            val t = label("${idx + 1}. ${nd.kind.title}", 14f, true, if (nd.on) 0xFFFFFFFF.toInt() else 0xFF737373.toInt())
            t.frame = CGRect(40f, 8f, 140f, 20f)
            cardV.addSubview(t)
            var bx = cardVRightBase()
            val eye = iconBtn(if (nd.on) "eye" else "eye.slash") { TerrainPanel.nodes[idx].on = !TerrainPanel.nodes[idx].on; rebuildNodes(); updatePreview() }
            eye.frame = CGRect(bx, 6f, 30f, 30f); cardV.addSubview(eye); bx -= 32f
            val up = iconBtn("chevron.up") { if (idx > 0) { java.util.Collections.swap(TerrainPanel.nodes, idx, idx - 1); rebuildNodes(); updatePreview() } }
            up.frame = CGRect(bx, 6f, 30f, 30f); cardV.addSubview(up); bx -= 32f
            val dn = iconBtn("chevron.down") { if (idx < TerrainPanel.nodes.size - 1) { java.util.Collections.swap(TerrainPanel.nodes, idx, idx + 1); rebuildNodes(); updatePreview() } }
            dn.frame = CGRect(bx, 6f, 30f, 30f); cardV.addSubview(dn); bx -= 32f
            val del = iconBtn("trash", 0xFFFF6666.toInt()) {
                TerrainPanel.selNodes.remove(TerrainPanel.nodes[idx].id)
                TerrainPanel.nodes.removeAt(idx)
                rebuildNodes(); updatePreview()
            }
            del.frame = CGRect(bx, 6f, 30f, 30f); cardV.addSubview(del)
            val sel = TerrainPanel.selNodes.contains(nd.id)
            val selB = PillButton(if (sel) "☑ Selected" else "☐ Select", null, 0x00000000.toInt(), if (sel) accent else 0xFFBFBFBF.toInt())
            selB.textSize = 12f
            selB.onClick = {
                if (TerrainPanel.selNodes.contains(nd.id)) TerrainPanel.selNodes.remove(nd.id) else TerrainPanel.selNodes.add(nd.id)
                rebuildNodes()
            }
            selB.frame = CGRect(0f, 0f, 110f, 26f)
            cardV.addSubview(selB)
            val pb = PillButton("＋ PBR layer", null, 0x00000000.toInt(), accent)
            pb.textSize = 12f
            pb.onClick = { newLayer(listOf(nd.id)) }
            pb.frame = CGRect(0f, 0f, 100f, 26f)
            cardV.addSubview(pb)
            val used = TerrainPanel.layers.withIndex().filter { it.value.nodes.contains(nd.id) }.map { "L${it.index + 1}" }
            val info = label(if (used.isEmpty()) "" else "PBR: " + used.joinToString(", "), 11f, false, accent)
            info.frame = CGRect(0f, 0f, 120f, 16f)
            cardV.addSubview(info)
            var prows = ArrayList<UiView>()
            prows.add(selB); prows.add(pb); prows.add(info)
            for ((pi, sp) in nd.kind.params.withIndex()) {
                if (sp.opts != null) {
                    val seg = UISegmentedControl(sp.opts)
                    seg.selectedSegmentIndex = nd.p[pi].toInt()
                    seg.onValueChanged = { TerrainPanel.nodes[idx].p[pi] = seg.selectedSegmentIndex.toFloat(); updatePreview() }
                    val row = UiView(appContext!!)
                    row.addSubview(label(sp.name))
                    row.addSubview(seg)
                    prows.add(row)
                    cardV.addSubview(row)
                } else {
                    val whole = sp.hi - sp.lo >= 8f
                    val row = slider(sp.name, sp.lo, sp.hi, nd.p[pi], if (whole) "%.0f" else "%.2f") { v ->
                        TerrainPanel.nodes[idx].p[pi] = if (whole) v.toInt().toFloat() else v
                        updatePreview()
                    }
                    prows.add(row)
                    cardV.addSubview(row)
                }
            }
            cardV.onLayout = { cw ->
                var y = 36f
                t.frame = CGRect(40f, 8f, cw - 40f - 140f, 20f)
                var bx2 = cw - 36f
                for (b in listOf(eye, up, dn, del)) { b.frame = CGRect(bx2 - 30f, 6f, 30f, 30f); bx2 -= 32f }
                // action row
                selB.frame = CGRect(12f, y, 110f, 26f)
                pb.frame = CGRect(128f, y, 100f, 26f)
                info.frame = CGRect(cw - 132f, y + 5f, 120f, 16f)
                y += 30f
                for ((k, row) in prows.withIndex()) {
                    if (k < 3) continue
                    val isSeg = row.subviews.size == 2 && row.subviews[1] is UISegmentedControl
                    if (isSeg) {
                        row.frame = CGRect(12f, y, cw - 24f, 32f)
                        row.subviews[0].frame = CGRect(0f, 8f, 90f, 18f)
                        row.subviews[1].frame = CGRect(96f, 0f, cw - 24f - 96f, 32f)
                        y += 36f
                    } else {
                        row.frame = CGRect(12f, y, cw - 24f, 36f)
                        row.onLayout?.invoke(cw - 24f)
                        y += 40f
                    }
                }
                cardV.frame = CGRect(cardV.frame.x, cardV.frame.y, cw, y + 4f)
            }
            cardV.frame = CGRect(0f, 0f, 100f, 120f)
            nodeStack.addSubview(cardV)
        }
        val ns = TerrainPanel.selNodes.size
        assignBtn.text = "◎ One PBR layer for $ns selected node${if (ns == 1) "" else "s"}"
        assignBtn.isHidden = ns == 0
        if (TerrainPanel.nodes.isEmpty()) nodeStack.addSubview(label("No nodes — the terrain is flat. Add a generator.", 12f))
        layoutVStack(nodesBox, scroll.rectWidth().takeIf { it > 0f } ?: 300f)
    }

    private fun cardVRightBase(): Float = 320f

    private fun showAddNodeMenu() {
        val gens = TKind.values().filter { it.isGen && it !in listOf(TKind.baked, TKind.blend, TKind.pbr, TKind.heightTex) }
        val mods = TKind.values().filter { !it.isGen && it !in listOf(TKind.baked, TKind.blend, TKind.pbr, TKind.heightTex) }
        Dlg(host).setTitle("Add node")
            .setItems(listOf("— Modifiers —") + mods.map { it.title } + listOf("— Generators —") + gens.map { it.title }) { _, i ->
                val all = listOf("— Modifiers —") + mods.map { it.title } + listOf("— Generators —") + gens.map { it.title }
                val name = all[i]
                val k = (mods + gens).firstOrNull { it.title == name } ?: return@setItems
                TerrainPanel.nodes.add(TNode(k))
                rebuildNodes(); updatePreview()
            }.show()
    }

    private fun newLayer(ids: List<Int>) {
        TerrainPanel.layers.add(PLayer(TerrainPanel.nextLayer, ids.toMutableList()))
        TerrainPanel.nextLayer += 1
        if (ids.isEmpty()) {      // whole-terrain layers share the height range in even bands so each one actually shows
            val w = TerrainPanel.layers.indices.filter { TerrainPanel.layers[it].nodes.isEmpty() }
            val k = w.size.toFloat()
            for ((n, i) in w.withIndex()) { TerrainPanel.layers[i].hLo = n / k; TerrainPanel.layers[i].hHi = (n + 1) / k }
        }
        TerrainPanel.selLayer = TerrainPanel.layers.size - 1
        TerrainPanel.selNodes.clear()
        rebuildNodes(); rebuildMaterial(); updatePreview()
        tabs.selectedSegmentIndex = 2; showTab()
    }

    private fun rebuildMaterial() {
        layerStack.subviews.toList().forEach { it.removeFromSuperview() }
        layerSliders.subviews.toList().forEach { it.removeFromSuperview() }
        for ((i, l) in TerrainPanel.layers.withIndex()) {
            val sel = i == TerrainPanel.selLayer
            val nn = if (l.nodes.isEmpty()) "whole terrain" else "${l.nodes.size} node${if (l.nodes.size == 1) "" else "s"}"
            val b = PillButton("${if (sel) "● " else "○ "}L${i + 1} · ${if (l.texName.isEmpty()) "procedural" else l.texName} · $nn", null, 0x00000000.toInt(), if (sel) accent else C.TEXT)
            b.textSize = 13f
            b.onClick = { TerrainPanel.selLayer = i; rebuildMaterial() }
            b.frame = CGRect(0f, 0f, 100f, 30f)
            val eye = iconBtn(if (l.on) "eye" else "eye.slash") { TerrainPanel.layers[i].on = !TerrainPanel.layers[i].on; rebuildMaterial(); updatePreview() }
            val del = iconBtn("trash", 0xFFFF6666.toInt()) {
                TerrainPanel.layers.removeAt(i)
                TerrainPanel.selLayer = min(TerrainPanel.selLayer, TerrainPanel.layers.size - 1)
                rebuildMaterial(); rebuildNodes(); updatePreview()
            }
            val r = UiView(appContext!!)
            r.addSubview(b); r.addSubview(eye); r.addSubview(del)
            r.onLayout = { w ->
                b.frame = CGRect(0f, 4f, w - 70f, 26f)
                eye.frame = CGRect(w - 64f, 2f, 30f, 30f)
                del.frame = CGRect(w - 32f, 2f, 30f, 30f)
            }
            layerStack.addSubview(r)
        }
        if (TerrainPanel.layers.isEmpty()) layerStack.addSubview(label("No PBR layers: the terrain uses procedural colours. Assign layers from the Nodes tab or add one here.", 12f))
        layerEditor.isHidden = curLayer == null
        table.reloadData()
        val cur = curLayer ?: return
        val si = TerrainPanel.selLayer
        fun ls(t: String, lo: Float, hi: Float, v: Float, fmt: String = "%.2f", set: (PLayer, Float) -> Unit) {
            val row = slider(t, lo, hi, v, fmt) { x ->
                if (TerrainPanel.layers.indices.contains(si)) {
                    set(TerrainPanel.layers[si], x)
                    updatePreview()
                }
            }
            layerSliders.addSubview(row)
        }
        ls("Tiling", 1f, 24f, cur.tiling, "%.0f") { p, x -> p.tiling = x.toInt().toFloat() }
        ls("Strength", 0f, 2f, cur.strength) { p, x -> p.strength = x }
        layerSliders.addSubview(label("Rules (each has a softness)", 13f, true, 0xFFFFFFFF.toInt()))
        ls("Height min", 0f, 1f, cur.hLo) { p, x -> p.hLo = x }
        ls("Height max", 0f, 1f, cur.hHi) { p, x -> p.hHi = x }
        ls("H softness", 0f, 0.5f, cur.hSoft) { p, x -> p.hSoft = x }
        ls("Slope min", 0f, 1f, cur.sLo) { p, x -> p.sLo = x }
        ls("Slope max", 0f, 1f, cur.sHi) { p, x -> p.sHi = x }
        ls("S softness", 0f, 0.5f, cur.sSoft) { p, x -> p.sSoft = x }
        ls("Shore min", 0f, 0.5f, cur.wLo) { p, x -> p.wLo = x }
        ls("Shore max", 0f, 0.5f, cur.wHi) { p, x -> p.wHi = x }
        ls("W softness", 0f, 0.3f, cur.wSoft) { p, x -> p.wSoft = x }
        layoutVStack(matBox, scroll.rectWidth().takeIf { it > 0f } ?: 300f)
    }

    private fun updatePreview() {
        previewRunnable?.let { previewHandler.removeCallbacks(it) }
        val nodes = TerrainPanel.nodes.toList()
        val e = TerrainPanel.edge; val s = TerrainPanel.sea
        val sc = TerrainPanel.genScale; val sd = TerrainPanel.genSeed.toInt()
        val amp = TerrainPanel.height * 0.5f
        val ly = TerrainPanel.layers.filter { it.on }
        val wm = TerrainPanel.viewMode == 1
        val r = Runnable {
            val img = TerrainGraph.preview(nodes, e, s, sc, sd, amp, ly, wm)
            uikitMain { previewView.bmp = img; previewView.setNeedsDisplay() }
        }
        previewRunnable = r
        previewHandler.postDelayed(r, 120)
    }

    private fun showTab() {
        for ((i, p) in pages.withIndex()) p.isHidden = i != tabs.selectedSegmentIndex
        addBtn.isHidden = false
        layoutPages()
    }

    private fun filter(q: String) {
        val k = q.trim().lowercase()
        shown = if (k.isEmpty()) all else all.filter { it.second.lowercase().contains(k) || it.first.contains(k) }
        table.reloadData()
    }

    override fun numberOfRows(t: UITableView, section: Int): Int = shown.size + 1

    override fun cellForRow(t: UITableView, row: Int): UITableViewCell {
        val c = UITableViewCell(appContext!!)
        c.setBackgroundColor(0x00000000)
        c.textLabel?.textColor = UIColor.white
        val i = row - 1
        c.textLabel?.text = if (i < 0) "Procedural colours (shore / grass / rock / snow)" else shown[i].second
        c.accessoryType = if (i == pick) 1 else 0
        if (i >= 0) {
            val id = shown[i].first
            PolyHavenNet.thumb(id) { img ->
                uikitMain {
                    if (img != null && i < shown.size && shown[i].first == id) c.setThumb(img)
                }
            }
        }
        return c
    }

    override fun didSelectRow(t: UITableView, row: Int) {
        val i = row - 1
        val si = TerrainPanel.selLayer
        if (TerrainPanel.layers.indices.contains(si)) {
            TerrainPanel.layers[si].tex = if (i >= 0) shown[i].first else null
            TerrainPanel.layers[si].texName = if (i >= 0) shown[i].second else ""
        }
        search.resignFirstResponder()
        rebuildMaterial()
    }

    var statusText: String
        get() = status.text ?: ""
        set(v) { status.text = v }

    val isBusy: Boolean get() = busy

    fun addTap() {
        if (busy) return
        busy = true; addBtn.alpha = 0.5f
        val o = TerrainGLB.Opt()
        o.nodes = TerrainPanel.nodes.toList()
        o.res = listOf(64, 128, 224)[resSeg.selectedSegmentIndex]
        o.height = TerrainPanel.height * 0.5f; o.edge = TerrainPanel.edge; o.sea = TerrainPanel.sea
        o.scale = TerrainPanel.genScale; o.seed = TerrainPanel.genSeed.toInt()
        val layers = TerrainPanel.layers.filter { it.on }
        val q = if (texRes.selectedSegmentIndex == 0) "1k" else "2k"
        val T = if (q == "1k") 2048 else 3072
        val ids = layers.mapNotNull { it.tex }.distinct()
        val anyTex = ids.isNotEmpty()
        status.text = if (layers.isEmpty()) "Building…" else (if (anyTex) "Downloading maps…" else "Baking layers…")
        fun finish(sets: Map<String, TerrainPBR.TexSet>) {
            uikitMain { status.text = if (layers.isEmpty()) "Building…" else "Baking PBR layers…" }
            Thread {
                var oo = TerrainGLB.Opt(nodes = o.nodes, res = o.res, height = o.height, edge = o.edge, sea = o.sea, tiles = o.tiles, scale = o.scale, seed = o.seed)
                var pk: com.saiki.motion.core.ExtrasGLB.Packed? = null
                var sd: TerrainPBR.SplatData? = null
                if (layers.isNotEmpty()) {
                    val r = TerrainPBR.bake(oo, layers, sets, T)
                    if (r != null) { oo.tiles = 1; pk = r.first; sd = r.second }
                }
                val glb = TerrainGLB.build(oo, pk, sd)
                val pp = pk
                uikitMain {
                    busy = false; addBtn.alpha = 1f
                    val path = ProjectIO.writeDataIntoSandbox(glb, "terrain_${nowMs()}.glb")
                    if (path == null) { status.text = "Could not build the terrain."; return@uikitMain }
                    host.addMedia(path, com.saiki.motion.core.LayerType.MODEL)
                    val l = Editor.scene.layers.lastOrNull { it.imagePath == path }
                    if (l != null) {
                        l.name = "Terrain"
                        l.tgraph = TerrainPanel.pendingGraph ?: TGraph.fromStack(TerrainPanel.nodes.toList(), TerrainPanel.edge, TerrainPanel.sea).json()
                        val old = TerrainPanel.replacing
                        if (old != null && old !== l) {
                            for (k in listOf("x", "y", "z", "scale", "rotX", "rotY", "rotZ")) l.track(k).set(Editor.time, old.p(k, Editor.time), false)
                            Editor.scene.layers.removeAll { it === old }
                        }
                        TerrainPanel.pendingGraph = null; TerrainPanel.replacing = null
                        if (pp != null) {
                            val rl = TerrainPanel.relief
                            l.xset("pbrNorm", 0.8f + 1.4f * rl); l.xset("pbrExtra", 1f); l.xset("pbrPom", 0.035f * rl)
                        }
                        host.render(); host.refreshPanel()
                    }
                    removeFromSuperview()
                }
            }.start()
        }
        Thread {
            val sets = HashMap<String, TerrainPBR.TexSet>()
            fun next(k: Int) {
                if (k >= ids.size) { finish(sets); return }
                val local = TerrainPanel.localSets[ids[k]]
                if (local != null) {
                    sets[ids[k]] = TerrainPBR.texSet(local, if (q == "1k") 1024 else 2048)
                    next(k + 1)
                    return
                }
                PolyHavenNet.maps(ids[k], q) { m ->
                    if (m == null) {
                        uikitMain { busy = false; addBtn.alpha = 1f; status.text = "Download failed. Try again." }
                        return@maps
                    }
                    sets[ids[k]] = TerrainPBR.texSet(m, if (q == "1k") 1024 else 2048)
                    next(k + 1)
                }
            }
            next(0)
        }.start()
    }
}
