@file:Suppress("unused", "FunctionName")

package com.saiki.motion.ui

import android.util.TypedValue
import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIControl
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.fillStyleRoundRect
import com.saiki.motion.uikit.fillStyleCircle
import com.saiki.motion.uikit.strokeStyleRoundRect
import com.saiki.motion.uikit.strokeStyleLine
import com.saiki.motion.uikit.currentActivity
import java.util.Locale
import kotlin.math.max

// Port of Sources/UI/Theme.swift — the design system (Ui.kt original). Colour constants, fonts and
// the Canvas/Paint-style drawing helpers every custom view shares. The current context handed out
// inside draw(_:) is top-left origin with y pointing down — identical to Android's Canvas — so all
// coordinates carry over. "dp" values are used as points directly.

/** Theme constants (ARGB Int, Android bit layout). GREEN is the app accent. */
object C {
    const val BG = 0xFF0E0E10.toInt()
    const val PANEL = 0xFF111114.toInt()
    const val CARD = 0xFF1C1C21.toInt()
    const val CARD2 = 0xFF26262C.toInt()
    const val GREEN = 0xFFFF8A1F.toInt()
    const val GREEN_DARK = 0xFFD96A00.toInt()
    const val ONDARK = 0xFF0D2113.toInt()
    const val AMBER = 0xFFF5B301.toInt()
    const val RED = 0xFFEF4444.toInt()
    const val BLUE = 0xFF38BDF8.toInt()
    const val TEXT = 0xFFFFFFFF.toInt()
    const val DIM = 0xFF8C8C96.toInt()
    const val LINE = 0xFF2A2A30.toInt()
}

/** Device scale: tablets get bigger parameter controls (detected automatically). */
object Dev {
    val isPad: Boolean by lazy {
        val dm = appContext!!.resources.displayMetrics
        val w = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 600f, dm)
        max(dm.widthPixels, dm.heightPixels) >= w
    }
    val k: Float get() = if (isPad) 1.35f else 1f
}

/** Key window of the app. */
fun appKeyWindow(): UiView? = currentActivity?.get()?.window?.decorView as? UiView

fun boldFont(size: CGFloat): com.saiki.motion.uikit.UIFont = com.saiki.motion.uikit.UIFont.boldSystemFont(size)
fun sysFont(size: CGFloat): com.saiki.motion.uikit.UIFont = com.saiki.motion.uikit.UIFont.systemFont(size)

/** Android Paint.measureText equivalent. */
fun measureText(s: String, size: CGFloat, bold: Boolean = false): CGFloat {
    if (s.isEmpty()) return 0f
    val p = (if (bold) boldFont(size) else sysFont(size)).toPaint()
    return p.measureText(s)
}

/** Android Canvas.drawText equivalent: (x, y) is the text BASELINE, returns the text width. */
fun drawText(s: String, x: CGFloat, y: CGFloat, color: Int, size: CGFloat, bold: Boolean = false, align: NSTextAlignment = NSTextAlignment.left): CGFloat {
    if (s.isEmpty()) return 0f
    val c = com.saiki.motion.uikit.UIGraphics.getCurrentContext() ?: return 0f
    val p = (if (bold) boldFont(size) else sysFont(size)).toPaint()
    p.color = color
    val w = p.measureText(s)
    var px = x
    if (align == NSTextAlignment.center) px -= w / 2 else if (align == NSTextAlignment.right) px -= w
    c.canvas.drawText(s, px, y, p)
    return w
}

fun fillRoundRect(c: CGContext, r: CGRect, radius: CGFloat, color: Int) = fillStyleRoundRect(c, r, radius, color)
fun strokeRoundRect(c: CGContext, r: CGRect, radius: CGFloat, width: CGFloat, color: Int) = strokeStyleRoundRect(c, r, radius, width, color)
fun strokeLine(c: CGContext, x0: CGFloat, y0: CGFloat, x1: CGFloat, y1: CGFloat, width: CGFloat, color: Int) = strokeStyleLine(c, x0, y0, x1, y1, width, color)
fun fillCircle(c: CGContext, x: CGFloat, y: CGFloat, r: CGFloat, color: Int) = fillStyleCircle(c, x, y, r, color)
fun strokeCircle(c: CGContext, x: CGFloat, y: CGFloat, r: CGFloat, width: CGFloat, color: Int) =
    com.saiki.motion.uikit.strokeStyleCircle(c, x, y, r, width, color)
fun fillRect(c: CGContext, r: CGRect, color: Int) = com.saiki.motion.uikit.fillRect(c, r, color)

fun disallowParentScrollInterception(v: UiView, disallow: Boolean) =
    com.saiki.motion.uikit.disallowParentScrollInterception(v, disallow)

/** Tappable base view: onClick fires when a touch ends inside the bounds; pressed state redraws. */
open class TapView : UIControl()

fun TapView.onTap(fn: () -> Unit) { onClick = fn }

/** Percentage formatting helper used across panels (Locale.US, one decimal). */
fun pct(v: Float): String = String.format(Locale.US, "%.1f%%", v)
