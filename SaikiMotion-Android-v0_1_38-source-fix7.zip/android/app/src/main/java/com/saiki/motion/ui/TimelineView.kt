@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import com.saiki.motion.core.Defs
import com.saiki.motion.core.Editor
import com.saiki.motion.core.FrameCache
import com.saiki.motion.core.Key
import com.saiki.motion.core.Layer
import com.saiki.motion.core.LayerType
import com.saiki.motion.core.Registry
import com.saiki.motion.core.RetimeSnap
import com.saiki.motion.core.Track
import com.saiki.motion.core.clamp
import com.saiki.motion.core.retime
import com.saiki.motion.core.retimeSnapshot
import com.saiki.motion.core.roundAway

import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGPath
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UIImpactFeedbackGenerator
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UITouchPhase
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.UIGraphicsImageRenderer
import com.saiki.motion.uikit.argbToUIColor
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

// Port of Sources/UI/TimelineView.swift — the real timeline (UI).
//
// Timeline with a CENTRED playhead: the playhead is a fixed orange line in
// the middle of the view and time flows under it — dragging anywhere in the
// tracks scrubs (content follows the finger), never the playhead. Top row =
// front-most layer. "^" (the chevron) expands a layer into its keyframe rows
// (or a group into its content), long-press a layer — or drag its right-edge
// handle — then drag up or down to reorder it. Pinch anywhere to zoom.
// Move / trim handles only appear on the SELECTED layer, so an accidental
// drag can never shift a clip you didn't tap first.
//
// Colors, row heights, hit slop, snap distances and the timecode format
// (MM:SS:FF) all match the iOS build exactly.

// MARK: - host protocols (the editor implements both)

interface EditHost2 {
    fun selectedLayer(): Layer?
    fun selectedId(): Int
    fun isSelected(id: Int): Boolean
    fun onSelect(id: Int)
    fun beginEdit()
    fun onEdited()
    fun autoKey(): Boolean
    fun puppetPanelOpen(): Boolean
    fun gradientKnobsOn(): Boolean
    fun moveAnchor(l: Layer, ax: Float, ay: Float)
}

interface TimelineHost2 {
    fun selectedLayer(): Layer?
    fun autoKey(): Boolean
    fun beginEdit()
    fun onEdited()
    fun onSeek(t: Float)
    fun onSelect(id: Int)
    fun onToggleVisible(l: Layer)
    fun onTimingChanged()
    fun onReorder(l: Layer, listIndex: Int)
    fun onKeyTap(l: Layer, key: String, idx: Int)
}

// MARK: - Waveform (iOS Waveform.swift twin: cached normalised audio peaks)

private object Waveform {
    private val lock = Any()
    private val cache = HashMap<String, FloatArray>()
    private val loading = HashSet<String>()
    const val buckets = 1500

    /** Normalised peaks (0..1) for the whole file, or null while still being decoded (`done` fires on the main thread when ready). */
    fun peaks(path: String, done: () -> Unit): FloatArray? {
        val cached = synchronized(lock) { cache[path] }
        if (cached != null) return cached
        val shouldLoad = synchronized(lock) {
            if (loading.contains(path)) false else { loading.add(path); true }
        }
        if (!shouldLoad) return null
        Thread {
            val p = compute(path)
            synchronized(lock) { cache[path] = p; loading.remove(path) }
            Handler(Looper.getMainLooper()).post(done)
        }.start()
        return null
    }

    private fun compute(path: String): FloatArray {
        // Waveform.swift:29 AVAudioFile decode -> MediaExtractor + MediaCodec 16-bit PCM decode; the peak is the max across
        // channels per frame, exactly like AVAudioPCMBuffer's floatChannelData loop.
        val out = FloatArray(buckets)
        try {
            val ex = android.media.MediaExtractor()
            ex.setDataSource(path)
            var audioTrack = -1
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(android.media.MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { audioTrack = i; break }
            }
            if (audioTrack < 0) return out
            ex.selectTrack(audioTrack)
            val fmt = ex.getTrackFormat(audioTrack)
            val mime = fmt.getString(android.media.MediaFormat.KEY_MIME) ?: return out
            val codec = try { android.media.MediaCodec.createDecoderByType(mime) } catch (_: Exception) { return out }
            try {
                codec.configure(fmt, null, null, 0)
                codec.start()
                // total sample count via duration * sample rate (AVAudioFile.length equivalent)
                val durUs = if (fmt.containsKey(android.media.MediaFormat.KEY_DURATION)) fmt.getLong(android.media.MediaFormat.KEY_DURATION) else 0L
                val sr = if (fmt.containsKey(android.media.MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(android.media.MediaFormat.KEY_SAMPLE_RATE) else 44100
                val total = (durUs * sr / 1_000_000L).coerceAtLeast(1L)
                val per = max(1L, total / buckets)
                val chs = if (fmt.containsKey(android.media.MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(android.media.MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1) else 1
                var pos = 0L
                var eos = false
                val info = android.media.MediaCodec.BufferInfo()
                while (!eos) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val ib = codec.getInputBuffer(inIdx)!!
                        val n = ex.readSampleData(ib, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, android.media.MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            eos = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                    var outIdx = codec.dequeueOutputBuffer(info, 10_000)
                    while (outIdx >= 0) {
                        val ob = codec.getOutputBuffer(outIdx)
                        if (ob != null && info.size > 0) {
                            val bb = ob.order(java.nio.ByteOrder.LITTLE_ENDIAN)
                            val shorts = info.size / 2
                            val frames = shorts / chs
                            var f = 0
                            while (f < frames) {
                                var m = 0f          // max across channels (Waveform.compute: max over ch[c][i])
                                for (c in 0 until chs) { val v = abs(bb.getShort((f * chs + c) * 2).toFloat()) / 32768f; if (v > m) m = v }
                                var q: Long = (pos + f.toLong()) / per
                                if (q > buckets - 1L) q = buckets - 1L
                                val idx = q.toInt()
                                if (m > out[idx]) out[idx] = m
                                f++
                            }
                            pos += frames
                        }
                        codec.releaseOutputBuffer(outIdx, false)
                        outIdx = codec.dequeueOutputBuffer(info, 0)
                    }
                }
            } finally {
                try { codec.stop() } catch (_: Exception) {}
                codec.release()
                ex.release()
            }
        } catch (_: Exception) {
        }
        var mx = 0.0001f
        for (v in out) mx = max(mx, v)
        for (i in out.indices) out[i] = out[i] / mx
        return out
    }
}

// MARK: - the view

class TimelineView(private val editHost: EditHost2?, private val tlHost: TimelineHost2?) : UiView(com.saiki.motion.uikit.appContext!!) {

    // iOS used density-multiplied px; this build works in points, so d = 1.
    private val d: CGFloat = 1f
    private var pxPerSec: CGFloat = 80f
    private var scrollY: CGFloat = 0f
    private val rulerH: CGFloat = 40f
    private val rowH: CGFloat = 40f
    private val paramH: CGFloat = 28f
    private val leftCol: CGFloat = 84f
    private var openIds = HashSet<Int>()

    // Palette (iOS TimelineView kept the Android palette identical on purpose):
    // the playhead "green" is this orange.
    companion object {
        val A_BG     = 0xFF0E0E10.toInt()
        val A_GREEN  = 0xFFFF8A1F.toInt()   // playhead / accents
        val A_AMBER  = 0xFFF5B301.toInt()
        val A_BLUE   = 0xFF38BDF8.toInt()
        val A_TEXT   = 0xFFFFFFFF.toInt()
        val A_DIM    = 0xFF8C8C96.toInt()
        val A_CACHE  = 0xFF34D27B.toInt()   // cached-frames bar (like After Effects)
        val A_TICK   = 0xFF55555E.toInt()
        val A_PILLTX = 0xFF2B1400.toInt()   // text on the playhead pill
        val A_EYE_OFF  = 0xFF666670.toInt()
        val A_CHEV_CLS = 0xFF777782.toInt()
        val A_GRPHDR = 0xFF14141A.toInt()   // keyframe group header row
        val A_KEYROW = 0xFF101015.toInt()   // keyframe row
        val A_KEYLBL = 0xCC0E0E10.toInt()   // keyframe label strip
        val A_DRAGBG = 0x66000000           // reorder drop overlay
        val A_THMVOV = 0x77000000           // thumbnail scrim
        val A_FXSTRIP = 0x33FFFFFF
        val A_AUDWAV = 0xAAFFFFFF.toInt()
        val A_ARROW  = 0xFF222222.toInt()

        /// Clip pill fill per layer type (iOS TimelineView.drawRow).
        fun tlFill(t: LayerType): Int = when (t) {
            LayerType.SHAPE -> 0xFF2F6BFF.toInt()
            LayerType.TEXT -> 0xFFD9822B.toInt()
            LayerType.IMAGE -> 0xFF1FA67A.toInt()
            LayerType.VIDEO -> 0xFF8B5CF6.toInt()
            LayerType.CAMERA -> 0xFF6B7280.toInt()
            LayerType.NULL -> 0xFF9CA3AF.toInt()
            LayerType.MODEL -> 0xFFEC4899.toInt()
            LayerType.PARTICLES -> 0xFFCA8A04.toInt()
            LayerType.GROUP -> 0xFF4B4B55.toInt()
            LayerType.ADJUST -> 0xFF0EA5E9.toInt()
            LayerType.AUDIO -> 0xFF64748B.toInt()
            LayerType.FLARE -> 0xFFF59E0B.toInt()
            else -> 0xFF2F6BFF.toInt()
        }
    }

    // MARK: rows

    private class TRow(val kind: Int, val layer: Layer, val depth: Int, val label: String = "", val key: String = "") {
        var top: CGFloat = 0f
        var h: CGFloat = 0f
    }
    private var trows = ArrayList<TRow>()
    private var totalH: CGFloat = 0f

    // MARK: gesture state

    private var mode = 0          // 0 none, 1 scrub, 2 pending tap, 3 trim start, 4 trim end,
                                  // 5 move bar, 6 vscroll, 7 reorder, 8 keyframe drag
    private var downX: CGFloat = 0f
    private var downY: CGFloat = 0f
    private var lastX: CGFloat = 0f
    private var lastY: CGFloat = 0f
    private var moved = false
    private var tapLayer: Layer? = null
    private var tapEye: Layer? = null
    private var tapChev: Layer? = null
    private var tapKey: Triple<Layer, String, Int>? = null
    private var dragLayer: Layer? = null
    private var dragY: CGFloat = 0f
    private var dragKey: Key? = null
    private var retimeLayer: Layer? = null
    private var retimeSnap: RetimeSnap? = null
    private var dragTrack: Track? = null
    private var keyBegun = false
    private var dragGrab: CGFloat = 0f
    private var offCur = HashMap<Int, CGFloat>()
    private var offTgt = HashMap<Int, CGFloat>()

    private var longWork: Runnable? = null
    private val handler = Handler(Looper.getMainLooper())
    private var pinchDist: CGFloat? = null       // span of the tracked 2-finger pinch
    private var pinchPts = HashMap<Int, CGPoint>()  // live pointer positions (allTouches substitute)
    private val haptic = UIImpactFeedbackGenerator()
    // CADisplayLink twin (the shim link has no pause flag): a repeating main-thread tick
    // that runs only while the reorder-settle animation is busy.
    private var settleRunning = false
    private val settleTick = object : Runnable {
        override fun run() {
            if (!settleRunning) return
            setNeedsDisplay()
            handler.postDelayed(this, 1000L / 60L)
        }
    }

    private fun setSettlePaused(paused: Boolean) {
        if (paused) {
            settleRunning = false
            handler.removeCallbacks(settleTick)
        } else if (!settleRunning) {
            settleRunning = true
            handler.postDelayed(settleTick, 1000L / 60L)
        }
    }

    init {
        setBackgroundColor(TimelineView.A_BG)
        isMultipleTouchEnabled = true
    }

    // MARK: - public surface

    fun timecode(t: Float): String {
        val fps = max(1, Editor.project.fps)
        val total = roundAway(t * fps.toFloat()).toInt()
        return String.format(Locale.US, "%02d:%02d:%02d", total / fps / 60, (total / fps) % 60, total % fps)
    }

    fun fitToScene() {
        val usable = boundsRect.width - leftCol - 24f * d
        if (usable > 0f && Editor.scene.duration > 0.01f) {
            pxPerSec = clamp(usable / Editor.scene.duration, 10f * d, 900f * d)
        }
        setNeedsDisplay()
    }

    /** Opens every layer and group, or closes them all if everything is already open. */
    fun expandAll() {
        val ls = Editor.scene.layers
        if (ls.any { !openIds.contains(it.id) }) {
            openIds.addAll(ls.map { it.id })
        } else {
            openIds.clear()
        }
        setNeedsDisplay()
    }

    // MARK: - geometry

    private fun cx(): CGFloat = boundsRect.width / 2f
    private fun tx(t: Float): CGFloat = cx() + (t - Editor.time) * pxPerSec
    private fun xt(x: CGFloat): Float = Editor.time + ((x - cx()) / max(pxPerSec, 0.001f))

    // MARK: - thumbnails

    private val thumbs = HashMap<Int, UIImage>()      // main-thread only
    private val loading = HashSet<Int>()              // main-thread only

    private fun thumb(l: Layer): UIImage? {
        if (l.type != LayerType.IMAGE && l.type != LayerType.VIDEO) return null
        val cachedThumb = thumbs[l.id]
        if (cachedThumb != null) return cachedThumb
        val p = l.imagePath ?: return null
        if (loading.contains(l.id)) return null
        loading.add(l.id)
        val isImage = l.type == LayerType.IMAGE
        Thread {
            var img: UIImage? = null
            if (isImage) {
                val full = try { BitmapFactory.decodeFile(p) } catch (_: Exception) { null }
                if (full != null) {
                    val h = max(full.height.toFloat(), 1f)
                    val scale = min(1f, 160f / h)
                    img = if (scale < 1f) {
                        val szW = max(1f, full.width * scale).toInt()
                        val szH = max(1f, h * scale).toInt()
                        val bmp = Bitmap.createBitmap(szW, szH, Bitmap.Config.ARGB_8888)
                        android.graphics.Canvas(bmp).drawBitmap(full, null, android.graphics.RectF(0f, 0f, szW.toFloat(), szH.toFloat()), android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                        UIImage(bmp)
                    } else {
                        UIImage(full)
                    }
                }
            } else {
                try {
                    val gen = MediaMetadataRetriever()
                    gen.setDataSource(p)
                    val cg: android.graphics.Bitmap? = gen.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    gen.release()
                    if (cg != null) {
                        // gen.maximumSize = CGSize(width: 100000, height: 80): clamp height to 80px
                        var bmp = cg
                        if (cg.height > 80) {
                            val w = (cg.width * 80f / cg.height).toInt().coerceAtLeast(1)
                            bmp = Bitmap.createScaledBitmap(cg, w, 80, true)
                        }
                        img = UIImage(bmp)
                    }
                } catch (_: Exception) {
                }
            }
            Handler(Looper.getMainLooper()).post {
                loading.remove(l.id)
                if (img != null) {
                    thumbs[l.id] = img
                    setNeedsDisplay()
                }
            }
        }.start()
        return null
    }

    // MARK: - row building

    private fun puppetLabel(l: Layer, k: String): String {
        if (!k.startsWith("pp")) return k
        val pp = l.puppet ?: return k
        if (k.isEmpty()) return k
        val ax = k.last()
        val id = k.drop(2).dropLast(1).toIntOrNull() ?: 0
        return "Pin ${pp.number(id)} " + (if (ax == 'x') "X" else "Y")
    }

    private fun groupOf(l: Layer, k: String): String {
        if (Defs.transform.any { it.key == k } || Defs.pos3d.any { it.key == k } || Defs.rot3d.any { it.key == k }) return "Transform"
        if (k == "camFov") return "Camera"
        if (k.startsWith("pp") && l.puppet != null) return "Puppet"
        for (id in l.fx) {
            val e = Registry.get(id)
            if (e != null && e.props.any { l.pkey(id, it) == k }) {
                return if (id.contains("~")) e.name + " " + (id.split("~").lastOrNull() ?: "") else e.name
            }
        }
        return "Other"
    }

    /// The nearest Group above a layer, following the parent chain through ordinary layers too. A layer parented to a
    /// layer that sits in a group is therefore shown (and spans / moves) inside that group.
    fun holder(l: Layer, ls: List<Layer>): Layer? {
        var cur = l
        val seen = HashSet<Int>()
        seen.add(l.id)
        while (true) {
            val par = ls.firstOrNull { it.id == cur.parentId } ?: return null
            if (seen.contains(par.id)) return null
            if (par.type == LayerType.GROUP) return par
            seen.add(par.id); cur = par
        }
    }

    private fun members(g: Layer): List<Layer> {
        val ls = Editor.scene.layers
        return ls.filter { holder(it, ls) === g }
    }

    private fun build() {
        trows.clear()
        val ls = Editor.scene.layers

        fun emit(l: Layer, depth: Int) {
            trows.add(TRow(0, l, depth))
            if (!openIds.contains(l.id) || depth > 4) return
            if (l.type == LayerType.GROUP) {
                for (c in ls.reversed()) if (holder(c, ls) === l) emit(c, depth + 1)
            } else {
                val groups = HashMap<String, MutableList<String>>()
                val order = ArrayList<String>()
                for ((k, tr) in l.props) if (tr.keys.isNotEmpty()) {
                    val g = groupOf(l, k)
                    if (!groups.containsKey(g)) { groups[g] = ArrayList(); order.add(g) }
                    groups[g]!!.add(k)
                }
                if (groups.isEmpty()) {
                    trows.add(TRow(3, l, depth + 1, "No keyframes yet"))
                }
                for (g in order) {
                    trows.add(TRow(1, l, depth + 1, g))
                    for (k in groups[g]!!) {
                        trows.add(TRow(2, l, depth + 2, Registry.propDef(k)?.label ?: puppetLabel(l, k), k))
                    }
                }
            }
        }

        for (l in ls.reversed()) {
            if (holder(l, ls) == null) emit(l, 0)
        }
        var y: CGFloat = 0f
        for (row in trows) {
            row.top = y
            row.h = if (row.kind == 0) rowH else paramH
            y += row.h
        }
        totalH = y
    }

    /** Start and end shown for a layer; groups span their children. */
    private fun extent(l: Layer): Pair<Float, Float> {
        if (l.type != LayerType.GROUP) return Pair(l.start, l.end)
        val kids = members(l)
        if (kids.isEmpty()) return Pair(0f, Editor.scene.duration)
        return Pair(kids.map { it.start }.minOrNull() ?: 0f, kids.map { it.end }.maxOrNull() ?: 0f)
    }

    private fun fitDuration() {
        val mx = Editor.scene.layers.filter { it.type != LayerType.GROUP }.map { it.end }.maxOrNull() ?: 0f
        if (mx > Editor.scene.duration + 0.001f) Editor.scene.duration = min(mx, 600f)
    }

    private fun rowFor(l: Layer): TRow? = trows.firstOrNull { it.kind == 0 && it.layer === l }

    private fun rowAt(y: CGFloat): TRow? {
        if (y < rulerH) return null
        for (row in trows) {
            val t = rulerH + row.top - scrollY
            if (y >= t && y < t + row.h) return row
        }
        return null
    }

    /** True for the top layer of a group that has its mask turned on. */
    private fun isMaskLayer(l: Layer): Boolean {
        val g = Editor.scene.layers.firstOrNull { it.id == l.parentId } ?: return false
        if (g.type != LayerType.GROUP || g.mask == 0) return false
        return Editor.scene.layers.lastOrNull { it.parentId == g.id }?.id == l.id
    }

    private fun siblings(l: Layer): List<TRow> {
        // rows shown at the same level of the same group (layers parented to ordinary layers are listed flat, so
        // comparing parentId made every such layer its own island and a Solid could not be moved among them)
        val ls = Editor.scene.layers
        val h = holder(l, ls)
        val d = rowFor(l)?.depth ?: 0
        return trows.filter { it.kind == 0 && it.depth == d && holder(it.layer, ls) === h }
    }

    // MARK: - drawing

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        draw0(c)
    }

    private fun draw0(c: CGContext) {
        val w = boundsRect.width
        val h = boundsRect.height
        val scene = Editor.scene
        build()
        fillRect(c, CGRect(0f, 0f, w, h), TimelineView.A_BG)

        // ruler
        val steps = listOf(0.1f, 0.2f, 0.5f, 1f, 2f, 5f, 10f, 30f, 60f)
        var step: CGFloat = 60f
        for (s in steps) if (s * pxPerSec >= 88f * d) { step = s; break }
        var t = floor(xt(0f) / step) * step
        val t1 = xt(w)
        while (t <= t1) {
            if (t >= -0.0001f) {
                val x = tx(t)
                strokeLine(c, x, rulerH - 14f * d, x, rulerH, 1f * d, TimelineView.A_TICK)
                val label = if (step >= 1f) String.format(Locale.US, "%d", roundAway(t).toInt()) else String.format(Locale.US, "%.1f", t)
                drawText(label, x, rulerH - 18f * d, color = TimelineView.A_DIM, size = 11f * d, align = NSTextAlignment.center)
            }
            for (k in 1..4) {
                val mt = t + step * k.toFloat() / 5f
                if (mt >= 0f && step * pxPerSec / 5f > 14f * d) {
                    strokeLine(c, tx(mt), rulerH - 6f * d, tx(mt), rulerH, 1f * d, TimelineView.A_TICK)
                }
            }
            t += step
        }
        strokeLine(c, max(tx(0f), 0f), 1.5f * d, min(tx(scene.duration), w), 1.5f * d, 3f * d, TimelineView.A_GREEN)
        if (FrameCache.enabled) {
            for ((a, b) in FrameCache.cachedRuns()) {
                val x0 = max(tx(a), 0f); val x1 = min(tx(min(b, scene.duration)), w)
                if (x1 > x0) strokeLine(c, x0, 5.5f * d, x1, 5.5f * d, 3f * d, TimelineView.A_CACHE)
            }
        }
        for (m in scene.markers) {
            val x = tx(m)
            fillTri(c, CGPoint(x - 6f * d, rulerH - 12f * d),
                    CGPoint(x + 6f * d, rulerH - 12f * d),
                    CGPoint(x, rulerH), TimelineView.A_BLUE)
            strokeLine(c, x, rulerH, x, h, 1f * d, TimelineView.A_TICK)
            val mnm = scene.markerName(m)
            if (mnm != null) {
                drawText(mnm, x + 8f * d, rulerH - 14f * d, color = TimelineView.A_BLUE,
                         size = 10f * d, bold = true)
            }
        }

        // rows
        advanceOffsets()
        c.saveGState()
        c.clip(CGRect(0f, rulerH, w, h - rulerH))
        val sel = editHost?.selectedId() ?: -1
        for (row in trows) {
            if (row.layer === dragLayer && row.kind == 0) continue
            var top = rulerH + row.top - scrollY
            if (row.kind == 0) top += offCur[row.layer.id] ?: 0f
            if (top > h || top + row.h < rulerH) continue
            drawRow(c, row, top, sel)
        }
        val dl = dragLayer
        if (dl != null) {
            val row = rowFor(dl)
            if (row != null) {
                val top = clamp(dragY - dragGrab, rulerH, h - rowH)
                fillRect(c, CGRect(0f, top - 2f * d, w, rowH + 4f * d), TimelineView.A_DRAGBG)
                drawRow(c, row, top, sel)
            }
        }
        c.restoreGState()

        // playhead: fixed at the horizontal centre
        val px = cx()
        strokeLine(c, px, 0f, px, h, 2f * d, TimelineView.A_GREEN)
        val tc = timecode(Editor.time)
        val bw = measureText(tc, 12f * d, true) + 18f * d
        fillRoundRect(c, CGRect(px - bw / 2f, 4f * d, bw, 20f * d),
                      10f * d, TimelineView.A_GREEN)
        drawText(tc, px, 19f * d, color = TimelineView.A_PILLTX, size = 12f * d, bold = true, align = NSTextAlignment.center)
    }

    private fun drawRow(c: CGContext, row: TRow, top: CGFloat, sel: Int) {
        val w = boundsRect.width
        val l = row.layer
        val indent = row.depth.toFloat() * 10f * d
        val multiSel = editHost?.isSelected(l.id) ?: false

        if (row.kind == 0) {
            var s0 = l.start
            var e0 = l.end
            if (l.type == LayerType.GROUP) {
                val kids = members(l)
                if (kids.isNotEmpty()) {
                    s0 = kids.map { it.start }.minOrNull() ?: 0f
                    e0 = kids.map { it.end }.maxOrNull() ?: 0f
                } else {
                    s0 = 0f
                    e0 = Editor.scene.duration
                }
            }
            val x0 = tx(s0)
            val x1 = tx(e0)
            val r = CGRect(x0, top + 4f * d, x1 - x0, rowH - 8f * d)
            val base = TimelineView.tlFill(l.type)
            val body = if (l.visible) argbToUIColor(base) else argbToUIColor(base).withAlphaComponent(90f / 255f)
            c.setFillColor(body.cgColor)
            c.addPath(CGPath.roundedRect(r, 7f * d, 7f * d))
            c.fillPath()

            val tb = thumb(l)
            if (tb != null && l.visible) {
                c.saveGState()
                c.clip(r)
                val cg = tb.cgImage
                if (cg != null) {
                    val th = r.height
                    val tw = max(1f, th * cg.width.toFloat() / max(cg.height.toFloat(), 1f))
                    var x = max(r.minX, 0f)
                    val endX = min(r.maxX, w)
                    val p = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
                    while (x < endX) {
                        c.canvas.drawBitmap(tb.bitmap, null, android.graphics.RectF(x, r.minY, x + tw, r.minY + th), p)
                        x += tw
                    }
                }
                c.restoreGState()
                fillRoundRect(c, r, 7f * d, TimelineView.A_THMVOV)
            }
            if (l.type == LayerType.AUDIO) {
                val origin = tx(l.start)
                var x = max(r.minX, leftCol)
                val ex = min(r.maxX, w)
                val mid = r.midY
                val pk = l.imagePath?.let { Waveform.peaks(it) { setNeedsDisplay() } }
                val dur = max(l.srcDur, 0.01f)
                while (x < ex) {
                    var amp = 0.05f
                    if (pk != null && pk.isNotEmpty()) {
                        // time in the source file under this pixel column
                        val t0 = ((x - origin) / (tx(l.start + 1f) - origin)) + l.srcOffset
                        val t1 = t0 + 3f * d / (tx(l.start + 1f) - origin)
                        val i0 = max(0, min(pk.size - 1, (t0 / dur * pk.size).toInt()))
                        val i1 = max(i0, min(pk.size - 1, (t1 / dur * pk.size).toInt()))
                        for (i in i0..i1) amp = max(amp, pk[i])
                    }
                    val hh = amp * r.height * 0.45f
                    strokeLine(c, x, mid - hh, x, mid + hh, 1.5f * d, TimelineView.A_AUDWAV)
                    x += 3f * d
                }
            }
            if (l.fx.isNotEmpty()) {
                fillRect(c, CGRect(r.minX + 6f * d, r.maxY - 6f * d,
                                   r.maxX - r.minX - 12f * d, 3f * d),
                         TimelineView.A_FXSTRIP)
            }
            if (l.type != LayerType.GROUP) {
                val seen = HashSet<Int>()
                for ((_, tr) in l.props) {
                    for (k in tr.keys) {
                        val kx = tx(k.t)
                        if (kx < x0 || kx > x1) continue
                        val key100 = roundAway(k.t * 100f).toInt()
                        if (!seen.add(key100)) continue
                        diamond(c, kx, r.midY, 4.5f * d, TimelineView.A_TEXT)
                    }
                }
            }
            // name inside the pill
            c.saveGState()
            c.clip(CGRect(max(r.minX + 8f * d, leftCol), r.minY,
                          max(0f, r.maxX - 8f * d - max(r.minX + 8f * d, leftCol)),
                          r.height))
            val maskTag = if (isMaskLayer(l)) "ask] " else ""
            val durTag = String.format(Locale.US, "%.1fs", l.end - l.start)
            val fxTag = if (l.fx.isEmpty()) "" else "  fx${l.fx.size}"
            val nameStr = if (l.type == LayerType.GROUP)
                l.name + (if (l.mask != 0) "  (mask" + (if (l.mask == 2 || l.mask == 4) ", inverted" else "") + ")" else "")
            else
                maskTag + l.name + "  " + durTag + fxTag
            drawText(nameStr, max(r.minX, leftCol) + 8f * d + indent, top + rowH / 2f + 4f * d,
                     color = TimelineView.A_TEXT, size = 11f * d, bold = true)
            c.restoreGState()

            if (l.id == sel && l.type != LayerType.GROUP) {
                strokeRoundRect(c, r, 7f * d, 2f * d, TimelineView.A_TEXT)
                for (side in 0..1) {
                    val hx = if (side == 0) r.minX else r.maxX
                    val hr = CGRect(hx - 9f * d, r.minY - 1f * d, 18f * d, r.height + 2f * d)
                    fillRoundRect(c, hr, 6f * d, TimelineView.A_TEXT)
                    val cy = r.midY
                    val dir: CGFloat = if (side == 0) -1f else 1f
                    fillTri(c, CGPoint(hx + dir * 3f * d, cy - 4f * d),
                            CGPoint(hx + dir * 3f * d, cy + 4f * d),
                            CGPoint(hx - dir * 2f * d, cy), TimelineView.A_ARROW)
                }
            } else if (multiSel) {
                strokeRoundRect(c, r, 7f * d, 2f * d, TimelineView.A_TEXT)
            }

            // left column (drawn over the track)
            fillRect(c, CGRect(0f, top, leftCol, rowH), TimelineView.A_BG)
            val cy = top + rowH / 2f
            Icons.draw(c, if (l.visible) "eye" else "eye_off", leftCol * 0.27f, cy, 19f * d,
                       if (l.visible) TimelineView.A_TEXT else TimelineView.A_EYE_OFF)
            Icons.draw(c, "chev_up", leftCol * 0.74f, cy, 19f * d,
                       if (openIds.contains(l.id)) TimelineView.A_AMBER else TimelineView.A_CHEV_CLS)
            // right drag handle column
            fillRect(c, CGRect(w - 30f * d, top, 30f * d, rowH), TimelineView.A_BG)
            Icons.draw(c, "handle", w - 16f * d, cy, 16f * d, TimelineView.A_DIM)
        } else if (row.kind == 1) {
            fillRect(c, CGRect(0f, top, w, row.h), TimelineView.A_GRPHDR)
            drawText(row.label, leftCol + 8f * d + indent, top + row.h / 2f + 4f * d,
                     color = TimelineView.A_GREEN, size = 11f * d, bold = true)
        } else if (row.kind == 2) {
            fillRect(c, CGRect(0f, top, w, row.h), TimelineView.A_KEYROW)
            val tr = l.props[row.key]
            if (tr != null) {
                for (k in tr.keys) {
                    val on = abs(k.t - Editor.time) < 0.03f
                    diamond(c, tx(k.t), top + row.h / 2f, 5f * d,
                            if (on) TimelineView.A_GREEN else TimelineView.A_TEXT)
                }
            }
            fillRect(c, CGRect(leftCol, top, 150f * d, row.h), TimelineView.A_KEYLBL)
            drawText(row.label, leftCol + 8f * d + indent, top + row.h / 2f + 4f * d,
                     color = TimelineView.A_DIM, size = 11f * d)
        } else {
            drawText(row.label, leftCol + 8f * d + indent, top + row.h / 2f + 4f * d,
                     color = TimelineView.A_DIM, size = 11f * d)
        }
    }

    private fun diamond(c: CGContext, x: CGFloat, y: CGFloat, s: CGFloat, col: Int) {
        fillTri(c, CGPoint(x, y - s), CGPoint(x + s, y), CGPoint(x, y + s), col)
        fillTri(c, CGPoint(x, y + s), CGPoint(x - s, y), CGPoint(x, y - s), col)
    }

    private fun fillTri(c: CGContext, a: CGPoint, b: CGPoint, p: CGPoint, col: Int) {
        val path = CGPath()
        path.move(a)
        path.addLine(b)
        path.addLine(p)
        path.closeSubpath()
        c.addPath(path.path)
        c.setFillColor(argbToUIColor(col).cgColor)
        c.fillPath()
    }

    /// Drags a keyframe along the timeline; snaps to beat markers and frames.
    private fun moveKey(x: CGFloat) {
        val k = dragKey ?: return
        val tr = dragTrack ?: return
        val fps = max(1, Editor.project.fps).toFloat()
        var t = xt(x)
        val m = Editor.scene.markers.minByOrNull { abs(it - t) }
        if (m != null && abs(m - t) < 8f * d / pxPerSec) {
            t = m
        } else {
            t = roundAway(t * fps) / fps
        }
        t = clamp(t, 0f, Editor.scene.duration)
        if (tr.keys.any { it !== k && abs(it.t - t) < 0.5f / fps }) return
        k.t = t
        tr.keys.sortBy { it.t }
        retimeLayer?.retime(retimeSnap)      // other params follow the footage
        tlHost?.onTimingChanged()
        setNeedsDisplay()
    }

    /// Smoothly slides the rows that the dragged layer passes over.
    private fun advanceOffsets() {
        offTgt.clear()
        val dl = dragLayer
        if (dl != null) {
            val sib = siblings(dl)
            val src = sib.indexOfFirst { it.layer === dl }.let { if (it < 0) 0 else it }
            val tgt = targetIndex(sib)
            for ((i, s) in sib.withIndex()) if (s.layer !== dl) {
                if (tgt < src && i >= tgt && i < src) {
                    offTgt[s.layer.id] = rowH
                } else if (tgt > src && i > src && i <= tgt) {
                    offTgt[s.layer.id] = -rowH
                } else {
                    offTgt[s.layer.id] = 0f
                }
            }
        }
        var busy = false
        val ids = HashSet(offCur.keys)
        ids.addAll(offTgt.keys)
        for (id in ids) {
            val cur = offCur[id] ?: 0f
            val tg = offTgt[id] ?: 0f
            val nv = cur + (tg - cur) * 0.32f
            if (abs(tg - nv) < 0.5f) {
                if (tg == 0f) offCur.remove(id) else offCur[id] = tg
            } else {
                offCur[id] = nv
                busy = true
            }
        }
        settleLinkPause(!(busy || dragLayer != null))
    }

    private fun settleLinkPause(paused: Boolean) = setSettlePaused(paused)

    private fun targetIndex(sib: List<TRow>): Int {
        if (dragLayer == null) return 0
        val center = dragY - dragGrab + rowH / 2f
        var best = sib.indexOfFirst { it.layer === dragLayer }.let { if (it < 0) 0 else it }
        var bd = Float.MAX_VALUE
        for ((i, s) in sib.withIndex()) {
            val cc = rulerH + s.top - scrollY + rowH / 2f
            val dd = abs(cc - center)
            if (dd < bd) { bd = dd; best = i }
        }
        return best
    }

    // MARK: - long press

    private fun scheduleLongPress() {
        stopLongPressTimer()
        val work = Runnable { longPressFired() }
        longWork = work
        handler.postDelayed(work, 420)
    }

    private fun stopLongPressTimer() {
        longWork?.let { handler.removeCallbacks(it) }
        longWork = null
    }

    private fun longPressFired() {
        longWork = null
        val l = tapLayer ?: return
        if (mode == 2 || mode == 5 || mode == 3 || mode == 4) {
            dragLayer = l
            mode = 7
            openIds.remove(l.id)
            haptic.impactOccurred()
            val row = rowFor(l)
            dragGrab = if (row != null) downY - (rulerH + row.top - scrollY) else rowH / 2f
            dragY = downY
            setNeedsDisplay()
        }
    }

    // MARK: - touches

    override fun touchesBegan(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val p = t.location(this)
        for (tt in touches) pinchPts[tt.hashCode()] = t.location(this)

        if (touches.size > 1) {
            // second finger landed: pinch takes over
            stopLongPressTimer()
            if (mode != 7) mode = 0
            pinchDist = null
            return
        }

        downX = p.x; downY = p.y; lastX = p.x; lastY = p.y; moved = false
        tapLayer = null; tapEye = null; tapChev = null; tapKey = null
        pinchDist = null
        disallowParentScrollInterception(this, true)
        val row = rowAt(p.y)
        mode = 1
        if (row != null && row.kind == 0) {
            val l = row.layer
            if (p.x > boundsRect.width - 30f * d) {
                dragLayer = l
                mode = 7
                openIds.remove(l.id)
                dragGrab = downY - (rulerH + row.top - scrollY)
                dragY = downY
                haptic.impactOccurred()
            } else if (p.x < leftCol * 0.5f) {
                tapEye = l
                mode = 0
            } else if (p.x < leftCol) {
                tapChev = l
                mode = 0
            } else {
                val (e0, e1) = extent(l)
                val x0 = tx(e0)
                val x1 = tx(e1)
                val hit: CGFloat = 22f * d
                val isSel = l.id == (editHost?.selectedId() ?: -1) && l.type != LayerType.GROUP
                if (isSel && abs(p.x - x0) < hit) {
                    tlHost?.beginEdit(); mode = 3
                } else if (isSel && abs(p.x - x1) < hit) {
                    tlHost?.beginEdit(); mode = 4
                } else if (l.id == (editHost?.selectedId() ?: -1) && p.x >= x0 && p.x <= x1) {
                    tlHost?.beginEdit(); mode = 5
                } else {
                    mode = 2
                }
                tapLayer = l
                scheduleLongPress()
            }
        } else if (row != null && row.kind == 2) {
            val tr = row.layer.props[row.key]
            if (tr != null) {
                var hitIdx = -1
                for ((i, k) in tr.keys.withIndex()) if (abs(p.x - tx(k.t)) < 20f * d) hitIdx = i
                tapLayer = row.layer
                mode = 2
                if (hitIdx >= 0) {
                    tapKey = Triple(row.layer, row.key, hitIdx)
                    dragKey = tr.keys[hitIdx]
                    dragTrack = tr
                    retimeLayer = if (row.key == "remapT") row.layer else null
                    retimeSnap = retimeLayer?.retimeSnapshot()
                    mode = 8
                }
            } else {
                tapLayer = row.layer
                mode = 2
            }
        } else if (p.y > rulerH) {
            tapLayer = row?.layer
            mode = 2
        }
    }

    override fun touchesMoved(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val p = t.location(this)
        for (tt in touches) pinchPts[tt.hashCode()] = t.location(this)

        // ---- manual two-finger pinch (Android ScaleGestureDetector)
        if (pinchPts.size > 1) {
            stopLongPressTimer()
            if (mode != 7) mode = 0
            val pair = pinchPts.entries.sortedBy { it.key }
            val a = pair[0].value
            val b = pair[1].value
            val dist = hypot(a.x - b.x, a.y - b.y)
            val prev = pinchDist
            if (prev != null && prev > 1f) {
                pxPerSec = clamp(pxPerSec * dist / prev, 10f * d, 900f * d)
                setNeedsDisplay()
            }
            pinchDist = dist
            lastX = a.x; lastY = a.y
            return
        }
        if (pinchDist != null) { pinchDist = null; lastX = p.x; lastY = p.y }

        val dx = p.x - lastX
        val dy = p.y - lastY
        if (abs(p.x - downX) > 8f * d || abs(p.y - downY) > 8f * d) {
            moved = true
            if (mode != 7) stopLongPressTimer()
        }

        when (mode) {
            7 -> {
                dragY = p.y
                setNeedsDisplay()
            }
            8 -> {
                if (moved) {
                    if (!keyBegun) { tlHost?.beginEdit(); keyBegun = true }
                    moveKey(p.x)
                }
            }
            1, 2 -> {
                if ((mode == 2 || mode == 1) && moved && abs(p.y - downY) > abs(p.x - downX) * 1.2f
                    && totalH > boundsRect.height - rulerH - 1f) {
                    mode = 6
                } else if (moved) {
                    mode = 1
                    tlHost?.onSeek(clamp(Editor.time - dx / pxPerSec, 0f, Editor.scene.duration))
                }
            }
            6 -> {
                scrollY = clamp(scrollY - dy, 0f, max(0f, totalH + 8f * d - (boundsRect.height - rulerH)))
                setNeedsDisplay()
            }
            3, 4, 5 -> {
                val layers = Editor.scene.layers
                val l = layers.firstOrNull { it.id == (editHost?.selectedId() ?: -1) }
                if (l != null && moved) {
                    val fps = max(1, Editor.project.fps).toFloat()
                    if (mode == 3) {
                        val ns = clamp(roundAway(xt(p.x) * fps) / fps, 0f, max(0f, l.end - 0.1f))
                        if (l.type == LayerType.VIDEO || l.type == LayerType.AUDIO) l.srcOffset += ns - l.start
                        l.start = ns
                    } else if (mode == 4) {
                        var ne = max(roundAway(xt(p.x) * fps) / fps, l.start + 0.1f)
                        if ((l.type == LayerType.VIDEO || l.type == LayerType.AUDIO) && l.srcDur > 0f) {
                            ne = min(ne, l.start + l.srcDur - l.srcOffset)
                        }
                        l.end = max(ne, l.start + 0.1f)
                        fitDuration()
                    } else {
                        if (l.type == LayerType.GROUP) {
                            val kids = ArrayList<Layer>()
                            val queue = ArrayList<Int>()
                            queue.add(l.id)
                            while (!queue.isEmpty()) {
                                val pid = queue.removeAt(queue.size - 1)
                                for (cL in layers) if (cL.parentId == pid && !kids.any { it === cL }) { kids.add(cL); queue.add(cL.id) }
                            }
                            if (kids.isNotEmpty()) {
                                val lo = -(kids.map { it.start }.minOrNull() ?: 0f)
                                val dt = max(dx / pxPerSec, lo)
                                for (k in kids) { k.start += dt; k.end += dt; k.shiftKeys(dt) }
                                fitDuration()
                            }
                        } else {
                            val len = l.end - l.start
                            val ns = max(l.start + dx / pxPerSec, 0f)
                            l.shiftKeys(ns - l.start)
                            l.start = ns
                            l.end = ns + len
                            fitDuration()
                        }
                    }
                    tlHost?.onTimingChanged()
                    setNeedsDisplay()
                }
            }
        }
        lastX = p.x; lastY = p.y
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        for (tt in touches) pinchPts.remove(tt.hashCode())
        val remaining = pinchPts.entries.filter { it.value != null }.map { it.value }
        if (remaining.size >= 2) {
            pinchDist = null
            return
        }
        if (remaining.size == 1) {
            // a pinch just lost one finger: the rest of the gesture is dead,
            // exactly like the Android early-return on pointerCount > 1
            pinchDist = null
            val rp = remaining.first()
            lastX = rp.x; lastY = rp.y
            return
        }

        stopLongPressTimer()
        disallowParentScrollInterception(this, false)
        val layers = Editor.scene.layers
        if (mode == 7) {
            val dl = dragLayer
            if (dl != null) {
                val sib = siblings(dl)
                val ti = targetIndex(sib)
                if (ti in sib.indices) {
                    val tl = sib[ti].layer
                    if (tl !== dl) {
                        val listIdx = layers.indexOfFirst { it === tl }.let { if (it < 0) 0 else it }
                        tlHost?.onReorder(dl, listIdx)
                    }
                }
            }
            dragLayer = null
            offCur.clear()
            offTgt.clear()
            settleLinkPause(true)
            setNeedsDisplay()
        } else if (!moved) {
            val eye = tapEye
            val chev = tapChev
            val key = tapKey
            val tl = tapLayer
            if (eye != null) {
                tlHost?.onToggleVisible(eye)
            } else if (chev != null) {
                if (!openIds.remove(chev.id)) openIds.add(chev.id)
                setNeedsDisplay()
            } else if (key != null) {
                tlHost?.onKeyTap(key.first, key.second, key.third)
            } else if (tl != null) {
                tlHost?.onSelect(tl.id)
            } else if (mode == 2) {
                tlHost?.onSelect(-1)
            }
        }
        dragKey = null; dragTrack = null; keyBegun = false; retimeLayer = null; retimeSnap = null
        mode = 0
    }

    override fun touchesCancelled(touches: Set<UITouch>, event: UIEvent?) {
        for (tt in touches) pinchPts.remove(tt.hashCode())
        stopLongPressTimer()
        disallowParentScrollInterception(this, false)
        dragLayer = null
        offCur.clear()
        offTgt.clear()
        settleLinkPause(true)
        pinchDist = null
        mode = 0
    }
}
