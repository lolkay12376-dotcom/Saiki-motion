package com.saiki.motion.ui

import android.os.Handler
import android.os.Looper
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.NSTextAlignment

// Port of Sources/UI/Toast.swift — the android.widget.Toast replacement: a small rounded dark label
// overlay on the key window that fades out after ~2.2s.
object Toast {
    private var current: UiView? = null
    private val handler = Handler(Looper.getMainLooper())

    fun show(text: String) {
        handler.post {
            val window = appKeyWindow() ?: return@post
            current?.let { it.removeFromSuperview(); current = null }
            val lbl = object : UiView(window.context) {
                override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    fillRoundRect(c, rect, 16f, 0xF5222228.toInt())
                    drawText(text, rect.midX, rect.midY + 5f, color = C.TEXT, size = 14f, bold = false,
                             align = NSTextAlignment.center)
                }
            }
            val maxW = window.rectWidth() - 48f
            val lines = 1 + text.length / 34
            val w = minOf(maxW, measureText(text, 14f) + 36f)
            val h = 24f + 18f * lines
            lbl.frame = CGRect((window.rectWidth() - w) / 2, window.rectHeight() - 160f - h, w, h)
            window.addSubview(lbl)
            current = lbl
            lbl.animate().alpha(1f).setDuration(150).start()
            handler.postDelayed({
                lbl.animate().alpha(0f).setDuration(350).withEndAction {
                    lbl.removeFromSuperview()
                    if (current === lbl) current = null
                }.start()
            }, 2050)
        }
    }
}
