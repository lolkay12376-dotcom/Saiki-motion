@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

// Port of Sources/UI/UniverseDashboard.swift — full-screen dashboard for Universe Glow / Universe
// Prism Displacement ("Open Dashboard…"). Live preview, preset grid with thumbnails of the neon
// skyline sample, every parameter. Close reverts, Apply keeps.
// CIContext bloom/tint thumbnails are approximated with a blur + screen tint (no CoreImage twin).

package com.saiki.motion.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.saiki.motion.core.ColorParam
import com.saiki.motion.core.EffectDef
import com.saiki.motion.core.Editor
import com.saiki.motion.core.Layer
import com.saiki.motion.core.PropDef
import com.saiki.motion.core.Registry
import com.saiki.motion.core.SceneRenderer
import com.saiki.motion.core.UniversePreset
import com.saiki.motion.core.UniversePresets
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIColor
import com.saiki.motion.uikit.UIColorWell
import com.saiki.motion.uikit.UIFont
import com.saiki.motion.uikit.UILabel
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UISegmentedControl
import com.saiki.motion.uikit.UISlider
import com.saiki.motion.uikit.UISwitch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIViewController
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.appContext
import com.saiki.motion.uikit.argbToUIColor
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class UniverseDashboardViewController(private val lay: Layer, private val entry: String, private val onDone: () -> Unit) : UIViewController() {
    private val def: EffectDef? = Registry.get(entry)
    private val presets: List<UniversePreset> = UniversePresets.list(Registry.get(entry)?.id ?: "uglow")
    private val snap = HashMap<String, Float>()
    private var savedVideoCb: (() -> Unit)? = null
    private val pv by lazy {
        savedVideoCb = SceneRenderer.onVideoFrame
        PreviewView(appContext!!).apply { quality = 2 }
    }
    private val accent = argbToUIColor(C.BLUE)
    private val rows = UiView(appContext!!)
    private val grid = UiView(appContext!!)
    private val refreshers = ArrayList<() -> Unit>()
    private val thumbs = HashMap<Int, Bitmap>()
    private val head = UILabel(appContext!!)

    init {
        for ((k, t) in lay.props) if (k.startsWith(entry + "__")) snap[k] = t.base
    }

    private fun key(k: String) = "${entry}__$k"

    private fun valx(k: String): Float {
        val t = lay.props[key(k)]
        if (t != null) return t.eval(lay.editTime(key(k), Editor.time))
        return def?.props?.firstOrNull { it.key == k }?.def ?: 0f
    }

    private fun set(k: String, v: Float) { lay.track(key(k)).base = v }

    private fun setColor(k: String, argb: Long) {
        lay.track(key(k) + "_a").base = ((argb shr 24) and 0xFF).toFloat() / 255f
        lay.track(key(k) + "_r").base = ((argb shr 16) and 0xFF).toFloat() / 255f
        lay.track(key(k) + "_g").base = ((argb shr 8) and 0xFF).toFloat() / 255f
        lay.track(key(k) + "_b").base = (argb and 0xFF).toFloat() / 255f
    }

    private fun colorVal(cp: ColorParam): UIColor {
        val d = cp.def.toLong() and 0xFFFFFFL
        fun comp(suf: String, sh: Int): Float {
            val t = lay.props[key(cp.key) + suf]
            return if (t != null) t.base else ((d shr sh) and 0xFF).toFloat() / 255f
        }
        return UIColor.rgb(comp("_r", 16), comp("_g", 8), comp("_b", 0), 1f)
    }

    private val bar = UiView(appContext!!)
    private val box = UiView(appContext!!)
    private val scroll = UIScrollView(appContext!!)
    private val titleL = UILabel(appContext!!)
    private val closeBtn = PillButton("✕", null, C.CARD2, C.TEXT)
    private val applyBtn = PillButton("Apply Effect", null, C.BLUE, C.TEXT)

    override fun viewDidLoad() {
        super.viewDidLoad()
        view.setBackgroundColor(0xFF141414.toInt())
        titleL.text = UniversePresets.title[def?.id ?: ""] ?: def?.name ?: ""
        titleL.font = UIFont.semiboldSystemFont(18f); titleL.textColor = UIColor.white
        titleL.textAlignment = NSTextAlignment.center
        closeBtn.onClick = { finish(apply = false) }
        applyBtn.onClick = { finish(apply = true) }
        view.addSubview(bar); view.addSubview(box); view.addSubview(head); view.addSubview(grid); view.addSubview(scroll)
        bar.addSubview(closeBtn); bar.addSubview(titleL); bar.addSubview(applyBtn)
        box.setBackgroundColor(0xFF000000.toInt())
        box.addSubview(pv)
        head.text = "PRESETS"; head.font = UIFont.semiboldSystemFont(13f); head.textColor = UIColor(0xFFB3B3B3.toInt())
        scroll.addSubview(rows)
        for (pd in def?.props ?: emptyList()) rows.addSubview(row(pd))
        for (cp in def?.colors ?: emptyList()) rows.addSubview(colorRow(cp))
        relayout()
        view.onLayout = { _ -> relayout() }
        buildThumbs()
    }

    private fun relayout() {
        val w = view.rectWidth(); val h = view.rectHeight()
        if (w < 10 || h < 10) return
        bar.frame = CGRect(0f, 0f, w, 52f)
        closeBtn.frame = CGRect(12f, 9f, 92f, 34f)
        applyBtn.frame = CGRect(w - 120f, 9f, 108f, 34f)
        titleL.frame = CGRect(104f, 11f, w - 236f, 30f)
        box.frame = CGRect(0f, 52f, w, h * 0.3f)
        val aspect = max(Editor.project.w, 1).toFloat() / max(Editor.project.h, 1).toFloat()
        var pw = box.rectWidth(); var ph = pw / aspect
        if (ph > box.rectHeight()) { ph = box.rectHeight(); pw = ph * aspect }
        pv.frame = CGRect((box.rectWidth() - pw) / 2, (box.rectHeight() - ph) / 2, pw, ph)
        head.frame = CGRect(14f, box.frame.maxY + 10f, 100f, 20f)
        val gridH = if (presets.size > 6) 176f else 88f
        grid.frame = CGRect(0f, head.frame.maxY + 6f, w, gridH)
        layoutGrid(w)
        scroll.frame = CGRect(0f, grid.frame.maxY + 10f, w, h - grid.frame.maxY - 10f)
        layoutRows()
    }

    private fun layoutGrid(w: Float) {
        grid.subviews.toList().forEach { it.removeFromSuperview() }
        var x = 12f
        for ((i, p) in presets.withIndex()) {
            val cell = object : TapView() {
                public override fun draw(rect: CGRect) {
                    val c = UIGraphics.getCurrentContext() ?: return
                    val th = thumbs[i]
                    if (th != null) {
                        c.canvas.drawBitmap(th, null, android.graphics.RectF(0f, 0f, rect.width, 64f),
                            android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG))
                    } else {
                        fillRoundRect(c, CGRect(0f, 0f, rect.width, 64f), 4f, 0xFF262626.toInt())
                    }
                    drawText(p.name, rect.midX, 80f, color = 0xFFD9D9D9.toInt(), size = 11f, bold = true, align = NSTextAlignment.center)
                }
            }
            cell.setBackgroundColor(0x00000000)
            cell.onClick = { applyPreset(p) }
            cell.frame = CGRect(x, 0f, 116f, 84f)
            cell.clipsToBounds = true
            grid.addSubview(cell)
            x += 116f + 6f
        }
        grid.frame = CGRect(grid.frame.x, grid.frame.y, max(x, grid.rectWidth()), grid.rectHeight())
    }

    private fun layoutRows() {
        var y = 0f
        for (v in rows.subviews) {
            val vh = if (v.subviews.size == 2 && v.subviews[1] is UISwitch) 32f
            else if (v.subviews.size == 3 && v.subviews[2] is UIColorWell) 34f
            else if (v.subviews.size == 3 && v.subviews[1] is PillButton) 34f
            else 64f
            v.frame = CGRect(16f, y, max(scroll.rectWidth() - 32f, 10f), vh)
            v.onLayout?.invoke(max(scroll.rectWidth() - 32f, 10f))
            y += vh + 8f
        }
        rows.frame = CGRect(0f, 0f, scroll.rectWidth(), y + 16f)
        scroll.contentSize = CGSize(scroll.rectWidth(), y + 16f)
    }

    override fun viewDidAppear(a: Boolean) {
        super.viewDidAppear(a)
        pv.requestDraw()
        android.os.Handler(android.os.Looper.getMainLooper()).post { pv.requestDraw() }
    }

    // MARK: rows

    private fun row(pd: PropDef): UiView {
        val name = UILabel(appContext!!)
        name.text = pd.label; name.textColor = UIColor.white; name.font = UIFont.systemFont(13f)
        val opts = pd.options
        if (opts != null) {
            if (opts.size == 2) {
                val sw = UISwitch(appContext!!)
                sw.isOn = valx(pd.key) >= 0.5f
                sw.onValueChanged = { set(pd.key, if (sw.isOn) 1f else 0f); pv.requestDraw() }
                refreshers.add { sw.isOn = valx(pd.key) >= 0.5f }
                val r = UiView(appContext!!)
                r.addSubview(name); r.addSubview(sw)
                r.onLayout = { w -> name.frame = CGRect(0f, 6f, w - 60f, 20f); sw.frame = CGRect(w - 54f, 0f, 50f, 32f) }
                return r
            }
            val b = PillButton("", null, 0x00000000.toInt(), C.BLUE)
            b.textSize = 13f
            fun rebuild() {
                val cur = valx(pd.key).toInt()
                b.text = opts[min(max(cur, 0), opts.size - 1)] + " ▾"
                b.onClick = {
                    com.saiki.motion.app.Dlg(this).setTitle(pd.label).setItems(opts) { _, i ->
                        set(pd.key, i.toFloat()); pv.requestDraw(); rebuild()
                    }.show()
                }
            }
            rebuild()
            refreshers.add { rebuild() }
            val r = UiView(appContext!!)
            r.addSubview(name); r.addSubview(b)
            r.onLayout = { w -> name.frame = CGRect(0f, 8f, w - 150f, 20f); b.frame = CGRect(w - 150f, 2f, 150f, 30f) }
            return r
        }
        val num = UILabel(appContext!!)
        num.textColor = accent; num.font = UIFont.monospacedDigitSystemFont(13f); num.textAlignment = NSTextAlignment.right
        val s = UISlider(appContext!!)
        s.minValue = pd.min; s.maxValue = pd.max; s.value = valx(pd.key)
        fun fmt(v: Float): String = String.format(Locale.US, "%.${pd.dec}f", v)
        num.text = fmt(s.value)
        s.onValueChanged = { set(pd.key, s.value); num.text = fmt(s.value); pv.requestDraw() }
        refreshers.add { val v = valx(pd.key); s.value = v; num.text = fmt(v) }
        val col = UiView(appContext!!)
        col.addSubview(name); col.addSubview(num); col.addSubview(s)
        col.onLayout = { w ->
            name.frame = CGRect(0f, 0f, w * 0.6f, 20f)
            num.frame = CGRect(w - 64f, 0f, 64f, 20f)
            s.frame = CGRect(0f, 24f, w, 34f)
        }
        return col
    }

    private fun colorRow(cp: ColorParam): UiView {
        val name = UILabel(appContext!!)
        name.text = cp.label; name.textColor = UIColor.white; name.font = UIFont.systemFont(13f)
        val well = UIColorWell(appContext!!)
        well.supportsAlpha = false; well.selectedColor = colorVal(cp)
        well.onValueChanged = {
            val c = well.selectedColor.toInt()
            setColor(cp.key, (0xFFL shl 24) or (((c shr 16) and 0xFF).toLong() shl 16) or (((c shr 8) and 0xFF).toLong() shl 8) or ((c and 0xFF).toLong()))
            pv.requestDraw()
        }
        refreshers.add { well.selectedColor = colorVal(cp) }
        val r = UiView(appContext!!)
        r.addSubview(name); r.addSubview(well)
        r.onLayout = { w -> name.frame = CGRect(0f, 8f, w - 56f, 20f); well.frame = CGRect(w - 48f, 4f, 44f, 28f) }
        return r
    }

    // MARK: presets

    private fun applyPreset(p: UniversePreset) {
        for (pd in def?.props ?: emptyList()) set(pd.key, pd.def)
        for (cp in def?.colors ?: emptyList()) setColor(cp.key, cp.def.toLong() and 0xFFFFFFFFL)
        for ((k, v) in p.vals) set(k, v)
        for ((k, c) in p.cols) setColor(k, c)
        for (r in refreshers) r()
        pv.requestDraw()
    }

    private fun buildThumbs() {
        val id = def?.id ?: ""
        val word = UniversePresets.words[id]
        var photo: Bitmap? = null
        if (word == null) {
            val nm = UniversePresets.thumbRes[id] ?: "fx_neon_skyline"
            val rid = appContext!!.resources.getIdentifier(nm, "drawable", appContext!!.packageName)
            if (rid != 0) photo = BitmapFactory.decodeResource(appContext!!.resources, rid)
            if (photo == null) {
                val f = java.io.File(com.saiki.motion.core.Paths.root, "../img/$nm.jpg")
                if (f.exists()) photo = BitmapFactory.decodeFile(f.path)
            }
            if (photo != null) {
                val sz = 232 to 130
                photo = Bitmap.createScaledBitmap(photo, sz.first, sz.second, true)
            }
        }
        val list = presets
        Thread {
            for ((i, p) in list.withIndex()) {
                var base: Bitmap
                if (word != null) {
                    val c = p.tint ?: 0xFFFFFFFFL
                    val col = (c and 0xFFFFFFFFL).toInt()
                    // 30% white + 70% tint (blended), Georgia-Bold fallback: serif bold
                    val r = (0.3f * 255 + 0.7f * ((col shr 16) and 0xFF)).toInt()
                    val g = (0.3f * 255 + 0.7f * ((col shr 8) and 0xFF)).toInt()
                    val b = (0.3f * 255 + 0.7f * (col and 0xFF)).toInt()
                    val bm = Bitmap.createBitmap(232, 130, Bitmap.Config.ARGB_8888)
                    val cv = android.graphics.Canvas(bm)
                    cv.drawColor(0xFF000000.toInt())
                    val pt = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                    pt.color = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    pt.textSize = 44f
                    pt.typeface = android.graphics.Typeface.create(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
                    val tw = pt.measureText(word)
                    val fm = pt.fontMetrics
                    cv.drawText(word, (232 - tw) / 2, (130 - fm.top - fm.bottom) / 2, pt)
                    base = bm
                } else if (photo != null) {
                    base = photo!!
                } else continue
                // bloom approximation: stack scaled-down copies with additive blending
                var out = base
                if (p.bloom > 0f) {
                    val bm = Bitmap.createBitmap(232, 130, Bitmap.Config.ARGB_8888)
                    val cv = android.graphics.Canvas(bm)
                    val dark = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG)
                    cv.drawRect(0f, 0f, 232f, 130f, dark.apply { color = 0xFF000000.toInt() })
                    val add = android.graphics.Paint(android.graphics.Paint.FILTER_BITMAP_FLAG or android.graphics.Paint.ANTI_ALIAS_FLAG)
                    add.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.ADD)
                    val k = 1f + p.bloom * 8f / 100f
                    cv.drawBitmap(base, null, android.graphics.RectF(-232f * (k - 1f) / 2, -130f * (k - 1f) / 2, 232f * (1 + (k - 1f) / 2f), 130f * (1 + (k - 1f) / 2f)), add)
                    cv.drawBitmap(base, null, android.graphics.RectF(0f, 0f, 232f, 130f), add)
                    out = bm
                }
                if (word == null && p.tint != null) {
                    // screen blend with the tint colour
                    val t = (p.tint!! and 0xFFFFFFFFL).toInt()
                    val bm = Bitmap.createBitmap(232, 130, Bitmap.Config.ARGB_8888)
                    val cv = android.graphics.Canvas(bm)
                    cv.drawBitmap(out, 0f, 0f, null)
                    val sp = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                    sp.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN)
                    sp.color = (0xFF shl 24) or (t and 0xFFFFFF)
                    cv.drawRect(0f, 0f, 232f, 130f, sp)
                    out = bm
                }
                val res = out
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    thumbs[i] = res
                    grid.setNeedsDisplay()
                }
            }
        }.start()
    }

    private fun finish(apply: Boolean) {
        if (!apply) {
            for (k in lay.props.keys.toList()) {
                if (!k.startsWith(entry + "__")) continue
                val b = snap[k]
                if (b != null) lay.props[k]?.base = b else lay.props.remove(k)
            }
        }
        SceneRenderer.onVideoFrame = savedVideoCb
        val done = onDone
        dismiss(animated = true) { done() }
    }
}
