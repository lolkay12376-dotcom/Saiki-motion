@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName")

package com.saiki.motion.ui

import android.graphics.Paint
import android.graphics.RectF
import com.saiki.motion.core.EffectThumbs
import com.saiki.motion.core.Registry
import com.saiki.motion.uikit.CGRect
import com.saiki.motion.uikit.CGPoint
import com.saiki.motion.uikit.CGSize
import com.saiki.motion.uikit.CGContext
import com.saiki.motion.uikit.CGFloat
import com.saiki.motion.uikit.NSTextAlignment
import com.saiki.motion.uikit.UIControl
import com.saiki.motion.uikit.UIEvent
import com.saiki.motion.uikit.UIImage
import com.saiki.motion.uikit.UILongPressGestureRecognizer
import com.saiki.motion.uikit.UIScrollView
import com.saiki.motion.uikit.UITouch
import com.saiki.motion.uikit.UiView
import com.saiki.motion.uikit.UIGraphics
import com.saiki.motion.uikit.argbToUIColor
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// MARK: - ChipView

/// Small outlined text chip, e.g. the preview quality switch.
class ChipView(text: String) : TapView() {
    var text: String = text
        set(v) { field = v; setNeedsDisplay() }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width; val h = rect.height
        val r = CGRect(2f, 6f, w - 4, h - 12)
        strokeRoundRect(c, r, 8f, 1.5f, 0xFF4A4A52.toInt())
        drawText(text, w / 2, h / 2 + 4.5f, color = C.TEXT, size = 13f, bold = true, align = NSTextAlignment.center)
    }
}

// MARK: - PillButton

/// Rounded text button, optionally with a leading icon. Used for "Add Effect" etc.
class PillButton(text: String, icon: String?, var fillColor: Int, private val textColor: Int) : TapView() {
    var text: String = text
        set(v) { field = v; setNeedsDisplay() }
    var icon: String? = icon
        set(v) { field = v; setNeedsDisplay() }
    var textSize: CGFloat = 15f
        set(v) { field = v; setNeedsDisplay() }
    private var altTextColor: Int = textColor
    fun setColors(tc: Int) { altTextColor = tc; setNeedsDisplay() }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width; val h = rect.height
        var col = argbToUIColor(fillColor)
        if (isHighlighted) col = col.withAlphaComponent(170f / 255f)
        fillRoundRect(c, CGRect(0f, 0f, w, h), 12f, col.toInt())
        val tw = measureText(text, textSize, true)
        val iw: CGFloat = if (icon != null) 22f + 8f else 0f
        var x = (w - tw - iw) / 2
        if (icon != null) {
            Icons.draw(c, icon!!, x + 11, h / 2, 20f, altTextColor)
            x += iw
        }
        drawText(text, x, h / 2 + textSize / 3f, color = altTextColor, size = textSize, bold = true, align = NSTextAlignment.left)
    }
}

// MARK: - ToolButton

/// Icon above a label; used for the bottom tool bar.
class ToolButton(val icon: String, val label: String) : TapView() {
    var tint: Int = C.TEXT

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width; val h = rect.height
        val col = if (isHighlighted) (tint or 0x80000000.toInt()) else tint
        Icons.draw(c, icon, w / 2, h / 2 - 7f, 24f, col)
        drawText(label, w / 2, h - 10f, color = col, size = 11f, bold = false, align = NSTextAlignment.center)
    }
}

// MARK: - chipRow

/// Horizontal row of selectable pills. Buttons are 92x38 at 3pt side / 4pt vertical margins → the row is 46pt tall.
fun chipRow(labels: List<String>, sel: Int, onPick: (Int) -> Unit): UiView {
    val sv = UIScrollView()
    sv.showsHorizontalScrollIndicator = false
    sv.clipsToBounds = true
    val row = UiView()
    row.frame = CGRect(0f, 0f, labels.size * 98f + 3f, 46f)
    for ((i, nm) in labels.withIndex()) {
        val on = i == sel
        val b = PillButton(nm, null, if (on) C.GREEN else C.CARD2, if (on) C.ONDARK else C.TEXT)
        b.onClick = { onPick(i) }
        b.frame = CGRect(3f + i * 98f, 4f, 92f, 38f)
        row.addSubview(b)
    }
    sv.addSubview(row)
    sv.contentSize = row.frame.size
    return sv
}

// MARK: - SwitchRow

/// Card with a label and an on/off switch. Used for every two-state setting.
class SwitchRow : TapView() {
    var label = ""
    var captionOn = "On"
    var captionOff = "Off"
    var on = false
    var onToggle: ((Boolean) -> Unit)? = null

    init {
        onClick = {
            on = !on
            onToggle?.invoke(on)
            setNeedsDisplay()
        }
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width; val h = rect.height
        fillRoundRect(c, CGRect(0f, 0f, w, h), 10f, C.CARD)
        drawText(label, 14f, h / 2 + 5f, color = C.TEXT, size = 15f, bold = true, align = NSTextAlignment.left)
        val sw = 50f
        val sh = 28f
        val x1 = w - 14f
        val x0 = x1 - sw
        val y0 = (h - sh) / 2
        fillRoundRect(c, CGRect(x0, y0, sw, sh), sh / 2, if (on) C.GREEN else 0xFF3A3A44.toInt())
        fillCircle(c, if (on) x1 - sh / 2 else x0 + sh / 2, y0 + sh / 2, sh / 2 - 3f, 0xFFFFFFFF.toInt())
        drawText(if (on) captionOn else captionOff, x0 - 10f, h / 2 + 4f, color = C.DIM, size = 12f, bold = false, align = NSTextAlignment.right)
    }
}

// MARK: - TabBar

/// Two to four text tabs with an accent underline under the selected one.
class TabBar(private val labels: List<String>, var sel: Int, private val onPick: (Int) -> Unit) : TapView() {
    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width / labels.size
        // Own Paint per label (no shared helper state) + explicit, clearly visible inactive colour.
        for (i in labels.indices) {
            val on = i == sel
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.textSize = 15f * Dev.k; p.isFakeBoldText = true
            p.color = if (on) C.GREEN else 0xFFB4B4BE.toInt()
            val tw = p.measureText(labels[i])
            c.canvas.drawText(labels[i], w * (i + 0.5f) - tw / 2f, rect.height / 2 + 5f, p)
            if (on) {
                val lp = Paint(Paint.ANTI_ALIAS_FLAG); lp.color = C.GREEN; lp.strokeWidth = 3f; lp.style = Paint.Style.STROKE
                c.canvas.drawLine(w * i + 16f, rect.height - 3f, w * (i + 1) - 16f, rect.height - 3f, lp)
            }
        }
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        val i = (t.location(this).x / (boundsRect.width / labels.size)).toInt().coerceIn(0, labels.size - 1)
        if (i != sel) { sel = i; setNeedsDisplay(); onPick(i) }
    }
}

// MARK: - PillToggle

/// Small pill toggle used in the top bar for motion blur. Tap to switch, long-press for settings.
class PillToggle : TapView() {
    var on = false
        set(v) { field = v; setNeedsDisplay() }
    var onLong: (() -> Unit)? = null

    init {
        val lp = UILongPressGestureRecognizer { }
        lp.minimumPressDuration = 0.4
        lp.cancelsTouchesInView = false
        addGestureRecognizer(lp)
    }

    private var didLong = false

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        if (didLong) { didLong = false; isHighlighted = false; return }
        // TapView fires onClick on touch-up (toggle once); a long press opens settings and must NOT toggle.
        if (didLong) return
        on = !on
        onClick?.invoke()
        isHighlighted = false
    }
}

// MARK: - FillSlider

/// Rounded fill slider (drag across the bar). Used for playback speed.
class FillSlider : UIControl(com.saiki.motion.uikit.appContext!!) {
    var lo: Float = 0f
    var hi: Float = 1f
    var value: Float = 0f
    var suffix = "x"
    var onBeginDrag: (() -> Unit)? = null
    var onChange: ((Float) -> Unit)? = null
    private var dragging = false

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), rect.height / 2, C.CARD)
        val f = ((value - lo) / (hi - lo)).coerceIn(0f, 1f)
        val fill = if (isUserInteractionEnabled) C.GREEN else 0xFF55555E.toInt()
        c.saveGState()
        c.clip(CGRect(0f, 0f, rect.width * f, rect.height))
        fillRoundRect(c, CGRect(0f, 0f, rect.width, rect.height), rect.height / 2, fill)
        c.restoreGState()
        drawText(String.format(Locale.US, "%.2f", value) + suffix, rect.width / 2, rect.height / 2 + 5f,
                 color = if (isUserInteractionEnabled) C.ONDARK else C.DIM, size = 15f, bold = true, align = NSTextAlignment.center)
    }

    override fun touchesBegan(touches: Set<UITouch>, event: UIEvent?) {
        val t = touches.firstOrNull() ?: return
        dragging = true
        disallowParentScrollInterception(this, true)
        onBeginDrag?.invoke()
        setv(t.location(this).x)
    }

    override fun touchesMoved(touches: Set<UITouch>, event: UIEvent?) {
        if (!dragging) return
        val t = touches.firstOrNull() ?: return
        setv(t.location(this).x)
    }

    override fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) {
        dragging = false
        disallowParentScrollInterception(this, false)
    }

    override fun touchesCancelled(touches: Set<UITouch>, event: UIEvent?) {
        dragging = false
        disallowParentScrollInterception(this, false)
    }

    private fun setv(x: CGFloat) {
        val v = lo + (x / boundsRect.width).coerceIn(0f, 1f) * (hi - lo)
        value = (v * 20).toInt() / 20f
        value = value.coerceIn(lo, hi)
        setNeedsDisplay()
        onChange?.invoke(value)
    }
}

// MARK: - EffectCard

/// Effect tile whose icon automatically swipes between the processed and the original anime portrait.
class EffectCard(name: String, category: String) : TapView() {
    var name: String = name
        set(v) { field = v; setNeedsDisplay() }
    var category: String = category
        set(v) { field = v; setNeedsDisplay() }
    var before: UIImage? = null
    var after: UIImage? = null
    var badge = false
    var thumbHeight: Float = 0.8f
    var anim = "swipe"
    var thumbId: String? = null
    var origId: String? = null

    val isVisibleOnScreen: Boolean
        get() = isShown && !isHidden && alpha > 0.01f

    override fun didMoveToWindow() {
        super.didMoveToWindow()
        if (window != null) {
            EffectCardTicker.add(this)
            setNeedsDisplay()
        } else {
            EffectCardTicker.remove(this)
        }
    }

    public override fun draw(rect: CGRect) {
        val c = UIGraphics.getCurrentContext() ?: return
        val w = rect.width
        val th = min(w * thumbHeight, rect.height - 44f)
        fillRoundRect(c, CGRect(0f, 0f, w, rect.height), 12f, C.CARD)
        // thumbnail area, top corners rounded 12
        c.saveGState()
        val clipPath = com.saiki.motion.uikit.UIBezierPath(CGRect(0f, 0f, w, th), com.saiki.motion.uikit.UIRectCorner.TOP_LEFT, CGSize(12f, 12f))
        c.addPath(clipPath.cgPath)
        c.clipPath()
        val oid = origId
        if (oid != null) {
            val gl = EffectThumbs.cache[oid]
            if (gl != null) before = com.saiki.motion.uikit.UIImage(gl)
            else if (before == null) before = EffectThumbs.raw(oid.drop("__orig:".length))?.let { com.saiki.motion.uikit.UIImage(it) }
        }
        if (thumbId != null && after == null) after = EffectThumbs.cache[thumbId!!]?.let { com.saiki.motion.uikit.UIImage(it) }
        val a = after
        val b = before
        if (a != null && b != null) {
            val ph = (System.currentTimeMillis() % 3600) / 3600f
            val u = if (ph < 0.5f) ph * 2 else 2 - ph * 2
            if (anim.startsWith("ctl_")) { drawControl(c, b, anim, ph, u, w, th); c.restoreGState(); drawCardLabels(c, w, th); return }
            drawFit(c, b, 0f, w, th)
            when (anim) {
                "fade" -> {
                    c.saveGState(); c.setAlpha(u.coerceIn(0f, 1f)); drawFit(c, a, 0f, w, th); c.restoreGState()
                }
                "cut" -> if (ph >= 0.5f) drawFit(c, a, 0f, w, th)
                "oscillate" -> {
                    drawFit(c, a, 0f, w, th)
                    val oy = th * (0.5f + 0.28f * sin(ph * 2 * Math.PI.toFloat()))
                    fillCircle(c, w / 2, oy, 10f, 0xFF3D8BFF.toInt())
                    fillCircle(c, w / 2 - 3, oy - 3, 3f, 0x99FFFFFF.toInt())
                }
                "twitch" -> {
                    val step = (ph * 6).toInt()
                    val hx = ((step * 37 + 11) % 100) / 100f; val hy = ((step * 53 + 29) % 100) / 100f
                    val sz = min(w, th) * 0.42f
                    val box = CGRect((w - sz) * hx, (th - sz) * hy, sz, sz)
                    c.saveGState(); c.clip(box); drawFit(c, a, 0f, w, th); c.restoreGState()
                    c.setStrokeColor(0xFFFF4FA8.toInt()); c.setLineWidth(3f); c.stroke(box)
                }
                "wipe" -> {
                    val ey = th * (0.06f + 0.88f * u)
                    c.saveGState(); c.clip(CGRect(0f, 0f, w, ey)); drawFit(c, a, 0f, w, th); c.restoreGState()
                    strokeLine(c, 0f, ey, w, ey, 2f, 0xFFFFFFFF.toInt())
                }
                else -> {
                    val ex = w * (0.08f + 0.84f * u)
                    c.saveGState(); c.clip(CGRect(0f, 0f, ex, th)); drawFit(c, a, 0f, w, th); c.restoreGState()
                    strokeLine(c, ex, 0f, ex, th, 2f, 0xFFFFFFFF.toInt())
                    fillCircle(c, ex, th / 2, 9f, 0xFFFFFFFF.toInt())
                    fillCircle(c, ex, th / 2, 3.5f, 0xFF111114.toInt())
                }
            }
        } else if (b != null) {
            drawFit(c, b, 0f, w, th)
            val tid = thumbId
            if (tid != null && Registry.errors.containsKey(tid)) {
                drawText("Preview unavailable", w / 2, th - 8f, color = 0xFFFFFFFF.toInt(), size = 11f, bold = false, align = NSTextAlignment.center)
            }
        } else {
            fillRect(c, CGRect(0f, 0f, w, th), C.CARD2)
        }
        c.restoreGState()
        drawCardLabels(c, w, th)
    }

    private fun drawCardLabels(c: CGContext, w: CGFloat, th: CGFloat) {
        drawText(name, 10f, th + 22f, color = C.TEXT, size = 14f, bold = true, align = NSTextAlignment.left)
        drawText(category, 10f, th + 38f, color = C.DIM, size = 11f, bold = false, align = NSTextAlignment.left)
        if (badge) fillCircle(c, w - 14f, th + 20f, 5f, C.GREEN)
    }

    /** Animated icons for the Controls tab. */
    private fun drawControl(c: CGContext, img: UIImage, kind: String, ph: Float, u: Float, w: CGFloat, th: CGFloat) {
        fillRect(c, CGRect(0f, 0f, w, th), C.CARD2)
        val p = ph; val uu = u
        val s = min(w, th) * 0.56f
        val cx = w / 2; val cy = th * 0.42f
        val white = 0xFFFFFFFF.toInt()
        fun pic(x: CGFloat, y: CGFloat, sz: CGFloat, rot: CGFloat = 0f, alpha: CGFloat = 1f) {
            c.saveGState()
            c.translateBy(x, y); c.rotate(rot)
            val path = com.saiki.motion.uikit.CGPath.roundedRect(CGRect(-sz / 2, -sz / 2, sz, sz), sz * 0.1f, sz * 0.1f)
            c.addPath(path); c.clipPath()
            val k = max(sz / img.size.width, sz / img.size.height)
            val p2 = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            p2.alpha = (alpha * 255).toInt().coerceIn(0, 255)
            c.canvas.drawBitmap(img.bitmap, null, RectF(-img.size.width * k / 2, -img.size.height * k / 2, img.size.width * k / 2, img.size.height * k / 2), p2)
            c.restoreGState()
        }
        fun cross(x: CGFloat, y: CGFloat) {
            strokeLine(c, x - 12, y, x + 12, y, 2.5f, white); strokeLine(c, x, y - 12, x, y + 12, 2.5f, white)
            c.setStrokeColor(0xFFFFFFFF.toInt()); c.setLineWidth(2f)
            c.strokeEllipse(CGRect(x - 6, y - 6, 12f, 12f))
        }
        val by = th * 0.86f
        when (kind) {
            "ctl_slider" -> {
                pic(cx, cy, s, alpha = 0.3f + 0.7f * uu)
                strokeLine(c, w * 0.22f, by, w * 0.78f, by, 4f, 0xFF6B6B75.toInt())
                fillCircle(c, w * (0.22f + 0.56f * uu), by, 8f, white)
            }
            "ctl_angle" -> {
                val a = (uu - 0.5f) * 2.4f
                pic(cx, cy, s * 0.8f, rot = a)
                c.setStrokeColor(0xCCFFFFFF.toInt()); c.setLineWidth(2.5f)
                c.strokeEllipse(CGRect(cx - 13, by - 13, 26f, 26f))
                strokeLine(c, cx, by, cx + 10 * sin(a), by - 10 * cos(a), 3f, white)
                fillCircle(c, cx, by, 3f, white)
            }
            "ctl_check" -> {
                val on = ph >= 0.5f
                pic(cx, cy, s, alpha = if (on) 1f else 0.3f)
                val r = CGRect(cx - 13, by - 13, 26f, 26f)
                if (on) fillRoundRect(c, r, 6f, C.GREEN)
                strokeRoundRect(c, r, 6f, 2.5f, white)
                if (on) { strokeLine(c, cx - 7, by, cx - 2, by + 6, 3f, white); strokeLine(c, cx - 2, by + 6, cx + 8, by - 6, 3f, white) }
            }
            "ctl_color" -> {
                val col = android.graphics.Color.HSVToColor(floatArrayOf(p * 360f % 360f, 0.75f, 1f))
                pic(cx, cy, s)
                c.saveGState()
                val path = com.saiki.motion.uikit.CGPath.roundedRect(CGRect(cx - s / 2, cy - s / 2, s, s), s * 0.1f, s * 0.1f)
                c.addPath(path); c.clipPath()
                c.setFillColor(((0.5f * 255).toInt() shl 24) or (col and 0xFFFFFF))
                c.fill(CGRect(0f, 0f, w, th))
                c.restoreGState()
                val r = CGRect(cx - 13, by - 13, 26f, 26f)
                c.setFillColor((0xFF shl 24) or (col and 0xFFFFFF))
                c.addPath(com.saiki.motion.uikit.CGPath.roundedRect(r, 6f, 6f)); c.fillPath()
                strokeRoundRect(c, r, 6f, 2.5f, white)
            }
            "ctl_point", "ctl_point3d" -> {
                val three = kind == "ctl_point3d"
                val a = p * 2 * Math.PI.toFloat()
                pic(cx, cy, if (three) s * (0.8f + 0.2f * cos(a)) else s)
                cross(cx + sin(a) * s * 0.3f, cy + cos(a * (if (three) 2f else 1f)) * s * 0.3f)
            }
            else -> {   // ctl_layer
                val sel = if (ph >= 0.5f) 1 else 0
                val sz = s * 0.62f
                for (i in 0 until 2) {
                    val x = cx + (if (i == 0) -sz * 0.62f else sz * 0.62f)
                    pic(x, cy, sz, alpha = if (i == sel) 1f else 0.35f)
                    if (i == sel) strokeRoundRect(c, CGRect(x - sz / 2 - 4, cy - sz / 2 - 4, sz + 8, sz + 8), 8f, 3f, white)
                }
                strokeLine(c, w * 0.34f, by, w * 0.66f, by, 4f, 0xFF6B6B75.toInt())
                fillCircle(c, if (sel == 1) w * 0.66f else w * 0.34f, by, 8f, white)
            }
        }
    }

    /// Center-crop fit.
    private fun drawFit(c: CGContext, img: UIImage, x: CGFloat, w: CGFloat, h: CGFloat) {
        val bw = img.size.width; val bh = img.size.height
        if (bw <= 0 || bh <= 0) return
        val s = max(w / bw, h / bh)
        val dw = bw * s; val dh = bh * s
        val dx = x + (w - dw) / 2
        val dy = (h - dh) / 2
        c.saveGState()
        c.clip(CGRect(x, 0f, w, h))
        c.canvas.drawBitmap(img.bitmap, null, RectF(dx, dy, dx + dw, dy + dh), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        c.restoreGState()
    }
}

/// Shared redraw clock for EffectCard.
object EffectCardTicker {
    private val cards = ArrayList<EffectCard>()
    private var link: com.saiki.motion.uikit.CADisplayLink? = null
    private val tickObj = Any()

    fun add(c: EffectCard) {
        synchronized(cards) {
            cards.add(c)
            if (link == null) {
                val l = com.saiki.motion.uikit.CADisplayLink(tickObj, "tick")
                l.preferredFramesPerSecond = 20
                l.add(Any(), Any())
                link = l
            }
        }
    }

    fun remove(c: EffectCard) {
        synchronized(cards) {
            cards.remove(c)
            if (cards.isEmpty()) { link?.invalidate(); link = null }
        }
    }

    fun tick() {
        for (c in cards.toList()) if (c.isVisibleOnScreen) c.setNeedsDisplay()
    }
}
