@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName", "PropertyName", "ClassName", "ConflictingOverloads")

package com.saiki.motion.uikit

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import java.lang.ref.WeakReference

// UIKit.kt — core geometry / colour / graphics types of the UIKit compatibility layer.
// (UIKit2.kt carries the widget half: UIControl, UILabel, UIButton, UITextField, UIScrollView,
//  UIStackView, UIAlertController, tables, feedback. This file carries everything those need.)

// MARK: - Core Geometry

typealias CGFloat = Float

class CGPoint(@JvmField var x: CGFloat, @JvmField var y: CGFloat) {
    override fun equals(other: Any?): Boolean = other is CGPoint && other.x == x && other.y == y
    override fun hashCode(): Int = x.hashCode() * 31 + y.hashCode()
    override fun toString(): String = "($x, $y)"
    operator fun plus(o: CGPoint) = CGPoint(x + o.x, y + o.y)
    operator fun minus(o: CGPoint) = CGPoint(x - o.x, y - o.y)
    operator fun times(s: CGFloat) = CGPoint(x * s, y * s)
    companion object { @JvmField val zero = CGPoint(0f, 0f) }
}

class CGSize(@JvmField var width: CGFloat, @JvmField var height: CGFloat) {
    override fun equals(other: Any?): Boolean = other is CGSize && other.width == width && other.height == height
    override fun hashCode(): Int = width.hashCode() * 31 + height.hashCode()
    companion object { @JvmField val zero = CGSize(0f, 0f) }
}

class CGRect(@JvmField var x: CGFloat, @JvmField var y: CGFloat, @JvmField var width: CGFloat, @JvmField var height: CGFloat) {
    constructor() : this(0f, 0f, 0f, 0f)
    val minX: CGFloat get() = x
    val midX: CGFloat get() = x + width / 2
    val maxX: CGFloat get() = x + width
    val minY: CGFloat get() = y
    val midY: CGFloat get() = y + height / 2
    val maxY: CGFloat get() = y + height
    val left: CGFloat get() = x
    val top: CGFloat get() = y
    val right: CGFloat get() = x + width
    val bottom: CGFloat get() = y + height
    val size: CGSize get() = CGSize(width, height)
    fun contains(p: CGPoint): Boolean = p.x >= x && p.x < maxX && p.y >= y && p.y < maxY
    fun contains(r: CGRect): Boolean = r.x >= x && r.maxX <= maxX && r.y >= y && r.maxY <= maxY
    fun intersects(r: CGRect): Boolean = !(r.maxX < x || r.x > maxX || r.maxY < y || r.y > maxY)
    fun insetBy(dx: CGFloat, dy: CGFloat): CGRect = CGRect(x + dx, y + dy, kotlin.math.max(0f, width - 2 * dx), kotlin.math.max(0f, height - 2 * dy))
    fun offsetBy(dx: CGFloat, dy: CGFloat): CGRect = CGRect(x + dx, y + dy, width, height)
    override fun equals(other: Any?): Boolean = other is CGRect && other.x == x && other.y == y && other.width == width && other.height == height
    override fun hashCode(): Int = x.hashCode() * 31 + y.hashCode() * 13 + width.hashCode() * 7 + height.hashCode()
    override fun toString(): String = "($x, $y, $width, $height)"
    fun toRectF(): RectF = RectF(x, y, x + width, y + height)
    companion object { @JvmField val zero = CGRect(0f, 0f, 0f, 0f) }
}

fun CGRectMake(x: CGFloat, y: CGFloat, w: CGFloat, h: CGFloat) = CGRect(x, y, w, h)

class UIEdgeInsets(val top: CGFloat, val left: CGFloat, val bottom: CGFloat, val right: CGFloat) {
    companion object { @JvmField val zero = UIEdgeInsets(0f, 0f, 0f, 0f) }
}

/** Auto-layout guide stub (the ports lay out by frame; guides only silence references). */
class UILayoutGuide

// MARK: - Colors

/** ARGB Int (Android bit layout) holder. iOS colors pass as `C.*` Ints everywhere. */
class UIColor(private val argb: Int) {
    fun withAlphaComponent(a: CGFloat): UIColor = ((a * 255).toInt().coerceIn(0, 255) shl 24).let { UIColor(it or (argb and 0x00FFFFFF)) }
    fun toInt(): Int = argb
    val cgColor: Int get() = argb
    companion object {
        val white = UIColor(0xFFFFFFFF.toInt())
        val black = UIColor(0xFF000000.toInt())
        val clear = UIColor(0x00000000)
        val red = UIColor(0xFFFF0000.toInt())
        val green = UIColor(0xFF00FF00.toInt())
        val blue = UIColor(0xFF0000FF.toInt())
        val lightGray = UIColor(0xFFAAAAAA.toInt())
        val darkGray = UIColor(0xFF555555.toInt())
        val systemBlue = UIColor(0xFF007AFF.toInt())
        fun hsv(h: CGFloat, s: CGFloat, b: CGFloat, a: CGFloat): UIColor {
            val c = android.graphics.Color.HSVToColor(floatArrayOf((h * 360f) % 360f, s, b))
            return UIColor(((a * 255).toInt() shl 24) or (c and 0xFFFFFF))
        }
        fun rgb(r: CGFloat, g: CGFloat, b: CGFloat, a: CGFloat): UIColor =
            UIColor((((a * 255).toInt() shl 24) or ((r * 255).toInt() shl 16) or ((g * 255).toInt() shl 8) or (b * 255).toInt()))
        /** UIColor(rgb: 0xRRGGBB) convenience (SdkIde.swift's highlight colors). */
        fun rgb(rgb: Int): UIColor = UIColor(0xFF000000.toInt() or (rgb and 0xFFFFFF))
    }
}

fun argbToUIColor(c: Int): UIColor = UIColor(c)
fun argbColor(a: Int, r: Int, g: Int, b: Int): Int = (a shl 24) or (r shl 16) or (g shl 8) or b

// MARK: - Fonts

class UIFont private constructor(val size: CGFloat, val bold: Boolean, val mono: Boolean = false) {
    fun toPaint(): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size
        isFakeBoldText = bold
        typeface = when {
            mono && bold -> android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
            mono -> android.graphics.Typeface.MONOSPACE
            bold -> android.graphics.Typeface.DEFAULT_BOLD
            else -> android.graphics.Typeface.DEFAULT
        }
    }
    fun withSize(newSize: CGFloat): UIFont = if (mono) monospacedFont(newSize) else UIFont(newSize, bold, false)
    companion object {
        fun systemFont(size: CGFloat, weight: Int = 0): UIFont = UIFont(size, weight >= 600, false)
        fun boldSystemFont(size: CGFloat): UIFont = UIFont(size, true, false)
        fun semiboldSystemFont(size: CGFloat): UIFont = UIFont(size, true, false)
        fun monospacedDigitSystemFont(size: CGFloat, weight: Int = 0): UIFont = UIFont(size, weight >= 600, false)
        /** UIFont(name: "Menlo", size:) / monospacedSystemFont twin (the code editor's font). */
        fun monospacedFont(size: CGFloat): UIFont = UIFont(size, false, true)
        fun monospacedSystemFont(size: CGFloat, weight: Int = 0): UIFont = UIFont(size, weight >= 600, true)
    }
}

// MARK: - Images

class UIImage(val bitmap: android.graphics.Bitmap) {
    val size: CGSize get() = CGSize(bitmap.width.toFloat(), bitmap.height.toFloat())
    fun withAlphaComponent(a: CGFloat): UIImage {
        val out = android.graphics.Bitmap.createBitmap(bitmap.width, bitmap.height, android.graphics.Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        p.alpha = (a * 255).toInt().coerceIn(0, 255)
        android.graphics.Canvas(out).drawBitmap(bitmap, 0f, 0f, p)
        return UIImage(out)
    }
    val cgImage: android.graphics.Bitmap get() = bitmap
    companion object {
        fun named(name: String): UIImage? = try {
            appContext!!.assets.open("img/$name.png").use { UIImage(android.graphics.BitmapFactory.decodeStream(it)) }
        } catch (_: Exception) { null }
    }
}

/** UIGraphicsImageRenderer twin: draws into a Bitmap and hands back a UIImage. */
class UIGraphicsImageRenderer(val w: Int, val h: Int) {
    fun image(draw: (CGContext) -> Unit): UIImage {
        val b = android.graphics.Bitmap.createBitmap(kotlin.math.max(1, w), kotlin.math.max(1, h), android.graphics.Bitmap.Config.ARGB_8888)
        val c = UIGraphics.pushNew(android.graphics.Canvas(b))   // one-shot canvas: never pooled (map would grow per thumbnail)
        try { draw(c) } finally { UIGraphics.pop() }
        return UIImage(b)
    }
}

// MARK: - Graphics context

class CGContext(val canvas: Canvas) {
    val paint: Paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val savedPaints = ArrayList<Paint>()
    private var paintPath: Path = Path()

    fun saveGState() { savedPaints.add(Paint(paint)); canvas.save() }
    fun restoreGState() {
        if (savedPaints.isNotEmpty()) paint.set(savedPaints.removeAt(savedPaints.size - 1))
        canvas.restore()
    }
    fun translateBy(x: CGFloat, y: CGFloat) = canvas.translate(x, y)
    fun scaleBy(x: CGFloat, y: CGFloat) = canvas.scale(x, y)
    fun rotate(by: Float) = canvas.rotate(by * 180f / Math.PI.toFloat())
    fun setStrokeColor(c: Int) { paint.color = c; paint.style = Paint.Style.STROKE }
    fun setFillColor(c: Int) { paint.color = c; paint.style = Paint.Style.FILL }
    fun setLineWidth(w: CGFloat) { paint.strokeWidth = w }
    fun setLineCap(cap: CGLineCap) { paint.strokeCap = when (cap) { CGLineCap.butt -> Paint.Cap.BUTT; CGLineCap.round -> Paint.Cap.ROUND; CGLineCap.square -> Paint.Cap.SQUARE } }
    fun setLineJoin(join: CGLineJoin) { paint.strokeJoin = when (join) { CGLineJoin.miter -> Paint.Join.MITER; CGLineJoin.round -> Paint.Join.ROUND; CGLineJoin.bevel -> Paint.Join.BEVEL } }
    fun setAlpha(a: CGFloat) { paint.alpha = (a * 255).toInt().coerceIn(0, 255) }
    fun setLineDash(phase: CGFloat, lengths: FloatArray) { paint.pathEffect = if (lengths.isEmpty()) null else DashPathEffect(lengths, phase) }
    fun setBlendMode(m: CGBlendMode) { paint.xfermode = when (m) { CGBlendMode.normal -> null; CGBlendMode.plusLighter -> android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.ADD); CGBlendMode.multiply -> android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.MULTIPLY); CGBlendMode.screen -> android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN); CGBlendMode.clear -> android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR); CGBlendMode.sourceOver -> null } }
    fun beginPath() { paintPath = Path() }
    fun addPath(p: Path) { paintPath = p }
    fun move(p: CGPoint) { paintPath.moveTo(p.x, p.y) }
    fun addLine(p: CGPoint) { paintPath.lineTo(p.x, p.y) }
    fun addQuadCurve(to: CGPoint, control: CGPoint) { paintPath.quadTo(control.x, control.y, to.x, to.y) }
    fun addCurve(to: CGPoint, control1: CGPoint, control2: CGPoint) { paintPath.cubicTo(control1.x, control1.y, control2.x, control2.y, to.x, to.y) }
    fun closeSubpath() { paintPath.close() }
    fun strokePath() { paint.style = Paint.Style.STROKE; canvas.drawPath(paintPath, paint); paintPath = Path() }
    fun fillPath() { paint.style = Paint.Style.FILL; canvas.drawPath(paintPath, paint); paintPath = Path() }
    fun clipPath() { canvas.clipPath(paintPath); paintPath = Path() }
    fun clip(to: CGRect) { canvas.clipRect(to.x, to.y, to.maxX, to.maxY) }
    fun strokeEllipse(r: CGRect) { paint.style = Paint.Style.STROKE; canvas.drawOval(r.toRectF(), paint) }
    fun fillEllipse(r: CGRect) { paint.style = Paint.Style.FILL; canvas.drawOval(r.toRectF(), paint) }
    fun fill(r: CGRect) { paint.style = Paint.Style.FILL; canvas.drawRect(r.x, r.y, r.maxX, r.maxY, paint) }
    fun stroke(r: CGRect) { paint.style = Paint.Style.STROKE; canvas.drawRect(r.x, r.y, r.maxX, r.maxY, paint) }
    fun drawLinearGradient(colors: IntArray, start: CGPoint, end: CGPoint) {
        val shader = if (colors.size == 2) LinearGradient(start.x, start.y, end.x, end.y, colors[0], colors[1], Shader.TileMode.CLAMP)
                     else LinearGradient(start.x, start.y, end.x, end.y, colors, null, Shader.TileMode.CLAMP)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.shader = shader; style = Paint.Style.FILL }
        canvas.drawPaint(p)
    }
    /** UIGraphics pool reuse: back to constructor state (draw code always sets color/style before drawing). */
    fun resetForReuse() {
        savedPaints.clear()
        paint.reset()
        paint.isAntiAlias = true
        paintPath = Path()
    }
}

enum class CGLineCap { butt, round, square }
enum class CGLineJoin { miter, round, bevel }
enum class CGBlendMode { normal, plusLighter, multiply, screen, clear, sourceOver }

class CGPath {
    val path = Path()
    fun move(p: CGPoint) { path.moveTo(p.x, p.y) }
    fun addLine(p: CGPoint) { path.lineTo(p.x, p.y) }
    fun addQuadCurve(to: CGPoint, control: CGPoint) { path.quadTo(control.x, control.y, to.x, to.y) }
    fun addCurve(to: CGPoint, control1: CGPoint, control2: CGPoint) { path.cubicTo(control1.x, control1.y, control2.x, control2.y, to.x, to.y) }
    fun closeSubpath() { path.close() }
    /** UIBezierPath.addArc twin (angles in radians, screen coords: positive sweep = clockwise). */
    fun addArc(center: CGPoint, radius: CGFloat, startAngle: CGFloat, endAngle: CGFloat, clockwise: Boolean) {
        val oval = android.graphics.RectF(center.x - radius, center.y - radius, center.x + radius, center.y + radius)
        val start = startAngle * 180f / Math.PI.toFloat()
        var sweep = (endAngle - startAngle) * 180f / Math.PI.toFloat()
        if (!clockwise && sweep > 0f) sweep -= 360f
        if (clockwise && sweep < 0f) sweep += 360f
        path.arcTo(oval, start, sweep, false)
    }
    val cgPath: Path get() = path
    companion object {
        fun roundedRect(r: CGRect, cornerWidth: CGFloat, cornerHeight: CGFloat): Path =
            Path().apply { addRoundRect(r.toRectF(), cornerWidth, cornerHeight, Path.Direction.CW) }
    }
}

class UIBezierPath(val rect: CGRect, val corners: UIRectCorner = UIRectCorner.ALL, val radii: CGSize = CGSize(0f, 0f)) {
    val cgPath: Path get() = Path().apply { addRoundRect(rect.toRectF(), radii.width, radii.height, Path.Direction.CW) }
    constructor(rect: CGRect, cornerRadius: CGFloat) : this(rect, UIRectCorner.ALL, CGSize(cornerRadius, cornerRadius))
}

@Suppress("unused")
enum class UIRectCorner(val mask: Int) { NONE(0), TOP_LEFT(1), TOP_RIGHT(2), BOTTOM_LEFT(4), BOTTOM_RIGHT(8), ALL(15) }
fun UIRectCorner.plus(o: UIRectCorner): UIRectCorner = UIRectCorner.entries.first { it.mask == this.mask or o.mask }!!

// MARK: - UIGraphics (current context handed to draw(rect:))

object UIGraphics {
    private var current: CGContext? = null
    // One cached context per canvas for the per-frame onDraw path (the old new-CGContext-per-push
    // churned a Paint+Path+ArrayList bundle per view per frame). Contexts are consumed synchronously
    // inside draw(rect:) and never retained past pop(), so reuse is safe. One-shot canvases
    // (UIGraphicsImageRenderer thumbnails) use pushNew() — pooling those would grow the map unboundedly.
    private val pool = HashMap<Canvas, CGContext>()
    fun getCurrentContext(): CGContext? = current
    fun push(canvas: Canvas): CGContext {
        var c = pool[canvas]
        if (c == null) { c = CGContext(canvas); pool[canvas] = c }
        c.resetForReuse()
        current = c
        return c
    }
    fun pushNew(canvas: Canvas): CGContext { val c = CGContext(canvas); current = c; return c }
    fun pop() { current = null }
}

object UIViewAnimator {
    /** Simple property animator: applies the change immediately (alpha uses View.animate where needed). */
    fun animate(duration: Double, body: () -> Unit) { body() }
    fun animate(duration: Float, body: () -> Unit) { body() }
    fun animate(duration: Double, delay: Double, options: Int, body: () -> Unit) { body() }
    fun animate(duration: Float, delay: Float, options: Int, body: () -> Unit) { body() }
}

// MARK: - App host

@Volatile var appContext: Context? = null
private var currentAct: WeakReference<Activity>? = null
val currentActivity: WeakReference<Activity>? get() = currentAct
fun setCurrentActivity(a: Activity?) { currentAct = if (a != null) WeakReference(a) else null }

// MARK: - CADisplayLink twin

class CADisplayLink(private val target: Any, private val sel: String) {
    var preferredFramesPerSecond = 60
    private var handler: android.os.Handler? = null
    private var running = false
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                val m = target.javaClass.getMethod(sel)
                m.invoke(target)
            } catch (_: Exception) {
                try { (target as? () -> Unit)?.invoke() } catch (_: Exception) {}
            }
            handler?.postDelayed(this, 1000L / kotlin.math.max(1, preferredFramesPerSecond))
        }
    }

    fun add(to: Any, mode: Any) { start() }
    fun start() {
        if (running) return
        running = true
        handler = android.os.Handler(android.os.Looper.getMainLooper())
        handler?.post(tick)
    }
    fun invalidate() { running = false; handler?.removeCallbacks(tick); handler = null }
}

// MARK: - Gestures

enum class UIGestureRecognizerState { possible, began, changed, ended, cancelled, failed }
enum class UITouchPhase { began, moved, stationary, ended, cancelled }

open class UIGestureRecognizer(val callback: ((UIGestureRecognizer) -> Unit)?) {
    var state: UIGestureRecognizerState = UIGestureRecognizerState.possible
    var minimumPressDuration: Double = 0.5
    var cancelsTouchesInView = true
    var numberOfTouchesRequired = 1
    var numberOfTapsRequired = 1
    var scale: CGFloat = 1f
    var enabled = true
    var delegate: Any? = null
    open fun location(inView: UiView?): CGPoint = CGPoint(0f, 0f)
    open fun onTouchEvent(e: MotionEvent, v: UiView): Boolean = false
    open fun handleEnd() { }
}

class UIPinchGestureRecognizer(cb: ((UIPinchGestureRecognizer) -> Unit)?) : UIGestureRecognizer(cb as ((UIGestureRecognizer) -> Unit)?) {
    var startSpan = 0f
}

/** UIRotationGestureRecognizer twin: reports the twist angle (radians) and the fingers' midpoint. */
class UIRotateGestureRecognizer(private val cb: (Float, CGPoint) -> Unit) : UIGestureRecognizer(null) {
    var rotation = 0f
    private var lastAngle = 0f
    private var lastX = 0f
    private var lastY = 0f
    val location: CGPoint get() = CGPoint(lastX, lastY)

    override fun onTouchEvent(e: MotionEvent, v: UiView): Boolean {
        if (e.pointerCount >= 2) {
            val ax = e.getX(0); val ay = e.getY(0)
            val bx = e.getX(1); val by = e.getY(1)
            val ang = kotlin.math.atan2(by - ay, bx - ax)
            lastX = (ax + bx) / 2f; lastY = (ay + by) / 2f
            when (e.actionMasked) {
                MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_DOWN -> lastAngle = ang
                else -> {
                    var d = ang - lastAngle
                    while (d > Math.PI.toFloat()) d -= 2f * Math.PI.toFloat()
                    while (d < -Math.PI.toFloat()) d += 2f * Math.PI.toFloat()
                    rotation += d
                    lastAngle = ang
                    state = UIGestureRecognizerState.changed
                    cb(rotation, location)
                }
            }
            return true
        }
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_POINTER_UP) {
            if (e.pointerCount <= 1) { state = UIGestureRecognizerState.ended; handleEnd() }
        }
        return false
    }
}

open class UIPanGestureRecognizer(cb: ((UIPanGestureRecognizer) -> Unit)?) : UIGestureRecognizer(cb as ((UIGestureRecognizer) -> Unit)?) {
    var minimumNumberOfTouches = 1
    var maximumNumberOfTouches = 10
    private var totalX = 0f; private var totalY = 0f
    fun translation(inView: UiView?): CGPoint = CGPoint(totalX, totalY)
    fun setTranslationZero() { totalX = 0f; totalY = 0f }
    fun velocity(inView: UiView?): CGPoint = CGPoint(0f, 0f)
    fun translation(p: CGPoint) { totalX = p.x; totalY = p.y }
}

class UITapGestureRecognizer(private val cb: (() -> Unit)?) : UIGestureRecognizer(null) {
    private var downX = 0f; private var downY = 0f; private var downT = 0L
    fun fireOnce() { cb?.invoke() }
    override fun handleEnd() { cb?.invoke() }
    override fun onTouchEvent(e: MotionEvent, v: UiView): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; downT = android.os.SystemClock.uptimeMillis(); state = UIGestureRecognizerState.possible }
            MotionEvent.ACTION_UP -> {
                val inside = e.x >= 0 && e.x <= v.width && e.y >= 0 && e.y <= v.height
                val moved = Math.abs(e.x - downX) > 12 || Math.abs(e.y - downY) > 12
                if (inside && !moved && android.os.SystemClock.uptimeMillis() - downT < 350) {
                    state = UIGestureRecognizerState.ended; handleEnd(); return true
                }
                state = UIGestureRecognizerState.failed
            }
            MotionEvent.ACTION_CANCEL -> state = UIGestureRecognizerState.failed
        }
        return false
    }
}

class UILongPressGestureRecognizer(cb: ((UIGestureRecognizer) -> Unit)?) : UIGestureRecognizer(cb) {
    var fired = false
    private var downX = 0f; private var downY = 0f
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var fire: Runnable? = null
    private var lastX = 0f; private var lastY = 0f
    /** iOS location(in:) twin: the point where the press began, in the view's coordinates. */
    override fun location(inView: UiView?): CGPoint = CGPoint(lastX, lastY)
    override fun onTouchEvent(e: MotionEvent, v: UiView): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y; fired = false
                val r = Runnable {
                    if (!fired) { fired = true; state = UIGestureRecognizerState.began; callback?.invoke(this@UILongPressGestureRecognizer) }
                }
                fire = r
                handler.postDelayed(r, (minimumPressDuration * 1000).toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                lastX = e.x; lastY = e.y
                if (!fired && (Math.abs(e.x - downX) > 12 || Math.abs(e.y - downY) > 12)) {
                    fire?.let { handler.removeCallbacks(it) }
                    if (state == UIGestureRecognizerState.possible) state = UIGestureRecognizerState.failed
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                fire?.let { handler.removeCallbacks(it) }
                if (state == UIGestureRecognizerState.began) state = UIGestureRecognizerState.ended
            }
        }
        return false
    }
}

// MARK: - Touch plumbing

class UITouch(val x: CGFloat, val y: CGFloat, val phase: UITouchPhase) {
    fun location(inView: UiView?): CGPoint = CGPoint(x, y)
}

class UIEvent(val touches: Set<UITouch>) {
    val allTouches: Set<UITouch> get() = touches
}

// MARK: - CapScroll (clipped, no-bounce scroll container)

class CapScroll(context: Context) : UIScrollView(context) {
    init { clipsToBounds = true }
}

fun capScrollOf(context: Context): CapScroll = CapScroll(context)
