pluginManagement { repositories { maven("https://maven.aliyun.com/repository/gradle-plugin"); maven("https://maven.aliyun.com/repository/public"); google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositories { maven("https://maven.aliyun.com/repository/public"); google(); mavenCentral() } }
rootProject.name = "SaikiMotion"
include(":app")
