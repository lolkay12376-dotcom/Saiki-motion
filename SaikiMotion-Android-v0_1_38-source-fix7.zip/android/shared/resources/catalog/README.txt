builtins.json is GENERATED: run tools/dump_catalog.sh <iOS Sources> on a Mac and commit the result. Not present yet (no Swift toolchain in the AI sessions).
