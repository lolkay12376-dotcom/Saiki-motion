// Pass 1: horizontal blur of the layer alpha (half resolution).
vec4 aurea_main(vec2 uv) {
    float acc = 0.0;
    for (int i = 0; i < 32; ++i) {
        float x = (float(i) + 0.5) / 32.0 * 2.0 - 1.0;
        acc += texture(aurea_source, uv + aurea_px_to_uv(vec2(x * bevelSize, 0.0))).a;
    }
    acc /= 32.0;
    return vec4(acc, acc, acc, 1.0);
}
