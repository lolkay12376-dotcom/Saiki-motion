// Deep Glow (AE) - generated from deep-glow-ae.xml. One shader shared by all 29 passes (acPass = AUREA_PASS_INDEX).
#define inputImg aurea_source
#define acScreenNorm vUv
#define acPass AUREA_PASS_INDEX
#define acEscalaDePixel acPixelScale
#define acResolution floor(aurea.layer.xy * exp2(-float(d)))
uniform float acPixelScale;
vec4 fragColor;
#define unmult (unmult_s > 0.5)
#define glowBlendMode int(glowBlendMode_s + 0.5)
#define dither (dither_s > 0.5)
#define chromaticAberration (chromaticAberration_s > 0.5)
#define tint (tint_s > 0.5)
#define autoGamma (autoGamma_s > 0.5)

const int NIVEIS = 6;                 // medido: seis n?veis, cada um com metade do alcance do anterior
const int DEGRAUS = 5;                // a pir?mide vai at? 1/32
const float SIGMA = 0.24494897;       // do shader do plugin: sqrt(0,06) da meia largura do n?vel
const int MEIA_MAX = 24;              // o desfoque soma at? 49 pontos por passe

const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);

/** O gama da conta linear: o medido (2,22) ou, com Auto Gamma desligado, o escolhido. */
float gama() { return autoGamma ? 2.2222222 : max(gammaValue, 0.1); }
vec3 paraLuz(vec3 g) { return pow(max(g, vec3(0.0)), vec3(gama())); }
vec3 paraGama(vec3 l) { return pow(max(l, vec3(0.0)), vec3(1.0 / gama())); }

/** Quanto o desfoque estica em cada eixo (Aspect Ratio): (1, 1) no padr?o. */
vec2 eixos() {
    float r = clamp(aspectRatio, 0.25, 4.0);
    return r >= 1.0 ? vec2(r, 1.0) : vec2(1.0, 1.0 / r);
}

/**
 * A luz num buffer de 8 bits: o halo de um ponto pequeno vale 0,0001 ou menos, e 8 bits (mesmo com gama) n?o
 * guardam isso. Vai ent?o como mantissa e expoente: o maior canal fica entre 0,5 e 1 (guardado com raiz, para
 * render mais) e o alfa leva a pot?ncia de dois ? o erro ? sempre uma fra??o do valor, claro ou escuro.
 */
vec4 codificar(vec3 l) {
    l = max(l, vec3(0.0));
    float m = max(l.r, max(l.g, l.b));
    if (m < 1e-9) return vec4(0.0);
    float e = clamp(ceil(log2(m)), -30.0, 2.0);
    return vec4(sqrt(min(l / exp2(e), vec3(1.0))), (e + 32.0) / 255.0);
}

vec3 decodificar(vec4 t) {
    if (t.a <= 0.0) return vec3(0.0);
    return t.rgb * t.rgb * exp2(floor(t.a * 255.0 + 0.5) - 32.0);
}

/** A luz da fonte num pixel: pr?-multiplicada, com o limiar do plugin (canal a canal), em linear, presa em 1. */
vec3 entrada(ivec2 p) {
    vec4 t = texelFetch(inputImg, p, 0);
    vec3 c = max(t.rgb * t.a, vec3(0.0));
    float lim = threshold / 100.0;
    if (lim > 0.0) {
        vec3 abaixo = (c / lim) * c * (thresholdSmooth / 100.0);
        c = mix(c, abaixo, vec3(lessThan(c, vec3(lim))));
    }
    return min(paraLuz(c), vec3(1.0));
}

/** A luz da fonte guardada pelo passe `lz`. */
vec3 luzDaFonte(ivec2 p) { return decodificar(texelFetch(lz, p, 0)); }

/** Espelha o ?ndice na borda (medido: a borda do plugin ? espelhada). */
int espelhar(int i, int n) {
    // Dentro do quadro o espelho ? o pr?prio ?ndice: sem a divis?o inteira, que em todo tap custava caro (0.569.0)
    if (i >= 0 && i < n) return i;
    int p = 2 * n;
    i = i - (i / p) * p; if (i < 0) i += p;
    return i < n ? i : p - 1 - i;
}

ivec2 tamanhoDe(int d) {
    if (d == 0) return textureSize(inputImg, 0);
    if (d == 1) return textureSize(p1, 0);
    if (d == 2) return textureSize(p2, 0);
    if (d == 3) return textureSize(p3, 0);
    if (d == 4) return textureSize(p4, 0);
    return textureSize(p5, 0);
}

/** Um ponto do degrau `d` da pir?mide (0 = a pr?pria entrada), em luz. */
vec3 degrau(int d, ivec2 p) {
    ivec2 T = tamanhoDe(d);
    p = ivec2(espelhar(p.x, T.x), espelhar(p.y, T.y));
    if (d == 0) return luzDaFonte(p);
    if (d == 1) return decodificar(texelFetch(p1, p, 0));
    if (d == 2) return decodificar(texelFetch(p2, p, 0));
    if (d == 3) return decodificar(texelFetch(p3, p, 0));
    if (d == 4) return decodificar(texelFetch(p4, p, 0));
    return decodificar(texelFetch(p5, p, 0));
}

/** O tamanho do buffer do desfoque horizontal do degrau `d` (o mesmo do degrau). */
ivec2 tamanhoDoH(int d) {
    if (d == 0) return textureSize(tf, 0);
    if (d == 1) return textureSize(h1, 0);
    if (d == 2) return textureSize(h2, 0);
    if (d == 3) return textureSize(h3, 0);
    if (d == 4) return textureSize(h4, 0);
    return textureSize(h5, 0);
}

vec3 horizontal(int d, ivec2 p) {
    // No passe vertical o alvo ? o pr?prio degrau (o motor n?o o entrega como textura): o tamanho vem do buffer do horizontal.
    ivec2 T = tamanhoDoH(d);
    p = ivec2(espelhar(p.x, T.x), espelhar(p.y, T.y));
    if (d == 0) return decodificar(texelFetch(tf, p, 0));
    if (d == 1) return decodificar(texelFetch(h1, p, 0));
    if (d == 2) return decodificar(texelFetch(h2, p, 0));
    if (d == 3) return decodificar(texelFetch(h3, p, 0));
    if (d == 4) return decodificar(texelFetch(h4, p, 0));
    return decodificar(texelFetch(h5, p, 0));
}

/** O degrau `d` lido num ponto qualquer da tela (uv), com interpola??o bilinear feita em luz. */
vec3 degrauEm(int d, vec2 uv) {
    vec2 c = uv * vec2(tamanhoDe(d)) - 0.5;
    ivec2 b = ivec2(floor(c));
    vec2 f = c - vec2(b);
    return mix(mix(degrau(d, b), degrau(d, b + ivec2(1, 0)), f.x), mix(degrau(d, b + ivec2(0, 1)), degrau(d, b + ivec2(1, 1)), f.x), f.y);
}

/** O sigma (em pixels do buffer cheio) do n?vel `k`: 0 ? o mais largo. */
float sigmaDoNivel(int k) {
    return SIGMA * radius * acEscalaDePixel * 0.5 / exp2(float(k));
}

/** O sigma do n?vel `k` no eixo que mais estica: ? ele que decide degrau e corte. */
float sigmaMaior(int k) {
    vec2 e = eixos();
    return sigmaDoNivel(k) * max(e.x, e.y);
}

/** O sigma do n?vel `k` num eixo. */
float sigmaNoEixo(int k, bool vertical) {
    vec2 e = eixos();
    return sigmaDoNivel(k) * (vertical ? e.y : e.x);
}

/** Em que degrau o n?vel mais largo ? desfocado: aquele em que o sigma dele fica entre 1,5 e 3 pontos. */
int degrauDoMaior() {
    float s = sigmaMaior(0);
    if (s < 3.0) return 0;
    return clamp(int(floor(log2(s / 1.5))), 0, DEGRAUS);
}

/** Um passe do desfoque gaussiano no degrau `d`, com `sigma` em pontos desse degrau. */
vec3 desfocar(int d, ivec2 p, float sigma, bool vertical) {
    int meia = min(int(ceil(sigma * 3.0)), MEIA_MAX);
    // Centro (i = 0, w = 1.0).
    vec3 soma = vertical ? horizontal(d, p) : degrau(d, p);
    float pesos = 1.0;
    // Pesos incrementais: um ?nico exp() por passada em vez de um por amostra.
    // w_i = w_{i-1} ? rk, com rk crescendo por r?: i=1?r, i=2?r?, i=3?r?, ...
    float r  = exp(-0.5 / (sigma * sigma));
    float r2 = r * r;
    float rk = r;   // r^(2i-1) para i=1
    float w  = 1.0;
    for (int i = 1; i <= MEIA_MAX; i++) {
        if (i > meia) break;
        w  *= rk;
        rk *= r2;
        ivec2 qP = p + (vertical ? ivec2(0,  i) : ivec2( i, 0));
        ivec2 qM = p + (vertical ? ivec2(0, -i) : ivec2(-i, 0));
        soma  += w * ((vertical ? horizontal(d, qP) : degrau(d, qP))
                    + (vertical ? horizontal(d, qM) : degrau(d, qM)));
        pesos += 2.0 * w;
    }
    return soma / pesos;
}

/**
 * O sigma, em pontos do degrau `d`, que falta aplicar para o n?vel `k`: a pr?pria pir?mide j?
 * desfocou um pouco (cada descida de 2 x 2 soma 1/12 de ponto? de vari?ncia).
 */
float sigmaNoDegrau(int k, int d, ivec2 T, bool vertical) {
    float ponto = float(textureSize(inputImg, 0).x) / float(T.x);
    float s = sigmaNoEixo(k, vertical) / ponto;
    float jaFeito = d == 0 ? 0.0 : (1.0 - exp2(-2.0 * float(d))) / 12.0;
    return sqrt(max(s * s - jaFeito, 0.01));
}

/** Um buffer codificado num ponto qualquer, com interpola??o bilinear feita em luz (a borda repete). */
vec3 bilinearEm(sampler2D t, vec2 uv) {
    ivec2 T = textureSize(t, 0);
    vec2 c = uv * vec2(T) - 0.5;
    ivec2 b = ivec2(floor(c));
    vec2 f = c - vec2(b);
    ivec2 m = T - 1;
    vec3 a00 = decodificar(texelFetch(t, clamp(b, ivec2(0), m), 0));
    vec3 a10 = decodificar(texelFetch(t, clamp(b + ivec2(1, 0), ivec2(0), m), 0));
    vec3 a01 = decodificar(texelFetch(t, clamp(b + ivec2(0, 1), ivec2(0), m), 0));
    vec3 a11 = decodificar(texelFetch(t, clamp(b + ivec2(1, 1), ivec2(0), m), 0));
    return mix(mix(a00, a10, f.x), mix(a01, a11, f.x), f.y);
}

/** Todos os n?veis juntos (screen), em luz, no pr?prio pixel: a conta medida, exata. */
vec3 juntaNoPixel(ivec2 p, int m0) {
    vec3 falta = 1.0 - decodificar(texelFetch(jb, p, 0));          // os n?veis finos desfocados
    vec3 e = luzDaFonte(p);
    for (int k = m0; k < NIVEIS; k++) {
        if (sigmaMaior(k) < 0.25) falta *= 1.0 - e;                // n?vel fino demais: ? a pr?pria entrada
    }
    if (m0 >= 1) falta *= 1.0 - bilinearEm(h1, acScreenNorm);      // os n?veis largos, j? juntos (passes 16?19)
    return 1.0 - falta;
}

/** O mesmo num ponto qualquer da tela (para a Chromatic Aberration). */
vec3 juntaEm(vec2 uv, int m0) {
    vec3 falta = 1.0 - bilinearEm(jb, uv);
    vec3 e = bilinearEm(lz, uv);
    for (int k = m0; k < NIVEIS; k++) {
        if (sigmaMaior(k) < 0.25) falta *= 1.0 - e;
    }
    if (m0 >= 1) falta *= 1.0 - bilinearEm(h1, uv);
    return 1.0 - falta;
}

float ruido(vec2 q) {
    vec3 h = fract(vec3(q.xyx) * 0.1031);
    h += dot(h, h.yzx + 33.33);
    return fract((h.x + h.y) * h.z);
}

void dg_main() {
    int m0 = degrauDoMaior();

    // ---- 0: a luz da fonte (limiar e gama), uma vez por pixel ----
    if (acPass == 0) {
        ivec2 T0 = textureSize(inputImg, 0);
        fragColor = codificar(entrada(ivec2(min(floor(acScreenNorm * vec2(T0)), vec2(T0) - 1.0))));
        return;
    }
    // Os passes daqui para baixo, contados a partir do 1.
    int passe = acPass - 1;

    // ---- 0..4: a pir?mide ----
    if (passe < 5) {
        int d = passe + 1;
        if (d > m0) { fragColor = vec4(0.0); return; }
        // A m?dia da ?REA que este ponto cobre no degrau de cima. Os buffers n?o t?m exatamente a metade um do
        // outro (o lado ? arredondado para baixo): com dois pontos por eixo, uma linha inteira ficava de fora.
        ivec2 Tc = tamanhoDe(d - 1);
        vec2 razao = vec2(Tc) / acResolution;
        vec2 de = floor(acScreenNorm * acResolution) * razao, ate = de + razao;
        ivec2 b = ivec2(floor(de));
        vec3 l = vec3(0.0);
        float area = 0.0;
        for (int j = 0; j < 4; j++) {
            float wy = min(float(b.y + j + 1), ate.y) - max(float(b.y + j), de.y);
            if (wy <= 0.0) continue;
            for (int i = 0; i < 4; i++) {
                float wx = min(float(b.x + i + 1), ate.x) - max(float(b.x + i), de.x);
                if (wx <= 0.0) continue;
                l += wx * wy * degrau(d - 1, b + ivec2(i, j));
                area += wx * wy;
            }
        }
        l /= max(area, 1e-6);
        fragColor = codificar(l);
        return;
    }

    // ---- 5..14: o n?vel de cada degrau (o degrau d recebe o n?vel m0 ? d) ----
    if (passe < 15) {
        bool vertical = passe >= 10;
        int d = (vertical ? passe - 10 : passe - 5) + 1;
        if (d > m0) { fragColor = vec4(0.0); return; }
        ivec2 T = vertical ? tamanhoDoH(d) : tamanhoDe(d);
        ivec2 p = ivec2(min(floor(acScreenNorm * vec2(T)), vec2(T) - 1.0));
        fragColor = codificar(desfocar(d, p, sigmaNoDegrau(m0 - d, d, T, vertical), vertical));
        return;
    }

    // ---- 15..18 (16..19 na lista): os n?veis largos juntos em screen, do degrau 5 subindo; o degrau d
    //      guarda (em h_d) ele mesmo junto com tudo o que est? abaixo dele, ampliado em luz ----
    if (passe < 19) {
        int d = 4 - (passe - 15);
        // O tamanho vem do degrau (o mesmo do h_d): o alvo do passe o motor n?o entrega como textura.
        ivec2 Td = tamanhoDe(d);
        ivec2 pd = ivec2(min(floor(acScreenNorm * vec2(Td)), vec2(Td) - 1.0));
        vec3 abaixo = d == 4 ? bilinearEm(p5, acScreenNorm)
                    : (d == 3 ? bilinearEm(h4, acScreenNorm) : (d == 2 ? bilinearEm(h3, acScreenNorm) : bilinearEm(h2, acScreenNorm)));
        fragColor = codificar(1.0 - (1.0 - degrau(d, pd)) * (1.0 - abaixo));
        return;
    }

    ivec2 T = textureSize(inputImg, 0);
    ivec2 p = ivec2(min(floor(acScreenNorm * vec2(T)), vec2(T) - 1.0));

    // ---- 19..26 (20..27 na lista): os n?veis finos (de m0 em diante), na resolu??o cheia; menos de 1/4 de ponto de sigma n?o desfoca ----
    if (passe < 27) {
        int vaga = (passe - 19) / 2;
        bool vertical = ((passe - 19) & 1) == 1;
        int k = m0 + vaga;
        bool usa = k < NIVEIS && sigmaMaior(k) >= 0.25;
        if (!vertical) {
            fragColor = usa ? codificar(desfocar(0, p, sigmaNoEixo(k, false), false)) : vec4(0.0);
            return;
        }
        // a jun??o at? aqui (screen): quem escreve em `ja` l? `jb`, e vice-versa; a primeira come?a do zero
        vec3 antes = vaga == 0 ? vec3(0.0) : decodificar((vaga & 1) == 1 ? texelFetch(ja, p, 0) : texelFetch(jb, p, 0));
        if (usa) antes = 1.0 - (1.0 - antes) * (1.0 - desfocar(0, p, sigmaNoEixo(k, true), true));
        fragColor = codificar(antes);
        return;
    }

    // ---- 27 (28 na lista): junta os n?veis, cor, exposi??o, gama e a mistura com a imagem ----
    vec3 junta = juntaNoPixel(p, m0);
    float ca = chromaticAberration ? clamp(caAmount, 0.0, 100.0) / 100.0 * 0.06 : 0.0;
    if (ca > 0.0) {
        // o vermelho lido mais perto do centro (halo ampliado), o azul mais longe (halo reduzido)
        vec2 c = acScreenNorm - 0.5;
        junta = vec3(juntaEm(0.5 + c * (1.0 - ca), m0).r, junta.g, juntaEm(0.5 + c * (1.0 + ca), m0).b);
    }
    if (tint) {
        vec3 tc = paraLuz(tintColor.rgb);
        vec3 tingida = dot(junta, LUMA) * tc / max(dot(tc, LUMA), 1e-4);
        junta = mix(junta, tingida, clamp(tintAmount / 100.0, 0.0, 1.0));
    }
    // medido: a exposi??o vem depois da jun??o, e o resultado volta do gama preso em 1
    vec3 luz = min(paraGama(junta * exposure), vec3(1.0));
    float maiorLuz = max(luz.r, max(luz.g, luz.b));

    vec4 fonte = texelFetch(inputImg, p, 0);
    float a = fonte.a * clamp(sourceOpacity / 100.0, 0.0, 1.0);
    vec3 fp = fonte.rgb * a;                                        // a fonte pr?-multiplicada
    bool soma = glowBlendMode == 1;
    vec3 cor = soma ? fp + luz : 1.0 - (1.0 - fp) * (1.0 - luz);    // Add, ou screen (o medido)
    // medido: sem Unmult a sa?da ? opaca; com ele, o alfa ? screen(alfa da fonte, maior canal da luz)
    float alfa = unmult ? (soma ? min(a + maiorLuz, 1.0) : 1.0 - (1.0 - a) * (1.0 - maiorLuz)) : 1.0;
    if (alfa <= 0.0) { fragColor = vec4(0.0); return; }
    vec3 rgb = min(cor / alfa, vec3(1.0));
    if (dither) {
        // triangular, de -1 a +1 n?vel de 255
        vec2 q = vec2(p);
        rgb = clamp(rgb + (ruido(q) - ruido(q + vec2(57.0, 113.0))) / 255.0, 0.0, 1.0);
    }
    fragColor = vec4(rgb, alfa);
}

vec4 aurea_main(vec2 uv) { fragColor = vec4(0.0); dg_main(); return fragColor; }
