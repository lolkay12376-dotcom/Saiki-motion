// Pass 2: edge-driven warp + multi-step chromatic smear.
float dc_sig(vec4 c) {
    return aurea_luma(c.rgb) + 0.5 * (c.r - c.b);
}

vec2 dc_refl(vec2 p) {
    return vec2(1.0) - abs(vec2(1.0) - mod(p, vec2(2.0)));
}

// Smooth (cubic B-spline) lookup of the warp field: no visible texel blocks.
float dc_field(vec2 uv) {
    vec2 ts = vec2(textureSize(soft, 0));
    uv = dc_refl(uv);
    vec2 c = uv * ts - 0.5;
    vec2 i = floor(c);
    vec2 f = c - i;
    vec2 w0 = (1.0 - f) * (1.0 - f) * (1.0 - f) / 6.0;
    vec2 w1 = (4.0 - 6.0 * f * f + 3.0 * f * f * f) / 6.0;
    vec2 w2 = (1.0 + 3.0 * f + 3.0 * f * f - 3.0 * f * f * f) / 6.0;
    vec2 w3 = f * f * f / 6.0;
    vec2 g0 = w0 + w1;
    vec2 g1 = w2 + w3;
    vec2 h0 = w1 / g0 - 1.0;
    vec2 h1 = w3 / g1 + 1.0;
    vec2 lo = vec2(0.5) / ts;
    vec2 hi = vec2(1.0) - lo;
    vec2 x0 = clamp(dc_refl((i + h0 + 0.5) / ts), lo, hi);
    vec2 x1 = clamp(dc_refl((i + h1 + 0.5) / ts), lo, hi);
    float a = dc_sig(textureLod(soft, vec2(x0.x, x0.y), 0.0));
    float b = dc_sig(textureLod(soft, vec2(x1.x, x0.y), 0.0));
    float cc = dc_sig(textureLod(soft, vec2(x0.x, x1.y), 0.0));
    float dd = dc_sig(textureLod(soft, vec2(x1.x, x1.y), 0.0));
    return g0.y * (g0.x * a + g1.x * b) + g1.y * (g0.x * cc + g1.x * dd);
}

uint dc_pcg(uint v) {
    uint state = v * 747796405u + 2891336453u;
    uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;
    return (word >> 22u) ^ word;
}

// good integer hash -> 0..1 (different for every pixel and every sample)
float dc_rand(uvec2 p, uint k) {
    uint h = dc_pcg(p.x + dc_pcg(p.y + dc_pcg(k)));
    return float(h) * (1.0 / 4294967295.0);
}

float dc_wrap(float v, float mode) {
    if (mode < 0.5) return v;                       // No: leave it, outside is transparent
    if (mode < 1.5) return fract(v);                // Tile
    return 1.0 - abs(1.0 - mod(v, 2.0));            // Reflect
}

vec4 aurea_main(vec2 uv) {
    // warp direction = gradient of the soft field, rotated
    vec2 ts = vec2(textureSize(soft, 0));
    vec2 e = max(aurea_px_to_uv(vec2(warpBlur * warpSize * 10.5)), vec2(1.5) / ts);
    float gx = dc_field(uv + vec2(e.x, 0.0)) - dc_field(uv - vec2(e.x, 0.0));
    float gy = dc_field(uv + vec2(0.0, e.y)) - dc_field(uv - vec2(0.0, e.y));
    vec2 g = clamp(vec2(gx, gy), vec2(-0.5), vec2(0.5));
    float wa = warpRotate * AUREA_PI;
    g = vec2(cos(wa) * g.x - sin(wa) * g.y, sin(wa) * g.x + cos(wa) * g.y);

    vec2 dispPx = g * 900.0 * amount * vec2(amountX, amountY);
    vec2 blurPx = vec2(cos(rotate), sin(rotate)) * blurLength * amount;
    vec2 dispUV = aurea_px_to_uv(dispPx);
    vec2 blurUV = aurea_px_to_uv(blurPx);

    // enough samples so the smear never shows as separate ghost lines:
    // at least one sample every ~3 layer px of total spread
    float spreadPx = length(blurPx) + 0.4 * length(dispPx);
    int n = int(clamp(max(floor(steps + 0.5), ceil(spreadPx / 3.0)), 1.0, 64.0));
    // every sample gets its own random offset inside its slot: ghost copies
    // (visible as lines at full resolution) become fine grain instead
    uvec2 pix = uvec2(floor(uv * aurea.resolution.xy));

    vec3 acc = vec3(0.0);
    vec3 wsum = vec3(0.0);
    float accA = 0.0;
    vec2 res = aurea.resolution.xy;
    vec2 srcSize = vec2(textureSize(aurea_source, 0));

    for (int i = 0; i < 64; ++i) {
        if (i >= n) break;
        float t = (n > 1) ? (float(i) + mix(0.5, dc_rand(pix, uint(i)), jitter)) / float(n) : 0.5;
        float tc = clamp(t + colorBias, 0.0, 1.0);
        vec3 w = (tc < 0.5) ? mix(color1.rgb, color2.rgb, tc * 2.0)
                            : mix(color2.rgb, color3.rgb, (tc - 0.5) * 2.0);
        // chromatic dispersion: each step is displaced a little differently
        vec2 p = uv + blurUV * (t - 0.5) + dispUV * (1.0 + fringe * (t - 0.5));
        vec2 q = aurea_layer_uv(p);
        q = vec2(dc_wrap(q.x, wrapX), dc_wrap(q.y, wrapY));
        p = aurea_uv_from_layer(q);
        // Tile / Reflect: stay inside the image so the transparent border never blends in (no seam lines)
        if (wrapX > 0.5) p.x = clamp(p.x, 0.5 / srcSize.x, 1.0 - 0.5 / srcSize.x);
        if (wrapY > 0.5) p.y = clamp(p.y, 0.5 / srcSize.y, 1.0 - 0.5 / srcSize.y);
        if (smoothing < 0.5) p = (floor(p * res) + 0.5) / res;
        vec4 s = textureLod(aurea_source, p, 0.0);
        acc += s.rgb * w;
        wsum += w;
        accA += s.a;
    }

    vec3 rgb = (whitePreserve > 0.5) ? acc / max(wsum, vec3(1e-4)) : acc / float(n);
    float lm = dot(rgb, vec3(0.299, 0.587, 0.114));
    rgb = mix(vec3(lm), rgb, satur);
    rgb = mix(rgb, rgb * tintColor.rgb, tintAmt);
    vec4 res0 = vec4(rgb, accA / float(n));
    return mix(texture(aurea_source, uv), res0, effectMix);
}
