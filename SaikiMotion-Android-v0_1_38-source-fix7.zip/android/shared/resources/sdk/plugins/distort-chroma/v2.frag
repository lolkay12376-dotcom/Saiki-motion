// Vertical gaussian blur level 2 (tap spacing = base * 0.5), dense enough to never alias.
vec4 aurea_main(vec2 uv) {
    float spacing = max(warpBlur, 0.0) * warpSize * 6.0 * 0.5;   // layer px between taps
    vec4 acc = vec4(0.0);
    float wsum = 0.0;
    vec2 sz = vec2(textureSize(fld, 0));
    for (int i = -4; i <= 4; ++i) {
        float w = exp(-0.12 * float(i * i));
        vec2 off = aurea_px_to_uv(vec2(0.0, float(i) * spacing));
        vec2 p = (vec2(1.0) - abs(vec2(1.0) - mod(uv + off, vec2(2.0))));
        p = clamp(p, vec2(0.5) / sz, vec2(1.0) - vec2(0.5) / sz);   // never touch the transparent border
        acc += textureLod(fld, p, 0.0) * w;
        wsum += w;
    }
    return acc / wsum;
}
