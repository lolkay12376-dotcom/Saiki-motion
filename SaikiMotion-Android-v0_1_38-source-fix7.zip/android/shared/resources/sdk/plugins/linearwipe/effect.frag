vec3 lwf_to_srgb(vec3 v) {
    v = max(v, vec3(0.0));
    vec3 lo = v * 12.92;
    vec3 hi = 1.055 * pow(v, vec3(0.4166667)) - vec3(0.055);
    return mix(hi, lo, vec3(lessThan(v, vec3(0.0031308))));
}

vec3 lwf_to_linear(vec3 v) {
    v = clamp(v, vec3(0.0), vec3(1.0));
    vec3 lo = v / 12.92;
    vec3 hi = pow((v + vec3(0.055)) / 1.055, vec3(2.4));
    return mix(hi, lo, vec3(lessThan(v, vec3(0.04045))));
}

vec4 aurea_main(vec2 uv) {
    vec4 s = texture(aurea_source, uv);
    float big = max(aurea.layer.x, aurea.layer.y);
    vec2 ext = aurea.layer.xy / big;
    vec2 p = (uv - vec2(0.5)) * ext;

    // AE convention: angle 90 sweeps left to right
    float a = 1.5707963 - lw_angle;
    vec2 dir = vec2(cos(a), sin(a));
    float len = max(abs(dir.x) * ext.x + abs(dir.y) * ext.y, 0.0001);
    float pos = dot(p, dir) / len + 0.5;

    float fe = max(lw_feather, 0.0005);
    float t = lw_completion;
    float edge = mix(lw_start - fe, lw_end + fe, t);
    float vis = smoothstep(edge - fe, edge + fe, pos);
    if (lw_mode > 0.5) vis = 1.0 - vis;

    vec4 res = s * vis;

    if (lw_border_width > 0.0) {
        float bm = (1.0 - smoothstep(lw_border_width, lw_border_width + fe, abs(pos - edge)));
        bm *= step(0.0001, t) * step(t, 0.9999);
        res = res * (1.0 - bm) + vec4(lw_border_color.rgb * bm, bm);
    }
    return res;
}
