// Mojo II - 1 passe, 1 leitura de textura por pixel.
// Parametros: footageType, mojo, mojoTint, punchIt, bleachIt, fadeIt, blueSqueeze, skinColor,
// skinSqueeze, skinSolo, showSkin, exposure, coolWarm, greenMagenta, vignette, strength.
// Correcao de exposicao e temperatura em luz linear; o resto em gama 2.2.

float mj_luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3 mj_enc(vec3 c) { return pow(max(c, vec3(0.0)), vec3(1.0 / 2.2)); }
vec3 mj_dec(vec3 c) { return pow(max(c, vec3(0.0)), vec3(2.2)); }
vec3 mj_hue(float h) {                                   // cor pura de um matiz em graus
    return clamp(abs(fract(vec3(h / 360.0) + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0, 0.0, 1.0);
}
vec3 mj_sCurve(vec3 v, float k) {                        // curva em S (so entre 0 e 1), k = forca
    vec3 vc = clamp(v, 0.0, 1.0);
    return v + (vc * vc * (3.0 - 2.0 * vc) - vc) * k;
}
vec2 mj_iq(vec3 v) {                                     // crominancia YIQ: a linha de pele fica perto do eixo I
    return vec2(0.596 * v.r - 0.274 * v.g - 0.322 * v.b, 0.211 * v.r - 0.523 * v.g + 0.312 * v.b);
}
vec3 mj_iqDelta(vec2 d) { return vec3(0.956 * d.x + 0.621 * d.y, -0.272 * d.x - 0.647 * d.y, -1.106 * d.x + 1.703 * d.y); }
vec2 mj_rot(vec2 p, float a) { float c = cos(a), s = sin(a); return vec2(c * p.x - s * p.y, s * p.x + c * p.y); }
const float MJ_SKIN_ANGLE = 0.15;                        // angulo da linha de pele no plano IQ (rad)

// Mascara de pele: perto da linha de pele, saturacao moderada, nem muito escuro nem estourado.
float mj_skin(vec3 v) {
    vec2 iq = mj_iq(v);
    float ch = length(iq);
    float cd = dot(iq / max(ch, 1e-4), vec2(cos(MJ_SKIN_ANGLE), sin(MJ_SKIN_ANGLE)));
    float l = mj_luma(v);
    return smoothstep(0.82, 0.96, cd) * smoothstep(0.03, 0.10, ch) * (1.0 - smoothstep(0.30, 0.50, ch))
         * smoothstep(0.08, 0.20, l) * (1.0 - smoothstep(0.90, 1.0, l));
}

vec4 aurea_main(vec2 uv) {
    vec4 src = texture(aurea_source, uv);
    float a = src.a;
    vec3 base = (a > 1e-4) ? src.rgb / a : vec3(0.0);

    // ---- Correcoes (linear): exposicao, frio/quente, verde/magenta ----
    vec3 c = base * exp2(exposure);
    c.r *= 1.0 + 0.2 * coolWarm * 0.01;
    c.b *= 1.0 - 0.2 * coolWarm * 0.01;
    c.g *= 1.0 - 0.2 * greenMagenta * 0.01;
    vec3 v = mj_enc(c);

    // ---- Meu material e: curva de contraste para o formato da imagem ----
    int ft = int(footageType + 0.5);
    float sat0 = 1.0;
    if (ft == 1) {                                       // Flat
        v = mj_sCurve(clamp((v - 0.04) / 0.92, 0.0, 1.0), 0.5);
        sat0 = 1.2;
    } else if (ft == 2) {                                // Pro
        v = mj_sCurve(v, 0.25);
        sat0 = 1.08;
    } else if (ft == 3) {                                // Log
        v = mj_sCurve(clamp((v - 0.10) / 0.80, 0.0, 1.0), 1.0);
        sat0 = 1.5;
    }
    float l0 = mj_luma(v);
    v = mix(vec3(l0), v, sat0);
    vec3 vIn = v;
    float skin = mj_skin(vIn);                           // mascara de pele medida antes de colorir

    // ---- Mojo: contraste + luzes quentes + sombras frias (a pele e poupada) ----
    float m = mojo * 0.01;
    float coolHue = (mojoTint >= 0.0) ? 190.0 + mojoTint * 0.35 : 190.0 + mojoTint * 1.7;   // + azul real, - laranja/vermelho
    float lm = mj_luma(v);
    float shadowW = 1.0 - smoothstep(0.0, 0.6, lm);
    float highW = smoothstep(0.4, 1.0, lm);
    vec3 coolF = mix(vec3(1.0), mj_hue(coolHue), 0.7);
    vec3 warmF = mix(vec3(1.0), mj_hue(coolHue + 180.0), 0.7);   // complementar: quente
    coolF /= max(mj_luma(coolF), 1e-3);
    warmF /= max(mj_luma(warmF), 1e-3);
    float spare = 1.0 - 0.8 * skin;
    v = mj_sCurve(v, 0.35 * m);
    v *= mix(vec3(1.0), coolF, m * shadowW * spare);
    v *= mix(vec3(1.0), warmF, m * highW * spare);

    // ---- Punch It: contraste nas sombras (mais forte = sombras mais escuras), poupa a pele ----
    float p = punchIt * 0.01;
    float ls = mj_luma(v);
    float pw = (1.0 - smoothstep(0.0, 0.65, ls)) * (1.0 - 0.7 * skin);
    v = pow(max(v, vec3(0.0)), vec3(1.0 + p * 0.6 * pw));
    float satP = 1.0 + max(p, 0.0) * 0.2 * (1.0 - skin);          // o contraste modula a saturacao
    v = mix(vec3(mj_luma(v)), v, satP);

    // ---- Controles de pele (plano IQ) ----
    vec2 iq = mj_iq(v);
    float th = atan(iq.y, max(iq.x, 1e-4));
    float dev = th - MJ_SKIN_ANGLE;
    vec2 iq2 = mj_rot(iq, -skinColor * 0.01 * 0.2 * skin);        // Skin Color: gira o matiz da pele
    iq2 = mj_rot(iq2, -dev * skinSqueeze * 0.01 * 0.85 * skin);   // Skin Squeeze: achata a faixa de tons de pele
    v += mj_iqDelta(iq2 - iq);

    // ---- Bleach It: satura ou dessatura tudo ----
    v = mix(vec3(mj_luma(v)), v, max(1.0 - bleachIt * 0.01 * 0.8, 0.0));

    // ---- Blue Squeeze: aproxima os azuis de um unico matiz (plano YUV) ----
    float yv = mj_luma(v);
    vec2 uvc = vec2(0.492 * (v.b - yv), 0.877 * (v.r - yv));
    float ang = atan(uvc.y, uvc.x);
    float aBlue = -0.35;
    float wBlue = (1.0 - smoothstep(0.35, 1.05, abs(ang - aBlue))) * smoothstep(0.02, 0.10, length(uvc));
    vec2 uvn = mj_rot(uvc, -(ang - aBlue) * blueSqueeze * 0.01 * 0.85 * wBlue);
    vec2 duv = uvn - uvc;
    v += vec3(1.13983 * duv.y, -0.39465 * duv.x - 0.5806 * duv.y, 2.03211 * duv.x);

    // ---- Fade It: levanta os pretos ----
    float fd = fadeIt * 0.01 * 0.12;
    v = v * (1.0 - fd) + fd;

    // ---- Skin Solo: dessatura tudo menos a pele ----
    v = mix(v, vec3(mj_luma(v)), skinSolo * 0.01 * (1.0 - skin));

    // ---- Vinheta (positivo escurece as bordas, negativo clareia) ----
    vec2 box = aurea.region.zw;
    float rv = length((uv - 0.5) * box) / (0.5 * max(length(box), 1.0));
    float vg = pow(smoothstep(0.35, 1.0, rv), 1.3);
    vec3 lin = mj_dec(v) * exp2(-vignette * 0.01 * 2.0 * vg);

    vec3 outRgb = mix(base, lin, clamp(strength * 0.01, 0.0, 1.0));

    // ---- Mostrar grade de pele: grade verde onde o matiz esta na faixa de pele ----
    if (showSkin > 0.5) {
        vec2 px = uv * box;
        float grid = float(mod(px.x, 10.0) < 1.5 || mod(px.y, 10.0) < 1.5);
        outRgb = mix(outRgb, vec3(0.1, 1.0, 0.25), 0.85 * grid * smoothstep(0.35, 0.65, skin));
    }

    return vec4(outRgb * a, a);
}
