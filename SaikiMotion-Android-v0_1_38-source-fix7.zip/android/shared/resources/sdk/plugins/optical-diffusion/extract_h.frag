// Optical Diffusion v1.1 for AUREA - pass 1/7
// Highlight extraction + DENSE horizontal capture blur.
// Writes target "cap_h" at 0.5 scale. Linear, premultiplied alpha.
//
// Why this pass exists: thin bright features (neon trails, sparks, text) are
// narrower than the tap spacing of any wide blur. Blurring them directly with
// sparse taps misses the feature between taps and deposits its energy in
// clumps -> chunky, non-smooth falloff. This pass blurs with a very small
// sigma and dense taps (spacing <= 1.25 texels) so every fine feature is
// captured into a smooth, band-limited field that the wider passes can safely
// re-blur.

// Fixed 24-tap Gaussian in sigma units: spacing 0.4 sigma, reach +/-4.6 sigma.
// Adjacent taps are pre-merged into 12 linear-sampled pairs -> 12 fetches,
// zero runtime exp(). Weights are pre-normalized (sum = 1).
const float KW[12] = float[12](
    0.0000276, 0.0006097, 0.0072059, 0.0457700, 0.1566795, 0.2897073,
    0.2897073, 0.1566795, 0.0457700, 0.0072059, 0.0006097, 0.0000276
);
const float KM[12] = float[12](
    -4.2584, -3.4766, -2.6985, -1.9239, -1.1529, -0.3840,
     0.3840,  1.1529,  1.9239,  2.6985,  3.4766,  4.2584
);

vec4 aurea_main(vec2 uv) {
    // --- filter character: tent blend across the 5 presets ---
    float f  = clamp(filter_type, 0.0, 4.0);
    float w0 = clamp(1.0 - abs(f - 0.0), 0.0, 1.0);
    float w1 = clamp(1.0 - abs(f - 1.0), 0.0, 1.0);
    float w2 = clamp(1.0 - abs(f - 2.0), 0.0, 1.0);
    float w3 = clamp(1.0 - abs(f - 3.0), 0.0, 1.0);
    float w4 = clamp(1.0 - abs(f - 4.0), 0.0, 1.0);
    float ws = max(w0 + w1 + w2 + w3 + w4, 1e-4);
    w0 /= ws; w1 /= ws; w2 /= ws; w3 /= ws; w4 /= ws;

    float thrBias = w0 * 0.10 + w1 * 0.00 + w2 * 0.15 + w3 * (-0.06) + w4 * 0.18;
    float sprC    = w0 * 0.90 + w1 * 1.00 + w2 * 0.70 + w3 * 1.40  + w4 * 0.50;

    // chain scale from Spread; capture sigma stays tiny and dense
    float scl = mix(0.60, 3.0, clamp(spread * sprC, 0.0, 1.0));
    float sig = 1.25 * scl;

    // smooth rational highlight weight: C1 onset, asymptotic shoulder,
    // never a hard truncation ring. Rise starts 0.15 below the threshold.
    float onset = clamp(threshold + thrBias, 0.05, 0.98) - 0.15;

    vec4 acc = vec4(0.0);
    for (int j = 0; j < 12; j++) {
        vec2 o = vec2(1.0, 0.0) * aurea.resolution.zw * (KM[j] * sig);
        vec4 c = texture(aurea_source, uv + o);
        float x = max(aurea_luma(c.rgb) - onset, 0.0);
        acc += c * ((x * x) / (x * x + 0.0256) * KW[j]);
    }
    return acc;
}
