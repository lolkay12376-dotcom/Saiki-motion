// Ripple Dissolve 1.1 - 1 passe, 1 leitura de textura por pixel.
// Parametros (ordem do plugin.json): animation, percentDone, duration, center, radiusPeak,
// waveHeight, perpHeight, waveWidth, widthGrow, waveSpeed, speedDecel, lightAngle,
// innerRadius, fallOff, lightLevel, fadeOut.

vec4 aurea_main(vec2 uv) {
    // Progresso: Automatico usa o tempo da camada; Percentual usa o parametro (keyframes).
    float t = (animation < 0.5)
        ? clamp(aurea.time.x / max(duration, 0.001), 0.0, 1.0)
        : clamp(percentDone * 0.01, 0.0, 1.0);
    float e = t * (0.5 + t * (1.5 - t));          // ease in/out suave (hermite, tangentes 0.5)
    float bell = sin(AUREA_PI * e);               // 0 no inicio e no fim, pico no meio
    float d = smoothstep(0.0, 1.0, e) * clamp(fadeOut * 0.01, 0.0, 1.0);   // esmaecer: 0 = nunca some

    // Geometria em px da camada (igual no preview reduzido e no export).
    vec2 dpx = (uv - center) * aurea.region.zw;
    float r = length(dpx);
    vec2 dir = (r > 1e-4) ? dpx / r : vec2(1.0, 0.0);
    vec2 perp = vec2(-dir.y, dir.x);
    vec2 boxPx = aurea.region.zw;
    vec2 cPx = center * boxPx;
    float halfDiag = length(max(cPx, boxPx - cPx));   // centro ate o canto mais distante: o raio cobre o quadro

    // Onda: comprimento cresce com Width Percent Increase; fase acumula a Speed com desaceleracao.
    float W = max(waveWidth * (1.0 + widthGrow * 0.01 * e), 1.0);
    float dec = clamp(speedDecel * 0.01, 0.0, 1.0);
    float accum = waveSpeed * (e - 0.5 * dec * e * e);
    float arg = 2.0 * AUREA_PI * (r / W - accum);

    // Envelope radial: frente externa ate Radius Peak, regiao interna amortecida.
    float R = radiusPeak * 0.01 * halfDiag * e;
    float fl = max(fallOff * 0.01, 0.01) * 0.5 * max(R, 1.0);
    float outerEnv = 1.0 - smoothstep(R - fl, R + fl, r);
    float ri = innerRadius * 0.01 * halfDiag * e;
    float innerEnv = (ri > 0.0) ? smoothstep(ri - fl, ri + fl, r) : 1.0;
    float env = outerEnv * innerEnv * bell;

    float s = sin(arg);
    float cs = cos(arg);
    vec2 dispPx = (dir * (waveHeight * s) + perp * (perpHeight * cs)) * env;

    // Distorce a camada e dissolve (o fundo aparece por baixo).
    vec2 uvS = clamp(uv - aurea_px_to_uv(dispPx), aurea.resolution.zw * 0.5, vec2(1.0) - aurea.resolution.zw * 0.5);
    vec4 col = texture(aurea_source, uvS) * (1.0 - d);

    // Luz na crista da onda (inclinacao da onda), somada e limitada ao alfa.
    float slope = waveHeight * cs * (2.0 * AUREA_PI / W) * env;
    vec3 N = normalize(vec3(-slope * dir, 1.0));
    vec3 L = normalize(vec3(cos(lightAngle), -sin(lightAngle), 1.0));   // 0 = luz vinda da direita, 90 = de cima
    float flatLit = pow(max(L.z, 0.0), 24.0);
    float lit = clamp((pow(max(dot(N, L), 0.0), 24.0) - flatLit) / max(1.0 - flatLit, 1e-3), 0.0, 1.0);
    col.rgb += vec3(1.0) * lit * lightLevel * 0.01 * col.a;

    return col;
}
