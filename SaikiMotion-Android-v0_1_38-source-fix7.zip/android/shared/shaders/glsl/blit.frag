#version 450
// PORT-OF: msl/MetalSL.passes.msl::blitFragment
// MSL-SHA256: 3d03b5595714ddb6
layout(location = 0) in vec2 vUv;
layout(location = 0) out vec4 outColor;
layout(set = 0, binding = 0) uniform sampler2D uTex;   // sampler = linear, clamp_to_edge (== linearClamp)
vec2 flipV(vec2 uv) { return vec2(uv.x, 1.0 - uv.y); }
void main() { outColor = texture(uTex, flipV(vUv)); }
