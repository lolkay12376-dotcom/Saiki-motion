#version 450
// PORT-OF: msl/MetalSL.passes.msl::compositeFragment (+ blend helpers). Keep line-for-line with the MSL.
// MSL-SHA256: 3d03b5595714ddb6
// MSL select(a,b,c) == GLSL mix(a,b,c) with bool selector (returns b when c is true).
layout(location = 0) in vec2 vUv;
layout(location = 0) out vec4 outColor;
layout(set = 0, binding = 0) uniform sampler2D uScene;
layout(set = 0, binding = 1) uniform sampler2D uSrc;
layout(set = 0, binding = 2) uniform sampler2D uMask;
layout(std140, set = 0, binding = 3) uniform CompParams { float alpha; float mode; float maskMode; float rgbShift; } u;

vec2 flipV(vec2 uv) { return vec2(uv.x, 1.0 - uv.y); }
float lumF(vec3 c) { return dot(c, vec3(0.3, 0.59, 0.11)); }
vec3 clipCol(vec3 c) {
    float l = lumF(c), n = min(min(c.r, c.g), c.b), x = max(max(c.r, c.g), c.b);
    if (n < 0.0) c = l + (c - l) * l / max(l - n, 1e-5);
    if (x > 1.0) c = l + (c - l) * (1.0 - l) / max(x - l, 1e-5);
    return c;
}
vec3 setLum(vec3 c, float l) { return clipCol(c + (l - lumF(c))); }
float satF(vec3 c) { return max(max(c.r, c.g), c.b) - min(min(c.r, c.g), c.b); }
vec3 setSat(vec3 c, float s) {
    float mx = max(max(c.r, c.g), c.b), mn = min(min(c.r, c.g), c.b);
    return mx <= mn ? vec3(0.0) : (c - mn) * s / (mx - mn);
}
vec3 burn3(vec3 d, vec3 s)  { return mix(1.0 - min(vec3(1.0), (1.0 - d) / max(s, vec3(1e-4))), vec3(0.0), lessThanEqual(s, vec3(0.0))); }
vec3 dodge3(vec3 d, vec3 s) { return mix(min(vec3(1.0), d / max(1.0 - s, vec3(1e-4))), vec3(1.0), greaterThanEqual(s, vec3(1.0))); }
vec3 blendFn(int m, vec3 d, vec3 s) {
    switch (m) {
    case 11: return min(d, s);
    case 12: return burn3(d, s);
    case 13: return max(d + s - 1.0, vec3(0.0));
    case 14: return lumF(d) <= lumF(s) ? d : s;
    case 15: return max(d, s);
    case 16: return dodge3(d, s);
    case 17: return lumF(d) >= lumF(s) ? d : s;
    case 18: return mix(1.0 - 2.0 * (1.0 - d) * (1.0 - s), 2.0 * d * s, lessThanEqual(d, vec3(0.5)));
    case 19: {
        vec3 D = mix(sqrt(d), ((16.0 * d - 12.0) * d + 4.0) * d, lessThanEqual(d, vec3(0.25)));
        return mix(d + (2.0 * s - 1.0) * (D - d), d - (1.0 - 2.0 * s) * d * (1.0 - d), lessThanEqual(s, vec3(0.5)));
    }
    case 20: return mix(1.0 - 2.0 * (1.0 - d) * (1.0 - s), 2.0 * d * s, lessThanEqual(s, vec3(0.5)));
    case 21: return mix(dodge3(d, 2.0 * s - 1.0), burn3(d, 2.0 * s), lessThanEqual(s, vec3(0.5)));
    case 22: return clamp(d + 2.0 * s - 1.0, 0.0, 1.0);
    case 23: return mix(max(d, 2.0 * s - 1.0), min(d, 2.0 * s), lessThanEqual(s, vec3(0.5)));
    case 24: return mix(vec3(0.0), vec3(1.0), greaterThanEqual(d + s, vec3(1.0)));
    case 25: return abs(d - s);
    case 26: return d + s - 2.0 * d * s;
    case 27: return max(d - s, vec3(0.0));
    case 28: return mix(min(d / max(s, vec3(1e-4)), vec3(1.0)), vec3(1.0), lessThanEqual(s, vec3(0.0)));
    case 31: return setLum(setSat(s, satF(d)), lumF(d));
    case 32: return setLum(setSat(d, satF(s)), lumF(d));
    case 33: return setLum(s, lumF(d));
    case 34: return setLum(d, lumF(s));
    }
    return s;
}

void main() {
    vec2 uvv = vUv;
    vec4 s = texture(uSrc, flipV(uvv));
    if (u.rgbShift != 0.0) {
        s.r = texture(uSrc, flipV(clamp(uvv + vec2(u.rgbShift, 0.0), 0.0, 1.0))).r;
        s.b = texture(uSrc, flipV(clamp(uvv - vec2(u.rgbShift, 0.0), 0.0, 1.0))).b;
    }
    vec4 sRaw = s;
    s *= u.alpha;
    if (u.mode > 4.5 && u.mode < 9.5) { outColor = mix(texture(uScene, flipV(uvv)), sRaw, u.alpha); return; }
    if (u.maskMode > 0.5) {
        vec4 mk = texture(uMask, flipV(uvv));
        float m = 1.0;
        if (u.maskMode < 1.5) { m = mk.a; }
        else if (u.maskMode < 2.5) { m = 1.0 - mk.a; }
        else if (u.maskMode < 3.5) { m = dot(mk.rgb, vec3(0.299, 0.587, 0.114)); }
        else { m = 1.0 - dot(mk.rgb, vec3(0.299, 0.587, 0.114)); }
        s *= m;
    }
    vec4 d = texture(uScene, flipV(uvv));
    if (u.mode > 98.5) { outColor = s; return; }
    if (u.mode > 9.5) {
        int m = int(u.mode + 0.5);
        if (m == 10) {
            float h = fract(sin(dot(floor(gl_FragCoord.xy), vec2(12.9898, 78.233))) * 43758.5453);
            outColor = h < s.a ? vec4(s.rgb / max(s.a, 1e-4), 1.0) : d; return;
        }
        vec3 sc = s.rgb / max(s.a, 1e-4), dc = d.rgb / max(d.a, 1e-4);
        vec3 B = blendFn(m, dc, sc);
        vec3 rgb = d.rgb * (1.0 - s.a) + s.a * ((1.0 - d.a) * sc + d.a * B);
        outColor = vec4(rgb, s.a + d.a * (1.0 - s.a)); return;
    }
    if (u.mode < 0.5)      { outColor = s + d * (1.0 - s.a); }
    else if (u.mode < 1.5) { outColor = d + s; }
    else if (u.mode < 2.5) {
        vec3 scr = 1.0 - (1.0 - d.rgb) * (1.0 - s.rgb);
        outColor = mix(d, vec4(scr, max(d.a, s.a)), s.a);
    } else if (u.mode < 3.5) {
        vec3 mul = d.rgb * s.rgb;
        outColor = mix(d, vec4(mul, d.a * s.a), s.a);
    } else { outColor = d + s; }
}
