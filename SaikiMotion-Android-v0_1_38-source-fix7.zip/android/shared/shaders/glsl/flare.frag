#version 450
// PORT-OF: msl/MetalFlareSL.source.msl::flareFragment
// MSL-SHA256: 5bb34a59162c9abc
// Bindings: set0 b0 dep (NEAREST clamp == flareDepthS, depth read as .r), b1 UBO FlareArr (MSL buffer(1), 112 vec4), b2 UBO FlareLens (MSL buffer(2), 256 vec4), b8 UBO FlareU (MSL buffer(0)).
// Body is the MSL text with only mechanical changes: float2/3/4->vec2/3/4, atan2->atan, in.uv->vUv, in.pos->gl_FragCoord, depth sample syntax, thread->out.
layout(location = 0) in vec2 vUv;
layout(location = 0) out vec4 outColor;
layout(set = 0, binding = 0) uniform sampler2D dep;
layout(std140, set = 0, binding = 1) uniform FlareArr { vec4 arr[112]; };
layout(std140, set = 0, binding = 2) uniform FlareLens { vec4 lens[256]; };
layout(std140, set = 0, binding = 8) uniform FlareU { vec4 h0; vec4 h1; vec4 h2; vec4 h3; vec4 h4; vec4 h5; } u;
vec2 flipV(vec2 uv) { return vec2(uv.x, 1.0 - uv.y); }
float glmod(float x, float y) { return x - y * floor(x / y); }

float hn(float x) { return fract(sin(x * 127.1) * 43758.5453); }
float vn(float x) { float i = floor(x); float f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(hn(i), hn(i + 1.0), f); }
vec3 hsv2rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(1.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, vec3(0.0), vec3(1.0)), vec3(c.y));
}

// procedural iris: radius (vertex = 1) of the polygon / star / flower at angle a
float irisR(float a, float n, float round, float star, float curve) {
    float seg = 6.28318 / n;
    float t = glmod(a, seg);
    float hs = seg * 0.5;
    float phi = abs(t - hs);
    float cosH = cos(hs);
    float sinH = sin(hs);
    float inner = mix(cosH, 0.12, star);
    float den = cos(phi) * sinH - sin(phi) * (cosH - inner);
    float r = min(inner * sinH / max(den, 0.05), 2.0);
    float u = phi / hs;
    r *= 1.0 + curve * 0.25 * (1.0 - u * u);
    float rc = (inner + 1.0) * 0.5;
    return mix(r, rc, round);
}

float irisMask(vec2 d, float size, float n, float round, float star, float curve,
               float thick, float soft, float grad) {
    float a = atan(d.y, d.x) + 1.5708;
    float R = irisR(a, n, round, star, curve) * size;
    float x = length(d) / max(R, 0.0001);
    float edge = 0.02 + soft * 0.6;
    float outer = 1.0 - smoothstep(1.0 - edge, 1.0, x);
    float hole = mix(smoothstep(1.0 - thick - edge, 1.0 - thick + 0.001, x), 1.0, step(0.99, thick));
    return outer * hole * mix(1.0, x * x, grad);
}

float hash21(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vn2(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x), mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm2(vec2 p) { return vn2(p) * 0.55 + vn2(p * 2.07 + 5.3) * 0.3 + vn2(p * 4.3 + 11.1) * 0.15; }

// lens catalogue for the multi-lens stack: a = (blades, round, star, curve), b = (thickness, stretch, special, 0)
void lensShape(int k, out vec4 a, out vec4 b) {
    a = vec4(6.0, 0.05, 0.0, 0.0); b = vec4(1.0, 1.0, 0.0, 0.0);
    switch (k) {
        case 0: a = vec4(12.0, 1.0, 0.0, 0.0); break;
        case 1: a = vec4(3.0, 0.08, 0.0, 0.0); break;
        case 2: a = vec4(4.0, 0.05, 0.0, 0.0); break;
        case 3: a = vec4(5.0, 0.06, 0.0, 0.0); break;
        case 4: a = vec4(6.0, 0.05, 0.0, 0.0); break;
        case 5: a = vec4(7.0, 0.10, 0.0, 0.0); break;
        case 6: a = vec4(8.0, 0.08, 0.0, 0.0); break;
        case 7: a = vec4(9.0, 0.25, 0.0, 0.0); break;
        case 8: a = vec4(7.0, 0.15, 0.0, 0.9); break;
        case 9: a = vec4(12.0, 1.0, 0.0, 0.0); b.y = 2.2; break;
        case 10: a = vec4(12.0, 1.0, 0.0, 0.0); b.z = 1.0; break;
        case 11: a = vec4(5.0, 0.0, 0.6, 0.0); break;
        case 12: a = vec4(6.0, 0.0, 0.65, 0.0); break;
        case 13: a = vec4(8.0, 0.5, 0.0, -0.9); break;
        case 14: a = vec4(12.0, 1.0, 0.0, 0.0); b.x = 0.22; break;
        case 15: a = vec4(6.0, 0.05, 0.0, 0.0); b.x = 0.2; break;
        case 16: a = vec4(12.0, 1.0, 0.0, 0.0); b.z = 2.0; break;
        case 17: a = vec4(4.0, 0.05, 0.0, 0.0); b.z = 3.0; break;
        default: break;
    }
}

float lensMask(vec2 d, int kind, float size, float stretch, float soft, float grad) {
    vec4 a; vec4 b; lensShape(kind, a, b);
    vec2 q = vec2(d.x / (stretch * b.y), d.y);
    if (b.z > 2.5) { q = vec2(q.x + q.y, q.y - q.x) * 0.7071; }
    if (b.z > 0.5 && b.z < 1.5) {                       // cat-eye: two clipped circles
        float o = size * 0.42;
        return irisMask(q - vec2(0.0, o), size, 12.0, 1.0, 0.0, 0.0, 1.0, soft, grad)
             * irisMask(q + vec2(0.0, o), size, 12.0, 1.0, 0.0, 0.0, 1.0, soft, grad);
    }
    if (b.z > 1.5 && b.z < 2.5) {                       // crescent
        float m1 = irisMask(q, size, 12.0, 1.0, 0.0, 0.0, 1.0, soft, grad);
        float m2 = irisMask(q - vec2(size * 0.35, 0.0), size * 0.85, 12.0, 1.0, 0.0, 0.0, 1.0, 0.1, 0.0);
        return m1 * (1.0 - m2);
    }
    return irisMask(q, size, a.x, a.y, a.z, a.w, b.x, soft, grad);
}

void main() {
    vec2 uLight = u.h0.xy; float uIntensity = u.h0.z; float uAxis = u.h0.w;
    float uSizeMul = u.h1.x; float uEdgeFade = u.h1.y; float uAspect = u.h1.z; float uCount = u.h1.w;
    float uTime = u.h2.x; float uFlicker = u.h2.y; float uSpeed = u.h2.z; float uRayAmt = u.h2.w;
    vec3 uTintRgb = u.h3.xyz;
    float uReal = u.h4.x; float uVeil = u.h4.y; float uDust = u.h4.z; float uOccl = u.h4.w;
    float uOcclSoft = u.h5.x; float uLightZ = u.h5.y; float uHasDepth = u.h5.z;
    // 3D occlusion: sample the model depth buffer over the light's disc; objects in front hide the whole flare
    float seen = 1.0;
    if (uHasDepth > 0.5 && uOccl > 0.001) {
        float rad = mix(0.003, 0.045, uOcclSoft);
        float vis = 0.0;
        for (int s = 0; s < 16; s++) {
            float ang = float(s) * 2.39996;
            float rr = sqrt((float(s) + 0.5) / 16.0) * rad;
            vec2 suv = uLight + vec2(cos(ang) / uAspect, sin(ang)) * rr;
            if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) { vis += 1.0; continue; }
            float z = texture(dep, flipV(suv)).r;
            vis += step(uLightZ - 0.0002, z);
        }
        seen = mix(1.0, vis / 16.0, uOccl);
    }
    vec2 asp = vec2(uAspect, 1.0);
    vec2 p = vUv * asp;
    vec2 L = uLight * asp;
    vec2 ax = (vec2(0.5) * asp - L) * uAxis;
    float axLen = length(ax);
    float axAng = atan(ax.y, ax.x);
    vec2 perpU = axLen > 0.0001 ? vec2(-ax.y, ax.x) / axLen : vec2(0.0, 1.0);
    vec3 acc = vec3(0.0);

    for (int i = 0; i < 16; i++) {
        float t = arr[0 + i].x;
        if (t < -0.5 || float(i) + 0.5 > uCount) { continue; }
        float pos = arr[0 + i].y;
        float size = min(arr[0 + i].z * uSizeMul, 3.0);
        float bright = arr[16 + i].x;
        float soft = arr[16 + i].y;
        float thick = arr[16 + i].z;
        float stretch = arr[16 + i].w;
        float sides = arr[32 + i].x;
        float rays = arr[32 + i].y;
        float chroma = arr[32 + i].z;
        float follow = arr[32 + i].w;
        float noise = arr[64 + i].x;

        float ang = radians(arr[0 + i].w) + follow * axAng * smoothstep(0.03, 0.3, axLen) + arr[64 + i].y * 1.2 * axLen;
        vec2 d = p - (L + ax * pos + perpU * arr[96 + i].y);
        float ca = cos(ang);
        float sa = sin(ang);
        d = vec2(ca * d.x + sa * d.y, -sa * d.x + ca * d.y);
        float r = length(d);

        // PERFORMANCE: skip every pixel that is outside the element's reach. Without this each
        // pixel evaluated up to 16 elements (atan/pow/iris x3, multi-iris x8) -> heavy lag.
        bool multi = (t > 13.5 && t < 14.5) || t > 15.5;
        if (!multi && r > size * max(stretch, 1.0) * 2.6 + 0.01) { continue; }
        if (bright * uIntensity < 0.002) { continue; }

        vec3 m = vec3(0.0);
        if (t < 0.5) {                                  // Glow
            vec2 q = vec2(d.x / stretch, d.y);
            float x = length(q) / max(size, 0.001);
            float win = mix(1.0 - smoothstep(0.85, 1.0, x), 1.0 - smoothstep(0.35, 2.4, x), uReal);   // no hard disc edge
            float g = exp(-pow(x, mix(2.0, 0.85, soft)) * 4.5) * win;
            // real lens glare: hot core + long inverse-square wings (like the reference photos)
            float wing = (1.0 / (1.0 + x * x * 24.0)) * (1.0 - smoothstep(0.55, 1.0, x));
            g = mix(g, g * 0.6 + wing * 0.5, soft);
            // optical PSF: sharp airy core + 1/r^3 tail + faint far halo, warmer at the edge (dispersion)
            float psf = 1.0 / pow(1.0 + x * x * 60.0, 1.5);
            float halo = 1.0 / (1.0 + x * x * 5.0);
            float gr = g + uReal * (psf * 0.45 + halo * 0.10 * win * smoothstep(0.0, 0.6, soft + 0.3));
            m = vec3(gr) * mix(vec3(1.0), vec3(1.0, 0.93, 0.82) + vec3(0.0, 0.0, 0.18) * (1.0 - clamp(x, 0.0, 1.0)), vec3(uReal * clamp(x, 0.0, 1.0) * 0.5));
        } else if (t < 1.5 || (t > 4.5 && t < 5.5) || (t > 12.5 && t < 13.5)) {   // Polygon / Ring polygon / Iris
            float st = 0.0; float rd = 0.0; float cv = 0.0; float gr = arr[48 + i].w; float th = thick; float sf = soft;
            if (t > 12.5) { rd = arr[48 + i].x; st = arr[48 + i].y; cv = arr[48 + i].z; }
            else { th = t < 1.5 ? max(thick, 0.3) : thick; gr = 0.3; sf = 0.12; }
            vec2 q = vec2(d.x / stretch, d.y);
            float k = chroma * 0.07;
            m = vec3(irisMask(q, size * (1.0 + k), sides, rd, st, cv, th, sf, gr),
                     irisMask(q, size, sides, rd, st, cv, th, sf, gr),
                     irisMask(q, size * (1.0 - k), sides, rd, st, cv, th, sf, gr));
            if (chroma > 0.01) { m *= vec3(1.0, 0.85, 1.0); }
        } else if (t < 2.5) {                            // Line
            vec2 s = vec2(size * stretch * 0.5, size * 0.5 * max(thick, 0.01));
            vec2 qq = abs(d) - s;
            float e = 0.004 + soft * 0.03;
            m = vec3(1.0 - smoothstep(-e, e, length(max(qq, vec2(0.0))) + min(max(qq.x, qq.y), 0.0)));
        } else if (t < 3.5) {                            // Rays: thin straight beams (constant width, fading along their length)
            float n = max(rays, 2.0);
            float a = atan(d.y, d.x);
            float seg = 6.2831853 / n;
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float perp = abs(fr) * r;
            float wd = size * (0.0035 + soft * 0.012) + 0.0005;
            float beam = exp(-(perp * perp) / (wd * wd));
            float rad = (1.0 - smoothstep(0.0, size * 0.5, r)) * smoothstep(0.0, size * 0.03, r);
            m = vec3(beam * rad * 0.22 * uRayAmt);
        } else if (t < 4.5) {                            // Ring
            float R = size * 0.5;
            float w = max(thick, 0.01) * R;
            float e = 0.004 + soft * 0.02;
            float k = chroma * 0.06;
            vec3 rr = vec3(r / (1.0 + k), r, r / (1.0 - k));
            if (thick >= 0.95) { m = 1.0 - smoothstep(vec3(R * (1.0 - soft * 0.5) - e), vec3(R + e), rr); }
            else { m = 1.0 - smoothstep(vec3(w * 0.5 - e), vec3(w * 0.5 + e), abs(rr - R)); }
        } else if (t < 6.5) {                            // Dot
            float R = size * 0.5;
            m = vec3(1.0 - smoothstep(R * (1.0 - soft * 0.8), R, r));
        } else if (t < 7.5) {                            // Glint: smooth starburst
            float n = max(rays, 2.0);
            float a = atan(d.y, d.x);
            float seg = 6.28318 / n;
            float idx = glmod(floor(a / seg + 0.5), n);
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float lenv = mix(1.0, 0.6 + 0.4 * hn(idx * 3.7 + arr[64 + i].z), noise * 0.6);
            float len = size * 0.5 * lenv;
            float w = mix(0.018, 0.075, soft);
            float beam = exp(-(fr * fr) / (w * w));
            float rad = exp(-r / max(len * 0.45, 0.001)) * (1.0 - smoothstep(len * 0.55, len, r));
            float core = exp(-r / max(size * 0.05, 0.001)) * 0.7;
            vec3 gspec = 0.72 + 0.28 * cos(6.28318 * (vec3(r / max(size * 0.5, 0.001) * 3.0) + vec3(0.0, 0.33, 0.67)));
            m = vec3(beam * rad * 0.8 * uRayAmt) * mix(vec3(1.0), gspec, vec3(uReal * 0.6)) + vec3(core);
        } else if (t < 8.5) {                            // Hoop
            float R = size * 0.5;
            float w = max(thick, 0.02) * R * 0.5;
            float k = chroma * 0.07;
            vec3 rr = vec3(r / (1.0 + k), r, r / (1.0 - k));
            vec3 z = (rr - R) / w;
            m = exp(-z * z * (1.0 + (1.0 - soft) * 3.0));
        } else if (t < 9.5) {                            // Streak (anamorphic)
            float len = size * stretch * 0.5;
            float wy = size * 0.5 * max(thick, 0.01) * 0.35 + 0.002;
            float hx = exp(-abs(d.x) / max(len * (0.12 + 0.5 * soft), 0.001));
            float vy = exp(-(d.y / wy) * (d.y / wy));
            m = vec3(hx * vy * (1.0 - smoothstep(len * 0.8, len * 1.2, abs(d.x))));
        } else if (t < 10.5) {                           // Spike ball: fine smooth spikes
            float n = max(rays, 3.0) * 2.0;
            float a = atan(d.y, d.x);
            float seg = 6.28318 / n;
            float idx = glmod(floor(a / seg + 0.5), n);
            float fr = (fract(a / seg + 0.5) - 0.5) * seg;
            float lenv = mix(1.0, 0.45 + 0.55 * hn(idx * 5.3 + arr[64 + i].z), noise * 0.7);
            float len = size * 0.5 * lenv;
            float w = mix(0.012, 0.04, soft);
            float beam = exp(-(fr * fr) / (w * w));
            float rad = exp(-r / max(len * 0.4, 0.001)) * (1.0 - smoothstep(len * 0.6, len, r));
            float core = exp(-pow(r / max(size * 0.12, 0.001), 1.2) * 2.0);
            m = vec3(beam * rad * 0.6 * uRayAmt + core * 0.9);
        } else if (t < 11.5) {                           // Rainbow
            float x = r / max(size * 0.5, 0.001);
            float inner = 1.0 - thick * 0.7;
            float band = smoothstep(inner, inner + 0.12, x) * (1.0 - smoothstep(0.92, 1.0, x));
            vec3 spec = hsv2rgb(vec3(clamp((1.0 - (x - inner) / max(1.0 - inner, 0.05)) * 0.75, 0.0, 0.8), 0.9, 1.0));
            m = band * mix(vec3(1.0), spec, vec3(0.25 + 0.75 * chroma));
        } else if (t > 15.5) {                           // Lens stack: each lens has its own shape / size / tint
            int cnt = int(clamp(rays, 1.0, 8.0) + 0.5);
            vec3 mm = vec3(0.0);
            float cov = 0.0;
            float sp = arr[64 + i].w;
            for (int k = 0; k < 8; k++) {
                if (k >= cnt) { break; }
                vec4 LA = lens[(i * 8 + k) * 2];
                vec4 LB = lens[(i * 8 + k) * 2 + 1];
                vec2 dk = p - (L + ax * (pos + float(k) * sp + LA.w) + perpU * arr[96 + i].y);
                float ra = ang + radians(LB.w);
                float cr = cos(ra - ang + 0.0); float sr = sin(ra - ang);
                dk = vec2(ca * dk.x + sa * dk.y, -sa * dk.x + ca * dk.y);
                dk = vec2(cr * dk.x + sr * dk.y, -sr * dk.x + cr * dk.y);
                float szk = size * LA.y;
                int kind = int(LA.x + 0.5);
                if (length(dk) > szk * max(stretch, 1.0) * 2.6 + 0.01) { continue; }
                float kk = chroma * 0.07 + uReal * 0.008;
                vec3 mk;
                if (kk > 0.004) {
                    mk = vec3(lensMask(dk, kind, szk * (1.0 + kk), stretch, soft, arr[48 + i].w),
                                lensMask(dk, kind, szk, stretch, soft, arr[48 + i].w),
                                lensMask(dk, kind, szk * (1.0 - kk), stretch, soft, arr[48 + i].w));
                } else {
                    mk = vec3(lensMask(dk, kind, szk, stretch, soft, arr[48 + i].w));
                }
                float fb = LA.z / (1.0 + 0.1 * float(k));
                mm += mk * LB.rgb * fb;
                cov += dot(mk, vec3(0.3333)) * fb;
            }
            float gn = arr[96 + i].x;
            m = mm * (1.0 + gn * max(cov - 1.0, 0.0) * 1.8);           // light passing several lenses gets brighter
        } else if (t > 14.5) {                           // Arc: partial lens ring with colour fringe
            float R = size * 0.5;
            float w = max(thick, 0.02) * R * 0.5;
            float k = chroma * 0.07;
            vec3 rr = vec3(r / (1.0 + k), r, r / (1.0 - k));
            vec3 z = (rr - R) / w;
            float aa = atan(d.y, d.x);
            float hs = clamp(arr[64 + i].w, 0.02, 1.0) * 3.14159;
            float am = 1.0 - smoothstep(hs * (1.0 - soft), hs, abs(aa));
            m = exp(-z * z * (1.0 + (1.0 - soft) * 3.0)) * am;
        } else if (t > 13.5) {                           // Multi iris: a chain of ghost irises
            float cnt = clamp(rays, 2.0, 8.0);
            vec3 mm = vec3(0.0);
            float cov = 0.0;
            for (int k = 0; k < 8; k++) {
                float fk = float(k);
                if (fk + 0.5 > cnt) { break; }
                float h1 = hn(fk * 12.9 + arr[64 + i].z);
                float h2 = hn(fk * 7.7 + arr[64 + i].z + 3.0);
                vec2 dk = p - (L + ax * (pos + fk * arr[64 + i].w) + perpU * arr[96 + i].y);
                dk = vec2(ca * dk.x + sa * dk.y, -sa * dk.x + ca * dk.y);
                float szk = size * (1.0 - noise * 0.6 * h1) * (1.0 - 0.06 * fk);
                float mk = irisMask(vec2(dk.x / stretch, dk.y), szk, sides, arr[48 + i].x, arr[48 + i].y, arr[48 + i].z,
                                    max(thick, 0.05), soft, arr[48 + i].w);
                vec3 spec = hsv2rgb(vec3(fract(0.08 + fk * 0.17 + h2 * 0.1), 0.65, 1.0));
                vec3 tk = mix(vec3(1.0), spec, vec3(chroma * 0.9));
                float fbk = (0.55 + 0.45 * h2) / (1.0 + 0.12 * fk);
                mm += mk * tk * fbk;
                cov += mk * fbk;
            }
            m = mm * (1.0 + arr[96 + i].x * max(cov - 1.0, 0.0) * 1.8);     // overlapping lenses: brighter
        } else {                                         // Shimmer
            float x = r / max(size, 0.001);
            float a = atan(d.y, d.x);
            float g = exp(-pow(x, 1.2) * 3.5) * (1.0 - smoothstep(0.9, 1.0, x));
            float nz = vn(a * rays * 0.35 + 20.0 + uTime * uSpeed * 1.2) * 0.7
                     + vn(a * rays * 0.9 + uTime * uSpeed * 2.3) * 0.5;
            m = vec3(g * (0.45 + nz * 1.1 * (0.25 + noise)));
        }

        bool ghost = (t > 0.5 && t < 1.5) || (t > 3.5 && t < 5.5) || (t > 7.5 && t < 8.5) || (t > 12.5);
        if (ghost && uReal > 0.0) {
            vec2 d0 = p - (L + ax * pos + perpU * arr[96 + i].y);
            float dl = max(length(d0), 0.0001);
            float facing = dot(d0 / dl, -ax / max(axLen, 0.0001));           // side of the ghost facing the light
            float dirG = mix(1.0, 0.62 + 0.76 * (facing * 0.5 + 0.5), uReal * 0.7);
            float dz = fbm2(d0 / max(size, 0.05) * 3.2 + float(i) * 7.1);
            float dustM = 1.0 - uDust * uReal * smoothstep(0.38, 0.85, dz) * 0.8;
            float scr = vn2(vec2(atan(d0.y, d0.x) * 14.0, dl / max(size, 0.05) * 1.5) + float(i));    // micro-scratches
            dustM *= 1.0 - uDust * uReal * 0.35 * smoothstep(0.7, 1.0, scr);
            m *= dirG * dustM;
        }
        float fl = 1.0 + uFlicker * (vn(uTime * uSpeed * 9.0 + float(i) * 3.1) - 0.5) * 0.7;
        acc += arr[80 + i].rgb * uTintRgb * m * bright * fl;
    }

    // the whole flare fades as the light leaves the frame
    vec2 lp = uLight;
    float outside = max(max(-lp.x, lp.x - 1.0), max(-lp.y, lp.y - 1.0));
    outside = max(outside - 0.12, 0.0);                 // never fades while the light is on or near the frame
    float vis = 1.0 - smoothstep(0.0, max(uEdgeFade, 0.05) + 0.25, outside);
    // veiling glare: faint haze that lifts the blacks around the light (stray light in the barrel)
    float vl = length(p - L);
    vec3 veilCol = (arr[0].x > -0.5 ? arr[80].rgb : vec3(1.0)) * uTintRgb;
    acc += veilCol * uVeil * uReal * (1.0 / (1.0 + vl * vl * 9.0)) * 0.22 * step(0.5, uCount);
    acc = clamp(acc, vec3(0.0), vec3(60.0)) * uIntensity * vis * seen;

    // soft highlight roll-off keeps hot colours from clipping to flat white
    vec3 o = vec3(1.0) - exp(-acc * 1.1);
    float lum = max(o.r, max(o.g, o.b));
    o = mix(o, vec3(lum), vec3(smoothstep(0.55, 1.0, lum) * mix(0.45, 0.7, uReal)));
    o = mix(o, o + o * o * o * 0.18, vec3(uReal));                      // film shoulder: hot highlights bloom   // hot cores bleed to white like film
    o = min(o, vec3(1.0));
    float dn = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)))) - 0.5;
    o = max(o + dn * (1.0 / 255.0) * step(vec3(0.002), o), vec3(0.0));
    outColor = vec4(o, max(o.r, max(o.g, o.b)));
}

