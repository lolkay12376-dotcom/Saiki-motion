#version 450
// PORT-OF: msl/MetalSL.passes.msl::fsVertex   (stamp with tools/shader_sync_check.py --stamp)
// MSL-SHA256: 3d03b5595714ddb6
// Fullscreen triangle. Vulkan viewport MUST use negative height (y flipped) so NDC is y-up like Metal;
// then this file and every fragment shader keep Metal's exact math (flipV, gl_FragCoord == in.pos).
layout(location = 0) out vec2 vUv;
void main() {
    vec2 p = vec2(gl_VertexIndex == 1 ? 3.0 : -1.0, gl_VertexIndex == 2 ? 3.0 : -1.0);
    gl_Position = vec4(p, 0.0, 1.0);
    vUv = p * 0.5 + 0.5;
}
