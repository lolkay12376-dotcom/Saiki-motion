#version 450
// PORT-OF: msl/MetalGlowSL.source.msl::glowBlur
// MSL-SHA256: effbcdca4dbd18bf
// Bindings: textures set0 b0.., uniform block set0 b8 (MSL buffer(0)). linearClamp == sampler2D.
layout(location = 0) in vec2 vUv;
layout(location = 0) out vec4 outColor;
vec2 flipV(vec2 uv) { return vec2(uv.x, 1.0 - uv.y); }
layout(set = 0, binding = 0) uniform sampler2D t;
layout(std140, set = 0, binding = 8) uniform GlowBlurU { vec2 st; } u;
void main() {
    vec2 v = vUv; vec2 st = u.st;
    vec4 c = texture(t, flipV(v)) * 0.2270270270;
    c += (texture(t, flipV(v + st * 1.3846153846)) + texture(t, flipV(v - st * 1.3846153846))) * 0.3162162162;
    c += (texture(t, flipV(v + st * 3.2307692308)) + texture(t, flipV(v - st * 3.2307692308))) * 0.0702702703;
    outColor = c;
}
