#version 450
// PORT-OF: msl/MetalGlowSL.source.msl::glowExtract
// MSL-SHA256: effbcdca4dbd18bf
// Bindings: textures set0 b0.., uniform block set0 b8 (MSL buffer(0)). linearClamp == sampler2D.
layout(location = 0) in vec2 vUv;
layout(location = 0) out vec4 outColor;
vec2 flipV(vec2 uv) { return vec2(uv.x, 1.0 - uv.y); }
layout(set = 0, binding = 0) uniform sampler2D t;
layout(std140, set = 0, binding = 8) uniform GlowExtractU { vec2 px; float thr; float knee; } u;
vec4 glowTap(vec2 uv, float thr, float knee0) {
    vec4 c = min(texture(t, flipV(uv)), vec4(16.0));
    float l = max(max(c.r, c.g), c.b);
    float knee = thr * knee0 + 0.0001;
    float sf = clamp(l - thr + knee, 0.0, 2.0 * knee);
    sf = sf * sf / (4.0 * knee);
    float k = max(sf, l - thr) / max(l, 0.0001);
    return c * clamp(k, 0.0, 1.0);
}
void main() {
    vec2 o = u.px * 0.5;
    vec2 v = vUv;
    vec4 a = glowTap(v + vec2(-o.x, -o.y), u.thr, u.knee) + glowTap(v + vec2(o.x, -o.y), u.thr, u.knee)
           + glowTap(v + vec2(-o.x, o.y), u.thr, u.knee) + glowTap(v + vec2(o.x, o.y), u.thr, u.knee);
    outColor = a * 0.25;
}
