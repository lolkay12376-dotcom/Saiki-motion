#version 450
// PORT-OF: msl/MetalGlowSL.source.msl::glowFinal
// MSL-SHA256: effbcdca4dbd18bf
// Bindings: textures set0 b0.., uniform block set0 b8 (MSL buffer(0)). linearClamp == sampler2D.
layout(location = 0) in vec2 vUv;
layout(location = 0) out vec4 outColor;
vec2 flipV(vec2 uv) { return vec2(uv.x, 1.0 - uv.y); }
layout(set = 0, binding = 0) uniform sampler2D tex;
layout(set = 0, binding = 1) uniform sampler2D tg;
layout(std140, set = 0, binding = 8) uniform GlowFinalU { vec4 tint; float gain; float chroma; float only; float tintAmt; vec2 res; vec2 pad; } u;
bool glowBad(float x) { return (floatBitsToUint(x) & 0x7fffffffu) > 0x7f800000u; }
void main() {
    vec2 vUvv = vUv;
    vec4 c = texture(tex, flipV(vUvv));
    vec4 g = texture(tg, flipV(vUvv));
    if (u.chroma > 0.001) {
        vec2 dir = (vUvv - 0.5) * u.chroma * 0.04;
        g.r = texture(tg, flipV(vUvv + dir)).r;
        g.b = texture(tg, flipV(vUvv - dir)).b;
    }
    g = clamp(g * u.gain, 0.0, 64.0);
    if (glowBad(g.r) || glowBad(g.g) || glowBad(g.b) || glowBad(g.a)) { g = vec4(0.0); }
    float gl = max(g.r, max(g.g, g.b));
    g.rgb = mix(g.rgb, u.tint.rgb * gl, u.tintAmt);
    vec3 add = g.rgb / (1.0 + g.rgb * 0.18);
    add += vec3(smoothstep(0.5, 3.0, gl) * 0.22 * gl);   // hot core: strong glow whitens toward the centre
    vec2 fc = vec2(gl_FragCoord.x, u.res.y - gl_FragCoord.y);          // GL-style fragment coordinate (gl_FragCoord == MSL in.pos, negative-height viewport)
    float n = fract(52.9829189 * fract(dot(fc, vec2(0.06711056, 0.00583715)))) - 0.5;
    add += n * (1.0 / 255.0) * min(1.0, g.a * 4.0);
    add = max(add, 0.0);
    float base = u.only > 0.5 ? 0.0 : 1.0;
    vec3 rgb = c.rgb * base + add;
    // halo alpha follows the added light only (never the blurred coverage): over-blending with alpha > light darkened the background
    float ga = clamp(min(add.r, min(add.g, add.b)), 0.0, 1.0);
    float a = clamp(c.a * base + ga * (1.0 - c.a * base), 0.0, 1.0);
    outColor = vec4(rgb, a);
}
