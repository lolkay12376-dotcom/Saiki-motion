#version 450
// PORT-OF: msl/MetalGlowSL.source.msl::glowScale
// MSL-SHA256: effbcdca4dbd18bf
// Bindings: textures set0 b0.., uniform block set0 b8 (MSL buffer(0)). linearClamp == sampler2D.
layout(location = 0) in vec2 vUv;
layout(location = 0) out vec4 outColor;
vec2 flipV(vec2 uv) { return vec2(uv.x, 1.0 - uv.y); }
layout(set = 0, binding = 0) uniform sampler2D a;
layout(std140, set = 0, binding = 8) uniform GlowScaleU { float w; } u;
void main() { outColor = texture(a, flipV(vUv)) * u.w; }
