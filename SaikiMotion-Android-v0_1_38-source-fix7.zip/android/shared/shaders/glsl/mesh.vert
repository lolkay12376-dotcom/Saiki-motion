#version 450
// PORT-OF: msl/MetalSceneSL.source.msl::meshVertex
// MSL-SHA256: 14940cf710527ec6
// Bindings: set0 b8 UBO QuadU (MSL buffer(0)); tex b0 (linear clamp); mpos/muv SSBOs b1/b2 (vec2[]).
layout(location = 0) out vec2 oUv;
layout(location = 1) out vec2 oLc;
layout(std140, set = 0, binding = 8) uniform QuadU {
    vec4 color;     // uColor
    vec4 abcd;      // uMat: a b c d  (Xf affine [a b c d tx ty])
    vec2 t;         // uMat: tx ty
    vec2 quad;      // uQuad (also the shape size)
    float aspect;   // uAspect
    float flipY;    // uFlipY
    float kind;     // uKind
    float corner;   // uCornerRadius
    vec4 rot3;      // 3D: x = uRot.x, y = uRot.y, z = uZ, w = uInvCam
    vec4 flags;     // 3D: x = uUseVP, y = 3D path on (else the exact 2D path)
    vec4 vp0; vec4 vp1; vec4 vp2; vec4 vp3;   // uVP columns (GL column-major)
    vec4 gradP;     // shape gradient knobs x1 y1 x2 y2 (quad space)
    vec4 gradC;     // gradient end colour
    vec4 gradM;     // x = mode (0 off, 1 linear, 2 radial)
} u;
layout(std430, set = 0, binding = 1) readonly buffer MPos { vec2 mpos[]; };
layout(std430, set = 0, binding = 2) readonly buffer MUv { vec2 muv[]; };
float glmod(float x, float y) { return x - y * floor(x / y); }

// Port of the GL layerQuadVertex tail: 3D rotation about the layer centre, then camera VP or the
// default z=3 perspective. flags.y = 0 keeps the untouched 2D position.
vec4 clipPos(vec2 w) {
    if (u.flags.y < 0.5) { return vec4(w.x / u.aspect, w.y, 0.0, 1.0); }
    vec2 c = u.t;
    vec3 o = vec3(w - c, 0.0);
    float cy = cos(u.rot3.y), sy = sin(u.rot3.y);
    o = vec3(o.x * cy + o.z * sy, o.y, -o.x * sy + o.z * cy);
    float cx = cos(u.rot3.x), sx = sin(u.rot3.x);
    o = vec3(o.x, o.y * cx - o.z * sx, o.y * sx + o.z * cx);
    vec3 pos = vec3(c + o.xy, o.z + u.rot3.z);
    if (u.flags.x > 0.5) {
        vec4 cl = u.vp0 * pos.x + u.vp1 * pos.y + u.vp2 * pos.z + u.vp3;
        if (cl.w < 0.02) { return vec4(2.0, 2.0, 0.0, 1.0); }
        return vec4(cl.x, cl.y, 0.0, cl.w);
    }
    return vec4(pos.x / u.aspect, pos.y, 0.0, 1.0 - pos.z * u.rot3.w);
}
// Puppet mesh: vertices come from two device buffers (expanded triangle list). pos is the deformed
// quad-space position in [-1,1] (same as GL aPos), uvs the rest uv (uv.y up, like the GL aUv).
void main() {
    uint vid = uint(gl_VertexIndex);
    vec2 pu = mpos[vid] * 0.5 + 0.5;
    vec2 lc = (pu - 0.5) * u.quad;
    vec2 w = vec2(u.abcd.x * lc.x + u.abcd.z * lc.y + u.t.x,
                  u.abcd.y * lc.x + u.abcd.w * lc.y + u.t.y);
    gl_Position = clipPos(w);
    oUv = muv[vid];
    oLc = lc;
}
