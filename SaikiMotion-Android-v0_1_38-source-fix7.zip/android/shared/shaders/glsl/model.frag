#version 450
// PORT-OF: msl/MetalModelSL.source.msl::modelFragment
// MSL-SHA256: 41eb491ce2bab9b4
#ifdef SAIKI_RT
#extension GL_EXT_ray_query : require
#endif
// Bindings (set0): MSL texture(n) -> binding n (arrays: first index); UBO ModelU b32 (buffer(0)); UBO LBuf b33 (buffer(5)).
// RT variant (-DSAIKI_RT): acc b36, UBO RtU b37. Samplers: per-texture combined sampler states as noted (constexpr sP/sT/sW/ls/ns in MSL).
// sP = linear+mip linear+REPEAT+maxAnisotropy 8, sT = same, sW/ls/rs = linear clamp, ns/rn = nearest clamp.
layout(location = 0) in vec3 vN;
layout(location = 1) in vec3 vW;
layout(location = 2) in vec2 vUv;
layout(location = 3) in vec4 vCol;
layout(location = 0) out vec4 outColor;
layout(std140, set = 0, binding = 32) uniform ModelU {
    vec4 vp0; vec4 vp1; vec4 vp2; vec4 vp3;     // uVP columns
    vec4 m0; vec4 m1; vec4 m2; vec4 m3;         // uModel columns
    vec4 color;     // uColor
    vec4 emis;      // uEmis.xyz
    vec4 eye;       // uEye.xyz
    vec4 prm;       // metal, rough, cutoff, unlit
    vec4 has;       // base, metal-rough, emissive, occlusion texture present
    vec4 opt;       // env, metallic reflectivity, view mode, ao strength
    vec4 xtra;      // exposure, rt ao, rt shadow, pbr bump strength
    vec4 lp0; vec4 lp1; vec4 lp2;     // scene point lights: world pos
    vec4 lc0; vec4 lc1; vec4 lc2;     // rgb * intensity (w = 1 when active)
    vec4 pg;        // procedural pbr: on, parallax depth, uv scale x, uv scale y
    vec4 wa;        // water: on, time, wave height, wave frequency
    vec4 wb;        // water: speed, foam, depth, choppiness
    vec4 wc;        // water: clarity, turbidity, refraction, subsurface
    vec4 wd;        // water: glint, detail, flow dir (rad), procedural seabed
    vec4 we;        // water: wave variation, swell, swell length, whitecaps
    vec4 wf;        // water: base y, reflect, scene depth available, rays
    vec4 wg;        // water rays: strength, length, sharpness, speed
    vec4 wh;        // water collision: rocks, shores, foam width, 0
    vec4 wi;        // water colours: shallow rgb, custom on
    vec4 wj;        // water colours: middle rgb, stop count (2 or 3)
    vec4 wk;        // water colours: deep rgb, gradient mode (0 depth, 1 bands, 2 patches)
    vec4 wl;        // water colours: gradient scale
    vec4 envp;      // HDRI environment: on, rotation (turns), max mip, gain
    vec4 sp0;       // terrain splat: on, layer count, 0, 0
    vec4 sp1;       // splat tiling per layer
    vec4 sp2;       // splat normal strength per layer
    vec4 pm;        // imported PBR maps: normal, roughness, metallic, height present
    vec4 pn;        // opacity map present, normal strength, normal Y sign, displacement amount (world units)
    vec4 pt;        // texture tiling u, v, parallax depth, height mid-point
    vec4 xr;        // x-ray view (editor preview only): on, rim power, base opacity, 0
    vec4 pq;        // roughness multiplier, metallic multiplier, emissive strength, maps on
    vec4 pr;        // clear coat, clear coat roughness, AO strength
    vec4 pnm;       // embedded (per-material) normal map: on, strength, green sign, 0
    vec4 ptc;       // point map: size px (0 = not a point map), anim mode, anim amount, time
} u;
layout(set = 0, binding = 0) uniform sampler2D tBase;   // sBase (per-material sampler state, set by the app)
layout(set = 0, binding = 1) uniform sampler2D tMR;     // sMR
layout(set = 0, binding = 2) uniform sampler2D tEm;     // sEm
layout(set = 0, binding = 3) uniform sampler2D tOcc;    // sOcc
layout(set = 0, binding = 4) uniform sampler2D tSD;     // depth, NEAREST clamp, read as .r
layout(set = 0, binding = 5) uniform sampler2D tScene;  // linear clamp
layout(set = 0, binding = 6) uniform sampler2D tEnv;    // linear + mip linear + REPEAT
layout(set = 0, binding = 7) uniform sampler2D tD[4];   // splat diffuse   (sT: linear+mip+REPEAT+aniso8)
layout(set = 0, binding = 11) uniform sampler2D tN[4];  // splat normal+AO (sT)
layout(set = 0, binding = 15) uniform sampler2D tR[4];  // splat height/rough/metal (sT)
layout(set = 0, binding = 19) uniform sampler2D tW0;    // splat weights (sW: linear clamp)
layout(set = 0, binding = 20) uniform sampler2D tW1;    // sW
layout(set = 0, binding = 21) uniform sampler2D tPN;    // sP: linear+mip+REPEAT+aniso8
layout(set = 0, binding = 22) uniform sampler2D tPR;    // sP
layout(set = 0, binding = 23) uniform sampler2D tPM;    // sP
layout(set = 0, binding = 24) uniform sampler2D tPH2;   // sP
layout(set = 0, binding = 25) uniform sampler2D tPO;    // sP
layout(std140, set = 0, binding = 33) uniform LBuf { vec4 LB[64]; };   // MSL buffer(5): 8 lights x 8 float4
#ifdef SAIKI_RT
// Ray-traced variant (iOS modelFragmentRT): compile with -DSAIKI_RT. Needs GL_EXT_ray_query (VK_KHR_ray_query).
layout(set = 0, binding = 36) uniform accelerationStructureEXT acc;
layout(std140, set = 0, binding = 37) uniform RtU { vec4 rtp; mat4 rinv; } rt;   // MSL buffer(3) rtp, buffer(4) rinv
// Soft shadow: n rays toward a disc light (position) or a cone around a direction (sun), rotated per pixel. Returns visibility 0...1.
// (any-hit termination: only hit existence is used, same result as Metal's closest-hit intersect.)
float rtSoftVis(vec3 Pw, vec3 tgt, bool isDir, float rad, int n, float rn, float sc) {
    vec3 d0 = isDir ? normalize(tgt) : normalize(tgt - Pw);
    vec3 T = normalize(abs(d0.y) < 0.9 ? cross(d0, vec3(0.0, 1.0, 0.0)) : cross(d0, vec3(1.0, 0.0, 0.0)));
    vec3 B = cross(d0, T);
    float hits = 0.0;
    for (int k = 0; k < n; k++) {
        float a = (float(k) + rn) * 2.3999632;
        float rr = sqrt((float(k) + 0.5) / float(n));
        vec2 o = vec2(cos(a), sin(a)) * rr * rad;
        vec3 dw; float tmax;
        if (isDir) { dw = normalize(d0 + (T * o.x + B * o.y)); tmax = 1.0e4; }
        else { vec3 tp = tgt + (T * o.x + B * o.y); dw = normalize(tp - Pw); tmax = max(length(tp - Pw) - 0.02, 0.01) * sc; }
        rayQueryEXT rq;
        rayQueryInitializeEXT(rq, acc, gl_RayFlagsOpaqueEXT | gl_RayFlagsTerminateOnFirstHitEXT, 0xFF, (rt.rinv * vec4(Pw, 1.0)).xyz, 0.0005 * sc, normalize((rt.rinv * vec4(dw, 0.0)).xyz), tmax);
        while (rayQueryProceedEXT(rq)) {}
        if (rayQueryGetIntersectionTypeEXT(rq, true) != gl_RayQueryCommittedIntersectionNoneEXT) { hits += 1.0; }
    }
    return 1.0 - hits / float(n);
}
#endif
float mHash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float mVn(vec2 p) {
    vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mHash(i), mHash(i + vec2(1.0, 0.0)), f.x), mix(mHash(i + vec2(0.0, 1.0)), mHash(i + vec2(1.0, 1.0)), f.x), f.y);
}
// Sharpened sine waves (Gerstner-like crests). Directions, frequencies and phases are jittered and domain-warped,
// amplitude is modulated at a large scale, so the pattern never visibly tiles. Returns height, gradient in g.
vec2 mH2(vec2 p) { return vec2(mHash(p), mHash(p + 17.3)); }
float wCell(vec2 p) {      // cellular distance: bubble walls
    vec2 i = floor(p), f = fract(p); float m = 8.0;
    for (int y = -1; y <= 1; y++) { for (int x = -1; x <= 1; x++) {
        vec2 g = vec2(float(x), float(y)); vec2 r = g + mH2(i + g) * 0.9 - f; m = min(m, dot(r, r)); } }
    return sqrt(m);
}
float wFoamT(vec2 p, float tt) {      // lacy foam: warped streaks + two scales of bubble walls
    vec2 wv = vec2(mVn(p * 1.3 + tt * 0.15), mVn(p * 1.3 + 9.0 - tt * 0.12)) - 0.5;
    p += wv * 1.3;
    float f = mVn(p * 2.0) * 0.45 + mVn(p * 5.0 + 3.0) * 0.3 + mVn(p * 12.0) * 0.25;
    float b1 = smoothstep(0.18, 0.62, wCell(p * 8.0 + tt * 0.06));
    float b2 = mVn(p * 31.0 - tt * 0.05 + 5.0);
    return smoothstep(0.22, 0.8, f * 0.5 + b1 * 0.35 + b2 * 0.2);
}
float wBeam(vec2 sp, float t, float wid) {      // sunbeams that pass through the moving surface
    float pat = mVn(sp * 1.1 + t * 0.25) * 0.65 + mVn(sp * 2.7 - t * 0.35 + 8.0) * 0.35;
    return pow(clamp(pat * 1.7 - 0.45, 0.0, 1.0), mix(1.2, 4.0, clamp(wid * 0.5, 0.0, 1.0)));
}
float wMean(float k) { float k2 = k * k; return exp(-k) * (1.0 + k2 * (0.25 + k2 * (0.015625 + k2 * (0.000434 + k2 * 0.0000068)))); }      // mean of exp((sin-1)k)
float wvH(vec2 p, float t, float amp, float freq, float spd, float chop, float dirA, float vari, vec2 sw, int nw, out vec2 g) {
    float k = mix(0.7, 2.6, chop);
    float zone = mix(0.6, 1.4, mVn(p * 0.03 + 19.0));      // calm / rough areas: far water differs from near water
    float am = mix(1.0, 0.45 + 1.1 * mVn(p * 0.09 + 7.0), vari);
    float wph = (mVn(p * 0.17 + 3.0) - 0.5) * 3.0 * vari;
    float h = 0.0, a = amp * am, f = freq, w = 1.0;
    g = vec2(0.0);
    for (int i = 0; i < nw; i++) {
        float fi = float(i);
        float ang = dirA + fi * 0.83 + sin(fi * 5.1 + 1.0) * 0.7 * (0.4 + vari);
        vec2 d = vec2(cos(ang), sin(ang));
        float fr = f * (1.0 + 0.21 * sin(fi * 7.3));
        float ph = dot(d, p) * fr + t * spd * w * 1.6 + fi * 1.7 + wph * (0.4 + 0.3 * fi);
        float e = exp((sin(ph) - 1.0) * k);
        h += a * (e - wMean(k));
        g += a * e * k * cos(ph) * fr * d;
        a *= 0.58; f *= 1.8; w *= 1.2;
    }
    for (int j = 0; j < 3; j++) {      // long rounded swells on their own headings
        float fj = float(j);
        float ang = dirA + 2.1 + fj * 1.9;
        vec2 d = vec2(cos(ang), sin(ang));
        float fr = freq * sw.y * (1.0 + 0.45 * fj);
        float ph = dot(d, p) * fr + t * spd * (0.8 + 0.25 * fj) + fj * 2.3 + wph * 0.5;
        float e = exp((sin(ph) - 1.0) * 0.9);
        float sa = amp * sw.x * zone * (1.0 - 0.25 * fj) * 2.2;
        h += sa * (e - 0.4934);
        g += sa * e * 0.9 * cos(ph) * fr * d;
    }
    return h;
}
const float mPI = 3.14159265;
const vec3 mL1 = vec3(0.4170, 0.6672, 0.6672);
const vec3 mL2 = vec3(-0.8704, 0.2176, 0.4352);

vec3 mEnv(vec3 d, float r) {
    float h = d.y * 0.5 + 0.5;
    vec3 c = mix(vec3(0.14, 0.13, 0.15), vec3(0.78, 0.80, 0.84), smoothstep(0.0, 0.5, h));
    c = mix(c, vec3(0.55, 0.68, 0.95), smoothstep(0.5, 1.0, h));
    float sun = pow(max(dot(d, mL1), 0.0), mix(150.0, 5.0, r)) * mix(8.0, 0.6, r);
    return c + vec3(1.0, 0.93, 0.82) * sun;
}

vec3 mEnvT(vec3 d, float r, sampler2D t, vec4 ep) {   // tEnv: linear + mip linear + REPEAT
    if (ep.x < 0.5) { return mEnv(d, r); }
    float uu = atan(d.z, d.x) * 0.15915494 + 0.5 + ep.y;
    float v = 0.5 - asin(clamp(d.y, -1.0, 1.0)) * 0.31830989;
    vec3 c = textureLod(t, vec2(uu, v), sqrt(r) * ep.z).rgb;
    return min(max(c, vec3(0.0)), vec3(40.0)) * ep.w;
}

vec3 mBrdf(vec3 N, vec3 V, vec3 L, vec3 diffC, vec3 F0, float r) {
    vec3 H = normalize(V + L);
    float NdL = max(dot(N, L), 0.0);
    float NdV = max(dot(N, V), 0.001);
    float NdH = max(dot(N, H), 0.0);
    float VdH = max(dot(V, H), 0.0);
    float a = r * r;
    float a2 = a * a;
    float dd = NdH * NdH * (a2 - 1.0) + 1.0;
    float D = a2 / (mPI * dd * dd + 0.0001);
    float Vis = 0.5 / max(NdL * sqrt(NdV * NdV * (1.0 - a2) + a2) + NdV * sqrt(NdL * NdL * (1.0 - a2) + a2), 1e-4);      // height-correlated Smith GGX
    vec3 F = F0 + (1.0 - F0) * pow(1.0 - VdH, 5.0);
    vec3 spec = D * Vis * F;
    return ((1.0 - F) * diffC / mPI + spec) * NdL;
}

float mLin(float d) { return 1000.0 / (10000.05 - (2.0 * d - 1.0) * 9999.95); }      // depth buffer -> view distance (near 0.05, far 10000)
vec3 wAbsorb() { return vec3(0.45, 0.09, 0.05) * mix(3.0, 0.4, u.wc.x) + u.wc.y * 0.5; }      // per metre
float wCaus(vec2 sq, float tt) {
    float c1 = mVn(sq * 1.6 + vec2(tt * 0.5, tt * 0.3)), c2 = mVn(sq * 2.1 - vec2(tt * 0.4, -tt * 0.55) + 5.0);
    return pow(clamp(1.0 - abs(c1 - c2) * 3.4, 0.0, 1.0), 7.0);
}
vec3 wFog(float depthCam) {      // display-space colour of the water column; darker the deeper the camera
    float k = 1.0 - exp(-depthCam * 0.15);
    if (u.wi.w > 0.5) {      // custom water colours: the underwater fog fades from the shallow colour to the deep colour
        vec3 mid = u.wj.w > 2.5 ? u.wj.rgb : mix(u.wi.rgb, u.wk.rgb, 0.5);
        vec3 fc = k < 0.5 ? mix(u.wi.rgb, mid, k * 2.0) : mix(mid, u.wk.rgb, k * 2.0 - 1.0);
        return fc * mix(0.65, 0.2, k);
    }
    vec3 base = mix(vec3(0.10, 0.45, 0.48), vec3(0.01, 0.06, 0.11), k);
    float cmx = max(u.color.r, max(u.color.g, u.color.b)), cmn = min(u.color.r, min(u.color.g, u.color.b));
    if (cmx - cmn > 0.05) { return dot(base, vec3(0.3, 0.6, 0.1)) * 1.8 * (u.color.rgb / max(cmx, 1e-3)); }      // a tinted layer colour recolours the water, not just darkens the blue
    return base;
}
float mLightAtt(vec4 LA, vec4 LC, vec4 LD, vec4 LE, vec3 wp, out vec3 Ld) {
    float att = 2.0;
    if (LA.w > 0.5 && LA.w < 1.5) { Ld = -normalize(LD.xyz); return att; }
    vec3 Lv = LA.xyz - wp; float d2 = dot(Lv, Lv);
    Ld = Lv * inversesqrt(max(d2, 1e-6));
    att = LC.w < -0.5 ? 0.6 : 2.5 / (d2 + 0.3);
    if (LC.w > 0.001) { float rr = d2 / (LC.w * LC.w); float wnd = clamp(1.0 - rr * rr, 0.0, 1.0); att *= wnd * wnd; }
    if (LA.w > 1.5) { att *= smoothstep(LD.w, max(LE.x, LD.w + 0.001), dot(-Ld, normalize(LD.xyz))); }
    return att;
}

// Multi-colour light: up to 3 colour stops blended by cone angle / distance (mode 0), around the axis (1) or world height (2).
vec3 mLightCol(int i, vec3 wp) {
    vec4 LA = LB[i * 8], LC = LB[i * 8 + 1], LD = LB[i * 8 + 2], LX = LB[i * 8 + 4], LY = LB[i * 8 + 5], LZ = LB[i * 8 + 6];
    int nc = int(LX.w + 0.5);
    vec3 c1 = LC.rgb, c2 = LX.rgb, c3 = LY.rgb;
    if (nc < 2) { return c1; }
    int mode = int(LZ.x + 0.5);
    float span = max(LZ.y, 0.05);
    vec3 Lv = wp - LA.xyz;
    float d = max(length(Lv), 1e-4);
    vec3 ax = LA.w > 0.5 ? normalize(LD.xyz) : vec3(0.0, -1.0, 0.0);
    float t = 0.0;
    if (mode == 0) {
        if (LA.w > 1.5) { t = acos(clamp(dot(Lv / d, ax), -1.0, 1.0)) / max(acos(clamp(LD.w, -1.0, 1.0)), 0.05); }
        else if (LA.w > 0.5) { t = dot(Lv, ax) / span; }
        else { t = d / span; }
    } else if (mode == 1) {
        vec3 a = normalize(abs(ax.y) < 0.99 ? cross(ax, vec3(0.0, 1.0, 0.0)) : cross(ax, vec3(1.0, 0.0, 0.0)));
        vec3 b = cross(ax, a);
        t = fract(atan(dot(Lv, b), dot(Lv, a)) / 6.2831853 + 0.5);
    } else {
        t = wp.y / span + 0.5;
    }
    bool wrap = mode == 1;
    float tt = wrap ? t : clamp(t, 0.0, 1.0);
    if (nc == 2) { return wrap ? mix(c1, c2, 0.5 - 0.5 * cos(tt * 6.2831853)) : mix(c1, c2, tt); }
    if (wrap) {
        float s = tt * 3.0;
        int k = min(int(floor(s)), 2);
        float f = s - float(k); f = f * f * (3.0 - 2.0 * f);
        vec3 a = k == 0 ? c1 : (k == 1 ? c2 : c3);
        vec3 b = k == 0 ? c2 : (k == 1 ? c3 : c1);
        return mix(a, b, f);
    }
    float s = tt * 2.0;
    return s < 1.0 ? mix(c1, c2, s) : mix(c2, c3, s - 1.0);
}
void main() {
    vec2 uv = vUv;
    if (u.pg.x > 0.5) {      // procedural pbr: tile density follows the layer scale, slow domain warp hides repetition
        uv *= u.pg.zw;
        vec2 q = uv * 0.37;
        uv += (vec2(mVn(q + 11.0), mVn(q + 37.0)) - 0.5) * 0.5;
    }
    bool pmOn = u.pq.w > 0.5;
    if (pmOn) { uv *= u.pt.xy; }
    vec2 gx = dFdx(uv), gy = dFdy(uv);
    vec3 N = normalize(vN);
    vec3 V = normalize(u.eye.xyz - vW);
    if (dot(N, V) < 0.0) { N = -N; }
    float nlt = u.lc0.w + u.lc1.w + u.lc2.w + u.pr.w;
    float sunK = nlt > 0.5 ? 0.2 : 1.0;      // scene lights replace the default studio sun / env instead of drowning in it
    float envK = nlt > 0.5 ? 0.45 : 1.0;
    if (u.wa.x > 0.5) {      // water
        float flow = u.wd.z;
        vec2 g; float h = wvH(vW.xz, u.wa.y, u.wa.z, u.wa.w, u.wb.x, u.wb.w, flow, u.we.x, u.we.yz, 6, g);
        float tt = u.wa.y * u.wb.x;
        float dist = length(u.eye.xyz - vW);
        vec2 g4; float h4 = wvH(vW.xz, u.wa.y, u.wa.z, u.wa.w, u.wb.x, u.wb.w, flow, u.we.x, u.we.yz, 4, g4);      // the mesh itself is displaced with 4 octaves
        float baseY = vW.y - h4;      // true rest level (was off by the 6-octave detail, which flipped the "camera below" test)
        bool under = u.eye.y < baseY - 0.002;
        float pf = length(fwidth(vW));
        float fadeD = 1.0 / (1.0 + pf * u.wa.w * 14.0);      // fine detail fades with pixel footprint: no shimmer in the distance
        float zone = mVn(vW.xz * 0.045 + 11.0);
        vec2 q = vW.xz * u.wa.w * 3.0;
        vec2 cf = vec2(cos(flow), sin(flow));
        vec2 qa = q + cf * tt * 0.9 + (vec2(mVn(q * 0.23 + 3.0), mVn(q * 0.23 + 9.0)) - 0.5) * 2.5;
        vec2 qb = q * 1.73 + vec2(-cf.y, cf.x) * tt * 0.7 + 17.0;
        vec2 rp = vec2(mVn(qa) - mVn(qa + vec2(0.7, 1.9)), mVn(qa.yx * 1.1 + 5.0) - mVn(qa.yx * 1.1 + vec2(2.1, 0.4)));
        rp += 0.6 * vec2(mVn(qb) - mVn(qb + vec2(1.3, 0.2)), mVn(qb.yx) - mVn(qb.yx + vec2(0.5, 1.1)));
        g += rp * u.wa.z * u.wa.w * 0.5 * u.wd.y * fadeD * mix(0.5, 1.4, zone);
        vec3 Nw = normalize(vec3(-g.x, 1.0, -g.y));
        Nw = normalize(mix(vec3(0.0, 1.0, 0.0), Nw, mix(0.4, 1.0, fadeD)));
        if (dot(Nw, V) < 0.0) { Nw = -Nw; }
        float nlt2 = u.lc0.w + u.lc1.w + u.lc2.w;
        if (under) {      // looking up at the surface from inside the water: Snell's window + total internal reflection
            float depthCam = max(baseY - u.eye.y, 0.0);
            vec3 fogL = pow(wFog(depthCam), vec3(2.2));
            vec3 Ru = refract(-V, Nw, 1.333);
            float tir = dot(Ru, Ru) < 1e-4 ? 1.0 : 0.0;
            vec3 sky = mEnvT(normalize(Ru + vec3(0.0, 1e-4, 0.0)), 0.15, tEnv, u.envp) * u.emis.w * envK * exp(-depthCam * 0.05);
            vec3 c = mix(sky, fogL * 0.8, tir);
            c = mix(c, fogL, 1.0 - exp(-dist * 0.1));
            c *= u.xtra.x;
            c = c * (1.0 + c / 6.0) / (1.0 + c);
            c = pow(max(c, vec3(0.0)), vec3(1.0 / 2.2));
            { outColor = vec4(c * u.color.a, u.color.a); return; }
        }
        float NdVw = clamp(dot(Nw, V), 0.3, 1.0);      // floor: at grazing angles Fresnel hit 1.0 and the whole plane turned into a flat white mirror
        float F = min(0.02 + 0.98 * pow(1.0 - NdVw, 5.0), 0.4);      // cap: a low camera no longer turns the whole sheet into a mirror
        vec3 Rw = reflect(-V, Nw); Rw.y = abs(Rw.y);
        vec3 refl = mEnvT(Rw, 0.03, tEnv, u.envp) * u.emis.w * envK;
        if (u.envp.x < 0.5) {      // no HDRI: a blue sky gradient (the default grey horizon made water look like snow) ...
            refl = mix(vec3(0.16, 0.26, 0.42), vec3(0.04, 0.13, 0.36), clamp(Rw.y * 1.6, 0.0, 1.0)) * (0.6 + 0.4 * envK);
            if (u.wf.z > 0.5) {      // ... and, better, reflect the real picture behind it (the 2D sky layer) at the mirrored view direction
                vec3 sp = u.eye.xyz + Rw * 60.0;
                vec4 sc = u.vp0 * sp.x + u.vp1 * sp.y + u.vp2 * sp.z + u.vp3;
                if (sc.w > 0.05) {
                    vec2 sUv = vec2(sc.x / sc.w * 0.5 + 0.5, 0.5 - sc.y / sc.w * 0.5);
                    float sEdge = smoothstep(0.0, 0.06, min(min(sUv.x, 1.0 - sUv.x), min(sUv.y, 1.0 - sUv.y)));
                    if (sEdge > 0.0 && texture(tSD, sUv).r >= 0.9999999) {
                        vec3 sk = pow(clamp(texture(tScene, sUv).rgb, vec3(0.0), vec3(4.0)), vec3(2.2));
                        refl = mix(refl, sk, sEdge);
                    }
                }
            }
        }
        if (u.wf.y > 0.5 && u.wf.z > 0.5) {      // Reflect surface: screen-space reflection of everything already drawn around the water
            vec3 rp = vW + Nw * 0.01;
            float stp = 0.05;
            for (int i = 0; i < 16; i++) {
                rp += Rw * stp; stp *= 1.32;
                vec4 cc = u.vp0 * rp.x + u.vp1 * rp.y + u.vp2 * rp.z + u.vp3;
                if (cc.w <= 0.05) { break; }
                vec2 ruv = vec2(cc.x / cc.w * 0.5 + 0.5, 0.5 - cc.y / cc.w * 0.5);
                if (ruv.x < 0.0 || ruv.x > 1.0 || ruv.y < 0.0 || ruv.y > 1.0) { break; }
                float rd = texture(tSD, ruv).r;
                if (rd < 0.9999999) {
                    float dl = cc.w - mLin(rd);
                    if (dl > 0.0 && dl < 0.35 + stp * 2.0) {
                        float edge = smoothstep(0.0, 0.08, min(min(ruv.x, 1.0 - ruv.x), min(ruv.y, 1.0 - ruv.y)));
                        vec3 hc = pow(clamp(texture(tScene, ruv).rgb, vec3(0.0), vec3(4.0)), vec3(2.2));
                        refl = mix(refl, hc, edge * (1.0 - float(i) / 30.0));
                        break;
                    }
                }
            }
        }
        float crest = clamp((h + u.wa.z * 0.4) / (u.wa.z * 1.3 + 1e-5), 0.0, 1.0);
        float clar = u.wc.x, turb = u.wc.y;
        float D = mix(0.3, 8.0, u.wb.z);
        vec3 Rr = refract(-V, Nw, 0.75);
        Rr = normalize(mix(-V, Rr, clamp(u.wc.z * 2.0, 0.0, 1.0)));
        float cr = max(-Rr.y, 0.12);
        vec3 absorb = wAbsorb();
        // what is below: real depth buffer + the picture drawn so far, looked up through the wavy surface (refraction warp)
        vec2 suv = gl_FragCoord.xy / vec2(float(textureSize(tScene, 0).x), float(textureSize(tScene, 0).y));
        float surfLin = 1.0 / gl_FragCoord.w;
        float ray = dist / max(surfLin, 1e-3);
        bool hasD = u.wf.z > 0.5;
        float sd0 = hasD ? texelFetch(tSD, ivec2(gl_FragCoord.xy), 0).r : 1.0;
        float th0 = sd0 < 0.9999999 ? max(mLin(sd0) - surfLin, 0.0) * ray : D / cr;
        vec2 dxz = -Nw.xz * u.wc.z * 0.35 * min(th0, 3.0);
        vec2 duv = vec2(u.vp0.x * dxz.x + u.vp2.x * dxz.y, -(u.vp0.y * dxz.x + u.vp2.y * dxz.y)) * gl_FragCoord.w * 0.5;
        vec2 uvR = suv + duv;
        float sdR = hasD ? texture(tSD, uvR).r : 1.0;
        if (hasD && mLin(sdR) < surfLin - 0.002) { uvR = suv; sdR = sd0; }      // something in front of the water: no warping across its edge
        bool hit = sdR < 0.9999999;
        float thR = hit ? max(mLin(sdR) - surfLin, 0.0) * ray : D / cr;
        vec3 Tr = exp(-absorb * thR);
        vec3 seabed = vec3(0.0), sceneT = vec3(0.0);
        vec3 hp = vW + Rr * thR;
        float sand = 0.0;
        if (hit) {      // real object / floor: lit fully when shallow, darker and bluer the deeper it is, with caustics on it
            float cs = wCaus(hp.xz * 1.7, tt) * (1.0 + 0.6 * u.wf.y);
            sceneT = clamp(texture(tScene, uvR).rgb, vec3(0.0), vec3(4.0)) * pow(Tr, vec3(0.4545)) * (1.0 + cs * (1.2 + 1.8 * u.wf.y) * u.eye.w * sunK * Tr.g);
        } else {        // nothing below: procedural seabed
            vec2 sq = hp.xz * 1.7;
            float sn = mVn(sq) * 0.6 + mVn(sq * 2.9 + 4.0) * 0.4;
            float rip = 0.5 + 0.5 * sin(hp.x * 5.0 + sn * 6.0 + hp.z * 2.0);
            vec3 snd = mix(vec3(0.50, 0.42, 0.30), vec3(0.30, 0.25, 0.18), sn) * (0.85 + 0.3 * rip);
            seabed = (snd * (0.5 + 0.5 * u.eye.w * sunK) + wCaus(sq, tt) * vec3(1.0, 0.95, 0.8) * 1.2 * u.eye.w) * Tr * u.wd.w;
            sand = 1.0;
        }
        float skyAmb = 0.35 + 0.65 * clamp(Nw.y, 0.0, 1.0);
        vec3 wcol = u.color.rgb;
        vec3 deep = vec3(0.015, 0.17, 0.20) * wcol, shallow = vec3(0.07, 0.42, 0.40) * wcol;
        if (u.wi.w > 0.5) {      // custom water colours: up to 3 stops blended by depth, flowing bands or noise patches
            float tg = 1.0 - Tr.g;
            if (u.wk.w > 0.5 && u.wk.w < 1.5) { tg = 0.5 + 0.5 * sin(dot(vW.xz, vec2(cos(u.wd.z), sin(u.wd.z))) * u.wl.x + u.wa.y * 0.3 * u.wb.x); }
            else if (u.wk.w > 1.5) { tg = clamp(mVn(vW.xz * u.wl.x * 0.4 + u.wa.y * 0.05 * u.wb.x) * 1.4 - 0.2, 0.0, 1.0); }
            vec3 mid = u.wj.w > 2.5 ? u.wj.rgb : mix(u.wi.rgb, u.wk.rgb, 0.5);
            wcol = tg < 0.5 ? mix(u.wi.rgb, mid, tg * 2.0) : mix(mid, u.wk.rgb, tg * 2.0 - 1.0);
            deep = wcol * 0.28; shallow = wcol * 0.7;
        }
        vec3 body = mix(deep, shallow, Tr.g) * skyAmb * (1.0 + turb * 1.5);
        body *= hit ? (1.0 - 0.9 * Tr.g) : (1.0 - 0.6 * Tr.g * u.wd.w);
        vec3 Hs = normalize(mL1 + Nw * 0.3);
        body += vec3(0.10, 0.55, 0.42) * (u.wi.w > 0.5 ? wcol * vec3(1.0) : u.color.rgb) * pow(clamp(dot(-V, Hs), 0.0, 1.0), 3.0) * crest * u.wc.w * u.eye.w * 0.9;
        float rg = mix(0.03, 0.14, 1.0 - fadeD);      // glints widen with distance instead of aliasing
        vec3 spec = (mBrdf(Nw, V, mL1, vec3(0.0), vec3(0.02), rg) * vec3(3.2, 3.0, 2.8)
                     + mBrdf(Nw, V, mL1, vec3(0.0), vec3(0.02), 0.18) * vec3(0.5, 0.48, 0.45)) * u.eye.w * u.wd.x * sunK
                    + mBrdf(Nw, V, mL2, vec3(0.0), vec3(0.02), 0.08) * vec3(0.9, 1.0, 1.3) * sunK;
        vec3 lit = vec3(0.0);
        for (int i = 0; i < 8; i++) {      // every scene light (point / sun / spot, any colour) hits the water
            vec4 LA = LB[i * 8], LC = LB[i * 8 + 1], LD = LB[i * 8 + 2], LE = LB[i * 8 + 3];
            if (LE.w < 0.5) { continue; }
            vec3 Ld; float att = mLightAtt(LA, LC, LD, LE, vW, Ld);
            spec += (mBrdf(Nw, V, Ld, vec3(0.0), vec3(0.02), max(rg, 0.04)) + mBrdf(Nw, V, Ld, vec3(0.0), vec3(0.02), 0.2) * 0.25) * LC.rgb * att * LE.z * u.wd.x;
            lit += LC.rgb * clamp(dot(Nw, Ld), 0.0, 1.0) * att * LE.y;
        }
        body += vec3(0.05, 0.28, 0.30) * (u.wi.w > 0.5 ? wcol * 0.6 : u.color.rgb) * lit * 0.3 * (0.4 + Tr.g);
        seabed += vec3(0.35, 0.3, 0.22) * lit * 0.25 * Tr * u.wd.w * sand;
        float steep = clamp(length(g) * 0.9 - 0.15, 0.0, 1.0);
        float fn = mVn(q * 4.0 - tt * 0.3) * 0.6 + mVn(q * 9.0 + tt * 0.2 + 3.0) * 0.4;
        float fm0 = smoothstep(1.0 - u.wb.y * 0.6, 1.0, crest * 0.7 + steep * 0.5 + (fn - 0.5) * 0.7) * smoothstep(0.05, 0.4, u.wb.y);
        float caps = smoothstep(0.55, 0.85, mVn(vW.xz * 0.07 + tt * 0.03 + 5.0)) * u.we.w * smoothstep(0.1, 0.5, u.wb.y);
        float dThR = fwidth(thR);
        bool coll = u.wh.x > 0.5 || u.wh.y > 0.5;
        float shoreOld = (hit && !coll) ? smoothstep(0.35, 0.0, thR) : 0.0;
        float contactF = 0.0;
        if (hit && coll) {      // water collision: foam where the surface meets rocks (steep) and shores (gentle), waves washing up and back
            // wave force: taller, choppier, faster waves hit harder -> wider, denser, longer-lived foam
            float force = clamp((u.wa.z * 9.0 + u.wb.w * 0.45) * (0.4 + 0.3 * u.wb.x), 0.15, 2.2);
            float hN = h / max(u.wa.z, 1e-4);                       // -1..1 wave height at this pixel
            float thE = max(thR - hN * (0.05 + 0.22 * force), 0.0);  // real run-up: the waterline surges up and back with the wave
            float fw = mix(0.12, 1.4, u.wh.z) * (0.6 + 0.6 * force);
            float steepD = smoothstep(0.02, 0.25, dThR * 8.0);
            float contact = smoothstep(fw, 0.0, thE);
            float wash = 0.55 + 0.45 * sin(tt * 1.4 - thE * 5.0 / (fw + 0.1) + fn * 3.0);
            float bands = smoothstep(0.55, 1.0, sin(thE * 9.0 / (fw + 0.1) - tt * 1.2 + fn * 2.0)) * smoothstep(fw * 2.6, fw * 0.8, thE) * 0.55;
            float lace = smoothstep(0.42, 0.7, mVn(q * 13.0 + tt * 0.6)) * smoothstep(fw * 2.2, fw * 0.3, thE);   // lacy bubble trails behind the edge
            float burst = (0.6 + 0.8 * clamp(crest + hN * 0.5, 0.0, 1.0)) * force;                           // splash bursts on the crest
            contactF = (contact * steepD * burst + lace * 0.6 * force) * u.wh.x + (contact * wash + bands + lace * 0.5) * (1.0 - steepD) * u.wh.y * (0.5 + 0.5 * force);
        }
        float cover = clamp(fm0 + caps * smoothstep(0.5, 0.8, fn) * 0.8 + shoreOld * smoothstep(0.3, 0.7, fn + 0.2) * u.wb.y + contactF * 1.3 * max(u.wb.y, 0.35), 0.0, 1.0);
        float ft = wFoamT(vW.xz, tt);
        vec3 fN = Nw;
        {   // bumpy foam normal from screen-space derivatives (no extra texture taps)
            vec3 dpx = dFdx(vW), dpy = dFdy(vW);
            float dhx = dFdx(ft), dhy = dFdy(ft);
            vec3 r1 = cross(dpy, Nw), r2 = cross(Nw, dpx);
            float det = dot(dpx, r1);
            vec3 gr = sign(det) * (dhx * r1 + dhy * r2);
            fN = normalize(abs(det) * Nw - clamp(gr * 0.02, vec3(-0.6 * abs(det)), vec3(0.6 * abs(det))));
        }
        float fm = clamp((cover * 1.5 - (1.0 - ft) * 0.85) * 2.0, 0.0, 1.0);
        float back = pow(clamp(dot(-V, mL1), 0.0, 1.0), 4.0);
        vec3 foamC = mix(vec3(0.60, 0.80, 0.82), vec3(0.97, 0.98, 0.99), clamp(fm * 1.2 + ft * 0.3, 0.0, 1.0))
                     * (0.3 + 0.7 * clamp(dot(fN, mL1), 0.0, 1.0) * u.eye.w * sunK + lit * 0.5 + 0.22 * envK + 0.12 * back * u.eye.w) * (0.78 + 0.22 * ft);
        vec3 base = mix(mix(body + seabed, refl, F), foamC, fm);
        vec3 outc = base + spec * (1.0 - fm);
        outc *= u.xtra.x;
        outc = outc * (1.0 + outc / 6.0) / (1.0 + outc);
        outc = pow(max(outc, vec3(0.0)), vec3(1.0 / 2.2));
        outc += sceneT * (1.0 - F) * (1.0 - fm);
        float aw = u.color.a;
        { outColor = vec4(outc * aw, aw); return; }
    }
    float pSh = 1.0;
    bool pbr = u.xtra.w > 0.0 && u.has.w > 0.5;
    vec3 Tn = vec3(0.0), Bn = vec3(0.0);
    if (pbr) {      // Extras PBR: tangent frame from derivatives, height (MR.r) -> parallax, normal XY (occ.gb) -> bump
        vec3 dp1 = dFdx(vW), dp2 = dFdy(vW);
        vec2 du1 = dFdx(vUv), du2 = dFdy(vUv);
        vec3 p2 = cross(dp2, N), p1 = cross(N, dp1);
        vec3 T = p2 * du1.x + p1 * du2.x, B = p2 * du1.y + p1 * du2.y;
        float inv = inversesqrt(max(max(dot(T, T), dot(B, B)), 1e-12));
        Tn = T * inv; Bn = B * inv;
        if (u.pg.y > 0.0 && u.has.y > 0.5 && u.sp0.x < 0.5) {      // parallax occlusion mapping (height in metal-rough R) + contact self-shadow
            vec3 Vt = vec3(dot(V, Tn), dot(V, Bn), max(dot(V, N), 0.3));
            vec2 P = Vt.xy / Vt.z * u.pg.y * smoothstep(0.05, 0.4, dot(V, N));
            float plod = max(0.0, log2(max(length(gx), length(gy)) * float(textureSize(tMR, 0).x))) + 0.5;
            const int NS = 20;
            float ld = 1.0 / float(NS), cl = 0.0;
            vec2 cuv = uv;
            float dv = 1.0 - textureLod(tMR, cuv, plod).r;
            for (int i = 0; i < NS; i++) {
                if (cl >= dv) { break; }
                cuv -= P * ld; dv = 1.0 - textureLod(tMR, cuv, plod).r; cl += ld;
            }
            vec2 prv = cuv + P * ld;
            float aft = dv - cl, bef = (1.0 - textureLod(tMR, prv, plod).r) - cl + ld;
            uv = mix(cuv, prv, clamp(aft / (aft - bef - 1e-5), 0.0, 1.0));
            vec3 Lt = vec3(dot(mL1, Tn), dot(mL1, Bn), dot(mL1, N));
            if (Lt.z > 0.02) {
                float h0 = textureLod(tMR, uv, plod).r;
                vec2 Ls = Lt.xy / max(Lt.z, 0.1) * u.pg.y;
                for (int i = 1; i <= 6; i++) {
                    float f = float(i) / 6.0;
                    float hh = textureLod(tMR, uv + Ls * f, plod).r;
                    pSh = min(pSh, clamp(1.0 - (hh - (h0 + f * 0.5)) * 6.0, 0.0, 1.0));
                }
            }
        }
        vec2 nxy = u.sp0.x > 0.5 ? vec2(0.0) : (textureGrad(tOcc, uv, gx, gy).gb * 2.0 - 1.0) * u.xtra.w;
        N = normalize(Tn * nxy.x + Bn * nxy.y + N * sqrt(max(1.0 - dot(nxy, nxy), 0.05)));
    }
    if (u.pnm.x > 0.5 && !pmOn) {      // the model's own normal map (FBX / glTF): screen-space tangent frame, glTF convention
        vec3 dp1 = dFdx(vW), dp2 = dFdy(vW);
        vec2 du1 = dFdx(vUv), du2 = dFdy(vUv);
        vec3 q2 = cross(dp2, N), q1 = cross(N, dp1);
        vec3 Tq = q2 * du1.x + q1 * du2.x;
        vec3 Tm = Tq * inversesqrt(max(dot(Tq, Tq), 1e-12));
        vec3 Bm = cross(N, Tm) * u.pnm.z;
        vec3 nt = textureGrad(tPN, uv, gx, gy).rgb * 2.0 - 1.0;
        nt.xy *= u.pnm.y;
        nt.z = sqrt(max(1.0 - dot(nt.xy, nt.xy), 0.05));
        N = normalize(Tm * nt.x + Bm * nt.y + N * nt.z);
    }
    if (pmOn) {      // imported PBR maps: tangent frame from derivatives, parallax + self-shadow from the height map, normal map
        vec3 dp1 = dFdx(vW), dp2 = dFdy(vW);
        vec2 du1 = dFdx(vUv), du2 = dFdy(vUv);
        vec3 q2 = cross(dp2, N), q1 = cross(N, dp1);
        vec3 Tq = q2 * du1.x + q1 * du2.x, Bq = q2 * du1.y + q1 * du2.y;
        float iv = inversesqrt(max(max(dot(Tq, Tq), dot(Bq, Bq)), 1e-12));
        vec3 Tm = Tq * iv, Bm = Bq * iv;
        bool hasH = u.pm.w > 0.5;
        if (hasH && u.pt.z > 0.0) {
            vec3 Vt = vec3(dot(V, Tm), dot(V, Bm), max(dot(V, N), 0.3));
            vec2 P = Vt.xy / Vt.z * u.pt.z * smoothstep(0.05, 0.4, dot(V, N));
            float plod = max(0.0, log2(max(length(gx), length(gy)) * float(textureSize(tPH2, 0).x))) + 0.5;
            const int NS = 24;
            float ld = 1.0 / float(NS), cl = 0.0;
            vec2 cuv = uv;
            float dv = 1.0 - textureLod(tPH2, cuv, plod).r;
            for (int i = 0; i < NS; i++) {
                if (cl >= dv) { break; }
                cuv -= P * ld; dv = 1.0 - textureLod(tPH2, cuv, plod).r; cl += ld;
            }
            vec2 prv = cuv + P * ld;
            float aft = dv - cl, bef = (1.0 - textureLod(tPH2, prv, plod).r) - cl + ld;
            uv = mix(cuv, prv, clamp(aft / (aft - bef - 1e-5), 0.0, 1.0));
            vec3 Lt = vec3(dot(mL1, Tm), dot(mL1, Bm), dot(mL1, N));
            if (Lt.z > 0.02) {
                float h0 = textureLod(tPH2, uv, plod).r;
                vec2 Ls = Lt.xy / max(Lt.z, 0.1) * u.pt.z;
                for (int i = 1; i <= 6; i++) {
                    float f = float(i) / 6.0;
                    float hh = textureLod(tPH2, uv + Ls * f, plod).r;
                    pSh = min(pSh, clamp(1.0 - (hh - (h0 + f * 0.5)) * 6.0, 0.0, 1.0));
                }
            }
        }
        vec3 nt = vec3(0.0, 0.0, 1.0);
        if (u.pm.x > 0.5) {
            nt = textureGrad(tPN, uv, gx, gy).rgb * 2.0 - 1.0;
            nt.y *= u.pn.z;
        } else if (hasH) {      // no normal map: the relief itself gives the normals
            float e = 1.0 / float(textureSize(tPH2, 0).x);
            float hl = textureLod(tPH2, uv - vec2(e, 0.0), 0.0).r, hr = textureLod(tPH2, uv + vec2(e, 0.0), 0.0).r;
            float hd = textureLod(tPH2, uv - vec2(0.0, e), 0.0).r, hu = textureLod(tPH2, uv + vec2(0.0, e), 0.0).r;
            nt = vec3((hl - hr) * 6.0, (hd - hu) * 6.0, 1.0);
        }
        nt.xy *= u.pn.y;
        nt.z = sqrt(max(1.0 - dot(nt.xy, nt.xy), 0.05));
        N = normalize(Tm * nt.x + Bm * nt.y + N * nt.z);
    }
    float spCov = 0.0, spR = 0.9, spM = 0.0, spAo = 1.0; vec3 spC = vec3(0.0);
    if (u.sp0.x > 0.5 && pbr) {      // terrain splat: up to 4 tiled PBR layers, weights from rules, height-based blend, per-pixel normals
        vec3 w0 = texture(tW0, vUv).rgb; float w1 = texture(tW1, vUv).r;
        float wt[4] = float[4](w0.r, w0.g, w0.b, w1);
        float tl[4] = float[4](u.sp1.x, u.sp1.y, u.sp1.z, u.sp1.w);
        float st[4] = float[4](u.sp2.x, u.sp2.y, u.sp2.z, u.sp2.w);
        vec3 Vt = vec3(dot(V, Tn), dot(V, Bn), max(dot(V, N), 0.3));
        vec2 duvx = dFdx(vUv), duvy = dFdy(vUv);
        float depth = u.pg.y, expo = 2.0 + depth * 60.0, rcs = 0.7986, rsn = 0.6018;
        float kk = 0.5 + 0.3 * sin(vUv.x * 9.1 + vUv.y * 5.3) * cos(vUv.y * 7.7 - vUv.x * 3.9);
        float gk = 1.0 / sqrt(kk * kk + (1.0 - kk) * (1.0 - kk));
        vec2 par = Vt.xy / Vt.z * depth * 8.0 * smoothstep(0.05, 0.4, dot(V, N));
        float wh[4]; vec3 cA[4]; float rA[4], mA[4], aA[4]; vec2 nA[4];
        float wsum = 0.0, cover = 0.0;
        for (int l = 0; l < 4; l++) {
            wh[l] = 0.0; cA[l] = vec3(0.0); rA[l] = 0.9; mA[l] = 0.0; aA[l] = 1.0; nA[l] = vec2(0.0);
            cover += wt[l];
            if (wt[l] < 0.004) { continue; }
            vec2 gxp = duvx * tl[l], gyp = duvy * tl[l], p = vUv * tl[l];
            p += par * (textureGrad(tR[l], p, gxp, gyp).r - 0.5);
            vec2 pb = vec2(rcs * p.x - rsn * p.y, rsn * p.x + rcs * p.y) * 0.93 + vec2(17.3, 5.1);
            vec2 gxb = vec2(rcs * gxp.x - rsn * gxp.y, rsn * gxp.x + rcs * gxp.y) * 0.93, gyb = vec2(rcs * gyp.x - rsn * gyp.y, rsn * gyp.x + rcs * gyp.y) * 0.93;
            vec4 d1 = textureGrad(tD[l], p, gxp, gyp), d2 = textureGrad(tD[l], pb, gxb, gyb);
            vec4 r1 = textureGrad(tR[l], p, gxp, gyp), r2 = textureGrad(tR[l], pb, gxb, gyb);
            vec4 n1 = textureGrad(tN[l], p, gxp, gyp), n2 = textureGrad(tN[l], pb, gxb, gyb);
            vec3 avg = textureLod(tD[l], vec2(0.5), 12.0).rgb;
            vec3 ce = clamp(avg + (mix(d1.rgb, d2.rgb, kk) - avg) * gk, 0.0, 1.0);
            float h = clamp(0.5 + (mix(r1.r, r2.r, kk) - 0.5) * gk, 0.0, 1.0);
            vec2 na = n1.rg * 2.0 - 1.0, nb0 = n2.rg * 2.0 - 1.0;
            vec2 nb = vec2(rcs * nb0.x + rsn * nb0.y, -rsn * nb0.x + rcs * nb0.y);
            cA[l] = pow(ce, vec3(2.2)); rA[l] = mix(r1.g, r2.g, kk); mA[l] = mix(r1.b, r2.b, kk); aA[l] = mix(n1.b, n2.b, kk);
            nA[l] = mix(na, nb, kk) * gk * st[l];
            wh[l] = wt[l] * pow(0.15 + h, expo); wsum += wh[l];
        }
        float tot = max(wsum, 1e-5); vec2 nsum = vec2(0.0);
        for (int l = 0; l < 4; l++) {
            float w = wh[l] / tot;
            spC += cA[l] * w; spR += (rA[l] - 0.9) * w; spM += mA[l] * w; spAo += (aA[l] - 1.0) * w; nsum += nA[l] * w;
        }
        spCov = clamp(cover, 0.0, 1.0);
        vec2 nx2 = nsum * u.xtra.w * spCov;
        N = normalize(Tn * nx2.x + Bn * nx2.y + N * sqrt(max(1.0 - dot(nx2, nx2), 0.05)));
    }
    float a = u.color.a * vCol.a;
    vec3 tint = u.color.rgb * pow(max(vCol.rgb, vec3(0.0)), vec3(2.2));
    vec3 alb = tint;
    if (u.has.x > 0.5) {
        vec4 t = textureGrad(tBase, uv, gx, gy);
        a *= t.a;
        alb *= pow(clamp(t.rgb / max(t.a, 0.001), 0.0, 1.0), vec3(2.2));
    }
    if (spCov > 0.0) { alb = mix(alb, tint * spC, spCov); }
    if (pmOn && u.pn.x > 0.5) { if (textureGrad(tPO, uv, gx, gy).r < 0.5) { discard; } }
    if (u.prm.z >= 0.0) {
        if (a < u.prm.z) { discard; }
        a = 1.0;
    }
    float metal = u.prm.x * u.opt.y;
    float rough = u.prm.y;
    float ao = 1.0;
    if (u.has.w > 0.5) { ao = mix(1.0, textureGrad(tOcc, uv, gx, gy).r, u.opt.w); }
    if (u.has.y > 0.5) {
        vec4 m = textureGrad(tMR, uv, gx, gy);
        rough *= m.g;
        metal *= m.b * u.opt.y;
    }
    if (pmOn) {
        if (u.pm.y > 0.5) { rough = textureGrad(tPR, uv, gx, gy).r; }
        rough *= u.pq.x;
        if (u.pm.z > 0.5) { metal = textureGrad(tPM, uv, gx, gy).r * u.opt.y; }
        metal *= u.pq.y;
        if (u.has.w > 0.5) { ao = mix(1.0, textureGrad(tOcc, uv, gx, gy).r, u.pr.z); }
        vec3 dnr = fwidth(N);      // geometric specular anti-aliasing: bumpy normals widen the highlight instead of sparkling
        rough = sqrt(rough * rough + min(0.5 * dot(dnr, dnr), 0.18));
    }
    if (spCov > 0.0) { rough = mix(rough, spR, spCov); metal = mix(metal, spM * u.opt.y, spCov); ao = mix(ao, spAo, spCov); }
    rough = clamp(rough, 0.04, 1.0);
    metal = clamp(metal, 0.0, 1.0);

    float NdV = max(dot(N, V), 0.001);

    vec3 F0 = mix(vec3(0.04), alb, metal);
    vec3 diffC = alb * (1.0 - metal);
    float rtSun = 1.0;
#ifdef SAIKI_RT
    float rtN = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    float rtSc = max(length(rt.rinv[0].xyz), 1e-6);
    vec3 rtPw = vW + N * 0.004;
    int rtNs = int(clamp(rt.rtp.w, 1.0, 16.0));
    if (rt.rtp.x > 0.0 && dot(N, mL1) > 0.0) { rtSun = 1.0 - (1.0 - rtSoftVis(rtPw, mL1, true, max(rt.rtp.z, 0.002), rtNs, rtN, rtSc)) * u.xtra.z; }
#endif
    vec3 col = mBrdf(N, V, mL1, diffC, F0, rough) * vec3(3.2, 3.0, 2.8) * u.eye.w * pSh * sunK * rtSun
               + mBrdf(N, V, mL2, diffC, F0, rough) * vec3(0.9, 1.0, 1.3) * sunK;
    {   // scene lights (Lighting layers): point / sun / spot, range window, spot cone + penumbra, separate diffuse + specular strength
        for (int i = 0; i < 8; i++) {
            vec4 LA = LB[i * 8], LC = LB[i * 8 + 1], LD = LB[i * 8 + 2], LE = LB[i * 8 + 3];
            if (LE.w < 0.5) { continue; }
            vec3 Ld; float att = mLightAtt(LA, LC, LD, LE, vW, Ld);
            float lsh = 1.0;
#ifdef SAIKI_RT
            if (rt.rtp.x > 0.0 && att > 0.002 && dot(N, Ld) > 0.0) {
                bool sunL = LA.w > 0.5 && LA.w < 1.5;
                vec3 tg = sunL ? Ld : LA.xyz;
                float rad = sunL ? max(rt.rtp.z, 0.002) : max(LB[i * 8 + 6].z, 0.0);
                lsh = 1.0 - (1.0 - rtSoftVis(rtPw, tg, sunL, rad, max(rtNs / 2, 2), rtN, rtSc)) * u.xtra.z;
            }
#endif
            att *= lsh;
            vec3 full = mBrdf(N, V, Ld, diffC, F0, rough);
            vec3 sp = mBrdf(N, V, Ld, vec3(0.0), F0, rough);
            col += ((full - sp) * LE.y + sp * LE.z) * mLightCol(i, vW) * att;
        }
    }
    if (pbr || pmOn) { col *= mix(1.0, ao, 0.8); }
#ifdef SAIKI_RT
    float rtAo = 1.0;
    if (rt.rtp.x > 0.0) {
        vec3 T = normalize(abs(N.y) < 0.9 ? cross(N, vec3(0.0, 1.0, 0.0)) : cross(N, vec3(1.0, 0.0, 0.0)));
        vec3 Bt = cross(N, T);
        float occl = 0.0;
        for (int k = 0; k < 8; k++) {
            float a2 = float(k) * 0.7853982 + rtN * 6.2831853;
            float el = (k & 1) == 0 ? 0.45 : 0.85;
            vec3 dw = normalize(N * el + (T * cos(a2) + Bt * sin(a2)) * (1.0 - el));
            float maxd = max(rt.rtp.y, 0.01) * rtSc;
            rayQueryEXT rq;
            rayQueryInitializeEXT(rq, acc, gl_RayFlagsOpaqueEXT, 0xFF, (rt.rinv * vec4(rtPw, 1.0)).xyz, 0.0005 * rtSc, normalize((rt.rinv * vec4(dw, 0.0)).xyz), maxd);
            while (rayQueryProceedEXT(rq)) {}
            if (rayQueryGetIntersectionTypeEXT(rq, true) != gl_RayQueryCommittedIntersectionNoneEXT) { occl += 1.0 - 0.6 * clamp(rayQueryGetIntersectionTEXT(rq, true) / maxd, 0.0, 1.0); }
        }
        rtAo = 1.0 - (occl / 8.0) * u.xtra.y;
    }
    ao *= rtAo;
#endif
    vec3 R = reflect(-V, N);
    vec3 Fr = F0 + (max(vec3(1.0 - rough), F0) - F0) * pow(1.0 - NdV, 5.0);
    if (u.opt.x > 0.5) {
        col += diffC * mEnvT(N, 1.0, tEnv, u.envp) * 0.8 * ao * u.emis.w * envK;
        col += mEnvT(R, rough, tEnv, u.envp) * Fr * (1.0 - 0.5 * rough) * ao * u.emis.w * envK;
    } else {
        col += diffC * 0.3 * ao;
    }
    if (pmOn && u.pr.x > 0.001) {      // clear coat: a second glossy dielectric layer over the base (lacquer, car paint, wet look)
        vec3 Ng = normalize(vN); if (dot(Ng, V) < 0.0) { Ng = -Ng; }
        float cr = clamp(u.pr.y, 0.03, 1.0);
        float Fc = 0.04 + 0.96 * pow(1.0 - max(dot(Ng, V), 0.001), 5.0);
        vec3 coat = mBrdf(Ng, V, mL1, vec3(0.0), vec3(0.04), cr) * vec3(3.2, 3.0, 2.8) * u.eye.w * sunK * pSh * rtSun;
        if (u.opt.x > 0.5) { coat += mEnvT(reflect(-V, Ng), cr, tEnv, u.envp) * Fc * u.emis.w * envK; }
        col = col * (1.0 - Fc * u.pr.x) + coat * u.pr.x;
    }
    vec3 em = u.emis.xyz;
    if (u.has.z > 0.5) { em *= pow(textureGrad(tEm, uv, gx, gy).rgb, vec3(2.2)); }
    if (pmOn && u.has.z > 0.5) { em = pow(textureGrad(tEm, uv, gx, gy).rgb, vec3(2.2)) * u.pq.z; }
    col += em;
    col = mix(col, alb + em, u.prm.w);
    if (u.opt.z > 0.5) {
        vec3 v = alb;
        if (u.opt.z > 1.5) { v = vec3(rough); }
        if (u.opt.z > 2.5) { v = vec3(metal); }
        if (u.opt.z > 3.5) { v = vec3(ao); }
        if (u.opt.z > 4.5) { v = em; }
        { outColor = vec4(pow(max(v, vec3(0.0)), vec3(1.0 / 2.2)) * a, a); return; }
    }
    col *= u.xtra.x;
    col = col * (1.0 + col / 6.0) / (1.0 + col);
    col = pow(max(col, vec3(0.0)), vec3(1.0 / 2.2));
    if (u.xr.x > 0.5) {         // x-ray: silhouette-bright, see-through centre, cool tint
        float rim = pow(1.0 - clamp(abs(dot(N, V)), 0.0, 1.0), u.xr.y);
        float xa = a * clamp(u.xr.z + (1.0 - u.xr.z) * rim, 0.0, 1.0);
        vec3 xc = mix(col * 0.6, vec3(0.45, 0.85, 1.0), 0.35 + 0.5 * rim);
        { outColor = vec4(xc * xa, xa); return; }
    }
    { outColor = vec4(col * a, a); return; }
}
