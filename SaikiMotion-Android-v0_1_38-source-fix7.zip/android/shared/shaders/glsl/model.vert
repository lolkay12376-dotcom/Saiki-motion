#version 450
// PORT-OF: msl/MetalModelSL.source.msl::modelVertex
// MSL-SHA256: 41eb491ce2bab9b4
// Bindings (set0): UBO ModelU b32 (MSL buffer(0)); SSBO vb b34 (std430 float[], 12 floats/vertex, MSL buffer(1));
// tPH b26 = imported height map, LINEAR + REPEAT, no mip (MSL texture(0) in the vertex stage; same image as fragment tPH2).
layout(location = 0) out vec3 oN;
layout(location = 1) out vec3 oW;
layout(location = 2) out vec2 oUv;
layout(location = 3) out vec4 oCol;
layout(std140, set = 0, binding = 32) uniform ModelU {
    vec4 vp0; vec4 vp1; vec4 vp2; vec4 vp3;     // uVP columns
    vec4 m0; vec4 m1; vec4 m2; vec4 m3;         // uModel columns
    vec4 color;     // uColor
    vec4 emis;      // uEmis.xyz
    vec4 eye;       // uEye.xyz
    vec4 prm;       // metal, rough, cutoff, unlit
    vec4 has;       // base, metal-rough, emissive, occlusion texture present
    vec4 opt;       // env, metallic reflectivity, view mode, ao strength
    vec4 xtra;      // exposure, rt ao, rt shadow, pbr bump strength
    vec4 lp0; vec4 lp1; vec4 lp2;     // scene point lights: world pos
    vec4 lc0; vec4 lc1; vec4 lc2;     // rgb * intensity (w = 1 when active)
    vec4 pg;        // procedural pbr: on, parallax depth, uv scale x, uv scale y
    vec4 wa;        // water: on, time, wave height, wave frequency
    vec4 wb;        // water: speed, foam, depth, choppiness
    vec4 wc;        // water: clarity, turbidity, refraction, subsurface
    vec4 wd;        // water: glint, detail, flow dir (rad), procedural seabed
    vec4 we;        // water: wave variation, swell, swell length, whitecaps
    vec4 wf;        // water: base y, reflect, scene depth available, rays
    vec4 wg;        // water rays: strength, length, sharpness, speed
    vec4 wh;        // water collision: rocks, shores, foam width, 0
    vec4 wi;        // water colours: shallow rgb, custom on
    vec4 wj;        // water colours: middle rgb, stop count (2 or 3)
    vec4 wk;        // water colours: deep rgb, gradient mode (0 depth, 1 bands, 2 patches)
    vec4 wl;        // water colours: gradient scale
    vec4 envp;      // HDRI environment: on, rotation (turns), max mip, gain
    vec4 sp0;       // terrain splat: on, layer count, 0, 0
    vec4 sp1;       // splat tiling per layer
    vec4 sp2;       // splat normal strength per layer
    vec4 pm;        // imported PBR maps: normal, roughness, metallic, height present
    vec4 pn;        // opacity map present, normal strength, normal Y sign, displacement amount (world units)
    vec4 pt;        // texture tiling u, v, parallax depth, height mid-point
    vec4 xr;        // x-ray view (editor preview only): on, rim power, base opacity, 0
    vec4 pq;        // roughness multiplier, metallic multiplier, emissive strength, maps on
    vec4 pr;        // clear coat, clear coat roughness, AO strength
    vec4 pnm;       // embedded (per-material) normal map: on, strength, green sign, 0
    vec4 ptc;       // point map: size px (0 = not a point map), anim mode, anim amount, time
} u;
layout(std430, set = 0, binding = 34) readonly buffer VB { float vb[]; };
layout(set = 0, binding = 26) uniform sampler2D tPH;
float glmod(float x, float y) { return x - y * floor(x / y); }
float mHash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float mVn(vec2 p) {
    vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mHash(i), mHash(i + vec2(1.0, 0.0)), f.x), mix(mHash(i + vec2(0.0, 1.0)), mHash(i + vec2(1.0, 1.0)), f.x), f.y);
}
// Sharpened sine waves (Gerstner-like crests). Directions, frequencies and phases are jittered and domain-warped,
// amplitude is modulated at a large scale, so the pattern never visibly tiles. Returns height, gradient in g.
vec2 mH2(vec2 p) { return vec2(mHash(p), mHash(p + 17.3)); }
float wCell(vec2 p) {      // cellular distance: bubble walls
    vec2 i = floor(p), f = fract(p); float m = 8.0;
    for (int y = -1; y <= 1; y++) { for (int x = -1; x <= 1; x++) {
        vec2 g = vec2(float(x), float(y)); vec2 r = g + mH2(i + g) * 0.9 - f; m = min(m, dot(r, r)); } }
    return sqrt(m);
}
float wFoamT(vec2 p, float tt) {      // lacy foam: warped streaks + two scales of bubble walls
    vec2 wv = vec2(mVn(p * 1.3 + tt * 0.15), mVn(p * 1.3 + 9.0 - tt * 0.12)) - 0.5;
    p += wv * 1.3;
    float f = mVn(p * 2.0) * 0.45 + mVn(p * 5.0 + 3.0) * 0.3 + mVn(p * 12.0) * 0.25;
    float b1 = smoothstep(0.18, 0.62, wCell(p * 8.0 + tt * 0.06));
    float b2 = mVn(p * 31.0 - tt * 0.05 + 5.0);
    return smoothstep(0.22, 0.8, f * 0.5 + b1 * 0.35 + b2 * 0.2);
}
float wBeam(vec2 sp, float t, float wid) {      // sunbeams that pass through the moving surface
    float pat = mVn(sp * 1.1 + t * 0.25) * 0.65 + mVn(sp * 2.7 - t * 0.35 + 8.0) * 0.35;
    return pow(clamp(pat * 1.7 - 0.45, 0.0, 1.0), mix(1.2, 4.0, clamp(wid * 0.5, 0.0, 1.0)));
}
float wMean(float k) { float k2 = k * k; return exp(-k) * (1.0 + k2 * (0.25 + k2 * (0.015625 + k2 * (0.000434 + k2 * 0.0000068)))); }      // mean of exp((sin-1)k)
float wvH(vec2 p, float t, float amp, float freq, float spd, float chop, float dirA, float vari, vec2 sw, int nw, out vec2 g) {
    float k = mix(0.7, 2.6, chop);
    float zone = mix(0.6, 1.4, mVn(p * 0.03 + 19.0));      // calm / rough areas: far water differs from near water
    float am = mix(1.0, 0.45 + 1.1 * mVn(p * 0.09 + 7.0), vari);
    float wph = (mVn(p * 0.17 + 3.0) - 0.5) * 3.0 * vari;
    float h = 0.0, a = amp * am, f = freq, w = 1.0;
    g = vec2(0.0);
    for (int i = 0; i < nw; i++) {
        float fi = float(i);
        float ang = dirA + fi * 0.83 + sin(fi * 5.1 + 1.0) * 0.7 * (0.4 + vari);
        vec2 d = vec2(cos(ang), sin(ang));
        float fr = f * (1.0 + 0.21 * sin(fi * 7.3));
        float ph = dot(d, p) * fr + t * spd * w * 1.6 + fi * 1.7 + wph * (0.4 + 0.3 * fi);
        float e = exp((sin(ph) - 1.0) * k);
        h += a * (e - wMean(k));
        g += a * e * k * cos(ph) * fr * d;
        a *= 0.58; f *= 1.8; w *= 1.2;
    }
    for (int j = 0; j < 3; j++) {      // long rounded swells on their own headings
        float fj = float(j);
        float ang = dirA + 2.1 + fj * 1.9;
        vec2 d = vec2(cos(ang), sin(ang));
        float fr = freq * sw.y * (1.0 + 0.45 * fj);
        float ph = dot(d, p) * fr + t * spd * (0.8 + 0.25 * fj) + fj * 2.3 + wph * 0.5;
        float e = exp((sin(ph) - 1.0) * 0.9);
        float sa = amp * sw.x * zone * (1.0 - 0.25 * fj) * 2.2;
        h += sa * (e - 0.4934);
        g += sa * e * 0.9 * cos(ph) * fr * d;
    }
    return h;
}
void main() {
    uint b = uint(gl_VertexIndex) * 12u;
    vec3 aPos = vec3(vb[b], vb[b + 1u], vb[b + 2u]);
    vec3 aNormal = vec3(vb[b + 3u], vb[b + 4u], vb[b + 5u]);
    vec2 aUv = vec2(vb[b + 6u], vb[b + 7u]);
    vec4 aCol = vec4(vb[b + 8u], vb[b + 9u], vb[b + 10u], vb[b + 11u]);
    vec4 wp = u.m0 * aPos.x + u.m1 * aPos.y + u.m2 * aPos.z + u.m3;
    vec3 wn = vec3(0.0, 1.0, 0.0);
    if (u.wa.x > 0.5) {
        vec2 g; float hh = wvH(wp.xz, u.wa.y, u.wa.z, u.wa.w, u.wb.x, u.wb.w, u.wd.z, u.we.x, u.we.yz, 4, g);
        wp.y += hh; wn = normalize(vec3(-g.x, 1.0, -g.y));
    }
    if (u.pq.w > 0.5 && u.pm.w > 0.5 && abs(u.pn.w) > 1e-5) {      // imported height map: real vertex displacement along the normal
        float hh = textureLod(tPH, aUv * u.pt.xy, 0.0).r;
        vec3 nW = u.m0.xyz * aNormal.x + u.m1.xyz * aNormal.y + u.m2.xyz * aNormal.z;
        nW = dot(nW, nW) > 1e-8 ? normalize(nW) : vec3(0.0, 1.0, 0.0);
        wp.xyz += nW * ((hh - u.pt.w) * u.pn.w);
    }
    float psz = 3.0;
    if (u.ptc.x > 0.0) {            // point map: size + animation (all in world space relative to the layer origin)
        psz = u.ptc.x;
        float t = u.ptc.w, amt = u.ptc.z, sc = max(length(u.m0.xyz), 1e-4);
        int md = int(u.ptc.y + 0.5);
        vec3 rel = (wp.xyz - u.m3.xyz) / sc;
        float h1 = mHash(aPos.xy * 91.7 + aPos.z * 13.1);
        vec3 dir = normalize(rel + (vec3(h1, mHash(aPos.yz * 7.3), mHash(aPos.zx * 5.1)) - 0.5) * 0.4 + 1e-4);
        if (md == 1) {              // ripple
            wp.y += sin(length(rel.xz) * 4.0 - t * 3.0) * 0.06 * amt * sc;
        } else if (md == 2) {       // shimmer / twinkle
            vec3 j = vec3(mHash(aPos.xy + floor(t * 6.0)), mHash(aPos.yz + floor(t * 6.0) + 3.0), mHash(aPos.zx + floor(t * 6.0) + 7.0)) - 0.5;
            wp.xyz += j * 0.03 * amt * sc;
            psz *= 0.55 + 0.9 * (0.5 + 0.5 * sin(t * 4.0 + h1 * 6.2832));
        } else if (md == 3) {       // scan sweep
            float hs = (fract(t * 0.25) * 2.0 - 1.0) * 0.6;
            float band = exp(-pow((rel.y - hs) * 7.0, 2.0));
            psz *= 1.0 + band * 2.5 * amt;
            wp.xyz += vec3(rel.x, 0.0, rel.z) * band * 0.06 * amt * sc;
            aCol.rgb += band * amt;
        } else if (md == 4) {       // burst / reassemble
            float k = 0.5 - 0.5 * cos(t * 1.2);
            wp.xyz += dir * k * k * amt * 0.7 * sc * (0.4 + h1);
        } else if (md == 5) {       // twist
            float a = amt * 0.9 * sin(t * 0.8) * (rel.y + 0.5) * 2.0;
            float cs = cos(a), sn = sin(a);
            vec3 d = vec3(rel.x * cs - rel.z * sn - rel.x, 0.0, rel.x * sn + rel.z * cs - rel.z);
            wp.xyz += d * sc;
        }
    }
    vec4 c = u.vp0 * wp.x + u.vp1 * wp.y + u.vp2 * wp.z + u.vp3 * wp.w;
    c.z = (c.z + c.w) * 0.5;
    gl_Position = c;
    gl_PointSize = psz;
    oW = wp.xyz;
    vec3 n = u.m0.xyz * aNormal.x + u.m1.xyz * aNormal.y + u.m2.xyz * aNormal.z;
    oN = dot(n, n) > 1e-8 ? normalize(n) : vec3(0.0, 1.0, 0.0);
    if (u.wa.x > 0.5) { oN = wn; }
    oUv = aUv;
    oCol = aCol;
}
