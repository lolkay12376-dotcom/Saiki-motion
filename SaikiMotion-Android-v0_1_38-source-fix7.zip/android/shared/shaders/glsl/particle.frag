#version 450
// PORT-OF: msl/MetalParticleSL.source.msl::particleFragment
// MSL-SHA256: eb9b9519e969e2cf
// Bindings: set0 b0 UBO PtU (same block as particle.vert), b3 atlas, b4 bump. smp == linear + clamp_to_edge.
layout(std140, set = 0, binding = 0) uniform PtU {
    vec4 vp0; vec4 vp1; vec4 vp2; vec4 vp3;
    vec4 a; vec4 b; vec4 colA; vec4 colB; vec4 c; vec4 d; vec4 e;
} u;
layout(set = 0, binding = 3) uniform sampler2D atlas;
layout(set = 0, binding = 4) uniform sampler2D bump;
layout(location = 0) in vec4 inCol;
layout(location = 1) in float inLife;
layout(location = 2) in float inSoft;
layout(location = 3) in float inPs;
layout(location = 4) in float inAlpha;
layout(location = 5) in float inRot;
layout(location = 6) in float inVari;
layout(location = 0) out vec4 outColor;
void main() {
    vec2 pc = gl_PointCoord;   // origin top-left in Vulkan, same as Metal point_coord
    float fade = smoothstep(0.0, u.b.y, inLife) * (1.0 - smoothstep(1.0 - u.b.z, 1.0, inLife));
    if (u.c.w > 0.5) {
        float gm = max(u.e.w, 1.0);
        vec2 q = (pc - 0.5) * 1.42 * gm;
        float cs = cos(inRot), sn = sin(inRot);
        vec2 r = vec2(q.x * cs - q.y * sn, q.x * sn + q.y * cs);
        float face = 1.0;
        if (u.e.y > 0.001) {   // 3D tumble: the sprite turns about its own axis, foreshortening and showing its back
            float ph = inVari * 6.2832 + inLife * (3.0 + 4.0 * inVari) * 3.1416;
            float sc = mix(1.0, cos(ph), u.e.y);
            face = sc >= 0.0 ? 1.0 : -1.0;
            r.x /= face * max(abs(sc), 0.1);
        }
        bool ins = abs(r.x) <= 0.5 && abs(r.y) <= 0.5;
        float halo = 0.0;
        if (u.b.w > 0.001) halo = u.b.w * pow(max(0.0, 1.0 - length(pc - 0.5) * 2.0), 2.2) * 0.6 * fade * u.b.x * inAlpha * inCol.a;
        if (!ins && halo <= 0.0005) discard;
        float cells = max(u.c.x, 1.0), grid = max(u.c.y, 1.0);
        float idx = u.d.y > 0.5 ? floor(clamp(inLife, 0.0, 0.999) * cells) : floor(clamp(inVari, 0.0, 0.999) * cells);
        vec2 cell = vec2(mod(idx, grid), floor(idx / grid));   // fmod==mod for the non-negative operands here
        vec4 t = ins ? texture(atlas, (cell + r + 0.5) / grid) : vec4(0.0);
        float a = t.a * fade * u.b.x * inAlpha * inCol.a;
        vec3 rgb = t.rgb / max(t.a, 0.001);
        rgb *= mix(vec3(1.0), inCol.rgb, u.c.z);
        if (u.e.x > 0.001 && ins) {   // bump map: height gradient -> normal, lit from the light angle, rotated with the particle
            vec2 uvc = (cell + r + 0.5) / grid;
            float ep = 1.5 / 512.0;
            float dx = texture(bump, uvc + vec2(ep, 0.0)).r - texture(bump, uvc - vec2(ep, 0.0)).r;
            float dy = texture(bump, uvc + vec2(0.0, ep)).r - texture(bump, uvc - vec2(0.0, ep)).r;
            float k = u.e.x * 10.0;
            vec3 n = normalize(vec3(-dx * k, -dy * k, 1.0));
            vec2 ns = vec2(n.x * cs + n.y * sn, -n.x * sn + n.y * cs);
            vec3 nn = normalize(vec3(ns * face, n.z));
            vec3 L = normalize(vec3(cos(u.e.z) * 0.8, -sin(u.e.z) * 0.8, 0.6));
            float diff = clamp(dot(nn, L), 0.0, 1.0);
            float shade = (0.5 + 0.9 * diff) / (0.5 + 0.9 * L.z);
            float sp = pow(clamp(dot(nn, normalize(L + vec3(0.0, 0.0, 1.0))), 0.0, 1.0), 30.0) * 0.18 * min(u.e.x, 1.5);
            rgb = rgb * shade + sp;
            if (face < 0.0) rgb *= 0.8;
        } else if (face < 0.0) { rgb *= 0.8; }
        outColor = vec4(rgb * a + inCol.rgb * halo, a + halo * 0.25);
        return;
    }
    float gm = max(u.e.w, 1.0);
    vec2 c = (pc - 0.5) * gm;
    float d = length(c);
    float aa = 1.5 / max(inPs / gm, 3.0);
    float a = 1.0 - smoothstep(mix(0.5 - aa, 0.0, inSoft), 0.5, d);
    a *= fade * u.b.x * inAlpha * inCol.a;
    float halo = 0.0;
    if (u.b.w > 0.001) halo = u.b.w * pow(max(0.0, 1.0 - length(pc - 0.5) * 2.0), 2.2) * 0.6 * fade * u.b.x * inAlpha * inCol.a;
    outColor = vec4(inCol.rgb * (a + halo), a + halo * 0.25);
}
