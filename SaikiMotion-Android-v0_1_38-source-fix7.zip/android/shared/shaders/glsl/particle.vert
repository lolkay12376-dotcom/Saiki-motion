#version 450
// PORT-OF: msl/MetalParticleSL.source.msl::particleVertex
// MSL-SHA256: eb9b9519e969e2cf
// Bindings: set0 b0 UBO PtU, b1 SSBO pts (float[], 12 floats/vertex), b2 UBO grad[16]. Point list topology.
layout(std140, set = 0, binding = 0) uniform PtU {
    vec4 vp0; vec4 vp1; vec4 vp2; vec4 vp3;
    vec4 a;       // aspect, ortho, size, px
    vec4 b;       // opacity, fadeIn, fadeOut, 0
    vec4 colA; vec4 colB;
    vec4 c;       // sprite cells, atlas grid, tint, hasSprite
    vec4 d;       // image colour mix, sprite animates over life, gradient by random, gradient on
    vec4 e;       // bump strength, 3D tumble, light angle, 0
} u;
layout(std430, set = 0, binding = 1) readonly buffer Pts { float pts[]; };
layout(std140, set = 0, binding = 2) uniform Grad { vec4 grad[16]; };
layout(location = 0) out vec4 oCol;
layout(location = 1) out float oLife;
layout(location = 2) out float oSoft;
layout(location = 3) out float oPs;
layout(location = 4) out float oAlpha;
layout(location = 5) out float oRot;
layout(location = 6) out float oVari;
void main() {
    uint vid = uint(gl_VertexIndex);
    uint o0 = vid * 12u;
    vec3 aPos = vec3(pts[o0], pts[o0 + 1u], pts[o0 + 2u]);
    vec3 aData = vec3(pts[o0 + 3u], pts[o0 + 4u], pts[o0 + 5u]);
    float k = 1.0;
    if (u.a.y > 0.5) {
        gl_Position = vec4(aPos.x / u.a.x, aPos.y, 0.5, 1.0);
    } else {
        mat4 vp = mat4(u.vp0, u.vp1, u.vp2, u.vp3);
        vec4 c = vp * vec4(aPos, 1.0);
        gl_Position = vec4(c.x, c.y, (c.z + c.w) * 0.5, c.w);     // GL clip z [-w, w] -> Metal/Vulkan [0, w]
        k = 3.0 / max(c.w, 0.05);
    }
    oAlpha = pts[o0 + 6u];
    oRot = pts[o0 + 7u];
    oVari = pts[o0 + 8u];
    oSoft = aData.z;
    float ps = max(4.0, u.a.z * u.a.w * aData.x * k * (1.0 + aData.z * 0.35));
    if (u.c.w > 0.5) ps *= 1.42;                                // room for a rotated sprite
    ps = min(ps * max(u.e.w, 1.0), 500.0);                      // glow halo room; clamp keeps fill-rate bounded
    gl_PointSize = ps;
    oPs = ps;
    oLife = aData.y;
    float lf = clamp(aData.y, 0.0, 1.0);
    vec4 col = mix(u.colA, u.colB, lf);
    if (u.d.w > 0.5) {
        float f = clamp(u.d.z > 0.5 ? oVari : lf, 0.0, 1.0) * 15.0;
        int i0 = int(floor(f));
        int i1 = min(i0 + 1, 15);
        col = mix(grad[i0], grad[i1], f - float(i0));
    }
    col.rgb = mix(col.rgb, vec3(pts[o0 + 9u], pts[o0 + 10u], pts[o0 + 11u]), u.d.x);
    oCol = col;
}
