#version 450
// PORT-OF: msl/MetalModelSL.source.msl::planeDepthF
// MSL-SHA256: 41eb491ce2bab9b4
// Bindings (set0): UBO PlOccU b32 (buffer(0)); tA b0 (NEAREST clamp). No colour output (depth-only pass).
layout(location = 0) in vec2 vUv;
layout(depth_any) out float gl_FragDepth;
layout(std140, set = 0, binding = 32) uniform PlOccU { mat4 inv; mat4 vp; vec4 p0; vec4 n; vec4 flags; } u;
layout(set = 0, binding = 0) uniform sampler2D tA;
float plDepth(vec2 uv, out bool ok) {
    vec2 nd = vec2(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0);
    vec4 a0 = u.inv * vec4(nd, -1.0, 1.0), a1 = u.inv * vec4(nd, 1.0, 1.0);
    vec3 A = a0.xyz / a0.w, B = a1.xyz / a1.w;
    float den = dot(B - A, u.n.xyz);
    ok = abs(den) > 1e-9;
    float t = ok ? dot(u.p0.xyz - A, u.n.xyz) / den : 0.0;
    vec4 cl = u.vp * vec4(A + (B - A) * t, 1.0);
    return (cl.z + cl.w) * 0.5 / cl.w;
}
void main() {
    bool ok; float pd = plDepth(vUv, ok);
    if (!ok || texture(tA, vUv).a < 0.5) { discard; }
    gl_FragDepth = clamp(pd, 0.0, 1.0);
}
