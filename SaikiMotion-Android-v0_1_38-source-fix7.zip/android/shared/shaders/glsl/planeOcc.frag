#version 450
// PORT-OF: msl/MetalModelSL.source.msl::planeOccF
// MSL-SHA256: 41eb491ce2bab9b4
// Bindings (set0): UBO PlOccU b32 (buffer(0)); tA b0 (linear clamp); tSD b4 depth (NEAREST clamp, .r).
layout(location = 0) in vec2 vUv;
layout(location = 0) out vec4 outColor;
layout(std140, set = 0, binding = 32) uniform PlOccU { mat4 inv; mat4 vp; vec4 p0; vec4 n; vec4 flags; } u;
layout(set = 0, binding = 0) uniform sampler2D tA;
layout(set = 0, binding = 4) uniform sampler2D tSD;
float plDepth(vec2 uv, out bool ok) {
    vec2 nd = vec2(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0);
    vec4 a0 = u.inv * vec4(nd, -1.0, 1.0), a1 = u.inv * vec4(nd, 1.0, 1.0);
    vec3 A = a0.xyz / a0.w, B = a1.xyz / a1.w;
    float den = dot(B - A, u.n.xyz);
    ok = abs(den) > 1e-9;
    float t = ok ? dot(u.p0.xyz - A, u.n.xyz) / den : 0.0;
    vec4 cl = u.vp * vec4(A + (B - A) * t, 1.0);
    return (cl.z + cl.w) * 0.5 / cl.w;
}
void main() {
    vec4 c = texture(tA, vUv);
    if (c.a <= 0.0 || u.flags.x < 0.5) { { outColor = c; return; } }
    bool ok; float pd = plDepth(vUv, ok);
    float md = texture(tSD, vUv).r;
    outColor = (ok && pd > md + 0.0004) ? vec4(0.0) : c; return;      // a model is nearer at this pixel
}
