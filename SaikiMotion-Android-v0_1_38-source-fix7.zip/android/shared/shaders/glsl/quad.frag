#version 450
// PORT-OF: msl/MetalSceneSL.source.msl::quadFragment
// MSL-SHA256: 14940cf710527ec6
// Bindings: set0 b8 UBO QuadU (MSL buffer(0)); tex b0 (linear clamp); mpos/muv SSBOs b1/b2 (vec2[]).
layout(location = 0) in vec2 vUv;
layout(location = 1) in vec2 vLc;
layout(location = 0) out vec4 outColor;
layout(set = 0, binding = 0) uniform sampler2D tex;
layout(std140, set = 0, binding = 8) uniform QuadU {
    vec4 color;     // uColor
    vec4 abcd;      // uMat: a b c d  (Xf affine [a b c d tx ty])
    vec2 t;         // uMat: tx ty
    vec2 quad;      // uQuad (also the shape size)
    float aspect;   // uAspect
    float flipY;    // uFlipY
    float kind;     // uKind
    float corner;   // uCornerRadius
    vec4 rot3;      // 3D: x = uRot.x, y = uRot.y, z = uZ, w = uInvCam
    vec4 flags;     // 3D: x = uUseVP, y = 3D path on (else the exact 2D path)
    vec4 vp0; vec4 vp1; vec4 vp2; vec4 vp3;   // uVP columns (GL column-major)
    vec4 gradP;     // shape gradient knobs x1 y1 x2 y2 (quad space)
    vec4 gradC;     // gradient end colour
    vec4 gradM;     // x = mode (0 off, 1 linear, 2 radial)
} u;
void main() {
    vec2 p = u.flipY > 0.5 ? vec2(vUv.x, 1.0 - vUv.y) : vUv;
    outColor = texture(tex, p) * u.color;
}
