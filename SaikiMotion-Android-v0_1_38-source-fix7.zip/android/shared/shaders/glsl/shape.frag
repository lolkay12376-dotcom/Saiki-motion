#version 450
// PORT-OF: msl/MetalSceneSL.source.msl::shapeFragment
// MSL-SHA256: 14940cf710527ec6
// Bindings: set0 b8 UBO QuadU (MSL buffer(0)); tex b0 (linear clamp); mpos/muv SSBOs b1/b2 (vec2[]).
layout(location = 0) in vec2 vUv;
layout(location = 1) in vec2 vLc;
layout(location = 0) out vec4 outColor;
layout(std140, set = 0, binding = 8) uniform QuadU {
    vec4 color;     // uColor
    vec4 abcd;      // uMat: a b c d  (Xf affine [a b c d tx ty])
    vec2 t;         // uMat: tx ty
    vec2 quad;      // uQuad (also the shape size)
    float aspect;   // uAspect
    float flipY;    // uFlipY
    float kind;     // uKind
    float corner;   // uCornerRadius
    vec4 rot3;      // 3D: x = uRot.x, y = uRot.y, z = uZ, w = uInvCam
    vec4 flags;     // 3D: x = uUseVP, y = 3D path on (else the exact 2D path)
    vec4 vp0; vec4 vp1; vec4 vp2; vec4 vp3;   // uVP columns (GL column-major)
    vec4 gradP;     // shape gradient knobs x1 y1 x2 y2 (quad space)
    vec4 gradC;     // gradient end colour
    vec4 gradM;     // x = mode (0 off, 1 linear, 2 radial)
} u;
float glmod(float x, float y) { return x - y * floor(x / y); }
float sdBox2(vec2 p, vec2 b) { vec2 d = abs(p) - b; return length(max(d, vec2(0.0))) + min(max(d.x, d.y), 0.0); }
float sdPoly(vec2 p, float n, float R) {
    float an = 3.14159265 / n;
    float bn = glmod(atan(p.x, p.y), 2.0 * an) - an;
    vec2 q = length(p) * vec2(cos(bn), abs(sin(bn)));
    q -= R * vec2(cos(an), sin(an));
    q.y += clamp(-q.y, 0.0, R * sin(an));
    return length(q) * sign(q.x);
}
float sdTri(vec2 p, vec2 a, vec2 b, vec2 c) {
    vec2 e0 = b - a; vec2 e1 = c - b; vec2 e2 = a - c;
    vec2 v0 = p - a; vec2 v1 = p - b; vec2 v2 = p - c;
    vec2 pq0 = v0 - e0 * clamp(dot(v0, e0) / dot(e0, e0), 0.0, 1.0);
    vec2 pq1 = v1 - e1 * clamp(dot(v1, e1) / dot(e1, e1), 0.0, 1.0);
    vec2 pq2 = v2 - e2 * clamp(dot(v2, e2) / dot(e2, e2), 0.0, 1.0);
    float s = sign(e0.x * e2.y - e0.y * e2.x);
    vec2 d = min(min(vec2(dot(pq0, pq0), s * (v0.x * e0.y - v0.y * e0.x)),
                     vec2(dot(pq1, pq1), s * (v1.x * e1.y - v1.y * e1.x))),
                     vec2(dot(pq2, pq2), s * (v2.x * e2.y - v2.y * e2.x)));
    return -sqrt(d.x) * sign(d.y);
}
float sdHeart(vec2 p) {
    p.x = abs(p.x);
    if (p.y + p.x > 1.0) { vec2 t = p - vec2(0.25, 0.75); return sqrt(dot(t, t)) - 0.35355339; }
    vec2 a = p - vec2(0.0, 1.0);
    vec2 b = p - 0.5 * max(p.x + p.y, 0.0);
    return sqrt(min(dot(a, a), dot(b, b))) * sign(p.x - p.y);
}
float smin2(float a, float b, float k) { float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0); return mix(b, a, h) - k * h * (1.0 - h); }
float shapeSd(vec2 q, vec2 qs, float kind, float rr, float th) {
    float mm = max(0.5 * min(qs.x, qs.y), 0.0001);
    vec2 p = q / max(qs * 0.5, vec2(0.0001));
    float rn = clamp(rr / mm, 0.0, 0.9);
    float sd = 1.0;
    if (kind < 8.5) {
        float n = 4.0;
        if (kind > 5.5) n = 6.0;
        if (kind > 6.5) n = 5.0;
        if (kind > 7.5) n = 8.0;
        float cv = cos(3.14159265 / n);
        float R = max(1.0 - rn / cv, 0.02);
        sd = sdPoly(p, n, R) - (1.0 - R) * cv;
    } else if (kind < 9.5) {
        float hy = max(th * 0.6, 0.04);
        float sdS = sdBox2(p - vec2(-0.325, 0.0), max(vec2(0.675, hy) - vec2(rn), vec2(0.0))) - rn;
        vec2 cc = vec2(0.4667, 0.0);
        float k = max(1.0 - rn * 1.5, 0.2);
        float sdH = sdTri(p, cc + (vec2(0.2, 0.95) - cc) * k, cc + (vec2(0.2, -0.95) - cc) * k, cc + (vec2(1.0, 0.0) - cc) * k) - rn * 0.7;
        sd = smin2(sdS, sdH, max(rn * 0.3, 0.0001));
    } else if (kind < 10.5) {
        float xc = 0.4 - 0.9 * abs(p.y);
        float band = (abs(p.x - xc) - 0.3) * 0.743;
        float kk = max(rn * 0.5, 0.0001);
        sd = -smin2(-band, 1.0 - abs(p.y), kk);
    } else if (kind < 11.5) {
        float t = clamp(th * 0.5, 0.03, 0.48);
        float a1 = sdBox2(p, max(vec2(1.0, t) - vec2(rn), vec2(0.0))) - rn;
        float a2 = sdBox2(p, max(vec2(t, 1.0) - vec2(rn), vec2(0.0))) - rn;
        sd = smin2(a1, a2, max(rn * 0.6, 0.0001));
    } else if (kind < 12.5) {
        vec2 uu = vec2(p.x * 0.6036, (p.y + 1.0) * 0.5518);
        sd = sdHeart(uu) / 0.58;
    } else if (kind < 13.5) {
        float t = clamp(th, 0.05, 0.95);
        sd = abs(length(p) - (1.0 - t * 0.5)) - t * 0.5;
    } else {
        sd = (length(p) - 1.0) * 0.75;
    }
    return sd * mm;
}
void main() {
    vec2 q = vLc;
    vec2 qs = u.quad;
    float cr = u.corner;
    float a = 0.0;
    if (u.kind < 0.5) {
        a = 1.0;
    } else if (u.kind < 1.5) {
        vec2 d = abs(q) - (qs * 0.5 - vec2(cr));
        float outD = length(max(d, vec2(0.0))) + min(max(d.x, d.y), 0.0) - cr;
        a = 1.0 - smoothstep(-0.004, 0.004, outD);
    } else if (u.kind < 2.5) {
        float m = min(qs.x, qs.y);
        a = 1.0 - smoothstep(0.48 * m, 0.5 * m, length(q));
    } else if (u.kind < 3.5) {
        vec2 v1 = vec2(-qs.x * 0.5, -qs.y * 0.5) - q;
        vec2 v2 = vec2(qs.x * 0.5, -qs.y * 0.5) - q;
        vec2 v3 = q - vec2(-qs.x * 0.5, -qs.y * 0.5);
        float s1 = v1.x * v2.y - v1.y * v2.x;
        float s2 = v2.x * v3.y - v2.y * v3.x;
        float s3 = v3.x * (-v1.y) - v3.y * (-v1.x);
        a = ((s1 >= 0.0 && s2 >= 0.0 && s3 >= 0.0) || (s1 <= 0.0 && s2 <= 0.0 && s3 <= 0.0)) ? 1.0 : 0.0;
    } else if (u.kind > 4.5) {
        a = 1.0 - smoothstep(-0.004, 0.004, shapeSd(q, qs, u.kind, cr, u.flags.z));
    } else {
        float n = 5.0;
        float a0 = atan(q.y, q.x) + 1.5708;
        float seg = 6.2831 / n;
        float m = min(qs.x, qs.y);
        float rIn = 0.22 * m;
        float rOut = 0.5 * m;
        float ang = glmod(a0, seg) - seg * 0.5;
        float rLim = mix(rOut, rIn, abs(ang) / (seg * 0.5));
        a = 1.0 - smoothstep(rLim - 0.01, rLim + 0.01, length(q));
    }
    // same as GL: rgb * a, alpha * a (the colour is not multiplied by its own alpha)
    vec4 col = u.color;
    if (u.gradM.x > 0.5) {
        vec2 h = qs * 0.5;
        vec2 g1 = u.gradP.xy * h, g2 = u.gradP.zw * h;
        float t;
        if (u.gradM.x < 1.5) { vec2 d = g2 - g1; t = dot(q - g1, d) / max(dot(d, d), 1e-6); }
        else { t = length(q - g1) / max(length(g2 - g1), 1e-6); }
        col = mix(u.color, u.gradC, clamp(t, 0.0, 1.0));
    }
    outColor = vec4(col.rgb * a, col.a * a);
}
