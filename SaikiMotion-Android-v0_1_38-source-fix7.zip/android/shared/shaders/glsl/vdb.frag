#version 450
// PORT-OF: msl/MetalVolumeSL.source.msl::vdbFragment
// MSL-SHA256: 881097ab4c24ed7e
// Bindings: set0 b0 vol (linear clamp), b1 dep (NEAREST clamp == volDepthS, depth sampled as sampler2D .r), b2 env, b3 scn (linear clamp), b8 UBO VolU.
layout(location = 0) in vec2 vUv;
layout(location = 0) out vec4 outColor;
layout(set = 0, binding = 0) uniform sampler2D vol;
layout(set = 0, binding = 1) uniform sampler2D dep;
layout(set = 0, binding = 2) uniform sampler2D env;
layout(set = 0, binding = 3) uniform sampler2D scn;
layout(std140, set = 0, binding = 8) uniform VolU {
    vec4 inv0; vec4 inv1; vec4 inv2; vec4 inv3;
    vec4 mvp0; vec4 mvp1; vec4 mvp2; vec4 mvp3;
    vec4 bnd;     // uB.xyz
    vec4 color;   // uColor
    vec4 prm;     // dens, bright, envOn, surround
    vec4 flg;     // useDepth
    vec4 lp0; vec4 lp1; vec4 lp2;   // light ball: xyz local pos, w radius
    vec4 lc0; vec4 lc1; vec4 lc2;   // light color * intensity
    vec4 la0; vec4 la1; vec4 la2;   // atmosphere color * amount
    vec4 lcnt;                      // x = light count
    vec4 edge;                      // rgb edge colour, a = amount
} u;
vec2 flipV(vec2 uv) { return vec2(uv.x, 1.0 - uv.y); }

vec3 volEnvAt(vec3 dir) {
    dir = normalize(dir);
    vec2 uv = vec2(atan(dir.z, dir.x) * 0.15915494 + 0.5, asin(clamp(dir.y, -1.0, 1.0)) * 0.31830989 + 0.5);
    return texture(env, uv).rgb;
}
vec3 volSurroundAt(vec2 uv) {
    vec3 a = vec3(0.0);
    for (int i = 0; i < 8; i++) {
        float ang = float(i) * 0.7853982;
        vec2 q = clamp(uv + vec2(cos(ang), sin(ang)) * 0.12, 0.0, 1.0);
        a += texture(scn, flipV(q)).rgb;
    }
    return a / 8.0;
}
float volSamp(vec3 q) {
    q = clamp(q, 0.0, 1.0);
    float fz = q.z * 127.0;
    float z0 = floor(fz);
    float z1 = min(z0 + 1.0, 127.0);
    vec2 xy = q.xy * 127.0 + 0.5;
    vec2 t0 = (vec2(mod(z0, 16.0), floor(z0 / 16.0)) * 128.0 + xy) / vec2(2048.0, 1024.0);   // fmod==mod (z0 >= 0)
    vec2 t1 = (vec2(mod(z1, 16.0), floor(z1 / 16.0)) * 128.0 + xy) / vec2(2048.0, 1024.0);
    float s = mix(texture(vol, t0).r, texture(vol, t1).r, fz - z0);
    vec3 e3 = min(q, 1.0 - q);
    float fade = smoothstep(0.0, 0.1, min(e3.x, min(e3.y, e3.z)));
    return s * s * fade;
}
float vH(vec3 p) { p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
float vN(vec3 x) {
    vec3 i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mix(vH(i), vH(i + vec3(1.0, 0.0, 0.0)), f.x), mix(vH(i + vec3(0.0, 1.0, 0.0)), vH(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
               mix(mix(vH(i + vec3(0.0, 0.0, 1.0)), vH(i + vec3(1.0, 0.0, 1.0)), f.x), mix(vH(i + vec3(0.0, 1.0, 1.0)), vH(i + vec3(1.0, 1.0, 1.0)), f.x), f.y), f.z);
}
// Henyey-Greenstein, normalised so an isotropic phase = 1
float vHG(float c, float g) { float g2 = g * g; return (1.0 - g2) / pow(max(1.0 + g2 - 2.0 * g * c, 1e-3), 1.5); }
// dual lobe: strong forward silver lining + soft back scatter
float vPhase(float c) { return mix(vHG(c, -0.2), vHG(c, 0.6), 0.35); }
void main() {
    mat4 inv = mat4(u.inv0, u.inv1, u.inv2, u.inv3);
    mat4 mvp = mat4(u.mvp0, u.mvp1, u.mvp2, u.mvp3);
    vec3 uB = u.bnd.xyz;
    float uDens = u.prm.x, uBright = u.prm.y, uEnvOn = u.prm.z, uSurround = u.prm.w;
    vec2 ndc = vUv * 2.0 - 1.0;
    vec4 n4 = inv * vec4(ndc, -1.0, 1.0);
    vec4 f4 = inv * vec4(ndc, 1.0, 1.0);
    vec3 o = n4.xyz / n4.w;
    vec3 d = f4.xyz / f4.w - o;
    vec3 h = uB * 0.5;
    vec3 rd = 1.0 / (d + vec3(1e-6));
    vec3 t1 = (-h - o) * rd;
    vec3 t2 = (h - o) * rd;
    vec3 tn = min(t1, t2);
    vec3 tf = max(t1, t2);
    float t0 = max(max(max(tn.x, tn.y), tn.z), 0.0);
    float t3 = min(min(tf.x, tf.y), tf.z);
    if (t3 <= t0) { outColor = vec4(0.0); return; }
    float sceneZ = u.flg.x > 0.5 ? texture(dep, flipV(vUv)).r : 1.0;
    float NS = clamp(u.flg.z, 16.0, 160.0);
    float dt = (t3 - t0) / NS;
    float seg = dt * length(d) / max(max(uB.x, uB.y), uB.z) * 8.0;
    float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));   // interleaved gradient noise: kills banding/streaks
    vec3 L = normalize(vec3(0.3, 1.0, 0.4)) * 0.06;
    float T = 1.0;
    vec3 col = vec3(0.0);
    vec3 amb = vec3(0.0);
    if (uEnvOn > 0.5) { amb = 0.5 * (volEnvAt(d) + volEnvAt(vec3(0.0, 1.0, 0.0))); }
    if (uSurround > 0.5) { amb += volSurroundAt(vUv); }
    float ambOn = (uEnvOn > 0.5 || uSurround > 0.5) ? 1.0 : 0.0;
    for (int i = 0; i < int(NS); i++) {
        vec3 pos = o + d * (t0 + (float(i) + jit) * dt);
        if (sceneZ < 1.0) {
            vec4 c = mvp * vec4(pos, 1.0);
            if (c.z / c.w * 0.5 + 0.5 > sceneZ - 0.0002) { break; }
        }
        vec3 q = pos / uB + 0.5;
        float raw = max(volSamp(q), 0.0);
        if (u.lcnt.y > 0.5 && raw > 0.002) {
            // cloud detail: the 128^3 lattice only holds the big shape. Billowy + wispy noise eats the edges
            // (Schneider-style erosion: thin parts vanish first, the dense core survives) so the surface is crisp
            // cauliflower instead of a soft blob, at any zoom.
            vec3 wq = q * vec3(9.0, 7.0, 9.0) + vec3(3.1, 1.7, 5.3);
            float dn = vN(wq) * 0.50 + vN(wq * 2.3) * 0.30 + vN(wq * 5.1) * 0.20;
            float er = dn * 0.42;
            raw = clamp((raw - er * (1.0 - raw * 0.35)) / (1.0 - er), 0.0, 1.0);
        }
        float den = pow(raw, u.flg.w) * uDens;
        if (den > 0.002) {
            float lt = volSamp(q + L * 1.5) + volSamp(q + L * 4.0);
            if (u.lcnt.y > 0.5) { lt += volSamp(q + L * 9.0) * 1.5; }
            vec3 lightSum = vec3(0.0);
            vec3 atmSum = vec3(0.0);
            for (int k = 0; k < 3; k++) {
                if (float(k) >= u.lcnt.x) { break; }
                vec4 lp = k == 0 ? u.lp0 : (k == 1 ? u.lp1 : u.lp2);
                vec3 lc = k == 0 ? u.lc0.xyz : (k == 1 ? u.lc1.xyz : u.lc2.xyz);
                vec3 la = k == 0 ? u.la0.xyz : (k == 1 ? u.la1.xyz : u.la2.xyz);
                vec3 dl = lp.xyz - pos;
                float r2 = lp.w * lp.w;
                float att = r2 / (r2 + dot(dl, dl));
                float occ = 0.0;
                for (int j = 0; j < 4; j++) { occ += volSamp((pos + dl * (0.1 + 0.2 * float(j))) / uB + 0.5); }
                lightSum += lc * att * exp(-occ * uDens * 1.2 * u.flg.y);
                atmSum += la * att;
            }
            float baseK = u.lcnt.x > 0.5 ? 0.35 : 1.0;
            float sh = exp(-lt * uDens * 2.4 * u.flg.y);
            float ex = exp(-den * seg);
            vec3 shade = ((0.3 + 0.8 * sh) * (1.0 - 0.6 * ambOn) + ambOn * (0.15 + 1.2 * sh) * amb) * baseK;
            if (u.lcnt.y > 0.5) {
                // Photoreal cumulus lighting: 5-tap sun march with growing steps -> Beer-Lambert, three-octave
                // multiple-scattering (keeps shadowed cores lit instead of black), dual-lobe HG phase (bright silver
                // rims toward the sun), powder term (dark thin edges), sky-blue ambient that fades toward the base.
                vec3 Ls = normalize(vec3(0.3, 1.0, 0.4));
                vec3 Lq = normalize(Ls / uB);
                float od = 0.0, acc = 0.0;
                const float stps[5] = float[5](0.012, 0.025, 0.05, 0.10, 0.20);
                for (int k = 0; k < 5; k++) { acc += stps[k]; od += volSamp(q + Lq * acc) * stps[k]; }
                od *= uDens * 5.5 * u.flg.y;
                float cosT = clamp(dot(normalize(d), Ls), -1.0, 1.0);
                float sunE = 0.0, ma = 1.0, mb = 1.0, mc = 1.0;
                for (int oc = 0; oc < 3; oc++) { sunE += ma * exp(-od * mb) * vPhase(cosT * mc); ma *= 0.5; mb *= 0.5; mc *= 0.5; }
                float powder = mix(1.0, 1.0 - exp(-raw * 7.0), 0.55);
                float hgt = clamp((q.y - 0.12) * 1.5, 0.0, 1.0);
                vec3 skyAmb = mix(vec3(0.30, 0.38, 0.54), vec3(0.66, 0.75, 0.92), hgt);
                float sunA = exp(-od);
                shade = vec3(1.0, 0.965, 0.90) * sunE * powder * 0.46 + skyAmb * (0.85 + 0.3 * sunA);
                if (ambOn > 0.5) { shade *= (0.6 + 0.55 * amb); }
                shade += vec3(0.10) * pow(sunA, 3.0) * (1.0 - clamp(den, 0.0, 1.0));
                shade = shade / (1.0 + shade * 0.12);
            }
            if (u.lcnt.z > 0.5) {      // mist: brighter toward the top of the layer, soft forward-scattered glow toward the sun
                float sunPh = pow(clamp(dot(normalize(d), normalize(vec3(0.3, 0.5, 0.4))), 0.0, 1.0), 6.0);
                shade = shade * (0.78 + 0.4 * clamp(q.y, 0.0, 1.0)) + vec3(1.0, 0.93, 0.8) * sunPh * 0.45 * sh;
            }
            shade += lightSum * 2.0 + atmSum;
            vec3 cTint = mix(u.color.rgb, u.edge.rgb, u.edge.a * (1.0 - clamp(den * 1.6, 0.0, 1.0)));
            col += T * (1.0 - ex) * cTint * shade * uBright;
            T *= ex;
            if (T < 0.02) { break; }
        }
    }
    outColor = vec4(col * u.bnd.w, (1.0 - T) * u.bnd.w);
}
