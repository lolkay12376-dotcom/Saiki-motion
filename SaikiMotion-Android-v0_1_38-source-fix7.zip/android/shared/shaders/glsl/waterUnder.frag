#version 450
// PORT-OF: msl/MetalModelSL.source.msl::waterUnderF
// MSL-SHA256: 41eb491ce2bab9b4
// Bindings (set0): UBO ModelU b32 (buffer(0)); UBO WInv b39 (buffer(1) float4x4 inverse view-projection);
// tSD b4 depth (NEAREST clamp, .r), tScene b5 (linear clamp).
layout(location = 0) in vec2 vUv;
layout(location = 0) out vec4 outColor;
layout(std140, set = 0, binding = 32) uniform ModelU {
    vec4 vp0; vec4 vp1; vec4 vp2; vec4 vp3;     // uVP columns
    vec4 m0; vec4 m1; vec4 m2; vec4 m3;         // uModel columns
    vec4 color;     // uColor
    vec4 emis;      // uEmis.xyz
    vec4 eye;       // uEye.xyz
    vec4 prm;       // metal, rough, cutoff, unlit
    vec4 has;       // base, metal-rough, emissive, occlusion texture present
    vec4 opt;       // env, metallic reflectivity, view mode, ao strength
    vec4 xtra;      // exposure, rt ao, rt shadow, pbr bump strength
    vec4 lp0; vec4 lp1; vec4 lp2;     // scene point lights: world pos
    vec4 lc0; vec4 lc1; vec4 lc2;     // rgb * intensity (w = 1 when active)
    vec4 pg;        // procedural pbr: on, parallax depth, uv scale x, uv scale y
    vec4 wa;        // water: on, time, wave height, wave frequency
    vec4 wb;        // water: speed, foam, depth, choppiness
    vec4 wc;        // water: clarity, turbidity, refraction, subsurface
    vec4 wd;        // water: glint, detail, flow dir (rad), procedural seabed
    vec4 we;        // water: wave variation, swell, swell length, whitecaps
    vec4 wf;        // water: base y, reflect, scene depth available, rays
    vec4 wg;        // water rays: strength, length, sharpness, speed
    vec4 wh;        // water collision: rocks, shores, foam width, 0
    vec4 wi;        // water colours: shallow rgb, custom on
    vec4 wj;        // water colours: middle rgb, stop count (2 or 3)
    vec4 wk;        // water colours: deep rgb, gradient mode (0 depth, 1 bands, 2 patches)
    vec4 wl;        // water colours: gradient scale
    vec4 envp;      // HDRI environment: on, rotation (turns), max mip, gain
    vec4 sp0;       // terrain splat: on, layer count, 0, 0
    vec4 sp1;       // splat tiling per layer
    vec4 sp2;       // splat normal strength per layer
    vec4 pm;        // imported PBR maps: normal, roughness, metallic, height present
    vec4 pn;        // opacity map present, normal strength, normal Y sign, displacement amount (world units)
    vec4 pt;        // texture tiling u, v, parallax depth, height mid-point
    vec4 xr;        // x-ray view (editor preview only): on, rim power, base opacity, 0
    vec4 pq;        // roughness multiplier, metallic multiplier, emissive strength, maps on
    vec4 pr;        // clear coat, clear coat roughness, AO strength
    vec4 pnm;       // embedded (per-material) normal map: on, strength, green sign, 0
    vec4 ptc;       // point map: size px (0 = not a point map), anim mode, anim amount, time
} u;
layout(std140, set = 0, binding = 39) uniform WInv { mat4 m; } inv;
layout(set = 0, binding = 4) uniform sampler2D tSD;
layout(set = 0, binding = 5) uniform sampler2D tScene;
float mHash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float mVn(vec2 p) {
    vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(mHash(i), mHash(i + vec2(1.0, 0.0)), f.x), mix(mHash(i + vec2(0.0, 1.0)), mHash(i + vec2(1.0, 1.0)), f.x), f.y);
}
// Sharpened sine waves (Gerstner-like crests). Directions, frequencies and phases are jittered and domain-warped,
// amplitude is modulated at a large scale, so the pattern never visibly tiles. Returns height, gradient in g.
vec2 mH2(vec2 p) { return vec2(mHash(p), mHash(p + 17.3)); }
float wCell(vec2 p) {      // cellular distance: bubble walls
    vec2 i = floor(p), f = fract(p); float m = 8.0;
    for (int y = -1; y <= 1; y++) { for (int x = -1; x <= 1; x++) {
        vec2 g = vec2(float(x), float(y)); vec2 r = g + mH2(i + g) * 0.9 - f; m = min(m, dot(r, r)); } }
    return sqrt(m);
}
float wFoamT(vec2 p, float tt) {      // lacy foam: warped streaks + two scales of bubble walls
    vec2 wv = vec2(mVn(p * 1.3 + tt * 0.15), mVn(p * 1.3 + 9.0 - tt * 0.12)) - 0.5;
    p += wv * 1.3;
    float f = mVn(p * 2.0) * 0.45 + mVn(p * 5.0 + 3.0) * 0.3 + mVn(p * 12.0) * 0.25;
    float b1 = smoothstep(0.18, 0.62, wCell(p * 8.0 + tt * 0.06));
    float b2 = mVn(p * 31.0 - tt * 0.05 + 5.0);
    return smoothstep(0.22, 0.8, f * 0.5 + b1 * 0.35 + b2 * 0.2);
}
float wBeam(vec2 sp, float t, float wid) {      // sunbeams that pass through the moving surface
    float pat = mVn(sp * 1.1 + t * 0.25) * 0.65 + mVn(sp * 2.7 - t * 0.35 + 8.0) * 0.35;
    return pow(clamp(pat * 1.7 - 0.45, 0.0, 1.0), mix(1.2, 4.0, clamp(wid * 0.5, 0.0, 1.0)));
}
float wMean(float k) { float k2 = k * k; return exp(-k) * (1.0 + k2 * (0.25 + k2 * (0.015625 + k2 * (0.000434 + k2 * 0.0000068)))); }      // mean of exp((sin-1)k)
float wvH(vec2 p, float t, float amp, float freq, float spd, float chop, float dirA, float vari, vec2 sw, int nw, out vec2 g) {
    float k = mix(0.7, 2.6, chop);
    float zone = mix(0.6, 1.4, mVn(p * 0.03 + 19.0));      // calm / rough areas: far water differs from near water
    float am = mix(1.0, 0.45 + 1.1 * mVn(p * 0.09 + 7.0), vari);
    float wph = (mVn(p * 0.17 + 3.0) - 0.5) * 3.0 * vari;
    float h = 0.0, a = amp * am, f = freq, w = 1.0;
    g = vec2(0.0);
    for (int i = 0; i < nw; i++) {
        float fi = float(i);
        float ang = dirA + fi * 0.83 + sin(fi * 5.1 + 1.0) * 0.7 * (0.4 + vari);
        vec2 d = vec2(cos(ang), sin(ang));
        float fr = f * (1.0 + 0.21 * sin(fi * 7.3));
        float ph = dot(d, p) * fr + t * spd * w * 1.6 + fi * 1.7 + wph * (0.4 + 0.3 * fi);
        float e = exp((sin(ph) - 1.0) * k);
        h += a * (e - wMean(k));
        g += a * e * k * cos(ph) * fr * d;
        a *= 0.58; f *= 1.8; w *= 1.2;
    }
    for (int j = 0; j < 3; j++) {      // long rounded swells on their own headings
        float fj = float(j);
        float ang = dirA + 2.1 + fj * 1.9;
        vec2 d = vec2(cos(ang), sin(ang));
        float fr = freq * sw.y * (1.0 + 0.45 * fj);
        float ph = dot(d, p) * fr + t * spd * (0.8 + 0.25 * fj) + fj * 2.3 + wph * 0.5;
        float e = exp((sin(ph) - 1.0) * 0.9);
        float sa = amp * sw.x * zone * (1.0 - 0.25 * fj) * 2.2;
        h += sa * (e - 0.4934);
        g += sa * e * 0.9 * cos(ph) * fr * d;
    }
    return h;
}
const float mPI = 3.14159265;
const vec3 mL1 = vec3(0.4170, 0.6672, 0.6672);
const vec3 mL2 = vec3(-0.8704, 0.2176, 0.4352);

vec3 mEnv(vec3 d, float r) {
    float h = d.y * 0.5 + 0.5;
    vec3 c = mix(vec3(0.14, 0.13, 0.15), vec3(0.78, 0.80, 0.84), smoothstep(0.0, 0.5, h));
    c = mix(c, vec3(0.55, 0.68, 0.95), smoothstep(0.5, 1.0, h));
    float sun = pow(max(dot(d, mL1), 0.0), mix(150.0, 5.0, r)) * mix(8.0, 0.6, r);
    return c + vec3(1.0, 0.93, 0.82) * sun;
}

vec3 mEnvT(vec3 d, float r, sampler2D t, vec4 ep) {   // tEnv: linear + mip linear + REPEAT
    if (ep.x < 0.5) { return mEnv(d, r); }
    float uu = atan(d.z, d.x) * 0.15915494 + 0.5 + ep.y;
    float v = 0.5 - asin(clamp(d.y, -1.0, 1.0)) * 0.31830989;
    vec3 c = textureLod(t, vec2(uu, v), sqrt(r) * ep.z).rgb;
    return min(max(c, vec3(0.0)), vec3(40.0)) * ep.w;
}

vec3 mBrdf(vec3 N, vec3 V, vec3 L, vec3 diffC, vec3 F0, float r) {
    vec3 H = normalize(V + L);
    float NdL = max(dot(N, L), 0.0);
    float NdV = max(dot(N, V), 0.001);
    float NdH = max(dot(N, H), 0.0);
    float VdH = max(dot(V, H), 0.0);
    float a = r * r;
    float a2 = a * a;
    float dd = NdH * NdH * (a2 - 1.0) + 1.0;
    float D = a2 / (mPI * dd * dd + 0.0001);
    float Vis = 0.5 / max(NdL * sqrt(NdV * NdV * (1.0 - a2) + a2) + NdV * sqrt(NdL * NdL * (1.0 - a2) + a2), 1e-4);      // height-correlated Smith GGX
    vec3 F = F0 + (1.0 - F0) * pow(1.0 - VdH, 5.0);
    vec3 spec = D * Vis * F;
    return ((1.0 - F) * diffC / mPI + spec) * NdL;
}

float mLin(float d) { return 1000.0 / (10000.05 - (2.0 * d - 1.0) * 9999.95); }      // depth buffer -> view distance (near 0.05, far 10000)
vec3 wAbsorb() { return vec3(0.45, 0.09, 0.05) * mix(3.0, 0.4, u.wc.x) + u.wc.y * 0.5; }      // per metre
float wCaus(vec2 sq, float tt) {
    float c1 = mVn(sq * 1.6 + vec2(tt * 0.5, tt * 0.3)), c2 = mVn(sq * 2.1 - vec2(tt * 0.4, -tt * 0.55) + 5.0);
    return pow(clamp(1.0 - abs(c1 - c2) * 3.4, 0.0, 1.0), 7.0);
}
vec3 wFog(float depthCam) {      // display-space colour of the water column; darker the deeper the camera
    float k = 1.0 - exp(-depthCam * 0.15);
    if (u.wi.w > 0.5) {      // custom water colours: the underwater fog fades from the shallow colour to the deep colour
        vec3 mid = u.wj.w > 2.5 ? u.wj.rgb : mix(u.wi.rgb, u.wk.rgb, 0.5);
        vec3 fc = k < 0.5 ? mix(u.wi.rgb, mid, k * 2.0) : mix(mid, u.wk.rgb, k * 2.0 - 1.0);
        return fc * mix(0.65, 0.2, k);
    }
    vec3 base = mix(vec3(0.10, 0.45, 0.48), vec3(0.01, 0.06, 0.11), k);
    float cmx = max(u.color.r, max(u.color.g, u.color.b)), cmn = min(u.color.r, min(u.color.g, u.color.b));
    if (cmx - cmn > 0.05) { return dot(base, vec3(0.3, 0.6, 0.1)) * 1.8 * (u.color.rgb / max(cmx, 1e-3)); }      // a tinted layer colour recolours the water, not just darkens the blue
    return base;
}
void main() {
    vec2 nd = vec2(vUv.x * 2.0 - 1.0, 1.0 - vUv.y * 2.0);
    float d = u.wf.z > 0.5 ? texture(tSD, vUv).r : 1.0;
    vec4 pw = inv.m * vec4(nd, d * 2.0 - 1.0, 1.0);
    vec3 wp = pw.xyz / pw.w;
    bool hit = d < 0.9999999;
    float dist = hit ? length(wp - u.eye.xyz) : 80.0;
    vec3 dir = normalize(wp - u.eye.xyz);
    float depthCam = max(u.wf.x - u.eye.y, 0.0);
    vec3 Tp = pow(exp(-wAbsorb() * dist), vec3(0.4545));
    vec3 sc = clamp(texture(tScene, vUv).rgb, vec3(0.0), vec3(4.0));
    vec3 col = sc * Tp + wFog(depthCam) * (1.0 - Tp);
    float t = u.wa.y * u.wb.x;
    float s = (u.wf.x - u.eye.y) / max(dir.y, 0.05);
    vec2 hp = u.eye.xz + dir.xz * s;
    float sh = pow(clamp(mVn(hp * 0.8 + t * 0.2) * 1.6 - 0.35, 0.0, 1.0), 2.0) * mVn(hp * 0.25 - t * 0.1 + 4.0);
    col += vec3(0.55, 0.85, 0.8) * sh * smoothstep(-0.1, 0.5, dir.y) * (1.0 - exp(-dist * 0.12)) * exp(-depthCam * 0.12) * u.eye.w * u.wc.w * 0.5 * (u.wf.w > 0.5 ? 0.3 : 1.0);
    if (u.wf.w > 0.5) {      // Rays: volumetric shafts in the water + the same beams landing on whatever is underwater
        float rt = t * u.wg.w, rstr = u.wg.x;
        float Ly = max(mL1.y, 0.15);
        float maxD = min(dist, 28.0 * u.wg.y);
        float acc = 0.0;
        const int NR = 10;
        float jit = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
        for (int i = 0; i < NR; i++) {
            float st = (float(i) + jit) / float(NR) * maxD;
            vec3 q = u.eye.xyz + dir * st;
            float dpt = u.wf.x - q.y;
            if (dpt < 0.0) { continue; }
            acc += wBeam(q.xz + mL1.xz / Ly * dpt, rt, u.wg.z) * exp(-dpt * 0.11 / max(u.wg.y, 0.2));
        }
        acc *= maxD / float(NR) * 0.18;
        float fwd = 0.45 + 0.55 * pow(clamp(dot(dir, mL1), 0.0, 1.0), 2.0);
        float lightK = max(u.eye.w, 0.3);
        col += vec3(0.50, 0.85, 0.78) * acc * fwd * lightK * rstr * (1.0 - 0.6 * (1.0 - exp(-depthCam * 0.08)));
        if (hit && wp.y < u.wf.x) {      // beams hit the ground, even in shallow water, and light it up with a soft glow beside them
            float dg = u.wf.x - wp.y;
            vec2 sg = wp.xz + mL1.xz / Ly * dg;
            float bg = wBeam(sg, rt, u.wg.z) * exp(-dg * 0.11 / max(u.wg.y, 0.2));
            float glow = wBeam(sg * 0.4, rt * 0.7, 0.2) * exp(-dg * 0.09);
            col += (sc * Tp * 2.2 + vec3(0.35, 0.6, 0.55) * 0.35) * bg * lightK * rstr + vec3(0.25, 0.5, 0.46) * glow * 0.18 * lightK * rstr * Tp;
        }
    }
    { outColor = vec4(col, 1.0); return; }
}
