#version 450
// PORT-OF: msl/MetalModelSL.source.msl::waterUnderV
// MSL-SHA256: 41eb491ce2bab9b4
layout(location = 0) out vec2 vUv;
void main() {
    uint vid = uint(gl_VertexIndex);
    vec2 p = vec2(float((vid << 1) & 2u), float(vid & 2u));
    gl_Position = vec4(p * 2.0 - 1.0, 0.5, 1.0); vUv = vec2(p.x, 1.0 - p.y);
}
