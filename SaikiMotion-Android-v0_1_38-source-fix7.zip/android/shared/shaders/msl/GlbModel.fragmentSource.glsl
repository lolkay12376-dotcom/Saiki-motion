// SOURCE: Sources/Render/GlbModel.swift  (GlbModel.fragmentSource)  prefix: -
precision highp float;
varying vec3 vN;
varying vec3 vW;
varying vec2 vUv;
varying vec4 vCol;
uniform vec4 uColor;
uniform vec3 uEmis;
uniform vec3 uEye;
uniform float uMetal, uRough, uCutoff, uUnlit;
uniform vec4 uHas;   // x base tex, y metal-rough tex, z emissive tex, w occlusion tex
uniform vec4 uOpt;   // x environment on, y metallic reflectivity on, z view mode, w occlusion strength
uniform sampler2D uTexOcc;
uniform sampler2D uTexBase;
uniform sampler2D uTexMR;
uniform sampler2D uTexEm;
const float PI = 3.14159265;
const vec3 L1 = vec3(0.4170, 0.6672, 0.6672);
const vec3 L2 = vec3(-0.8704, 0.2176, 0.4352);

vec3 envC(vec3 d, float r) {
    float h = d.y * 0.5 + 0.5;
    vec3 c = mix(vec3(0.14, 0.13, 0.15), vec3(0.78, 0.80, 0.84), smoothstep(0.0, 0.5, h));
    c = mix(c, vec3(0.55, 0.68, 0.95), smoothstep(0.5, 1.0, h));
    float sun = pow(max(dot(d, L1), 0.0), mix(150.0, 5.0, r)) * mix(8.0, 0.6, r);
    return c + vec3(1.0, 0.93, 0.82) * sun;
}

vec3 brdf(vec3 N, vec3 V, vec3 L, vec3 diffC, vec3 F0, float r) {
    vec3 H = normalize(V + L);
    float NdL = max(dot(N, L), 0.0);
    float NdV = max(dot(N, V), 0.001);
    float NdH = max(dot(N, H), 0.0);
    float VdH = max(dot(V, H), 0.0);
    float a = r * r;
    float a2 = a * a;
    float dd = NdH * NdH * (a2 - 1.0) + 1.0;
    float D = a2 / (PI * dd * dd + 0.0001);
    float k = (r + 1.0) * (r + 1.0) / 8.0;
    float G = (NdL / (NdL * (1.0 - k) + k)) * (NdV / (NdV * (1.0 - k) + k));
    vec3 F = F0 + (1.0 - F0) * pow(1.0 - VdH, 5.0);
    vec3 spec = D * G * F / max(4.0 * NdV * NdL, 0.001);
    return ((1.0 - F) * diffC / PI + spec) * NdL;
}

void main() {
    float a = uColor.a * vCol.a;
    vec3 tint = uColor.rgb * pow(max(vCol.rgb, vec3(0.0)), vec3(2.2));
    vec3 alb = tint;
    if (uHas.x > 0.5) {
        vec4 t = texture2D(uTexBase, vUv);
        a *= t.a;
        alb *= pow(clamp(t.rgb / max(t.a, 0.001), 0.0, 1.0), vec3(2.2));
    }
    if (uCutoff >= 0.0) {
        if (a < uCutoff) { discard; }
        a = 1.0;
    }
    float metal = uMetal * uOpt.y;
    float rough = uRough;
    float ao = 1.0;
    if (uHas.w > 0.5) { ao = mix(1.0, texture2D(uTexOcc, vUv).r, uOpt.w); }
    if (uHas.y > 0.5) {
        vec4 m = texture2D(uTexMR, vUv);
        rough *= m.g;
        metal *= m.b * uOpt.y;
    }
    rough = clamp(rough, 0.04, 1.0);
    metal = clamp(metal, 0.0, 1.0);

    vec3 N = normalize(vN);
    vec3 V = normalize(uEye - vW);
    if (dot(N, V) < 0.0) { N = -N; }
    float NdV = max(dot(N, V), 0.001);

    vec3 F0 = mix(vec3(0.04), alb, metal);
    vec3 diffC = alb * (1.0 - metal);
    vec3 col = brdf(N, V, L1, diffC, F0, rough) * vec3(3.2, 3.0, 2.8) * 1.0
             + brdf(N, V, L2, diffC, F0, rough) * vec3(0.9, 1.0, 1.3);
    vec3 R = reflect(-V, N);
    vec3 Fr = F0 + (max(vec3(1.0 - rough), F0) - F0) * pow(1.0 - NdV, 5.0);
    if (uOpt.x > 0.5) {
        col += diffC * envC(N, 1.0) * 0.8 * ao;
        col += envC(R, rough) * Fr * (1.0 - 0.5 * rough) * ao;
    } else {
        col += diffC * 0.3 * ao;
    }
    vec3 em = uEmis;
    if (uHas.z > 0.5) { em *= pow(texture2D(uTexEm, vUv).rgb, vec3(2.2)); }
    col += em;
    col = mix(col, alb + em, uUnlit);
    if (uOpt.z > 0.5) {   // PBR texture viewer
        vec3 v = alb;
        if (uOpt.z > 1.5) { v = vec3(rough); }
        if (uOpt.z > 2.5) { v = vec3(metal); }
        if (uOpt.z > 3.5) { v = vec3(ao); }
        if (uOpt.z > 4.5) { v = em; }
        gl_FragColor = vec4(pow(max(v, vec3(0.0)), vec3(1.0 / 2.2)) * a, a);
        return;
    }
    col = col * (1.0 + col / 6.0) / (1.0 + col);          // soft highlight roll-off
    col = pow(max(col, vec3(0.0)), vec3(1.0 / 2.2));
    gl_FragColor = vec4(col * a, a);
}
