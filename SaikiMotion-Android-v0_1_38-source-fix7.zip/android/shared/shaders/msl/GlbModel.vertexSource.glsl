// SOURCE: Sources/Render/GlbModel.swift  (GlbModel.vertexSource)  prefix: -
attribute vec3 aPos;
attribute vec3 aNormal;
attribute vec2 aUv;
attribute vec4 aCol;
uniform mat4 uVP;
uniform mat4 uModel;
varying vec3 vN;
varying vec3 vW;
varying vec2 vUv;
varying vec4 vCol;
void main() {
    vec4 w = uModel * vec4(aPos, 1.0);
    gl_Position = uVP * w;
    gl_PointSize = 3.0;
    vW = w.xyz;
    vec3 n = uModel[0].xyz * aNormal.x + uModel[1].xyz * aNormal.y + uModel[2].xyz * aNormal.z;
    vN = dot(n, n) > 1e-8 ? normalize(n) : vec3(0.0, 1.0, 0.0);
    vUv = aUv;
    vCol = aCol;
}
