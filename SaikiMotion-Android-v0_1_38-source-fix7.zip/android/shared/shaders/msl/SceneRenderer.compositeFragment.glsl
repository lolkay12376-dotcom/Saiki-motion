// SOURCE: Sources/Render/SceneRenderer.swift  (SceneRenderer.compositeFragment)  prefix: -
precision highp float;
varying vec2 vUv;
uniform sampler2D uScene;
uniform sampler2D uSrc;
uniform sampler2D uMask;
uniform float uAlpha;
uniform float uMode;      // 0 normal 1 add 2 screen 3 multiply 4 accumulate 5 running average
uniform float uMaskMode;  // 0 none 1 alpha 2 inv alpha 3 luma 4 inv luma
uniform float uRgbShift;
void main() {
    vec4 s = texture2D(uSrc, vUv);
    if (uRgbShift != 0.0) {
        s.r = texture2D(uSrc, clamp(vUv + vec2(uRgbShift, 0.0), 0.0, 1.0)).r;
        s.b = texture2D(uSrc, clamp(vUv - vec2(uRgbShift, 0.0), 0.0, 1.0)).b;
    }
    vec4 sRaw = s;
    s *= uAlpha;
    if (uMode > 4.5 && uMode < 9.5) {
        // running average: acc = mix(acc, sample, 1/(i+1)). Keeps full precision in 8-bit
        // targets (additive 1/N accumulation rounds dim pixels to 0 → visible opacity steps)
        gl_FragColor = mix(texture2D(uScene, vUv), sRaw, uAlpha);
        return;
    }
    if (uMaskMode > 0.5) {
        vec4 mk = texture2D(uMask, vUv);
        float m = 1.0;
        if (uMaskMode < 1.5) { m = mk.a; }
        else if (uMaskMode < 2.5) { m = 1.0 - mk.a; }
        else if (uMaskMode < 3.5) { m = dot(mk.rgb, vec3(0.299, 0.587, 0.114)); }
        else { m = 1.0 - dot(mk.rgb, vec3(0.299, 0.587, 0.114)); }
        s *= m;
    }
    if (uMode > 98.5) { gl_FragColor = s; return; }      // matte pass: masked source only
    vec4 d = texture2D(uScene, vUv);
    if (uMode < 0.5) {
        gl_FragColor = s + d * (1.0 - s.a);
    } else if (uMode < 1.5) {
        gl_FragColor = d + s;
    } else if (uMode < 2.5) {
        vec3 scr = 1.0 - (1.0 - d.rgb) * (1.0 - s.rgb);
        gl_FragColor = mix(d, vec4(scr, max(d.a, s.a)), s.a);
    } else if (uMode < 3.5) {
        vec3 mul = d.rgb * s.rgb;
        gl_FragColor = mix(d, vec4(mul, d.a * s.a), s.a);
    } else {
        gl_FragColor = d + s;
    }
}
