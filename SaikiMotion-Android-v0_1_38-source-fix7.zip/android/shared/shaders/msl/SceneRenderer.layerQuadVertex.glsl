// SOURCE: Sources/Render/SceneRenderer.swift  (SceneRenderer.layerQuadVertex)  prefix: -
attribute vec2 aPos;
attribute vec2 aUv;
uniform float uMesh;
uniform mat3 uMat;
uniform vec2 uQuad;
uniform float uAspect;
uniform vec3 uRot;
uniform float uZ;
uniform float uInvCam;
uniform mat4 uVP;
uniform float uUseVP;
varying vec2 vUv;
void main() {
    vec2 pu = aPos * 0.5 + 0.5;
    vUv = uMesh > 0.5 ? aUv : pu;
    vec2 w = (uMat * vec3((pu - 0.5) * uQuad, 1.0)).xy;
    vec2 c = (uMat * vec3(0.0, 0.0, 1.0)).xy;
    vec3 o = vec3(w - c, 0.0);
    float cy = cos(uRot.y), sy = sin(uRot.y);
    o = vec3(o.x * cy + o.z * sy, o.y, -o.x * sy + o.z * cy);
    float cx = cos(uRot.x), sx = sin(uRot.x);
    o = vec3(o.x, o.y * cx - o.z * sx, o.y * sx + o.z * cx);
    vec3 pos = vec3(c + o.xy, o.z + uZ);
    if (uUseVP > 0.5) {
        vec4 cl = uVP * vec4(pos, 1.0);
        if (cl.w < 0.02) { gl_Position = vec4(2.0, 2.0, 0.0, 1.0); }   // behind the camera
        else { gl_Position = vec4(cl.xy, 0.0, cl.w); }
    } else {
        gl_Position = vec4(pos.x / uAspect, pos.y, 0.0, 1.0 - pos.z * uInvCam);
    }
}
