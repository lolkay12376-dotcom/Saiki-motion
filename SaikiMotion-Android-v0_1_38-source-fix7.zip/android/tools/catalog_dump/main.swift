// Writes the iOS effect catalog (Builtins.all() + the bundled examples) as JSON for the Android port.
// Key order and float text are fixed here; Float uses Swift's shortest round-trip description so Kotlin reads back the same Float.
import Foundation

func esc(_ s: String) -> String {
    var o = "\""
    for u in s.unicodeScalars {
        switch u {
        case "\"": o += "\\\""
        case "\\": o += "\\\\"
        case "\n": o += "\\n"
        case "\r": o += "\\r"
        case "\t": o += "\\t"
        default:
            if u.value < 0x20 { o += String(format: "\\u%04x", u.value) } else { o.unicodeScalars.append(u) }
        }
    }
    return o + "\""
}

func num(_ f: Float) -> String {
    if !f.isFinite { FileHandle.standardError.write("non-finite float in catalog\n".data(using: .utf8)!); exit(2) }
    return "\(f)"
}

func def(_ d: EffectDef) -> String {
    var s = "{\"id\":\(esc(d.id)),\"name\":\(esc(d.name)),\"desc\":\(esc(d.desc)),\"category\":\(esc(d.category)),\"kind\":\(d.kind),\"preview\":\(esc(d.previewAnim)),\"builtin\":\(d.builtin),\"bundled\":\(d.bundled)"
    if let src = d.source { s += ",\"source\":\(esc(src))" }
    s += ",\"props\":["
    s += d.props.map { p in
        var o = "{\"key\":\(esc(p.key)),\"label\":\(esc(p.label)),\"min\":\(num(p.min)),\"max\":\(num(p.max)),\"def\":\(num(p.def)),\"dec\":\(p.dec)"
        if let op = p.options { o += ",\"options\":[" + op.map(esc).joined(separator: ",") + "]" }
        o += ",\"inf\":\(p.inf),\"span\":\(num(p.span))}"
        return o
    }.joined(separator: ",")
    s += "],\"colors\":["
    s += d.colors.map { "{\"key\":\(esc($0.key)),\"label\":\(esc($0.label)),\"def\":\(UInt32(bitPattern: $0.def))}" }.joined(separator: ",")
    s += "],\"inputs\":[" + d.inputs.map(esc).joined(separator: ",") + "]"
    if let m = d.msl { s += ",\"msl\":\(esc(m))" }
    s += ",\"glsl\":\(esc(d.glsl))}"
    return s
}

let all = Builtins.all()
var out = "{\"version\":1,\"builtins\":[\n"
out += all.map(def).joined(separator: ",\n")
out += "\n],\"examples\":[\n"
out += Builtins.exampleIds.compactMap { Builtins.exampleById($0) }.map(def).joined(separator: ",\n")
out += "\n]}\n"
let path = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "builtins.json"
try! out.write(toFile: path, atomically: true, encoding: .utf8)
print("wrote \(all.count) builtins + \(Builtins.exampleIds.count) examples -> \(path)")
