// Stand-ins for the three iOS types the Builtins*.swift files construct (copied field-for-field from Model/Layer.swift:54-92 and
// Effects/EffectDef.swift:11-62; nothing else of the app is needed once BuiltinsShine's runtime part is cut by dump_catalog.sh).
import Foundation

struct PropDef {
    let key: String
    let label: String
    let min: Float
    let max: Float
    var def: Float
    var dec: Int = 2
    var options: [String]? = nil
    var inf: Bool = false
    var span: Float = 1
    init(_ key: String, _ label: String, _ min: Float, _ max: Float, _ def: Float,
         _ dec: Int = 2, _ options: [String]? = nil, _ inf: Bool = false, _ span: Float = 1) {
        self.key = key; self.label = label; self.min = min; self.max = max; self.def = def
        self.dec = dec; self.options = options; self.inf = inf; self.span = span
    }
}

struct ColorParam {
    let key: String
    let label: String
    var def: Int32
    init(_ key: String, _ label: String, _ def: Int32) { self.key = key; self.label = label; self.def = def }
}

final class EffectDef {
    let id: String
    var name: String
    var desc: String
    var category: String
    var kind: Int
    var props: [PropDef]
    var colors: [ColorParam]
    var inputs: [String]
    var previewAnim: String
    var builtin: Bool
    var bundled: Bool
    var source: String?
    var glsl: String
    var msl: String? = nil
    init(id: String, name: String, desc: String, category: String = "Custom",
         kind: Int = 0, props: [PropDef] = [], colors: [ColorParam] = [],
         inputs: [String] = [], previewAnim: String = "swipe",
         builtin: Bool = false, bundled: Bool = false, source: String? = nil,
         glsl: String = "") {
        self.id = id; self.name = name; self.desc = desc; self.category = category; self.kind = kind
        self.props = props; self.colors = colors; self.inputs = inputs; self.previewAnim = previewAnim
        self.builtin = builtin; self.bundled = bundled; self.source = source; self.glsl = glsl
    }
}
