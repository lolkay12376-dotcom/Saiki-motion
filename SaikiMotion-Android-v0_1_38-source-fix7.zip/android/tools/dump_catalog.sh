#!/bin/sh
# Generates shared/resources/catalog/builtins.json from the iOS Builtins*.swift (needs macOS + swiftc; no iOS source is modified).
# usage: tools/dump_catalog.sh <iOS Sources dir> [out.json]
set -e
SRC="$1"; OUT="${2:-$(dirname "$0")/../shared/resources/catalog/builtins.json}"
[ -d "$SRC/Effects" ] || { echo "usage: $0 <iOS Sources dir> [out.json]"; exit 1; }
T=$(mktemp -d); HERE=$(cd "$(dirname "$0")" && pwd)
for f in "$SRC"/Effects/Builtins*.swift; do cp "$f" "$T/"; done
# BuiltinsShine.swift: drop the runtime-only ShineCam enum (needs Editor/Xf/MetalCam); every EffectDef above/below it stays unchanged.
awk '/^enum ShineCam \{/{skip=1} /^func shineFx\(\)/{skip=0} !skip' "$SRC/Effects/BuiltinsShine.swift" > "$T/BuiltinsShine.swift"
swiftc -O "$HERE/catalog_dump/stubs.swift" "$HERE/catalog_dump/main.swift" "$T"/Builtins*.swift -o "$T/dump"
mkdir -p "$(dirname "$OUT")"
"$T/dump" "$OUT"
rm -rf "$T"
