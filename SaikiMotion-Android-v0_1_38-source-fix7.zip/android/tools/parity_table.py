#!/usr/bin/env python3
"""Regenerate docs/PARITY.md. Usage: tools/parity_table.py --ios <path to iOS Sources dir>
Edit ONLY tools/status.json to record progress (s = TODO|PARTIAL|DONE|N/A|VERIFIED, a = android file, n = note).
VERIFIED means: rendered/behaved identically to iOS on a device side-by-side (see docs/RULES.md #6)."""
import json, os, re, sys, collections
ios = sys.argv[sys.argv.index('--ios') + 1]
here = os.path.dirname(__file__); st = json.load(open(os.path.join(here, 'status.json')))
fw = re.compile(r'^import\s+(\w+)', re.M); skip = {'Foundation', 'Swift', 'Dispatch', 'simd', 'Darwin', 'CCrashLog', 'CNative'}
rows = []; tot = collections.Counter()
for d, _, fs in sorted(os.walk(ios)):
    for f in sorted(fs):
        if not f.endswith('.swift'): continue
        p = os.path.relpath(os.path.join(d, f), ios); t = open(os.path.join(d, f), errors='ignore').read()
        e = st.get(p, {}); s = e.get('s', 'TODO'); loc = t.count('\n')
        rows.append((p, loc, ', '.join(sorted(set(fw.findall(t)) - skip)), s, e.get('a', ''), e.get('n', ''))); tot[s] += loc
out = ['# Feature parity tracker (generated — edit tools/status.json, not this file)\n',
       'LOC by status: ' + ', '.join(f'{k} {v}' for k, v in sorted(tot.items())) + f'  (total {sum(tot.values())})\n',
       '| iOS file | LOC | iOS-only frameworks to replace | Status | Android file | Notes |', '|---|---|---|---|---|---|']
out += [f'| {p} | {l} | {fwk} | {s} | {a} | {n} |' for p, l, fwk, s, a, n in rows]
open(os.path.join(here, '..', 'docs', 'PARITY.md'), 'w').write('\n'.join(out) + '\n'); print(out[1])
