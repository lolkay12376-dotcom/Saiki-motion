#!/usr/bin/env python3
"""Drift guard: every shared/shaders/glsl/*.{vert,frag,comp} has a `// PORT-OF: msl/<file>::<fn>` line.
--stamp  : (re)write `// MSL-SHA256: <hash>` under it (run after you port/verify a shader against the MSL)
(default): fail if the MSL file changed since the stamp -> that GLSL twin must be re-ported."""
import hashlib, re, sys, glob, os
root = os.path.join(os.path.dirname(__file__), '..', 'shared', 'shaders')
stamp = '--stamp' in sys.argv; bad = 0
for f in sorted(glob.glob(root + '/glsl/*.*')):
    t = open(f).read(); m = re.search(r'PORT-OF: (msl/[\w.]+)', t)
    if not m: print('NO PORT-OF  ', os.path.basename(f)); bad += 1; continue
    h = hashlib.sha256(open(os.path.join(root, m.group(1)), 'rb').read()).hexdigest()[:16]
    old = re.search(r'// MSL-SHA256: (\w+)', t)
    if stamp:
        t = re.sub(r'// MSL-SHA256: \w+\n', '', t)
        t = re.sub(r'(// PORT-OF:[^\n]*\n)', r'\1// MSL-SHA256: %s\n' % h, t, 1); open(f, 'w').write(t)
    elif not old or old.group(1) != h: print('DRIFT/UNSTAMPED', os.path.basename(f)); bad += 1
print('ok' if not bad else f'{bad} problem(s)'); sys.exit(1 if bad and not stamp else 0)
