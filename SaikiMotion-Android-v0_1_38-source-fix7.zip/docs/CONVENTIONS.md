# Android port conventions (READ FULLY before porting any file)

You are porting an iOS Swift file to Kotlin inside an existing Android project that already
contains a UIKit-compatible layer. The iOS source is the SPEC. Match it exactly: same UI,
layout, labels, defaults, behaviour, strings, saved-state keys.

## Project layout

- Android root: `work/android/`
- Kotlin sources: `android/app/src/main/java/com/saiki/motion/`
  - `core/` — everything from iOS Sources/{Core,Model,Render,Effects,Media,Support,Tools}
  - `ui/` — everything from iOS Sources/UI  (UIKit-based screens)
  - `app/` — everything from iOS Sources/App (editor + screens; MainActivity is the entry)
  - `uikit/` — the UIKit compatibility layer (UiView, UIKit.kt, UIKit2.kt)
- Native: `android/app/src/main/cpp/` (vk_core.cpp = MetalPasses/MetalCore, jni_*.cpp bridges)
- Shared with iOS (byte-for-byte): `android/shared/shaders/glsl/` (GLSL),
  `android/shared/resources/` (img/sdk assets).
- iOS source of truth: `work/restore/ios/proj/Sources/` — READ THE WHOLE FILE before porting.

## The uikit layer (how UIKit maps to Kotlin)

Every screen is ported against the custom UIKit layer, NOT raw Android widgets:
`UiView` = UIView (own Canvas-based drawing, `draw(rect:)` -> `draw(rect: CGRect)`),
`UIViewController` lifecycle (viewDidLoad etc.), UIColor/CGFloat/CGRect/CGPoint/CGSize,
UIStackView, UILabel, UIButton, UITableView + source, UITableViewController, UIGestureRecognizer
(tap/pan/pinch/long-press), UIAlertController, UINavigationController via `Navigator`
(UIKit2.kt). ALWAYS check what exists first:
```
grep -n 'fun \|class \|val ' android/app/src/main/java/com/saiki/motion/uikit/UIKit.kt | head -50
grep -rn 'setNeedsDisplay\|addSubview\|UIStackView' android/app/src/main/java/com/saiki/motion/uikit/*.kt
```
Look at an already-ported screen (ui/MovePad.kt, ui/PreviewView.kt, ui/GraphEditor.kt,
ui/ColorPickerView.kt, ui/TimelineView.kt) and copy its patterns: how it declares the class,
overrides draw, uses Theme.C colors, binds gestures, and sizes via layoutSubviews.

## Hard rules

1. SAME NAMES: keep iOS type/member names. `EditorViewController` stays
   `EditorViewController` (in package com.saiki.motion.app). Swift `final class X: Y` ->
   `class X : Y()`. `struct` -> `class` (or data class if pure value + used by value).
   `enum` -> `enum class`. `protocol` -> `interface`.
2. SAME STRINGS: every user-visible label, toast, alert title/message/button, error string
   must be the exact same text as iOS. If iOS uses Localization.get("key"), use
   `Localization.get("key")` (core/Localization.kt exists; check its table — if a key is
   missing, ADD it to the table with the iOS value from Sources/Support/Localization.swift).
3. SAME KEYS: UserDefaults keys (`UserDefaults.standard.string(forKey:)` ->
   `Prefs.getString("key")` — check core/Util.kt or UIKit2.kt for the Prefs helper; if
   absent use android.content.SharedPreferences via uikit.appContext) and project JSON keys
   must be byte-identical. Do not rename anything.
4. SAME NUMBERS: all constants, default values, durations, sizes, colors copy exactly
   (0.25 -> 0.25f, colors as 0xAARRGGBB Ints via UIColor).
5. Math: Float everywhere (CGFloat = Float). sin/cos/pow/sqrt/min/max from kotlin.math.
   Keep the exact same expressions and order of operations.
6. Files: one iOS .swift -> one .kt with the same basename (BuiltinsAM.swift -> BuiltinsAM.kt
   in core/). Put a header comment `// Port of Sources/<folder>/<name>.swift`.
7. If something needs a UIKit API that does not exist in the uikit layer yet, ADD it to
   uikit/UIKit2.kt (small, generic, reusable) — do NOT hack around it in the screen.
8. TODO(parity) is ONLY for a real platform impossibility (with iOS file:line + reason).
   Everything else gets a real implementation. No stubs, no "not implemented" placeholders.
9. GCD: DispatchQueue.main.async -> `uikit main { }` (check UIKit2.kt for the helper),
   async background work -> Thread { }.start() or coroutines if already used in the file.
10. Files that must NOT be ported (intentionally replaced): Gl.swift, MetalPreview,
    RenderBackend, MetalParity, MetalDebug, AppDelegate/SceneDelegate/Main.swift,
    Metal shader source strings (GLSL twins already exist in shared/shaders/glsl).

## Before you write any ported file

1. Read the ENTIRE iOS file (cat it in chunks if big).
2. Read at least one already-ported screen of similar kind.
3. Check which of the iOS file's collaborators already exist in Kotlin (grep the type name
   under android/app/src/main/java) and read their Kotlin signatures — use those, don't
   re-invent them.
4. Port fully. Then run:
   `bash work/scripts/kcheck.sh <file.kt>` (syntax-only check; kotlinc if available).
5. Never leave `println` debug spam; use the same logging the file's neighbours use.

## Definition of done for a file

Compiles (syntax check passes), every type from the iOS file exists with the same name,
every user-visible string is byte-identical, every storage key is byte-identical, and the
header cites the iOS path. No TODO(parity) unless a genuine platform impossibility.
