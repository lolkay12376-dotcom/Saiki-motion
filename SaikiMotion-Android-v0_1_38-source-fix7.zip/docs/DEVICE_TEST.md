# Device test list — MetalModel renderer (SaikiMotion Android port)

iOS spec: `work/restore/proj/Sources/Render/MetalModel.swift` (1,696 lines).
Android twins: `core/MetalModel.kt`, `core/MetalModelDraw.kt`, `cpp/vk_model.inc`, `cpp/jni_model.cpp`,
`shared/shaders/glsl/model.vert | model.frag | model_rt.frag | waterUnder.* | planeOcc.frag | planeDepth.frag`.

Everything below compiles and is code-verified against the iOS file, but needs a physical device (or a
Vulkan-capable emulator with the listed extensions) to confirm visually. Check each item against an iPhone
running the iOS build side by side.

## 1. Plain model drawing
- [ ] GLB / glTF / OBJ / ABC model loads and draws with the right colour, metal/roughness and emissive.
- [ ] glTF alpha modes: OPAQUE (no discard), MASK (cutoff discard from `alphaCutoff`, default 0.5, alpha forced to 1), BLEND (`sp.blend` -> premultiplied ONE / ONE_MINUS_SRC_ALPHA blend, depth write off).
- [ ] Alpha-tested textures keep their mip chain (aniso4 samplers, `vk_model.inc`/`jni_model.cpp`) — no shimmer at grazing angles.
- [ ] Depth compare LESS_OR_EQUAL with depth write, cull NONE (MetalModel.swift:1330) — double-sided glTF materials look identical to iOS.

## 2. Ray-traced lighting (model_rt.frag, VK_KHR_ray_query)
- [ ] `rtOn` layer switch shows soft sun shadows (rtSoftVis toward mL1, disc radius `rtSoft`, samples `rtSamples`).
- [ ] rtShadow strength slider (`xtra.z`) fades shadows; rtAo (`xtra.y`) fades ambient occlusion.
- [ ] Scene lights (Point/Sun/Spot lighting layers) cast shadows; per-light radius from `lightRad * lightShadowSoft`.
- [ ] RT falls back to the plain `model.frag` pipeline on GPUs without VK_KHR_ray_query; `rtStatus` message shows in 3D editor Properties.
- [ ] Animated (ABC) models rebuild the BLAS every frame without a visible stall; static models build once.

## 3. PBR material maps (Properties > PBR material)
- [ ] normal / roughness / metallic / height / opacity / albedo / emissive / ao file pickers bind the right textures (bindings 21-25 + material slots).
- [ ] Height map: parallax occlusion mapping (24 steps) + contact self-shadow; vertex displacement with subdivision level (`pbrSub` 0..4, maxTris 1.4M).
- [ ] No normal map + height map: relief-derived normals.
- [ ] Roughness/metal multipliers (`pbrRough`, `pbrMetal`), emissive strength (`pbrEm`), AO strength (`pbrAo`).
- [ ] Clear coat (`pbrCoat`, `pbrCoatR`) — glossy second layer over car paint / lacquer.
- [ ] Geometric specular anti-aliasing (fwidth(N) widens the highlight).

## 4. Embedded PBR (glTF materials)
- [ ] metallicRoughnessTexture (G=rough, B=metal), emissiveTexture (gamma 2.2), occlusionTexture (R, `m3Ao` strength).
- [ ] Model's own normal map (texNormal) with glTF green-sign convention, `pbrNStr` / `pbrFlip`.
- [ ] Procedural PBR (pgOn): tile density follows layer scale, parallax from metal-rough R, bump from occ GB (`pbrNorm`).

## 5. Terrain splat (asset.extras.splat)
- [ ] Up to 4 splat layers blend by weight maps + height; per-layer tiling and normal strength.
- [ ] Detail-rotation trick (rcs/rsn) removes visible tiling; splat textures aniso8.

## 6. Water (wa > 0.5)
- [ ] Gerstner-style displaced surface, 4 octaves in the vertex shader, 6 in the fragment.
- [ ] Camera above: reflection (HDRI or sky), refraction warp via depth snapshot, caustics, foam, whitecaps.
- [ ] Custom water colours (3 stops, gradient modes: depth / bands / patches).
- [ ] Water collision foam: rocks (steep) and shores (gentle), run-up bands.
- [ ] Reflect surface (wRefl): screen-space reflection of layers drawn before the water (needs `sceneTex` = the scene target — Android passes the final target like iOS `target.tex`).
- [ ] Camera below the surface: waterUnder full-screen pass (Snell's window, TIR, rays); depth snapshot + inverse VP.
- [ ] Rays (wRays): volumetric shafts + beams landing on the ground.

## 7. Depth handling / occlusion
- [ ] `depthDirty` semantics: first model of the frame clears depth, later models load (shared depth buffer across model layers).
- [ ] 3D media plane vs models: `occludePlane` (planeOcc colour cut + planeDepth analytic depth write).
- [ ] Volume occlusion: `occlusionDepth()` returns the depth only when a model drew this frame.

## 8. Points / point maps
- [ ] Point map layers: size in px scaled by height/720, density prefix, animations 1-5 (ripple / shimmer / scan sweep / burst / twist).
- [ ] Collider mesh (name "SaikiCollider"): drawn depth-only first with depth bias 4/4/0 so points/objects behind a wall are hidden but points sitting ON the wall stay visible (newly implemented — verify!).
- [ ] Physical collision (colPhys): model sphere pushed out of collider triangles, 3 settling passes.
- [ ] `colOcc` / `colShow` toggles.

## 9. Skinning / animation
- [ ] Bone-track posing (applyPose -> Skeleton3D.skinVerts) re-uploads the vertex buffer every frame it changes.
- [ ] ABC baked animation (setAnimTime) updates pos+normal per frame; animated models keep re-uploading (no stale first-frame mesh).
- [ ] Animated + RT: BLAS rebuild uses the fresh vertex buffer.

## 10. Instancing (Scatter)
- [ ] Scatter onto a model / quad / procedural ground: instanced draw with per-instance model matrix (N descriptor sets).
- [ ] Normalisation (scale/offset) and `scSit` base-on-surface; keep-original (scKeep).
- [ ] View culling at > 12 instances, 1500 instance cap.

## 11. Bounding boxes / normalization
- [ ] Auto-normalised models (fit to unit) draw at the same size/position as iOS; `baseY` used by scatter sit and water base level (wf.x = mm[13]).

## 12. HDRI environment (GlobalEnv)
- [ ] .hdr / .exr / jpg equirect loads, mip chain generated; `envp` = (1, rot, maxMip, gain); reflection/ambient tint matches iOS.
- [ ] No HDRI: procedural sky gradient env.

## 13. X-ray editor preview
- [ ] Editor.xray on: rim-bright see-through, cool tint, alpha 0.12 base.

## Notes
- Sampler aniso is a device feature (`samplerAnisotropy`); on devices without it, aniso4/aniso8 silently fall back to linear filtering (same as Metal on old iOS GPUs).
- `VK_KHR_ray_query` + `VK_KHR_acceleration_structure` + `VK_KHR_buffer_device_address` (+ spirv_1_4, float_controls, deferred_host_operations) must all be present, else RT is disabled at device creation (iOS: A13+ gate).

## 14. Scene compositor (SceneRenderer.kt vs SceneRenderer.swift)
- [ ] Layer pipeline order matches iOS: content → effects → cutByNearer3D → clipByMasks → composite; adjustment layer with fx REPLACES what is below (blit, no blend).
- [ ] Blend modes 0/1/2/3/4/5 + 10 (Dissolve) + 11-34 (blendFn set) give pixel-identical results vs iOS for a two-layer scene (composite.frag == MetalPasses.compositeFragment).
- [ ] Mask modes 1-4 (alpha / inv alpha / luma / inv luma) and Mask Group matte (maskMode = g.mask, mode 99) clip like Cubism.
- [ ] Fast path: plain image/video layer (blend 0, no mask/clip/fx, no nearer occluder, no plane depth) draws as ONE blended quad into the scene (premultiplied ONE / ONE_MINUS_SRC_ALPHA).
- [ ] VDB volumes draw after all other layers, water volumes after VDBs, flares last (vdbLast reorder).
- [ ] Live2D clip: mask layers union; no mask present → clipping released.
- [ ] 3D media planes take part in the shared model depth when a model is present (planeUsesDepth / planeOcc / planeDepth passes).
- [ ] Group depth up to 4 (poolTarget); pre-rendered (baked) groups: cache hit → flat plane, prefetch of next 4 frames while playing/scrubbing.
- [ ] Motion blur: sample count = screenTravel-based (px≥0.5 → ceil(px)/2+1 capped 10/64 preview/export), video-only averaging min(cap, 3/6), ADJUST never blurred, movingFx → max(n, 12/96); rgbShift = frac*0.004*amount; glowBlurComp 2.4 on the blurred result.

## 15. Particles (MetalParticles.kt / particle.vert+frag vs MetalParticles.swift)
- [ ] ParticlesSim / ParticularSim / StrandsSim fields identical; rotation X/Y of the whole field about the layer origin; layer Position Z moves the field.
- [ ] 3D: far→near sort, point size k = 3/w; occluder rectangles hide particles behind 3D layers/models (pOcclude/ptOcclude/stOcclude).
- [ ] Blend: premultiplied ONE / ONE_MINUS_SRC_ALPHA point sprites (VK over pipeline, == MTL one/oneMinusSourceAlpha).
- [ ] Sprite sheet: 512² premultiplied atlas, 1.42 room, rotation, life/random-indexed cells; gradient LUT (16 stops) vs uColA/uColB mix; ptImgColor per-particle colour.
- [ ] Particular extras: bump shading (normal from height map, light angle, back side 0.8), 3D tumble foreshortening, glow halo (u.b.w) with (a + halo) alpha.
- [ ] simTime under motion blur: particles stay crisp (particleSimTime twin).

## 16. Flares (MetalFlare.kt / flare.frag vs MetalFlare.swift)
- [ ] Element loop (16): Glow/Polygon/Ring polygon/Iris/Line/Rays/Ring/Dot/Glint/Hoop/Streak/Spike/Rainbow/Multi-iris/Arc/Lens stack/Shimmer with the same per-element uniforms (arr blocks A/B/C/D/E/Col + gain/off).
- [ ] 3D light: projected through the camera, sizeMul by w0/w clamped 0.15..6 × depthScale, hidden behind the camera (intensity 0 → skip).
- [ ] Occlusion: 16-tap disc sample of the model depth buffer, seen = mix(1, vis/16, uOccl).
- [ ] Realism: PSF + halo wings, ghost directionality, dust/scratches, veiling glare, film shoulder; roll-off + dither identical.
- [ ] Preview: half-resolution shading + blit upsample (tw >= 64, !isExport); export full res.
- [ ] flareMode: FLARE layers default to ADD (blend 1) unless blend == 2.

## 17. Deep Glow (MetalGlow.kt / glow*.frag vs MetalGlow.swift)
- [ ] 9 levels, div = 4<<k (level 0 = quarter res), all RGBA16F; extract (thr/knee on premultiplied brightness), 4-tap down chain, separable Gaussian (0.227/0.316/0.070 weights), weighted up-accumulate, final (tint/chroma/glowOnly/dither).
- [ ] Level weights: log2(sigmaPx/8) position, sg = 0.55+falloff*1.6, w<=0.04 zeroed, sum-normalised; top = deepest used level.
- [ ] gain = intensity*0.55*(1+(comp-1)*0.3)*(1+max(0,1/zs-1)*0.15); threshold /= blurComp; zScale shrinks the glow with pushed-back layers.
- [ ] Haze/Flare (mblooks mbHf) pre-bloom: radius 0.03+mbHfRe*0.0045, thr 0.5, knee 0.6, falloff mbHfSo*0.01, glowOnly 1, into hazeT as in0.

## 18. VDB volumes (MetalVolume.kt / vdb.frag vs MetalVolume.swift)
- [ ] 128³ lattice → 2048×1024 atlas (16×8 slices of 128×128), sqrt-encoded density in R.
- [ ] Ray march: NS steps clamp 16..160 (vdbSteps×quality), interleaved-gradient jitter, self-shadow (L*1.5 + L*4 + L*9), Beer-Lambert, depth-read occlusion against models.
- [ ] Cloud detail erosion (3-octave vN), photoreal cumulus path (5-tap sun march, 3-octave multiple scattering, dual-lobe HG, powder, sky ambient), mist mode, edge tint.
- [ ] Up to 3 light balls (3D Null isLight) in volume-local space; sun/infinite lights not distance-faded (×0.1).
- [ ] Scissor to the box's screen bounds (+3 px); bnd.w = vdbOpacity; accumulate mode (pipelineOver) for scatter copies; surroundings light reads the scene texture.

## 19. Video sampler (VideoFrames.kt vs MetalScene.swift MetalVideoSampler / VideoFrames.swift)
- [ ] Async buckets: newest bucket wins, stale decode skipped when the playhead moved on; fresh frame → onUploaded → SceneRenderer.onVideoFrame (preview redraw).
- [ ] Twixtor: bucketsPerSec = source fps (frame A of the pair); remap (remapT / remapSpeed) and srcOffset respected in sourceTime.
- [ ] Export: synchronous decode of the exact frame; preview caps decode at 1280 px.
- [ ] Rotation 90/270 swaps videoSize; fallback seek (±50 ms) mirrors requestedTimeTolerance 0.05 s.

## 20. Passes / targets (vk_core.cpp, jni_scene.cpp vs MetalPasses.swift / MetalCore.swift)
- [ ] Offscreen targets RGBA8; half targets RGBA16F; swapchain BGRA8; negative-height viewport = y-up NDC like Metal.
- [ ] blit/composite: fullscreen triangle, no blend; composite result swapped target<->scratch (no copy-back); clear via loadOp-clear pass == MTLClearColor(0,0,0,0).
- [ ] pipelineOver (ONE / ONE_MINUS_SRC_ALPHA) used by particle, flare and accumulate volume passes == MTL sourceRGB .one / destinationRGB .oneMinusSourceAlpha.
- [ ] quadPass QuadU std140 (52 floats) == MetalScene QuadU byte order; fs.vert / mesh.vert / warp.vert cover the 2D/3D/puppet paths.
- [ ] readTarget: RGBA8 only (half → nil, like MetalTarget.readImage); thumbnail/snapshot path round-trips to Bitmap.

## 21. Effects chain (FxGlsl/FxSteps/fx_runtime vs MetalEffects.swift)
- [ ] Effect GLSL → SPIR-V runtime compile with the same prelude (luma/hash/fbm/hsv), uniforms uRes/uTime/uHas0/uHas1/uLC/uLX/uLY and props flattened in def order.
- [ ] Layer inputs in0/in1: referenced layer rendered into dedicated targets (max 2), layerA snapshotted and restored; Copy Background reads the composite below the layer.
- [ ] Ping-pong layerA/layerB, result swapped back into layerA; failed/unready effect = passthrough (never a blank frame).
- [ ] MB Looks .cube LUT strip → in1 + lkLutSize (LookLut.shared).
- [ ] Plugin (.aureaplugin multi-pass) effects: ineligible → frame falls back (lastFallbackReason "GL-only plugin"); single-pass GLSL effects run through the fx runtime.
- [ ] gizmoProject (editor overlay): 3D layers rotate about the layer origin (rotX then -rotY), z + camera VP, NDC x × aspect; broken camera → flat fallback, never vanish.

## 22. Media browser / album picker (MediaBrowser.kt vs MediaBrowser.swift)
- [ ] First open on Android 13+: system permission dialog appears (READ_MEDIA_IMAGES/VIDEO); Deny → "Allow photo access in Settings to browse your library." empty-state; grant + reopen → grid fills. (Polish round: manifest previously declared no permissions at all — the grid was permanently dead; fixed + added this section.)
- [ ] Album menu (top-left): All + smart albums (Favorites may be absent — MediaStore has no portable favourite flag) + device folders, same order as iOS.
- [ ] Tapping a photo/video imports into a layer; type routing glb/mmd/vdb/vrm/collider/env identical to iOS (checklist item 3).
- [ ] iOS side: Photos app albums appear identically; a denied-permission empty state matches.
