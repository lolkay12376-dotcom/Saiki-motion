# Feature parity tracker (generated — edit tools/status.json, not this file)

LOC by status: DONE 3781, PARTIAL 18232, TODO 48791  (total 70804)

| iOS file | LOC | iOS-only frameworks to replace | Status | Android file | Notes |
|---|---|---|---|---|---|
| App/EditorViewController.swift | 1375 | AVFoundation, CoreMedia, PhotosUI, UIKit, UniformTypeIdentifiers | TODO |  |  |
| App/EffectsGalleryViewController.swift | 244 | UIKit | TODO |  |  |
| App/HomeViewController.swift | 1370 | UIKit, UniformTypeIdentifiers | TODO |  |  |
| App/HomeWidgets.swift | 258 | UIKit | TODO |  |  |
| App/Main.swift | 47 | UIKit | TODO |  |  |
| App/SdkIdeViewController.swift | 837 | UIKit | TODO |  |  |
| App/WelcomeViewController.swift | 213 | UIKit | TODO |  |  |
| App/Editor/EditorAudio.swift | 123 | AVFoundation, UIKit | TODO |  |  |
| App/Editor/EditorAudioFx.swift | 693 | UIKit | TODO |  |  |
| App/Editor/EditorAudioLibrary.swift | 79 | UIKit, UniformTypeIdentifiers | TODO |  |  |
| App/Editor/EditorBlendSpeed.swift | 207 | UIKit | TODO |  |  |
| App/Editor/EditorDepth.swift | 86 | AVFoundation, UIKit | TODO |  |  |
| App/Editor/EditorDialogs.swift | 533 | AVFoundation, UIKit | TODO |  |  |
| App/Editor/EditorEffects.swift | 949 | UIKit, UniformTypeIdentifiers | TODO |  |  |
| App/Editor/EditorFlare.swift | 603 | UIKit | TODO |  |  |
| App/Editor/EditorGraph.swift | 93 | UIKit | TODO |  |  |
| App/Editor/EditorHelpers.swift | 146 | UIKit | TODO |  |  |
| App/Editor/EditorImport.swift | 540 | AVFoundation, CoreMedia, PhotosUI, UIKit, UniformTypeIdentifiers | TODO |  |  |
| App/Editor/EditorLayers.swift | 430 | UIKit | TODO |  |  |
| App/Editor/EditorLiveCache.swift | 157 | UIKit | TODO |  |  |
| App/Editor/EditorPanelsText.swift | 1143 | PhotosUI, UIKit, UniformTypeIdentifiers | TODO |  |  |
| App/Editor/EditorPbr.swift | 89 | UIKit, UniformTypeIdentifiers | TODO |  |  |
| App/Editor/EditorPen.swift | 18 | UIKit | TODO |  |  |
| App/Editor/EditorPointMap.swift | 49 | UIKit | TODO |  |  |
| App/Editor/EditorPuppet.swift | 431 | UIKit | TODO |  |  |
| App/Editor/EditorSceneSetup.swift | 169 | ObjectiveC, UIKit | TODO |  |  |
| App/Editor/EditorTransform.swift | 294 | UIKit | TODO |  |  |
| Core/Editor.swift | 40 |  | DONE | core/Editor.kt | Editor object (project/sceneIndex/time/scene). Unbuilt. |
| Core/Json.swift | 511 |  | PARTIAL | core/Json.kt | Writer identical to iOS JObj.toString (no '/' escaping, numberToString, NaN->null), opt helpers with explicit defaults. Parsing = org.json. Unbuilt/unverified. |
| Core/Util.swift | 462 | UIKit | PARTIAL | core/Util.kt | clamp, ktRandom, noise1, roundAway, Paths only. Rest (Snack, color helpers, threads) not ported. |
| Effects/AureaPlugin.swift | 120 |  | PARTIAL | core/AureaPlugin.kt,core/EffectDef.kt | FxPass, fromAureaPlugin (reads assets via lambda), aureaPassSource (GLSL ES spec text) ported; all 15 bundled plugin.json parse against the loader logic. TODO(parity): multi-pass Vulkan runtime (iOS runs plugins only in GL: SceneRenderer.applyPluginEffect). Unbuilt/unverified. |
| Effects/Builtins.swift | 1771 |  | PARTIAL | core/Builtins.kt,tools/dump_catalog.sh,tools/catalog_dump/ | Defs are generated, not hand-ported: tools/dump_catalog.sh compiles the iOS Builtins*.swift on a Mac and writes shared/resources/catalog/builtins.json (Builtins.all() order + 5 examples); Builtins.kt reads it. TODO(parity): run the dump and commit the JSON (not done, no swiftc). Applies to all Effects/Builtins*.swift. Unbuilt/unverified. |
| Effects/BuiltinsAETwixtor.swift | 138 |  | TODO |  |  |
| Effects/BuiltinsAM.swift | 235 |  | TODO |  |  |
| Effects/BuiltinsBCC.swift | 382 |  | TODO |  |  |
| Effects/BuiltinsCapCut.swift | 112 |  | TODO |  |  |
| Effects/BuiltinsChromaTown.swift | 120 |  | TODO |  |  |
| Effects/BuiltinsControls.swift | 48 |  | TODO |  |  |
| Effects/BuiltinsExtra.swift | 215 |  | TODO |  |  |
| Effects/BuiltinsLooks.swift | 329 |  | TODO |  |  |
| Effects/BuiltinsMBL.swift | 332 |  | TODO |  |  |
| Effects/BuiltinsMotion.swift | 266 |  | TODO |  |  |
| Effects/BuiltinsNodeVideo.swift | 192 |  | TODO |  |  |
| Effects/BuiltinsSaiki.swift | 94 |  | TODO |  |  |
| Effects/BuiltinsSapphire.swift | 633 |  | TODO |  |  |
| Effects/BuiltinsSapphire2.swift | 364 |  | TODO |  |  |
| Effects/BuiltinsSapphire3.swift | 238 |  | TODO |  |  |
| Effects/BuiltinsSapphire4.swift | 515 |  | TODO |  |  |
| Effects/BuiltinsSapphire5.swift | 210 |  | TODO |  |  |
| Effects/BuiltinsShine.swift | 353 |  | TODO |  |  |
| Effects/BuiltinsUniverse.swift | 166 |  | TODO |  |  |
| Effects/BuiltinsUniverse2.swift | 309 |  | TODO |  |  |
| Effects/BuiltinsUniverse3.swift | 348 |  | TODO |  |  |
| Effects/BuiltinsUniverse4.swift | 323 |  | TODO |  |  |
| Effects/DepthAnything.swift | 274 | Compression, CoreML, UIKit, Vision | TODO |  |  |
| Effects/EffectDef.swift | 171 |  | PARTIAL | core/EffectDef.kt | Full port (fromJson/toJson/parseColor/confinesToAlpha). TODO(parity): EffectDef.swift passes [FxPass] (multi-pass .aureaplugin), msl kept only for round trip. Unbuilt/unverified. |
| Effects/EffectThumbs.swift | 439 | GLKit, OpenGLES, UIKit | TODO |  |  |
| Effects/LookLut.swift | 91 | Metal | TODO |  |  |
| Effects/Registry.swift | 425 | OpenGLES | PARTIAL | core/Registry.kt,core/PtGroup.kt,core/Assets.kt | Full port (order/byId/errors, reloadSdk incl. bundled plugins + user sdk folders, newEffectFolder, get/uniqueEntry/instProp/instColor/propDef incl. PtGroup.strip, addCustom/deleteCustom, presets, capture/applyPreset). validateProgram uses the Vulkan async compile (result known later). TODO(parity): EffectThumbs.generate (:117). Catalog is empty until shared/resources/catalog/builtins.json is generated. Unbuilt/unverified. |
| Effects/TwixtorTime.swift | 23 |  | TODO |  |  |
| Media/AudioFx.swift | 977 | AVFoundation | TODO |  |  |
| Media/AudioFxLive.swift | 211 | AVFoundation, AudioToolbox | TODO |  |  |
| Media/AudioTools.swift | 122 | AVFoundation | TODO |  |  |
| Model/Anim.swift | 696 |  | DONE | core/Anim.kt | Ease/Key/Track/easing math/Expr (parser, eval, wiggle/noise bit-exact UInt64/UInt32). Unbuilt/unverified. |
| Model/Flare.swift | 854 | UIKit | PARTIAL | core/Flare.kt | IrisDef, LensDef, FlareEl, Flare, 26 builtin presets (generated line-for-line, counts checked), user presets, elementPreviews. TODO(parity): Flare.swift:684 FlareThumbs.generate/irisPath + UIColor.mixed (UI slice). Unbuilt/unverified. |
| Model/Folders.swift | 64 |  | DONE | core/Folders.kt | folders.json beside projects. Unbuilt/unverified. |
| Model/Layer.swift | 612 |  | PARTIAL | core/Layer.kt,core/Placeholders.kt | Layer/LayerType/ShapeKind/TextFx/TextAnim/R3D + toJson(canonical)/fromJson/p()/track()/fxChain/xf/xset ported line-for-line. Flare/Puppet/Rig/Warp/AudioFxItem are lossless raw-JSON holders (TODO(parity) Flare.swift, Puppet.swift, Rig.swift:521, AudioFx.swift:12). Unbuilt/unverified. |
| Model/Physics3D.swift | 507 |  | DONE | core/Physics3D.kt | VRM spring bones, PMX rigid-body particles/joints, springNodes/parseVrm. Quat-from-matrix and fromTo are textbook versions (sign may differ from simd, rotation same). Unbuilt/unverified. |
| Model/Project.swift | 222 |  | PARTIAL | core/Project.kt,core/Defs.kt | Scene+Project+JSON and Defs tables (transform/scaleXY/scaleZ/pos3d/rot3d/anchor/text/audio/camera/flare/blur) ported. Unbuilt/unverified. |
| Model/ProjectArchive.swift | 193 |  | PARTIAL | core/ProjectArchive.kt | SAIKIPRJ1 export/import/isArchive. FontLibrary.importURLs wired. Unbuilt/unverified. |
| Model/ProjectIO.swift | 84 | UniformTypeIdentifiers | DONE | core/Projects.kt | sandboxName/copyMediaIntoSandbox(Uri)/writeData/mediaFile/deleteMedia. Unbuilt/unverified. |
| Model/Projects.swift | 222 |  | DONE | core/Projects.kt | save(+.bak, atomic, read-back)/load/list/delete/rename/duplicate/overwrite/importFile/lenientParse/resLabel. overwrite keeps iOS always-nil quirk (suspected iOS bug). Unbuilt/unverified. |
| Model/Puppet.swift | 342 | OpenGLES | DONE | core/Puppet.kt | Model + PuppetMath (wave/physics/IDW grid/topology/mesh). Gl.drawMesh (GL) not ported: Vulkan scene renderer draws PuppetMath.mesh(). Unbuilt/unverified. |
| Model/Retime.swift | 71 |  | DONE | core/Retime.kt | RetimeSnap, srcMap, retimeSnapshot, retime. Unbuilt/unverified. |
| Model/Rig.swift | 553 |  | DONE | core/Rig.kt | Rig, physics groups, Warp, apply/applyWarp, ticker via main Handler. Unbuilt/unverified. |
| Model/Skeleton3D.swift | 300 |  | DONE | core/Skeleton3D.kt | Bones, pose from layer tracks, skinVerts, SKL1/SKL2 sidecar read/write (little-endian). Uses core/Math3D.kt (simd replacement). Unbuilt/unverified. |
| Model/Store.swift | 27 |  | DONE | core/Util.kt | StoreNotification (projectsChanged/languageChanged) as listener list. Unbuilt. |
| Model/VPath.swift | 59 | UIKit | DONE | core/VPath.kt | Model + VPathRaster via Canvas (fill WINDING / stroke round 3%). Unbuilt/unverified. |
| Render/Exporter.swift | 299 | AVFoundation, GLKit, OpenGLES, UIKit, os | TODO |  |  |
| Render/FbxImport.swift | 718 | UIKit | PARTIAL | core/FbxImport.kt | Full line-for-line port: binary+ascii FBX parse, hierarchy/up-axis, materials+textures (embedded/neighbouring/discovered, ORM packing, opacity->alpha), skins, glb writer, .skel/.noskel sidecars, baked .anim. UIImage/CGContext -> Bitmap helpers; GlbModel.load/validate wired. TODO(parity): VdbVolume.inflateZlib (java.util.zip substitute), UIImage.pngData EXIF orientation bake, premultiply rounding vs CGContext. Unbuilt/unverified. |
| Render/FrameCache.swift | 193 | UIKit | TODO |  |  |
| Render/Gl.swift | 456 | CoreGraphics, GLKit, OpenGLES, UIKit | TODO |  |  |
| Render/GlbModel.swift | 1408 | GLKit, OpenGLES, UIKit | PARTIAL | core/GlbModel.kt | CPU-only loader: glb/gltf/obj, materials, skins+VRM springs, abc sidecar anim, zip unwrap, preflight, eye(). TODO(parity): GL draw()+shader sources (GlbModel.swift:1216-1408, superseded by Vulkan model renderer); .abc native transcode (:393), MmdImport hooks (:189-:196, :331; FBX wired); validate() abc/mmd passthrough. Unbuilt/unverified. |
| Render/GlobalEnv.swift | 50 | ImageIO, Metal, UIKit | PARTIAL | core/GlobalEnv.kt | path+uniform only; TODO(parity) GlobalEnv.swift:24 tex() HDR/EXR -> RGBA16F mip texture needs native upload. Unbuilt/unverified. |
| Render/Lights.swift | 82 |  | PARTIAL | core/Lights.kt | Full port (kelvin/tint/direction/stop/buffer). Unbuilt/unverified. |
| Render/MetalCamera.swift | 175 |  | DONE | core/MetalCamera.kt | MetalCam full port (vp, vpCamera, parentedWorld, viewProj, vpForModel, modelMatrix, lookAt/lookAtEye, mat helpers). SceneRenderer.editCam lives in SceneRendererStatics (TODO(parity) SceneRenderer.swift, slice 8: move onto SceneRenderer). Unbuilt/unverified. |
| Render/MetalCore.swift | 133 | Metal, UIKit | PARTIAL | cpp/vk_core.cpp,vk_core.h | MetalTarget(half RGBA16F/RGBA8)+readImage+selfTest+supportsRaytracing detection ported. TODO(parity): MetalCore.swift:36 library/compute pipelines; ray-query path not enabled. Unbuilt/unverified. |
| Render/MetalDebug.swift | 40 | UIKit | TODO |  |  |
| Render/MetalEffects.swift | 312 | Metal | PARTIAL | core/FxGlsl.kt,cpp/fx_runtime.cpp | Gl.effectShaderSource (Gl.swift:367) + FxGlsl.vulkanSource (== MetalEffects.translate, GLSL used directly; fetch flips V like FxCtx.fetch; props UBO b4 = props then colours on 16B boundary; FxCommon b3), async shaderc compile cache (passthrough until ready), fxApply/fxApplyChain, key(). TODO(parity): EffectCrashLog hooks (MetalEffects.swift:121-165, slice 10), JNI/Kotlin scene-side Step plumbing, pipeline warm-up for rgba8/bgra8 (:155), texture2DLod/Proj ES calls. NDK shaderc is deprecated/may be missing in newer NDKs. Unbuilt/unverified. |
| Render/MetalFlare.swift | 499 | Metal, UIKit | PARTIAL | shared/shaders/glsl | GLSL twins in shared/shaders/glsl (flare.frag (mechanical MSL->GLSL conversion)). UBO at set0 b8, textures b0.., SSBO/extra UBO per file header. Not compiled (no glslang), unverified vs MSL by eye only. Wiring via pipelineFor(file) is slice 5. |
| Render/MetalGlow.swift | 265 | Metal, UIKit | PARTIAL | shared/shaders/glsl | GLSL twins in shared/shaders/glsl (glow*.frag). UBO at set0 b8, textures b0.., SSBO/extra UBO per file header. Not compiled (no glslang), unverified vs MSL by eye only. Wiring via pipelineFor(file) is slice 5. |
| Render/MetalModel.swift | 1696 | Metal, OpenGLES, UIKit | PARTIAL | shared/shaders/glsl,core/MetalModel.kt,cpp/vk_model.inc,cpp/vk_core.h,core/MetalModelDraw.kt,core/NativeModel.kt,cpp/jni_model.cpp | GLSL twins: model.vert, model.frag (+ -DSAIKI_RT ray-query variant = modelFragmentRT via GL_EXT_ray_query), waterUnder.vert/.frag, planeOcc.frag, planeDepth.frag (mechanical MSL->GLSL, stamped, uncompiled). Model bindings differ from the b8 convention (MSL texture(n)=binding n up to 26, UBO ModelU b32, LBuf b33, vb SSBO b34, RT acc b36/RtU b37, WInv b39) because texture indices reach 25. TODO(parity): MetalModel.swift renderer (pipelines, per-material samplers, accel structure build) not ported; compute fallback for devices without ray_query not written. Unverified. | S23 7k CPU side in core/MetalModel.kt: MetalModel prim table (CpuTex substitutes), makeTexture CPU scale/premultiply, Splat.load, MetalModelRenderer.subdivide/loadModel cache/evict/evictMaps/mapTexture/colliderTris/collidePush/ptSurface/scatterWorld/scatterMatrices. Still TODO(parity): MetalModelSL pipelines, renderer GPU init, pso/psoUnder, depth buffers, buildAccel (ray query), draw(), occludePlane, setVBuf, GPU texture upload (mips). Unbuilt/unverified. | S23b 7l native primitives (cpp/vk_model.inc, included from vk_core.cpp): persistent buffers (makeBufferData/destroyBuf, Bind.buffer for SSBO b34), uploadTextureMips (mip chain via blits), DepthTex (D32, rests READ_ONLY), rpModel colour+depth passes, modelPipeline (== pso + dsWrite/dsNoWrite, depthOnly, points), encodeModelPass (N indexed draws, per-draw descriptor set). NOT yet: JNI surface, Kotlin MetalModelRenderer.draw() orchestration (MetalModel.swift:1204-1420), RT accel, occludePlane, psoUnder, cull mode check. Unbuilt/unverified. | S24 (7m): JNI (buffers, mip textures, DepthTex, targets, pso, modelPass) + MetalModelRenderer.draw for plain models (MetalModelDraw.kt) + Lights.kt + GlobalEnv.kt (PARTIAL: no HDRI decode). TODO(parity): points/subCache/splat (7n), RT accel/occludePlane/water depth snapshot/psoUnder (7o), collider depth bias, aniso4 samplers. Unbuilt/unverified. | S25 (7n): points (density/size/anim, point pipeline), displacement subCache (GPU bufs freed in trimMemory), splat uniforms+14 textures in MetalModelDraw.kt. Remaining: 7o. Unbuilt/unverified. | S26 (7o-a): water depth snapshot (copyDepth, depthCopyH), waterUnder full-screen pass inside encodeModelPass (non-indexed ModelDraw, depth ALWAYS), occludePlane (planeOcc colour pass via encodeFx + planeDepth depth-only pass). Remaining: RT accel/ray-query (7o-b: device ext+features, BLAS/TLAS, model_rt layout b36/b37). Unbuilt/unverified. | S27 7o-b ray query: device enables VK_KHR_ray_query/acceleration_structure/bufferDeviceAddress (+spirv_1_4, float_controls, deferred_host_operations) with VkPhysicalDeviceFeatures2 chain; vk_model.inc buildAccel (BLAS, opaque triangles, stride 48, per-frame retire list), model_rt set layout (b36 AS, b37 RtU 80B), model_rt.frag generated by tools/gen_model_rt.py (== rtSource); JNI accelBuild/accelFree/rtSupported + modelPass(accel, rtu); Kotlin MetalModelDraw rtI/rinv/rtp, rtPS ?? pso, subdivision skipped when accel. Any-hit (TerminateOnFirstHit) used for shadow rays: result equals closest-hit existence. TODO(parity): compute fallback for devices without ray_query; collider depth bias; aniso4. Unbuilt/unverified. |
| Render/MetalParity.swift | 168 | Metal, OpenGLES, UIKit | TODO |  |  |
| Render/MetalParticles.swift | 382 | Metal, UIKit | PARTIAL | shared/shaders/glsl | GLSL twins in shared/shaders/glsl (particle.vert/frag). UBO at set0 b8, textures b0.., SSBO/extra UBO per file header. Not compiled (no glslang), unverified vs MSL by eye only. Wiring via pipelineFor(file) is slice 5. |
| Render/MetalPasses.swift | 298 | Metal, UIKit | PARTIAL | cpp/vk_core.cpp,vk_core.h | pipeline/pipelineOver cache, encode/encodeLoad, blit, composite (+swap overload), dummy, makeTexture, runSync, FxCommon/CompParams ported. Not yet: libKey external libraries (other shader files via pipelineFor(file)), layer-driven composite (needs Layer). Unbuilt/unverified. | S7: generic per-shader layouts (layoutFor/layoutForShader/fxLayout), pipelineForDesc/pipelineForFile (vert+frag+layout+over+topology), Bind/encodeFx (textures, UBO/SSBO via 16MB per-frame arena, sampler arrays, MSL-equivalent Samp set incl. aniso8), device features (aniso, sampler-array indexing). TODO(parity): depth-attachment passes (model/volume/flare depth), accel-structure descriptors, arena grow-on-demand. Unbuilt/unverified. |
| Render/MetalPreview.swift | 52 | Metal, QuartzCore, UIKit | TODO |  |  |
| Render/MetalScene.swift | 415 | AVFoundation, CoreVideo, Metal, UIKit | PARTIAL | shared/shaders/glsl | GLSL twins in shared/shaders/glsl (quad/mesh/warp.vert, quad/shape.frag). UBO at set0 b8, textures b0.., SSBO/extra UBO per file header. Not compiled (no glslang), unverified vs MSL by eye only. Wiring via pipelineFor(file) is slice 5. |
| Render/MetalSceneParity.swift | 159 | OpenGLES, UIKit | TODO |  |  |
| Render/MetalSceneRenderer.swift | 1210 | Metal, QuartzCore, UIKit | PARTIAL | core/FxSteps.kt | Only effectSteps/paramValue/colorComp (:1039-1090) ported (data half: props/colours/inRef0/1). TODO(parity): twixtor in1 (:1072), mblooks LUT (:1078), bindEffectInputs (:1094) and the whole scene renderer. Unbuilt/unverified. |
| Render/MetalVolume.swift | 380 | ImageIO, Metal, UIKit | PARTIAL | shared/shaders/glsl,core/MetalVolume.kt,cpp/jni_model.cpp | GLSL twins in shared/shaders/glsl (vdb.frag). UBO at set0 b8, textures b0.., SSBO/extra UBO per file header. Not compiled (no glslang), unverified vs MSL by eye only. Wiring via pipelineFor(file) is slice 5. | S28 7p: core/MetalVolume.kt (MetalVolumeRenderer: inv4/mul4 line-for-line, 128^3 atlas packed 2048x1024 (RGBA8 with density in R instead of r8Unorm), env texture, VolU 92 floats, light balls into local space, screen-bounds scissor) + jni volumePass (pipelineForFile fs.vert+vdb.frag, over blend when accumulate, encodeFx scissor) + MetalModelRenderer.occlusionDepth. TODO(parity): scene-side call sites (slice 8). Unbuilt/unverified. |
| Render/MistGen.swift | 138 |  | PARTIAL | core/MistGen.kt,core/Util.kt | MistGen.make + MistSettings (writeFile/setup/applyLook/rebuildSoon via ScheduledExecutor+main Handler) full; nowMs() added to Util.kt. Unbuilt/unverified. |
| Render/MmdImport.swift | 618 | ImageIO, UIKit | PARTIAL | core/MmdImport.kt | Full line-for-line port: PMX parse (BDEF/SDEF/QDEF, rigid bodies+joints), PBR sibling maps, glb writer, .skel sidecar, VMD bake (bezier, append, CCD IK) to .anim, applyVmd, unzipAll; GlbModel.load/validate/unwrapZip wired. TODO(parity): VdbVolume.inflate (java.util.zip substitute), simd_slerp re-implemented, bitmap scale/premultiply vs CGContext, .anim streamed to disk. Unbuilt/unverified. |
| Render/Particles.swift | 113 |  | PARTIAL | core/Particles.kt | Full port (Particle, ParticlesSim.field, UInt32 PCG hash via Int wrap). Unbuilt/unverified. |
| Render/Particular.swift | 389 |  | PARTIAL | core/PtGroup.kt | Only enum PtGroup (:40-50) ported. Particle sim TODO(parity) Particular.swift:60+. |
| Render/ParticularAssets.swift | 824 | AVFoundation, UIKit | TODO |  |  |
| Render/PlyImport.swift | 449 |  | PARTIAL | core/PlyImport.kt | Full line-for-line port: PLY ascii/binary LE+BE (xyz/rgb/3DGS/faces), SPZ v1-v3, OBJ collider, shuffleAndCap (SplitMix), sidecars (_pts.bin/_flip.flag/_col.flag), GLB writer, attach/removeCollider. Inflate uses java.util.zip. TODO(parity): VdbVolume.inflate (VdbVolume.swift:320) once VDB slice lands; UI callers (PlyQualitySheet) in UI slice. Unbuilt/unverified. |
| Render/PreRender.swift | 266 |  | PARTIAL | core/PreRender.kt | Only enabled + descendants(of:in:) ported; bake/cache -> scene renderer slice. |
| Render/Scatter.swift | 247 | OpenGLES | PARTIAL | core/Scatter.kt | Full port (tris/ground/quad, Rng xorshift64, placements+group, matrices, instances); normal matrix via cofactors. Quat substitutes. Unbuilt/unverified. |
| Render/SceneRenderer.swift | 2954 | GLKit, ImageIO, OpenGLES, UIKit | TODO |  |  |
| Render/Strands.swift | 114 |  | PARTIAL | core/Strands.kt | Full port (noise3, field). TODO(parity): sin(Float) vs sinf ulp differences feed the sin-hash; unverified. |
| Render/TextRaster.swift | 465 | CoreText, UIKit | DONE | core/TextRaster.kt | Ported line-for-line to Paint/Canvas. Substitutes: Typeface.create(l.font) for iOS families, letterSpacing kern (last-glyph kern excluded), shadow = blurred alpha copy, text stroke miter 10. Unbuilt/unverified (pixels will differ by font). |
| Render/VdbVolume.swift | 481 | Compression | PARTIAL | core/VdbVolume.kt,core/NativeBlosc.kt,cpp/jni_bridge.cpp | VdbVolume.parse/load/evict/density/inflate/inflateZlib + CloudGen full; blosc via JNI NativeBlosc (c-blosc unchanged); zlib via java.util.zip.Inflater (replaces substitutes in PlyImport/FbxImport/MmdImport). Dead private parseGrid/bloscDecode* intentionally not ported. Unbuilt/unverified. |
| Render/VideoFrames.swift | 137 | AVFoundation, GLKit, OpenGLES, UIKit | PARTIAL | core/VideoFrames.kt | Only videoSize (MediaMetadataRetriever); duration + Sampler -> video slice. |
| Render/WaterAssets.swift | 147 | CoreGraphics, UIKit | TODO |  |  |
| Render/Xf.swift | 405 | CoreGraphics, UIKit | PARTIAL | core/Xf.kt | Full port. Depends on PreRender.enabled (TODO(parity) PreRender.swift:20 persisted pref) and VideoFrames.videoSize. Unbuilt/unverified. |
| Support/AppInfo.swift | 22 |  | TODO |  |  |
| Support/CrashLog.swift | 71 |  | TODO |  |  |
| Support/EffectCrashLog.swift | 145 | UIKit | TODO |  |  |
| Support/EffectGuard.swift | 109 | OpenGLES, UIKit | TODO |  |  |
| Support/FontLibrary.swift | 176 | Compression, CoreText, UIKit | DONE | core/FontLibrary.kt | MiniZip -> ZipInputStream, CGFont names -> sfnt name table, importURLs takes Uris. Unbuilt/unverified. |
| Support/FreezeWatchdog.swift | 120 | UIKit | TODO |  |  |
| Support/Localization.swift | 193 |  | TODO |  |  |
| Tools/AnimeDecomposeViewController.swift | 929 | PhotosUI, UIKit | TODO |  |  |
| Tools/AnimeDecomposer.swift | 1843 | CoreVideo, UIKit, Vision | TODO |  |  |
| Tools/AnimeSegModel.swift | 385 | CoreML, CoreVideo, OnnxRuntimeBindings, UIKit, Vision | TODO |  |  |
| Tools/DrawingArchive.swift | 103 |  | TODO |  |  |
| Tools/DrawingCanvas.swift | 1290 | UIKit | TODO |  |  |
| Tools/DrawingEditorViewController.swift | 1316 | Photos, PhotosUI, UIKit, UniformTypeIdentifiers | TODO |  |  |
| Tools/DrawingGalleryViewController.swift | 374 | PhotosUI, UIKit, UniformTypeIdentifiers | TODO |  |  |
| Tools/DrawingNewSheet.swift | 223 | UIKit | TODO |  |  |
| Tools/DrawingStore.swift | 242 | UIKit | TODO |  |  |
| Tools/PSDWriter.swift | 150 |  | TODO |  |  |
| Tools/VectorPenViewController.swift | 190 | UIKit | TODO |  |  |
| UI/AspectLayout.swift | 121 | UIKit | TODO |  |  |
| UI/AspectPicker.swift | 128 | UIKit | TODO |  |  |
| UI/BlendPicker.swift | 112 | Metal, UIKit | TODO |  |  |
| UI/Chibi.swift | 49 | UIKit | TODO |  |  |
| UI/ChromaTownDashboard.swift | 189 | UIKit | TODO |  |  |
| UI/ColorPickerView.swift | 143 | UIKit | TODO |  |  |
| UI/CrashBrowser.swift | 130 | UIKit | TODO |  |  |
| UI/EnvPanel.swift | 183 | UIKit | TODO |  |  |
| UI/ExtrasPanel.swift | 479 | UIKit | TODO |  |  |
| UI/FontBrowserViewController.swift | 237 | UIKit, UniformTypeIdentifiers | TODO |  |  |
| UI/GraphEditor.swift | 235 | UIKit | TODO |  |  |
| UI/GraphPanel.swift | 447 | UIKit | TODO |  |  |
| UI/HelpDocs.swift | 98 | UIKit | TODO |  |  |
| UI/Icons.swift | 654 | UIKit | TODO |  |  |
| UI/LayersSheet.swift | 79 | UIKit | TODO |  |  |
| UI/LightPanel.swift | 158 | UIKit | TODO |  |  |
| UI/LooksEditor.swift | 666 | UIKit, UniformTypeIdentifiers | TODO |  |  |
| UI/MBLEditor.swift | 580 | UIKit | TODO |  |  |
| UI/MBLExtras.swift | 476 | UIKit | TODO |  |  |
| UI/MediaBrowser.swift | 375 | AVFoundation, Photos, UIKit | TODO |  |  |
| UI/MovePad.swift | 269 | UIKit | TODO |  |  |
| UI/OverlayView.swift | 568 | UIKit | TODO |  |  |
| UI/ParticularDesigner.swift | 1183 | PhotosUI, UIKit, UniformTypeIdentifiers | TODO |  |  |
| UI/ParticularDraw.swift | 227 | UIKit | TODO |  |  |
| UI/PhysicsScreen.swift | 132 | UIKit | TODO |  |  |
| UI/PlusMenu.swift | 143 | UIKit | TODO |  |  |
| UI/PlyQualitySheet.swift | 50 | UIKit | TODO |  |  |
| UI/PoseUI.swift | 240 | UIKit | TODO |  |  |
| UI/PreRenderOverlay.swift | 166 | UIKit | TODO |  |  |
| UI/PreviewView.swift | 203 | GLKit, OpenGLES, UIKit | TODO |  |  |
| UI/RenderOverlay.swift | 456 | UIKit | TODO |  |  |
| UI/RigEditor.swift | 2002 | UIKit | TODO |  |  |
| UI/RulerSlider.swift | 223 | UIKit | TODO |  |  |
| UI/ScatterEditor.swift | 217 | UIKit | TODO |  |  |
| UI/Scene3DView.swift | 2074 | OpenGLES, SceneKit, UIKit | TODO |  |  |
| UI/ShapeTiles.swift | 117 | UIKit | TODO |  |  |
| UI/ShineDashboard.swift | 402 | UIKit | TODO |  |  |
| UI/SimulationsPanel.swift | 192 | UIKit | TODO |  |  |
| UI/SkyPanel.swift | 115 | UIKit | TODO |  |  |
| UI/TerrainNodeEditor.swift | 702 | PhotosUI, SceneKit, UIKit, UniformTypeIdentifiers | PARTIAL | core/Terrain.kt | TGNode/TGWire/TGraph model + TKind.desc ported in core/Terrain.kt (lines 13-101, 561-575); TGCanvas/TerrainNodeEditor/TGPalette/TGTexPicker UI = slice 9. Unbuilt/unverified. |
| UI/TerrainPanel.swift | 984 | UIKit | PARTIAL | core/Terrain.kt | Model code ported to core/Terrain.kt: TKind/TNode/HeightImages/TerrainGraph(eval,colour,preview,presets)/PLayer/TerrainPBR(analyse,vertexW,sampling,bake)/TerrainGLB.build/TGNode/TGWire/TGraph(+JSON). PolyHaven.Maps/ExtrasGLB.Packed are minimal holders (ExtrasPanel.swift:54,117; slice 9 must extend). Bitmap substitutes for CGContext (gray/premultiply may differ by 1 level), kotlin.math sin/pow/exp ulp. TODO(parity): panel/node-editor UI = slice 9. Unbuilt/unverified. |
| UI/Theme.swift | 154 | UIKit | TODO |  |  |
| UI/TimelineView.swift | 955 | AVFoundation, UIKit | TODO |  |  |
| UI/Toast.swift | 43 | UIKit | TODO |  |  |
| UI/UniverseDashboard.swift | 277 | CoreImage, UIKit | TODO |  |  |
| UI/Waveform.swift | 52 | AVFoundation | TODO |  |  |
| UI/Widgets.swift | 560 | UIKit | TODO |  |  |
