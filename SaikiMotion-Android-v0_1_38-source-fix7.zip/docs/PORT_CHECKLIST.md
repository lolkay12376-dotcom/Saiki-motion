# SaikiMotion Android Port Checklist — v0.1.36 audit round

Real project: `work/android/` (v0.1.36, versionCode 88). iOS spec: `work/restore/ios136/proj/Sources`.
Version note (STEP 0c finding): iOS Info.plist says 0.1.26/75 and AppInfo.swift says 0.1.17/74 (stale — its own comment says Info.plist is authoritative), while the source zip is labeled v0_1_36 and the Android port is 0.1.36/88. Android keeps 0.1.36/88 to match the zip label (the newer of the iOS markings); flagged to the owner in the final report.

## STEP 0 — housekeeping
- [x] 0a. Stale tree: no `and1/` exists anywhere on disk or in git history — nothing to delete. Real project is `work/android/`. No stale APK zip copies in the work tree (only the git-tracked `work/android/app-debug.apk` deliverable, kept).
- [x] 0b. This checklist rewritten from the audit HANDOFF (old one had 107 stale unchecked items from earlier waves).
- [x] 0c. Version mismatch documented above (reported, Android kept at 0.1.36/88).

## PART 1 — features
- [x] 1. openDirectDrawing full flow (EditorDialogs.kt:1134 stub → wire existing DrawingEditorViewController; Direct edits / Drawing applied / Separate layers; Allow Photos access / Couldn't save strings)
- [x] 2. Media import: importPickedItem / importPickedVideo / loadVideo / pickFromSystemPicker + 9 strings
- [x] 3. 3D picking: tapModel / tapMmd / tapVdb / tapVrm / loadAlbums / animateIn / chipTap / dismissSheet / expandTap + type routing (glb/mmd/vdb/vrm/collider/env) + 2 strings
- [x] 4. Depth Anything: real on-device inference (replaces READY-file stub)
- [x] 5. AnimeSeg: ONNX runtime + onnxRaw/mask() isnetis + subject-mask path
- [x] 6. HDR/EXR env decoder + RGBA16F mip upload (GlobalEnv.tex)
- [x] 7. Particular Designer: real share sheet + photo picker
- [x] 8. GraphPanel ellipsis: real popup menu
- [x] 9. FlareThumbs + EffectThumbs.generate + Registry compile-failure reporting
- [x] 10. All TODO(parity) resolved (33 remaining → 0; 12 justified PARITY-NOTEs — grep `PARITY-NOTE` in app/src for the list with iOS file:line refs)

## PART 2 — UI parity
- [x] 11. Strings audit + full 1196-string sweep
- [x] 12. Scene3DView gestures, PoseUI, LooksEditor, TerrainNodeEditor, SdkIde, Home, Drawing* URLs, search bars, monoTimeFont, EditorPuppet spacing

## PART 3 — renderers
- [x] 13. MetalModel vs Kotlin model renderer, section by section (audit done 2026-11: collider depth bias 4/4/0, aniso4 per-material samplers, GlobalEnv.tex() per-draw call implemented; docs/DEVICE_TEST.md lists what needs a device)
- [x] 14. SceneRenderer 34 unmatched functions + Metal* twin passes
- [x] 15. docs/DEVICE_TEST.md

## PART 4 — shared code
- [x] 16. docs/SHARED_CODE.md + move shareable data into shared/

## FINAL
- [x] 17. Scans: TODO(parity)=0, stub grep clean (2 hits are iOS-side strings), string residual 314 captured in docs/strings_missing*.json and ported (spot-verified present in Kotlin)
- [x] 18. assembleDebug BUILD SUCCESSFUL (fresh from-scratch rebuild this round: app-debug.apk 38.9 MB, 232 entries, .so page-aligned, apksigner-verified debug cert)
- [x] 19. SaikiMotion-Android-v0_1_36-final.zip delivered + honest report
