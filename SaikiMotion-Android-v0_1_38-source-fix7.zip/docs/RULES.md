# RULES (every AI session must follow these)

**BIG RULE: iOS is the spec. Never break or change an existing feature on either platform. Android must behave and look identical.**
**BIG RULE 2: do not burn the owner's tokens.**

## Parity
1. Before porting a feature, read ONLY its iOS source (grep + `sed -n a,bp`; never cat whole files > 300 lines). Port line-for-line: same constants, defaults, ordering, clamps, rounding, string formats.
2. Do not "improve", refactor, rename or simplify. Do not touch iOS source. Only edit an already-ported Android file to fix a diff against iOS.
3. File formats are shared. JSON keys/defaults/number formats identical to iOS (.saikiproject must open on both). Use Locale.US for formatting. org.json optDouble default is NaN: always pass explicit defaults.
4. No silent stubs. Unfinished = `// TODO(parity): <iOS file>:<line> <what is missing>` and status PARTIAL. Never mark DONE unless complete.
5. VERIFIED (status.json) only after a side-by-side iOS vs Android check (same project, same frame/time, same pixels or values). Otherwise say "unverified".
6. If an iOS API has no Android equivalent, DO NOT drop the feature: pick the closest substitute from the table below, note it in status.json, keep behavior identical.

## Shaders (same shaders on both)
7. Truth = `shared/shaders/msl/*` (extracted verbatim from iOS) + GLSL plugin effects in `shared/resources/sdk`. Vulkan twin lives in `shared/shaders/glsl/` with `// PORT-OF: msl/<file>::<fn>`, ported line-for-line (MSL `select(a,b,c)` == GLSL `mix(a,b,c)` with bool selector; `constexpr sampler linearClamp` == linear + clamp_to_edge).
8. After porting/verifying a shader run `python3 tools/shader_sync_check.py --stamp`; CI/next session runs it without `--stamp` and must be clean. If iOS shader changes, the MSL is re-extracted and the twin is re-ported.
9. Vulkan uses a NEGATIVE-HEIGHT viewport (y-up NDC like Metal). Never "fix" flips inside shaders. Swapchain B8G8R8A8_UNORM (no sRGB), offscreen RGBA16F, same as iOS.

## Token discipline
10. One subsystem per session. Don't re-survey: read docs/PARITY.md + HANDOFF.md only. Don't re-print big files in chat; write them to disk.
11. Record progress by editing `tools/status.json` and running `tools/parity_table.py --ios <iOS Sources>`; append ONE line to the Session log in HANDOFF.md. Do not rewrite docs.
12. Stop before running out of budget: leave the tree compiling (or clearly flagged), update status, output the HANDOFF block.

## iOS -> Android substitutes (keep behavior identical)
UIKit views/gestures -> Android Views/Compose with identical layout metrics (Theme.swift values) | Metal -> Vulkan (NDK) | GLSL->MSL translator (MetalEffects) -> use GLSL directly (wrap like Gl.effectShaderSource, compile at runtime with NDK shaderc) | AVFoundation (video decode/encode/audio) -> MediaCodec/MediaExtractor/MediaMuxer/AudioTrack | PhotosUI -> Photo Picker | UniformTypeIdentifiers -> MIME types | CoreText/CoreGraphics (TextRaster, drawing) -> Android Canvas/Paint/StaticLayout producing same bitmaps | ImageIO -> BitmapFactory/ImageDecoder | Vision/CoreML/Onnx -> onnxruntime-android | Compression -> java.util.zip | CCrashLog (mach/signals) -> NDK sigaction | OpenGLES/GLKit legacy path -> superseded by the Metal path; port the Metal path.
