# Shared code between iOS and Android (v0.1.36 audit round)

The port lives in `work/android/`. This file records what is genuinely shared with the
iOS app (`SaikiMotion-v0_1_36-src.zip` → Sources/) versus what is written twice.

## 1. Genuinely shared (byte-for-byte, both platforms read the same files)

Location: `work/android/shared/` — the same directory ships inside the iOS app bundle.

| Item | Path | Notes |
| --- | --- | --- |
| Effect catalog (175 effects) | `shared/resources/catalog/builtins.json` | one JSON both platforms parse; labels, defaults, GLSL code, prop tables |
| SDK examples + plugins | `shared/resources/sdk/**` | effect.json + effect.glsl folders, identical |
| Image assets (presets, previews) | `shared/resources/img/**` | 5.4 MB |
| GLSL shaders (Vulkan) | `shared/shaders/glsl/*.frag/.vert` (25 files) | the Vulkan twins; `model_rt.frag` is generated from the MSL by `android/tools/gen_model_rt.py` |
| MSL shaders (Metal) | `shared/shaders/msl/*` | kept as the iOS source of truth; GLSL files are hand/generator twins of these |
| .abc Alembic decoder | `app/src/main/cpp/native/` C decoder | the same C sources the iOS app compiles (outside shared/, but byte-identical); Android builds them via CMake |
| Blosc decompressor | `app/src/main/cpp/native/blosc/` (c-blosc) | used by VdbVolume on both platforms |
| Build/parity tooling | `android/tools/` (dump_catalog.sh, gen_model_rt.py, parity_table.py, shader_sync_check.py) | generates builtins.json + RT shader + parity tables |

Shader parity is enforced by `android/tools/shader_sync_check.py`; the effect count parity
(175 = 175) by `android/tools/dump_catalog.sh`.

## 2. Duplicated (same logic, written twice: Swift vs Kotlin)

Everything in the app layer — by necessity, since UIKit ≠ Android custom stack:

- **UI layer**: all view controllers/panels (Editor*, Home*, Drawing*, Rig/Puppet, MBL,
  Particular, Terrain, SdkIde, MediaBrowser, …). Kotlin twins in `app/src/main/java/com/saiki/motion/{app,ui}/`.
- **UIKit shim**: `uikit/` (UIView/UILabel/UIScrollView/UITableView/UIAlertController/
  gestures/Animator) — custom Android implementation of the UIKit API surface.
- **Model/data**: Layer/Track/Key/Project JSON, Json.swift↔Json.kt parser, Store, Prefs —
  same keys and same float formatting (verified shortest-round-trip parity this round).
- **Importers**: GlbModel, MmdImport, FbxImport, PlyImport (Kotlin) vs Swift equivalents;
  VdbVolume Kotlin reader + native blosc.
- **Renderers**: Metal* (Swift) vs Kotlin+C++/Vulkan twins (MetalModel/MetalModelDraw,
  SceneRenderer/SceneRendererN + jni_scene/vk_core/vk_model, MetalFlare/Glow/Particles/
  Volume, MetalCam, MetalImageCache, VideoFrames).
- **ML inference**: iOS Core ML/Vision vs Android ONNX Runtime (AnimeSeg isnetis,
  DepthAnything V2 small/large) — same models' different runtimes, same preprocessing math.
- **ON-CPU effects**: FxSteps/FxGlsl orchestration mirrors MetalEffects; effect GLSL bodies
  come from the shared catalog, the host-side step logic is duplicated.

## 3. Moves made this round (data → shared/)

None needed beyond what exists: strings, presets, effect definitions, images and shaders
were already shared through `shared/` + `builtins.json`. The PtBuiltins/UniversePresets
preset tables were verified to live inside the shared catalog (verified in earlier waves;
no preset data remains Kotlin-only).

## 4. Intentional divergences (documented, not shared)

- Metal-only files not ported (per HANDOFF baseline): Gl.swift, MetalPreview,
  RenderBackend, MetalParity, MetalSceneParity, MetalDebug, AppDelegate/SceneDelegate.
- Android uses Vulkan (SPIR-V via precompiled assets) instead of Metal; GLSL twins of the
  MSL sources; ray query instead of Metal RT.
- Core ML/Vision → ONNX Runtime / MediaCodec for ML + media decode.
- 12 justified PARITY-NOTEs remain in code (Vision subject-lift, GL plugin runtime, ULP
  float notes, fixed Vulkan arena vs iOS grow-on-demand, shaderc compile thread, etc.)
  — grep `PARITY-NOTE` for the exact list with iOS file:line refs.
