#!/bin/bash
# ndk-build the NDK r26 shaderc sources into the libs/<stl>/<abi> layout CMakeLists.txt expects.
# (Recreates the prebuilt static libs; the previous ones were lost with the sandbox.)
set -e
W=/home/z/my-project/work
NDK=$W/tools/sdk/ndk/26.1.10909125
SC=$NDK/sources/third_party/shaderc
cd "$SC"
for ABI in arm64-v8a x86_64; do
  $NDK/ndk-build APP_ABI=$ABI APP_STL=c++_shared APP_PLATFORM=android-24 \
    NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=Android.mk \
    -j$(nproc) > /tmp/shaderc_$ABI.log 2>&1 || { tail -30 /tmp/shaderc_$ABI.log; exit 1; }
done
echo done
