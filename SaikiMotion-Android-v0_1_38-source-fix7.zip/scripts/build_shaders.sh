#!/bin/bash
# Compile android/shared/shaders/glsl -> android/app/src/main/assets/shaders/<file>.spv
# IMPORTANT: the native code loads "shaders/<full file name>.spv" (e.g. blit.frag.spv, fs.vert.spv, model.vert.spv),
# so the output name KEEPS the .vert/.frag extension (vert and frag with the same base name must not collide).
# Target: Vulkan 1.1 (SPIR-V 1.3) so Mali-G52 class devices (Vulkan 1.1.x) accept the modules.
# Only model_rt (ray query) needs Vulkan 1.2; it is only loaded when the device exposes ray query.
set -e
ROOT="${1:-$(cd "$(dirname "$0")/../android" && pwd)}"
NDK="${ANDROID_NDK_HOME:-${ANDROID_HOME}/ndk/26.1.10909125}"
G="${GLSLC:-$NDK/shader-tools/linux-x86_64/glslc}"
SRC="$ROOT/shared/shaders/glsl"
OUT="$ROOT/app/src/main/assets/shaders"
mkdir -p "$OUT"; rm -f "$OUT"/*.spv
n=0
for f in "$SRC"/*.vert "$SRC"/*.frag; do
  [ -e "$f" ] || continue
  b=$(basename "$f"); stage="${b##*.}"
  env=vulkan1.1; case "$b" in model_rt.*) env=vulkan1.2;; esac
  if ! "$G" --target-env=$env -fshader-stage=$stage "$f" -o "$OUT/$b.spv" 2> /tmp/glslc_err.txt; then
    echo "WARN: $b failed for $env, retrying with vulkan1.2:"; cat /tmp/glslc_err.txt
    "$G" --target-env=vulkan1.2 -fshader-stage=$stage "$f" -o "$OUT/$b.spv"
    echo "WARN: $b is SPIR-V 1.5 -> may be rejected by Vulkan 1.1 drivers"
  fi
  n=$((n+1))
done
echo "compiled $n shaders -> $OUT"
python3 - "$OUT" <<'PY'
import glob,struct,sys
for f in sorted(glob.glob(sys.argv[1]+'/*.spv')):
    v=struct.unpack('<II',open(f,'rb').read(8))[1]
    print(f.split('/')[-1], 'SPIR-V %d.%d'%((v>>16)&255,(v>>8)&255))
PY
