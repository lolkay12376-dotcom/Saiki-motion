#!/usr/bin/env python3
"""Package the FINAL deliverable zip (v0.1.36 audit round, polish pass).

Layout inside the zip (all paths relative to the zip root, no `..` escapes):
  android/...        the whole Android project (source, shared/, wrapper, APK)
  docs/...           the port docs (PARITY, HANDOFF, DEVICE_TEST, SHARED_CODE, PORT_CHECKLIST, ...)
  tools/...          the small parity/build tools (catalog_dump, dump_catalog.sh, ...)
  scripts/...        build helper scripts
  README.md          top-level pointer
"""
import os, zipfile

W = "/home/z/my-project/work"
OUT = "/home/z/my-project/download/SaikiMotion-Android-v0_1_36-final.zip"
if os.path.exists(OUT): os.remove(OUT)

# NOTE: no "sdk" here — android/shared/resources/sdk/ is real content. The vendored toolchain
# under work/tools/ is never walked (tools/ is added file-by-file below).
SKIP_DIRS = {"build", ".gradle", ".cxx", "obj", "gradle-home",
             "restore", "gradle-8.7"}
SKIP_FILES = {".log"}                                   # build logs

zf = zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED)
count = 0

def add_tree(abs_dir, arc_root):
    """Add abs_dir recursively under arc_root, skipping toolchain/build junk."""
    global count
    for root, dirs, files in os.walk(abs_dir):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            if os.path.splitext(f)[1] in SKIP_FILES: continue
            p = os.path.join(root, f)
            zf.write(p, os.path.join(arc_root, os.path.relpath(p, abs_dir)))
            count += 1

add_tree(f"{W}/android", "android")          # project incl. wrapper, tools/, APKs (app-release + app-debug at android/ root)
add_tree(f"{W}/docs", "docs")
add_tree(f"{W}/scripts", "scripts")

zf.close()
print("wrote", OUT, os.path.getsize(OUT), "bytes,", count, "files")
