package com.saiki.motion

import android.app.Activity
import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Choreographer
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.FrameLayout
import com.saiki.motion.app.HomeViewController
import com.saiki.motion.core.AudioLibrary
import com.saiki.motion.core.CrashLog
import com.saiki.motion.core.FreezeWatchdog
import com.saiki.motion.core.Paths
import com.saiki.motion.render.NativeRenderer
import com.saiki.motion.uikit.Navigator
import com.saiki.motion.uikit.appContext

/**
 * Main.swift twin: hosts the UIKit layer (Navigator root = the app's UI tree) over the Vulkan
 * core's SurfaceView. The surface stays alive underneath; the editor's PreviewView renders into
 * it (GLKView parity), so surfaceCreated only inits the renderer, never replaces the content view.
 */
class MainActivity : Activity(), SurfaceHolder.Callback, Choreographer.FrameCallback {
    private var running = false
    private var uiBooted = false

    /** Android-only diagnostics: on any uncaught exception, save the stack trace to Downloads/SaikiMotion-crash.txt (no permission needed on API 29+). */
    private fun installCrashFileWriter() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val text = "SaikiMotion crash  " + java.util.Date() + "\nthread: " + t.name +
                    "\ndevice: " + Build.MANUFACTURER + " " + Build.MODEL + "  Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")" +
                    "\nabis: " + Build.SUPPORTED_ABIS.joinToString() + "\n\n" + android.util.Log.getStackTraceString(e)
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, "SaikiMotion-crash.txt")
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                if (uri != null) contentResolver.openOutputStream(uri, "w")?.use { it.write(text.toByteArray()) }
            } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }

    // ---- boot diagnostics (Android-only): on-screen log + Downloads/SaikiMotion-boot.txt, so a blank screen still tells us why ----
    private var diag: android.widget.TextView? = null
    private val diagLog = StringBuilder()
    private fun d(msg: String) {
        SaikiLog.log(msg)
        diagLog.append(msg).append('\n')
        val t = diagLog.toString()
        runOnUiThread { diag?.text = t }
    }
    private fun writeBootFile() {
        try {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "SaikiMotion-boot.txt")
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
            if (uri != null) contentResolver.openOutputStream(uri, "w")?.use { it.write(diagLog.toString().toByteArray()) }
        } catch (_: Throwable) {}
    }
    private fun dumpTree(v: android.view.View, depth: Int, maxDepth: Int, sb: StringBuilder) {
        sb.append("  ".repeat(depth)).append(v.javaClass.simpleName).append(' ').append(v.width).append('x').append(v.height)
            .append(" @").append(v.left).append(',').append(v.top).append(" vis=").append(v.visibility)
        if (v is android.view.ViewGroup) { sb.append(" kids=").append(v.childCount); sb.append('\n')
            if (depth < maxDepth) for (i in 0 until minOf(v.childCount, 12)) dumpTree(v.getChildAt(i), depth + 1, maxDepth, sb) }
        else sb.append('\n')
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SaikiLog.log("MainActivity.onCreate begin")
        com.saiki.motion.uikit.setCurrentActivity(this)   // Navigator/dialogs/pickers need it; was never set -> UI never attached (gradient-only screen)
        installCrashFileWriter()
        System.loadLibrary("saiki")   // before the first native call (CrashLog.install below)
        appContext = this   // UIKit shim needs it for view construction
        Paths.init(this); Paths.ensure()
        CrashLog.install(); installCrashFileWriter(); FreezeWatchdog.start(); AudioLibrary.dir  // Main.swift parity
        val sv = SurfaceView(this); sv.holder.addCallback(this)
        val host = Navigator.host(this)      // FrameLayout root
        host.addView(sv, FrameLayout.LayoutParams(-1, -1))
        diag = android.widget.TextView(this).apply {
            setTextColor(0xFF00FF66.toInt()); textSize = 10f; setBackgroundColor(0xB0000000.toInt()); setPadding(12, 12, 12, 12)
            setTextIsSelectable(false); isClickable = false
        }
        addContentView(diag, FrameLayout.LayoutParams(-2, -2))      // window level: always above the app's screens
        d("SaikiMotion boot  " + Build.MODEL + "  API " + Build.VERSION.SDK_INT)
        d("onCreate: libsaiki + paths ok")
        try {
            Navigator.setRoot(HomeViewController())
            d("setRoot(Home): ok")
        } catch (t: Throwable) {
            d("setRoot(Home) FAILED:\n" + android.util.Log.getStackTraceString(t).take(1800))
        }
        uiBooted = true
        SaikiLog.log("MainActivity.onCreate end (UI tree built)")
        val hostView = host
        val report = Runnable {
            val sb = StringBuilder()
            dumpTree(hostView, 0, 3, sb)
            d("view tree:\n" + sb.toString().take(1500))
            writeBootFile()
        }
        hostView.postDelayed(report, 2500)
    }

    override fun surfaceCreated(h: SurfaceHolder) {
        d("surfaceCreated uiBooted=$uiBooted")
        if (uiBooted) {
            running = try { NativeRenderer.init(h.surface, assets) } catch (t: Throwable) { d("NativeRenderer.init threw: $t"); false }
            d("vkInit=" + running)
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) { NativeRenderer.resize(w, hh) }
    override fun onResume() { super.onResume(); com.saiki.motion.uikit.setCurrentActivity(this) }
    override fun onDestroy() { super.onDestroy(); if (com.saiki.motion.uikit.currentActivity?.get() === this) com.saiki.motion.uikit.setCurrentActivity(null) }
    override fun surfaceDestroyed(h: SurfaceHolder) { running = false; NativeRenderer.destroy() }
    override fun doFrame(ns: Long) {
        if (!running) return
        NativeRenderer.frame(ns / 1e9f)
        Choreographer.getInstance().postFrameCallback(this)
    }
}
