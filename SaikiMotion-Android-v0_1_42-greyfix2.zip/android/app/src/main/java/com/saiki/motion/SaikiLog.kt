package com.saiki.motion

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Android-only diagnostics. Everything lands in  Download/SaikiMotion-Logs/  (visible in the Files app):
 *   launch-<time>.txt   boot steps, every uncaught exception (all threads), main-thread-hang stack dumps, own logcat
 *   native-<name>.log   native crash reports copied over from the app's Crash folder on the next launch
 * Written from a background thread so a frozen UI thread can't stop the log; no permissions needed (API 29+).
 */
object SaikiLog {
    private var ctx: Context? = null
    private var uri: android.net.Uri? = null
    private val sb = StringBuilder()
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "saiki-log").apply { isDaemon = true } }
    @Volatile private var beat = System.currentTimeMillis()
    @Volatile private var started = false
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private const val DIR = "Download/SaikiMotion-Logs"

    fun init(c: Context) {
        if (started) return
        started = true
        ctx = c.applicationContext ?: c
        try {
            val name = "launch-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt"
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, DIR)
            }
            uri = ctx!!.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
        } catch (_: Throwable) {}
        log("SaikiMotion launch  " + Build.MANUFACTURER + " " + Build.MODEL + "  Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")  abis=" + Build.SUPPORTED_ABIS.joinToString())
        if (uri == null) log("WARNING: could not create the log file in Downloads")
        installHandler()
        startHangWatch()
        copyNativeCrashes()
    }

    @Synchronized fun log(msg: String) {
        sb.append(fmt.format(Date())).append("  ").append(msg).append('\n')
        if (sb.length > 300_000) sb.delete(0, sb.length - 250_000)
        val text = sb.toString()
        io.execute { write(text) }
    }

    private fun write(text: String) {
        try {
            val u = uri ?: return
            ctx?.contentResolver?.openOutputStream(u, "wt")?.use { it.write(text.toByteArray()) }
        } catch (_: Throwable) {}
    }

    /** Synchronous variant for the dying process. */
    @Synchronized private fun logNow(msg: String) {
        sb.append(fmt.format(Date())).append("  ").append(msg).append('\n')
        write(sb.toString())
    }

    private fun ownLogcat(lines: Int = 250): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("logcat", "-d", "-t", lines.toString(), "-v", "time"))
        val t = p.inputStream.bufferedReader().readText(); p.destroy(); t
    } catch (e: Throwable) { "(logcat unavailable: $e)" }

    private fun installHandler() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                logNow("=== UNCAUGHT EXCEPTION on thread '" + t.name + "' ===\n" + android.util.Log.getStackTraceString(e))
                logNow("--- own logcat (last 250 lines) ---\n" + ownLogcat())
            } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }

    /** Main-thread hang detector: a frozen/looping UI thread (blank screen, no crash) gets its stack written to the log. */
    private fun startHangWatch() {
        val main = Handler(Looper.getMainLooper())
        val tick = object : Runnable { override fun run() { beat = System.currentTimeMillis(); main.postDelayed(this, 500) } }
        main.post(tick)
        Thread({
            var dumps = 0; var lastTop = ""; var sentLogcat = false
            val t0 = System.currentTimeMillis()
            while (true) {
                try { Thread.sleep(1000) } catch (_: InterruptedException) {}
                val now = System.currentTimeMillis()
                if (!sentLogcat && now - t0 > 8000) { sentLogcat = true; logNow("--- own logcat 8s after launch ---\n" + ownLogcat()) }
                val blocked = now - beat
                if (blocked > 3000 && dumps < 25) {
                    val st = Looper.getMainLooper().thread.stackTrace
                    val top = st.take(3).joinToString("|")
                    if (top != lastTop || dumps % 5 == 0) {
                        dumps++; lastTop = top
                        logNow("=== MAIN THREAD BLOCKED for " + (blocked / 1000) + "s — it is stuck here ===\n" + st.take(60).joinToString("\n") { "    at $it" })
                    }
                }
            }
        }, "saiki-hang-watch").apply { isDaemon = true }.start()
    }

    private fun copyNativeCrashes() {
        io.execute {
            try {
                val c = ctx ?: return@execute
                val dir = File(File(c.filesDir, "SaikiMotion"), "Crash")
                val seen = File(c.filesDir, "copied_crashes.txt")
                val done = if (seen.exists()) seen.readLines().toHashSet() else HashSet()
                for (f in dir.listFiles() ?: emptyArray()) {
                    if (!f.isFile || f.name in done || f.length() > 2_000_000) continue
                    val v = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, "native-" + f.name)
                        put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                        put(MediaStore.Downloads.RELATIVE_PATH, DIR)
                    }
                    val u = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: continue
                    c.contentResolver.openOutputStream(u, "wt")?.use { it.write(f.readBytes()) }
                    seen.appendText(f.name + "\n")
                }
            } catch (_: Throwable) {}
        }
    }
}

class SaikiApp : android.app.Application() {
    override fun onCreate() { super.onCreate(); SaikiLog.init(this); SaikiLog.log("Application.onCreate") }
}
