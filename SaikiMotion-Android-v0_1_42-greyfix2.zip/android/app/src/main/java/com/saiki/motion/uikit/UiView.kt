@file:Suppress("unused", "MemberVisibilityCanBePrivate", "FunctionName", "LeakingThis")

package com.saiki.motion.uikit

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.view.MotionEvent
import android.view.ViewGroup

// UiView.kt — the UIView twin every ported view extends. Frame-based layout with a UIKit-style
// draw(rect:) callback; touches arrive as UITouch sets; onClick fires on touch-up inside bounds.

@SuppressLint("ViewConstructor")
open class UiView(context: Context) : ViewGroup(context) {
    /** Swift-style no-argument constructor (appContext must be set at app start). */
    constructor() : this(appContext ?: throw IllegalStateException("appContext not set"))

    /** UIKit frame (x, y, w, h) in the parent's coordinate space. */
    var frame: CGRect = CGRect(0f, 0f, 0f, 0f)
        set(v) {
            val changed = field != v
            field = v
            if (changed) {
                layout(v.x.toInt(), v.y.toInt(), (v.x + v.width).toInt(), (v.y + v.height).toInt())
                requestLayout()
            }
        }

    /** Extra transform applied on top of the frame (viewport zoom/pan). */
    var transform: Matrix? = null
        set(v) { field = v; setNeedsDisplay() }   // UIKit's transform setter invalidates through setNeedsDisplay
    fun setTransformIdentity() { transform = null }

    var onClick: (() -> Unit)? = null
    var isHighlighted: Boolean
        get() = isPressed
        set(v) { isPressed = v; invalidate() }
    var isHidden: Boolean
        get() = visibility == GONE || visibility == INVISIBLE
        set(v) { visibility = if (v) INVISIBLE else VISIBLE }
    val window: UiView? get() = (context as? android.app.Activity)?.window?.decorView as? UiView
    val superview: UiView? get() = parent as? UiView
    val subviews: List<UiView> get() = (0 until childCount).mapNotNull { getChildAt(it) as? UiView }

    /** UIKit isShown (renamed: View.isShown() owns the JVM signature). */
    val isShownNow: Boolean get() = visibility == VISIBLE && parent != null


    /** iOS autoresizing flag — kept for source compatibility (no-op; frame layout is manual). */
    var translatesAutoresizingMaskIntoConstraints = false

    var isMultipleTouchEnabled: Boolean
        get() = true
        set(v) { isMotionEventSplittingEnabled = v }

    /** UIKit isUserInteractionEnabled: disabled views swallow touches. */
    var isUserInteractionEnabled: Boolean
        get() = isEnabled && visibility == VISIBLE && visibility != GONE
        set(v) { isEnabled = v }

    var clipsToBounds: Boolean
        get() = clipChildren
        set(v) { clipChildren = v; clipToOutline = v }

    /** UIKit-safe aliases (bounds conflicts with View.bounds in some usages). */
    val boundsRect: CGRect get() = CGRect(0f, 0f, width.toFloat(), height.toFloat())
    fun rectWidth(): CGFloat = width.toFloat()
    fun rectHeight(): CGFloat = height.toFloat()
    fun rectLeft(): CGFloat = left.toFloat()
    fun rectTop(): CGFloat = top.toFloat()
    fun rectRight(): CGFloat = right.toFloat()
    fun rectBottom(): CGFloat = bottom.toFloat()

    open fun setNeedsDisplay() { invalidate() }

    /** UIKit viewWithTag/tag: screens tag their subviews and look them up later. */
    var tagId: Int = 0
    fun setTag(t: Int) { tagId = t }
    fun findViewWithTag(t: Int): UiView? {
        if (tagId == t) return this
        for (i in 0 until childCount) {
            val c = getChildAt(i) as? UiView ?: continue
            c.findViewWithTag(t)?.let { return it }
        }
        return null
    }

    /** App-wave layout hook: called with the parent width when the owning screen lays out. */
    var postLayout: ((CGFloat) -> Unit)? = null
    /** Second hook (screens that need a later pass after content build). */
    var postLayout2: ((Float) -> Unit)? = null
    /** Generic layout hook: row wrappers assign their inner frames here (called from layoutSubviews). */
    var onLayoutSubviews: (() -> Unit)? = null


    fun addSubview(v: UiView) { addView(v) }
    fun subviewsList(): List<UiView> = (0 until childCount).mapNotNull { getChildAt(it) as? UiView }
    fun removeFromSuperview() { (parent as? ViewGroup)?.removeView(this) }

    /** Convert this view's bounds rect into `to`'s coordinate space. */
    fun convertBoundsTo(to: UiView): CGRect {
        val a = IntArray(2); val b = IntArray(2)
        getLocationOnScreen(a); to.getLocationOnScreen(b)
        val dx = (a[0] - b[0]).toFloat(); val dy = (a[1] - b[1]).toFloat()
        return CGRect(dx, dy, width.toFloat(), height.toFloat())
    }

    val safeAreaInsets: UIEdgeInsets
        get() {
            val r = if (android.os.Build.VERSION.SDK_INT >= 28) rootWindowInsets?.systemWindowInsets else null
            return UIEdgeInsets((r?.top ?: 0).toFloat(), (r?.left ?: 0).toFloat(), (r?.bottom ?: 0).toFloat(), (r?.right ?: 0).toFloat())
        }

    // MARK: - lifecycle hooks (UIKit names)

    open fun layoutSubviews() { }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            // UiView children own their frame (set via `frame`, which lays them out directly): keep it. Re-using the
            // measured size here clobbered children laid out during this pass (stale measure => zero-size screens).
            if (c is UiView) c.layout(c.left, c.top, c.right, c.bottom)
            else c.layout(c.left, c.top, c.left + c.measuredWidth, c.top + c.measuredHeight)
        }
        if (changed) { layoutSubviews(); onLayoutSubviews?.invoke() }
    }

    public override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w != ow || h != oh) {
            layoutSubviews()
            onLayoutSubviews?.invoke()
            postLayout?.invoke(w.toFloat())
        }
    }

    /** iOS-port closure layout hook (LooksEditor and friends): the new width after a size change. */
    var onLayout: ((Float) -> Unit)? = null

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val mw = if (width - paddingLeft - paddingRight > 0) width - paddingLeft - paddingRight else 0
            val mh = if (height - paddingTop - paddingBottom > 0) height - paddingTop - paddingBottom else 0
            if (c is UiView) { c.measure(MeasureSpec.makeMeasureSpec(c.width, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(c.height, MeasureSpec.EXACTLY)); continue }
            c.measure(MeasureSpec.makeMeasureSpec(mw, MeasureSpec.UNSPECIFIED),
                      MeasureSpec.makeMeasureSpec(mh, MeasureSpec.UNSPECIFIED))
        }
        setMeasuredDimension(resolveSize(width, widthSpec), resolveSize(height, heightSpec))
    }

    /** UIKit draw(_:) — the current UIGraphics context wraps the canvas. */
    open fun draw(rect: CGRect) { }
    /** Optional direct-Canvas draw hook (HelpDocs StaticLayout etc.); called after draw(rect:). */
    var drawBlock: ((android.graphics.Canvas) -> Unit)? = null
    final override fun onDraw(canvas: Canvas) {
        val c = UIGraphics.push(canvas)
        try {
            canvas.save()
            transform?.let { canvas.concat(it) }
            draw(CGRect(0f, 0f, width.toFloat(), height.toFloat()))
            drawBlock?.invoke(canvas)
            canvas.restore()
        } finally {
            UIGraphics.pop()
        }
    }

    open fun didMoveToWindow() { }
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        didMoveToWindow()
    }

    open fun onScroll(l: Int, t: Int, oldl: Int, oldt: Int) { }

    // MARK: - touches (UIKit-style sets)

    open fun touchesBegan(touches: Set<UITouch>, event: UIEvent?) { }
    open fun touchesMoved(touches: Set<UITouch>, event: UIEvent?) { }
    open fun touchesEnded(touches: Set<UITouch>, event: UIEvent?) { }
    open fun touchesCancelled(touches: Set<UITouch>, event: UIEvent?) { }

    /** UIKit point(inside:with:): can a touch at this point (this view's coordinates) hit this view?
     *  Default = the frame bounds; views with a hit area outside their bounds override this. */
    open fun pointInside(p: CGPoint): Boolean = p.x >= 0 && p.x <= width && p.y >= 0 && p.y <= height

    private var activeTouches = HashMap<Int, UITouch>()
    private val recognizers = ArrayList<UIGestureRecognizer>()
    private var clickDownX = 0f
    private var clickDownY = 0f
    private var pendingClick = false
    /** Last touch location in this view's coordinates (g.location(in:) parity for click handlers). */
    var lastTouchLocation: CGPoint = CGPoint(0f, 0f)
        private set

    fun addGestureRecognizer(g: UIGestureRecognizer) { recognizers.add(g) }
    fun removeGestureRecognizer(g: UIGestureRecognizer) { recognizers.remove(g) }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val t = when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                clickDownX = e.x; clickDownY = e.y; pendingClick = true
                lastTouchLocation = CGPoint(e.x, e.y)
                UITouch(e.x, e.y, UITouchPhase.began)
            }
            MotionEvent.ACTION_MOVE -> UITouch(e.x, e.y, UITouchPhase.moved)
            MotionEvent.ACTION_UP -> UITouch(e.x, e.y, UITouchPhase.ended)
            MotionEvent.ACTION_CANCEL -> UITouch(e.x, e.y, UITouchPhase.cancelled)
            else -> null
        }
        if (t == null) return super.onTouchEvent(e)
        val set = setOf(t)
        val ev = UIEvent(set)
        // gestures first (pinch/pan/tap/long-press)
        var handled = false
        for (g in recognizers) if (g.enabled && g.onTouchEvent(e, this)) handled = true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { activeTouches[e.getPointerId(0)] = t; touchesBegan(set, ev) }
            MotionEvent.ACTION_MOVE -> { activeTouches[e.getPointerId(0)] = t; touchesMoved(set, ev) }
            MotionEvent.ACTION_UP -> {
                activeTouches.remove(e.getPointerId(0))
                touchesEnded(set, ev)
                lastTouchLocation = CGPoint(e.x, e.y)
                // TapView semantics: click when the finger went down and came up inside the bounds
                if (pendingClick && onClick != null) {
                    val inside = e.x >= 0 && e.x <= width && e.y >= 0 && e.y <= height
                    val moved = Math.abs(e.x - clickDownX) > 12 || Math.abs(e.y - clickDownY) > 12
                    if (inside && !moved) onClick?.invoke()
                }
                pendingClick = false
            }
            MotionEvent.ACTION_CANCEL -> { activeTouches.remove(e.getPointerId(0)); touchesCancelled(set, ev); pendingClick = false }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        onClick?.invoke()
        return true
    }

}
