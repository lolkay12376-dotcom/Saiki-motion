# Saiki Motion

Native Android motion-graphics editor (Kotlin + OpenGL ES 2.0). No WebView, no FFmpeg, no third-party libraries.

## What is inside
- **My Playground**: project menu. Create projects up to 4K and 120 fps, rename, duplicate, delete.
- **Bottom tool bar**: Media, Text, Shape, Camera, Null, Particles, 3D Model. Tap a layer to get Edit, Transform, Effects, Blending, Speed, Graph.
- **Video** through the system MediaCodec decoder (frame accurate, adds 0 MB to the APK).
- **3D**: cube icon in the top bar turns a layer 3D. Camera layers, Null layers (a Null must be 3D to drive children) and Parent links.
- **Bezier graph** editor for keyframe easing, per segment.
- **Effects**: DistortRGB, Etching, HalfTone, PsykoBlobs, Shake, TextureFolded, TextureMoire, Zebrafy, Twitch, Deep Glow,
  RGB Split, Blur, Wave Warp, Pixelate, Grayscale, Invert, Motion Tile, Time Remap, Swing, Layer Shake.
  Each has an animated before/after swipe icon rendered with the real shader on the bundled portrait.
- **Custom effects and presets**: create or import effects (JSON + GLSL), save, import and export presets.
- **Particle World**: particle layer with birth rate, producer, physics, size, color and opacity controls.
- **GLB import**: static meshes, baked and uploaded once to the GPU.

## Custom effect file format (`*.saikieffect.json`)
```json
{
  "name": "Mono Mix",
  "description": "Blends the image with grayscale.",
  "category": "Custom",
  "params": [{ "name": "amount", "label": "Amount", "min": 0, "max": 1, "def": 1 }],
  "inputs": [],
  "code": "vec4 effect(vec2 uv) { vec4 c = src(uv); return vec4(mix(c.rgb, vec3(luma(c.rgb)) * c.a, amount), c.a); }"
}
```
Helpers available in code: `src(uv)`, `in0(uv)`, `in1(uv)`, `srcW(uv, mode)`, `luma`, `hash11`, `hash21`, `fbm`, `rot`, `hsv2rgb`, `unpremul`,
and `uTime`, `uRes`. Each param becomes a `uniform float` with its name. `src()` is premultiplied alpha.

## Build the APK on GitHub
1. Upload `SaikiMotion.zip` (replace the old one) to the repository root, together with `.github/workflows/build.yml`.
2. Open the Actions tab, wait for the green check, download the artifact **SaikiMotion-APK**.
3. Unzip, send `app-debug.apk` to the Android device and install it.

## Build locally
Android Studio (JDK 17) or `gradle assembleDebug` with Gradle 8.7. minSdk 29.
