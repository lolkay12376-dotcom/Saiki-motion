package com.saiki.motion

import android.content.Context
import android.view.View
import android.widget.FrameLayout

/** Fits its children to the project aspect ratio, centred inside the available space. */
class AspectLayout(ctx: Context) : FrameLayout(ctx) {
    var ratio = 16f / 9f
        set(v) { field = v; requestLayout() }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec)
        val maxH = MeasureSpec.getSize(hSpec)
        var w = maxW
        var h = (w / ratio).toInt()
        if (h > maxH) { h = maxH; w = (h * ratio).toInt() }
        setMeasuredDimension(maxW, maxH)
        for (i in 0 until childCount) {
            getChildAt(i).measure(
                MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val c: View = getChildAt(i)
            val cw = c.measuredWidth
            val ch = c.measuredHeight
            val cl = (r - l - cw) / 2
            val ct = (b - t - ch) / 2
            c.layout(cl, ct, cl + cw, ct + ch)
        }
    }
}
