package com.saiki.motion

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object AudioTools {
    private fun audioTrack(ex: MediaExtractor): Int {
        for (i in 0 until ex.trackCount) if ((ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) return i
        return -1
    }

    /** Copies the audio track of a video into an .m4a file without re-encoding. */
    fun extractAudio(src: String, out: File): Boolean {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(src)
            val idx = audioTrack(ex)
            if (idx < 0) return false
            ex.selectTrack(idx)
            val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val tr = mux.addTrack(ex.getTrackFormat(idx))
            mux.start()
            val buf = ByteBuffer.allocate(1 shl 20)
            val info = MediaCodec.BufferInfo()
            while (true) {
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                info.set(0, n, ex.sampleTime, ex.sampleFlags)
                mux.writeSampleData(tr, buf, info)
                ex.advance()
            }
            mux.stop(); mux.release()
            return true
        } finally { ex.release() }
    }

    /** Energy-flux beat detector. Returns beat times in seconds (first 3 minutes of audio). */
    fun detectBeats(path: String): List<Float> {
        val ex = MediaExtractor()
        ex.setDataSource(path)
        val idx = audioTrack(ex)
        if (idx < 0) { ex.release(); return emptyList() }
        val fmt = ex.getTrackFormat(idx)
        val sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        val ch = max(1, fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
        ex.selectTrack(idx)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0)
        codec.start()
        val hop = 1024
        val env = ArrayList<Float>()
        var acc = 0.0
        var cnt = 0
        var frames = 0L
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        var guard = 0
        while (!outDone && frames < sr * 180L && guard++ < 3_000_000) {
            if (!inDone) {
                val ii = codec.dequeueInputBuffer(5000)
                if (ii >= 0) {
                    val b = codec.getInputBuffer(ii)!!
                    val n = ex.readSampleData(b, 0)
                    if (n < 0) { codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                    else { codec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                }
            }
            val oi = codec.dequeueOutputBuffer(info, 5000)
            if (oi >= 0) {
                val ob = codec.getOutputBuffer(oi)!!
                ob.position(info.offset); ob.limit(info.offset + info.size)
                val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                val total = sb.remaining()
                var i = 0
                while (i + ch <= total) {
                    val s = sb.get(i) / 32768.0
                    acc += s * s; cnt++; frames++
                    if (cnt == hop) { env.add(sqrt(acc / hop).toFloat()); acc = 0.0; cnt = 0 }
                    i += ch
                }
                codec.releaseOutputBuffer(oi, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
            }
        }
        try { codec.stop() } catch (e: Exception) { }
        codec.release(); ex.release()
        val n = env.size
        val hopSec = hop.toFloat() / sr
        val flux = FloatArray(n) { if (it == 0) 0f else max(0f, env[it] - env[it - 1]) }
        val beats = ArrayList<Float>()
        var last = -1f
        val win = max(4, (1f / hopSec).toInt())
        for (i in 1 until n - 1) {
            var s = 0f
            var c = 0
            for (j in max(0, i - win)..min(n - 1, i + win)) { s += flux[j]; c++ }
            val thr = s / c * 1.6f + 0.002f
            if (flux[i] > thr && flux[i] >= flux[i - 1] && flux[i] >= flux[i + 1]) {
                val t = i * hopSec
                if (last < 0f || t - last > 0.22f) { beats.add(t); last = t }
            }
        }
        return beats
    }
}
