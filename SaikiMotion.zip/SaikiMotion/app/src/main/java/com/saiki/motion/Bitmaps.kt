package com.saiki.motion

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin

/** Turns a layer into a bitmap that is uploaded as a GL texture. */
object LayerBitmaps {
    fun baseHeight(l: Layer): Float = when (l.type) {
        LayerType.SHAPE -> 0.8f
        LayerType.TEXT -> 0.3f * l.texComp
        LayerType.IMAGE, LayerType.VIDEO -> 2.0f
        LayerType.CAMERA, LayerType.NULL -> 0.4f
        else -> 1.0f
    }

    fun make(l: Layer, lt: Float = 0f): Bitmap = when (l.type) {
        LayerType.SHAPE -> shape(l)
        LayerType.TEXT -> text(l, lt)
        else -> image(l)
    }

    private fun shape(l: Layer): Bitmap {
        val s = 512
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = l.color
        p.style = Paint.Style.FILL
        val m = 40f
        val r = RectF(m, m, s - m, s - m)
        when (l.shape) {
            ShapeKind.RECT -> c.drawRect(r, p)
            ShapeKind.ROUND -> c.drawRoundRect(r, 90f, 90f, p)
            ShapeKind.CIRCLE -> c.drawOval(r, p)
            ShapeKind.TRIANGLE -> {
                val path = Path()
                path.moveTo(s / 2f, m); path.lineTo(s - m, s - m); path.lineTo(m, s - m); path.close()
                c.drawPath(path, p)
            }
            ShapeKind.STAR -> {
                val path = Path()
                val cx = s / 2f
                val cy = s / 2f
                val ro = s / 2f - m
                val ri = ro * 0.45f
                for (i in 0 until 10) {
                    val ang = -Math.PI / 2 + i * Math.PI / 5
                    val rr = if (i % 2 == 0) ro else ri
                    val px = (cx + rr * cos(ang)).toFloat()
                    val py = (cy + rr * sin(ang)).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                c.drawPath(path, p)
            }
        }
        return bmp
    }

    private val faces = HashMap<String, Typeface>()

    private fun face(l: Layer): Typeface {
        val st = if (l.bold && l.italic) Typeface.BOLD_ITALIC else if (l.bold) Typeface.BOLD else if (l.italic) Typeface.ITALIC else Typeface.NORMAL
        val fp = l.fontPath
        if (fp != null) {
            faces["f:" + fp]?.let { return it }
            try { val tf = Typeface.createFromFile(fp); faces["f:" + fp] = tf; return tf } catch (e: Exception) { }
        }
        return faces.getOrPut(l.font + st) { Typeface.create(l.font, st) }
    }

    private fun easeU(u: Float, an: TextAnim): Float {
        val x = u.coerceIn(0f, 1f)
        return when (an.ease) {
            0 -> x
            1 -> 1f - (1f - x) * (1f - x)
            2 -> if (x < 0.5f) 2f * x * x else 1f - 2f * (1f - x) * (1f - x)
            3 -> bounceOut(x)
            else -> bezier(x, an.curve.x1, an.curve.y1, an.curve.x2, an.curve.y2)
        }
    }

    private fun rnd(q: Int, i: Int, k: Int): Float {
        val s = sin(q * 12.9898 + i * 78.233 + k * 37.719) * 43758.5453
        return (s - floor(s)).toFloat()
    }

    private fun text(l: Layer, lt: Float): Bitmap {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = 160f
        p.typeface = face(l)
        p.letterSpacing = l.p("spacing", lt)
        val s = if (l.text.isEmpty()) " " else l.text
        val tw = max(p.measureText(s), 40f)
        val fm = p.fontMetrics
        val th = fm.descent - fm.ascent
        val sw = l.p("strokeW", lt) * 3f
        val bw = l.p("borderW", lt) * 3f
        val anim = l.anims.isNotEmpty()
        val pad = 40f + (if (anim) 90f else 0f) + sw / 2f + (if (bw > 0f) l.p("borderPad", lt) * 2f + bw else 0f)
        val w = (tw + pad * 2).toInt().coerceIn(64, 4096)
        val h = (th + pad * 2).toInt()
        l.texComp = h / (th + 80f)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val x0 = pad
        val base = pad - fm.ascent
        if (bw > 0f) {
            val bp = Paint(Paint.ANTI_ALIAS_FLAG)
            bp.style = Paint.Style.STROKE; bp.strokeWidth = bw; bp.color = l.borderColor
            val bx = l.p("borderPad", lt) * 2f
            c.drawRoundRect(RectF(x0 - bx, pad - bx, x0 + tw + bx, pad + th + bx), 24f, 24f, bp)
        }
        val sp = Paint(Paint.ANTI_ALIAS_FLAG)
        sp.style = Paint.Style.STROKE; sp.strokeJoin = Paint.Join.ROUND
        sp.textSize = 160f; sp.typeface = p.typeface; sp.letterSpacing = l.p("spacing", lt)
        if (!anim) {
            if (sw > 0f) { sp.strokeWidth = sw; sp.color = l.strokeColor; c.drawText(s, x0, base, sp) }
            p.color = l.color
            c.drawText(s, x0, base, p)
            return bmp
        }
        val rel = lt - l.start
        for (i in s.indices) {
            val ch = s[i].toString()
            val cx0 = x0 + p.measureText(s, 0, i)
            val cw = p.measureText(ch)
            var a = 1f
            var dx = 0f
            var dy = 0f
            var sc = 1f
            var rot = 0f
            var swm = 1f
            for (an in l.anims) {
                val t0 = an.start + i * an.stagger
                val k = when (an.mode) { 0 -> 1f - easeU((rel - t0) / an.dur, an); 1 -> easeU((rel - t0) / an.dur, an); else -> 1f }
                when (an.type) {
                    0 -> a *= 1f - k
                    1 -> { dy += k * an.distance * th; if (an.fade) a *= 1f - k }
                    2 -> { dy -= k * an.distance * th; if (an.fade) a *= 1f - k }
                    3 -> { dx += k * an.distance * th; if (an.fade) a *= 1f - k }
                    4 -> { dx -= k * an.distance * th; if (an.fade) a *= 1f - k }
                    5 -> { sc *= 1f + (an.scaleFrom - 1f) * k; if (an.fade) a *= 1f - k }
                    6 -> { rot += k * an.rotFrom; if (an.fade) a *= 1f - k }
                    7 -> { if (an.mode == 0 && rel < t0) a = 0f else if (an.mode == 1 && rel >= t0) a = 0f }
                    8 -> dy += sin((rel * an.speed * 6.2832f + i * 0.6f).toDouble()).toFloat() * an.distance * th * 0.3f
                    9 -> swm *= 1f - k
                    10 -> {
                        val q = (rel * an.speed * 12f).toInt()
                        dx += (rnd(q, i, 1) - 0.5f) * an.distance * th * 0.2f
                        dy += (rnd(q, i, 2) - 0.5f) * an.distance * th * 0.2f
                    }
                }
            }
            if (a <= 0.003f) continue
            val ccx = cx0 + cw / 2f
            val ccy = base - th * 0.35f
            c.save()
            c.translate(dx, dy)
            c.rotate(rot, ccx, ccy)
            c.scale(sc, sc, ccx, ccy)
            if (sw * swm > 0.5f) {
                sp.strokeWidth = sw * swm
                sp.color = l.strokeColor
                sp.alpha = (Color.alpha(l.strokeColor) * a).toInt()
                c.drawText(ch, cx0, base, sp)
            }
            p.color = l.color
            p.alpha = (Color.alpha(l.color) * a).toInt()
            c.drawText(ch, cx0, base, p)
            c.restore()
        }
        return bmp
    }

    private fun image(l: Layer): Bitmap {
        val path = l.imagePath
        if (path != null) {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, o)
            var ss = 1
            while (o.outWidth / ss > 1500 || o.outHeight / ss > 1500) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            val b = BitmapFactory.decodeFile(path, o2)
            if (b != null) return b
        }
        val bmp = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(0xFF888888.toInt())
        return bmp
    }
}
