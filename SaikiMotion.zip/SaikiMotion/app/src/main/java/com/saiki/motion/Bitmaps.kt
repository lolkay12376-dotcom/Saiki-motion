package com.saiki.motion

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.sin

/** Turns a layer into a bitmap that is uploaded as a GL texture. */
object LayerBitmaps {
    fun baseHeight(l: Layer): Float = when (l.type) {
        LayerType.SHAPE -> 0.8f
        LayerType.TEXT -> 0.3f * l.texComp
        LayerType.IMAGE, LayerType.VIDEO -> 2.0f
        LayerType.CAMERA, LayerType.NULL, LayerType.FLARE -> 0.4f
        else -> 1.0f
    }

    fun make(l: Layer, lt: Float = 0f): Bitmap = when (l.type) {
        LayerType.SHAPE -> shape(l)
        LayerType.TEXT -> text(l, lt)
        else -> image(l)
    }

    private fun shape(l: Layer): Bitmap {
        val s = 512
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = l.color
        p.style = Paint.Style.FILL
        val m = 40f
        val r = RectF(m, m, s - m, s - m)
        when (l.shape) {
            ShapeKind.RECT -> c.drawRect(r, p)
            ShapeKind.ROUND -> c.drawRoundRect(r, 90f, 90f, p)
            ShapeKind.CIRCLE -> c.drawOval(r, p)
            ShapeKind.TRIANGLE -> {
                val path = Path()
                path.moveTo(s / 2f, m); path.lineTo(s - m, s - m); path.lineTo(m, s - m); path.close()
                c.drawPath(path, p)
            }
            ShapeKind.STAR -> {
                val path = Path()
                val cx = s / 2f
                val cy = s / 2f
                val ro = s / 2f - m
                val ri = ro * 0.45f
                for (i in 0 until 10) {
                    val ang = -Math.PI / 2 + i * Math.PI / 5
                    val rr = if (i % 2 == 0) ro else ri
                    val px = (cx + rr * cos(ang)).toFloat()
                    val py = (cy + rr * sin(ang)).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                c.drawPath(path, p)
            }
        }
        return bmp
    }

    private val faces = HashMap<String, Typeface>()

    private fun face(l: Layer): Typeface {
        val st = if (l.bold && l.italic) Typeface.BOLD_ITALIC else if (l.bold) Typeface.BOLD else if (l.italic) Typeface.ITALIC else Typeface.NORMAL
        val fp = l.fontPath
        if (fp != null) {
            faces["f:" + fp]?.let { return it }
            try { val tf = Typeface.createFromFile(fp); faces["f:" + fp] = tf; return tf } catch (e: Exception) { }
        }
        return faces.getOrPut(l.font + st) { Typeface.create(l.font, st) }
    }

    private fun easeU(u: Float, an: TextAnim): Float {
        val x = u.coerceIn(0f, 1f)
        return when (an.ease) {
            0 -> x
            1 -> 1f - (1f - x) * (1f - x)
            2 -> if (x < 0.5f) 2f * x * x else 1f - 2f * (1f - x) * (1f - x)
            3 -> bounceOut(x)
            else -> bezier(x, an.curve.x1, an.curve.y1, an.curve.x2, an.curve.y2)
        }
    }

    private fun rnd(q: Int, i: Int, k: Int): Float {
        val s = sin(q * 12.9898 + i * 78.233 + k * 37.719) * 43758.5453
        return (s - floor(s)).toFloat()
    }

    private fun text(l: Layer, lt: Float): Bitmap {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = 160f
        p.typeface = face(l)
        p.letterSpacing = l.p("spacing", lt)
        val src = if (l.text.isEmpty()) " " else l.text
        val raw = when (l.caps) { 1 -> src.uppercase(); 2 -> src.lowercase(); else -> src }
        val lines = raw.split('\n')
        val fm = p.fontMetrics
        val th = fm.descent - fm.ascent
        val lineH = th * l.p("lineSpacing", lt).coerceIn(0.3f, 4f)
        val widths = lines.map { p.measureText(if (it.isEmpty()) " " else it) }
        val tw = max(widths.maxOrNull() ?: 40f, 40f)
        val sw = l.p("strokeW", lt) * 3f
        val sw2 = l.p("stroke2W", lt) * 3f
        val bw = l.p("borderW", lt) * 3f
        val shB = l.p("shadowBlur", lt) * 2f
        val shX = l.p("shadowX", lt) * 2f
        val shY = l.p("shadowY", lt) * 2f
        val outward = (if (l.strokePos == 0) sw else sw / 2f) + sw2
        val anim = l.anims.isNotEmpty()
        val shReach = if (l.shadowOn) shB * 1.5f + max(abs(shX), abs(shY)) else 0f
        val boxed = bw > 0f || Color.alpha(l.borderFill) > 0
        val pad = 40f + (if (anim) 90f else 0f) + outward + shReach + (if (boxed) l.p("borderPad", lt) * 2f + bw else 0f)
        val totalH = th + (lines.size - 1) * lineH
        val w = (tw + pad * 2).toInt().coerceIn(64, 4096)
        val h = (totalH + pad * 2).toInt().coerceIn(16, 4096)
        l.texComp = h / (th + 80f)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val x0 = pad
        if (boxed) {
            val bx = l.p("borderPad", lt) * 2f
            val rad = l.p("borderRadius", lt) * 2f
            val rect = RectF(x0 - bx, pad - bx, x0 + tw + bx, pad + totalH + bx)
            if (Color.alpha(l.borderFill) > 0) {
                val fp = Paint(Paint.ANTI_ALIAS_FLAG)
                fp.style = Paint.Style.FILL; fp.color = l.borderFill
                c.drawRoundRect(rect, rad, rad, fp)
            }
            if (bw > 0f) {
                val bp = Paint(Paint.ANTI_ALIAS_FLAG)
                bp.style = Paint.Style.STROKE; bp.strokeWidth = bw; bp.color = l.borderColor
                if (l.borderDash) bp.pathEffect = android.graphics.DashPathEffect(floatArrayOf(bw * 2.2f, bw * 1.6f), 0f)
                c.drawRoundRect(rect, rad, rad, bp)
            }
        }
        val sp = Paint(Paint.ANTI_ALIAS_FLAG)
        sp.style = Paint.Style.STROKE
        sp.strokeJoin = if (l.strokeJoin == 1) Paint.Join.MITER else Paint.Join.ROUND
        sp.strokeMiter = 4f
        sp.textSize = 160f; sp.typeface = p.typeface; sp.letterSpacing = l.p("spacing", lt)
        val deco = Paint(Paint.ANTI_ALIAS_FLAG)

        /** Draws one run of text with shadow, strokes, fill and underline/strike. a = opacity, swm = stroke width multiplier. */
        fun glyphs(str: String, x: Float, y: Float, a: Float, swm: Float, lw: Float) {
            if (a <= 0.003f) return
            val s1 = sw * swm
            val s2 = sw2 * swm
            val reach = (if (l.strokePos == 0) s1 else s1 / 2f) + s2
            if (l.shadowOn) {
                val shp = Paint(sp)
                shp.style = Paint.Style.FILL_AND_STROKE
                shp.strokeWidth = reach * 2f
                shp.color = l.shadowColor
                shp.alpha = (Color.alpha(l.shadowColor) * a).toInt()
                if (shB > 0.5f) shp.maskFilter = android.graphics.BlurMaskFilter(shB, android.graphics.BlurMaskFilter.Blur.NORMAL)
                c.drawText(str, x + shX, y + shY, shp)
            }
            if (s2 > 0.5f) {
                sp.strokeWidth = (if (l.strokePos == 0) s1 else s1 / 2f) * 2f + s2 * 2f
                sp.color = l.stroke2Color
                sp.alpha = (Color.alpha(l.stroke2Color) * a).toInt()
                c.drawText(str, x, y, sp)
            }
            if (s1 > 0.5f && l.strokePos == 0) {
                sp.strokeWidth = s1 * 2f
                sp.color = l.strokeColor
                sp.alpha = (Color.alpha(l.strokeColor) * a).toInt()
                c.drawText(str, x, y, sp)
            }
            p.color = l.color
            p.alpha = (Color.alpha(l.color) * a).toInt()
            c.drawText(str, x, y, p)
            if (s1 > 0.5f && l.strokePos == 1) {
                sp.strokeWidth = s1
                sp.color = l.strokeColor
                sp.alpha = (Color.alpha(l.strokeColor) * a).toInt()
                c.drawText(str, x, y, sp)
            }
            if (s1 > 0.5f && l.strokePos == 2) {
                val path = Path()
                p.getTextPath(str, 0, str.length, x, y, path)
                c.save()
                c.clipPath(path)
                sp.strokeWidth = s1 * 2f
                sp.color = l.strokeColor
                sp.alpha = (Color.alpha(l.strokeColor) * a).toInt()
                c.drawText(str, x, y, sp)
                c.restore()
            }
            if (l.underline || l.strike) {
                deco.color = l.color
                deco.alpha = (Color.alpha(l.color) * a).toInt()
                if (l.underline) c.drawRect(x, y + th * 0.08f, x + lw, y + th * 0.08f + th * 0.05f, deco)
                if (l.strike) c.drawRect(x, y - th * 0.3f, x + lw, y - th * 0.3f + th * 0.05f, deco)
            }
        }

        val nChars = max(lines.sumOf { it.length }, 1)
        val u1 = IntArray(nChars)
        val u2 = IntArray(nChars)
        var wi = 0
        var gk = 0
        for ((lj, ln) in lines.withIndex()) {
            for (ch2 in ln) { if (gk < nChars) { u1[gk] = wi; u2[gk] = lj }; if (ch2 == ' ') wi++; gk++ }
            wi++
        }
        val n1 = max(wi, 1)
        val n2 = lines.size
        /** Position of a letter in the animation order (letter, word or line; left to right, center out, random...). */
        fun orderOf(an: TextAnim, g: Int): Float {
            val u: Int
            val n: Int
            when (an.unit) { 1 -> { u = u1[g]; n = n1 }; 2 -> { u = u2[g]; n = n2 }; else -> { u = g; n = nChars } }
            val mid = (n - 1) / 2f
            return when (an.order) {
                1 -> (n - 1 - u).toFloat()
                2 -> abs(u - mid)
                3 -> mid - abs(u - mid)
                4 -> rnd(an.type, u, 7) * n
                else -> u.toFloat()
            }
        }

        val rel = lt - l.start
        var gi = 0
        for ((li, line) in lines.withIndex()) {
            val lx = x0 + (tw - widths[li]) * (l.align / 2f)
            val base = pad - fm.ascent + li * lineH
            if (!anim) {
                if (line.isNotEmpty()) glyphs(line, lx, base, 1f, 1f, widths[li])
                continue
            }
            for (i in line.indices) {
                val ch = line[i].toString()
                val cx0 = lx + p.measureText(line, 0, i)
                val cw = p.measureText(ch)
                var a = 1f
                var dx = 0f
                var dy = 0f
                var sc = 1f
                var rot = 0f
                var swm = 1f
                for (an in l.anims) {
                    val t0 = an.start + orderOf(an, gi) * an.stagger
                    val k = if (an.type == 11 && an.mode == 2) 0.5f + 0.5f * sin((rel * an.speed * 6.2832f + orderOf(an, gi) * 0.6f).toDouble()).toFloat()
                        else when (an.mode) { 0 -> 1f - easeU((rel - t0) / an.dur, an); 1 -> easeU((rel - t0) / an.dur, an); else -> 1f }
                    when (an.type) {
                        0 -> a *= 1f - k
                        1 -> { dy += k * an.distance * th; if (an.fade) a *= 1f - k }
                        2 -> { dy -= k * an.distance * th; if (an.fade) a *= 1f - k }
                        3 -> { dx += k * an.distance * th; if (an.fade) a *= 1f - k }
                        4 -> { dx -= k * an.distance * th; if (an.fade) a *= 1f - k }
                        5 -> { sc *= 1f + (an.scaleFrom - 1f) * k; if (an.fade) a *= 1f - k }
                        6 -> { rot += k * an.rotFrom; if (an.fade) a *= 1f - k }
                        7 -> { if (an.mode == 0 && rel < t0) a = 0f else if (an.mode == 1 && rel >= t0) a = 0f }
                        8 -> dy += sin((rel * an.speed * 6.2832f + gi * 0.6f).toDouble()).toFloat() * an.distance * th * 0.3f
                        9 -> swm *= 1f - k
                        11 -> {
                            dx += k * an.dx * th
                            dy += k * an.dy * th
                            sc *= 1f + (an.scaleFrom - 1f) * k
                            rot += k * an.rotFrom
                            a *= 1f - k * (1f - an.opaFrom)
                            swm *= 1f + (an.strokeFrom - 1f) * k
                        }
                        10 -> {
                            val q = (rel * an.speed * 12f).toInt()
                            dx += (rnd(q, gi, 1) - 0.5f) * an.distance * th * 0.2f
                            dy += (rnd(q, gi, 2) - 0.5f) * an.distance * th * 0.2f
                        }
                    }
                }
                gi++
                if (a <= 0.003f) continue
                val ccx = cx0 + cw / 2f
                val ccy = base - th * 0.35f
                c.save()
                c.translate(dx, dy)
                c.rotate(rot, ccx, ccy)
                c.scale(sc, sc, ccx, ccy)
                glyphs(ch, cx0, base, a, swm, cw)
                c.restore()
            }
        }
        return bmp
    }

    private fun image(l: Layer): Bitmap {
        val path = l.imagePath
        if (path != null) {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, o)
            var ss = 1
            while (o.outWidth / ss > 1500 || o.outHeight / ss > 1500) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            val b = BitmapFactory.decodeFile(path, o2)
            if (b != null) return b
        }
        val bmp = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(0xFF888888.toInt())
        return bmp
    }
}
