package com.saiki.motion

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class CapScroll(ctx: Context, private val cap: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) { super.onMeasure(w, MeasureSpec.makeMeasureSpec(cap, MeasureSpec.AT_MOST)) }
}

/** Rounded progress bar for rendering. */
class ProgressBarView(ctx: Context) : View(ctx) {
    var progress = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    override fun onDraw(c: Canvas) {
        p.color = C.CARD2
        r.set(0f, 0f, width.toFloat(), height.toFloat())
        c.drawRoundRect(r, height / 2f, height / 2f, p)
        p.color = C.GREEN
        r.set(0f, 0f, maxOf(height.toFloat(), width * progress), height.toFloat())
        c.drawRoundRect(r, height / 2f, height / 2f, p)
    }
    override fun onMeasure(w: Int, h: Int) { super.onMeasure(w, MeasureSpec.makeMeasureSpec((12 * d).toInt(), MeasureSpec.EXACTLY)) }
}

/** Custom dark dialog with the same builder shape as AlertDialog, used everywhere in the app. */
class Dlg(private val ctx: Context) {
    private var title: String? = null
    private var message: String? = null
    private var view: View? = null
    private var items: Array<String>? = null
    private var icons: Array<String>? = null
    private var onItem: ((Any?, Int) -> Unit)? = null
    private var pos: Pair<String, ((Any?, Int) -> Unit)?>? = null
    private var neg: Pair<String, ((Any?, Int) -> Unit)?>? = null
    private var neu: Pair<String, ((Any?, Int) -> Unit)?>? = null
    private var cancelable = true
    private var dialog: Dialog? = null

    fun setTitle(t: String): Dlg { title = t; return this }
    fun setMessage(m: String): Dlg { message = m; return this }
    fun setView(v: View): Dlg { view = v; return this }
    fun setCancelable(b: Boolean): Dlg { cancelable = b; return this }
    fun setItems(it: Array<String>, l: (Any?, Int) -> Unit): Dlg { items = it; onItem = l; return this }
    fun setIconItems(labels: Array<String>, ic: Array<String>, l: (Any?, Int) -> Unit): Dlg { items = labels; icons = ic; onItem = l; return this }
    fun setPositiveButton(t: String, l: ((Any?, Int) -> Unit)?): Dlg { pos = Pair(t, l); return this }
    fun setNegativeButton(t: String, l: ((Any?, Int) -> Unit)?): Dlg { neg = Pair(t, l); return this }
    fun setNeutralButton(t: String, l: ((Any?, Int) -> Unit)?): Dlg { neu = Pair(t, l); return this }
    fun create(): Dlg = this
    fun dismiss() { try { dialog?.dismiss() } catch (e: Exception) { } }

    fun show(): Dlg {
        val dens = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * dens).toInt()
        val dm = ctx.resources.displayMetrics
        val d = Dialog(ctx)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(ctx)
        card.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0xFF1A1A20.toInt()); bg.cornerRadius = 22f * dens; bg.setStroke(dp(1), C.LINE)
        card.background = bg
        card.setPadding(dp(18), dp(16), dp(18), dp(12))
        title?.let {
            val t = TextView(ctx)
            t.text = it; t.setTextColor(C.TEXT); t.textSize = 19f; t.typeface = Typeface.DEFAULT_BOLD
            t.setPadding(dp(4), 0, dp(4), dp(10))
            card.addView(t)
        }
        message?.let {
            val t = TextView(ctx)
            t.text = it; t.setTextColor(C.DIM); t.textSize = 15f
            t.setPadding(dp(4), 0, dp(4), dp(10))
            card.addView(t)
        }
        val cap = (dm.heightPixels * 0.6f).toInt()
        view?.let { v ->
            (v.parent as? ViewGroup)?.removeView(v)
            if (v is ScrollView) card.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            else { val s = CapScroll(ctx, cap); s.addView(v); card.addView(s, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)) }
        }
        items?.let { its ->
            val col = LinearLayout(ctx)
            col.orientation = LinearLayout.VERTICAL
            for ((i, label) in its.withIndex()) {
                val row = LinearLayout(ctx)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(8), dp(13), dp(8), dp(13))
                icons?.getOrNull(i)?.let { row.addView(IconView(ctx, it, C.DIM, 20f), LinearLayout.LayoutParams(dp(34), dp(24))) }
                val t = TextView(ctx)
                t.text = label
                t.setTextColor(if (label.startsWith("Delete")) C.RED else C.TEXT)
                t.textSize = 16f
                row.addView(t)
                row.isClickable = true
                row.setOnClickListener { d.dismiss(); onItem?.invoke(d, i) }
                col.addView(row)
                if (i < its.size - 1) { val ln = View(ctx); ln.setBackgroundColor(C.LINE); col.addView(ln, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)) }
            }
            val s = CapScroll(ctx, cap)
            s.addView(col)
            card.addView(s)
        }
        if (pos != null || neg != null || neu != null) {
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.END
            row.setPadding(0, dp(12), 0, 0)
            fun btn(p: Pair<String, ((Any?, Int) -> Unit)?>?, fill: Int, tc: Int) {
                if (p == null) return
                val b = PillButton(ctx, p.first, null, fill, tc)
                b.onClick = { d.dismiss(); p.second?.invoke(d, 0) }
                val lp = LinearLayout.LayoutParams(dp(104), dp(42))
                lp.setMargins(dp(5), 0, 0, 0)
                row.addView(b, lp)
            }
            btn(neu, C.CARD2, C.TEXT)
            btn(neg, C.CARD2, C.TEXT)
            btn(pos, C.GREEN, 0xFF2B1400.toInt())
            card.addView(row)
        }
        d.setContentView(card)
        d.setCancelable(cancelable)
        d.window?.setBackgroundDrawable(ColorDrawable(0))
        d.window?.setDimAmount(0.65f)
        d.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        d.show()
        d.window?.setLayout(minOf((dm.widthPixels * 0.9f).toInt(), dp(480)), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog = d
        return this
    }
}

/** Small custom toast that fades in above the tool bar. */
object Snack {
    fun show(a: Activity, msg: String) {
        val root = a.window.decorView as? FrameLayout ?: return
        val d = a.resources.displayMetrics.density
        val tv = TextView(a)
        tv.text = msg; tv.setTextColor(C.TEXT); tv.textSize = 14f
        val bg = GradientDrawable()
        bg.setColor(0xF0222228.toInt()); bg.cornerRadius = 20f * d; bg.setStroke((1 * d).toInt(), C.LINE)
        tv.background = bg
        tv.setPadding((18 * d).toInt(), (10 * d).toInt(), (18 * d).toInt(), (10 * d).toInt())
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = (120 * d).toInt()
        tv.alpha = 0f
        root.addView(tv, lp)
        tv.animate().alpha(1f).setDuration(150).withEndAction {
            tv.postDelayed({ tv.animate().alpha(0f).setDuration(250).withEndAction { root.removeView(tv) }.start() }, 1700)
        }.start()
    }
}
