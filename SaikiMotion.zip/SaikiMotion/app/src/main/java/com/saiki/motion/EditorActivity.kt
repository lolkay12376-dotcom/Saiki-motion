package com.saiki.motion

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class EditorActivity : Activity(), EditHost, TimelineHost {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val P_NONE = 0; private val P_MEDIA = 1; private val P_SHAPES = 2; private val P_EDIT = 3
    private val P_XFORM = 4; private val P_FX = 5; private val P_BLEND = 6; private val P_SPEED = 7; private val P_GRAPH = 8
    private val R_VIDEO = 51; private val R_IMAGE = 52; private val R_GLB = 53; private val R_FX = 54; private val R_PRESET = 55

    private lateinit var projectId: String
    private lateinit var preview: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var aspect: AspectLayout
    private lateinit var timeline: TimelineView
    private lateinit var titleView: TextView
    private lateinit var playIcon: IconView
    private lateinit var markIcon: IconView
    private lateinit var cubeIcon: IconView
    private lateinit var qualityChip: ChipView
    private lateinit var toolbarBox: HorizontalScrollView
    private lateinit var toolbarRow: LinearLayout
    private lateinit var panelBox: LinearLayout
    private lateinit var panelList: LinearLayout
    private lateinit var diamondSide: IconView

    private var selectedId = -1
    private var panel = P_NONE
    private var fxTab = 0
    private var fxCat = 0
    private var playing = false
    private var lastNs = 0L
    private var autoKey = false
    private var quality = 1
    private var graphProp = ""
    private var graphKey = 0
    private var selKey = ""
    private lateinit var screen: FrameLayout
    private lateinit var panelHome: LinearLayout
    private lateinit var panelLp: ViewGroup.LayoutParams
    private val R_AUDIOFILE = 58
    private val R_FONT = 59
    private var textTab = 0
    private val players = HashMap<Int, android.media.MediaPlayer>()
    private val R_BEAT = 57
    private lateinit var subView: TextView
    private val multi = LinkedHashSet<Int>()
    private var multiMode = false
    private val clipboard = ArrayList<Layer>()

    private val expanded = HashSet<String>()
    private val rows = ArrayList<Row>()
    private class Row(val slider: RulerSlider, val d: PropDef, val layer: Layer)
    private val undo = ArrayList<String>()
    private val redo = ArrayList<String>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Snack.show(this, s)

    private fun safe(step: String, block: () -> Unit) {
        try { block() } catch (e: Exception) { toast(step + ": " + (e.message ?: e.javaClass.simpleName)) }
    }

    // ================================================================ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Registry.init(this)
        CrashLog.install(this)
        projectId = intent.getStringExtra("id") ?: ""
        Editor.project = Projects.load(this, projectId)
        Editor.sceneIndex = 0
        if (savedInstanceState == null) Editor.time = 0f
        selectedId = savedInstanceState?.getInt("sel", -1) ?: -1
        buildUi()
        refreshAll()
        safe("previews") { EffectThumbs.generate(this, preview) { if (panel == P_FX && fxTab == 1) refreshPanel() } }
    }

    override fun onResume() { super.onResume(); preview.onResume() }

    override fun onPause() {
        super.onPause()
        playing = false
        stopAudio()
        playIcon.set("play", C.TEXT)
        preview.onPause()
        Projects.save(this, projectId, Editor.project)
    }

    override fun onConfigurationChanged(c: android.content.res.Configuration) {
        super.onConfigurationChanged(c)
        buildUi()
        refreshAll()
    }

    override fun onBackPressed() { onBack() }

    override fun onDestroy() { releaseAudio(); super.onDestroy() }

    private val prepared = HashSet<Int>()
    private val audioLead = 110

    /** Players are created and prepared in the background as soon as an audio layer exists, so Play starts instantly. */
    private fun ensureAudio() {
        val ids = HashSet<Int>()
        for (l in Editor.scene.layers) {
            if (l.type != LayerType.AUDIO) continue
            ids.add(l.id)
            val path = l.imagePath ?: continue
            if (players.containsKey(l.id)) continue
            try {
                val mp = android.media.MediaPlayer()
                mp.setDataSource(path)
                mp.setOnPreparedListener { prepared.add(l.id) }
                mp.prepareAsync()
                players[l.id] = mp
            } catch (e: Exception) { }
        }
        for (id in players.keys.toList()) if (!ids.contains(id)) {
            try { players[id]?.release() } catch (e: Exception) { }
            players.remove(id); prepared.remove(id)
        }
    }

    private fun releaseAudio() {
        for (mp in players.values) try { mp.release() } catch (e: Exception) { }
        players.clear(); prepared.clear()
    }

    private fun stopAudio() {
        for (mp in players.values) try { if (mp.isPlaying) mp.pause() } catch (e: Exception) { }
    }

    private fun startAudio() { ensureAudio(); tickAudio(true) }

    /** Keeps every audio layer locked to the playhead and corrects drift. */
    private fun tickAudio(restart: Boolean = false) {
        val t = Editor.time
        for (l in Editor.scene.layers) {
            val mp = players[l.id] ?: continue
            if (!prepared.contains(l.id)) continue
            try {
                val inside = l.visible && t >= l.start && t <= l.end
                val want = ((t - l.start + l.srcOffset) * 1000f).toInt() + audioLead
                if (inside) {
                    val v = l.p("volume", t).coerceIn(0f, 1f)
                    mp.setVolume(v, v)
                    if (!mp.isPlaying) { mp.seekTo(want.toLong(), android.media.MediaPlayer.SEEK_CLOSEST); mp.start() }
                    else if (restart || Math.abs(mp.currentPosition - want) > 140) mp.seekTo(want.toLong(), android.media.MediaPlayer.SEEK_CLOSEST)
                } else if (mp.isPlaying) mp.pause()
            } catch (e: Exception) { }
        }
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); o.putInt("sel", selectedId) }

    // ================================================================ UI skeleton

    private fun icon(name: String, tint: Int = C.TEXT, click: () -> Unit = {}): IconView {
        val v = IconView(this, name, tint)
        v.onClick = click
        return v
    }

    private fun hRow(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    private fun addIcon(parent: LinearLayout, v: IconView, w: Int = 44, h: Int = 48) {
        parent.addView(v, LinearLayout.LayoutParams(dp(w), dp(h)))
    }

    private fun buildUi() {
        val land = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val root = LinearLayout(this)
        root.orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.fitsSystemWindows = true

        val top = hRow()
        top.setPadding(dp(4), 0, dp(8), 0)
        addIcon(top, icon("back", C.AMBER) { onBack() }, 40)
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        titleView = TextView(this)
        titleView.setTextColor(C.TEXT); titleView.textSize = 17f; titleView.typeface = Typeface.DEFAULT_BOLD; titleView.maxLines = 1
        subView = TextView(this)
        subView.setTextColor(C.DIM); subView.textSize = 11f
        tcol.addView(titleView); tcol.addView(subView)
        top.addView(tcol, LinearLayout.LayoutParams(0, WRAP, 1f))
        cubeIcon = icon("cube") { toggle3d() }
        addIcon(top, cubeIcon, 40)
        addIcon(top, icon("gear") { showSceneDialog() }, 40)
        top.addView(pill("Render", "export", C.GREEN, 0xFF2B1400.toInt()) { showRenderDialog() }, LinearLayout.LayoutParams(dp(104), dp(38)))

        val previewBox = FrameLayout(this)
        previewBox.setBackgroundColor(0xFF161618.toInt())
        aspect = AspectLayout(this)
        preview = PreviewView(this)
        overlay = OverlayView(this, this)
        aspect.addView(preview, MATCH, MATCH)
        aspect.addView(overlay, MATCH, MATCH)
        previewBox.addView(aspect, MATCH, MATCH)

        val tr = hRow()
        tr.setPadding(dp(6), 0, dp(6), 0)
        addIcon(tr, icon("fit") { timeline.fitToScene() })
        qualityChip = ChipView(this, "Full")
        qualityChip.onClick = { cycleQuality() }
        tr.addView(qualityChip, LinearLayout.LayoutParams(dp(56), dp(48)))
        markIcon = icon("bookmark") { toggleMarker() }
        markIcon.onLong = { nameMarker() }
        addIcon(tr, markIcon)
        tr.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val prev = icon("prev") { stepFrame(-1) }
        prev.onLong = { jump(-1) }
        addIcon(tr, prev, 48)
        playIcon = icon("play") { togglePlay() }
        addIcon(tr, playIcon, 52)
        val next = icon("next") { stepFrame(1) }
        next.onLong = { jump(1) }
        addIcon(tr, next, 48)
        tr.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        addIcon(tr, icon("layers") { showLayersMenu() })
        addIcon(tr, icon("undo") { doUndo() })
        addIcon(tr, icon("redo") { doRedo() })

        timeline = TimelineView(this, this)

        toolbarBox = HorizontalScrollView(this)
        toolbarBox.isHorizontalScrollBarEnabled = false
        toolbarBox.setBackgroundColor(C.PANEL)
        toolbarRow = LinearLayout(this)
        toolbarRow.orientation = LinearLayout.HORIZONTAL
        toolbarBox.addView(toolbarRow)

        panelBox = LinearLayout(this)
        panelBox.orientation = LinearLayout.HORIZONTAL
        panelBox.setBackgroundColor(C.PANEL)
        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER_HORIZONTAL
        side.addView(icon("close") { closePanel() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        side.addView(icon("plus", C.GREEN) { fxTab = 1; openPanel(P_FX) }, LinearLayout.LayoutParams(dp(48), dp(44)))
        diamondSide = icon("diamond_f", C.DIM) { keySelected() }
        side.addView(diamondSide, LinearLayout.LayoutParams(dp(48), dp(44)))
        side.addView(icon("graph", C.DIM) { openPanel(P_GRAPH) }, LinearLayout.LayoutParams(dp(48), dp(44)))
        side.addView(icon("box", C.DIM) { fxTab = 2; openPanel(P_FX) }, LinearLayout.LayoutParams(dp(48), dp(44)))
        side.addView(icon("more", C.DIM) { showPanelMenu() }, LinearLayout.LayoutParams(dp(48), dp(44)))
        panelBox.addView(side, LinearLayout.LayoutParams(dp(52), MATCH))
        val sv = ScrollView(this)
        panelList = LinearLayout(this)
        panelList.orientation = LinearLayout.VERTICAL
        panelList.setPadding(dp(4), dp(6), dp(8), dp(16))
        sv.addView(panelList, MATCH, WRAP)
        panelBox.addView(sv, LinearLayout.LayoutParams(0, MATCH, 1f))

        if (land) {
            val left = LinearLayout(this)
            left.orientation = LinearLayout.VERTICAL
            left.addView(top, LinearLayout.LayoutParams(MATCH, dp(52)))
            left.addView(previewBox, LinearLayout.LayoutParams(MATCH, 0, 1f))
            left.addView(tr, LinearLayout.LayoutParams(MATCH, dp(48)))
            val right = LinearLayout(this)
            right.orientation = LinearLayout.VERTICAL
            right.addView(timeline, LinearLayout.LayoutParams(MATCH, 0, 1f))
            right.addView(toolbarBox, LinearLayout.LayoutParams(MATCH, dp(76)))
            right.addView(panelBox, LinearLayout.LayoutParams(MATCH, dp(220)))
            root.addView(left, LinearLayout.LayoutParams(0, MATCH, 0.46f))
            root.addView(right, LinearLayout.LayoutParams(0, MATCH, 0.54f))
        } else {
            root.addView(top, LinearLayout.LayoutParams(MATCH, dp(52)))
            root.addView(previewBox, LinearLayout.LayoutParams(MATCH, 0, 1f))
            root.addView(tr, LinearLayout.LayoutParams(MATCH, dp(48)))
            root.addView(timeline, LinearLayout.LayoutParams(MATCH, 0, 1.15f))
            root.addView(toolbarBox, LinearLayout.LayoutParams(MATCH, dp(76)))
            root.addView(panelBox, LinearLayout.LayoutParams(MATCH, dp(300)))
        }
        panelHome = panelBox.parent as LinearLayout
        panelLp = panelBox.layoutParams
        root.fitsSystemWindows = false
        screen = FrameLayout(this)
        screen.fitsSystemWindows = true
        screen.addView(root, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(screen)
    }

    // ================================================================ small helpers

    private fun selected(): Layer? = Editor.scene.layers.firstOrNull { it.id == selectedId }

    private fun render() {
        preview.requestRender(); overlay.invalidate(); timeline.invalidate()
    }

    private fun pill(text: String, icon: String? = null, fill: Int = C.CARD2, tc: Int = C.TEXT, click: () -> Unit): PillButton {
        val b = PillButton(this, text, icon, fill, tc)
        b.onClick = click
        return b
    }

    private fun put(parent: LinearLayout, v: View, hDp: Int = 0, mT: Int = 3, mB: Int = 3) {
        val lp = LinearLayout.LayoutParams(MATCH, if (hDp == 0) WRAP else dp(hDp))
        lp.setMargins(0, dp(mT), 0, dp(mB))
        parent.addView(v, lp)
    }

    private fun text(parent: LinearLayout, t: String, color: Int = C.DIM, size: Float = 13f, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t; tv.setTextColor(color); tv.textSize = size
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dp(6), dp(6), dp(6), dp(4))
        parent.addView(tv)
        return tv
    }

    private fun refreshAll() {
        aspect.ratio = Editor.project.w.toFloat() / Editor.project.h.toFloat()
        if (selected() == null) selectedId = -1
        safe("title") { refreshTitle() }; safe("toolbar") { refreshToolbar() }; safe("panel") { showBottom() }; safe("panel") { refreshPanel() }; safe("time") { onTimeChanged() }; safe("audio") { ensureAudio() }
    }

    private fun refreshTitle() {
        val l = selected()
        titleView.text = l?.name ?: Editor.project.name
        cubeIcon.tint = if (l != null && (l.is3d || l.type == LayerType.MODEL || l.type == LayerType.CAMERA)) C.GREEN else C.TEXT
        cubeIcon.invalidate()
    }

    /** The Effects panel covers the whole screen; every other panel sits under the timeline. */
    private fun placePanel(full: Boolean) {
        val cur = panelBox.parent as? ViewGroup
        if (full) {
            if (cur !== screen) { cur?.removeView(panelBox); screen.addView(panelBox, FrameLayout.LayoutParams(MATCH, MATCH)) }
            panelBox.bringToFront()
        } else if (cur !== panelHome) {
            cur?.removeView(panelBox)
            panelHome.addView(panelBox, panelLp)
        }
    }

    private fun showBottom() {
        placePanel(panel == P_FX && fxTab == 1)
        toolbarBox.visibility = if (panel == P_NONE) View.VISIBLE else View.GONE
        panelBox.visibility = if (panel != P_NONE) View.VISIBLE else View.GONE
    }

    private fun onTimeChanged() {
        syncRows()
        subView.text = timeline.timecode(Editor.time) + " / " + timeline.timecode(Editor.scene.duration)
        val has = Editor.scene.markers.any { Math.abs(it - Editor.time) < 0.02f }
        markIcon.set(if (has) "bookmark_f" else "bookmark", if (has) C.BLUE else C.TEXT)
        render()
    }

    private fun onBack() {
        if (panel != P_NONE) closePanel() else if (selectedId != -1) onSelect(-1) else finish()
    }

    private fun openPanel(p: Int) {
        if (p != P_MEDIA && p != P_SHAPES && selected() == null) { toast("Select a layer first"); return }
        panel = p
        showBottom(); refreshPanel()
    }

    private fun closePanel() { panel = P_NONE; showBottom() }

    // ================================================================ tool bar

    private fun refreshToolbar() {
        toolbarRow.removeAllViews()
        val l = selected()
        fun tool(ic: String, label: String, tint: Int = C.TEXT, click: () -> Unit) {
            val b = ToolButton(this, ic, label)
            b.tint = tint
            b.onClick = click
            toolbarRow.addView(b, LinearLayout.LayoutParams(dp(76), dp(76)))
        }
        if (l == null) {
            tool("media", "Media") { openPanel(P_MEDIA) }
            tool("text", "Text") { addLayer(LayerType.TEXT) }
            tool("solid", "Solid") { addSolid() }
            tool("adjust", "Adjustment") { addLayer(LayerType.ADJUST) }
            tool("audio", "Audio") { pickFile(R_AUDIOFILE, "audio/*") }
            tool("nullobj", "Null") { addLayer(LayerType.NULL) }
            tool("shape", "Shape") { openPanel(P_SHAPES) }
            tool("camera", "Camera") { addLayer(LayerType.CAMERA) }
            tool("particles", "Particles") { addParticles() }
            tool("layers", "Group") { addLayer(LayerType.GROUP) }
            tool("cube", "3D Model") { pickFile(R_GLB, "*/*") }
        } else {
            toolbarRow.addView(icon("back", C.GREEN) { onSelect(-1) }, LinearLayout.LayoutParams(dp(44), dp(76)))
            tool("split", "Split") { splitAtPlayhead(false) }
            tool("trimin", "Trim start") { trimTo(true) }
            tool("trimout", "Trim end") { trimTo(false) }
            if (l.type == LayerType.VIDEO) tool("audio", "Extract audio") { extractAudio(l) }
            tool("edit", "Edit") { openPanel(P_EDIT) }
            tool("move", "Transform") { openPanel(P_XFORM) }
            if (l.isRenderable() || l.type == LayerType.GROUP) {
                tool("sparkle", "Effects") { openPanel(P_FX) }
                tool("drop", "Blending") { openPanel(P_BLEND) }
                tool("speed", "Speed") { openPanel(P_SPEED) }
            }
            tool("trash", "Delete", C.RED) { deleteLayer() }
        }
    }

    // ================================================================ playback

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (!playing) return
            if (lastNs != 0L) {
                var t = Editor.time + (ns - lastNs) / 1e9f
                var wrapped = false
                if (t > Editor.scene.duration) { t = 0f; wrapped = true }
                Editor.time = t
                if (wrapped) startAudio() else tickAudio()
                onTimeChanged()
            }
            lastNs = ns
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun togglePlay() {
        playing = !playing
        playIcon.set(if (playing) "pause" else "play", C.TEXT)
        if (playing) { lastNs = 0L; Choreographer.getInstance().postFrameCallback(frameCb); startAudio() } else stopAudio()
    }

    private fun stepFrame(dir: Int) {
        Editor.time = (Editor.time + dir / Editor.project.fps.toFloat()).coerceIn(0f, Editor.scene.duration)
        onTimeChanged()
    }

    private fun jump(dir: Int) {
        val times = ArrayList<Float>()
        times.addAll(Editor.scene.markers)
        selected()?.let { l -> for ((_, tr) in l.props) for (k in tr.keys) times.add(k.t) }
        times.sort()
        val now = Editor.time
        val target = if (dir > 0) times.firstOrNull { it > now + 0.02f } else times.lastOrNull { it < now - 0.02f }
        if (target != null) { Editor.time = target; onTimeChanged() }
    }

    private fun toggleMarker() {
        val ms = Editor.scene.markers
        val ex = ms.firstOrNull { Math.abs(it - Editor.time) < 0.02f }
        pushUndo()
        if (ex != null) { Editor.scene.setMarkerName(ex, ""); ms.remove(ex) } else ms.add(Editor.time)
        onTimeChanged()
    }

    private fun nameMarker() {
        val ms = Editor.scene.markers
        var m = ms.firstOrNull { Math.abs(it - Editor.time) < 0.02f }
        if (m == null) { pushUndo(); ms.add(Editor.time); m = Editor.time; onTimeChanged() }
        val tm = m
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(4), dp(4), dp(4))
        text(box, timeline.timecode(tm), C.DIM, 13f)
        val et = EditText(this)
        et.hint = "Marker name"
        et.setText(Editor.scene.markerName(tm) ?: "")
        et.setSingleLine(true)
        box.addView(et)
        text(box, "Expressions can reach this marker by name:  marker.key(\"name\")", C.DIM, 12f)
        Dlg(this).setTitle("Name marker").setView(box).setPositiveButton("Save") { _, _ ->
            pushUndo()
            Editor.scene.setMarkerName(tm, et.text.toString())
            timeline.invalidate(); render()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun cycleQuality() {
        quality = when (quality) { 1 -> 2; 2 -> 4; else -> 1 }
        preview.quality = quality
        qualityChip.text = when (quality) { 1 -> "Full"; 2 -> "1/2"; else -> "1/4" }
        qualityChip.invalidate(); render()
    }

    // ================================================================ undo / redo

    private fun snapshot(): String = Store.toJson(Editor.project).toString()

    private fun pushUndo() {
        val s = snapshot()
        if (undo.lastOrNull() == s) return
        undo.add(s)
        if (undo.size > 40) undo.removeAt(0)
        redo.clear()
    }

    private fun restore(js: String) {
        val p = Store.fromJson(JSONObject(js))
        Editor.project = p
        if (Editor.sceneIndex >= p.scenes.size) Editor.sceneIndex = p.scenes.size - 1
        Editor.time = Editor.time.coerceIn(0f, Editor.scene.duration)
        refreshAll()
    }

    private fun doUndo() { if (undo.isEmpty()) { toast("Nothing to undo"); return }; redo.add(snapshot()); restore(undo.removeAt(undo.size - 1)) }
    private fun doRedo() { if (redo.isEmpty()) { toast("Nothing to redo"); return }; undo.add(snapshot()); restore(redo.removeAt(redo.size - 1)) }

    // ================================================================ hosts

    override fun selectedLayer(): Layer? = selected()
    override fun autoKey(): Boolean = autoKey
    override fun beginEdit() { pushUndo() }
    override fun onEdited() { syncRows(); render() }
    override fun selectedId(): Int = selectedId
    override fun isSelected(id: Int): Boolean = id == selectedId || multi.contains(id)
    override fun onSeek(t: Float) { Editor.time = t; onTimeChanged() }
    override fun onSelect(id: Int) {
        if (multiMode && id >= 0) {
            if (!multi.remove(id)) multi.add(id)
            selectedId = id; panel = P_NONE
            refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
            return
        }
        if (!multiMode) multi.clear()
        selectedId = id
        panel = if (id >= 0 && selected()?.type == LayerType.TEXT) P_EDIT else P_NONE
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
    }
    override fun onToggleVisible(l: Layer) { pushUndo(); l.visible = !l.visible; render() }
    override fun onTimingChanged() { render() }

    override fun onReorder(l: Layer, listIndex: Int) {
        pushUndo()
        val ls = Editor.scene.layers
        ls.remove(l)
        ls.add(listIndex.coerceIn(0, ls.size), l)
        render()
    }

    override fun onKeyTap(l: Layer, key: String, idx: Int) {
        selectedId = l.id
        graphProp = key
        graphKey = idx
        Editor.time = l.track(key).keys.getOrNull(idx)?.t ?: Editor.time
        panel = P_GRAPH
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); onTimeChanged()
    }

    // ================================================================ layers

    private fun addLayer(type: LayerType): Layer {
        pushUndo()
        val p = Editor.project
        val s = Editor.scene
        val id = p.nextId++
        val nm = when (type) {
            LayerType.SHAPE -> "Shape"; LayerType.TEXT -> "Text"; LayerType.IMAGE -> "Image"; LayerType.VIDEO -> "Video"
            LayerType.CAMERA -> "Camera"; LayerType.NULL -> "Null"; LayerType.MODEL -> "Model"; LayerType.PARTICLES -> "Particles"; LayerType.GROUP -> "Group"; LayerType.ADJUST -> "Adjustment"; LayerType.AUDIO -> "Audio"
        }
        val l = Layer(id, "$nm $id", type)
        l.end = s.duration
        if (type == LayerType.TEXT) l.color = 0xFFFFFFFF.toInt()
        if (type == LayerType.MODEL || type == LayerType.CAMERA) l.is3d = true
        s.layers.add(l)
        if (type == LayerType.NULL) toast("Turn on the 3D cube (top bar) so this Null can drive other layers")
        if (type == LayerType.CAMERA) toast("The camera affects layers below it that have the 3D cube on")
        onSelect(id)
        return l
    }

    private fun addParticles() {
        val l = addLayer(LayerType.SHAPE)
        l.name = "Particles " + l.id
        l.shape = ShapeKind.CIRCLE
        l.fx.add("particles")
        l.track("pShowSrc").base = 0f
        expanded.add(l.id.toString() + ":particles")
        fxTab = 0
        panel = P_FX
        showBottom(); refreshPanel()
    }

    private fun cloneLayer(l: Layer, suffix: String): Layer {
        val c = Layer(Editor.project.nextId++, l.name + suffix, l.type)
        c.text = l.text; c.color = l.color; c.color2 = l.color2; c.shape = l.shape; c.imagePath = l.imagePath
        c.bold = l.bold; c.italic = l.italic; c.font = l.font; c.fontPath = l.fontPath; c.strokeW = l.strokeW; c.strokeColor = l.strokeColor; c.spacing = l.spacing; c.borderW = l.borderW; c.borderColor = l.borderColor; c.borderPad = l.borderPad; for (an in l.anims) c.anims.add(an.copy()); c.start = l.start; c.end = l.end; c.is3d = l.is3d; c.parentId = l.parentId
        c.blend = l.blend; c.srcDur = l.srcDur; c.visible = l.visible; c.srcOffset = l.srcOffset; c.mask = l.mask; c.mblur = l.mblur; c.fx.addAll(l.fx); c.fxOff.addAll(l.fxOff); c.inputs.putAll(l.inputs)
        for ((k, tr) in l.props) {
            val n = c.track(k)
            n.base = tr.base
            n.copyExprFrom(tr)
            for (key in tr.keys) { val nk = Key(key.t, key.v, key.ease); nk.x1 = key.x1; nk.y1 = key.y1; nk.x2 = key.x2; nk.y2 = key.y2; n.keys.add(nk) }
        }
        return c
    }

    private fun targets(): List<Layer> {
        val m = Editor.scene.layers.filter { multi.contains(it.id) }
        if (m.isNotEmpty()) return m
        val s = selected()
        return if (s != null) listOf(s) else emptyList()
    }

    private fun duplicateSelected() {
        val t = targets()
        if (t.isEmpty()) { toast("Select a layer first"); return }
        pushUndo()
        var last = -1
        for (l in t) { val c = cloneLayer(l, " copy"); Editor.scene.layers.add(c); last = c.id }
        multi.clear(); multiMode = false
        onSelect(last)
    }

    private fun copySelected() {
        val t = targets()
        if (t.isEmpty()) { toast("Select a layer first"); return }
        clipboard.clear()
        for (l in t) clipboard.add(cloneLayer(l, ""))
        toast("Copied " + t.size + (if (t.size == 1) " layer" else " layers"))
    }

    private fun pasteLayers() {
        if (clipboard.isEmpty()) { toast("Nothing copied yet"); return }
        pushUndo()
        var last = -1
        for (c in clipboard) { val n = cloneLayer(c, ""); Editor.scene.layers.add(n); last = n.id }
        multi.clear(); multiMode = false
        onSelect(last)
    }

    private fun selectAll() {
        multi.clear()
        for (l in Editor.scene.layers) multi.add(l.id)
        if (multi.isEmpty()) { toast("No layers yet"); return }
        selectedId = multi.last()
        refreshTitle(); refreshToolbar(); render()
        toast("All layers selected")
    }

    private fun groupSelected() {
        val t = targets().filter { it.type != LayerType.GROUP }
        if (t.isEmpty()) { toast("Select layers first"); return }
        val g = addLayer(LayerType.GROUP)
        for (l in t) l.parentId = g.id
        multi.clear(); multiMode = false
        onSelect(g.id)
        toast("Grouped " + t.size + " layers")
    }

    private fun addSolid() {
        val l = addLayer(LayerType.SHAPE)
        l.shape = ShapeKind.RECT
        l.name = "Solid " + l.id
        l.color = 0xFF2A2A33.toInt()
        val ar = Editor.project.w.toFloat() / Editor.project.h
        l.track("scale").base = (maxOf(2f * ar, 2f) / 0.8f / 0.84f * 1.02f).coerceAtMost(8f)
        refreshPanel(); render()
    }

    private fun deleteLayer() {
        val t = targets()
        if (t.isEmpty()) return
        pushUndo()
        for (l in t) { Editor.scene.layers.remove(l); for (o in Editor.scene.layers) if (o.parentId == l.id) o.parentId = -1 }
        multi.clear(); multiMode = false
        onSelect(-1)
    }

    private fun splitLayer(l: Layer, t: Float): Layer? {
        if (t <= l.start + 0.04f || t >= l.end - 0.04f || l.type == LayerType.GROUP) return null
        val c = cloneLayer(l, "")
        c.name = l.name
        c.start = t
        if (l.type == LayerType.VIDEO || l.type == LayerType.AUDIO) c.srcOffset = l.srcOffset + (t - l.start)
        l.end = t
        val ls = Editor.scene.layers
        ls.add(ls.indexOf(l) + 1, c)
        return c
    }

    /** Splits the selected layers (or every layer under the playhead) at the playhead. */
    private fun splitAtPlayhead(all: Boolean) {
        val t = Editor.time
        val list = if (all) Editor.scene.layers.toList() else targets()
        if (list.isEmpty()) { toast("Select a layer first"); return }
        pushUndo()
        var last: Layer? = null
        var n = 0
        for (l in list) { val c = splitLayer(l, t); if (c != null) { last = c; n++ } }
        if (last == null) { toast("Move the playhead inside the layer to split it"); return }
        multi.clear(); multiMode = false
        toast(if (n == 1) "Layer split" else "Split $n layers")
        onSelect(last.id)
    }

    /** Moves the start or end of the selected layers to the playhead. */
    private fun trimTo(start: Boolean) {
        val list = targets()
        if (list.isEmpty()) { toast("Select a layer first"); return }
        val t = Editor.time
        pushUndo()
        var n = 0
        for (l in list) {
            if (l.type == LayerType.GROUP) continue
            if (start && t > l.start + 0.04f && t < l.end) {
                if (l.type == LayerType.VIDEO || l.type == LayerType.AUDIO) l.srcOffset += t - l.start
                l.start = t; n++
            } else if (!start && t < l.end - 0.04f && t > l.start) { l.end = t; n++ }
        }
        if (n == 0) toast("Move the playhead inside the layer first") else render()
    }

    private fun moveLayer(dir: Int) {
        val l = selected() ?: return
        pushUndo()
        val ls = Editor.scene.layers
        val i = ls.indexOf(l)
        val j = i + dir
        if (j < 0 || j >= ls.size) return
        ls.removeAt(i); ls.add(j, l); render()
    }

    private fun toggle3d() {
        val l = selected() ?: run { toast("Select a layer first"); return }
        if (l.type == LayerType.MODEL || l.type == LayerType.CAMERA) { toast("This layer is always 3D"); return }
        pushUndo()
        l.is3d = !l.is3d
        refreshTitle(); refreshPanel(); render()
        toast(if (l.is3d) "3D on" else "3D off")
    }

    private fun showLayersMenu() {
        val labels = arrayOf("Select All Layers", if (multiMode) "Stop Selecting Multiple" else "Select Multiple Layers", "Group Layers", "Show All Keyframes",
            "Split at Playhead", "Split All Layers at Playhead", "Copy Layer", "Paste Layer", "Duplicate Layer", "Move Layer Up", "Move Layer Down",
            if (overlay.guides) "Hide Guides" else "Show Guides", "Delete Layer")
        val icons = arrayOf("layers", "check", "layers", "graph", "split", "split", "dup", "import", "dup", "chev_up", "chev_down", "dots", "trash")
        Dlg(this).setTitle("Layers").setIconItems(labels, icons) { _, w ->
            when (w) {
                0 -> selectAll()
                1 -> { multiMode = !multiMode; if (!multiMode) multi.clear(); render(); toast(if (multiMode) "Tap layers to select them" else "Multi select off") }
                2 -> groupSelected()
                3 -> timeline.expandAll()
                4 -> splitAtPlayhead(false)
                5 -> splitAtPlayhead(true)
                6 -> copySelected()
                7 -> pasteLayers()
                8 -> duplicateSelected()
                9 -> moveLayer(1)
                10 -> moveLayer(-1)
                11 -> { overlay.guides = !overlay.guides; overlay.invalidate() }
                else -> deleteLayer()
            }
        }.show()
    }

    // ---------------------------------------------------------------- expressions, audio, beats

    private fun showExpression(l: Layer, d: PropDef) {
        val tr = l.track(d.key)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(4), dp(4), dp(4))
        val sw = SwitchRow(this)
        sw.label = "fx  (expression)"
        sw.on = tr.exprOn && tr.exprSrc.isNotBlank()
        sw.captionOn = "On"; sw.captionOff = "Off"
        var swOn = sw.on
        sw.onToggle = { v -> swOn = v }
        put(box, sw, 52)
        text(box, "t = time, v = keyframed value. wiggle(freq, amp), sin, cos, abs, min, max, clamp, pow, sqrt, linear(t, a, b, c, d), noise, floor, round, mix, if(c, a, b), step(a, b), comparisons < > <= >= ==, pi, marker.key(\"name\").", C.DIM, 12f)
        val et = EditText(this)
        et.setText(tr.exprSrc)
        et.typeface = Typeface.MONOSPACE
        et.hint = "v + wiggle(3, 0.1)"
        box.addView(et)
        val presets = listOf("v + wiggle(3, 0.1)", "v * (1 + 0.2 * sin(t * 8))", "v + t * 90", "v + abs(sin(t * 4)) * 0.3", "")
        box.addView(chipRow(this, listOf("Wiggle", "Pulse", "Spin", "Bounce", "Clear"), -1) { i -> et.setText(presets[i]) })
        val names = Editor.scene.markerNames.values.toList().sorted()
        if (names.isNotEmpty()) {
            text(box, "Named markers (tap to insert)", C.DIM, 12f)
            box.addView(chipRow(this, names, -1) { i -> et.text.insert(et.selectionStart.coerceAtLeast(0), "marker.key(\"" + names[i] + "\")") })
        }
        Dlg(this).setTitle("Expression: " + d.label).setView(ScrollView(this).also { it.addView(box) }).setPositiveButton("Apply") { _, _ ->
            pushUndo()
            val src = et.text.toString()
            if (!tr.setExpr(src)) toast("Expression error") else { tr.exprOn = swOn && src.isNotBlank(); refreshPanel(); render() }
        }.setNegativeButton("Cancel", null).show()
    }

    private fun extractAudio(l: Layer) {
        val src = l.imagePath ?: return
        toast("Extracting audio...")
        Thread {
            try {
                val f = File(cacheDir, "audio_" + System.currentTimeMillis() + ".m4a")
                if (!AudioTools.extractAudio(src, f)) { runOnUiThread { toast("This video has no audio track") }; return@Thread }
                val v = ContentValues()
                v.put(MediaStore.Audio.Media.DISPLAY_NAME, l.name.substringBeforeLast('.') + ".m4a")
                v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                v.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/SaikiMotion")
                val u = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
                val mf = File(Projects.mediaDir(this), System.currentTimeMillis().toString() + "_" + l.name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9]"), "_") + ".m4a")
                f.copyTo(mf, true)
                f.delete()
                runOnUiThread { toast("Saved to Music/SaikiMotion and added as an audio layer"); addMedia(mf.absolutePath, LayerType.AUDIO) }
            } catch (e: Exception) { runOnUiThread { toast("Could not extract audio") } }
        }.start()
    }

    private fun beatsFrom(path: String, offset: Float) {
        toast("Analyzing beats...")
        Thread {
            try {
                val beats = AudioTools.detectBeats(path)
                runOnUiThread {
                    pushUndo()
                    val ms = Editor.scene.markers
                    var n = 0
                    for (b in beats) {
                        val t = offset + b
                        if (t <= Editor.scene.duration && ms.none { Math.abs(it - t) < 0.05f }) { ms.add(t); n++ }
                    }
                    render(); toast("Added " + n + " beat markers")
                }
            } catch (e: Exception) { runOnUiThread { toast("Could not analyze audio") } }
        }.start()
    }

    private fun snapKeys(l: Layer) {
        val ms = Editor.scene.markers
        for ((_, tr) in l.props) {
            var ch = false
            for (k in tr.keys) {
                val m = ms.minByOrNull { Math.abs(it - k.t) }
                if (m != null && Math.abs(m - k.t) < 0.35f) { k.t = m; ch = true }
            }
            if (ch) tr.keys.sortBy { it.t }
        }
        toast("Keyframes snapped to markers")
    }

    // ================================================================ importing

    private fun pickFile(req: Int, mime: String) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = mime
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(i, req)
    }

    private fun displayName(uri: android.net.Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "file"
            }
        } catch (e: Exception) { }
        return "file"
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        if (req == R_FX || req == R_PRESET) {
            try {
                val txt = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                if (req == R_FX) {
                    val err = Registry.addCustom(this, txt)
                    if (err != null) toast(err) else { toast("Effect imported"); EffectThumbs.generate(this, preview) { refreshPanel() }; refreshPanel() }
                } else {
                    val o = JSONObject(txt)
                    o.getString("name")
                    Registry.savePreset(this, o)
                    toast("Preset imported"); refreshPanel()
                }
            } catch (e: Exception) { toast("Could not read file") }
            return
        }
        if (req == R_FONT) {
            val tl = selected() ?: return
            Thread {
                try {
                    val f = File(Projects.mediaDir(this), System.currentTimeMillis().toString() + "_font.ttf")
                    contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    runOnUiThread { pushUndo(); tl.fontPath = f.absolutePath; refreshPanel(); render() }
                } catch (e: Exception) { runOnUiThread { toast("Could not load the font") } }
            }.start()
            return
        }
        if (req == R_BEAT) {
            Thread {
                try {
                    val f = File(cacheDir, "beat_src")
                    contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    runOnUiThread { beatsFrom(f.absolutePath, 0f) }
                } catch (e: Exception) { runOnUiThread { toast("Could not read audio") } }
            }.start()
            return
        }
        val name = displayName(uri)
        toast("Importing...")
        Thread {
            try {
                val f = File(Projects.mediaDir(this), System.currentTimeMillis().toString() + "_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread { addMedia(f.absolutePath, when (req) { R_VIDEO -> LayerType.VIDEO; R_GLB -> LayerType.MODEL; R_AUDIOFILE -> LayerType.AUDIO; else -> LayerType.IMAGE }) }
            } catch (e: Exception) { runOnUiThread { toast("Import failed") } }
        }.start()
    }

    private fun addMedia(path: String, type: LayerType) {
        val l = addLayer(type)
        l.imagePath = path
        l.name = File(path).name.substringAfter('_')
        if (type == LayerType.VIDEO || type == LayerType.AUDIO) {
            try {
                val mr = MediaMetadataRetriever()
                mr.setDataSource(path)
                val ms = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                mr.release()
                l.srcDur = ms / 1000f
                val s = Editor.scene
                if (l.srcDur > 0.5f) s.duration = maxOf(s.duration, minOf(600f, l.start + l.srcDur))
                l.end = minOf(s.duration, l.start + l.srcDur.coerceAtLeast(0.5f))
            } catch (e: Exception) { }
        }
        refreshTitle(); refreshPanel(); render()
    }

    private fun exportText(name: String, content: String) {
        try {
            val v = ContentValues()
            v.put(MediaStore.Downloads.DISPLAY_NAME, name)
            v.put(MediaStore.Downloads.MIME_TYPE, "application/json")
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SaikiMotion")
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(content.toByteArray()) }
            toast("Saved to Downloads/SaikiMotion/$name")
        } catch (e: Exception) { toast("Export failed") }
    }

    // ================================================================ panels

    private fun refreshPanel() {
        panelList.removeAllViews()
        rows.clear()
        if (panel == P_NONE) return
        if (panel == P_MEDIA) buildMedia()
        else if (panel == P_SHAPES) buildShapes()
        else {
            val l = selected() ?: run { closePanel(); return }
            when (panel) {
                P_EDIT -> buildEdit(l)
                P_XFORM -> buildXform(l)
                P_FX -> buildFx(l)
                P_BLEND -> buildBlend(l)
                P_SPEED -> buildSpeed(l)
                P_GRAPH -> buildGraph(l)
            }
        }
        syncRows()
    }

    private fun addRow(parent: LinearLayout, l: Layer, d: PropDef, label: String = d.label) {
        if (d.options != null) { addOptionRow(parent, l, d); return }
        val tr = l.track(d.key)
        val s = RulerSlider(this)
        s.label = label; s.lo = d.min; s.hi = d.max; s.dec = d.dec
        s.infinite = d.inf; s.span = if (d.span > 0f) d.span else 1f
        s.onExprIcon = { showExpression(l, d) }
        s.value = tr.eval(l.editTime(d.key, Editor.time))
        s.onBegin = { pushUndo(); selKey = d.key; syncRows(s) }
        s.onChange = { v -> tr.set(l.editTime(d.key, Editor.time), v, autoKey); syncRows(s); render() }
        s.onLabelTap = { selKey = d.key; syncRows() }
        s.onLabelLong = { showExpression(l, d) }
        put(parent, s, 60)
        rows.add(Row(s, d, l))
    }

    private fun addOptionRow(parent: LinearLayout, l: Layer, d: PropDef) {
        val tr = l.track(d.key)
        val opts = d.options!!
        if (opts.size == 2) {
            val sw = SwitchRow(this)
            sw.label = d.label
            sw.on = tr.base >= 0.5f
            sw.captionOff = opts[0]; sw.captionOn = opts[1]
            sw.onToggle = { v -> pushUndo(); tr.keys.clear(); tr.base = if (v) 1f else 0f; render() }
            put(parent, sw, 52)
            return
        }
        text(parent, d.label, C.TEXT, 14f, true)
        parent.addView(chipRow(this, opts, tr.base.toInt()) { i -> pushUndo(); tr.keys.clear(); tr.base = i.toFloat(); refreshPanel(); render() })
    }

    private fun addPlain(parent: LinearLayout, label: String, lo: Float, hi: Float, v: Float, dec: Int, onChange: (Float) -> Unit) {
        val s = RulerSlider(this)
        s.label = label; s.lo = lo; s.hi = hi; s.value = v; s.dec = dec; s.canKey = false
        s.onBegin = { pushUndo() }
        s.onChange = onChange
        put(parent, s, 60)
    }

    private fun syncRows(except: RulerSlider? = null) {
        for (r in rows) {
            val tr = r.layer.track(r.d.key)
            val t = r.layer.editTime(r.d.key, Editor.time)
            if (r.slider !== except) r.slider.value = tr.eval(t)
            r.slider.hasKey = tr.keyAt(t) != null
            r.slider.hasAnim = tr.keys.isNotEmpty()
            r.slider.hasExpr = tr.exprActive()
            r.slider.rowSelected = r.d.key == selKey
            r.slider.invalidate()
        }
        diamondSide.set("diamond_f", if (rows.any { it.d.key == selKey && it.slider.hasKey }) C.GREEN else if (rows.any { it.d.key == selKey }) C.TEXT else C.DIM)
    }

    /** Adds or removes a keyframe on the parameter that was tapped last. */
    private fun keySelected() {
        val r = rows.firstOrNull { it.d.key == selKey }
        if (r == null) { toast("Tap a parameter first, then tap the keyframe button"); return }
        pushUndo()
        r.layer.track(r.d.key).toggleKey(r.layer.editTime(r.d.key, Editor.time))
        syncRows(); render()
    }

    /** Full color picker: saturation, hue, opacity, hex and an eyedropper that samples the preview. */
    private fun showColorPicker(initial: Int, onPick: (Int) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(4), dp(4), dp(4))
        val cp = ColorPickerView(this)
        cp.setColor(initial)
        box.addView(cp, LinearLayout.LayoutParams(MATCH, dp(250)))
        val row = hRow()
        row.setPadding(0, dp(10), 0, dp(6))
        val hex = EditText(this)
        hex.setText(String.format("%08X", initial)); hex.typeface = Typeface.MONOSPACE; hex.setSingleLine()
        val sw = View(this)
        sw.setBackgroundColor(initial)
        var lock = false
        cp.onChange = { c ->
            sw.setBackgroundColor(c)
            lock = true; hex.setText(String.format("%08X", c)); lock = false
            onPick(c)
        }
        hex.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (lock) return
                val t = (s?.toString() ?: "").trim().removePrefix("#")
                try {
                    val v = when (t.length) { 6 -> 0xFF000000L or t.toLong(16); 8 -> t.toLong(16); else -> return }
                    cp.setColor(v.toInt()); sw.setBackgroundColor(v.toInt()); onPick(v.toInt())
                } catch (e: Exception) { }
            }
        })
        row.addView(hex, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(sw, LinearLayout.LayoutParams(dp(52), dp(40)))
        box.addView(row)
        var ref: Dlg? = null
        box.addView(pill("Pen: pick a color from the preview", "pipette") {
            ref?.dismiss()
            startEyedropper { c -> showColorPicker(c, onPick); onPick(c) }
        })
        pushUndo()
        ref = Dlg(this).setTitle("Color").setView(box).setPositiveButton("Done", null).show()
    }

    private fun startEyedropper(cb: (Int) -> Unit) {
        toast("Tap the preview to pick a color")
        overlay.pick = { x, y ->
            val w = preview.width
            val h = preview.height
            if (w > 0 && h > 0) {
                val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
                try {
                    android.view.PixelCopy.request(preview, bmp, { res ->
                        if (res == android.view.PixelCopy.SUCCESS) cb(bmp.getPixel(x.toInt().coerceIn(0, w - 1), y.toInt().coerceIn(0, h - 1)) or 0xFF000000.toInt())
                        else toast("Could not read the preview")
                    }, android.os.Handler(android.os.Looper.getMainLooper()))
                } catch (e: Exception) { toast("Eyedropper is not available here") }
            }
        }
    }

    private fun colorRow(cur: Int = 0xFFFFFFFF.toInt(), onPick: (Int) -> Unit): View {
        val colors = intArrayOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFF44336.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(),
            0xFF22C55E.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFF7C4DFF.toInt(), 0xFFFF4081.toInt())
        val row = hRow()
        val now = View(this)
        now.setBackgroundColor(cur)
        val nlp = LinearLayout.LayoutParams(dp(44), dp(36))
        nlp.setMargins(dp(4), dp(6), dp(10), dp(6))
        now.setOnClickListener { showColorPicker(cur, onPick) }
        row.addView(now, nlp)
        for (col in colors) {
            val v = View(this)
            v.setBackgroundColor(col)
            v.setOnClickListener { onPick(col) }
            val lp = LinearLayout.LayoutParams(dp(32), dp(32))
            lp.setMargins(dp(3), dp(6), dp(3), dp(6))
            row.addView(v, lp)
        }
        val more = View(this)
        val gd = android.graphics.drawable.GradientDrawable()
        gd.shape = android.graphics.drawable.GradientDrawable.OVAL
        gd.gradientType = android.graphics.drawable.GradientDrawable.SWEEP_GRADIENT
        gd.colors = intArrayOf(0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(), 0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt())
        more.background = gd
        more.setOnClickListener { showColorPicker(cur, onPick) }
        val mlp = LinearLayout.LayoutParams(dp(36), dp(36))
        mlp.setMargins(dp(8), dp(4), dp(4), dp(4))
        row.addView(more, mlp)
        val sv = HorizontalScrollView(this)
        sv.addView(row)
        return sv
    }

    private fun setColorParam(l: Layer, cp: ColorParam, col: Int) {
        val vals = listOf("_r" to android.graphics.Color.red(col), "_g" to android.graphics.Color.green(col), "_b" to android.graphics.Color.blue(col), "_a" to android.graphics.Color.alpha(col))
        for ((suffix, v) in vals) { val tr = l.track(cp.key + suffix); tr.keys.clear(); tr.base = v / 255f }
    }

    private fun addColorParam(parent: LinearLayout, l: Layer, cp: ColorParam) {
        fun cur(): Int = android.graphics.Color.argb((l.p(cp.key + "_a", 0f) * 255f).toInt(), (l.p(cp.key + "_r", 0f) * 255f).toInt(),
            (l.p(cp.key + "_g", 0f) * 255f).toInt(), (l.p(cp.key + "_b", 0f) * 255f).toInt())
        val row = hRow()
        row.setBackgroundColor(C.CARD)
        row.setPadding(dp(14), 0, dp(10), 0)
        val tv = TextView(this)
        tv.text = cp.label; tv.setTextColor(C.TEXT); tv.textSize = 15f; tv.typeface = Typeface.DEFAULT_BOLD
        row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = View(this)
        sw.setBackgroundColor(cur())
        sw.setOnClickListener { showColorPicker(cur()) { col -> setColorParam(l, cp, col); sw.setBackgroundColor(col); render() } }
        row.addView(sw, LinearLayout.LayoutParams(dp(72), dp(34)))
        put(parent, row, 52)
    }

    // ---------------------------------------------------------------- media + shapes

    private fun buildMedia() {
        val p = panelList
        text(p, "Media", C.TEXT, 16f, true)
        put(p, pill("Import video", "import") { pickFile(R_VIDEO, "video/*") }, 44)
        put(p, pill("Import image", "import") { pickFile(R_IMAGE, "image/*") }, 44)
        put(p, pill("Import audio", "import") { pickFile(R_AUDIOFILE, "audio/*") }, 44)
        put(p, pill("Import 3D model (.glb)", "import") { pickFile(R_GLB, "*/*") }, 44)
        put(p, pill("Beat markers from an audio file", "graph") { pickFile(R_BEAT, "audio/*") }, 44)
        val files = (Projects.mediaDir(this).listFiles() ?: emptyArray()).sortedByDescending { it.lastModified() }.take(12)
        if (files.isNotEmpty()) text(p, "Recent media", C.DIM, 13f)
        for (f in files) {
            val ext = f.extension.lowercase()
            val type = if (ext == "glb") LayerType.MODEL else if (ext in listOf("mp4", "mov", "mkv", "webm", "3gp", "m4v")) LayerType.VIDEO else if (ext in listOf("m4a", "mp3", "aac", "wav", "ogg", "flac")) LayerType.AUDIO else LayerType.IMAGE
            put(p, pill(f.name.substringAfter('_'), if (type == LayerType.VIDEO) "media" else if (type == LayerType.MODEL) "cube" else "media") {
                addMedia(f.absolutePath, type)
            }, 40)
        }
    }

    private fun buildShapes() {
        text(panelList, "Add shape", C.TEXT, 16f, true)
        val names = ShapeKind.values().map { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }
        panelList.addView(chipRow(this, names, -1) { i ->
            val l = addLayer(LayerType.SHAPE)
            l.shape = ShapeKind.values()[i]
            render()
        })
    }

    // ---------------------------------------------------------------- edit

    private fun buildEdit(l: Layer) {
        val p = panelList
        when (l.type) {
            LayerType.TEXT -> buildText(p, l)
            LayerType.SHAPE -> {
                text(p, "Shape", C.TEXT, 16f, true)
                val names = ShapeKind.values().map { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }
                p.addView(chipRow(this, names, l.shape.ordinal) { i -> pushUndo(); l.shape = ShapeKind.values()[i]; refreshPanel(); render() })
                text(p, "Color", C.DIM)
                p.addView(colorRow(l.color) { c -> pushUndo(); l.color = c; render() })
            }
            LayerType.GROUP -> {
                text(p, "Group", C.TEXT, 16f, true)
                text(p, "Put layers inside with Parent in their Transform panel. Tap the ^ arrow in the timeline to open or close the group. Groups can have effects, and 3D layers inside a group keep their 3D look.", C.DIM, 12f)
                text(p, "Mask", C.GREEN, 13f, true)
                text(p, "The top layer inside the group masks the layers beneath it.", C.DIM, 12f)
                p.addView(chipRow(this, listOf("None", "Alpha", "Inverted alpha", "Luma", "Inverted luma"), l.mask) { i -> pushUndo(); l.mask = i; refreshPanel(); render() })
            }
            LayerType.AUDIO -> {
                text(p, "Audio", C.TEXT, 16f, true); text(p, l.name)
                addRow(p, l, Defs.audio[0])
                put(p, pill("Beat markers from this audio", "graph") { beatsFrom(l.imagePath ?: "", l.start) }, 42)
                text(p, "Plays during preview and is mixed into the render (the first audio layer; AAC or MP3 files work best).", C.DIM, 12f)
            }
            LayerType.ADJUST -> { text(p, "Adjustment layer", C.TEXT, 16f, true); text(p, "Add effects to it in the Effects panel. They apply to everything below it for as long as the layer lasts.") }
            LayerType.CAMERA -> { text(p, "Camera", C.TEXT, 16f, true); addRow(p, l, Defs.camera[0]); text(p, "Position and rotate it in Transform. It controls every layer whose 3D cube is on.") }
            LayerType.NULL -> { text(p, "Null object", C.TEXT, 16f, true); text(p, "An invisible layer. Turn its 3D cube on, then pick it as Parent in other layers' Transform panel.") }
            else -> {
                text(p, l.type.name.lowercase().replaceFirstChar { it.uppercase() }, C.TEXT, 16f, true)
                text(p, l.name)
                if (l.type == LayerType.VIDEO) {
                    text(p, "Length: " + String.format("%.1f", l.srcDur) + " s. Decoded with the system decoder.")
                    put(p, pill("Extract audio", "export") { extractAudio(l) }, 42)
                    put(p, pill("Beat markers from this video", "graph") { beatsFrom(l.imagePath ?: "", l.start) }, 42)
                }
                if (l.type == LayerType.MODEL) text(p, "Static .glb mesh. Transforms are baked on load and everything is drawn from one GPU buffer per part.")
            }
        }
    }

    private fun buildText(p: LinearLayout, l: Layer) {
        text(p, "Text", C.TEXT, 16f, true)
        p.addView(chipRow(this, listOf("Text", "Style", "Animate"), textTab) { textTab = it; refreshPanel() })
        when (textTab) {
            0 -> {
                val et = EditText(this)
                et.setText(l.text)
                et.setTextColor(C.TEXT)
                et.addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: android.text.Editable?) { l.text = s?.toString() ?: ""; render() }
                })
                put(p, et)
                val sb = SwitchRow(this)
                sb.label = "Bold"; sb.on = l.bold; sb.onToggle = { v -> pushUndo(); l.bold = v; render() }
                put(p, sb, 52)
                val si = SwitchRow(this)
                si.label = "Italic"; si.on = l.italic; si.onToggle = { v -> pushUndo(); l.italic = v; render() }
                put(p, si, 52)
                text(p, "Font", C.GREEN, 13f, true)
                val fams = listOf("sans-serif", "serif", "monospace", "cursive", "casual", "sans-serif-condensed", "sans-serif-light", "sans-serif-medium", "sans-serif-black", "serif-monospace")
                val names = listOf("Sans", "Serif", "Mono", "Cursive", "Casual", "Condensed", "Light", "Medium", "Black", "Typewriter")
                p.addView(chipRow(this, names, if (l.fontPath != null) -1 else fams.indexOf(l.font)) { i -> pushUndo(); l.font = fams[i]; l.fontPath = null; refreshPanel(); render() })
                put(p, pill(if (l.fontPath != null) "Custom font loaded. Import another" else "Import a font file (.ttf or .otf)", "import") { pickFile(R_FONT, "*/*") }, 42)
                text(p, "Color", C.GREEN, 13f, true)
                p.addView(colorRow(l.color) { c -> pushUndo(); l.color = c; render() })
                addRow(p, l, Defs.transform[2], "Size")
            }
            1 -> {
                text(p, "Stroke", C.GREEN, 13f, true)
                addRow(p, l, Defs.text[0])
                p.addView(colorRow(l.strokeColor) { c -> pushUndo(); l.strokeColor = c; render() })
                text(p, "Border box", C.GREEN, 13f, true)
                addRow(p, l, Defs.text[1])
                addRow(p, l, Defs.text[2])
                p.addView(colorRow(l.borderColor) { c -> pushUndo(); l.borderColor = c; render() })
                text(p, "Spacing", C.GREEN, 13f, true)
                addRow(p, l, Defs.text[3])
            }
            else -> buildTextAnim(p, l)
        }
    }

    private fun buildTextAnim(p: LinearLayout, l: Layer) {
        put(p, pill("Add animation", "plus", C.GREEN, 0xFF2B1400.toInt()) {
            Dlg(this).setTitle("Add animation").setItems(TextAnim.TYPES.toTypedArray()) { _, w ->
                pushUndo()
                val a = TextAnim(w, if (w == 8 || w == 10) 2 else 0)
                if (w == 5) a.scaleFrom = 0f
                if (w == 6) a.rotFrom = 90f
                l.anims.add(a)
                expanded.add("anim:" + l.id + ":" + (l.anims.size - 1))
                refreshPanel(); render()
            }.show()
        }, 46)
        if (l.anims.isEmpty()) text(p, "Animations play per letter. Stack several, for example Slide up in plus Fade out. Outline draw animates the stroke from the Style tab.", C.DIM, 12f)
        for ((i, a) in l.anims.withIndex()) {
            val key = "anim:" + l.id + ":" + i
            val open = expanded.contains(key)
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            val bar = hRow()
            bar.setBackgroundColor(C.CARD)
            bar.setPadding(dp(14), 0, dp(2), 0)
            val tv = TextView(this)
            tv.text = a.name(); tv.setTextColor(C.TEXT); tv.textSize = 16f; tv.typeface = Typeface.DEFAULT_BOLD
            bar.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            val chev = IconView(this, if (open) "chev_up" else "chev_down", C.DIM, 20f)
            chev.onClick = { if (!expanded.remove(key)) expanded.add(key); refreshPanel() }
            bar.addView(chev, LinearLayout.LayoutParams(dp(40), dp(48)))
            val del = IconView(this, "trash", C.RED, 20f)
            del.onClick = { pushUndo(); l.anims.remove(a); refreshPanel(); render() }
            bar.addView(del, LinearLayout.LayoutParams(dp(40), dp(48)))
            card.addView(bar)
            if (open) {
                card.addView(chipRow(this, listOf("In", "Out", "Loop"), a.mode) { m -> pushUndo(); a.mode = m; refreshPanel(); render() })
                addPlain(card, "Start (s)", 0f, 10f, a.start, 2) { a.start = it; render() }
                addPlain(card, "Duration (s)", 0.05f, 5f, a.dur, 2) { a.dur = it; render() }
                addPlain(card, "Delay per letter (s)", 0f, 0.5f, a.stagger, 2) { a.stagger = it; render() }
                addPlain(card, "Distance", 0f, 3f, a.distance, 2) { a.distance = it; render() }
                addPlain(card, "Scale from", 0f, 3f, a.scaleFrom, 2) { a.scaleFrom = it; render() }
                addPlain(card, "Rotate from (deg)", -360f, 360f, a.rotFrom, 0) { a.rotFrom = it; render() }
                addPlain(card, "Speed (loops)", 0f, 10f, a.speed, 1) { a.speed = it; render() }
                text(card, "Easing", C.DIM, 12f)
                card.addView(chipRow(this, listOf("Linear", "Ease out", "Ease in-out", "Bounce", "Custom curve"), a.ease) { e -> pushUndo(); a.ease = e; if (e == 4) a.curve.ease = Ease.CUSTOM; refreshPanel(); render() })
                if (a.ease == 4) {
                    val gv = GraphView(this)
                    gv.key = a.curve
                    gv.onBegin = { pushUndo() }
                    gv.onChange = { render() }
                    put(card, gv, 200)
                }
                val sf = SwitchRow(this)
                sf.label = "Fade while moving"; sf.on = a.fade; sf.onToggle = { v -> pushUndo(); a.fade = v; render() }
                put(card, sf, 52)
            }
            put(p, card, 0, 3, 6)
        }
    }

    // ---------------------------------------------------------------- transform

    private fun buildXform(l: Layer) {
        val p = panelList
        val threeD = l.is3d || l.type == LayerType.MODEL || l.type == LayerType.CAMERA
        text(p, "Transform", C.TEXT, 16f, true)
        val s3 = SwitchRow(this)
        s3.label = "3D layer"; s3.on = threeD
        s3.onToggle = { _ -> toggle3d() }
        put(p, s3, 52)
        if (l.type == LayerType.NULL && !l.is3d) text(p, "This Null is 2D, so it will not move other layers. Turn 3D on.", C.AMBER)
        addRow(p, l, Defs.transform[0]); addRow(p, l, Defs.transform[1])
        if (threeD) addRow(p, l, Defs.pos3d[0])
        if (l.type != LayerType.CAMERA) addRow(p, l, Defs.transform[2])
        addRow(p, l, Defs.transform[4])
        if (threeD) { addRow(p, l, Defs.rot3d[0]); addRow(p, l, Defs.rot3d[1]) }
        if (l.isRenderable() || l.type == LayerType.GROUP) addRow(p, l, Defs.transform[3])
        val par = Editor.scene.layers.firstOrNull { it.id == l.parentId }
        put(p, pill("Parent: " + (par?.name ?: "None"), "layers") { showParentDialog(l) }, 42)
        val b = hRow()
        for (axis in arrayOf("rotX", "rotY", "rotZ")) {
            if (!threeD && axis != "rotZ") continue
            b.addView(pill("Spin " + axis.last()) { spin(l, axis) }, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        put(p, b)
    }

    private fun spin(l: Layer, key: String) {
        pushUndo()
        val tr = l.track(key)
        tr.keys.clear()
        tr.keys.add(Key(l.start, 0f, Ease.LINEAR)); tr.keys.add(Key(l.end, 360f, Ease.LINEAR))
        refreshPanel(); render()
    }

    private fun showParentDialog(l: Layer) {
        val cands = Editor.scene.layers.filter { it.id != l.id && it.parentId != l.id }
        val names = arrayOf("None") + cands.map { it.name + when (it.type) { LayerType.NULL -> " (Null)"; LayerType.GROUP -> " (Group)"; else -> "" } }
        Dlg(this).setTitle("Parent").setItems(names) { _, w ->
            pushUndo()
            l.parentId = if (w == 0) -1 else cands[w - 1].id
            refreshPanel(); render()
        }.show()
    }

    // ---------------------------------------------------------------- blending + speed

    private fun buildBlend(l: Layer) {
        val p = panelList
        text(p, "Blending", C.TEXT, 16f, true)
        addRow(p, l, Defs.transform[3])
        text(p, "Blend mode", C.DIM)
        p.addView(chipRow(this, listOf("Normal", "Add", "Screen", "Multiply"), l.blend) { i -> pushUndo(); l.blend = i; refreshPanel(); render() })
        val mb = SwitchRow(this)
        mb.label = "Motion blur"; mb.on = l.mblur
        mb.onToggle = { v -> pushUndo(); l.mblur = v; refreshPanel(); render() }
        put(p, mb, 52)
        if (l.mblur) {
            addRow(p, l, Defs.blur[0]); addRow(p, l, Defs.blur[1])
            text(p, "Works with particles and every moving or animated layer. More samples is smoother but slower. Video layers are not blurred.", C.DIM, 12f)
        }
    }

    private fun buildSpeed(l: Layer) {
        val p = panelList
        text(p, "Speed and Time Remap", C.TEXT, 16f, true)
        val on = l.fx.contains("remap")
        val sw = SwitchRow(this)
        sw.label = "Time remap"; sw.captionOff = "Normal speed"; sw.captionOn = "On"; sw.on = on
        sw.onToggle = { v ->
            pushUndo()
            if (v) { if (!l.fx.contains("remap")) l.fx.add("remap"); l.fxOff.remove("remap") } else l.fx.remove("remap")
            refreshPanel(); render()
        }
        put(p, sw, 52)
        if (on) {
            for (d in Registry.get("remap")!!.props) addRow(p, l, d)
            text(p, "Negative speed plays backwards. Loop length repeats the layer. Video layers follow this speed too.")
        }
    }

    // ---------------------------------------------------------------- effects

    private fun buildFx(l: Layer) {
        val p = panelList
        val hdr = hRow()
        val ht = TextView(this)
        ht.text = "Effects  ·  " + l.name; ht.setTextColor(C.TEXT); ht.textSize = 20f; ht.typeface = Typeface.DEFAULT_BOLD
        hdr.addView(ht, LinearLayout.LayoutParams(0, WRAP, 1f))
        hdr.addView(pill("Close", "close") { closePanel() }, LinearLayout.LayoutParams(dp(112), dp(42)))
        put(p, hdr, 0, 6, 8)
        p.addView(chipRow(this, listOf("Applied", "Browse", "Presets", "Custom"), fxTab) { fxTab = it; showBottom(); refreshPanel() })
        when (fxTab) { 0 -> buildApplied(l); 1 -> buildBrowse(l); 2 -> buildPresets(l); else -> buildCustom(l) }
    }

    private class FxSnap(val id: String, val tracks: Map<String, JSONObject>, val inputs: Map<String, Int>, val off: Boolean)
    private var fxClip: List<FxSnap> = emptyList()

    private fun snapFx(l: Layer, entry: String): FxSnap? {
        val d = Registry.get(entry) ?: return null
        val m = LinkedHashMap<String, JSONObject>()
        if (d.kind == 1) { for (pd in d.props) l.props[pd.key]?.let { m["=" + pd.key] = it.toJson() } }
        else { val pre = entry + "__"; for ((k, tr) in l.props) if (k.startsWith(pre)) m[k.substring(pre.length)] = tr.toJson() }
        val ins = HashMap<String, Int>()
        for ((k, v) in l.inputs) if (k.startsWith("$entry:")) ins[k.substring(entry.length + 1)] = v
        return FxSnap(d.id, m, ins, l.fxOff.contains(entry))
    }

    private fun pasteFx(l: Layer, snap: FxSnap) {
        val d = Registry.byId[snap.id] ?: return
        val entry: String
        if (d.kind == 1) { entry = d.id; if (!l.fx.contains(entry)) l.fx.add(entry) }
        else { entry = Registry.uniqueEntry(l, d.id); l.fx.add(entry) }
        if (snap.off) l.fxOff.add(entry) else l.fxOff.remove(entry)
        for ((rk, js) in snap.tracks) {
            val key = if (rk.startsWith("=")) rk.substring(1) else entry + "__" + rk
            l.track(key).load(js)
        }
        for ((nm, id) in snap.inputs) l.inputs["$entry:$nm"] = id
        expanded.add(l.id.toString() + ":" + entry)
    }

    private fun resetFx(l: Layer, entry: String) {
        val d = Registry.get(entry) ?: return
        for (pd in d.props) {
            val tr = l.track(l.pkey(entry, pd))
            tr.keys.clear(); tr.base = pd.def; tr.setExpr(""); tr.exprOn = false
        }
        for (cp in d.colors) {
            val ck = l.ckey(entry, cp)
            val vals = listOf("_r" to ((cp.def shr 16) and 255), "_g" to ((cp.def shr 8) and 255), "_b" to (cp.def and 255), "_a" to ((cp.def ushr 24) and 255))
            for ((sf, v) in vals) { val tr = l.track(ck + sf); tr.keys.clear(); tr.base = v / 255f }
        }
    }

    private fun moveFx(l: Layer, entry: String, dir: Int) {
        val idx = l.fx.indexOf(entry)
        val to = idx + dir
        if (idx < 0 || to < 0 || to >= l.fx.size) return
        l.fx.removeAt(idx); l.fx.add(to, entry)
    }

    private fun removeFx(l: Layer, entry: String) {
        l.fx.remove(entry); l.fxOff.remove(entry)
        val pre = entry + "__"
        if (entry.contains('~')) { for (k in l.props.keys.toList()) if (k.startsWith(pre)) l.props.remove(k) }
        for (k in l.inputs.keys.toList()) if (k.startsWith("$entry:")) l.inputs.remove(k)
    }

    private fun fxMenu(l: Layer, entry: String) {
        val d = Registry.get(entry) ?: return
        val idx = l.fx.indexOf(entry)
        val labels = arrayOf("Copy effect", "Duplicate effect", "Move up", "Move down", "Reset to default", "Remove effect")
        val icons = arrayOf("dup", "dup", "chev_up", "chev_down", "adjust", "trash")
        Dlg(this).setTitle(d.name).setIconItems(labels, icons) { _, w ->
            when (w) {
                0 -> { snapFx(l, entry)?.let { fxClip = listOf(it) }; toast("Effect copied") }
                1 -> { snapFx(l, entry)?.let { pushUndo(); pasteFx(l, it); refreshPanel(); render() } }
                2 -> { if (idx > 0) { pushUndo(); moveFx(l, entry, -1); refreshPanel(); render() } }
                3 -> { if (idx < l.fx.size - 1) { pushUndo(); moveFx(l, entry, 1); refreshPanel(); render() } }
                4 -> { pushUndo(); resetFx(l, entry); refreshPanel(); render() }
                5 -> { pushUndo(); removeFx(l, entry); refreshPanel(); render() }
            }
        }.show()
    }

    private fun fxListMenu(l: Layer) {
        val labels = arrayOf("Copy all effects", if (fxClip.isEmpty()) "Paste effects (nothing copied)" else "Paste effects (" + fxClip.size + ")", "Reset all to default", "Remove all effects")
        val icons = arrayOf("dup", "import", "adjust", "trash")
        Dlg(this).setTitle("Effects").setIconItems(labels, icons) { _, w ->
            when (w) {
                0 -> { fxClip = l.fx.mapNotNull { snapFx(l, it) }; toast(if (fxClip.isEmpty()) "No effects to copy" else "Copied " + fxClip.size + " effects") }
                1 -> { if (fxClip.isEmpty()) toast("No effects copied") else { pushUndo(); for (sn in fxClip) pasteFx(l, sn); refreshPanel(); render() } }
                2 -> { pushUndo(); for (e in l.fx.toList()) resetFx(l, e); refreshPanel(); render() }
                3 -> { pushUndo(); for (e in l.fx.toList()) removeFx(l, e); refreshPanel(); render() }
            }
        }.show()
    }

    private fun fxHeader(l: Layer, d: EffectDef, entry: String): View {
        val key = l.id.toString() + ":" + entry
        val open = expanded.contains(key)
        val bar = hRow()
        bar.setBackgroundColor(C.CARD)
        bar.addView(IconView(this, "handle", C.DIM, 20f), LinearLayout.LayoutParams(dp(36), dp(48)))
        val t = TextView(this)
        t.text = if (entry.contains('~')) d.name + " " + entry.substringAfter('~') else d.name
        t.setTextColor(C.TEXT); t.textSize = 16f; t.typeface = Typeface.DEFAULT_BOLD
        bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        val off = l.fxOff.contains(entry)
        val eye = IconView(this, if (off) "eye_off" else "eye", if (off) C.DIM else C.GREEN, 20f)
        eye.onClick = { pushUndo(); if (off) l.fxOff.remove(entry) else l.fxOff.add(entry); refreshPanel(); render() }
        bar.addView(eye, LinearLayout.LayoutParams(dp(40), dp(48)))
        val chev = IconView(this, if (open) "chev_up" else "chev_down", C.DIM, 20f)
        chev.onClick = { if (!expanded.remove(key)) expanded.add(key); refreshPanel() }
        bar.addView(chev, LinearLayout.LayoutParams(dp(40), dp(48)))
        val more = IconView(this, "more", C.TEXT, 20f)
        more.onClick = { fxMenu(l, entry) }
        bar.addView(more, LinearLayout.LayoutParams(dp(40), dp(48)))
        return bar
    }

    private fun buildApplied(l: Layer) {
        val p = panelList
        val top = hRow()
        val cnt = TextView(this)
        cnt.text = l.fx.size.toString() + (if (l.fx.size == 1) " effect" else " effects")
        cnt.setTextColor(C.DIM); cnt.textSize = 13f
        top.addView(cnt, LinearLayout.LayoutParams(0, WRAP, 1f))
        val menu = IconView(this, "more", C.TEXT, 22f)
        menu.onClick = { fxListMenu(l) }
        top.addView(menu, LinearLayout.LayoutParams(dp(44), dp(40)))
        put(p, top, 0, 6, 2)
        if (l.fx.isEmpty()) text(p, "No effects yet. Tap Add Effect to browse.")
        for (entry in l.fx) {
            val d = Registry.get(entry) ?: continue
            val id = d.id
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.addView(fxHeader(l, d, entry))
            if (expanded.contains(l.id.toString() + ":" + entry)) {
                text(c, d.desc, C.DIM, 12f)
                Registry.errors[id]?.let { text(c, "Shader error: $it", C.RED, 12f) }
                for (pd in d.props) addRow(c, l, Registry.instProp(l, entry, pd))
                for (cp in d.colors) addColorParam(c, l, Registry.instColor(l, entry, cp))
                if (id == "particles") {
                    val pmb = SwitchRow(this)
                    pmb.label = "Motion blur"; pmb.on = l.mblur
                    pmb.onToggle = { v -> pushUndo(); l.mblur = v; render() }
                    put(c, pmb, 52)
                    text(c, "Birth color", C.DIM); c.addView(colorRow(l.color) { col -> pushUndo(); l.color = col; render() })
                    text(c, "Death color", C.DIM); c.addView(colorRow(l.color2) { col -> pushUndo(); l.color2 = col; render() })
                }
                for (nm in d.inputs) {
                    val rid = l.inputs[entry + ":" + nm]
                    val ref = Editor.scene.layers.firstOrNull { it.id == rid }
                    put(c, pill(nm + " layer: " + (ref?.name ?: "None"), "layers") { showInputDialog(l, entry, nm) }, 42)
                }
                if (id == "lightsweep") put(c, pill("Animate sweep") { lightSweepAnim(l) }, 42)
                if (id == "tile") {
                    val b = hRow()
                    for (axis in arrayOf("tileX", "tileY")) b.addView(pill("Scroll " + axis.last()) { tileScroll(l, axis) }, LinearLayout.LayoutParams(0, dp(40), 1f))
                    c.addView(b)
                }
            }
            put(p, c, 0, 3, 6)
        }
        put(p, pill("Add Effect", "plus", C.GREEN, 0xFF2B1400.toInt()) { fxTab = 1; showBottom(); refreshPanel() }, 48, 10, 10)
    }

    private fun lightSweepAnim(l: Layer) {
        pushUndo()
        val tr = l.track("lightsweep__centerX")
        tr.keys.clear()
        tr.keys.add(Key(l.start, -0.4f, Ease.EASE_IN_OUT)); tr.keys.add(Key(l.end, 1.4f, Ease.EASE_IN_OUT))
        refreshPanel(); render()
    }

    private fun tileScroll(l: Layer, key: String) {
        pushUndo()
        val tr = l.track(key)
        val mirror = l.p("tileMirror", Editor.time) >= 0.5f
        tr.keys.clear()
        tr.keys.add(Key(l.start, 0f, Ease.LINEAR)); tr.keys.add(Key(l.end, if (mirror) 2f else 1f, Ease.LINEAR))
        refreshPanel(); render()
    }

    private fun showInputDialog(l: Layer, entry: String, nm: String) {
        val cands = Editor.scene.layers.filter { it.id != l.id && it.isRenderable() && it.type != LayerType.VIDEO && it.type != LayerType.MODEL && it.type != LayerType.PARTICLES }
        val names = arrayOf("None") + cands.map { it.name }
        Dlg(this).setTitle(nm + " layer").setItems(names) { _, w ->
            pushUndo()
            if (w == 0) l.inputs.remove(entry + ":" + nm) else l.inputs[entry + ":" + nm] = cands[w - 1].id
            refreshPanel(); render()
        }.show()
    }

    private var fxQuery = ""

    private fun fxCategory(d: EffectDef): String = when (d.id) {
        "deepglow", "lightsweep", "contour", "lightleak" -> "Light and glow"
        "tritone", "duotone", "hueshift", "grayscale", "invert", "rgbsplit", "vignette" -> "Color"
        "etching", "halftone", "zebrafy", "posterize", "filmgrain", "edgelines", "scanlines", "pixelate", "sharpen" -> "Stylize"
        "distortrgb", "kaleido", "bulge", "twirl", "barrel", "wavewarp", "ripple" -> "Distort"
        "blur", "radialblur" -> "Blur"
        "psykoblobs", "texturefolded", "texturemoire" -> "Generate"
        "sshake", "twitch", "glitchslices" -> "Glitch and motion"
        "chromakey" -> "Keying"
        else -> if (d.builtin) "Transform and time" else "Custom"
    }

    private fun buildBrowse(l: Layer) {
        val p = panelList
        val q = EditText(this)
        q.hint = "Search effects"
        q.setSingleLine()
        q.setText(fxQuery)
        q.setTextColor(C.TEXT)
        put(p, q)
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        val catOrder = listOf("Light and glow", "Color", "Stylize", "Distort", "Blur", "Generate", "Glitch and motion", "Keying", "Transform and time", "Custom")
        fun fill() {
            grid.removeAllViews()
            val qs = fxQuery.trim().lowercase()
            val list = Registry.order.filter { qs.isEmpty() || it.name.lowercase().contains(qs) || it.desc.lowercase().contains(qs) || fxCategory(it).lowercase().contains(qs) }
            val groups = list.groupBy { fxCategory(it) }
            val keys = groups.keys.sortedBy { k -> catOrder.indexOf(k).let { if (it < 0) 99 else it } }
            if (keys.isEmpty()) text(grid, "No effects match your search.", C.DIM, 13f)
            val cols = maxOf(2, (resources.configuration.screenWidthDp - 60) / 200)
            for (k in keys) {
                val items = groups[k]!!.sortedBy { it.name }
                text(grid, k + "  (" + items.size + ")", C.GREEN, 14f, true)
                var i = 0
                while (i < items.size) {
                    val r = hRow()
                    for (j in 0 until cols) {
                        if (i + j >= items.size) { r.addView(View(this), LinearLayout.LayoutParams(0, dp(250), 1f)); continue }
                        val d = items[i + j]
                        val card = EffectCard(this, d.name, fxCategory(d))
                        card.before = EffectThumbs.cache["__orig"]
                        card.after = EffectThumbs.cache[d.id]
                        card.badge = l.fx.contains(d.id)
                        card.onClick = { showEffectInfo(d, l) }
                        val lp = LinearLayout.LayoutParams(0, dp(250), 1f)
                        lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                        r.addView(card, lp)
                    }
                    grid.addView(r)
                    i += cols
                }
            }
        }
        q.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { fxQuery = s?.toString() ?: ""; fill() }
        })
        fill()
        p.addView(grid)
        if (Registry.order.any { !EffectThumbs.ready(it.id) }) EffectThumbs.generate(this, preview) { if (panel == P_FX && fxTab == 1) refreshPanel() }
        if (EffectThumbs.lastError.isNotEmpty()) text(p, "Preview error: " + EffectThumbs.lastError, C.RED, 11f)
        Registry.errors["__gl"]?.let { text(p, "GL error: " + it, C.RED, 11f) }
    }

    private fun showEffectInfo(d: EffectDef, l: Layer) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val card = EffectCard(this, d.name, d.category)
        card.before = EffectThumbs.cache["__orig"]; card.after = EffectThumbs.cache[d.id]
        box.addView(card, LinearLayout.LayoutParams(MATCH, dp(280)))
        val info = TextView(this)
        val sb = StringBuilder(d.desc).append("\n\nParameters: ")
        sb.append(if (d.props.isEmpty()) "none" else d.props.joinToString(", ") { it.label })
        if (d.inputs.isNotEmpty()) sb.append("\nLayer inputs: ").append(d.inputs.joinToString(", "))
        if (!d.builtin) sb.append("\nCustom effect")
        Registry.errors[d.id]?.let { sb.append("\n\nShader error:\n").append(it) }
        info.text = sb.toString()
        info.setPadding(0, dp(10), 0, 0)
        box.addView(info)
        val b = Dlg(this).setTitle(d.name).setView(ScrollView(this).also { it.addView(box) })
            .setPositiveButton("Add to layer") { _, _ ->
                pushUndo()
                val entry = if (d.kind == 1) d.id else Registry.uniqueEntry(l, d.id)
                if (!l.fx.contains(entry)) l.fx.add(entry)
                l.fxOff.remove(entry)
                expanded.add(l.id.toString() + ":" + entry)
                fxTab = 0; showBottom(); refreshPanel(); render()
            }.setNegativeButton("Close", null)
        if (!d.builtin) b.setNeutralButton("Export") { _, _ -> exportText(d.id + ".saikieffect.json", Registry.toJson(d).toString(2)) }
        b.show()
    }

    private fun buildPresets(l: Layer) {
        val p = panelList
        put(p, pill("Save current effects as preset", "plus", C.GREEN, 0xFF2B1400.toInt()) {
            if (l.fx.isEmpty()) { toast("Add an effect first"); return@pill }
            val et = EditText(this)
            et.setText("My preset")
            Dlg(this).setTitle("Preset name").setView(et).setPositiveButton("Save") { _, _ ->
                Registry.savePreset(this, Registry.capturePreset(l, et.text.toString().ifBlank { "My preset" }, Editor.time))
                refreshPanel()
            }.show()
        }, 44)
        put(p, pill("Import preset file", "import") { pickFile(R_PRESET, "*/*") }, 44)
        for (pr in Registry.presets(this)) {
            text(p, pr.name + if (pr.builtin) "  (built in)" else "", C.TEXT, 15f, true)
            val r = hRow()
            r.addView(pill("Apply") { pushUndo(); Registry.applyPreset(l, pr.json); fxTab = 0; refreshPanel(); render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill("Export") { exportText(pr.name + ".saikipreset.json", pr.json.toString(2)) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            if (!pr.builtin) r.addView(pill("Delete", null, C.CARD2, C.RED) { Registry.deletePreset(this, pr.name); refreshPanel() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            put(p, r)
        }
    }

    private fun buildCustom(l: Layer) {
        val p = panelList
        put(p, pill("Import effect file", "import") { pickFile(R_FX, "*/*") }, 44)
        put(p, pill("Create your own effect", "plus", C.GREEN, 0xFF2B1400.toInt()) { showCreateEffect() }, 44)
        text(p, "An effect is a JSON file with: name, description, params (name, label, min, max, def) and code. The code defines vec4 effect(vec2 uv) and may call src(uv), in0(uv), in1(uv), luma(), hash21(), fbm(), rot(), hsv2rgb() and use uTime and uRes. Every effect gets an auto-rendered animated icon.", C.DIM, 12f)
        val custom = Registry.order.filter { !it.builtin }
        if (custom.isEmpty()) text(p, "No custom effects yet.")
        for (d in custom) {
            text(p, d.name, C.TEXT, 15f, true)
            text(p, d.desc, C.DIM, 12f)
            val r = hRow()
            r.addView(pill("Info") { showEffectInfo(d, l) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill("Export") { exportText(d.id + ".saikieffect.json", Registry.toJson(d).toString(2)) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill("Delete", null, C.CARD2, C.RED) { Registry.deleteCustom(this, d.id); EffectThumbs.cache.remove(d.id); refreshPanel() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            put(p, r)
        }
    }

    private fun showCreateEffect() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        fun field(hint: String, init: String, lines: Int): EditText {
            val e = EditText(this)
            e.hint = hint; e.setText(init); e.textSize = 13f
            if (lines > 1) { e.minLines = lines; e.gravity = Gravity.TOP }
            box.addView(e)
            return e
        }
        val name = field("Name", "My Effect", 1)
        val desc = field("Description", "Mixes the image with grayscale.", 1)
        val params = field("Parameters, one per line: name,label,min,max,default", "amount,Amount,0,1,1", 3)
        val code = field("GLSL code", "vec4 effect(vec2 uv) {\n  vec4 c = src(uv);\n  return vec4(mix(c.rgb, vec3(luma(c.rgb)) * c.a, amount), c.a);\n}", 8)
        Dlg(this).setTitle("Create effect").setView(ScrollView(this).also { it.addView(box) })
            .setPositiveButton("Create") { _, _ ->
                try {
                    val pa = JSONArray()
                    for (line in params.text.toString().lines()) {
                        val f = line.split(",").map { it.trim() }
                        if (f.size >= 5) pa.put(JSONObject().put("name", f[0]).put("label", f[1]).put("min", f[2].toDouble()).put("max", f[3].toDouble()).put("def", f[4].toDouble()))
                    }
                    val o = JSONObject().put("name", name.text.toString()).put("description", desc.text.toString()).put("params", pa).put("code", code.text.toString())
                    val err = Registry.addCustom(this, o.toString())
                    if (err != null) toast(err) else { toast("Effect created"); EffectThumbs.generate(this, preview) { refreshPanel() }; refreshPanel() }
                } catch (e: Exception) { toast("Check the parameter lines") }
            }.setNegativeButton("Cancel", null).show()
    }

    // ---------------------------------------------------------------- graph

    private fun buildGraph(l: Layer) {
        val p = panelList
        text(p, "Graph editor", C.TEXT, 16f, true)
        val animated = l.props.filter { it.value.keys.size >= 2 }.keys.toList()
        if (animated.isEmpty()) { text(p, "Add two keyframes to a parameter (tap its name, then the keyframe button) or tap a keyframe in the timeline."); return }
        if (graphProp !in animated) { graphProp = animated[0]; graphKey = 0 }
        p.addView(chipRow(this, animated.map { Registry.propDef(it)?.label ?: it }, animated.indexOf(graphProp)) { graphProp = animated[it]; graphKey = 0; refreshPanel() })
        val tr = l.track(graphProp)
        graphKey = graphKey.coerceIn(0, tr.keys.size - 2)
        val vg = ValueGraphView(this)
        vg.track = tr
        vg.t0 = maxOf(0f, tr.keys.first().t - 0.3f)
        vg.t1 = maxOf(vg.t0 + 0.5f, tr.keys.last().t + 0.3f)
        vg.selIdx = graphKey
        vg.onPick = { i -> graphKey = i.coerceIn(0, tr.keys.size - 2); Editor.time = tr.keys[i].t; onTimeChanged(); refreshPanel() }
        put(p, vg, 150)
        text(p, "Segment " + (graphKey + 1) + " of " + (tr.keys.size - 1) + ". Tap a dot to choose a keyframe.", C.DIM, 12f)
        val key = tr.keys[graphKey]
        addPlain(p, "Keyframe time (s)", 0f, Editor.scene.duration, key.t, 2) { key.t = it; tr.keys.sortBy { k -> k.t }; render() }
        val pd = Registry.propDef(graphProp)
        if (pd != null) addPlain(p, "Keyframe value", pd.min, pd.max, key.v, pd.dec) { key.v = it; render() }
        text(p, "Easing curve to the next keyframe", C.GREEN, 13f, true)
        val g = GraphView(this)
        g.key = key
        g.onBegin = { pushUndo() }
        g.onChange = { render() }
        put(p, g, 220)
        val names = listOf("Linear", "Ease In", "Ease Out", "Ease In-Out", "Bounce", "Back", "Expo", "Snap")
        p.addView(chipRow(this, names, -1) { i ->
            pushUndo()
            when (i) {
                0 -> key.preset(Ease.LINEAR)
                1 -> key.preset(Ease.EASE_IN)
                2 -> key.preset(Ease.EASE_OUT)
                3 -> key.preset(Ease.EASE_IN_OUT)
                4 -> key.preset(Ease.BOUNCE)
                else -> {
                    val v = listOf(floatArrayOf(0.34f, 1.56f, 0.64f, 1f), floatArrayOf(0.7f, 0f, 0.84f, 0f), floatArrayOf(1f, 0f, 0f, 1f))[i - 5]
                    key.ease = Ease.CUSTOM; key.x1 = v[0]; key.y1 = v[1]; key.x2 = v[2]; key.y2 = v[3]
                }
            }
            refreshPanel(); render()
        })
        put(p, pill("Copy this curve to every segment") {
            pushUndo()
            for (k in tr.keys) { k.ease = key.ease; k.x1 = key.x1; k.y1 = key.y1; k.x2 = key.x2; k.y2 = key.y2 }
            render()
        }, 42)
        text(p, "Drag the white handles. Pull a handle above the top for overshoot.", C.DIM, 12f)
    }

    private fun showPanelMenu() {
        val l = selected() ?: return
        Dlg(this).setTitle("Layer").setItems(arrayOf("Clear all keyframes", "Reset transform", "Snap keyframes to beat markers")) { _, which ->
            pushUndo()
            if (which == 2) snapKeys(l)
            else for ((k, tr) in l.props) {
                if (which == 0) { tr.keys.clear(); tr.setExpr(""); tr.exprOn = false }
                else if (Defs.transform.any { it.key == k } || Defs.rot3d.any { it.key == k } || k == "z") { tr.keys.clear(); tr.base = Registry.propDef(k)?.def ?: 0f }
            }
            refreshPanel(); render()
        }.show()
    }

    // ================================================================ scenes + export

    private fun showSceneDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val dlg = Dlg(this).setTitle("Scene setup").setView(ScrollView(this).also { it.addView(box) }).setPositiveButton("Done", null).create()
        fun build() {
            box.removeAllViews()
            val pr = Editor.project
            val s = Editor.scene
            text(box, Projects.resLabel(pr.w, pr.h) + "  ·  " + pr.w + " x " + pr.h + "  ·  " + pr.fps + " fps", C.DIM)
            text(box, "Guides", C.GREEN, 13f, true)
            val gs = SwitchRow(this)
            gs.label = "Guides"; gs.on = overlay.guides
            gs.onToggle = { v -> overlay.guides = v; overlay.invalidate() }
            put(box, gs, 52)
            text(box, "Scenes", C.GREEN, 13f, true)
            box.addView(chipRow(this, pr.scenes.map { it.name } + listOf("New scene"), Editor.sceneIndex) { i ->
                pushUndo()
                if (i == pr.scenes.size) { pr.scenes.add(Scene("Scene " + (pr.scenes.size + 1))); Editor.sceneIndex = pr.scenes.size - 1 } else Editor.sceneIndex = i
                Editor.time = 0f; selectedId = -1; panel = P_NONE; refreshAll(); build()
            })
            if (pr.scenes.size > 1) put(box, pill("Delete this scene", null, C.CARD2, C.RED) {
                pushUndo(); pr.scenes.remove(s); Editor.sceneIndex = 0; Editor.time = 0f; selectedId = -1; panel = P_NONE; refreshAll(); build()
            }, 40)
            val d = RulerSlider(this)
            d.label = "Duration (s)"; d.lo = 1f; d.hi = 120f; d.value = s.duration; d.dec = 1; d.canKey = false
            d.onChange = { v ->
                val old = s.duration
                s.duration = maxOf(1f, Math.round(v * 2f) / 2f)
                for (l in s.layers) if (l.end >= old - 0.001f) l.end = s.duration
                Editor.time = Editor.time.coerceIn(0f, s.duration); onTimeChanged()
            }
            put(box, d, 60, 8, 4)
            val f = RulerSlider(this)
            f.label = "Scene FOV"; f.lo = 15f; f.hi = 90f; f.value = s.fov; f.dec = 0; f.canKey = false
            f.onChange = { v -> s.fov = v; render() }
            put(box, f, 60)
            text(box, "Background", C.GREEN, 13f, true)
            box.addView(colorRow(s.bg) { c -> s.bg = c; render() })
        }
        build()
        dlg.show()
    }

    private fun showRenderDialog() {
        if (playing) togglePlay()
        Projects.save(this, projectId, Editor.project)
        val proj = Editor.project
        RenderUi.settings(this, proj) { st -> RenderUi.show(this, proj, st) }
    }
}
