package com.saiki.motion

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class EditorActivity : Activity(), EditHost, TimelineHost {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val P_NONE = 0; private val P_MEDIA = 1; private val P_SHAPES = 2; private val P_EDIT = 3
    private val P_XFORM = 4; private val P_FX = 5; private val P_BLEND = 6; private val P_SPEED = 7; private val P_GRAPH = 8
    private val R_VIDEO = 51; private val R_IMAGE = 52; private val R_GLB = 53; private val R_FX = 54; private val R_PRESET = 55

    private lateinit var projectId: String
    private lateinit var preview: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var aspect: AspectLayout
    private lateinit var timeline: TimelineView
    private lateinit var titleView: TextView
    private lateinit var playIcon: IconView
    private lateinit var markIcon: IconView
    private lateinit var cubeIcon: IconView
    private lateinit var qualityChip: ChipView
    private lateinit var toolbarBox: HorizontalScrollView
    private lateinit var toolbarRow: LinearLayout
    private lateinit var panelBox: LinearLayout
    private lateinit var panelList: LinearLayout
    private lateinit var diamondSide: IconView

    private var selectedId = -1
    private var panel = P_NONE
    private var fxTab = 0
    private var fxCat = 0
    private var playing = false
    private var lastNs = 0L
    private var autoKey = false
    private var quality = 1
    private var graphProp = ""
    private var graphKey = 0

    private val expanded = HashSet<String>()
    private val rows = ArrayList<Row>()
    private class Row(val slider: RulerSlider, val d: PropDef, val layer: Layer)
    private val undo = ArrayList<String>()
    private val redo = ArrayList<String>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ================================================================ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Registry.init(this)
        projectId = intent.getStringExtra("id") ?: ""
        Editor.project = Projects.load(this, projectId)
        Editor.sceneIndex = 0
        Editor.time = 0f
        buildUi()
        refreshAll()
        EffectThumbs.generate(this) { if (panel == P_FX && fxTab == 1) refreshPanel() }
    }

    override fun onResume() { super.onResume(); preview.onResume() }

    override fun onPause() {
        super.onPause()
        playing = false
        playIcon.set("play", C.TEXT)
        preview.onPause()
        Projects.save(this, projectId, Editor.project)
    }

    // ================================================================ UI skeleton

    private fun icon(name: String, tint: Int = C.TEXT, click: () -> Unit = {}): IconView {
        val v = IconView(this, name, tint)
        v.onClick = click
        return v
    }

    private fun hRow(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    private fun addIcon(parent: LinearLayout, v: IconView, w: Int = 44, h: Int = 48) {
        parent.addView(v, LinearLayout.LayoutParams(dp(w), dp(h)))
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.fitsSystemWindows = true

        val top = hRow()
        top.setPadding(dp(4), 0, dp(4), 0)
        addIcon(top, icon("back", C.AMBER) { onBack() })
        titleView = TextView(this)
        titleView.setTextColor(C.TEXT); titleView.textSize = 18f; titleView.typeface = Typeface.DEFAULT_BOLD; titleView.maxLines = 1
        top.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f))
        cubeIcon = icon("cube") { toggle3d() }
        addIcon(top, cubeIcon)
        val guides = icon("dots")
        guides.onClick = { overlay.guides = !overlay.guides; guides.tint = if (overlay.guides) C.GREEN else C.TEXT; guides.invalidate(); overlay.invalidate() }
        addIcon(top, guides)
        addIcon(top, icon("dup") { duplicateLayer() })
        addIcon(top, icon("more") { showMenu() })
        root.addView(top, LinearLayout.LayoutParams(MATCH, dp(52)))

        val previewBox = FrameLayout(this)
        previewBox.setBackgroundColor(0xFF161618.toInt())
        aspect = AspectLayout(this)
        preview = PreviewView(this)
        overlay = OverlayView(this, this)
        aspect.addView(preview, MATCH, MATCH)
        aspect.addView(overlay, MATCH, MATCH)
        previewBox.addView(aspect, MATCH, MATCH)
        root.addView(previewBox, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val tr = hRow()
        tr.setPadding(dp(6), 0, dp(6), 0)
        addIcon(tr, icon("fit") { timeline.fitToScene() })
        qualityChip = ChipView(this, "Full")
        qualityChip.onClick = { cycleQuality() }
        tr.addView(qualityChip, LinearLayout.LayoutParams(dp(56), dp(48)))
        markIcon = icon("bookmark") { toggleMarker() }
        addIcon(tr, markIcon)
        tr.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val prev = icon("prev") { stepFrame(-1) }
        prev.onLong = { jump(-1) }
        addIcon(tr, prev, 48)
        playIcon = icon("play") { togglePlay() }
        addIcon(tr, playIcon, 52)
        val next = icon("next") { stepFrame(1) }
        next.onLong = { jump(1) }
        addIcon(tr, next, 48)
        tr.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        addIcon(tr, icon("layers") { openPanel(P_MEDIA) })
        addIcon(tr, icon("undo") { doUndo() })
        addIcon(tr, icon("redo") { doRedo() })
        root.addView(tr, LinearLayout.LayoutParams(MATCH, dp(48)))

        timeline = TimelineView(this, this)
        root.addView(timeline, LinearLayout.LayoutParams(MATCH, dp(168)))

        toolbarBox = HorizontalScrollView(this)
        toolbarBox.isHorizontalScrollBarEnabled = false
        toolbarBox.setBackgroundColor(C.PANEL)
        toolbarRow = LinearLayout(this)
        toolbarRow.orientation = LinearLayout.HORIZONTAL
        toolbarBox.addView(toolbarRow)
        root.addView(toolbarBox, LinearLayout.LayoutParams(MATCH, dp(76)))

        panelBox = LinearLayout(this)
        panelBox.orientation = LinearLayout.HORIZONTAL
        panelBox.setBackgroundColor(C.PANEL)
        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER_HORIZONTAL
        side.addView(icon("close") { closePanel() }, LinearLayout.LayoutParams(dp(48), dp(52)))
        side.addView(icon("plus", C.GREEN) { fxTab = 1; openPanel(P_FX) }, LinearLayout.LayoutParams(dp(48), dp(48)))
        diamondSide = icon("diamond_f", C.DIM) { keyAllRows() }
        side.addView(diamondSide, LinearLayout.LayoutParams(dp(48), dp(48)))
        side.addView(icon("graph", C.DIM) { openPanel(P_GRAPH) }, LinearLayout.LayoutParams(dp(48), dp(48)))
        side.addView(icon("box", C.DIM) { fxTab = 2; openPanel(P_FX) }, LinearLayout.LayoutParams(dp(48), dp(48)))
        side.addView(icon("more", C.DIM) { showPanelMenu() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        panelBox.addView(side, LinearLayout.LayoutParams(dp(52), MATCH))
        val sv = ScrollView(this)
        panelList = LinearLayout(this)
        panelList.orientation = LinearLayout.VERTICAL
        panelList.setPadding(dp(4), dp(6), dp(8), dp(16))
        sv.addView(panelList, MATCH, WRAP)
        panelBox.addView(sv, LinearLayout.LayoutParams(0, MATCH, 1f))
        root.addView(panelBox, LinearLayout.LayoutParams(MATCH, dp(300)))
        setContentView(root)
    }

    // ================================================================ small helpers

    private fun selected(): Layer? = Editor.scene.layers.firstOrNull { it.id == selectedId }

    private fun render() {
        preview.requestRender(); overlay.invalidate(); timeline.invalidate()
    }

    private fun pill(text: String, icon: String? = null, fill: Int = C.CARD2, tc: Int = C.TEXT, click: () -> Unit): PillButton {
        val b = PillButton(this, text, icon, fill, tc)
        b.onClick = click
        return b
    }

    private fun put(parent: LinearLayout, v: View, hDp: Int = 0, mT: Int = 3, mB: Int = 3) {
        val lp = LinearLayout.LayoutParams(MATCH, if (hDp == 0) WRAP else dp(hDp))
        lp.setMargins(0, dp(mT), 0, dp(mB))
        parent.addView(v, lp)
    }

    private fun text(parent: LinearLayout, t: String, color: Int = C.DIM, size: Float = 13f, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t; tv.setTextColor(color); tv.textSize = size
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dp(6), dp(6), dp(6), dp(4))
        parent.addView(tv)
        return tv
    }

    private fun refreshAll() {
        aspect.ratio = Editor.project.w.toFloat() / Editor.project.h.toFloat()
        if (selected() == null) selectedId = -1
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); onTimeChanged()
    }

    private fun refreshTitle() {
        val l = selected()
        titleView.text = l?.name ?: Editor.project.name
        cubeIcon.tint = if (l != null && (l.is3d || l.type == LayerType.MODEL || l.type == LayerType.CAMERA)) C.GREEN else C.TEXT
        cubeIcon.invalidate()
    }

    private fun showBottom() {
        toolbarBox.visibility = if (panel == P_NONE) View.VISIBLE else View.GONE
        panelBox.visibility = if (panel != P_NONE) View.VISIBLE else View.GONE
    }

    private fun onTimeChanged() {
        syncRows()
        val has = Editor.scene.markers.any { Math.abs(it - Editor.time) < 0.02f }
        markIcon.set(if (has) "bookmark_f" else "bookmark", if (has) C.BLUE else C.TEXT)
        render()
    }

    private fun onBack() {
        if (panel != P_NONE) closePanel() else if (selectedId != -1) onSelect(-1) else finish()
    }

    private fun openPanel(p: Int) {
        if (p != P_MEDIA && p != P_SHAPES && selected() == null) { toast("Select a layer first"); return }
        panel = p
        showBottom(); refreshPanel()
    }

    private fun closePanel() { panel = P_NONE; showBottom() }

    // ================================================================ tool bar

    private fun refreshToolbar() {
        toolbarRow.removeAllViews()
        val l = selected()
        fun tool(ic: String, label: String, tint: Int = C.TEXT, click: () -> Unit) {
            val b = ToolButton(this, ic, label)
            b.tint = tint
            b.onClick = click
            toolbarRow.addView(b, LinearLayout.LayoutParams(dp(76), dp(76)))
        }
        if (l == null) {
            tool("media", "Media") { openPanel(P_MEDIA) }
            tool("text", "Text") { addLayer(LayerType.TEXT) }
            tool("shape", "Shape") { openPanel(P_SHAPES) }
            tool("camera", "Camera") { addLayer(LayerType.CAMERA) }
            tool("nullobj", "Null") { addLayer(LayerType.NULL) }
            tool("particles", "Particles") { addLayer(LayerType.PARTICLES) }
            tool("cube", "3D Model") { pickFile(R_GLB, "*/*") }
        } else {
            toolbarRow.addView(icon("back", C.GREEN) { onSelect(-1) }, LinearLayout.LayoutParams(dp(44), dp(76)))
            tool("edit", "Edit") { openPanel(P_EDIT) }
            tool("move", "Transform") { openPanel(P_XFORM) }
            if (l.isRenderable()) {
                tool("sparkle", "Effects") { openPanel(P_FX) }
                tool("drop", "Blending") { openPanel(P_BLEND) }
                tool("speed", "Speed") { openPanel(P_SPEED) }
            }
            tool("graph", "Graph") { openPanel(P_GRAPH) }
            tool("trash", "Delete", C.RED) { deleteLayer() }
        }
    }

    // ================================================================ playback

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (!playing) return
            if (lastNs != 0L) {
                var t = Editor.time + (ns - lastNs) / 1e9f
                if (t > Editor.scene.duration) t = 0f
                Editor.time = t
                onTimeChanged()
            }
            lastNs = ns
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun togglePlay() {
        playing = !playing
        playIcon.set(if (playing) "pause" else "play", C.TEXT)
        if (playing) { lastNs = 0L; Choreographer.getInstance().postFrameCallback(frameCb) }
    }

    private fun stepFrame(dir: Int) {
        Editor.time = (Editor.time + dir / Editor.project.fps.toFloat()).coerceIn(0f, Editor.scene.duration)
        onTimeChanged()
    }

    private fun jump(dir: Int) {
        val times = ArrayList<Float>()
        times.addAll(Editor.scene.markers)
        selected()?.let { l -> for ((_, tr) in l.props) for (k in tr.keys) times.add(k.t) }
        times.sort()
        val now = Editor.time
        val target = if (dir > 0) times.firstOrNull { it > now + 0.02f } else times.lastOrNull { it < now - 0.02f }
        if (target != null) { Editor.time = target; onTimeChanged() }
    }

    private fun toggleMarker() {
        val ms = Editor.scene.markers
        val ex = ms.firstOrNull { Math.abs(it - Editor.time) < 0.02f }
        pushUndo()
        if (ex != null) ms.remove(ex) else ms.add(Editor.time)
        onTimeChanged()
    }

    private fun cycleQuality() {
        quality = when (quality) { 1 -> 2; 2 -> 4; else -> 1 }
        preview.quality = quality
        qualityChip.text = when (quality) { 1 -> "Full"; 2 -> "1/2"; else -> "1/4" }
        qualityChip.invalidate(); render()
    }

    // ================================================================ undo / redo

    private fun snapshot(): String = Store.toJson(Editor.project).toString()

    private fun pushUndo() {
        val s = snapshot()
        if (undo.lastOrNull() == s) return
        undo.add(s)
        if (undo.size > 40) undo.removeAt(0)
        redo.clear()
    }

    private fun restore(js: String) {
        val p = Store.fromJson(JSONObject(js))
        Editor.project = p
        if (Editor.sceneIndex >= p.scenes.size) Editor.sceneIndex = p.scenes.size - 1
        Editor.time = Editor.time.coerceIn(0f, Editor.scene.duration)
        refreshAll()
    }

    private fun doUndo() { if (undo.isEmpty()) { toast("Nothing to undo"); return }; redo.add(snapshot()); restore(undo.removeAt(undo.size - 1)) }
    private fun doRedo() { if (redo.isEmpty()) { toast("Nothing to redo"); return }; undo.add(snapshot()); restore(redo.removeAt(redo.size - 1)) }

    // ================================================================ hosts

    override fun selectedLayer(): Layer? = selected()
    override fun autoKey(): Boolean = autoKey
    override fun beginEdit() { pushUndo() }
    override fun onEdited() { syncRows(); render() }
    override fun selectedId(): Int = selectedId
    override fun onSeek(t: Float) { Editor.time = t; onTimeChanged() }
    override fun onSelect(id: Int) {
        selectedId = id
        panel = if (id >= 0 && selected()?.type == LayerType.TEXT) P_EDIT else P_NONE
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
    }
    override fun onToggleVisible(l: Layer) { pushUndo(); l.visible = !l.visible; render() }
    override fun onTimingChanged() { render() }

    // ================================================================ layers

    private fun addLayer(type: LayerType): Layer {
        pushUndo()
        val p = Editor.project
        val s = Editor.scene
        val id = p.nextId++
        val nm = when (type) {
            LayerType.SHAPE -> "Shape"; LayerType.TEXT -> "Text"; LayerType.IMAGE -> "Image"; LayerType.VIDEO -> "Video"
            LayerType.CAMERA -> "Camera"; LayerType.NULL -> "Null"; LayerType.MODEL -> "Model"; LayerType.PARTICLES -> "Particles"
        }
        val l = Layer(id, "$nm $id", type)
        l.end = s.duration
        if (type == LayerType.TEXT) l.color = 0xFFFFFFFF.toInt()
        if (type == LayerType.MODEL || type == LayerType.CAMERA) l.is3d = true
        if (type == LayerType.PARTICLES) l.is3d = true
        s.layers.add(l)
        if (type == LayerType.NULL) toast("Turn on the 3D cube (top bar) so this Null can drive other layers")
        if (type == LayerType.CAMERA) toast("The camera views layers that have the 3D cube on")
        onSelect(id)
        return l
    }

    private fun duplicateLayer() {
        val l = selected() ?: run { toast("Select a layer first"); return }
        pushUndo()
        val id = Editor.project.nextId++
        val c = Layer(id, l.name + " copy", l.type)
        c.text = l.text; c.color = l.color; c.color2 = l.color2; c.shape = l.shape; c.imagePath = l.imagePath
        c.bold = l.bold; c.italic = l.italic; c.start = l.start; c.end = l.end; c.is3d = l.is3d; c.parentId = l.parentId
        c.blend = l.blend; c.srcDur = l.srcDur; c.fx.addAll(l.fx); c.fxOff.addAll(l.fxOff); c.inputs.putAll(l.inputs)
        for ((k, tr) in l.props) {
            val n = c.track(k)
            n.base = tr.base
            for (key in tr.keys) { val nk = Key(key.t, key.v, key.ease); nk.x1 = key.x1; nk.y1 = key.y1; nk.x2 = key.x2; nk.y2 = key.y2; n.keys.add(nk) }
        }
        c.track("x").base = c.track("x").base + 0.1f
        Editor.scene.layers.add(c)
        onSelect(id)
    }

    private fun deleteLayer() {
        val l = selected() ?: return
        pushUndo()
        Editor.scene.layers.remove(l)
        for (o in Editor.scene.layers) if (o.parentId == l.id) o.parentId = -1
        onSelect(-1)
    }

    private fun moveLayer(dir: Int) {
        val l = selected() ?: return
        pushUndo()
        val ls = Editor.scene.layers
        val i = ls.indexOf(l)
        val j = i + dir
        if (j < 0 || j >= ls.size) return
        ls.removeAt(i); ls.add(j, l); render()
    }

    private fun toggle3d() {
        val l = selected() ?: run { toast("Select a layer first"); return }
        if (l.type == LayerType.MODEL || l.type == LayerType.CAMERA) { toast("This layer is always 3D"); return }
        pushUndo()
        l.is3d = !l.is3d
        refreshTitle(); refreshPanel(); render()
        toast(if (l.is3d) "3D on" else "3D off")
    }

    private fun showMenu() {
        val items = arrayOf("Export video", "Scene setup", "Move layer up", "Move layer down", "Delete layer", "Close project")
        AlertDialog.Builder(this).setItems(items) { _, w ->
            when (w) { 0 -> doExport(); 1 -> showSceneDialog(); 2 -> moveLayer(1); 3 -> moveLayer(-1); 4 -> deleteLayer(); else -> finish() }
        }.show()
    }

    // ================================================================ importing

    private fun pickFile(req: Int, mime: String) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = mime
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(i, req)
    }

    private fun displayName(uri: android.net.Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "file"
            }
        } catch (e: Exception) { }
        return "file"
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        if (req == R_FX || req == R_PRESET) {
            try {
                val txt = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                if (req == R_FX) {
                    val err = Registry.addCustom(this, txt)
                    if (err != null) toast(err) else { toast("Effect imported"); EffectThumbs.generate(this) { refreshPanel() }; refreshPanel() }
                } else {
                    val o = JSONObject(txt)
                    o.getString("name")
                    Registry.savePreset(this, o)
                    toast("Preset imported"); refreshPanel()
                }
            } catch (e: Exception) { toast("Could not read file") }
            return
        }
        val name = displayName(uri)
        toast("Importing...")
        Thread {
            try {
                val f = File(Projects.mediaDir(this), System.currentTimeMillis().toString() + "_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread { addMedia(f.absolutePath, when (req) { R_VIDEO -> LayerType.VIDEO; R_GLB -> LayerType.MODEL; else -> LayerType.IMAGE }) }
            } catch (e: Exception) { runOnUiThread { toast("Import failed") } }
        }.start()
    }

    private fun addMedia(path: String, type: LayerType) {
        val l = addLayer(type)
        l.imagePath = path
        l.name = File(path).name.substringAfter('_')
        if (type == LayerType.VIDEO) {
            try {
                val mr = MediaMetadataRetriever()
                mr.setDataSource(path)
                val ms = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                mr.release()
                l.srcDur = ms / 1000f
                val s = Editor.scene
                if (s.layers.size == 1 && l.srcDur > 0.5f) { s.duration = l.srcDur.coerceAtMost(120f) }
                l.end = minOf(s.duration, l.start + l.srcDur.coerceAtLeast(0.5f))
            } catch (e: Exception) { }
        }
        refreshTitle(); refreshPanel(); render()
    }

    private fun exportText(name: String, content: String) {
        try {
            val v = ContentValues()
            v.put(MediaStore.Downloads.DISPLAY_NAME, name)
            v.put(MediaStore.Downloads.MIME_TYPE, "application/json")
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SaikiMotion")
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(content.toByteArray()) }
            toast("Saved to Downloads/SaikiMotion/$name")
        } catch (e: Exception) { toast("Export failed") }
    }

    // ================================================================ panels

    private fun refreshPanel() {
        panelList.removeAllViews()
        rows.clear()
        if (panel == P_NONE) return
        if (panel == P_MEDIA) buildMedia()
        else if (panel == P_SHAPES) buildShapes()
        else {
            val l = selected() ?: run { closePanel(); return }
            when (panel) {
                P_EDIT -> buildEdit(l)
                P_XFORM -> buildXform(l)
                P_FX -> buildFx(l)
                P_BLEND -> buildBlend(l)
                P_SPEED -> buildSpeed(l)
                P_GRAPH -> buildGraph(l)
            }
        }
        syncRows()
    }

    private fun addRow(parent: LinearLayout, l: Layer, d: PropDef, label: String = d.label) {
        if (d.options != null) { addOptionRow(parent, l, d); return }
        val tr = l.track(d.key)
        val s = RulerSlider(this)
        s.label = label; s.lo = d.min; s.hi = d.max; s.dec = d.dec
        s.value = tr.eval(l.editTime(d.key, Editor.time))
        s.onBegin = { pushUndo() }
        s.onChange = { v -> tr.set(l.editTime(d.key, Editor.time), v, autoKey); syncRows(s); render() }
        s.onLabelTap = { pushUndo(); tr.toggleKey(l.editTime(d.key, Editor.time)); syncRows(); render() }
        put(parent, s, 60)
        rows.add(Row(s, d, l))
    }

    private fun addOptionRow(parent: LinearLayout, l: Layer, d: PropDef) {
        text(parent, d.label, C.TEXT, 14f, true)
        val tr = l.track(d.key)
        parent.addView(chipRow(this, d.options!!, tr.base.toInt()) { i -> pushUndo(); tr.keys.clear(); tr.base = i.toFloat(); refreshPanel(); render() })
    }

    private fun addPlain(parent: LinearLayout, label: String, lo: Float, hi: Float, v: Float, dec: Int, onChange: (Float) -> Unit) {
        val s = RulerSlider(this)
        s.label = label; s.lo = lo; s.hi = hi; s.value = v; s.dec = dec; s.canKey = false
        s.onBegin = { pushUndo() }
        s.onChange = onChange
        put(parent, s, 60)
    }

    private fun syncRows(except: RulerSlider? = null) {
        for (r in rows) {
            val tr = r.layer.track(r.d.key)
            val t = r.layer.editTime(r.d.key, Editor.time)
            if (r.slider !== except) r.slider.value = tr.eval(t)
            r.slider.hasKey = tr.keyAt(t) != null
            r.slider.hasAnim = tr.keys.isNotEmpty()
            r.slider.invalidate()
        }
        diamondSide.set("diamond_f", if (rows.any { it.slider.hasKey }) C.GREEN else C.DIM)
    }

    private fun keyAllRows() {
        if (rows.isEmpty()) { toast("Open Transform or an effect first"); return }
        pushUndo()
        val all = rows.all { it.slider.hasKey }
        for (r in rows) {
            val tr = r.layer.track(r.d.key)
            val t = r.layer.editTime(r.d.key, Editor.time)
            val has = tr.keyAt(t) != null
            if ((all && has) || (!all && !has)) tr.toggleKey(t)
        }
        syncRows(); render()
    }

    private fun colorRow(onPick: (Int) -> Unit): View {
        val colors = intArrayOf(0xFF7C4DFF.toInt(), 0xFFFF4081.toInt(), 0xFFF44336.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(),
            0xFF22C55E.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt())
        val row = hRow()
        for (col in colors) {
            val v = View(this)
            v.setBackgroundColor(col)
            v.setOnClickListener { onPick(col) }
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.setMargins(dp(4), dp(6), dp(4), dp(6))
            row.addView(v, lp)
        }
        val sv = HorizontalScrollView(this)
        sv.addView(row)
        return sv
    }

    // ---------------------------------------------------------------- media + shapes

    private fun buildMedia() {
        val p = panelList
        text(p, "Media", C.TEXT, 16f, true)
        put(p, pill("Import video", "import") { pickFile(R_VIDEO, "video/*") }, 44)
        put(p, pill("Import image", "import") { pickFile(R_IMAGE, "image/*") }, 44)
        put(p, pill("Import 3D model (.glb)", "import") { pickFile(R_GLB, "*/*") }, 44)
        val files = (Projects.mediaDir(this).listFiles() ?: emptyArray()).sortedByDescending { it.lastModified() }.take(12)
        if (files.isNotEmpty()) text(p, "Recent media", C.DIM, 13f)
        for (f in files) {
            val ext = f.extension.lowercase()
            val type = if (ext == "glb") LayerType.MODEL else if (ext in listOf("mp4", "mov", "mkv", "webm", "3gp", "m4v")) LayerType.VIDEO else LayerType.IMAGE
            put(p, pill(f.name.substringAfter('_'), if (type == LayerType.VIDEO) "media" else if (type == LayerType.MODEL) "cube" else "media") {
                addMedia(f.absolutePath, type)
            }, 40)
        }
    }

    private fun buildShapes() {
        text(panelList, "Add shape", C.TEXT, 16f, true)
        val names = ShapeKind.values().map { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }
        panelList.addView(chipRow(this, names, -1) { i ->
            val l = addLayer(LayerType.SHAPE)
            l.shape = ShapeKind.values()[i]
            render()
        })
    }

    // ---------------------------------------------------------------- edit

    private fun buildEdit(l: Layer) {
        val p = panelList
        when (l.type) {
            LayerType.TEXT -> {
                text(p, "Text", C.TEXT, 16f, true)
                val et = EditText(this)
                et.setText(l.text)
                et.setTextColor(C.TEXT)
                et.addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: android.text.Editable?) { l.text = s?.toString() ?: ""; render() }
                })
                put(p, et)
                val r = hRow()
                r.addView(pill(if (l.bold) "Bold: on" else "Bold: off") { pushUndo(); l.bold = !l.bold; refreshPanel(); render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
                r.addView(pill(if (l.italic) "Italic: on" else "Italic: off") { pushUndo(); l.italic = !l.italic; refreshPanel(); render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
                put(p, r)
                text(p, "Color", C.DIM)
                p.addView(colorRow { c -> pushUndo(); l.color = c; render() })
                addRow(p, l, Defs.transform[2], "Size")
            }
            LayerType.SHAPE -> {
                text(p, "Shape", C.TEXT, 16f, true)
                val names = ShapeKind.values().map { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }
                p.addView(chipRow(this, names, l.shape.ordinal) { i -> pushUndo(); l.shape = ShapeKind.values()[i]; refreshPanel(); render() })
                text(p, "Color", C.DIM)
                p.addView(colorRow { c -> pushUndo(); l.color = c; render() })
            }
            LayerType.PARTICLES -> {
                text(p, "Particle World", C.TEXT, 16f, true)
                text(p, "Birth color", C.DIM); p.addView(colorRow { c -> pushUndo(); l.color = c; render() })
                text(p, "Death color", C.DIM); p.addView(colorRow { c -> pushUndo(); l.color2 = c; render() })
                val groups = listOf("Birth" to listOf("pBirthRate", "pLongevity", "pProdX", "pProdY", "pProdZ", "pRadX", "pRadY", "pRadZ"),
                    "Physics" to listOf("pAnim", "pVelocity", "pDirection", "pSpread", "pGravity", "pResist", "pExtra"),
                    "Particle" to listOf("pType", "pBirthSize", "pDeathSize", "pSizeVar", "pOpacity", "pFade", "pAdd", "pSeed"))
                for ((g, keys) in groups) {
                    text(p, g, C.GREEN, 14f, true)
                    for (k in keys) Registry.propDef(k)?.let { addRow(p, l, it) }
                }
            }
            LayerType.CAMERA -> { text(p, "Camera", C.TEXT, 16f, true); addRow(p, l, Defs.camera[0]); text(p, "Position and rotate it in Transform. It controls every layer whose 3D cube is on.") }
            LayerType.NULL -> { text(p, "Null object", C.TEXT, 16f, true); text(p, "An invisible layer. Turn its 3D cube on, then pick it as Parent in other layers' Transform panel.") }
            else -> {
                text(p, l.type.name.lowercase().replaceFirstChar { it.uppercase() }, C.TEXT, 16f, true)
                text(p, l.name)
                if (l.type == LayerType.VIDEO) text(p, "Length: " + String.format("%.1f", l.srcDur) + " s. Decoded with the system decoder, no extra libraries.")
                if (l.type == LayerType.MODEL) text(p, "Static .glb mesh. Transforms are baked on load and everything is drawn from one GPU buffer per part.")
            }
        }
    }

    // ---------------------------------------------------------------- transform

    private fun buildXform(l: Layer) {
        val p = panelList
        val threeD = l.is3d || l.type == LayerType.MODEL || l.type == LayerType.CAMERA
        text(p, "Transform", C.TEXT, 16f, true)
        put(p, pill(if (threeD) "3D layer: on" else "3D layer: off (tap the cube)", "cube", C.CARD2, if (threeD) C.GREEN else C.TEXT) { toggle3d() }, 42)
        if (l.type == LayerType.NULL && !l.is3d) text(p, "This Null is 2D, so it will not move other layers. Turn 3D on.", C.AMBER)
        addRow(p, l, Defs.transform[0]); addRow(p, l, Defs.transform[1])
        if (threeD) addRow(p, l, Defs.pos3d[0])
        if (l.type != LayerType.CAMERA) addRow(p, l, Defs.transform[2])
        addRow(p, l, Defs.transform[4])
        if (threeD) { addRow(p, l, Defs.rot3d[0]); addRow(p, l, Defs.rot3d[1]) }
        if (l.isRenderable()) addRow(p, l, Defs.transform[3])
        val par = Editor.scene.layers.firstOrNull { it.id == l.parentId }
        put(p, pill("Parent: " + (par?.name ?: "None"), "layers") { showParentDialog(l) }, 42)
        val b = hRow()
        for (axis in arrayOf("rotX", "rotY", "rotZ")) {
            if (!threeD && axis != "rotZ") continue
            b.addView(pill("Spin " + axis.last()) { spin(l, axis) }, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        put(p, b)
    }

    private fun spin(l: Layer, key: String) {
        pushUndo()
        val tr = l.track(key)
        tr.keys.clear()
        tr.keys.add(Key(l.start, 0f, Ease.LINEAR)); tr.keys.add(Key(l.end, 360f, Ease.LINEAR))
        refreshPanel(); render()
    }

    private fun showParentDialog(l: Layer) {
        val cands = Editor.scene.layers.filter { it.id != l.id && it.parentId != l.id }
        val names = arrayOf("None") + cands.map { it.name + if (it.type == LayerType.NULL) " (Null)" else "" }
        AlertDialog.Builder(this).setTitle("Parent").setItems(names) { _, w ->
            pushUndo()
            l.parentId = if (w == 0) -1 else cands[w - 1].id
            refreshPanel(); render()
        }.show()
    }

    // ---------------------------------------------------------------- blending + speed

    private fun buildBlend(l: Layer) {
        val p = panelList
        text(p, "Blending", C.TEXT, 16f, true)
        addRow(p, l, Defs.transform[3])
        text(p, "Blend mode", C.DIM)
        p.addView(chipRow(this, listOf("Normal", "Add", "Screen", "Multiply"), l.blend) { i -> pushUndo(); l.blend = i; refreshPanel(); render() })
    }

    private fun buildSpeed(l: Layer) {
        val p = panelList
        text(p, "Speed and Time Remap", C.TEXT, 16f, true)
        val on = l.fx.contains("remap")
        p.addView(chipRow(this, listOf("Normal speed", "Time remap"), if (on) 1 else 0) { i ->
            pushUndo()
            if (i == 1) { if (!l.fx.contains("remap")) l.fx.add("remap"); l.fxOff.remove("remap") } else l.fx.remove("remap")
            refreshPanel(); render()
        })
        if (on) {
            for (d in Registry.get("remap")!!.props) addRow(p, l, d)
            text(p, "Negative speed plays backwards. Loop length repeats the layer. Video layers follow this speed too.")
        }
    }

    // ---------------------------------------------------------------- effects

    private fun buildFx(l: Layer) {
        val p = panelList
        p.addView(chipRow(this, listOf("Applied", "Browse", "Presets", "Custom"), fxTab) { fxTab = it; refreshPanel() })
        when (fxTab) { 0 -> buildApplied(l); 1 -> buildBrowse(l); 2 -> buildPresets(l); else -> buildCustom(l) }
    }

    private fun fxHeader(l: Layer, d: EffectDef): View {
        val key = l.id.toString() + ":" + d.id
        val open = expanded.contains(key)
        val bar = hRow()
        bar.setBackgroundColor(C.CARD)
        bar.addView(IconView(this, "handle", C.DIM, 20f), LinearLayout.LayoutParams(dp(36), dp(48)))
        val t = TextView(this)
        t.text = d.name; t.setTextColor(C.TEXT); t.textSize = 16f; t.typeface = Typeface.DEFAULT_BOLD
        bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        val off = l.fxOff.contains(d.id)
        val eye = IconView(this, if (off) "eye_off" else "eye", if (off) C.DIM else C.GREEN, 20f)
        eye.onClick = { pushUndo(); if (off) l.fxOff.remove(d.id) else l.fxOff.add(d.id); refreshPanel(); render() }
        bar.addView(eye, LinearLayout.LayoutParams(dp(40), dp(48)))
        val chev = IconView(this, if (open) "chev_up" else "chev_down", C.DIM, 20f)
        chev.onClick = { if (!expanded.remove(key)) expanded.add(key); refreshPanel() }
        bar.addView(chev, LinearLayout.LayoutParams(dp(40), dp(48)))
        val del = IconView(this, "trash", C.RED, 20f)
        del.onClick = { pushUndo(); l.fx.remove(d.id); l.fxOff.remove(d.id); refreshPanel(); render() }
        bar.addView(del, LinearLayout.LayoutParams(dp(40), dp(48)))
        return bar
    }

    private fun buildApplied(l: Layer) {
        val p = panelList
        if (l.fx.isEmpty()) text(p, "No effects yet. Tap Add Effect to browse.")
        for (id in l.fx) {
            val d = Registry.get(id) ?: continue
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.addView(fxHeader(l, d))
            if (expanded.contains(l.id.toString() + ":" + id)) {
                text(c, d.desc, C.DIM, 12f)
                Registry.errors[id]?.let { text(c, "Shader error: $it", C.RED, 12f) }
                for (pd in d.props) addRow(c, l, pd)
                for (nm in d.inputs) {
                    val rid = l.inputs[id + ":" + nm]
                    val ref = Editor.scene.layers.firstOrNull { it.id == rid }
                    put(c, pill(nm + " layer: " + (ref?.name ?: "None"), "layers") { showInputDialog(l, d, nm) }, 42)
                }
                if (id == "tile") {
                    val b = hRow()
                    for (axis in arrayOf("tileX", "tileY")) b.addView(pill("Scroll " + axis.last()) { tileScroll(l, axis) }, LinearLayout.LayoutParams(0, dp(40), 1f))
                    c.addView(b)
                }
            }
            put(p, c, 0, 3, 6)
        }
        put(p, pill("Add Effect", "plus", C.GREEN, 0xFF04210F.toInt()) { fxTab = 1; refreshPanel() }, 48, 10, 10)
    }

    private fun tileScroll(l: Layer, key: String) {
        pushUndo()
        val tr = l.track(key)
        val mirror = l.p("tileMirror", Editor.time) >= 0.5f
        tr.keys.clear()
        tr.keys.add(Key(l.start, 0f, Ease.LINEAR)); tr.keys.add(Key(l.end, if (mirror) 2f else 1f, Ease.LINEAR))
        refreshPanel(); render()
    }

    private fun showInputDialog(l: Layer, d: EffectDef, nm: String) {
        val cands = Editor.scene.layers.filter { it.id != l.id && it.isRenderable() && it.type != LayerType.VIDEO && it.type != LayerType.MODEL && it.type != LayerType.PARTICLES }
        val names = arrayOf("None") + cands.map { it.name }
        AlertDialog.Builder(this).setTitle(nm + " layer").setItems(names) { _, w ->
            pushUndo()
            if (w == 0) l.inputs.remove(d.id + ":" + nm) else l.inputs[d.id + ":" + nm] = cands[w - 1].id
            refreshPanel(); render()
        }.show()
    }

    private fun buildBrowse(l: Layer) {
        val p = panelList
        val cats = listOf("All") + Registry.order.map { it.category }.distinct()
        p.addView(chipRow(this, cats, fxCat) { fxCat = it; refreshPanel() })
        val list = Registry.order.filter { fxCat == 0 || it.category == cats[fxCat] }
        if (list.any { !EffectThumbs.ready(it.id) }) EffectThumbs.generate(this) { if (panel == P_FX && fxTab == 1) refreshPanel() }
        var i = 0
        while (i < list.size) {
            val r = hRow()
            for (j in 0 until 2) {
                if (i + j >= list.size) { r.addView(View(this), LinearLayout.LayoutParams(0, dp(170), 1f)); continue }
                val d = list[i + j]
                val card = EffectCard(this, d.name, d.category)
                card.before = EffectThumbs.cache["__orig"]
                card.after = EffectThumbs.cache[d.id]
                card.badge = l.fx.contains(d.id)
                card.onClick = { showEffectInfo(d, l) }
                val lp = LinearLayout.LayoutParams(0, dp(170), 1f)
                lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                r.addView(card, lp)
            }
            p.addView(r)
            i += 2
        }
    }

    private fun showEffectInfo(d: EffectDef, l: Layer) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val card = EffectCard(this, d.name, d.category)
        card.before = EffectThumbs.cache["__orig"]; card.after = EffectThumbs.cache[d.id]
        box.addView(card, LinearLayout.LayoutParams(MATCH, dp(280)))
        val info = TextView(this)
        val sb = StringBuilder(d.desc).append("\n\nParameters: ")
        sb.append(if (d.props.isEmpty()) "none" else d.props.joinToString(", ") { it.label })
        if (d.inputs.isNotEmpty()) sb.append("\nLayer inputs: ").append(d.inputs.joinToString(", "))
        if (!d.builtin) sb.append("\nCustom effect")
        Registry.errors[d.id]?.let { sb.append("\n\nShader error:\n").append(it) }
        info.text = sb.toString()
        info.setPadding(0, dp(10), 0, 0)
        box.addView(info)
        val b = AlertDialog.Builder(this).setTitle(d.name).setView(ScrollView(this).also { it.addView(box) })
            .setPositiveButton("Add to layer") { _, _ ->
                pushUndo()
                if (!l.fx.contains(d.id)) l.fx.add(d.id)
                l.fxOff.remove(d.id)
                expanded.add(l.id.toString() + ":" + d.id)
                fxTab = 0; refreshPanel(); render()
            }.setNegativeButton("Close", null)
        if (!d.builtin) b.setNeutralButton("Export") { _, _ -> exportText(d.id + ".saikieffect.json", Registry.toJson(d).toString(2)) }
        b.show()
    }

    private fun buildPresets(l: Layer) {
        val p = panelList
        put(p, pill("Save current effects as preset", "plus", C.GREEN, 0xFF04210F.toInt()) {
            if (l.fx.isEmpty()) { toast("Add an effect first"); return@pill }
            val et = EditText(this)
            et.setText("My preset")
            AlertDialog.Builder(this).setTitle("Preset name").setView(et).setPositiveButton("Save") { _, _ ->
                Registry.savePreset(this, Registry.capturePreset(l, et.text.toString().ifBlank { "My preset" }, Editor.time))
                refreshPanel()
            }.show()
        }, 44)
        put(p, pill("Import preset file", "import") { pickFile(R_PRESET, "*/*") }, 44)
        for (pr in Registry.presets(this)) {
            text(p, pr.name + if (pr.builtin) "  (built in)" else "", C.TEXT, 15f, true)
            val r = hRow()
            r.addView(pill("Apply") { pushUndo(); Registry.applyPreset(l, pr.json); fxTab = 0; refreshPanel(); render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill("Export") { exportText(pr.name + ".saikipreset.json", pr.json.toString(2)) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            if (!pr.builtin) r.addView(pill("Delete", null, C.CARD2, C.RED) { Registry.deletePreset(this, pr.name); refreshPanel() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            put(p, r)
        }
    }

    private fun buildCustom(l: Layer) {
        val p = panelList
        put(p, pill("Import effect file", "import") { pickFile(R_FX, "*/*") }, 44)
        put(p, pill("Create your own effect", "plus", C.GREEN, 0xFF04210F.toInt()) { showCreateEffect() }, 44)
        text(p, "An effect is a JSON file with: name, description, params (name, label, min, max, def) and code. The code defines vec4 effect(vec2 uv) and may call src(uv), in0(uv), in1(uv), luma(), hash21(), fbm(), rot(), hsv2rgb() and use uTime and uRes. Every effect gets an auto-rendered animated icon.", C.DIM, 12f)
        val custom = Registry.order.filter { !it.builtin }
        if (custom.isEmpty()) text(p, "No custom effects yet.")
        for (d in custom) {
            text(p, d.name, C.TEXT, 15f, true)
            text(p, d.desc, C.DIM, 12f)
            val r = hRow()
            r.addView(pill("Info") { showEffectInfo(d, l) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill("Export") { exportText(d.id + ".saikieffect.json", Registry.toJson(d).toString(2)) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill("Delete", null, C.CARD2, C.RED) { Registry.deleteCustom(this, d.id); EffectThumbs.cache.remove(d.id); refreshPanel() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            put(p, r)
        }
    }

    private fun showCreateEffect() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        fun field(hint: String, init: String, lines: Int): EditText {
            val e = EditText(this)
            e.hint = hint; e.setText(init); e.textSize = 13f
            if (lines > 1) { e.minLines = lines; e.gravity = Gravity.TOP }
            box.addView(e)
            return e
        }
        val name = field("Name", "My Effect", 1)
        val desc = field("Description", "Mixes the image with grayscale.", 1)
        val params = field("Parameters, one per line: name,label,min,max,default", "amount,Amount,0,1,1", 3)
        val code = field("GLSL code", "vec4 effect(vec2 uv) {\n  vec4 c = src(uv);\n  return vec4(mix(c.rgb, vec3(luma(c.rgb)) * c.a, amount), c.a);\n}", 8)
        AlertDialog.Builder(this).setTitle("Create effect").setView(ScrollView(this).also { it.addView(box) })
            .setPositiveButton("Create") { _, _ ->
                try {
                    val pa = JSONArray()
                    for (line in params.text.toString().lines()) {
                        val f = line.split(",").map { it.trim() }
                        if (f.size >= 5) pa.put(JSONObject().put("name", f[0]).put("label", f[1]).put("min", f[2].toDouble()).put("max", f[3].toDouble()).put("def", f[4].toDouble()))
                    }
                    val o = JSONObject().put("name", name.text.toString()).put("description", desc.text.toString()).put("params", pa).put("code", code.text.toString())
                    val err = Registry.addCustom(this, o.toString())
                    if (err != null) toast(err) else { toast("Effect created"); EffectThumbs.generate(this) { refreshPanel() }; refreshPanel() }
                } catch (e: Exception) { toast("Check the parameter lines") }
            }.setNegativeButton("Cancel", null).show()
    }

    // ---------------------------------------------------------------- graph

    private fun buildGraph(l: Layer) {
        val p = panelList
        text(p, "Bezier graph", C.TEXT, 16f, true)
        val animated = l.props.filter { it.value.keys.size >= 2 }.keys.toList()
        if (animated.isEmpty()) { text(p, "Add two keyframes to a property (tap its label or use the diamond), then edit the curve here."); return }
        if (graphProp !in animated) { graphProp = animated[0]; graphKey = 0 }
        p.addView(chipRow(this, animated.map { Registry.propDef(it)?.label ?: it }, animated.indexOf(graphProp)) { graphProp = animated[it]; graphKey = 0; refreshPanel() })
        val tr = l.track(graphProp)
        graphKey = graphKey.coerceIn(0, tr.keys.size - 2)
        p.addView(chipRow(this, (0 until tr.keys.size - 1).map { "Segment " + (it + 1) }, graphKey) { graphKey = it; refreshPanel() })
        val g = GraphView(this)
        g.key = tr.keys[graphKey]
        g.onBegin = { pushUndo() }
        g.onChange = { render() }
        put(p, g, 220)
        p.addView(chipRow(this, listOf("Linear", "Ease In", "Ease Out", "Ease In-Out", "Bounce"), -1) { i ->
            pushUndo()
            tr.keys[graphKey].preset(listOf(Ease.LINEAR, Ease.EASE_IN, Ease.EASE_OUT, Ease.EASE_IN_OUT, Ease.BOUNCE)[i])
            refreshPanel(); render()
        })
        put(p, pill("Copy this curve to all segments") {
            pushUndo()
            val s = tr.keys[graphKey]
            for (k in tr.keys) { k.ease = s.ease; k.x1 = s.x1; k.y1 = s.y1; k.x2 = s.x2; k.y2 = s.y2 }
            render()
        }, 42)
        text(p, "Drag the two white handles. Pull a handle above 1 for overshoot.", C.DIM, 12f)
    }

    private fun showPanelMenu() {
        val l = selected() ?: return
        AlertDialog.Builder(this).setItems(arrayOf("Clear all keyframes", "Reset transform")) { _, which ->
            pushUndo()
            for ((k, tr) in l.props) {
                if (which == 0) tr.keys.clear()
                else if (Defs.transform.any { it.key == k } || Defs.rot3d.any { it.key == k } || k == "z") { tr.keys.clear(); tr.base = Registry.propDef(k)?.def ?: 0f }
            }
            refreshPanel(); render()
        }.show()
    }

    // ================================================================ scenes + export

    private fun showSceneDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val dlg = AlertDialog.Builder(this).setTitle("Scene setup").setView(ScrollView(this).also { it.addView(box) }).setPositiveButton("Done", null).create()
        fun build() {
            box.removeAllViews()
            val pr = Editor.project
            val s = Editor.scene
            text(box, Projects.resLabel(pr.w, pr.h) + "  ·  " + pr.w + " x " + pr.h + "  ·  " + pr.fps + " fps", C.DIM)
            text(box, "Scenes", C.GREEN, 13f, true)
            box.addView(chipRow(this, pr.scenes.map { it.name } + listOf("New scene"), Editor.sceneIndex) { i ->
                pushUndo()
                if (i == pr.scenes.size) { pr.scenes.add(Scene("Scene " + (pr.scenes.size + 1))); Editor.sceneIndex = pr.scenes.size - 1 } else Editor.sceneIndex = i
                Editor.time = 0f; selectedId = -1; panel = P_NONE; refreshAll(); build()
            })
            if (pr.scenes.size > 1) put(box, pill("Delete this scene", null, C.CARD2, C.RED) {
                pushUndo(); pr.scenes.remove(s); Editor.sceneIndex = 0; Editor.time = 0f; selectedId = -1; panel = P_NONE; refreshAll(); build()
            }, 40)
            val d = RulerSlider(this)
            d.label = "Duration (s)"; d.lo = 1f; d.hi = 120f; d.value = s.duration; d.dec = 1; d.canKey = false
            d.onChange = { v ->
                val old = s.duration
                s.duration = maxOf(1f, Math.round(v * 2f) / 2f)
                for (l in s.layers) if (l.end >= old - 0.001f) l.end = s.duration
                Editor.time = Editor.time.coerceIn(0f, s.duration); onTimeChanged()
            }
            put(box, d, 60, 8, 4)
            val f = RulerSlider(this)
            f.label = "Scene FOV"; f.lo = 15f; f.hi = 90f; f.value = s.fov; f.dec = 0; f.canKey = false
            f.onChange = { v -> s.fov = v; render() }
            put(box, f, 60)
            text(box, "Background", C.GREEN, 13f, true)
            box.addView(colorRow { c -> s.bg = c; render() })
        }
        build()
        dlg.show()
    }

    private fun doExport() {
        if (playing) togglePlay()
        val tv = TextView(this)
        tv.text = "Rendering 0%"; tv.textSize = 16f
        tv.setPadding(dp(24), dp(24), dp(24), dp(24))
        val dlg = AlertDialog.Builder(this).setTitle("Exporting video").setView(tv).setCancelable(false).show()
        Exporter(applicationContext, Editor.project, { pct -> runOnUiThread { tv.text = "Rendering " + pct + "%" } },
            { loc, err -> runOnUiThread { dlg.dismiss(); if (err != null) toast("Export failed: " + err) else toast("Saved to " + loc) } }).start()
    }
}
