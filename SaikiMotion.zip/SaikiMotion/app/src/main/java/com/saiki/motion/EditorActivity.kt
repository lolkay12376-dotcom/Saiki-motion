package com.saiki.motion

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class EditorActivity : Activity(), EditHost, TimelineHost {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val P_NONE = 0; private val P_MEDIA = 1; private val P_SHAPES = 2; private val P_EDIT = 3
    private val P_XFORM = 4; private val P_FX = 5; private val P_BLEND = 6; private val P_SPEED = 7; private val P_GRAPH = 8
    private val R_VIDEO = 51; private val R_IMAGE = 52; private val R_GLB = 53; private val R_FX = 54; private val R_PRESET = 55; private val R_IDE = 56

    private lateinit var projectId: String
    private lateinit var preview: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var aspect: AspectLayout
    private lateinit var timeline: TimelineView
    private lateinit var titleView: TextView
    private lateinit var playIcon: IconView
    private lateinit var markIcon: IconView
    private lateinit var cubeIcon: IconView
    private lateinit var mbToggle: PillToggle
    private lateinit var parentIcon: IconView
    private lateinit var moreIcon: IconView
    private lateinit var gearIcon: IconView
    private lateinit var renderBtn: View
    private lateinit var actionBar: LinearLayout
    private var xformTab = 0
    private var scaleLinked = true
    private var sepDims = true
    private var moveMode = false
    private lateinit var qualityChip: ChipView
    private lateinit var toolbarBox: HorizontalScrollView
    private lateinit var toolbarRow: LinearLayout
    private lateinit var panelBox: LinearLayout
    private lateinit var panelList: LinearLayout
    private lateinit var diamondSide: IconView

    private var selectedId = -1
    private var panel = P_NONE
    private var fxTab = 0
    private var fxCat = 0
    private var playing = false
    private var lastNs = 0L
    private var autoKey = false
    private var quality = 1
    private var graphProp = ""
    private var graphKey = 0
    private var selKey = ""
    private lateinit var screen: FrameLayout
    private lateinit var panelHome: LinearLayout
    private lateinit var panelLp: ViewGroup.LayoutParams
    private val R_AUDIOFILE = 58
    private val R_FONT = 59
    private var textTab = 0
    private val players = HashMap<Int, android.media.MediaPlayer>()
    private val R_BEAT = 57
    private lateinit var subView: TextView
    private val multi = LinkedHashSet<Int>()
    private var multiMode = false
    private val clipboard = ArrayList<Layer>()

    private val expanded = HashSet<String>()
    private val rows = ArrayList<Row>()
    private class Row(val slider: RulerSlider, val d: PropDef, val layer: Layer)
    private val undo = ArrayList<String>()
    private val redo = ArrayList<String>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Snack.show(this, s)

    private fun safe(step: String, block: () -> Unit) {
        try { block() } catch (e: Exception) { toast(step + ": " + (e.message ?: e.javaClass.simpleName)) }
    }

    // ================================================================ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Registry.init(this)
        CrashLog.install(this)
        projectId = intent.getStringExtra("id") ?: ""
        Editor.project = Projects.load(this, projectId)
        Editor.sceneIndex = 0
        if (savedInstanceState == null) Editor.time = 0f
        selectedId = savedInstanceState?.getInt("sel", -1) ?: -1
        buildUi()
        refreshAll()
        safe("previews") { EffectThumbs.generate(this, preview) { if (panel == P_FX && fxTab == 1) refreshPanel() } }
    }

    override fun onResume() { super.onResume(); preview.onResume() }

    override fun onPause() {
        super.onPause()
        playing = false
        stopAudio()
        playIcon.set("play", C.TEXT)
        preview.onPause()
        Projects.save(this, projectId, Editor.project)
    }

    override fun onConfigurationChanged(c: android.content.res.Configuration) {
        super.onConfigurationChanged(c)
        buildUi()
        refreshAll()
    }

    override fun onBackPressed() { onBack() }

    override fun onDestroy() { releaseAudio(); super.onDestroy() }

    private val prepared = HashSet<Int>()
    private val audioLead = 110

    /** Players are created and prepared in the background as soon as an audio layer exists, so Play starts instantly. */
    private fun ensureAudio() {
        val ids = HashSet<Int>()
        for (l in Editor.scene.layers) {
            if (l.type != LayerType.AUDIO) continue
            ids.add(l.id)
            val path = l.imagePath ?: continue
            if (players.containsKey(l.id)) continue
            try {
                val mp = android.media.MediaPlayer()
                mp.setDataSource(path)
                mp.setOnPreparedListener { prepared.add(l.id) }
                mp.prepareAsync()
                players[l.id] = mp
            } catch (e: Exception) { }
        }
        for (id in players.keys.toList()) if (!ids.contains(id)) {
            try { players[id]?.release() } catch (e: Exception) { }
            players.remove(id); prepared.remove(id)
        }
    }

    private fun releaseAudio() {
        for (mp in players.values) try { mp.release() } catch (e: Exception) { }
        players.clear(); prepared.clear()
    }

    private fun stopAudio() {
        for (mp in players.values) try { if (mp.isPlaying) mp.pause() } catch (e: Exception) { }
    }

    private fun startAudio() { ensureAudio(); tickAudio(true) }

    /** Keeps every audio layer locked to the playhead and corrects drift. */
    private fun tickAudio(restart: Boolean = false) {
        val t = Editor.time
        for (l in Editor.scene.layers) {
            val mp = players[l.id] ?: continue
            if (!prepared.contains(l.id)) continue
            try {
                val inside = l.visible && t >= l.start && t <= l.end
                val want = ((t - l.start + l.srcOffset) * 1000f).toInt() + audioLead
                if (inside) {
                    val v = l.p("volume", t).coerceIn(0f, 1f)
                    mp.setVolume(v, v)
                    if (!mp.isPlaying) { mp.seekTo(want.toLong(), android.media.MediaPlayer.SEEK_CLOSEST); mp.start() }
                    else if (restart || Math.abs(mp.currentPosition - want) > 140) mp.seekTo(want.toLong(), android.media.MediaPlayer.SEEK_CLOSEST)
                } else if (mp.isPlaying) mp.pause()
            } catch (e: Exception) { }
        }
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); o.putInt("sel", selectedId) }

    // ================================================================ UI skeleton

    private fun icon(name: String, tint: Int = C.TEXT, click: () -> Unit = {}): IconView {
        val v = IconView(this, name, tint)
        v.onClick = click
        return v
    }

    private fun hRow(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    private fun addIcon(parent: LinearLayout, v: IconView, w: Int = 44, h: Int = 48) {
        parent.addView(v, LinearLayout.LayoutParams(dp(w), dp(h)))
    }

    private fun buildUi() {
        val land = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val root = LinearLayout(this)
        root.orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.fitsSystemWindows = true

        val top = hRow()
        top.setPadding(dp(4), 0, dp(8), 0)
        addIcon(top, icon("back", C.AMBER) { onBack() }, 40)
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        titleView = TextView(this)
        titleView.setTextColor(C.TEXT); titleView.textSize = 17f; titleView.typeface = Typeface.DEFAULT_BOLD; titleView.maxLines = 1
        subView = TextView(this)
        subView.setTextColor(C.DIM); subView.textSize = 11f
        tcol.addView(titleView); tcol.addView(subView)
        top.addView(tcol, LinearLayout.LayoutParams(0, WRAP, 1f))
        cubeIcon = icon("cube") { toggle3d() }
        addIcon(top, cubeIcon, 40)
        mbToggle = PillToggle(this)
        mbToggle.onClick = { selected()?.let { l -> pushUndo(); l.mblur = !l.mblur; mbToggle.on = l.mblur; refreshPanel(); render() } }
        mbToggle.onLong = { selected()?.let { l -> showMotionBlurSettings(l) } }
        top.addView(mbToggle, LinearLayout.LayoutParams(dp(52), dp(40)))
        parentIcon = icon("dup") { selected()?.let { l -> showParentPopup(l, parentIcon) } }
        addIcon(top, parentIcon, 40)
        moreIcon = icon("more") { showLayersMenu() }
        addIcon(top, moreIcon, 40)
        gearIcon = icon("gear") { showSceneDialog() }
        addIcon(top, gearIcon, 40)
        renderBtn = pill("Render", "export", C.GREEN, 0xFF2B1400.toInt()) { showRenderDialog() }
        top.addView(renderBtn, LinearLayout.LayoutParams(dp(104), dp(38)))

        val previewBox = FrameLayout(this)
        previewBox.setBackgroundColor(0xFF161618.toInt())
        aspect = AspectLayout(this)
        preview = PreviewView(this)
        overlay = OverlayView(this, this)
        aspect.addView(preview, MATCH, MATCH)
        aspect.addView(overlay, MATCH, MATCH)
        previewBox.addView(aspect, MATCH, MATCH)

        val tr = hRow()
        tr.setPadding(dp(6), 0, dp(6), 0)
        addIcon(tr, icon("fit") { timeline.fitToScene() })
        qualityChip = ChipView(this, "Full")
        qualityChip.onClick = { cycleQuality() }
        tr.addView(qualityChip, LinearLayout.LayoutParams(dp(56), dp(48)))
        markIcon = icon("bookmark") { toggleMarker() }
        markIcon.onLong = { nameMarker() }
        addIcon(tr, markIcon)
        tr.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val prev = icon("prev") { stepFrame(-1) }
        prev.onLong = { jump(-1) }
        addIcon(tr, prev, 48)
        playIcon = icon("play") { togglePlay() }
        addIcon(tr, playIcon, 52)
        val next = icon("next") { stepFrame(1) }
        next.onLong = { jump(1) }
        addIcon(tr, next, 48)
        tr.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        addIcon(tr, icon("layers") { showLayersMenu() })
        addIcon(tr, icon("undo") { doUndo() })
        addIcon(tr, icon("redo") { doRedo() })

        timeline = TimelineView(this, this)
        val tlBox = FrameLayout(this)
        tlBox.addView(timeline, FrameLayout.LayoutParams(MATCH, MATCH))
        actionBar = LinearLayout(this)
        actionBar.orientation = LinearLayout.HORIZONTAL
        actionBar.gravity = Gravity.CENTER
        val abg = android.graphics.drawable.GradientDrawable()
        abg.setColor(0xF01E1E22.toInt()); abg.cornerRadius = dp(26).toFloat(); abg.setStroke(dp(1), 0xFF3A3A42.toInt())
        actionBar.background = abg
        actionBar.setPadding(dp(8), 0, dp(8), 0)
        actionBar.addView(icon("trimin") { trimTo(true) }, LinearLayout.LayoutParams(dp(52), dp(48)))
        actionBar.addView(icon("split") { splitAtPlayhead(false) }, LinearLayout.LayoutParams(dp(52), dp(48)))
        actionBar.addView(icon("trimout") { trimTo(false) }, LinearLayout.LayoutParams(dp(52), dp(48)))
        actionBar.addView(icon("trash", C.RED) { deleteLayer() }, LinearLayout.LayoutParams(dp(52), dp(48)))
        val alp = FrameLayout.LayoutParams(WRAP, dp(48))
        alp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        alp.bottomMargin = dp(8)
        tlBox.addView(actionBar, alp)
        actionBar.visibility = View.GONE

        toolbarBox = HorizontalScrollView(this)
        toolbarBox.isHorizontalScrollBarEnabled = false
        toolbarBox.setBackgroundColor(C.PANEL)
        toolbarRow = LinearLayout(this)
        toolbarRow.orientation = LinearLayout.HORIZONTAL
        toolbarBox.addView(toolbarRow)

        panelBox = LinearLayout(this)
        panelBox.orientation = LinearLayout.HORIZONTAL
        panelBox.setBackgroundColor(C.PANEL)
        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER_HORIZONTAL
        side.addView(icon("close") { closePanel() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        side.addView(icon("plus", C.GREEN) { fxTab = 1; openPanel(P_FX) }, LinearLayout.LayoutParams(dp(48), dp(44)))
        diamondSide = icon("diamond_f", C.DIM) { keySelected() }
        side.addView(diamondSide, LinearLayout.LayoutParams(dp(48), dp(44)))
        side.addView(icon("graph", C.DIM) { openPanel(P_GRAPH) }, LinearLayout.LayoutParams(dp(48), dp(44)))
        side.addView(icon("box", C.DIM) { fxTab = 2; openPanel(P_FX) }, LinearLayout.LayoutParams(dp(48), dp(44)))
        side.addView(icon("more", C.DIM) { showPanelMenu() }, LinearLayout.LayoutParams(dp(48), dp(44)))
        panelBox.addView(side, LinearLayout.LayoutParams(dp(52), MATCH))
        val sv = ScrollView(this)
        panelList = LinearLayout(this)
        panelList.orientation = LinearLayout.VERTICAL
        panelList.setPadding(dp(4), dp(6), dp(8), dp(16))
        sv.addView(panelList, MATCH, WRAP)
        panelBox.addView(sv, LinearLayout.LayoutParams(0, MATCH, 1f))

        if (land) {
            val left = LinearLayout(this)
            left.orientation = LinearLayout.VERTICAL
            left.addView(top, LinearLayout.LayoutParams(MATCH, dp(52)))
            left.addView(previewBox, LinearLayout.LayoutParams(MATCH, 0, 1f))
            left.addView(tr, LinearLayout.LayoutParams(MATCH, dp(48)))
            val right = LinearLayout(this)
            right.orientation = LinearLayout.VERTICAL
            right.addView(tlBox, LinearLayout.LayoutParams(MATCH, 0, 1f))
            right.addView(toolbarBox, LinearLayout.LayoutParams(MATCH, dp(76)))
            right.addView(panelBox, LinearLayout.LayoutParams(MATCH, dp(220)))
            root.addView(left, LinearLayout.LayoutParams(0, MATCH, 0.46f))
            root.addView(right, LinearLayout.LayoutParams(0, MATCH, 0.54f))
        } else {
            root.addView(top, LinearLayout.LayoutParams(MATCH, dp(52)))
            root.addView(previewBox, LinearLayout.LayoutParams(MATCH, 0, 1f))
            root.addView(tr, LinearLayout.LayoutParams(MATCH, dp(48)))
            root.addView(tlBox, LinearLayout.LayoutParams(MATCH, 0, 1.15f))
            root.addView(toolbarBox, LinearLayout.LayoutParams(MATCH, dp(76)))
            root.addView(panelBox, LinearLayout.LayoutParams(MATCH, dp(300)))
        }
        panelHome = panelBox.parent as LinearLayout
        panelLp = panelBox.layoutParams
        root.fitsSystemWindows = false
        screen = FrameLayout(this)
        screen.fitsSystemWindows = true
        screen.addView(root, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(screen)
    }

    // ================================================================ small helpers

    private fun selected(): Layer? = Editor.scene.layers.firstOrNull { it.id == selectedId }

    private fun render() {
        preview.requestRender(); overlay.invalidate(); timeline.invalidate()
    }

    private fun pill(text: String, icon: String? = null, fill: Int = C.CARD2, tc: Int = C.TEXT, click: () -> Unit): PillButton {
        val b = PillButton(this, text, icon, fill, tc)
        b.onClick = click
        return b
    }

    private fun put(parent: LinearLayout, v: View, hDp: Int = 0, mT: Int = 3, mB: Int = 3) {
        val lp = LinearLayout.LayoutParams(MATCH, if (hDp == 0) WRAP else dp(hDp))
        lp.setMargins(0, dp(mT), 0, dp(mB))
        parent.addView(v, lp)
    }

    private fun text(parent: LinearLayout, t: String, color: Int = C.DIM, size: Float = 13f, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t; tv.setTextColor(color); tv.textSize = size
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dp(6), dp(6), dp(6), dp(4))
        parent.addView(tv)
        return tv
    }

    private fun refreshAll() {
        aspect.ratio = Editor.project.w.toFloat() / Editor.project.h.toFloat()
        if (selected() == null) selectedId = -1
        safe("title") { refreshTitle() }; safe("toolbar") { refreshToolbar() }; safe("panel") { showBottom() }; safe("panel") { refreshPanel() }; safe("time") { onTimeChanged() }; safe("audio") { ensureAudio() }
    }

    private fun refreshTitle() {
        val l = selected()
        titleView.text = l?.name ?: Editor.project.name
        cubeIcon.tint = if (l != null && (l.is3d || l.type == LayerType.MODEL || l.type == LayerType.CAMERA)) C.GREEN else C.TEXT
        cubeIcon.invalidate()
        val sel = l != null
        cubeIcon.visibility = if (sel) View.VISIBLE else View.GONE
        mbToggle.visibility = if (sel && l!!.type != LayerType.AUDIO) View.VISIBLE else View.GONE
        parentIcon.visibility = if (sel) View.VISIBLE else View.GONE
        moreIcon.visibility = if (sel) View.VISIBLE else View.GONE
        gearIcon.visibility = if (sel) View.GONE else View.VISIBLE
        renderBtn.visibility = if (sel) View.GONE else View.VISIBLE
        if (l != null) { mbToggle.on = l.mblur; parentIcon.tint = if (l.parentId >= 0) C.GREEN else C.TEXT; parentIcon.invalidate() }
    }

    /** The Effects panel covers the whole screen; every other panel sits under the timeline. */
    private fun placePanel(full: Boolean) {
        val cur = panelBox.parent as? ViewGroup
        if (full) {
            if (cur !== screen) { cur?.removeView(panelBox); screen.addView(panelBox, FrameLayout.LayoutParams(MATCH, MATCH)) }
            panelBox.bringToFront()
        } else if (cur !== panelHome) {
            cur?.removeView(panelBox)
            panelHome.addView(panelBox, panelLp)
        }
    }

    private fun showBottom() {
        placePanel(panel == P_FX && fxTab == 1)
        toolbarBox.visibility = if (panel == P_NONE) View.VISIBLE else View.GONE
        panelBox.visibility = if (panel != P_NONE) View.VISIBLE else View.GONE
    }

    private fun onTimeChanged() {
        syncRows()
        subView.text = timeline.timecode(Editor.time) + " / " + timeline.timecode(Editor.scene.duration)
        val has = Editor.scene.markers.any { Math.abs(it - Editor.time) < 0.02f }
        markIcon.set(if (has) "bookmark_f" else "bookmark", if (has) C.BLUE else C.TEXT)
        render()
    }

    private fun onBack() {
        if (panel != P_NONE) closePanel() else if (selectedId != -1) onSelect(-1) else finish()
    }

    private fun openPanel(p: Int) {
        if (p != P_MEDIA && p != P_SHAPES && selected() == null) { toast("Select a layer first"); return }
        panel = p
        showBottom(); refreshPanel()
    }

    private fun closePanel() { panel = P_NONE; showBottom() }

    // ================================================================ tool bar

    private fun refreshToolbar() {
        toolbarRow.removeAllViews()
        val l = selected()
        actionBar.visibility = if (l != null) View.VISIBLE else View.GONE
        fun tool(ic: String, label: String, tint: Int = C.TEXT, click: () -> Unit) {
            val b = ToolButton(this, ic, label)
            b.tint = tint
            b.onClick = click
            toolbarRow.addView(b, LinearLayout.LayoutParams(dp(76), dp(76)))
        }
        if (l == null) {
            tool("media", "Media") { openPanel(P_MEDIA) }
            tool("text", "Text") { addLayer(LayerType.TEXT) }
            tool("solid", "Solid") { addSolid() }
            tool("adjust", "Adjustment") { addLayer(LayerType.ADJUST) }
            tool("audio", "Audio") { pickFile(R_AUDIOFILE, "audio/*") }
            tool("nullobj", "Null") { addLayer(LayerType.NULL) }
            tool("shape", "Shape") { openPanel(P_SHAPES) }
            tool("camera", "Camera") { addLayer(LayerType.CAMERA) }
            tool("particles", "Particles") { addParticles() }
            tool("layers", "Group") { addLayer(LayerType.GROUP) }
            tool("cube", "3D Model") { pickFile(R_GLB, "*/*") }
        } else {
            toolbarRow.addView(icon("back", C.GREEN) { onSelect(-1) }, LinearLayout.LayoutParams(dp(44), dp(76)))
            if (l.type == LayerType.VIDEO) tool("audio", "Extract audio") { extractAudio(l) }
            tool("edit", "Edit") { openPanel(P_EDIT) }
            tool("move", "Transform") { openPanel(P_XFORM) }
            if (l.isRenderable() || l.type == LayerType.GROUP) {
                tool("sparkle", "Effects") { openPanel(P_FX) }
                tool("drop", "Blending") { openPanel(P_BLEND) }
                tool("speed", "Speed") { openPanel(P_SPEED) }
            }
        }
    }

    // ================================================================ playback

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (!playing) return
            if (lastNs != 0L) {
                var t = Editor.time + (ns - lastNs) / 1e9f
                var wrapped = false
                if (t > Editor.scene.duration) { t = 0f; wrapped = true }
                Editor.time = t
                if (wrapped) startAudio() else tickAudio()
                onTimeChanged()
            }
            lastNs = ns
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun togglePlay() {
        playing = !playing
        playIcon.set(if (playing) "pause" else "play", C.TEXT)
        if (playing) { lastNs = 0L; Choreographer.getInstance().postFrameCallback(frameCb); startAudio() } else stopAudio()
    }

    private fun stepFrame(dir: Int) {
        Editor.time = (Editor.time + dir / Editor.project.fps.toFloat()).coerceIn(0f, Editor.scene.duration)
        onTimeChanged()
    }

    private fun jump(dir: Int) {
        val times = ArrayList<Float>()
        times.addAll(Editor.scene.markers)
        selected()?.let { l -> for ((_, tr) in l.props) for (k in tr.keys) times.add(k.t) }
        times.sort()
        val now = Editor.time
        val target = if (dir > 0) times.firstOrNull { it > now + 0.02f } else times.lastOrNull { it < now - 0.02f }
        if (target != null) { Editor.time = target; onTimeChanged() }
    }

    private fun toggleMarker() {
        val ms = Editor.scene.markers
        val ex = ms.firstOrNull { Math.abs(it - Editor.time) < 0.02f }
        pushUndo()
        if (ex != null) { Editor.scene.setMarkerName(ex, ""); ms.remove(ex) } else ms.add(Editor.time)
        onTimeChanged()
    }

    private fun nameMarker() {
        val ms = Editor.scene.markers
        var m = ms.firstOrNull { Math.abs(it - Editor.time) < 0.02f }
        if (m == null) { pushUndo(); ms.add(Editor.time); m = Editor.time; onTimeChanged() }
        val tm = m
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(4), dp(4), dp(4))
        text(box, timeline.timecode(tm), C.DIM, 13f)
        val et = EditText(this)
        et.hint = "Marker name"
        et.setText(Editor.scene.markerName(tm) ?: "")
        et.setSingleLine(true)
        box.addView(et)
        text(box, "Expressions can reach this marker by name:  marker.key(\"name\")", C.DIM, 12f)
        Dlg(this).setTitle("Name marker").setView(box).setPositiveButton("Save") { _, _ ->
            pushUndo()
            Editor.scene.setMarkerName(tm, et.text.toString())
            timeline.invalidate(); render()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun cycleQuality() {
        quality = when (quality) { 1 -> 2; 2 -> 4; else -> 1 }
        preview.quality = quality
        qualityChip.text = when (quality) { 1 -> "Full"; 2 -> "1/2"; else -> "1/4" }
        qualityChip.invalidate(); render()
    }

    // ================================================================ undo / redo

    private fun snapshot(): String = Store.toJson(Editor.project).toString()

    private fun pushUndo() {
        val s = snapshot()
        if (undo.lastOrNull() == s) return
        undo.add(s)
        if (undo.size > 40) undo.removeAt(0)
        redo.clear()
    }

    private fun restore(js: String) {
        val p = Store.fromJson(JSONObject(js))
        Editor.project = p
        if (Editor.sceneIndex >= p.scenes.size) Editor.sceneIndex = p.scenes.size - 1
        Editor.time = Editor.time.coerceIn(0f, Editor.scene.duration)
        refreshAll()
    }

    private fun doUndo() { if (undo.isEmpty()) { toast("Nothing to undo"); return }; redo.add(snapshot()); restore(undo.removeAt(undo.size - 1)) }
    private fun doRedo() { if (redo.isEmpty()) { toast("Nothing to redo"); return }; undo.add(snapshot()); restore(redo.removeAt(redo.size - 1)) }

    // ================================================================ hosts

    override fun selectedLayer(): Layer? = selected()
    override fun autoKey(): Boolean = autoKey
    override fun beginEdit() { pushUndo() }
    override fun onEdited() { syncRows(); render() }
    override fun selectedId(): Int = selectedId
    override fun isSelected(id: Int): Boolean = id == selectedId || multi.contains(id)
    override fun onSeek(t: Float) { Editor.time = t; onTimeChanged() }
    override fun onSelect(id: Int) {
        if (multiMode && id >= 0) {
            if (!multi.remove(id)) multi.add(id)
            selectedId = id; panel = P_NONE
            refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
            return
        }
        if (!multiMode) multi.clear()
        selectedId = id
        panel = if (id >= 0 && selected()?.type == LayerType.TEXT) P_EDIT else P_NONE
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
    }
    override fun onToggleVisible(l: Layer) { pushUndo(); l.visible = !l.visible; render() }
    override fun onTimingChanged() { render() }

    override fun onReorder(l: Layer, listIndex: Int) {
        pushUndo()
        val ls = Editor.scene.layers
        ls.remove(l)
        ls.add(listIndex.coerceIn(0, ls.size), l)
        render()
    }

    override fun onKeyTap(l: Layer, key: String, idx: Int) {
        selectedId = l.id
        graphProp = key
        graphKey = idx
        Editor.time = l.track(key).keys.getOrNull(idx)?.t ?: Editor.time
        panel = P_GRAPH
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); onTimeChanged()
    }

    // ================================================================ layers

    private fun addLayer(type: LayerType): Layer {
        pushUndo()
        val p = Editor.project
        val s = Editor.scene
        val id = p.nextId++
        val nm = when (type) {
            LayerType.SHAPE -> "Shape"; LayerType.TEXT -> "Text"; LayerType.IMAGE -> "Image"; LayerType.VIDEO -> "Video"
            LayerType.CAMERA -> "Camera"; LayerType.NULL -> "Null"; LayerType.MODEL -> "Model"; LayerType.PARTICLES -> "Particles"; LayerType.GROUP -> "Group"; LayerType.ADJUST -> "Adjustment"; LayerType.AUDIO -> "Audio"
        }
        val l = Layer(id, "$nm $id", type)
        l.end = s.duration
        if (type == LayerType.TEXT) l.color = 0xFFFFFFFF.toInt()
        if (type == LayerType.MODEL || type == LayerType.CAMERA) l.is3d = true
        s.layers.add(l)
        if (type == LayerType.NULL) toast("Turn on the 3D cube (top bar) so this Null can drive other layers")
        if (type == LayerType.CAMERA) toast("The camera affects layers below it that have the 3D cube on")
        onSelect(id)
        return l
    }

    private fun addParticles() {
        val l = addLayer(LayerType.SHAPE)
        l.name = "Particles " + l.id
        l.shape = ShapeKind.CIRCLE
        l.fx.add("particles")
        l.track("pShowSrc").base = 0f
        expanded.add(l.id.toString() + ":particles")
        fxTab = 0
        panel = P_FX
        showBottom(); refreshPanel()
    }

    private fun cloneLayer(l: Layer, suffix: String): Layer {
        val c = Layer(Editor.project.nextId++, l.name + suffix, l.type)
        c.text = l.text; c.color = l.color; c.color2 = l.color2; c.shape = l.shape; c.imagePath = l.imagePath
        c.bold = l.bold; c.italic = l.italic; c.font = l.font; c.fontPath = l.fontPath; c.strokeW = l.strokeW; c.strokeColor = l.strokeColor; c.spacing = l.spacing; c.borderW = l.borderW; c.borderColor = l.borderColor; c.borderPad = l.borderPad; c.align = l.align; c.underline = l.underline; c.strike = l.strike; c.caps = l.caps; c.shadowOn = l.shadowOn; c.shadowColor = l.shadowColor; c.strokePos = l.strokePos; c.strokeJoin = l.strokeJoin; c.stroke2Color = l.stroke2Color; c.borderFill = l.borderFill; c.borderDash = l.borderDash; for (an in l.anims) c.anims.add(an.copy()); c.start = l.start; c.end = l.end; c.is3d = l.is3d; c.parentId = l.parentId
        c.blend = l.blend; c.srcDur = l.srcDur; c.visible = l.visible; c.srcOffset = l.srcOffset; c.mask = l.mask; c.mblur = l.mblur; c.mbRgb = l.mbRgb; c.mbStutter = l.mbStutter; c.fx.addAll(l.fx); c.fxOff.addAll(l.fxOff); c.inputs.putAll(l.inputs)
        for ((k, tr) in l.props) {
            val n = c.track(k)
            n.base = tr.base
            n.copyExprFrom(tr)
            for (key in tr.keys) { val nk = Key(key.t, key.v, key.ease); nk.x1 = key.x1; nk.y1 = key.y1; nk.x2 = key.x2; nk.y2 = key.y2; n.keys.add(nk) }
        }
        return c
    }

    private fun targets(): List<Layer> {
        val m = Editor.scene.layers.filter { multi.contains(it.id) }
        if (m.isNotEmpty()) return m
        val s = selected()
        return if (s != null) listOf(s) else emptyList()
    }

    private fun duplicateSelected() {
        val t = targets()
        if (t.isEmpty()) { toast("Select a layer first"); return }
        pushUndo()
        var last = -1
        for (l in t) { val c = cloneLayer(l, " copy"); Editor.scene.layers.add(c); last = c.id }
        multi.clear(); multiMode = false
        onSelect(last)
    }

    private fun copySelected() {
        val t = targets()
        if (t.isEmpty()) { toast("Select a layer first"); return }
        clipboard.clear()
        for (l in t) clipboard.add(cloneLayer(l, ""))
        toast("Copied " + t.size + (if (t.size == 1) " layer" else " layers"))
    }

    private fun pasteLayers() {
        if (clipboard.isEmpty()) { toast("Nothing copied yet"); return }
        pushUndo()
        var last = -1
        for (c in clipboard) { val n = cloneLayer(c, ""); Editor.scene.layers.add(n); last = n.id }
        multi.clear(); multiMode = false
        onSelect(last)
    }

    private fun selectAll() {
        multi.clear()
        for (l in Editor.scene.layers) multi.add(l.id)
        if (multi.isEmpty()) { toast("No layers yet"); return }
        selectedId = multi.last()
        refreshTitle(); refreshToolbar(); render()
        toast("All layers selected")
    }

    private fun groupSelected(asMask: Boolean = false) {
        val t = targets()
        if (t.isEmpty()) { toast("Select layers first"); return }
        pushUndo()
        val g = addLayer(LayerType.GROUP)
        for (l in t) l.parentId = g.id
        if (asMask) {
            if (t.size < 2) toast("Select at least two layers: the top one becomes the mask")
            g.mask = 1
            g.name = "Mask group"
        }
        multi.clear(); multiMode = false
        onSelect(g.id)
        toast(if (asMask) "Mask group: the top layer masks the rest" else "Grouped " + t.size + " layers")
    }

    private fun addSolid() {
        val l = addLayer(LayerType.SHAPE)
        l.shape = ShapeKind.RECT
        l.name = "Solid " + l.id
        l.color = 0xFF2A2A33.toInt()
        val ar = Editor.project.w.toFloat() / Editor.project.h
        l.track("scale").base = (maxOf(2f * ar, 2f) / 0.8f / 0.84f * 1.02f).coerceAtMost(8f)
        refreshPanel(); render()
    }

    private fun deleteLayer() {
        val t = targets()
        if (t.isEmpty()) return
        pushUndo()
        for (l in t) { Editor.scene.layers.remove(l); for (o in Editor.scene.layers) if (o.parentId == l.id) o.parentId = -1 }
        multi.clear(); multiMode = false
        onSelect(-1)
    }

    private fun splitLayer(l: Layer, t: Float): Layer? {
        if (t <= l.start + 0.04f || t >= l.end - 0.04f || l.type == LayerType.GROUP) return null
        val c = cloneLayer(l, "")
        c.name = l.name
        c.start = t
        if (l.type == LayerType.VIDEO || l.type == LayerType.AUDIO) c.srcOffset = l.srcOffset + (t - l.start)
        l.end = t
        val ls = Editor.scene.layers
        ls.add(ls.indexOf(l) + 1, c)
        return c
    }

    /** Splits the selected layers (or every layer under the playhead) at the playhead. */
    private fun splitAtPlayhead(all: Boolean) {
        val t = Editor.time
        val list = if (all) Editor.scene.layers.toList() else targets()
        if (list.isEmpty()) { toast("Select a layer first"); return }
        pushUndo()
        var last: Layer? = null
        var n = 0
        for (l in list) { val c = splitLayer(l, t); if (c != null) { last = c; n++ } }
        if (last == null) { toast("Move the playhead inside the layer to split it"); return }
        multi.clear(); multiMode = false
        toast(if (n == 1) "Layer split" else "Split $n layers")
        onSelect(last.id)
    }

    /** Moves the start or end of the selected layers to the playhead. */
    private fun trimTo(start: Boolean) {
        val list = targets()
        if (list.isEmpty()) { toast("Select a layer first"); return }
        val t = Editor.time
        pushUndo()
        var n = 0
        for (l in list) {
            if (l.type == LayerType.GROUP) continue
            if (start && t > l.start + 0.04f && t < l.end) {
                if (l.type == LayerType.VIDEO || l.type == LayerType.AUDIO) l.srcOffset += t - l.start
                l.start = t; n++
            } else if (!start && t < l.end - 0.04f && t > l.start) { l.end = t; n++ }
        }
        if (n == 0) toast("Move the playhead inside the layer first") else render()
    }

    private fun moveLayer(dir: Int) {
        val l = selected() ?: return
        pushUndo()
        val ls = Editor.scene.layers
        val i = ls.indexOf(l)
        val j = i + dir
        if (j < 0 || j >= ls.size) return
        ls.removeAt(i); ls.add(j, l); render()
    }

    private fun toggle3d() {
        val l = selected() ?: run { toast("Select a layer first"); return }
        if (l.type == LayerType.MODEL || l.type == LayerType.CAMERA) { toast("This layer is always 3D"); return }
        pushUndo()
        l.is3d = !l.is3d
        refreshTitle(); refreshPanel(); render()
        toast(if (l.is3d) "3D on" else "3D off")
    }

    private fun showLayersMenu() {
        val labels = arrayOf("Select All Layers", if (multiMode) "Stop Selecting Multiple" else "Select Multiple Layers", "Group Layers", "Show All Keyframes",
            "Split at Playhead", "Split All Layers at Playhead", "Copy Layer", "Paste Layer", "Duplicate Layer", "Move Layer Up", "Move Layer Down",
            if (overlay.guides) "Hide Guides" else "Show Guides", "Delete Layer", "Mask Group")
        val icons = arrayOf("layers", "check", "layers", "graph", "split", "split", "dup", "import", "dup", "chev_up", "chev_down", "dots", "trash", "mask")
        Dlg(this).setTitle("Layers").setIconItems(labels, icons) { _, w ->
            when (w) {
                0 -> selectAll()
                1 -> { multiMode = !multiMode; if (!multiMode) multi.clear(); render(); toast(if (multiMode) "Tap layers to select them" else "Multi select off") }
                2 -> groupSelected()
                3 -> timeline.expandAll()
                4 -> splitAtPlayhead(false)
                5 -> splitAtPlayhead(true)
                6 -> copySelected()
                7 -> pasteLayers()
                8 -> duplicateSelected()
                9 -> moveLayer(1)
                10 -> moveLayer(-1)
                11 -> { overlay.guides = !overlay.guides; overlay.invalidate() }
                13 -> groupSelected(true)
                else -> deleteLayer()
            }
        }.show()
    }

    // ---------------------------------------------------------------- expressions, audio, beats

    private fun showExpression(l: Layer, d: PropDef) {
        val tr = l.track(d.key)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(4), dp(4), dp(4))
        val sw = SwitchRow(this)
        sw.label = "fx  (expression)"
        sw.on = tr.exprOn && tr.exprSrc.isNotBlank()
        sw.captionOn = "On"; sw.captionOff = "Off"
        var swOn = sw.on
        sw.onToggle = { v -> swOn = v }
        put(box, sw, 52)
        text(box, "t = time, v = keyframed value. wiggle(freq, amp), sin, cos, abs, min, max, clamp, pow, sqrt, linear(t, a, b, c, d), noise, floor, round, mix, if(c, a, b), step(a, b), comparisons < > <= >= ==, pi, marker.key(\"name\").", C.DIM, 12f)
        val et = EditText(this)
        et.setText(tr.exprSrc)
        et.typeface = Typeface.MONOSPACE
        et.hint = "v + wiggle(3, 0.1)"
        box.addView(et)
        val presets = listOf("v + wiggle(3, 0.1)", "v * (1 + 0.2 * sin(t * 8))", "v + t * 90", "v + abs(sin(t * 4)) * 0.3", "")
        box.addView(chipRow(this, listOf("Wiggle", "Pulse", "Spin", "Bounce", "Clear"), -1) { i -> et.setText(presets[i]) })
        val names = Editor.scene.markerNames.values.toList().sorted()
        if (names.isNotEmpty()) {
            text(box, "Named markers (tap to insert)", C.DIM, 12f)
            box.addView(chipRow(this, names, -1) { i -> et.text.insert(et.selectionStart.coerceAtLeast(0), "marker.key(\"" + names[i] + "\")") })
        }
        Dlg(this).setTitle("Expression: " + d.label).setView(ScrollView(this).also { it.addView(box) }).setPositiveButton("Apply") { _, _ ->
            pushUndo()
            val src = et.text.toString()
            if (!tr.setExpr(src)) toast("Expression error") else { tr.exprOn = swOn && src.isNotBlank(); refreshPanel(); render() }
        }.setNegativeButton("Cancel", null).show()
    }

    private fun extractAudio(l: Layer) {
        val src = l.imagePath ?: return
        toast("Extracting audio...")
        Thread {
            try {
                val f = File(cacheDir, "audio_" + System.currentTimeMillis() + ".m4a")
                if (!AudioTools.extractAudio(src, f)) { runOnUiThread { toast("This video has no audio track") }; return@Thread }
                val v = ContentValues()
                v.put(MediaStore.Audio.Media.DISPLAY_NAME, l.name.substringBeforeLast('.') + ".m4a")
                v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                v.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/SaikiMotion")
                val u = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
                val mf = File(Projects.mediaDir(this), System.currentTimeMillis().toString() + "_" + l.name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9]"), "_") + ".m4a")
                f.copyTo(mf, true)
                f.delete()
                runOnUiThread { toast("Saved to Music/SaikiMotion and added as an audio layer"); addMedia(mf.absolutePath, LayerType.AUDIO) }
            } catch (e: Exception) { runOnUiThread { toast("Could not extract audio") } }
        }.start()
    }

    private fun beatsFrom(path: String, offset: Float) {
        toast("Analyzing beats...")
        Thread {
            try {
                val beats = AudioTools.detectBeats(path)
                runOnUiThread {
                    pushUndo()
                    val ms = Editor.scene.markers
                    var n = 0
                    for (b in beats) {
                        val t = offset + b
                        if (t <= Editor.scene.duration && ms.none { Math.abs(it - t) < 0.05f }) { ms.add(t); n++ }
                    }
                    render(); toast("Added " + n + " beat markers")
                }
            } catch (e: Exception) { runOnUiThread { toast("Could not analyze audio") } }
        }.start()
    }

    private fun snapKeys(l: Layer) {
        val ms = Editor.scene.markers
        for ((_, tr) in l.props) {
            var ch = false
            for (k in tr.keys) {
                val m = ms.minByOrNull { Math.abs(it - k.t) }
                if (m != null && Math.abs(m - k.t) < 0.35f) { k.t = m; ch = true }
            }
            if (ch) tr.keys.sortBy { it.t }
        }
        toast("Keyframes snapped to markers")
    }

    // ================================================================ importing

    private fun pickFile(req: Int, mime: String) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = mime
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(i, req)
    }

    private fun displayName(uri: android.net.Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "file"
            }
        } catch (e: Exception) { }
        return "file"
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == R_IDE) {
            Registry.reloadSdk(this)
            EffectThumbs.cache.keys.removeAll { k -> Registry.byId[k]?.builtin == false || k.startsWith("__orig:custom:") }
            EffectThumbs.generate(this, preview) { refreshPanel() }
            refreshPanel(); render()
            return
        }
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        if (req == R_FX || req == R_PRESET) {
            try {
                val txt = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                if (req == R_FX) {
                    val err = Registry.addCustom(this, txt)
                    if (err != null) toast(err) else { toast("Effect imported"); EffectThumbs.generate(this, preview) { refreshPanel() }; refreshPanel() }
                } else {
                    val o = JSONObject(txt)
                    o.getString("name")
                    Registry.savePreset(this, o)
                    toast("Preset imported"); refreshPanel()
                }
            } catch (e: Exception) { toast("Could not read file") }
            return
        }
        if (req == R_FONT) {
            val tl = selected() ?: return
            Thread {
                try {
                    val f = File(Projects.mediaDir(this), System.currentTimeMillis().toString() + "_font.ttf")
                    contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    runOnUiThread { pushUndo(); tl.fontPath = f.absolutePath; refreshPanel(); render() }
                } catch (e: Exception) { runOnUiThread { toast("Could not load the font") } }
            }.start()
            return
        }
        if (req == R_BEAT) {
            Thread {
                try {
                    val f = File(cacheDir, "beat_src")
                    contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    runOnUiThread { beatsFrom(f.absolutePath, 0f) }
                } catch (e: Exception) { runOnUiThread { toast("Could not read audio") } }
            }.start()
            return
        }
        val name = displayName(uri)
        toast("Importing...")
        Thread {
            try {
                val f = File(Projects.mediaDir(this), System.currentTimeMillis().toString() + "_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread { addMedia(f.absolutePath, when (req) { R_VIDEO -> LayerType.VIDEO; R_GLB -> LayerType.MODEL; R_AUDIOFILE -> LayerType.AUDIO; else -> LayerType.IMAGE }) }
            } catch (e: Exception) { runOnUiThread { toast("Import failed") } }
        }.start()
    }

    private fun addMedia(path: String, type: LayerType) {
        val l = addLayer(type)
        l.imagePath = path
        l.name = File(path).name.substringAfter('_')
        if (type == LayerType.VIDEO || type == LayerType.AUDIO) {
            try {
                val mr = MediaMetadataRetriever()
                mr.setDataSource(path)
                val ms = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                mr.release()
                l.srcDur = ms / 1000f
                val s = Editor.scene
                if (l.srcDur > 0.5f) s.duration = maxOf(s.duration, minOf(600f, l.start + l.srcDur))
                l.end = minOf(s.duration, l.start + l.srcDur.coerceAtLeast(0.5f))
            } catch (e: Exception) { }
        }
        refreshTitle(); refreshPanel(); render()
    }

    private fun exportText(name: String, content: String) {
        try {
            val v = ContentValues()
            v.put(MediaStore.Downloads.DISPLAY_NAME, name)
            v.put(MediaStore.Downloads.MIME_TYPE, "application/json")
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SaikiMotion")
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(content.toByteArray()) }
            toast("Saved to Downloads/SaikiMotion/$name")
        } catch (e: Exception) { toast("Export failed") }
    }

    // ================================================================ panels

    private fun refreshPanel() {
        panelList.removeAllViews()
        rows.clear()
        if (panel == P_NONE) return
        if (panel == P_MEDIA) buildMedia()
        else if (panel == P_SHAPES) buildShapes()
        else {
            val l = selected() ?: run { closePanel(); return }
            when (panel) {
                P_EDIT -> buildEdit(l)
                P_XFORM -> buildXform(l)
                P_FX -> buildFx(l)
                P_BLEND -> buildBlend(l)
                P_SPEED -> buildSpeed(l)
                P_GRAPH -> buildGraph(l)
            }
        }
        syncRows()
    }

    private fun addRow(parent: LinearLayout, l: Layer, d: PropDef, label: String = d.label) {
        if (d.options != null) { addOptionRow(parent, l, d); return }
        val tr = l.track(d.key)
        val s = RulerSlider(this)
        s.label = label; s.lo = d.min; s.hi = d.max; s.dec = d.dec
        s.infinite = d.inf; s.span = if (d.span > 0f) d.span else 1f
        s.onExprIcon = { showExpression(l, d) }
        s.value = tr.eval(l.editTime(d.key, Editor.time))
        s.onBegin = { pushUndo(); selKey = d.key; syncRows(s) }
        s.onChange = { v -> tr.set(l.editTime(d.key, Editor.time), v, autoKey); syncRows(s); render() }
        s.onLabelTap = { selKey = d.key; syncRows() }
        s.onLabelLong = { showExpression(l, d) }
        put(parent, s, 60)
        rows.add(Row(s, d, l))
    }

    private fun addOptionRow(parent: LinearLayout, l: Layer, d: PropDef) {
        val tr = l.track(d.key)
        val opts = d.options!!
        if (opts.size == 2) {
            val sw = SwitchRow(this)
            sw.label = d.label
            sw.on = tr.base >= 0.5f
            sw.captionOff = opts[0]; sw.captionOn = opts[1]
            sw.onToggle = { v -> pushUndo(); tr.keys.clear(); tr.base = if (v) 1f else 0f; render() }
            put(parent, sw, 52)
            return
        }
        text(parent, d.label, C.TEXT, 14f, true)
        parent.addView(chipRow(this, opts, tr.base.toInt()) { i -> pushUndo(); tr.keys.clear(); tr.base = i.toFloat(); refreshPanel(); render() })
    }

    private fun addPlain(parent: LinearLayout, label: String, lo: Float, hi: Float, v: Float, dec: Int, onChange: (Float) -> Unit) {
        val s = RulerSlider(this)
        s.label = label; s.lo = lo; s.hi = hi; s.value = v; s.dec = dec; s.canKey = false
        s.onBegin = { pushUndo() }
        s.onChange = onChange
        put(parent, s, 60)
    }

    private fun syncRows(except: RulerSlider? = null) {
        for (r in rows) {
            val tr = r.layer.track(r.d.key)
            val t = r.layer.editTime(r.d.key, Editor.time)
            if (r.slider !== except) r.slider.value = tr.eval(t)
            r.slider.hasKey = tr.keyAt(t) != null
            r.slider.hasAnim = tr.keys.isNotEmpty()
            r.slider.hasExpr = tr.exprActive()
            r.slider.rowSelected = r.d.key == selKey
            r.slider.invalidate()
        }
        diamondSide.set("diamond_f", if (rows.any { it.d.key == selKey && it.slider.hasKey }) C.GREEN else if (rows.any { it.d.key == selKey }) C.TEXT else C.DIM)
    }

    /** Adds or removes a keyframe on the parameter that was tapped last. */
    private fun keySelected() {
        val r = rows.firstOrNull { it.d.key == selKey }
        if (r == null) { toast("Tap a parameter first, then tap the keyframe button"); return }
        pushUndo()
        r.layer.track(r.d.key).toggleKey(r.layer.editTime(r.d.key, Editor.time))
        syncRows(); render()
    }

    /** Full color picker: saturation, hue, opacity, hex and an eyedropper that samples the preview. */
    private fun showColorPicker(initial: Int, onPick: (Int) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(4), dp(4), dp(4))
        val cp = ColorPickerView(this)
        cp.setColor(initial)
        box.addView(cp, LinearLayout.LayoutParams(MATCH, dp(250)))
        val row = hRow()
        row.setPadding(0, dp(10), 0, dp(6))
        val hex = EditText(this)
        hex.setText(hexOf(initial)); hex.typeface = Typeface.MONOSPACE; hex.setSingleLine(); hex.hint = "#RRGGBB"
        val sw = View(this)
        sw.setBackgroundColor(initial)
        var lock = false
        cp.onChange = { c ->
            sw.setBackgroundColor(c)
            lock = true; hex.setText(hexOf(c)); lock = false
            onPick(c)
        }
        hex.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (lock) return
                val v = parseHex(s?.toString() ?: "") ?: return
                cp.setColor(v); sw.setBackgroundColor(v); onPick(v)
            }
        })
        row.addView(hex, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(sw, LinearLayout.LayoutParams(dp(52), dp(40)))
        box.addView(row)
        var ref: Dlg? = null
        box.addView(pill("Pen: pick a color from the preview", "pipette") {
            ref?.dismiss()
            startEyedropper { c -> showColorPicker(c, onPick); onPick(c) }
        })
        pushUndo()
        ref = Dlg(this).setTitle("Color").setView(box).setPositiveButton("Done", null).show()
    }

    private fun startEyedropper(cb: (Int) -> Unit) {
        toast("Tap the preview to pick a color")
        overlay.pick = { x, y ->
            val w = preview.width
            val h = preview.height
            if (w > 0 && h > 0) {
                val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
                try {
                    android.view.PixelCopy.request(preview, bmp, { res ->
                        if (res == android.view.PixelCopy.SUCCESS) cb(bmp.getPixel(x.toInt().coerceIn(0, w - 1), y.toInt().coerceIn(0, h - 1)) or 0xFF000000.toInt())
                        else toast("Could not read the preview")
                    }, android.os.Handler(android.os.Looper.getMainLooper()))
                } catch (e: Exception) { toast("Eyedropper is not available here") }
            }
        }
    }

    private fun hexOf(c: Int): String =
        if (android.graphics.Color.alpha(c) == 255) String.format("#%06X", c and 0xFFFFFF) else String.format("#%06X%02X", c and 0xFFFFFF, android.graphics.Color.alpha(c))

    /** Accepts RGB, RRGGBB or RRGGBBAA with or without the leading #. */
    private fun parseHex(t0: String): Int? {
        val t = t0.trim().removePrefix("#")
        return try {
            when (t.length) {
                3 -> { val v = t.toLong(16); val r = (v shr 8) and 15; val g = (v shr 4) and 15; val b = v and 15; (0xFF000000L or (r * 17 shl 16) or (g * 17 shl 8) or (b * 17)).toInt() }
                6 -> (0xFF000000L or t.toLong(16)).toInt()
                8 -> { val v = t.toLong(16); (((v and 0xFF) shl 24) or (v ushr 8)).toInt() }
                else -> null
            }
        } catch (e: Exception) { null }
    }

    private fun colorRow(cur: Int = 0xFFFFFFFF.toInt(), onPick: (Int) -> Unit): View {
        val colors = intArrayOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFF44336.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(),
            0xFF22C55E.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFF7C4DFF.toInt(), 0xFFFF4081.toInt())
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val row = hRow()
        val now = View(this)
        now.setBackgroundColor(cur)
        val nlp = LinearLayout.LayoutParams(dp(44), dp(36))
        nlp.setMargins(dp(4), dp(6), dp(10), dp(6))
        now.setOnClickListener { showColorPicker(cur, onPick) }
        row.addView(now, nlp)
        for (col in colors) {
            val v = View(this)
            v.setBackgroundColor(col)
            v.setOnClickListener { onPick(col); refreshPanel() }
            val lp = LinearLayout.LayoutParams(dp(32), dp(32))
            lp.setMargins(dp(3), dp(6), dp(3), dp(6))
            row.addView(v, lp)
        }
        val more = View(this)
        val gd = android.graphics.drawable.GradientDrawable()
        gd.shape = android.graphics.drawable.GradientDrawable.OVAL
        gd.gradientType = android.graphics.drawable.GradientDrawable.SWEEP_GRADIENT
        gd.colors = intArrayOf(0xFFFF0000.toInt(), 0xFFFFFF00.toInt(), 0xFF00FF00.toInt(), 0xFF00FFFF.toInt(), 0xFF0000FF.toInt(), 0xFFFF00FF.toInt(), 0xFFFF0000.toInt())
        more.background = gd
        more.setOnClickListener { showColorPicker(cur, onPick) }
        val mlp = LinearLayout.LayoutParams(dp(36), dp(36))
        mlp.setMargins(dp(8), dp(4), dp(4), dp(4))
        row.addView(more, mlp)
        val sv = HorizontalScrollView(this)
        sv.addView(row)
        box.addView(sv)
        // Second row: pen (eyedropper) and a hex field.
        val r2 = hRow()
        r2.setPadding(dp(4), 0, dp(4), dp(4))
        val pen = IconView(this, "pipette", 0xFFFFFFFF.toInt(), 22f)
        pen.onClick = { startEyedropper { c -> onPick(c); refreshPanel() } }
        r2.addView(pen, LinearLayout.LayoutParams(dp(44), dp(44)))
        val hex = EditText(this)
        hex.setText(hexOf(cur))
        hex.typeface = Typeface.MONOSPACE
        hex.hint = "#RRGGBB"
        hex.setSingleLine()
        hex.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        val prev = View(this)
        prev.setBackgroundColor(cur)
        hex.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val v = parseHex(s?.toString() ?: "") ?: return
                if (v != cur) { prev.setBackgroundColor(v); onPick(v) }
            }
        })
        r2.addView(hex, LinearLayout.LayoutParams(0, WRAP, 1f))
        val plp = LinearLayout.LayoutParams(dp(44), dp(32))
        plp.setMargins(dp(8), 0, 0, 0)
        r2.addView(prev, plp)
        box.addView(r2)
        return box
    }

    private fun setColorParam(l: Layer, cp: ColorParam, col: Int) {
        val vals = listOf("_r" to android.graphics.Color.red(col), "_g" to android.graphics.Color.green(col), "_b" to android.graphics.Color.blue(col), "_a" to android.graphics.Color.alpha(col))
        for ((suffix, v) in vals) { val tr = l.track(cp.key + suffix); tr.keys.clear(); tr.base = v / 255f }
    }

    private fun addColorParam(parent: LinearLayout, l: Layer, cp: ColorParam) {
        fun cur(): Int = android.graphics.Color.argb((l.p(cp.key + "_a", 0f) * 255f).toInt(), (l.p(cp.key + "_r", 0f) * 255f).toInt(),
            (l.p(cp.key + "_g", 0f) * 255f).toInt(), (l.p(cp.key + "_b", 0f) * 255f).toInt())
        val row = hRow()
        row.setBackgroundColor(C.CARD)
        row.setPadding(dp(14), 0, dp(10), 0)
        val tv = TextView(this)
        tv.text = cp.label; tv.setTextColor(C.TEXT); tv.textSize = 15f; tv.typeface = Typeface.DEFAULT_BOLD
        row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = View(this)
        sw.setBackgroundColor(cur())
        sw.setOnClickListener { showColorPicker(cur()) { col -> setColorParam(l, cp, col); sw.setBackgroundColor(col); render() } }
        row.addView(sw, LinearLayout.LayoutParams(dp(72), dp(34)))
        put(parent, row, 52)
    }

    // ---------------------------------------------------------------- media + shapes

    private fun buildMedia() {
        val p = panelList
        text(p, "Media", C.TEXT, 16f, true)
        put(p, pill("Import video", "import") { pickFile(R_VIDEO, "video/*") }, 44)
        put(p, pill("Import image", "import") { pickFile(R_IMAGE, "image/*") }, 44)
        put(p, pill("Import audio", "import") { pickFile(R_AUDIOFILE, "audio/*") }, 44)
        put(p, pill("Import 3D model (.glb)", "import") { pickFile(R_GLB, "*/*") }, 44)
        put(p, pill("Beat markers from an audio file", "graph") { pickFile(R_BEAT, "audio/*") }, 44)
        val files = (Projects.mediaDir(this).listFiles() ?: emptyArray()).sortedByDescending { it.lastModified() }.take(12)
        if (files.isNotEmpty()) text(p, "Recent media", C.DIM, 13f)
        for (f in files) {
            val ext = f.extension.lowercase()
            val type = if (ext == "glb") LayerType.MODEL else if (ext in listOf("mp4", "mov", "mkv", "webm", "3gp", "m4v")) LayerType.VIDEO else if (ext in listOf("m4a", "mp3", "aac", "wav", "ogg", "flac")) LayerType.AUDIO else LayerType.IMAGE
            put(p, pill(f.name.substringAfter('_'), if (type == LayerType.VIDEO) "media" else if (type == LayerType.MODEL) "cube" else "media") {
                addMedia(f.absolutePath, type)
            }, 40)
        }
    }

    private fun buildShapes() {
        text(panelList, "Add shape", C.TEXT, 16f, true)
        val names = ShapeKind.values().map { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }
        panelList.addView(chipRow(this, names, -1) { i ->
            val l = addLayer(LayerType.SHAPE)
            l.shape = ShapeKind.values()[i]
            render()
        })
    }

    // ---------------------------------------------------------------- edit

    private fun buildEdit(l: Layer) {
        val p = panelList
        when (l.type) {
            LayerType.TEXT -> buildText(p, l)
            LayerType.SHAPE -> {
                text(p, "Shape", C.TEXT, 16f, true)
                val names = ShapeKind.values().map { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }
                p.addView(chipRow(this, names, l.shape.ordinal) { i -> pushUndo(); l.shape = ShapeKind.values()[i]; refreshPanel(); render() })
                text(p, "Color", C.DIM)
                p.addView(colorRow(l.color) { c -> pushUndo(); l.color = c; render() })
            }
            LayerType.GROUP -> {
                text(p, "Group", C.TEXT, 16f, true)
                text(p, "Put layers inside with Parent in their Transform panel. Tap the ^ arrow in the timeline to open or close the group. Groups can have effects, and 3D layers inside a group keep their 3D look.", C.DIM, 12f)
                text(p, "Mask", C.TEXT, 15f, true)
                text(p, "The top layer in the group is the mask. It cuts out the layers beneath it.", C.DIM, 12f)
                val isOn = l.mask != 0
                val isLuma = l.mask >= 3
                val isInv = l.mask == 2 || l.mask == 4
                fun setMask(on: Boolean, luma: Boolean, inv: Boolean) {
                    pushUndo()
                    l.mask = if (!on) 0 else (if (luma) 3 else 1) + (if (inv) 1 else 0)
                    refreshPanel(); render()
                }
                val mrow = hRow()
                fun toggle(icon: String, label: String, on: Boolean, click: () -> Unit) {
                    val b = LinearLayout(this)
                    b.orientation = LinearLayout.VERTICAL
                    b.gravity = android.view.Gravity.CENTER
                    val bg = android.graphics.drawable.GradientDrawable()
                    bg.setColor(if (on) 0xFF2E2E36.toInt() else C.CARD2)
                    bg.cornerRadius = dp(14).toFloat()
                    if (on) bg.setStroke(dp(2), 0xFFFFFFFF.toInt())
                    b.background = bg
                    val iv = IconView(this, icon, 0xFFFFFFFF.toInt(), 24f)
                    iv.isClickable = false
                    b.addView(iv, LinearLayout.LayoutParams(dp(36), dp(34)))
                    val tv = TextView(this)
                    tv.text = label; tv.setTextColor(0xFFFFFFFF.toInt()); tv.textSize = 12f
                    tv.gravity = android.view.Gravity.CENTER
                    b.addView(tv, LinearLayout.LayoutParams(WRAP, WRAP))
                    b.setOnClickListener { click() }
                    val lp = LinearLayout.LayoutParams(0, dp(72), 1f)
                    lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                    mrow.addView(b, lp)
                }
                toggle("mask", "Mask", isOn) { setMask(!isOn, isLuma, isInv) }
                toggle("mask_invert", "Invert", isInv) { setMask(true, isLuma, !isInv) }
                put(p, mrow)
                text(p, "Mask type", C.DIM, 12f)
                p.addView(chipRow(this, listOf("Alpha", "Luma"), if (isLuma) 1 else 0) { i -> setMask(true, i == 1, isInv) })
                if (!isOn) text(p, "Mask is off. Tap Mask to turn the top layer into a mask.", C.DIM, 12f)
            }
            LayerType.AUDIO -> {
                text(p, "Audio", C.TEXT, 16f, true); text(p, l.name)
                addRow(p, l, Defs.audio[0])
                put(p, pill("Beat markers from this audio", "graph") { beatsFrom(l.imagePath ?: "", l.start) }, 42)
                text(p, "Plays during preview and is mixed into the render (the first audio layer; AAC or MP3 files work best).", C.DIM, 12f)
            }
            LayerType.ADJUST -> { text(p, "Adjustment layer", C.TEXT, 16f, true); text(p, "Add effects to it in the Effects panel. They apply to everything below it for as long as the layer lasts.") }
            LayerType.CAMERA -> { text(p, "Camera", C.TEXT, 16f, true); addRow(p, l, Defs.camera[0]); text(p, "Position and rotate it in Transform. It controls every layer whose 3D cube is on.") }
            LayerType.NULL -> { text(p, "Null object", C.TEXT, 16f, true); text(p, "An invisible layer. Turn its 3D cube on, then pick it as Parent in other layers' Transform panel.") }
            else -> {
                text(p, l.type.name.lowercase().replaceFirstChar { it.uppercase() }, C.TEXT, 16f, true)
                text(p, l.name)
                if (l.type == LayerType.VIDEO) {
                    text(p, "Length: " + String.format("%.1f", l.srcDur) + " s. Decoded with the system decoder.")
                    put(p, pill("Extract audio", "export") { extractAudio(l) }, 42)
                    put(p, pill("Beat markers from this video", "graph") { beatsFrom(l.imagePath ?: "", l.start) }, 42)
                }
                if (l.type == LayerType.MODEL) text(p, "Static .glb mesh. Transforms are baked on load and everything is drawn from one GPU buffer per part.")
            }
        }
    }

    private fun buildText(p: LinearLayout, l: Layer) {
        text(p, "Text", C.TEXT, 16f, true)
        p.addView(chipRow(this, listOf("Text", "Style", "Animate"), textTab) { textTab = it; refreshPanel() })
        when (textTab) {
            0 -> {
                val et = EditText(this)
                et.setText(l.text)
                et.setTextColor(C.TEXT)
                et.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                et.minLines = 2
                et.gravity = android.view.Gravity.TOP
                et.addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: android.text.Editable?) { l.text = s?.toString() ?: ""; render() }
                })
                put(p, et)
                text(p, "Alignment", C.GREEN, 13f, true)
                p.addView(chipRow(this, listOf("Left", "Center", "Right"), l.align) { i -> pushUndo(); l.align = i; render() })
                text(p, "Letter case", C.GREEN, 13f, true)
                p.addView(chipRow(this, listOf("As typed", "UPPER", "lower"), l.caps) { i -> pushUndo(); l.caps = i; render() })
                val sb = SwitchRow(this)
                sb.label = "Bold"; sb.on = l.bold; sb.onToggle = { v -> pushUndo(); l.bold = v; render() }
                put(p, sb, 52)
                val si = SwitchRow(this)
                si.label = "Italic"; si.on = l.italic; si.onToggle = { v -> pushUndo(); l.italic = v; render() }
                put(p, si, 52)
                val su = SwitchRow(this)
                su.label = "Underline"; su.on = l.underline; su.onToggle = { v -> pushUndo(); l.underline = v; render() }
                put(p, su, 52)
                val ss = SwitchRow(this)
                ss.label = "Strikethrough"; ss.on = l.strike; ss.onToggle = { v -> pushUndo(); l.strike = v; render() }
                put(p, ss, 52)
                addRow(p, l, Defs.text[4])
                text(p, "Font", C.GREEN, 13f, true)
                val fams = listOf("sans-serif", "serif", "monospace", "cursive", "casual", "sans-serif-condensed", "sans-serif-light", "sans-serif-medium", "sans-serif-black", "serif-monospace")
                val names = listOf("Sans", "Serif", "Mono", "Cursive", "Casual", "Condensed", "Light", "Medium", "Black", "Typewriter")
                p.addView(chipRow(this, names, if (l.fontPath != null) -1 else fams.indexOf(l.font)) { i -> pushUndo(); l.font = fams[i]; l.fontPath = null; refreshPanel(); render() })
                put(p, pill(if (l.fontPath != null) "Custom font loaded. Import another" else "Import a font file (.ttf or .otf)", "import") { pickFile(R_FONT, "*/*") }, 42)
                text(p, "Color", C.GREEN, 13f, true)
                p.addView(colorRow(l.color) { c -> pushUndo(); l.color = c; render() })
                addRow(p, l, Defs.transform[2], "Size")
            }
            1 -> {
                text(p, "Stroke", C.GREEN, 13f, true)
                addRow(p, l, Defs.text[0])
                p.addView(colorRow(l.strokeColor) { c -> pushUndo(); l.strokeColor = c; render() })
                text(p, "Stroke position", C.DIM, 12f)
                p.addView(chipRow(this, listOf("Outside", "Center", "Inside"), l.strokePos) { i -> pushUndo(); l.strokePos = i; render() })
                text(p, "Corners", C.DIM, 12f)
                p.addView(chipRow(this, listOf("Round", "Sharp"), l.strokeJoin) { i -> pushUndo(); l.strokeJoin = i; render() })
                text(p, "Second stroke (outside the first)", C.GREEN, 13f, true)
                addRow(p, l, Defs.text[8])
                p.addView(colorRow(l.stroke2Color) { c -> pushUndo(); l.stroke2Color = c; render() })
                text(p, "Border box", C.GREEN, 13f, true)
                addRow(p, l, Defs.text[1])
                addRow(p, l, Defs.text[2])
                addRow(p, l, Defs.text[9])
                p.addView(colorRow(l.borderColor) { c -> pushUndo(); l.borderColor = c; render() })
                val bd = SwitchRow(this)
                bd.label = "Dashed border"; bd.on = l.borderDash; bd.onToggle = { v -> pushUndo(); l.borderDash = v; render() }
                put(p, bd, 52)
                text(p, "Box fill", C.DIM, 12f)
                p.addView(colorRow(if (android.graphics.Color.alpha(l.borderFill) == 0) 0xFF000000.toInt() else l.borderFill) { c -> pushUndo(); l.borderFill = c; render() })
                put(p, pill("No box fill", "close") { pushUndo(); l.borderFill = 0; refreshPanel(); render() }, 40)
                text(p, "Shadow", C.GREEN, 13f, true)
                val sh = SwitchRow(this)
                sh.label = "Shadow"; sh.on = l.shadowOn; sh.onToggle = { v -> pushUndo(); l.shadowOn = v; refreshPanel(); render() }
                put(p, sh, 52)
                if (l.shadowOn) {
                    p.addView(colorRow(l.shadowColor) { c -> pushUndo(); l.shadowColor = c; render() })
                    addRow(p, l, Defs.text[5])
                    addRow(p, l, Defs.text[6])
                    addRow(p, l, Defs.text[7])
                }
                text(p, "Spacing", C.GREEN, 13f, true)
                addRow(p, l, Defs.text[3])
            }
            else -> buildTextAnim(p, l)
        }
    }

    private fun buildTextAnim(p: LinearLayout, l: Layer) {
        put(p, pill("Add animation", "plus", C.GREEN, 0xFF2B1400.toInt()) {
            Dlg(this).setTitle("Add animation").setItems(TextAnim.TYPES.toTypedArray()) { _, w ->
                pushUndo()
                val a = TextAnim(w, if (w == 8 || w == 10) 2 else 0)
                if (w == 5) a.scaleFrom = 0f
                if (w == 6) a.rotFrom = 90f
                l.anims.add(a)
                expanded.add("anim:" + l.id + ":" + (l.anims.size - 1))
                refreshPanel(); render()
            }.show()
        }, 46)
        if (l.anims.isEmpty()) text(p, "Animations play per letter. Stack several, for example Slide up in plus Fade out. Outline draw animates the stroke from the Style tab.", C.DIM, 12f)
        for ((i, a) in l.anims.withIndex()) {
            val key = "anim:" + l.id + ":" + i
            val open = expanded.contains(key)
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            val bar = hRow()
            bar.setBackgroundColor(C.CARD)
            bar.setPadding(dp(14), 0, dp(2), 0)
            val tv = TextView(this)
            tv.text = a.name(); tv.setTextColor(C.TEXT); tv.textSize = 16f; tv.typeface = Typeface.DEFAULT_BOLD
            bar.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            val chev = IconView(this, if (open) "chev_up" else "chev_down", C.DIM, 20f)
            chev.onClick = { if (!expanded.remove(key)) expanded.add(key); refreshPanel() }
            bar.addView(chev, LinearLayout.LayoutParams(dp(40), dp(48)))
            val del = IconView(this, "trash", C.RED, 20f)
            del.onClick = { pushUndo(); l.anims.remove(a); refreshPanel(); render() }
            bar.addView(del, LinearLayout.LayoutParams(dp(40), dp(48)))
            card.addView(bar)
            if (open) {
                card.addView(chipRow(this, listOf("In", "Out", "Loop"), a.mode) { m -> pushUndo(); a.mode = m; refreshPanel(); render() })
                addPlain(card, "Start (s)", 0f, 10f, a.start, 2) { a.start = it; render() }
                addPlain(card, "Duration (s)", 0.05f, 5f, a.dur, 2) { a.dur = it; render() }
                addPlain(card, "Delay per letter (s)", 0f, 0.5f, a.stagger, 2) { a.stagger = it; render() }
                addPlain(card, "Distance", 0f, 3f, a.distance, 2) { a.distance = it; render() }
                addPlain(card, "Scale from", 0f, 3f, a.scaleFrom, 2) { a.scaleFrom = it; render() }
                addPlain(card, "Rotate from (deg)", -360f, 360f, a.rotFrom, 0) { a.rotFrom = it; render() }
                addPlain(card, "Speed (loops)", 0f, 10f, a.speed, 1) { a.speed = it; render() }
                text(card, "Easing", C.DIM, 12f)
                card.addView(chipRow(this, listOf("Linear", "Ease out", "Ease in-out", "Bounce", "Custom curve"), a.ease) { e -> pushUndo(); a.ease = e; if (e == 4) a.curve.ease = Ease.CUSTOM; refreshPanel(); render() })
                if (a.ease == 4) {
                    val gv = GraphView(this)
                    gv.key = a.curve
                    gv.onBegin = { pushUndo() }
                    gv.onChange = { render() }
                    put(card, gv, 200)
                }
                val sf = SwitchRow(this)
                sf.label = "Fade while moving"; sf.on = a.fade; sf.onToggle = { v -> pushUndo(); a.fade = v; render() }
                put(card, sf, 52)
            }
            put(p, card, 0, 3, 6)
        }
    }

    // ---------------------------------------------------------------- transform

    private fun buildXform(l: Layer) {
        val p = panelList
        p.addView(TabBar(this, listOf("Attributes", "Anchor & Align"), xformTab) { xformTab = it; refreshPanel() }, LinearLayout.LayoutParams(MATCH, dp(44)))
        if (xformTab == 1) { buildAnchorAlign(l); return }
        val threeD = l.is3d || l.type == LayerType.MODEL || l.type == LayerType.CAMERA
        val s3 = SwitchRow(this)
        s3.label = "3D layer"; s3.on = threeD
        s3.onToggle = { _ -> toggle3d() }
        put(p, s3, 52)
        if (l.type == LayerType.NULL && !l.is3d) text(p, "This Null is 2D, so it will not move other layers. Turn 3D on.", C.AMBER)
        groupHeader(p, "Position") { showPositionMenu(l, threeD) }
        if (moveMode || !sepDims) addMovePad(p, l)
        if (sepDims) { addRow(p, l, Defs.transform[0]); addRow(p, l, Defs.transform[1]) }
        if (threeD) addRow(p, l, Defs.pos3d[0])
        if (l.type != LayerType.CAMERA) {
            val sh = hRow()
            val stt = TextView(this)
            stt.text = "Scale"; stt.setTextColor(C.TEXT); stt.textSize = 15f; stt.typeface = Typeface.DEFAULT_BOLD
            sh.addView(stt, LinearLayout.LayoutParams(0, WRAP, 1f))
            val chain = IconView(this, if (scaleLinked) "link" else "unlink", 0xFFFFFFFF.toInt(), 22f)
            chain.onClick = { scaleLinked = !scaleLinked; refreshPanel() }
            sh.addView(chain, LinearLayout.LayoutParams(dp(44), dp(40)))
            val sm = IconView(this, "more", C.TEXT, 20f)
            sm.onClick = { showParamMenu(l, "Scale", listOf(Defs.transform[2], Defs.scaleXY[0], Defs.scaleXY[1])) }
            sh.addView(sm, LinearLayout.LayoutParams(dp(44), dp(40)))
            put(p, sh, 0, 4, 0)
            addRow(p, l, Defs.transform[2], if (scaleLinked) "Scale (X and Y together)" else "Scale (all)")
            if (!scaleLinked) {
                addRow(p, l, Defs.scaleXY[0])
                addRow(p, l, Defs.scaleXY[1])
            } else {
                val lt0 = l.editTime("scaleX", Editor.time)
                if (Math.abs(l.p("scaleX", lt0) - 1f) > 0.001f || Math.abs(l.p("scaleY", lt0) - 1f) > 0.001f) text(p, "X and Y are stretched separately. Tap the chain to edit them.", C.DIM, 12f)
            }
        }
        val rotDefs = if (threeD) listOf(Defs.transform[4], Defs.rot3d[0], Defs.rot3d[1]) else listOf(Defs.transform[4])
        groupHeader(p, "Rotation") { showParamMenu(l, "Rotation", rotDefs) }
        for (d in rotDefs) addRow(p, l, d)
        if (l.isRenderable() || l.type == LayerType.GROUP) {
            groupHeader(p, "Opacity") { showParamMenu(l, "Opacity", listOf(Defs.transform[3])) }
            addRow(p, l, Defs.transform[3])
        }
        val b = hRow()
        for (axis in arrayOf("rotX", "rotY", "rotZ")) {
            if (!threeD && axis != "rotZ") continue
            b.addView(pill("Spin " + axis.last()) { spin(l, axis) }, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        put(p, b)
    }

    private fun groupHeader(p: LinearLayout, title: String, onMenu: () -> Unit) {
        val h = hRow()
        val t = TextView(this)
        t.text = title; t.setTextColor(C.TEXT); t.textSize = 15f; t.typeface = Typeface.DEFAULT_BOLD
        h.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        val m = IconView(this, "more", C.TEXT, 20f)
        m.onClick = { onMenu() }
        h.addView(m, LinearLayout.LayoutParams(dp(44), dp(40)))
        put(p, h, 0, 4, 0)
    }

    /** The three-dot menu used by Scale, Rotation and Opacity. */
    private fun showParamMenu(l: Layer, title: String, defs: List<PropDef>) {
        val labels = arrayOf("Reset to default", "Clear keyframes (keep current value)", "Expression...")
        val icons = arrayOf("adjust", "close", "box")
        Dlg(this).setTitle(title).setIconItems(labels, icons) { _, w ->
            when (w) {
                0 -> {
                    pushUndo()
                    for (d in defs) { val tr = l.track(d.key); tr.keys.clear(); tr.base = d.def; tr.setExpr(""); tr.exprOn = false }
                    refreshPanel(); render()
                }
                1 -> {
                    pushUndo()
                    for (d in defs) { val tr = l.track(d.key); val v = tr.eval(l.editTime(d.key, Editor.time)); tr.keys.clear(); tr.base = v }
                    refreshPanel(); render()
                }
                2 -> {
                    if (defs.size == 1) showExpression(l, defs[0])
                    else Dlg(this).setTitle("Expression for").setItems(defs.map { it.label }.toTypedArray()) { _, i -> showExpression(l, defs[i]) }.show()
                }
            }
        }.show()
    }

    private fun addMovePad(p: LinearLayout, l: Layer) {
        val pad = MovePadView(this)
        val t0 = l.editTime("x", Editor.time)
        pad.px = l.track("x").eval(t0); pad.py = l.track("y").eval(t0)
        pad.onBegin = { pushUndo() }
        pad.onMove = { dx, dy ->
            val t = l.editTime("x", Editor.time)
            val nx = l.track("x").eval(t) + dx
            val ny = l.track("y").eval(t) + dy
            l.track("x").set(t, nx, autoKey); l.track("y").set(t, ny, autoKey)
            pad.px = nx; pad.py = ny; pad.invalidate()
            syncRows(); render()
        }
        put(p, pad, 150)
    }

    private fun showPositionMenu(l: Layer, threeD: Boolean) {
        val labels = arrayOf(
            "Separate dimensions  (" + (if (sepDims) "on" else "off") + ")",
            "Move mode  (" + (if (moveMode) "on" else "off") + ")",
            "Reset to default",
            "Expression...")
        val icons = arrayOf("grid", "move", "adjust", "box")
        Dlg(this).setTitle("Position").setIconItems(labels, icons) { _, w ->
            when (w) {
                0 -> { sepDims = !sepDims; refreshPanel() }
                1 -> { moveMode = !moveMode; refreshPanel() }
                2 -> {
                    pushUndo()
                    for (k in listOf("x", "y", "z")) { val tr = l.track(k); tr.keys.clear(); tr.base = 0f; tr.setExpr(""); tr.exprOn = false }
                    refreshPanel(); render()
                }
                3 -> {
                    val names = if (threeD) arrayOf("Position X", "Position Y", "Position Z") else arrayOf("Position X", "Position Y")
                    Dlg(this).setTitle("Expression for").setItems(names) { _, i ->
                        showExpression(l, if (i == 2) Defs.pos3d[0] else Defs.transform[i])
                    }.show()
                }
            }
        }.show()
    }

    // ---------------------------------------------------------------- anchor + align

    private fun buildAnchorAlign(l: Layer) {
        val p = panelList
        text(p, "Anchor", C.TEXT, 15f, true)
        addRow(p, l, Defs.anchor[0]); addRow(p, l, Defs.anchor[1])
        val lt = l.editTime("anchorX", Editor.time)
        val ax = l.p("anchorX", lt)
        val ay = l.p("anchorY", lt)
        text(p, "Preset Anchor", C.TEXT, 15f, true)
        val g = GridPick(this)
        g.sel = (0..8).firstOrNull { Math.abs((it % 3) * 50f - ax) < 0.5f && Math.abs((it / 3) * 50f - ay) < 0.5f } ?: -1
        g.onPick = { i -> pushUndo(); setAnchorKeepVisual(l, (i % 3) * 50f, (i / 3) * 50f); refreshPanel(); render() }
        put(p, g, 128)
        text(p, "Align to Canvas", C.TEXT, 15f, true)
        val rows = listOf(listOf("align_l", "align_hc", "align_r"), listOf("align_t", "align_vc", "align_b"))
        for ((ri, row) in rows.withIndex()) {
            val h = hRow()
            for ((ci, ic) in row.withIndex()) {
                val b = IconView(this, ic, C.TEXT, 24f)
                b.setBackgroundColor(C.CARD)
                b.onClick = { pushUndo(); alignToCanvas(l, ri * 3 + ci); refreshPanel(); render() }
                val lp = LinearLayout.LayoutParams(0, dp(52), 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                h.addView(b, lp)
            }
            put(p, h)
        }
        text(p, "Align uses the layer's size and rotation. Choosing a preset anchor keeps the layer where it is.", C.DIM, 12f)
    }

    /** Offset of the layer centre from its position, in world units, for the current anchor, scale and rotation. */
    private fun anchorOffset(l: Layer, lt: Float, ax: Float, ay: Float): Pair<Float, Float> {
        val (qw, qh) = Xf.quadSize(l)
        val sc = l.p("scale", lt)
        val ox = -(ax - 50f) / 100f * qw * sc * l.p("scaleX", lt)
        val oy = (ay - 50f) / 100f * qh * sc * l.p("scaleY", lt)
        val a = Math.toRadians(l.p("rotZ", lt).toDouble())
        val c = Math.cos(a).toFloat(); val sn = Math.sin(a).toFloat()
        return Pair(ox * c - oy * sn, ox * sn + oy * c)
    }

    private fun setAnchorKeepVisual(l: Layer, nx: Float, ny: Float) {
        val t = l.editTime("anchorX", Editor.time)
        val oa = anchorOffset(l, t, l.p("anchorX", t), l.p("anchorY", t))
        val na = anchorOffset(l, t, nx, ny)
        l.track("x").set(t, l.p("x", t) + oa.first - na.first, autoKey)
        l.track("y").set(t, l.p("y", t) + oa.second - na.second, autoKey)
        l.track("anchorX").set(t, nx, autoKey); l.track("anchorY").set(t, ny, autoKey)
    }

    /** which: 0 left, 1 h-centre, 2 right, 3 top, 4 v-centre, 5 bottom. */
    private fun alignToCanvas(l: Layer, which: Int) {
        val t = l.editTime("x", Editor.time)
        val (qw, qh) = Xf.quadSize(l)
        val sc = Math.abs(l.p("scale", t))
        val hw = qw * sc * Math.abs(l.p("scaleX", t)) / 2f
        val hh = qh * sc * Math.abs(l.p("scaleY", t)) / 2f
        val a = Math.toRadians(l.p("rotZ", t).toDouble())
        val c = Math.abs(Math.cos(a)).toFloat(); val sn = Math.abs(Math.sin(a)).toFloat()
        val bw = c * hw + sn * hh
        val bh = sn * hw + c * hh
        val W = Editor.project.w.toFloat() / Editor.project.h.toFloat()
        val off = anchorOffset(l, t, l.p("anchorX", t), l.p("anchorY", t))
        when (which) {
            0 -> l.track("x").set(t, -W + bw - off.first, autoKey)
            1 -> l.track("x").set(t, -off.first, autoKey)
            2 -> l.track("x").set(t, W - bw - off.first, autoKey)
            3 -> l.track("y").set(t, 1f - bh - off.second, autoKey)
            4 -> l.track("y").set(t, -off.second, autoKey)
            5 -> l.track("y").set(t, -1f + bh - off.second, autoKey)
        }
    }

    // ---------------------------------------------------------------- parent popup + motion blur settings

    private fun typeIcon(t: LayerType): String = when (t) {
        LayerType.SHAPE -> "shape"; LayerType.TEXT -> "text"; LayerType.IMAGE, LayerType.VIDEO -> "media"
        LayerType.CAMERA -> "camera"; LayerType.NULL -> "nullobj"; LayerType.MODEL -> "cube"
        LayerType.PARTICLES -> "particles"; LayerType.GROUP -> "layers"; LayerType.ADJUST -> "adjust"; LayerType.AUDIO -> "audio"
    }

    private fun showParentPopup(l: Layer, anchor: View) {
        val cands = Editor.scene.layers.filter { it.id != l.id && !isDescendant(it, l) }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(8), dp(8), dp(8), dp(8))
        val bg = android.graphics.drawable.GradientDrawable()
        bg.setColor(C.CARD); bg.cornerRadius = dp(16).toFloat(); bg.setStroke(dp(1), 0xFF3A3A42.toInt())
        col.background = bg
        val sv = ScrollView(this)
        sv.addView(col)
        val pw = android.widget.PopupWindow(sv, dp(240), WRAP, true)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0))
        pw.elevation = dp(10).toFloat()
        fun item(icon: String, name: String, on: Boolean, pick: () -> Unit) {
            val row = hRow()
            row.setPadding(dp(10), 0, dp(10), 0)
            val rb = android.graphics.drawable.GradientDrawable()
            rb.setColor(0xFF2A2A30.toInt()); rb.cornerRadius = dp(12).toFloat()
            if (on) rb.setStroke(dp(2), C.GREEN)
            row.background = rb
            row.addView(IconView(this, icon, if (on) C.GREEN else C.TEXT, 20f), LinearLayout.LayoutParams(dp(32), dp(44)))
            val tv = TextView(this)
            tv.text = name; tv.setTextColor(C.TEXT); tv.textSize = 15f; tv.maxLines = 1
            tv.setPadding(dp(8), 0, 0, 0)
            row.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.setOnClickListener { pick(); pw.dismiss() }
            val lp = LinearLayout.LayoutParams(MATCH, dp(46))
            lp.setMargins(0, dp(3), 0, dp(3))
            col.addView(row, lp)
        }
        item("close", "None", l.parentId < 0) { pushUndo(); l.parentId = -1; refreshTitle(); refreshPanel(); render() }
        for (c in cands) item(typeIcon(c.type), c.name, l.parentId == c.id) { pushUndo(); l.parentId = c.id; refreshTitle(); refreshPanel(); render() }
        col.measure(View.MeasureSpec.makeMeasureSpec(dp(240), View.MeasureSpec.EXACTLY), View.MeasureSpec.UNSPECIFIED)
        pw.height = Math.min(col.measuredHeight, (resources.displayMetrics.heightPixels * 0.6f).toInt())
        pw.showAsDropDown(anchor, -dp(190), 0)
    }

    private fun isDescendant(c: Layer, of: Layer): Boolean {
        var cur: Layer? = c
        var guard = 0
        while (cur != null && guard++ < 64) {
            if (cur.parentId == of.id) return true
            val pid = cur.parentId
            cur = Editor.scene.layers.firstOrNull { it.id == pid }
        }
        return false
    }

    private fun showMotionBlurSettings(l: Layer) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(4), dp(4), dp(4))
        val on = SwitchRow(this)
        on.label = "Motion blur"; on.on = l.mblur
        on.onToggle = { v -> pushUndo(); l.mblur = v; mbToggle.on = v; render() }
        put(box, on, 52)
        val stut = SwitchRow(this)
        stut.label = "Stuttering"; stut.on = l.mbStutter
        stut.onToggle = { v -> pushUndo(); l.mbStutter = v; render() }
        put(box, stut, 52)
        val rgb = SwitchRow(this)
        rgb.label = "Enable RGB sampling"; rgb.on = l.mbRgb
        rgb.onToggle = { v -> pushUndo(); l.mbRgb = v; render() }
        put(box, rgb, 52)
        text(box, "Quality", C.DIM, 13f)
        val smp = l.track("mbSamples")
        val q = if (smp.base <= 5f) 0 else if (smp.base <= 10f) 1 else 2
        box.addView(chipRow(this, listOf("Low", "Medium", "High"), q) { i -> pushUndo(); smp.keys.clear(); smp.base = floatArrayOf(4f, 8f, 16f)[i]; render() })
        val amt = l.track("mbAmount")
        addPlain(box, "Blur strength", 0f, 4f, amt.base, 2) { v -> amt.keys.clear(); amt.base = v; render() }
        if (l.type == LayerType.CAMERA) text(box, "Camera motion blur: every 3D layer below this camera is blurred by the camera's movement.", C.DIM, 12f)
        text(box, "Stuttering snaps the blur samples to whole frames. RGB sampling gives the trails a red-to-blue fringe.", C.DIM, 12f)
        Dlg(this).setTitle("Motion blur").setView(ScrollView(this).also { it.addView(box) }).setPositiveButton("Done", null).show()
    }

    private fun spin(l: Layer, key: String) {
        pushUndo()
        val tr = l.track(key)
        tr.keys.clear()
        tr.keys.add(Key(l.start, 0f, Ease.LINEAR)); tr.keys.add(Key(l.end, 360f, Ease.LINEAR))
        refreshPanel(); render()
    }

    private fun showParentDialog(l: Layer) {
        val cands = Editor.scene.layers.filter { it.id != l.id && it.parentId != l.id }
        val names = arrayOf("None") + cands.map { it.name + when (it.type) { LayerType.NULL -> " (Null)"; LayerType.GROUP -> " (Group)"; else -> "" } }
        Dlg(this).setTitle("Parent").setItems(names) { _, w ->
            pushUndo()
            l.parentId = if (w == 0) -1 else cands[w - 1].id
            refreshPanel(); render()
        }.show()
    }

    // ---------------------------------------------------------------- blending + speed

    private fun buildBlend(l: Layer) {
        val p = panelList
        text(p, "Blending", C.TEXT, 16f, true)
        addRow(p, l, Defs.transform[3])
        text(p, "Blend mode", C.DIM)
        p.addView(chipRow(this, listOf("Normal", "Add", "Screen", "Multiply"), l.blend) { i -> pushUndo(); l.blend = i; refreshPanel(); render() })
        val mb = SwitchRow(this)
        mb.label = "Motion blur"; mb.on = l.mblur
        mb.onToggle = { v -> pushUndo(); l.mblur = v; refreshPanel(); render() }
        put(p, mb, 52)
        if (l.mblur) {
            addRow(p, l, Defs.blur[0]); addRow(p, l, Defs.blur[1])
            text(p, "Works with particles and every moving or animated layer. More samples is smoother but slower. Video layers are not blurred.", C.DIM, 12f)
        }
    }

    private fun ensureRemap(l: Layer) {
        if (!l.fx.contains("remap")) l.fx.add("remap")
        l.fxOff.remove("remap")
    }

    /** Creates the two identity Time Remap keyframes when none exist yet. */
    private fun ensureRemapKeys(l: Layer) {
        ensureRemap(l)
        val tr = l.track("remapT")
        if (tr.keys.isNotEmpty()) return
        val sp = l.track("remapSpeed").base
        tr.keys.add(Key(l.start, 0f, Ease.LINEAR))
        tr.keys.add(Key(l.end, (l.end - l.start) * sp, Ease.LINEAR))
    }

    /** Holds the current source frame for one second, pushing later keyframes back. */
    private fun freezeFrame(l: Layer) {
        ensureRemapKeys(l)
        val tr = l.track("remapT")
        val t = Editor.time
        val v = tr.eval(t)
        val hold = 1f
        for (k in tr.keys) if (k.t > t + 0.001f) k.t += hold
        if (tr.keys.none { Math.abs(it.t - t) < 0.001f }) tr.keys.add(Key(t, v, Ease.LINEAR))
        tr.keys.add(Key(t + hold, v, Ease.LINEAR))
        tr.keys.sortBy { it.t }
    }

    /** Plays the layer backwards: the end of the source at the start, the start at the end. */
    private fun reverseRemap(l: Layer) {
        ensureRemap(l)
        val tr = l.track("remapT")
        tr.keys.clear()
        tr.keys.add(Key(l.start, l.end - l.start, Ease.LINEAR))
        tr.keys.add(Key(l.end, 0f, Ease.LINEAR))
    }

    private fun buildSpeed(l: Layer) {
        val p = panelList
        val hasMap = l.props["remapT"]?.keys?.isNotEmpty() == true
        val spd = l.speedAt(Editor.time)
        val head = hRow()
        val ht = TextView(this)
        ht.text = "Playback Speed"; ht.setTextColor(C.TEXT); ht.textSize = 16f; ht.typeface = Typeface.DEFAULT_BOLD
        head.addView(ht, LinearLayout.LayoutParams(0, WRAP, 1f))
        val here = TextView(this)
        here.text = String.format("%.2fx here", spd); here.setTextColor(C.DIM); here.textSize = 13f
        head.addView(here, LinearLayout.LayoutParams(WRAP, WRAP))
        put(p, head, 0, 4, 4)
        val fs = FillSlider(this)
        fs.lo = 0.1f; fs.hi = 4f
        fs.value = Math.abs(if (hasMap) 1f else l.track("remapSpeed").eval(Editor.time)).coerceIn(0.1f, 4f)
        fs.isEnabled = !hasMap
        fs.onBegin = { pushUndo() }
        fs.onChange = { v ->
            ensureRemap(l)
            l.track("remapSpeed").set(Editor.time, v, autoKey)
            here.text = String.format("%.2fx here", v)
            render()
        }
        put(p, fs, 46)
        val presets = floatArrayOf(0.1f, 0.25f, 0.5f, 1f, 2f, 4f)
        val labels = arrayOf("0.1x", "0.25x", "0.5x", "1.0x", "2.0x", "4.0x")
        for (rowStart in intArrayOf(0, 3)) {
            val rw = hRow()
            for (k in rowStart until rowStart + 3) {
                val on = !hasMap && Math.abs(spd - presets[k]) < 0.01f
                val b = pill(labels[k], null, if (on) C.GREEN else C.CARD2, if (on) 0xFF2B1400.toInt() else C.TEXT) {
                    if (!hasMap) {
                        pushUndo(); ensureRemap(l)
                        val tr = l.track("remapSpeed"); tr.keys.clear(); tr.base = presets[k]
                        refreshPanel(); render()
                    }
                }
                val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                rw.addView(b, lp)
            }
            put(p, rw)
        }
        if (hasMap) text(p, "Time Remap keyframes are driving playback. Remove them to use the speed slider.", C.AMBER, 12f)

        text(p, "Time Remap", C.TEXT, 16f, true)
        if (!hasMap) {
            text(p, "Keyframe which moment of the source plays at each point in time. Add keyframes, then move them like any other parameter.", C.DIM, 12f)
            put(p, pill("Add Time Remap keyframes", "plus") {
                pushUndo(); ensureRemapKeys(l); selKey = "remapT"
                refreshPanel(); render()
            }, 44)
            val q = hRow()
            val b1 = pill("Freeze frame") { pushUndo(); freezeFrame(l); selKey = "remapT"; refreshPanel(); render() }
            val b2 = pill("Reverse") { pushUndo(); reverseRemap(l); selKey = "remapT"; refreshPanel(); render() }
            for (b in listOf(b1, b2)) { val lp = LinearLayout.LayoutParams(0, dp(40), 1f); lp.setMargins(dp(3), dp(3), dp(3), dp(3)); q.addView(b, lp) }
            put(p, q)
        } else {
            val def = Registry.get("remap")!!.props.first { it.key == "remapT" }
            addRow(p, l, def, "Time Remap (s)")
            val q = hRow()
            val b1 = pill("Freeze frame") { pushUndo(); freezeFrame(l); refreshPanel(); render() }
            val b2 = pill("Reverse") { pushUndo(); reverseRemap(l); refreshPanel(); render() }
            for (b in listOf(b1, b2)) { val lp = LinearLayout.LayoutParams(0, dp(40), 1f); lp.setMargins(dp(3), dp(3), dp(3), dp(3)); q.addView(b, lp) }
            put(p, q)
            put(p, pill("Remove Time Remap", "trash", C.CARD2, C.RED) {
                pushUndo(); l.track("remapT").keys.clear(); refreshPanel(); render()
            }, 42)
            text(p, "Tap the name, then the keyframe diamond, to add a keyframe at the playhead.", C.DIM, 12f)
        }

        text(p, "Frame Interpolation", C.TEXT, 16f, true)
        val itr = l.track("remapInterp")
        p.addView(chipRow(this, listOf("Off", "Frame Blend", "Optical Flow"), itr.base.toInt()) { i ->
            pushUndo(); ensureRemap(l); itr.keys.clear(); itr.base = i.toFloat(); refreshPanel(); render()
        })
        text(p, when (itr.base.toInt()) {
            1 -> "Blends the two source frames around each moment, so slow motion looks smooth instead of stepping."
            2 -> "Optical Flow currently uses Frame Blend. It applies to video layers."
            else -> "Shows the nearest source frame. Slow motion on video can look steppy."
        }, C.DIM, 12f)
        if (l.type != LayerType.VIDEO) text(p, "Frame interpolation only affects video layers.", C.DIM, 12f)
    }

    // ---------------------------------------------------------------- effects

    private fun buildFx(l: Layer) {
        val p = panelList
        val hdr = hRow()
        val ht = TextView(this)
        ht.text = "Effects  ·  " + l.name; ht.setTextColor(C.TEXT); ht.textSize = 20f; ht.typeface = Typeface.DEFAULT_BOLD
        hdr.addView(ht, LinearLayout.LayoutParams(0, WRAP, 1f))
        hdr.addView(pill("Close", "close") { closePanel() }, LinearLayout.LayoutParams(dp(112), dp(42)))
        put(p, hdr, 0, 6, 8)
        p.addView(chipRow(this, listOf("Applied", "Browse", "Presets", "Custom"), fxTab) { fxTab = it; showBottom(); refreshPanel() })
        when (fxTab) { 0 -> buildApplied(l); 1 -> buildBrowse(l); 2 -> buildPresets(l); else -> buildCustom(l) }
    }

    private class FxSnap(val id: String, val tracks: Map<String, JSONObject>, val inputs: Map<String, Int>, val off: Boolean)
    private var fxClip: List<FxSnap> = emptyList()

    private fun snapFx(l: Layer, entry: String): FxSnap? {
        val d = Registry.get(entry) ?: return null
        val m = LinkedHashMap<String, JSONObject>()
        if (d.kind == 1) { for (pd in d.props) l.props[pd.key]?.let { m["=" + pd.key] = it.toJson() } }
        else { val pre = entry + "__"; for ((k, tr) in l.props) if (k.startsWith(pre)) m[k.substring(pre.length)] = tr.toJson() }
        val ins = HashMap<String, Int>()
        for ((k, v) in l.inputs) if (k.startsWith("$entry:")) ins[k.substring(entry.length + 1)] = v
        return FxSnap(d.id, m, ins, l.fxOff.contains(entry))
    }

    private fun pasteFx(l: Layer, snap: FxSnap) {
        val d = Registry.byId[snap.id] ?: return
        val entry: String
        if (d.kind == 1) { entry = d.id; if (!l.fx.contains(entry)) l.fx.add(entry) }
        else { entry = Registry.uniqueEntry(l, d.id); l.fx.add(entry) }
        if (snap.off) l.fxOff.add(entry) else l.fxOff.remove(entry)
        for ((rk, js) in snap.tracks) {
            val key = if (rk.startsWith("=")) rk.substring(1) else entry + "__" + rk
            l.track(key).load(js)
        }
        for ((nm, id) in snap.inputs) l.inputs["$entry:$nm"] = id
        expanded.add(l.id.toString() + ":" + entry)
    }

    private fun resetFx(l: Layer, entry: String) {
        val d = Registry.get(entry) ?: return
        for (pd in d.props) {
            val tr = l.track(l.pkey(entry, pd))
            tr.keys.clear(); tr.base = pd.def; tr.setExpr(""); tr.exprOn = false
        }
        for (cp in d.colors) {
            val ck = l.ckey(entry, cp)
            val vals = listOf("_r" to ((cp.def shr 16) and 255), "_g" to ((cp.def shr 8) and 255), "_b" to (cp.def and 255), "_a" to ((cp.def ushr 24) and 255))
            for ((sf, v) in vals) { val tr = l.track(ck + sf); tr.keys.clear(); tr.base = v / 255f }
        }
    }

    private fun moveFx(l: Layer, entry: String, dir: Int) {
        val idx = l.fx.indexOf(entry)
        val to = idx + dir
        if (idx < 0 || to < 0 || to >= l.fx.size) return
        l.fx.removeAt(idx); l.fx.add(to, entry)
    }

    private fun removeFx(l: Layer, entry: String) {
        l.fx.remove(entry); l.fxOff.remove(entry)
        val pre = entry + "__"
        if (entry.contains('~')) { for (k in l.props.keys.toList()) if (k.startsWith(pre)) l.props.remove(k) }
        for (k in l.inputs.keys.toList()) if (k.startsWith("$entry:")) l.inputs.remove(k)
    }

    private fun fxMenu(l: Layer, entry: String) {
        val d = Registry.get(entry) ?: return
        val idx = l.fx.indexOf(entry)
        val labels = arrayOf("Copy effect", "Duplicate effect", "Move up", "Move down", "Reset to default", "Remove effect")
        val icons = arrayOf("dup", "dup", "chev_up", "chev_down", "adjust", "trash")
        Dlg(this).setTitle(d.name).setIconItems(labels, icons) { _, w ->
            when (w) {
                0 -> { snapFx(l, entry)?.let { fxClip = listOf(it) }; toast("Effect copied") }
                1 -> { snapFx(l, entry)?.let { pushUndo(); pasteFx(l, it); refreshPanel(); render() } }
                2 -> { if (idx > 0) { pushUndo(); moveFx(l, entry, -1); refreshPanel(); render() } }
                3 -> { if (idx < l.fx.size - 1) { pushUndo(); moveFx(l, entry, 1); refreshPanel(); render() } }
                4 -> { pushUndo(); resetFx(l, entry); refreshPanel(); render() }
                5 -> { pushUndo(); removeFx(l, entry); refreshPanel(); render() }
            }
        }.show()
    }

    private fun fxListMenu(l: Layer) {
        val labels = arrayOf("Copy all effects", if (fxClip.isEmpty()) "Paste effects (nothing copied)" else "Paste effects (" + fxClip.size + ")", "Reset all to default", "Remove all effects")
        val icons = arrayOf("dup", "import", "adjust", "trash")
        Dlg(this).setTitle("Effects").setIconItems(labels, icons) { _, w ->
            when (w) {
                0 -> { fxClip = l.fx.mapNotNull { snapFx(l, it) }; toast(if (fxClip.isEmpty()) "No effects to copy" else "Copied " + fxClip.size + " effects") }
                1 -> { if (fxClip.isEmpty()) toast("No effects copied") else { pushUndo(); for (sn in fxClip) pasteFx(l, sn); refreshPanel(); render() } }
                2 -> { pushUndo(); for (e in l.fx.toList()) resetFx(l, e); refreshPanel(); render() }
                3 -> { pushUndo(); for (e in l.fx.toList()) removeFx(l, e); refreshPanel(); render() }
            }
        }.show()
    }

    private fun fxHeader(l: Layer, d: EffectDef, entry: String): View {
        val key = l.id.toString() + ":" + entry
        val open = expanded.contains(key)
        val bar = hRow()
        bar.setBackgroundColor(C.CARD)
        bar.addView(IconView(this, "handle", C.DIM, 20f), LinearLayout.LayoutParams(dp(36), dp(48)))
        val t = TextView(this)
        t.text = if (entry.contains('~')) d.name + " " + entry.substringAfter('~') else d.name
        t.setTextColor(C.TEXT); t.textSize = 16f; t.typeface = Typeface.DEFAULT_BOLD
        bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        val off = l.fxOff.contains(entry)
        val eye = IconView(this, if (off) "eye_off" else "eye", if (off) C.DIM else C.GREEN, 20f)
        eye.onClick = { pushUndo(); if (off) l.fxOff.remove(entry) else l.fxOff.add(entry); refreshPanel(); render() }
        bar.addView(eye, LinearLayout.LayoutParams(dp(40), dp(48)))
        val chev = IconView(this, if (open) "chev_up" else "chev_down", C.DIM, 20f)
        chev.onClick = { if (!expanded.remove(key)) expanded.add(key); refreshPanel() }
        bar.addView(chev, LinearLayout.LayoutParams(dp(40), dp(48)))
        val more = IconView(this, "more", C.TEXT, 20f)
        more.onClick = { fxMenu(l, entry) }
        bar.addView(more, LinearLayout.LayoutParams(dp(40), dp(48)))
        return bar
    }

    private fun buildApplied(l: Layer) {
        val p = panelList
        val top = hRow()
        val cnt = TextView(this)
        cnt.text = l.fx.size.toString() + (if (l.fx.size == 1) " effect" else " effects")
        cnt.setTextColor(C.DIM); cnt.textSize = 13f
        top.addView(cnt, LinearLayout.LayoutParams(0, WRAP, 1f))
        val menu = IconView(this, "more", C.TEXT, 22f)
        menu.onClick = { fxListMenu(l) }
        top.addView(menu, LinearLayout.LayoutParams(dp(44), dp(40)))
        put(p, top, 0, 6, 2)
        if (l.fx.isEmpty()) text(p, "No effects yet. Tap Add Effect to browse.")
        for (entry in l.fx) {
            val d = Registry.get(entry) ?: continue
            val id = d.id
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.addView(fxHeader(l, d, entry))
            if (expanded.contains(l.id.toString() + ":" + entry)) {
                text(c, d.desc, C.DIM, 12f)
                Registry.errors[id]?.let { text(c, "Shader error: $it", C.RED, 12f) }
                for (pd in d.props) addRow(c, l, Registry.instProp(l, entry, pd))
                for (cp in d.colors) addColorParam(c, l, Registry.instColor(l, entry, cp))
                if (id == "particles") {
                    val pmb = SwitchRow(this)
                    pmb.label = "Motion blur"; pmb.on = l.mblur
                    pmb.onToggle = { v -> pushUndo(); l.mblur = v; render() }
                    put(c, pmb, 52)
                    text(c, "Birth color", C.DIM); c.addView(colorRow(l.color) { col -> pushUndo(); l.color = col; render() })
                    text(c, "Death color", C.DIM); c.addView(colorRow(l.color2) { col -> pushUndo(); l.color2 = col; render() })
                }
                for (nm in d.inputs) {
                    val rid = l.inputs[entry + ":" + nm]
                    val ref = Editor.scene.layers.firstOrNull { it.id == rid }
                    put(c, pill(nm + " layer: " + (ref?.name ?: "None"), "layers") { showInputDialog(l, entry, nm) }, 42)
                }
                if (id == "lightsweep") put(c, pill("Animate sweep") { lightSweepAnim(l) }, 42)
                if (id == "tile") {
                    val b = hRow()
                    for (axis in arrayOf("tileX", "tileY")) b.addView(pill("Scroll " + axis.last()) { tileScroll(l, axis) }, LinearLayout.LayoutParams(0, dp(40), 1f))
                    c.addView(b)
                }
            }
            put(p, c, 0, 3, 6)
        }
        put(p, pill("Add Effect", "plus", C.GREEN, 0xFF2B1400.toInt()) { fxTab = 1; showBottom(); refreshPanel() }, 48, 10, 10)
    }

    private fun lightSweepAnim(l: Layer) {
        pushUndo()
        val tr = l.track("lightsweep__centerX")
        tr.keys.clear()
        tr.keys.add(Key(l.start, -0.4f, Ease.EASE_IN_OUT)); tr.keys.add(Key(l.end, 1.4f, Ease.EASE_IN_OUT))
        refreshPanel(); render()
    }

    private fun tileScroll(l: Layer, key: String) {
        pushUndo()
        val tr = l.track(key)
        val mirror = l.p("tileMirror", Editor.time) >= 0.5f
        tr.keys.clear()
        tr.keys.add(Key(l.start, 0f, Ease.LINEAR)); tr.keys.add(Key(l.end, if (mirror) 2f else 1f, Ease.LINEAR))
        refreshPanel(); render()
    }

    private fun showInputDialog(l: Layer, entry: String, nm: String) {
        val cands = Editor.scene.layers.filter { it.id != l.id && it.isRenderable() && it.type != LayerType.VIDEO && it.type != LayerType.MODEL && it.type != LayerType.PARTICLES }
        val names = arrayOf("None") + cands.map { it.name }
        Dlg(this).setTitle(nm + " layer").setItems(names) { _, w ->
            pushUndo()
            if (w == 0) l.inputs.remove(entry + ":" + nm) else l.inputs[entry + ":" + nm] = cands[w - 1].id
            refreshPanel(); render()
        }.show()
    }

    private var fxQuery = ""

    private fun fxCategory(d: EffectDef): String = fxCategoryOf(d)

    private fun buildBrowse(l: Layer) {
        val p = panelList
        val q = EditText(this)
        q.hint = "Search effects"
        q.setSingleLine()
        q.setText(fxQuery)
        q.setTextColor(C.TEXT)
        put(p, q)
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        val catOrder = listOf("Light and glow", "Color", "Stylize", "Distort", "Blur", "Generate", "Glitch and motion", "Keying", "Transform and time", "Custom")
        fun fill() {
            grid.removeAllViews()
            val qs = fxQuery.trim().lowercase()
            val list = Registry.order.filter { qs.isEmpty() || it.name.lowercase().contains(qs) || it.desc.lowercase().contains(qs) || fxCategory(it).lowercase().contains(qs) }
            val groups = list.groupBy { fxCategory(it) }
            val keys = groups.keys.sortedBy { k -> catOrder.indexOf(k).let { if (it < 0) 99 else it } }
            if (keys.isEmpty()) text(grid, "No effects match your search.", C.DIM, 13f)
            val cols = maxOf(2, (resources.configuration.screenWidthDp - 60) / 200)
            for (k in keys) {
                val items = groups[k]!!.sortedBy { it.name }
                val hdr = hRow()
                val sample = EffectThumbs.cache[EffectThumbs.origKey(items[0].id)]
                if (sample != null) {
                    val iv = android.widget.ImageView(this)
                    iv.setImageBitmap(sample)
                    iv.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                    val ibg = android.graphics.drawable.GradientDrawable()
                    ibg.setColor(C.CARD2); ibg.cornerRadius = dp(10).toFloat()
                    iv.background = ibg
                    iv.clipToOutline = true
                    val ilp = LinearLayout.LayoutParams(dp(44), dp(44))
                    ilp.setMargins(0, 0, dp(10), 0)
                    hdr.addView(iv, ilp)
                }
                val ht = TextView(this)
                ht.text = k + "  (" + items.size + ")"
                ht.setTextColor(C.GREEN); ht.textSize = 15f; ht.typeface = Typeface.DEFAULT_BOLD
                hdr.addView(ht, LinearLayout.LayoutParams(0, WRAP, 1f))
                grid.addView(hdr, LinearLayout.LayoutParams(MATCH, WRAP).also { it.setMargins(dp(4), dp(10), dp(4), dp(4)) })
                var i = 0
                while (i < items.size) {
                    val r = hRow()
                    for (j in 0 until cols) {
                        if (i + j >= items.size) { r.addView(View(this), LinearLayout.LayoutParams(0, dp(250), 1f)); continue }
                        val d = items[i + j]
                        val card = EffectCard(this, d.name, fxCategory(d))
                        card.anim = d.previewAnim; card.thumbId = d.id; card.origId = EffectThumbs.origKey(d.id)
                        card.before = EffectThumbs.cache[EffectThumbs.origKey(d.id)]
                        card.after = EffectThumbs.cache[d.id]
                        card.badge = l.fx.contains(d.id)
                        card.onClick = { showEffectInfo(d, l) }
                        val lp = LinearLayout.LayoutParams(0, dp(250), 1f)
                        lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                        r.addView(card, lp)
                    }
                    grid.addView(r)
                    i += cols
                }
            }
        }
        q.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { fxQuery = s?.toString() ?: ""; fill() }
        })
        fill()
        p.addView(grid)
        if (Registry.order.any { !EffectThumbs.ready(it.id) }) EffectThumbs.generate(this, preview) { if (panel == P_FX && fxTab == 1) refreshPanel() }
        if (EffectThumbs.lastError.isNotEmpty()) text(p, "Preview error: " + EffectThumbs.lastError, C.RED, 11f)
        Registry.errors["__gl"]?.let { text(p, "GL error: " + it, C.RED, 11f) }
    }

    private fun showEffectInfo(d: EffectDef, l: Layer) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val card = EffectCard(this, d.name, d.category)
        card.anim = d.previewAnim; card.thumbId = d.id; card.origId = EffectThumbs.origKey(d.id)
        card.before = EffectThumbs.cache[EffectThumbs.origKey(d.id)]; card.after = EffectThumbs.cache[d.id]
        box.addView(card, LinearLayout.LayoutParams(MATCH, dp(280)))
        val info = TextView(this)
        val sb = StringBuilder(d.desc).append("\n\nParameters: ")
        sb.append(if (d.props.isEmpty()) "none" else d.props.joinToString(", ") { it.label })
        if (d.inputs.isNotEmpty()) sb.append("\nLayer inputs: ").append(d.inputs.joinToString(", "))
        if (!d.builtin) sb.append("\nCustom effect")
        Registry.errors[d.id]?.let { sb.append("\n\nShader error:\n").append(it) }
        info.text = sb.toString()
        info.setPadding(0, dp(10), 0, 0)
        box.addView(info)
        val b = Dlg(this).setTitle(d.name).setView(ScrollView(this).also { it.addView(box) })
            .setPositiveButton("Add to layer") { _, _ ->
                pushUndo()
                val entry = if (d.kind == 1) d.id else Registry.uniqueEntry(l, d.id)
                if (!l.fx.contains(entry)) l.fx.add(entry)
                l.fxOff.remove(entry)
                expanded.add(l.id.toString() + ":" + entry)
                fxTab = 0; showBottom(); refreshPanel(); render()
            }.setNegativeButton("Close", null)
        if (!d.builtin) b.setNeutralButton("Export") { _, _ -> exportText(d.id + ".saikieffect.json", Registry.toJson(d).toString(2)) }
        b.show()
    }

    private fun buildPresets(l: Layer) {
        val p = panelList
        put(p, pill("Save current effects as preset", "plus", C.GREEN, 0xFF2B1400.toInt()) {
            if (l.fx.isEmpty()) { toast("Add an effect first"); return@pill }
            val et = EditText(this)
            et.setText("My preset")
            Dlg(this).setTitle("Preset name").setView(et).setPositiveButton("Save") { _, _ ->
                Registry.savePreset(this, Registry.capturePreset(l, et.text.toString().ifBlank { "My preset" }, Editor.time))
                refreshPanel()
            }.show()
        }, 44)
        put(p, pill("Import preset file", "import") { pickFile(R_PRESET, "*/*") }, 44)
        for (pr in Registry.presets(this)) {
            text(p, pr.name + if (pr.builtin) "  (built in)" else "", C.TEXT, 15f, true)
            val r = hRow()
            r.addView(pill("Apply") { pushUndo(); Registry.applyPreset(l, pr.json); fxTab = 0; refreshPanel(); render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill("Export") { exportText(pr.name + ".saikipreset.json", pr.json.toString(2)) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            if (!pr.builtin) r.addView(pill("Delete", null, C.CARD2, C.RED) { Registry.deletePreset(this, pr.name); refreshPanel() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            put(p, r)
        }
    }

    private fun openEffectEditor(openPath: String? = null, newEffect: Boolean = false) {
        val i = Intent(this, SdkIdeActivity::class.java)
        if (openPath != null) i.putExtra("open", openPath)
        if (newEffect) i.putExtra("new", true)
        startActivityForResult(i, R_IDE)
    }

    private fun buildCustom(l: Layer) {
        val p = panelList
        put(p, pill("Open Effect Editor", "edit", C.GREEN, 0xFF2B1400.toInt()) { openEffectEditor() }, 48)
        val r0 = hRow()
        r0.addView(pill("New effect", "plus") { openEffectEditor(null, true) }, LinearLayout.LayoutParams(0, dp(42), 1f))
        r0.addView(pill("Import file", "import") { pickFile(R_FX, "*/*") }, LinearLayout.LayoutParams(0, dp(42), 1f))
        put(p, r0)
        text(p, "Each effect is a folder with effect.json and effect.glsl. Edit them in the full-screen editor, or put folders in app/src/main/assets/sdk/ before building the APK. See SDK.md.", C.DIM, 12f)
        val custom = Registry.order.filter { !it.builtin }
        if (custom.isEmpty()) text(p, "No custom effects yet.")
        for (d in custom) {
            text(p, d.name + (if (d.bundled) "  (bundled)" else ""), C.TEXT, 15f, true)
            text(p, d.desc, C.DIM, 12f)
            Registry.errors[d.id]?.let { text(p, "Shader error. Open the editor and press Run to see the line.", C.RED, 12f) }
            val r = hRow()
            r.addView(pill("Info") { showEffectInfo(d, l) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill(if (d.bundled) "View" else "Edit") { openEffectEditor(d.source) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill("Export") { exportText(d.id + ".saikieffect.json", Registry.toJson(d).toString(2)) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            if (!d.bundled) r.addView(pill("Delete", null, C.CARD2, C.RED) { Registry.deleteCustom(this, d.id); EffectThumbs.cache.remove(d.id); refreshPanel() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            put(p, r)
        }
    }

    private fun showCreateEffect() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        fun field(hint: String, init: String, lines: Int): EditText {
            val e = EditText(this)
            e.hint = hint; e.setText(init); e.textSize = 13f
            if (lines > 1) { e.minLines = lines; e.gravity = Gravity.TOP }
            box.addView(e)
            return e
        }
        val name = field("Name", "My Effect", 1)
        val desc = field("Description", "Mixes the image with grayscale.", 1)
        val params = field("Parameters, one per line: name,label,min,max,default", "amount,Amount,0,1,1", 3)
        val code = field("GLSL code", "vec4 effect(vec2 uv) {\n  vec4 c = src(uv);\n  return vec4(mix(c.rgb, vec3(luma(c.rgb)) * c.a, amount), c.a);\n}", 8)
        Dlg(this).setTitle("Create effect").setView(ScrollView(this).also { it.addView(box) })
            .setPositiveButton("Create") { _, _ ->
                try {
                    val pa = JSONArray()
                    for (line in params.text.toString().lines()) {
                        val f = line.split(",").map { it.trim() }
                        if (f.size >= 5) pa.put(JSONObject().put("name", f[0]).put("label", f[1]).put("min", f[2].toDouble()).put("max", f[3].toDouble()).put("def", f[4].toDouble()))
                    }
                    val o = JSONObject().put("name", name.text.toString()).put("description", desc.text.toString()).put("params", pa).put("code", code.text.toString())
                    val err = Registry.addCustom(this, o.toString())
                    if (err != null) toast(err) else { toast("Effect created"); EffectThumbs.generate(this, preview) { refreshPanel() }; refreshPanel() }
                } catch (e: Exception) { toast("Check the parameter lines") }
            }.setNegativeButton("Cancel", null).show()
    }

    // ---------------------------------------------------------------- graph

    private var graphMode = 0
    private var curveClip: Key? = null
    private val savedCurves = ArrayList<Pair<String, Key>>()
    private var savedLoaded = false

    private fun curveFile() = java.io.File(filesDir, "graph_presets.json")

    private fun loadCurves() {
        if (savedLoaded) return
        savedLoaded = true
        try {
            val a = JSONArray(curveFile().readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val k = Key(0f, 0f, Ease.CUSTOM)
                k.curveFromJson(o)
                savedCurves.add(Pair(o.optString("name", "Preset"), k))
            }
        } catch (e: Exception) { }
    }

    private fun saveCurves() {
        try {
            val a = JSONArray()
            for ((n, k) in savedCurves) a.put(k.curveJson().put("name", n))
            curveFile().writeText(a.toString())
        } catch (e: Exception) { }
    }

    private fun builtinCurves(): List<Pair<String, Key>> {
        fun bz(x1: Float, y1: Float, x2: Float, y2: Float) = Key(0f, 0f, Ease.CUSTOM).also { it.x1 = x1; it.y1 = y1; it.x2 = x2; it.y2 = y2 }
        fun ty(e: Ease, cn: Int, amp: Float = 1f) = Key(0f, 0f, e).also { it.cn = cn; it.amp = amp }
        return listOf(
            "Linear" to Key(0f, 0f, Ease.LINEAR), "Ease In" to Key(0f, 0f, Ease.EASE_IN), "Ease Out" to Key(0f, 0f, Ease.EASE_OUT),
            "Ease In-Out" to Key(0f, 0f, Ease.EASE_IN_OUT), "Back" to bz(0.34f, 1.56f, 0.64f, 1f), "Expo" to bz(0.7f, 0f, 0.84f, 0f),
            "Snap" to bz(1f, 0f, 0f, 1f), "Elastic" to ty(Ease.ELASTIC, 3), "Bounce" to ty(Ease.BOUNCE, 3),
            "Wave" to ty(Ease.WAVE, 2), "Steps" to ty(Ease.STEPS, 4))
    }

    private fun buildGraph(l: Layer) {
        val p = panelList
        text(p, "Graph editor", C.TEXT, 16f, true)
        val animated = l.props.filter { it.value.keys.size >= 2 }.keys.toList()
        if (animated.isEmpty()) { text(p, "Add two keyframes to a parameter (tap its name, then the keyframe button) or tap a keyframe in the timeline."); return }
        if (graphProp !in animated) { graphProp = animated[0]; graphKey = 0 }
        p.addView(TabBar(this, listOf("Ease", "Value", "Speed"), graphMode) { graphMode = it; refreshPanel() }, LinearLayout.LayoutParams(MATCH, dp(44)))
        p.addView(chipRow(this, animated.map { Registry.propDef(it)?.label ?: it }, animated.indexOf(graphProp)) { graphProp = animated[it]; graphKey = 0; refreshPanel() })
        val tr = l.track(graphProp)
        graphKey = graphKey.coerceIn(0, tr.keys.size - 2)
        val key = tr.keys[graphKey]
        val pd = Registry.propDef(graphProp)
        fun valueGraph(speed: Boolean) {
            val vg = ValueGraphView(this)
            vg.track = tr
            vg.speedMode = speed
            vg.t0 = maxOf(0f, tr.keys.first().t - 0.3f)
            vg.t1 = maxOf(vg.t0 + 0.5f, tr.keys.last().t + 0.3f)
            vg.selIdx = graphKey
            vg.onPick = { i -> graphKey = i.coerceIn(0, tr.keys.size - 2); Editor.time = tr.keys[i].t; onTimeChanged(); refreshPanel() }
            put(p, vg, 190)
            text(p, if (speed) "Speed is how fast the value changes. Flat lines mean constant speed, peaks mean fast moments." else "Segment " + (graphKey + 1) + " of " + (tr.keys.size - 1) + ". Tap a dot to choose a keyframe.", C.DIM, 12f)
        }
        if (graphMode == 1 || graphMode == 2) {
            valueGraph(graphMode == 2)
            if (graphMode == 1) {
                addPlain(p, "Keyframe time (s)", 0f, Editor.scene.duration, key.t, 2) { key.t = it; tr.keys.sortBy { k -> k.t }; render() }
                if (pd != null) addPlain(p, "Keyframe value", pd.min, pd.max, key.v, pd.dec) { key.v = it; render() }
            }
            return
        }
        valueGraph(false)
        addPlain(p, "Keyframe time (s)", 0f, Editor.scene.duration, key.t, 2) { key.t = it; tr.keys.sortBy { k -> k.t }; render() }
        if (pd != null) addPlain(p, "Keyframe value", pd.min, pd.max, key.v, pd.dec) { key.v = it; render() }
        text(p, "Easing curve to the next keyframe", C.GREEN, 13f, true)
        val types = listOf("Bezier", "Elastic", "Bounce", "Wave", "Steps")
        val cur = when (key.ease) { Ease.ELASTIC -> 1; Ease.BOUNCE -> 2; Ease.WAVE -> 3; Ease.STEPS -> 4; else -> 0 }
        p.addView(chipRow(this, types, cur) { i ->
            pushUndo()
            when (i) {
                0 -> if (!key.isBezier()) key.preset(Ease.EASE_IN_OUT)
                1 -> { key.ease = Ease.ELASTIC; key.cn = 3; key.amp = 1f }
                2 -> { key.ease = Ease.BOUNCE }
                3 -> { key.ease = Ease.WAVE; key.cn = 2; key.amp = 1f }
                else -> { key.ease = Ease.STEPS; key.cn = 4 }
            }
            refreshPanel(); render()
        })
        val g = GraphView(this)
        g.key = key
        g.onBegin = { pushUndo() }
        g.onChange = { render() }
        put(p, g, 200)
        if (key.ease == Ease.ELASTIC || key.ease == Ease.WAVE) {
            addPlain(p, "Strength", 0f, 2f, key.amp, 2) { key.amp = it; g.invalidate(); render() }
        }
        if (key.ease == Ease.ELASTIC || key.ease == Ease.WAVE || key.ease == Ease.STEPS) {
            addPlain(p, if (key.ease == Ease.STEPS) "Steps" else "Count", 1f, 12f, key.cn.toFloat(), 0) { key.cn = it.toInt().coerceIn(1, 12); g.invalidate(); render() }
        }
        if (key.isBezier() && !key.rev) text(p, "Drag the white handles. Pull a handle above the top for overshoot.", C.DIM, 12f)
        val acts = hRow()
        fun act(label: String, click: () -> Unit) {
            val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            acts.addView(pill(label) { click() }, lp)
        }
        act("Copy") { curveClip = Key(0f, 0f, Ease.CUSTOM).also { it.copyCurveFrom(key) }; toast("Curve copied") }
        act("Paste") { val c = curveClip; if (c == null) toast("No curve copied") else { pushUndo(); key.copyCurveFrom(c); refreshPanel(); render() } }
        act("Reverse") { pushUndo(); key.rev = !key.rev; refreshPanel(); render() }
        put(p, acts)
        put(p, pill("Apply this curve to every segment") {
            pushUndo()
            for (k in tr.keys) k.copyCurveFrom(key)
            render()
        }, 42)
        loadCurves()
        text(p, "Curve presets", C.TEXT, 14f, true)
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun thumb(name: String, k: Key, saved: Boolean) {
            val tv = CurveThumb(this, k, name)
            tv.onClick = { pushUndo(); key.copyCurveFrom(k); refreshPanel(); render() }
            if (saved) tv.setOnLongClickListener {
                Dlg(this).setTitle("Delete preset?").setMessage(name).setPositiveButton("Delete") { _, _ ->
                    savedCurves.removeAll { it.first == name && it.second === k }; saveCurves(); refreshPanel()
                }.setNegativeButton("Cancel", null).show()
                true
            }
            val lp = LinearLayout.LayoutParams(dp(78), dp(78))
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            row.addView(tv, lp)
        }
        for ((n, k) in builtinCurves()) thumb(n, k, false)
        for ((n, k) in savedCurves) thumb(n, k, true)
        hs.addView(row)
        p.addView(hs, LinearLayout.LayoutParams(MATCH, dp(86)))
        put(p, pill("Save this curve as a preset", "plus") {
            val et = EditText(this)
            et.hint = "Preset name"; et.setSingleLine(true)
            Dlg(this).setTitle("Save curve").setView(et).setPositiveButton("Save") { _, _ ->
                val nm = et.text.toString().trim().ifEmpty { "Curve " + (savedCurves.size + 1) }
                val k = Key(0f, 0f, Ease.CUSTOM); k.copyCurveFrom(key)
                savedCurves.add(Pair(nm, k)); saveCurves(); refreshPanel()
            }.setNegativeButton("Cancel", null).show()
        }, 42)
        text(p, "Long-press a saved preset to delete it.", C.DIM, 12f)
    }

    private fun showPanelMenu() {
        val l = selected() ?: return
        Dlg(this).setTitle("Layer").setItems(arrayOf("Clear all keyframes", "Reset transform", "Snap keyframes to beat markers")) { _, which ->
            pushUndo()
            if (which == 2) snapKeys(l)
            else for ((k, tr) in l.props) {
                if (which == 0) { tr.keys.clear(); tr.setExpr(""); tr.exprOn = false }
                else if (Defs.transform.any { it.key == k } || Defs.rot3d.any { it.key == k } || k == "z" || k.startsWith("anchor")) { tr.keys.clear(); tr.base = Registry.propDef(k)?.def ?: 0f }
            }
            refreshPanel(); render()
        }.show()
    }

    // ================================================================ scenes + export

    private fun showSceneDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val dlg = Dlg(this).setTitle("Scene setup").setView(ScrollView(this).also { it.addView(box) }).setPositiveButton("Done", null).create()
        fun build() {
            box.removeAllViews()
            val pr = Editor.project
            val s = Editor.scene
            text(box, Projects.resLabel(pr.w, pr.h) + "  ·  " + pr.w + " x " + pr.h + "  ·  " + pr.fps + " fps", C.DIM)
            text(box, "Guides", C.GREEN, 13f, true)
            val gs = SwitchRow(this)
            gs.label = "Guides"; gs.on = overlay.guides
            gs.onToggle = { v -> overlay.guides = v; overlay.invalidate() }
            put(box, gs, 52)
            text(box, "Scenes", C.GREEN, 13f, true)
            box.addView(chipRow(this, pr.scenes.map { it.name } + listOf("New scene"), Editor.sceneIndex) { i ->
                pushUndo()
                if (i == pr.scenes.size) { pr.scenes.add(Scene("Scene " + (pr.scenes.size + 1))); Editor.sceneIndex = pr.scenes.size - 1 } else Editor.sceneIndex = i
                Editor.time = 0f; selectedId = -1; panel = P_NONE; refreshAll(); build()
            })
            if (pr.scenes.size > 1) put(box, pill("Delete this scene", null, C.CARD2, C.RED) {
                pushUndo(); pr.scenes.remove(s); Editor.sceneIndex = 0; Editor.time = 0f; selectedId = -1; panel = P_NONE; refreshAll(); build()
            }, 40)
            val d = RulerSlider(this)
            d.label = "Duration (s)"; d.lo = 1f; d.hi = 120f; d.value = s.duration; d.dec = 1; d.canKey = false
            d.onChange = { v ->
                val old = s.duration
                s.duration = maxOf(1f, Math.round(v * 2f) / 2f)
                for (l in s.layers) if (l.end >= old - 0.001f) l.end = s.duration
                Editor.time = Editor.time.coerceIn(0f, s.duration); onTimeChanged()
            }
            put(box, d, 60, 8, 4)
            val f = RulerSlider(this)
            f.label = "Scene FOV"; f.lo = 15f; f.hi = 90f; f.value = s.fov; f.dec = 0; f.canKey = false
            f.onChange = { v -> s.fov = v; render() }
            put(box, f, 60)
            text(box, "Background", C.GREEN, 13f, true)
            box.addView(colorRow(s.bg) { c -> s.bg = c; render() })
        }
        build()
        dlg.show()
    }

    private fun showRenderDialog() {
        if (playing) togglePlay()
        Projects.save(this, projectId, Editor.project)
        val proj = Editor.project
        RenderUi.settings(this, proj) { st -> RenderUi.show(this, proj, st) }
    }
}
