package com.saiki.motion

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class EditorActivity : Activity(), EditHost, TimelineHost {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val P_NONE = 0; private val P_MEDIA = 1; private val P_SHAPES = 2; private val P_EDIT = 3
    private val P_XFORM = 4; private val P_FX = 5; private val P_BLEND = 6; private val P_SPEED = 7; private val P_GRAPH = 8
    private val R_VIDEO = 51; private val R_IMAGE = 52; private val R_GLB = 53; private val R_FX = 54; private val R_PRESET = 55

    private lateinit var projectId: String
    private lateinit var preview: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var aspect: AspectLayout
    private lateinit var timeline: TimelineView
    private lateinit var titleView: TextView
    private lateinit var playIcon: IconView
    private lateinit var markIcon: IconView
    private lateinit var cubeIcon: IconView
    private lateinit var qualityChip: ChipView
    private lateinit var toolbarBox: HorizontalScrollView
    private lateinit var toolbarRow: LinearLayout
    private lateinit var panelBox: LinearLayout
    private lateinit var panelList: LinearLayout
    private lateinit var diamondSide: IconView

    private var selectedId = -1
    private var panel = P_NONE
    private var fxTab = 0
    private var fxCat = 0
    private var playing = false
    private var lastNs = 0L
    private var autoKey = false
    private var quality = 1
    private var graphProp = ""
    private var graphKey = 0
    private var selKey = ""
    private val R_AUDIOFILE = 58
    private val players = HashMap<Int, android.media.MediaPlayer>()
    private val R_BEAT = 57
    private lateinit var subView: TextView
    private val multi = LinkedHashSet<Int>()
    private var multiMode = false
    private val clipboard = ArrayList<Layer>()

    private val expanded = HashSet<String>()
    private val rows = ArrayList<Row>()
    private class Row(val slider: RulerSlider, val d: PropDef, val layer: Layer)
    private val undo = ArrayList<String>()
    private val redo = ArrayList<String>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Snack.show(this, s)

    // ================================================================ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Registry.init(this)
        projectId = intent.getStringExtra("id") ?: ""
        Editor.project = Projects.load(this, projectId)
        Editor.sceneIndex = 0
        if (savedInstanceState == null) Editor.time = 0f
        selectedId = savedInstanceState?.getInt("sel", -1) ?: -1
        buildUi()
        refreshAll()
        EffectThumbs.generate(this) { if (panel == P_FX && fxTab == 1) refreshPanel() }
    }

    override fun onResume() { super.onResume(); preview.onResume() }

    override fun onPause() {
        super.onPause()
        playing = false
        stopAudio()
        playIcon.set("play", C.TEXT)
        preview.onPause()
        Projects.save(this, projectId, Editor.project)
    }

    override fun onDestroy() { stopAudio(); super.onDestroy() }

    private fun stopAudio() {
        for (mp in players.values) try { mp.release() } catch (e: Exception) { }
        players.clear()
    }

    private fun startAudio() {
        stopAudio()
        val t = Editor.time
        for (l in Editor.scene.layers) {
            if (l.type != LayerType.AUDIO || !l.visible || t > l.end) continue
            val path = l.imagePath ?: continue
            try {
                val mp = android.media.MediaPlayer()
                mp.setDataSource(path); mp.prepare()
                val v = l.p("volume", t).coerceIn(0f, 1f)
                mp.setVolume(v, v)
                players[l.id] = mp
            } catch (e: Exception) { }
        }
        tickAudio()
    }

    private fun tickAudio() {
        val t = Editor.time
        for (l in Editor.scene.layers) {
            val mp = players[l.id] ?: continue
            try {
                val inside = t >= l.start && t <= l.end
                if (inside && !mp.isPlaying) { mp.seekTo(((t - l.start) * 1000f).toInt()); mp.start() }
                else if (!inside && mp.isPlaying) mp.pause()
            } catch (e: Exception) { }
        }
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); o.putInt("sel", selectedId) }

    // ================================================================ UI skeleton

    private fun icon(name: String, tint: Int = C.TEXT, click: () -> Unit = {}): IconView {
        val v = IconView(this, name, tint)
        v.onClick = click
        return v
    }

    private fun hRow(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    private fun addIcon(parent: LinearLayout, v: IconView, w: Int = 44, h: Int = 48) {
        parent.addView(v, LinearLayout.LayoutParams(dp(w), dp(h)))
    }

    private fun buildUi() {
        val land = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val root = LinearLayout(this)
        root.orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.fitsSystemWindows = true

        val top = hRow()
        top.setPadding(dp(4), 0, dp(8), 0)
        addIcon(top, icon("back", C.AMBER) { onBack() }, 40)
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        titleView = TextView(this)
        titleView.setTextColor(C.TEXT); titleView.textSize = 17f; titleView.typeface = Typeface.DEFAULT_BOLD; titleView.maxLines = 1
        subView = TextView(this)
        subView.setTextColor(C.DIM); subView.textSize = 11f
        tcol.addView(titleView); tcol.addView(subView)
        top.addView(tcol, LinearLayout.LayoutParams(0, WRAP, 1f))
        cubeIcon = icon("cube") { toggle3d() }
        addIcon(top, cubeIcon, 40)
        addIcon(top, icon("gear") { showSceneDialog() }, 40)
        top.addView(pill("Render", "export", C.GREEN, 0xFF04210F.toInt()) { showRenderDialog() }, LinearLayout.LayoutParams(dp(104), dp(38)))

        val previewBox = FrameLayout(this)
        previewBox.setBackgroundColor(0xFF161618.toInt())
        aspect = AspectLayout(this)
        preview = PreviewView(this)
        overlay = OverlayView(this, this)
        aspect.addView(preview, MATCH, MATCH)
        aspect.addView(overlay, MATCH, MATCH)
        previewBox.addView(aspect, MATCH, MATCH)

        val tr = hRow()
        tr.setPadding(dp(6), 0, dp(6), 0)
        addIcon(tr, icon("fit") { timeline.fitToScene() })
        qualityChip = ChipView(this, "Full")
        qualityChip.onClick = { cycleQuality() }
        tr.addView(qualityChip, LinearLayout.LayoutParams(dp(56), dp(48)))
        markIcon = icon("bookmark") { toggleMarker() }
        addIcon(tr, markIcon)
        tr.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val prev = icon("prev") { stepFrame(-1) }
        prev.onLong = { jump(-1) }
        addIcon(tr, prev, 48)
        playIcon = icon("play") { togglePlay() }
        addIcon(tr, playIcon, 52)
        val next = icon("next") { stepFrame(1) }
        next.onLong = { jump(1) }
        addIcon(tr, next, 48)
        tr.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        addIcon(tr, icon("layers") { showLayersMenu() })
        addIcon(tr, icon("undo") { doUndo() })
        addIcon(tr, icon("redo") { doRedo() })

        timeline = TimelineView(this, this)

        toolbarBox = HorizontalScrollView(this)
        toolbarBox.isHorizontalScrollBarEnabled = false
        toolbarBox.setBackgroundColor(C.PANEL)
        toolbarRow = LinearLayout(this)
        toolbarRow.orientation = LinearLayout.HORIZONTAL
        toolbarBox.addView(toolbarRow)

        panelBox = LinearLayout(this)
        panelBox.orientation = LinearLayout.HORIZONTAL
        panelBox.setBackgroundColor(C.PANEL)
        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER_HORIZONTAL
        side.addView(icon("close") { closePanel() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        side.addView(icon("plus", C.GREEN) { fxTab = 1; openPanel(P_FX) }, LinearLayout.LayoutParams(dp(48), dp(44)))
        diamondSide = icon("diamond_f", C.DIM) { keySelected() }
        side.addView(diamondSide, LinearLayout.LayoutParams(dp(48), dp(44)))
        side.addView(icon("graph", C.DIM) { openPanel(P_GRAPH) }, LinearLayout.LayoutParams(dp(48), dp(44)))
        side.addView(icon("box", C.DIM) { fxTab = 2; openPanel(P_FX) }, LinearLayout.LayoutParams(dp(48), dp(44)))
        side.addView(icon("more", C.DIM) { showPanelMenu() }, LinearLayout.LayoutParams(dp(48), dp(44)))
        panelBox.addView(side, LinearLayout.LayoutParams(dp(52), MATCH))
        val sv = ScrollView(this)
        panelList = LinearLayout(this)
        panelList.orientation = LinearLayout.VERTICAL
        panelList.setPadding(dp(4), dp(6), dp(8), dp(16))
        sv.addView(panelList, MATCH, WRAP)
        panelBox.addView(sv, LinearLayout.LayoutParams(0, MATCH, 1f))

        if (land) {
            val left = LinearLayout(this)
            left.orientation = LinearLayout.VERTICAL
            left.addView(top, LinearLayout.LayoutParams(MATCH, dp(52)))
            left.addView(previewBox, LinearLayout.LayoutParams(MATCH, 0, 1f))
            left.addView(tr, LinearLayout.LayoutParams(MATCH, dp(48)))
            val right = LinearLayout(this)
            right.orientation = LinearLayout.VERTICAL
            right.addView(timeline, LinearLayout.LayoutParams(MATCH, 0, 1f))
            right.addView(toolbarBox, LinearLayout.LayoutParams(MATCH, dp(76)))
            right.addView(panelBox, LinearLayout.LayoutParams(MATCH, dp(220)))
            root.addView(left, LinearLayout.LayoutParams(0, MATCH, 0.46f))
            root.addView(right, LinearLayout.LayoutParams(0, MATCH, 0.54f))
        } else {
            root.addView(top, LinearLayout.LayoutParams(MATCH, dp(52)))
            root.addView(previewBox, LinearLayout.LayoutParams(MATCH, 0, 1f))
            root.addView(tr, LinearLayout.LayoutParams(MATCH, dp(48)))
            root.addView(timeline, LinearLayout.LayoutParams(MATCH, dp(168)))
            root.addView(toolbarBox, LinearLayout.LayoutParams(MATCH, dp(76)))
            root.addView(panelBox, LinearLayout.LayoutParams(MATCH, dp(300)))
        }
        setContentView(root)
    }

    // ================================================================ small helpers

    private fun selected(): Layer? = Editor.scene.layers.firstOrNull { it.id == selectedId }

    private fun render() {
        preview.requestRender(); overlay.invalidate(); timeline.invalidate()
    }

    private fun pill(text: String, icon: String? = null, fill: Int = C.CARD2, tc: Int = C.TEXT, click: () -> Unit): PillButton {
        val b = PillButton(this, text, icon, fill, tc)
        b.onClick = click
        return b
    }

    private fun put(parent: LinearLayout, v: View, hDp: Int = 0, mT: Int = 3, mB: Int = 3) {
        val lp = LinearLayout.LayoutParams(MATCH, if (hDp == 0) WRAP else dp(hDp))
        lp.setMargins(0, dp(mT), 0, dp(mB))
        parent.addView(v, lp)
    }

    private fun text(parent: LinearLayout, t: String, color: Int = C.DIM, size: Float = 13f, bold: Boolean = false): TextView {
        val tv = TextView(this)
        tv.text = t; tv.setTextColor(color); tv.textSize = size
        if (bold) tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(dp(6), dp(6), dp(6), dp(4))
        parent.addView(tv)
        return tv
    }

    private fun refreshAll() {
        aspect.ratio = Editor.project.w.toFloat() / Editor.project.h.toFloat()
        if (selected() == null) selectedId = -1
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); onTimeChanged()
    }

    private fun refreshTitle() {
        val l = selected()
        titleView.text = l?.name ?: Editor.project.name
        cubeIcon.tint = if (l != null && (l.is3d || l.type == LayerType.MODEL || l.type == LayerType.CAMERA)) C.GREEN else C.TEXT
        cubeIcon.invalidate()
    }

    private fun showBottom() {
        toolbarBox.visibility = if (panel == P_NONE) View.VISIBLE else View.GONE
        panelBox.visibility = if (panel != P_NONE) View.VISIBLE else View.GONE
    }

    private fun onTimeChanged() {
        syncRows()
        subView.text = timeline.timecode(Editor.time) + " / " + timeline.timecode(Editor.scene.duration)
        val has = Editor.scene.markers.any { Math.abs(it - Editor.time) < 0.02f }
        markIcon.set(if (has) "bookmark_f" else "bookmark", if (has) C.BLUE else C.TEXT)
        render()
    }

    private fun onBack() {
        if (panel != P_NONE) closePanel() else if (selectedId != -1) onSelect(-1) else finish()
    }

    private fun openPanel(p: Int) {
        if (p != P_MEDIA && p != P_SHAPES && selected() == null) { toast("Select a layer first"); return }
        panel = p
        showBottom(); refreshPanel()
    }

    private fun closePanel() { panel = P_NONE; showBottom() }

    // ================================================================ tool bar

    private fun refreshToolbar() {
        toolbarRow.removeAllViews()
        val l = selected()
        fun tool(ic: String, label: String, tint: Int = C.TEXT, click: () -> Unit) {
            val b = ToolButton(this, ic, label)
            b.tint = tint
            b.onClick = click
            toolbarRow.addView(b, LinearLayout.LayoutParams(dp(76), dp(76)))
        }
        if (l == null) {
            tool("media", "Media") { openPanel(P_MEDIA) }
            tool("text", "Text") { addLayer(LayerType.TEXT) }
            tool("solid", "Solid") { addSolid() }
            tool("adjust", "Adjustment") { addLayer(LayerType.ADJUST) }
            tool("audio", "Audio") { pickFile(R_AUDIOFILE, "audio/*") }
            tool("nullobj", "Null") { addLayer(LayerType.NULL) }
            tool("shape", "Shape") { openPanel(P_SHAPES) }
            tool("camera", "Camera") { addLayer(LayerType.CAMERA) }
            tool("particles", "Particles") { addParticles() }
            tool("layers", "Group") { addLayer(LayerType.GROUP) }
            tool("cube", "3D Model") { pickFile(R_GLB, "*/*") }
        } else {
            toolbarRow.addView(icon("back", C.GREEN) { onSelect(-1) }, LinearLayout.LayoutParams(dp(44), dp(76)))
            tool("edit", "Edit") { openPanel(P_EDIT) }
            tool("move", "Transform") { openPanel(P_XFORM) }
            if (l.isRenderable()) {
                tool("sparkle", "Effects") { openPanel(P_FX) }
                tool("drop", "Blending") { openPanel(P_BLEND) }
                tool("speed", "Speed") { openPanel(P_SPEED) }
            }
            tool("trash", "Delete", C.RED) { deleteLayer() }
        }
    }

    // ================================================================ playback

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (!playing) return
            if (lastNs != 0L) {
                var t = Editor.time + (ns - lastNs) / 1e9f
                var wrapped = false
                if (t > Editor.scene.duration) { t = 0f; wrapped = true }
                Editor.time = t
                if (wrapped) startAudio() else tickAudio()
                onTimeChanged()
            }
            lastNs = ns
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun togglePlay() {
        playing = !playing
        playIcon.set(if (playing) "pause" else "play", C.TEXT)
        if (playing) { lastNs = 0L; Choreographer.getInstance().postFrameCallback(frameCb); startAudio() } else stopAudio()
    }

    private fun stepFrame(dir: Int) {
        Editor.time = (Editor.time + dir / Editor.project.fps.toFloat()).coerceIn(0f, Editor.scene.duration)
        onTimeChanged()
    }

    private fun jump(dir: Int) {
        val times = ArrayList<Float>()
        times.addAll(Editor.scene.markers)
        selected()?.let { l -> for ((_, tr) in l.props) for (k in tr.keys) times.add(k.t) }
        times.sort()
        val now = Editor.time
        val target = if (dir > 0) times.firstOrNull { it > now + 0.02f } else times.lastOrNull { it < now - 0.02f }
        if (target != null) { Editor.time = target; onTimeChanged() }
    }

    private fun toggleMarker() {
        val ms = Editor.scene.markers
        val ex = ms.firstOrNull { Math.abs(it - Editor.time) < 0.02f }
        pushUndo()
        if (ex != null) ms.remove(ex) else ms.add(Editor.time)
        onTimeChanged()
    }

    private fun cycleQuality() {
        quality = when (quality) { 1 -> 2; 2 -> 4; else -> 1 }
        preview.quality = quality
        qualityChip.text = when (quality) { 1 -> "Full"; 2 -> "1/2"; else -> "1/4" }
        qualityChip.invalidate(); render()
    }

    // ================================================================ undo / redo

    private fun snapshot(): String = Store.toJson(Editor.project).toString()

    private fun pushUndo() {
        val s = snapshot()
        if (undo.lastOrNull() == s) return
        undo.add(s)
        if (undo.size > 40) undo.removeAt(0)
        redo.clear()
    }

    private fun restore(js: String) {
        val p = Store.fromJson(JSONObject(js))
        Editor.project = p
        if (Editor.sceneIndex >= p.scenes.size) Editor.sceneIndex = p.scenes.size - 1
        Editor.time = Editor.time.coerceIn(0f, Editor.scene.duration)
        refreshAll()
    }

    private fun doUndo() { if (undo.isEmpty()) { toast("Nothing to undo"); return }; redo.add(snapshot()); restore(undo.removeAt(undo.size - 1)) }
    private fun doRedo() { if (redo.isEmpty()) { toast("Nothing to redo"); return }; undo.add(snapshot()); restore(redo.removeAt(redo.size - 1)) }

    // ================================================================ hosts

    override fun selectedLayer(): Layer? = selected()
    override fun autoKey(): Boolean = autoKey
    override fun beginEdit() { pushUndo() }
    override fun onEdited() { syncRows(); render() }
    override fun selectedId(): Int = selectedId
    override fun isSelected(id: Int): Boolean = id == selectedId || multi.contains(id)
    override fun onSeek(t: Float) { Editor.time = t; onTimeChanged() }
    override fun onSelect(id: Int) {
        if (multiMode && id >= 0) {
            if (!multi.remove(id)) multi.add(id)
            selectedId = id; panel = P_NONE
            refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
            return
        }
        if (!multiMode) multi.clear()
        selectedId = id
        panel = if (id >= 0 && selected()?.type == LayerType.TEXT) P_EDIT else P_NONE
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); render()
    }
    override fun onToggleVisible(l: Layer) { pushUndo(); l.visible = !l.visible; render() }
    override fun onTimingChanged() { render() }

    override fun onReorder(l: Layer, listIndex: Int) {
        pushUndo()
        val ls = Editor.scene.layers
        ls.remove(l)
        ls.add(listIndex.coerceIn(0, ls.size), l)
        render()
    }

    override fun onKeyTap(l: Layer, key: String, idx: Int) {
        selectedId = l.id
        graphProp = key
        graphKey = idx
        Editor.time = l.track(key).keys.getOrNull(idx)?.t ?: Editor.time
        panel = P_GRAPH
        refreshTitle(); refreshToolbar(); showBottom(); refreshPanel(); onTimeChanged()
    }

    // ================================================================ layers

    private fun addLayer(type: LayerType): Layer {
        pushUndo()
        val p = Editor.project
        val s = Editor.scene
        val id = p.nextId++
        val nm = when (type) {
            LayerType.SHAPE -> "Shape"; LayerType.TEXT -> "Text"; LayerType.IMAGE -> "Image"; LayerType.VIDEO -> "Video"
            LayerType.CAMERA -> "Camera"; LayerType.NULL -> "Null"; LayerType.MODEL -> "Model"; LayerType.PARTICLES -> "Particles"; LayerType.GROUP -> "Group"; LayerType.ADJUST -> "Adjustment"; LayerType.AUDIO -> "Audio"
        }
        val l = Layer(id, "$nm $id", type)
        l.end = s.duration
        if (type == LayerType.TEXT) l.color = 0xFFFFFFFF.toInt()
        if (type == LayerType.MODEL || type == LayerType.CAMERA) l.is3d = true
        s.layers.add(l)
        if (type == LayerType.NULL) toast("Turn on the 3D cube (top bar) so this Null can drive other layers")
        if (type == LayerType.CAMERA) toast("The camera affects layers below it that have the 3D cube on")
        onSelect(id)
        return l
    }

    private fun addParticles() {
        val l = addLayer(LayerType.SHAPE)
        l.name = "Particles " + l.id
        l.shape = ShapeKind.CIRCLE
        l.fx.add("particles")
        l.track("pShowSrc").base = 0f
        expanded.add(l.id.toString() + ":particles")
        fxTab = 0
        panel = P_FX
        showBottom(); refreshPanel()
    }

    private fun cloneLayer(l: Layer, suffix: String): Layer {
        val c = Layer(Editor.project.nextId++, l.name + suffix, l.type)
        c.text = l.text; c.color = l.color; c.color2 = l.color2; c.shape = l.shape; c.imagePath = l.imagePath
        c.bold = l.bold; c.italic = l.italic; c.start = l.start; c.end = l.end; c.is3d = l.is3d; c.parentId = l.parentId
        c.blend = l.blend; c.srcDur = l.srcDur; c.visible = l.visible; c.fx.addAll(l.fx); c.fxOff.addAll(l.fxOff); c.inputs.putAll(l.inputs)
        for ((k, tr) in l.props) {
            val n = c.track(k)
            n.base = tr.base
            n.setExpr(tr.exprSrc)
            for (key in tr.keys) { val nk = Key(key.t, key.v, key.ease); nk.x1 = key.x1; nk.y1 = key.y1; nk.x2 = key.x2; nk.y2 = key.y2; n.keys.add(nk) }
        }
        return c
    }

    private fun targets(): List<Layer> {
        val m = Editor.scene.layers.filter { multi.contains(it.id) }
        if (m.isNotEmpty()) return m
        val s = selected()
        return if (s != null) listOf(s) else emptyList()
    }

    private fun duplicateSelected() {
        val t = targets()
        if (t.isEmpty()) { toast("Select a layer first"); return }
        pushUndo()
        var last = -1
        for (l in t) { val c = cloneLayer(l, " copy"); Editor.scene.layers.add(c); last = c.id }
        multi.clear(); multiMode = false
        onSelect(last)
    }

    private fun copySelected() {
        val t = targets()
        if (t.isEmpty()) { toast("Select a layer first"); return }
        clipboard.clear()
        for (l in t) clipboard.add(cloneLayer(l, ""))
        toast("Copied " + t.size + (if (t.size == 1) " layer" else " layers"))
    }

    private fun pasteLayers() {
        if (clipboard.isEmpty()) { toast("Nothing copied yet"); return }
        pushUndo()
        var last = -1
        for (c in clipboard) { val n = cloneLayer(c, ""); Editor.scene.layers.add(n); last = n.id }
        multi.clear(); multiMode = false
        onSelect(last)
    }

    private fun selectAll() {
        multi.clear()
        for (l in Editor.scene.layers) multi.add(l.id)
        if (multi.isEmpty()) { toast("No layers yet"); return }
        selectedId = multi.last()
        refreshTitle(); refreshToolbar(); render()
        toast("All layers selected")
    }

    private fun groupSelected() {
        val t = targets().filter { it.type != LayerType.GROUP }
        if (t.isEmpty()) { toast("Select layers first"); return }
        val g = addLayer(LayerType.GROUP)
        for (l in t) l.parentId = g.id
        multi.clear(); multiMode = false
        onSelect(g.id)
        toast("Grouped " + t.size + " layers")
    }

    private fun addSolid() {
        val l = addLayer(LayerType.SHAPE)
        l.shape = ShapeKind.RECT
        l.name = "Solid " + l.id
        l.color = 0xFF2A2A33.toInt()
        val ar = Editor.project.w.toFloat() / Editor.project.h
        l.track("scale").base = (maxOf(2f * ar, 2f) / 0.8f / 0.84f * 1.02f).coerceAtMost(8f)
        refreshPanel(); render()
    }

    private fun deleteLayer() {
        val t = targets()
        if (t.isEmpty()) return
        pushUndo()
        for (l in t) { Editor.scene.layers.remove(l); for (o in Editor.scene.layers) if (o.parentId == l.id) o.parentId = -1 }
        multi.clear(); multiMode = false
        onSelect(-1)
    }

    private fun moveLayer(dir: Int) {
        val l = selected() ?: return
        pushUndo()
        val ls = Editor.scene.layers
        val i = ls.indexOf(l)
        val j = i + dir
        if (j < 0 || j >= ls.size) return
        ls.removeAt(i); ls.add(j, l); render()
    }

    private fun toggle3d() {
        val l = selected() ?: run { toast("Select a layer first"); return }
        if (l.type == LayerType.MODEL || l.type == LayerType.CAMERA) { toast("This layer is always 3D"); return }
        pushUndo()
        l.is3d = !l.is3d
        refreshTitle(); refreshPanel(); render()
        toast(if (l.is3d) "3D on" else "3D off")
    }

    private fun showLayersMenu() {
        val labels = arrayOf("Select All Layers", if (multiMode) "Stop Selecting Multiple" else "Select Multiple Layers", "Group Layers", "Show All Keyframes",
            "Copy Layer", "Paste Layer", "Duplicate Layer", "Move Layer Up", "Move Layer Down", if (overlay.guides) "Hide Guides" else "Show Guides", "Delete Layer")
        val icons = arrayOf("layers", "check", "layers", "graph", "dup", "import", "dup", "chev_up", "chev_down", "dots", "trash")
        Dlg(this).setTitle("Layers").setIconItems(labels, icons) { _, w ->
            when (w) {
                0 -> selectAll()
                1 -> { multiMode = !multiMode; if (!multiMode) multi.clear(); render(); toast(if (multiMode) "Tap layers to select them" else "Multi select off") }
                2 -> groupSelected()
                3 -> timeline.expandAll()
                4 -> copySelected()
                5 -> pasteLayers()
                6 -> duplicateSelected()
                7 -> moveLayer(1)
                8 -> moveLayer(-1)
                9 -> { overlay.guides = !overlay.guides; overlay.invalidate() }
                else -> deleteLayer()
            }
        }.show()
    }

    // ---------------------------------------------------------------- expressions, audio, beats

    private fun showExpression(l: Layer, d: PropDef) {
        val tr = l.track(d.key)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(4), dp(4), dp(4))
        text(box, "t = time, v = keyframed value. Functions: wiggle(freq, amp), sin, cos, abs, min, max, clamp, pow, sqrt, linear(t, a, b, c, d), noise, floor, round, mix, pi.", C.DIM, 12f)
        val et = EditText(this)
        et.setText(tr.exprSrc)
        et.typeface = Typeface.MONOSPACE
        et.hint = "v + wiggle(3, 0.1)"
        box.addView(et)
        val presets = listOf("v + wiggle(3, 0.1)", "v * (1 + 0.2 * sin(t * 8))", "v + t * 90", "v + abs(sin(t * 4)) * 0.3", "")
        box.addView(chipRow(this, listOf("Wiggle", "Pulse", "Spin", "Bounce", "Clear"), -1) { i -> et.setText(presets[i]) })
        Dlg(this).setTitle("Expression: " + d.label).setView(box).setPositiveButton("Apply") { _, _ ->
            pushUndo()
            if (!tr.setExpr(et.text.toString())) toast("Expression error") else { refreshPanel(); render() }
        }.setNegativeButton("Cancel", null).show()
    }

    private fun extractAudio(l: Layer) {
        val src = l.imagePath ?: return
        toast("Extracting audio...")
        Thread {
            try {
                val f = File(cacheDir, "audio_" + System.currentTimeMillis() + ".m4a")
                if (!AudioTools.extractAudio(src, f)) { runOnUiThread { toast("This video has no audio track") }; return@Thread }
                val v = ContentValues()
                v.put(MediaStore.Audio.Media.DISPLAY_NAME, l.name.substringBeforeLast('.') + ".m4a")
                v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                v.put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/SaikiMotion")
                val u = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
                val mf = File(Projects.mediaDir(this), System.currentTimeMillis().toString() + "_" + l.name.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9]"), "_") + ".m4a")
                f.copyTo(mf, true)
                f.delete()
                runOnUiThread { toast("Saved to Music/SaikiMotion and added as an audio layer"); addMedia(mf.absolutePath, LayerType.AUDIO) }
            } catch (e: Exception) { runOnUiThread { toast("Could not extract audio") } }
        }.start()
    }

    private fun beatsFrom(path: String, offset: Float) {
        toast("Analyzing beats...")
        Thread {
            try {
                val beats = AudioTools.detectBeats(path)
                runOnUiThread {
                    pushUndo()
                    val ms = Editor.scene.markers
                    var n = 0
                    for (b in beats) {
                        val t = offset + b
                        if (t <= Editor.scene.duration && ms.none { Math.abs(it - t) < 0.05f }) { ms.add(t); n++ }
                    }
                    render(); toast("Added " + n + " beat markers")
                }
            } catch (e: Exception) { runOnUiThread { toast("Could not analyze audio") } }
        }.start()
    }

    private fun snapKeys(l: Layer) {
        val ms = Editor.scene.markers
        for ((_, tr) in l.props) {
            var ch = false
            for (k in tr.keys) {
                val m = ms.minByOrNull { Math.abs(it - k.t) }
                if (m != null && Math.abs(m - k.t) < 0.35f) { k.t = m; ch = true }
            }
            if (ch) tr.keys.sortBy { it.t }
        }
        toast("Keyframes snapped to markers")
    }

    // ================================================================ importing

    private fun pickFile(req: Int, mime: String) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = mime
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(i, req)
    }

    private fun displayName(uri: android.net.Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "file"
            }
        } catch (e: Exception) { }
        return "file"
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        if (req == R_FX || req == R_PRESET) {
            try {
                val txt = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                if (req == R_FX) {
                    val err = Registry.addCustom(this, txt)
                    if (err != null) toast(err) else { toast("Effect imported"); EffectThumbs.generate(this) { refreshPanel() }; refreshPanel() }
                } else {
                    val o = JSONObject(txt)
                    o.getString("name")
                    Registry.savePreset(this, o)
                    toast("Preset imported"); refreshPanel()
                }
            } catch (e: Exception) { toast("Could not read file") }
            return
        }
        if (req == R_BEAT) {
            Thread {
                try {
                    val f = File(cacheDir, "beat_src")
                    contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    runOnUiThread { beatsFrom(f.absolutePath, 0f) }
                } catch (e: Exception) { runOnUiThread { toast("Could not read audio") } }
            }.start()
            return
        }
        val name = displayName(uri)
        toast("Importing...")
        Thread {
            try {
                val f = File(Projects.mediaDir(this), System.currentTimeMillis().toString() + "_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread { addMedia(f.absolutePath, when (req) { R_VIDEO -> LayerType.VIDEO; R_GLB -> LayerType.MODEL; R_AUDIOFILE -> LayerType.AUDIO; else -> LayerType.IMAGE }) }
            } catch (e: Exception) { runOnUiThread { toast("Import failed") } }
        }.start()
    }

    private fun addMedia(path: String, type: LayerType) {
        val l = addLayer(type)
        l.imagePath = path
        l.name = File(path).name.substringAfter('_')
        if (type == LayerType.VIDEO || type == LayerType.AUDIO) {
            try {
                val mr = MediaMetadataRetriever()
                mr.setDataSource(path)
                val ms = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                mr.release()
                l.srcDur = ms / 1000f
                val s = Editor.scene
                if (s.layers.size == 1 && l.srcDur > 0.5f) { s.duration = l.srcDur.coerceAtMost(120f) }
                l.end = minOf(s.duration, l.start + l.srcDur.coerceAtLeast(0.5f))
            } catch (e: Exception) { }
        }
        refreshTitle(); refreshPanel(); render()
    }

    private fun exportText(name: String, content: String) {
        try {
            val v = ContentValues()
            v.put(MediaStore.Downloads.DISPLAY_NAME, name)
            v.put(MediaStore.Downloads.MIME_TYPE, "application/json")
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SaikiMotion")
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(content.toByteArray()) }
            toast("Saved to Downloads/SaikiMotion/$name")
        } catch (e: Exception) { toast("Export failed") }
    }

    // ================================================================ panels

    private fun refreshPanel() {
        panelList.removeAllViews()
        rows.clear()
        if (panel == P_NONE) return
        if (panel == P_MEDIA) buildMedia()
        else if (panel == P_SHAPES) buildShapes()
        else {
            val l = selected() ?: run { closePanel(); return }
            when (panel) {
                P_EDIT -> buildEdit(l)
                P_XFORM -> buildXform(l)
                P_FX -> buildFx(l)
                P_BLEND -> buildBlend(l)
                P_SPEED -> buildSpeed(l)
                P_GRAPH -> buildGraph(l)
            }
        }
        syncRows()
    }

    private fun addRow(parent: LinearLayout, l: Layer, d: PropDef, label: String = d.label) {
        if (d.options != null) { addOptionRow(parent, l, d); return }
        val tr = l.track(d.key)
        val s = RulerSlider(this)
        s.label = label; s.lo = d.min; s.hi = d.max; s.dec = d.dec
        s.value = tr.eval(l.editTime(d.key, Editor.time))
        s.onBegin = { pushUndo(); selKey = d.key; syncRows(s) }
        s.onChange = { v -> tr.set(l.editTime(d.key, Editor.time), v, autoKey); syncRows(s); render() }
        s.onLabelTap = { selKey = d.key; syncRows() }
        s.onLabelLong = { showExpression(l, d) }
        put(parent, s, 60)
        rows.add(Row(s, d, l))
    }

    private fun addOptionRow(parent: LinearLayout, l: Layer, d: PropDef) {
        text(parent, d.label, C.TEXT, 14f, true)
        val tr = l.track(d.key)
        parent.addView(chipRow(this, d.options!!, tr.base.toInt()) { i -> pushUndo(); tr.keys.clear(); tr.base = i.toFloat(); refreshPanel(); render() })
    }

    private fun addPlain(parent: LinearLayout, label: String, lo: Float, hi: Float, v: Float, dec: Int, onChange: (Float) -> Unit) {
        val s = RulerSlider(this)
        s.label = label; s.lo = lo; s.hi = hi; s.value = v; s.dec = dec; s.canKey = false
        s.onBegin = { pushUndo() }
        s.onChange = onChange
        put(parent, s, 60)
    }

    private fun syncRows(except: RulerSlider? = null) {
        for (r in rows) {
            val tr = r.layer.track(r.d.key)
            val t = r.layer.editTime(r.d.key, Editor.time)
            if (r.slider !== except) r.slider.value = tr.eval(t)
            r.slider.hasKey = tr.keyAt(t) != null
            r.slider.hasAnim = tr.keys.isNotEmpty()
            r.slider.hasExpr = tr.expr != null
            r.slider.selected = r.d.key == selKey
            r.slider.invalidate()
        }
        diamondSide.set("diamond_f", if (rows.any { it.d.key == selKey && it.slider.hasKey }) C.GREEN else if (rows.any { it.d.key == selKey }) C.TEXT else C.DIM)
    }

    /** Adds or removes a keyframe on the parameter that was tapped last. */
    private fun keySelected() {
        val r = rows.firstOrNull { it.d.key == selKey }
        if (r == null) { toast("Tap a parameter first, then tap the keyframe button"); return }
        pushUndo()
        r.layer.track(r.d.key).toggleKey(r.layer.editTime(r.d.key, Editor.time))
        syncRows(); render()
    }

    private fun colorRow(onPick: (Int) -> Unit): View {
        val colors = intArrayOf(0xFF7C4DFF.toInt(), 0xFFFF4081.toInt(), 0xFFF44336.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(),
            0xFF22C55E.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt())
        val row = hRow()
        for (col in colors) {
            val v = View(this)
            v.setBackgroundColor(col)
            v.setOnClickListener { onPick(col) }
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.setMargins(dp(4), dp(6), dp(4), dp(6))
            row.addView(v, lp)
        }
        val sv = HorizontalScrollView(this)
        sv.addView(row)
        return sv
    }

    // ---------------------------------------------------------------- media + shapes

    private fun buildMedia() {
        val p = panelList
        text(p, "Media", C.TEXT, 16f, true)
        put(p, pill("Import video", "import") { pickFile(R_VIDEO, "video/*") }, 44)
        put(p, pill("Import image", "import") { pickFile(R_IMAGE, "image/*") }, 44)
        put(p, pill("Import audio", "import") { pickFile(R_AUDIOFILE, "audio/*") }, 44)
        put(p, pill("Import 3D model (.glb)", "import") { pickFile(R_GLB, "*/*") }, 44)
        put(p, pill("Beat markers from an audio file", "graph") { pickFile(R_BEAT, "audio/*") }, 44)
        val files = (Projects.mediaDir(this).listFiles() ?: emptyArray()).sortedByDescending { it.lastModified() }.take(12)
        if (files.isNotEmpty()) text(p, "Recent media", C.DIM, 13f)
        for (f in files) {
            val ext = f.extension.lowercase()
            val type = if (ext == "glb") LayerType.MODEL else if (ext in listOf("mp4", "mov", "mkv", "webm", "3gp", "m4v")) LayerType.VIDEO else if (ext in listOf("m4a", "mp3", "aac", "wav", "ogg", "flac")) LayerType.AUDIO else LayerType.IMAGE
            put(p, pill(f.name.substringAfter('_'), if (type == LayerType.VIDEO) "media" else if (type == LayerType.MODEL) "cube" else "media") {
                addMedia(f.absolutePath, type)
            }, 40)
        }
    }

    private fun buildShapes() {
        text(panelList, "Add shape", C.TEXT, 16f, true)
        val names = ShapeKind.values().map { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }
        panelList.addView(chipRow(this, names, -1) { i ->
            val l = addLayer(LayerType.SHAPE)
            l.shape = ShapeKind.values()[i]
            render()
        })
    }

    // ---------------------------------------------------------------- edit

    private fun buildEdit(l: Layer) {
        val p = panelList
        when (l.type) {
            LayerType.TEXT -> {
                text(p, "Text", C.TEXT, 16f, true)
                val et = EditText(this)
                et.setText(l.text)
                et.setTextColor(C.TEXT)
                et.addTextChangedListener(object : android.text.TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: android.text.Editable?) { l.text = s?.toString() ?: ""; render() }
                })
                put(p, et)
                val r = hRow()
                r.addView(pill(if (l.bold) "Bold: on" else "Bold: off") { pushUndo(); l.bold = !l.bold; refreshPanel(); render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
                r.addView(pill(if (l.italic) "Italic: on" else "Italic: off") { pushUndo(); l.italic = !l.italic; refreshPanel(); render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
                put(p, r)
                text(p, "Color", C.DIM)
                p.addView(colorRow { c -> pushUndo(); l.color = c; render() })
                addRow(p, l, Defs.transform[2], "Size")
            }
            LayerType.SHAPE -> {
                text(p, "Shape", C.TEXT, 16f, true)
                val names = ShapeKind.values().map { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }
                p.addView(chipRow(this, names, l.shape.ordinal) { i -> pushUndo(); l.shape = ShapeKind.values()[i]; refreshPanel(); render() })
                text(p, "Color", C.DIM)
                p.addView(colorRow { c -> pushUndo(); l.color = c; render() })
            }
            LayerType.GROUP -> { text(p, "Group", C.TEXT, 16f, true); text(p, "Put layers inside with Parent in their Transform panel. Tap the ^ arrow in the timeline to open or close the group.") }
            LayerType.AUDIO -> {
                text(p, "Audio", C.TEXT, 16f, true); text(p, l.name)
                addRow(p, l, Defs.audio[0])
                put(p, pill("Beat markers from this audio", "graph") { beatsFrom(l.imagePath ?: "", l.start) }, 42)
                text(p, "Plays during preview and is mixed into the render (the first audio layer; AAC or MP3 files work best).", C.DIM, 12f)
            }
            LayerType.ADJUST -> { text(p, "Adjustment layer", C.TEXT, 16f, true); text(p, "Add effects to it in the Effects panel. They apply to everything below it for as long as the layer lasts.") }
            LayerType.CAMERA -> { text(p, "Camera", C.TEXT, 16f, true); addRow(p, l, Defs.camera[0]); text(p, "Position and rotate it in Transform. It controls every layer whose 3D cube is on.") }
            LayerType.NULL -> { text(p, "Null object", C.TEXT, 16f, true); text(p, "An invisible layer. Turn its 3D cube on, then pick it as Parent in other layers' Transform panel.") }
            else -> {
                text(p, l.type.name.lowercase().replaceFirstChar { it.uppercase() }, C.TEXT, 16f, true)
                text(p, l.name)
                if (l.type == LayerType.VIDEO) {
                    text(p, "Length: " + String.format("%.1f", l.srcDur) + " s. Decoded with the system decoder.")
                    put(p, pill("Extract audio", "export") { extractAudio(l) }, 42)
                    put(p, pill("Beat markers from this video", "graph") { beatsFrom(l.imagePath ?: "", l.start) }, 42)
                }
                if (l.type == LayerType.MODEL) text(p, "Static .glb mesh. Transforms are baked on load and everything is drawn from one GPU buffer per part.")
            }
        }
    }

    // ---------------------------------------------------------------- transform

    private fun buildXform(l: Layer) {
        val p = panelList
        val threeD = l.is3d || l.type == LayerType.MODEL || l.type == LayerType.CAMERA
        text(p, "Transform", C.TEXT, 16f, true)
        put(p, pill(if (threeD) "3D layer: on" else "3D layer: off (tap the cube)", "cube", C.CARD2, if (threeD) C.GREEN else C.TEXT) { toggle3d() }, 42)
        if (l.type == LayerType.NULL && !l.is3d) text(p, "This Null is 2D, so it will not move other layers. Turn 3D on.", C.AMBER)
        addRow(p, l, Defs.transform[0]); addRow(p, l, Defs.transform[1])
        if (threeD) addRow(p, l, Defs.pos3d[0])
        if (l.type != LayerType.CAMERA) addRow(p, l, Defs.transform[2])
        addRow(p, l, Defs.transform[4])
        if (threeD) { addRow(p, l, Defs.rot3d[0]); addRow(p, l, Defs.rot3d[1]) }
        if (l.isRenderable()) addRow(p, l, Defs.transform[3])
        val par = Editor.scene.layers.firstOrNull { it.id == l.parentId }
        put(p, pill("Parent: " + (par?.name ?: "None"), "layers") { showParentDialog(l) }, 42)
        val b = hRow()
        for (axis in arrayOf("rotX", "rotY", "rotZ")) {
            if (!threeD && axis != "rotZ") continue
            b.addView(pill("Spin " + axis.last()) { spin(l, axis) }, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        put(p, b)
    }

    private fun spin(l: Layer, key: String) {
        pushUndo()
        val tr = l.track(key)
        tr.keys.clear()
        tr.keys.add(Key(l.start, 0f, Ease.LINEAR)); tr.keys.add(Key(l.end, 360f, Ease.LINEAR))
        refreshPanel(); render()
    }

    private fun showParentDialog(l: Layer) {
        val cands = Editor.scene.layers.filter { it.id != l.id && it.parentId != l.id }
        val names = arrayOf("None") + cands.map { it.name + when (it.type) { LayerType.NULL -> " (Null)"; LayerType.GROUP -> " (Group)"; else -> "" } }
        Dlg(this).setTitle("Parent").setItems(names) { _, w ->
            pushUndo()
            l.parentId = if (w == 0) -1 else cands[w - 1].id
            refreshPanel(); render()
        }.show()
    }

    // ---------------------------------------------------------------- blending + speed

    private fun buildBlend(l: Layer) {
        val p = panelList
        text(p, "Blending", C.TEXT, 16f, true)
        addRow(p, l, Defs.transform[3])
        text(p, "Blend mode", C.DIM)
        p.addView(chipRow(this, listOf("Normal", "Add", "Screen", "Multiply"), l.blend) { i -> pushUndo(); l.blend = i; refreshPanel(); render() })
    }

    private fun buildSpeed(l: Layer) {
        val p = panelList
        text(p, "Speed and Time Remap", C.TEXT, 16f, true)
        val on = l.fx.contains("remap")
        p.addView(chipRow(this, listOf("Normal speed", "Time remap"), if (on) 1 else 0) { i ->
            pushUndo()
            if (i == 1) { if (!l.fx.contains("remap")) l.fx.add("remap"); l.fxOff.remove("remap") } else l.fx.remove("remap")
            refreshPanel(); render()
        })
        if (on) {
            for (d in Registry.get("remap")!!.props) addRow(p, l, d)
            text(p, "Negative speed plays backwards. Loop length repeats the layer. Video layers follow this speed too.")
        }
    }

    // ---------------------------------------------------------------- effects

    private fun buildFx(l: Layer) {
        val p = panelList
        p.addView(chipRow(this, listOf("Applied", "Browse", "Presets", "Custom"), fxTab) { fxTab = it; refreshPanel() })
        when (fxTab) { 0 -> buildApplied(l); 1 -> buildBrowse(l); 2 -> buildPresets(l); else -> buildCustom(l) }
    }

    private fun fxHeader(l: Layer, d: EffectDef): View {
        val key = l.id.toString() + ":" + d.id
        val open = expanded.contains(key)
        val bar = hRow()
        bar.setBackgroundColor(C.CARD)
        bar.addView(IconView(this, "handle", C.DIM, 20f), LinearLayout.LayoutParams(dp(36), dp(48)))
        val t = TextView(this)
        t.text = d.name; t.setTextColor(C.TEXT); t.textSize = 16f; t.typeface = Typeface.DEFAULT_BOLD
        bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        val off = l.fxOff.contains(d.id)
        val eye = IconView(this, if (off) "eye_off" else "eye", if (off) C.DIM else C.GREEN, 20f)
        eye.onClick = { pushUndo(); if (off) l.fxOff.remove(d.id) else l.fxOff.add(d.id); refreshPanel(); render() }
        bar.addView(eye, LinearLayout.LayoutParams(dp(40), dp(48)))
        val chev = IconView(this, if (open) "chev_up" else "chev_down", C.DIM, 20f)
        chev.onClick = { if (!expanded.remove(key)) expanded.add(key); refreshPanel() }
        bar.addView(chev, LinearLayout.LayoutParams(dp(40), dp(48)))
        val del = IconView(this, "trash", C.RED, 20f)
        del.onClick = { pushUndo(); l.fx.remove(d.id); l.fxOff.remove(d.id); refreshPanel(); render() }
        bar.addView(del, LinearLayout.LayoutParams(dp(40), dp(48)))
        return bar
    }

    private fun buildApplied(l: Layer) {
        val p = panelList
        if (l.fx.isEmpty()) text(p, "No effects yet. Tap Add Effect to browse.")
        for (id in l.fx) {
            val d = Registry.get(id) ?: continue
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.addView(fxHeader(l, d))
            if (expanded.contains(l.id.toString() + ":" + id)) {
                text(c, d.desc, C.DIM, 12f)
                Registry.errors[id]?.let { text(c, "Shader error: $it", C.RED, 12f) }
                for (pd in d.props) addRow(c, l, pd)
                if (id == "particles") {
                    text(c, "Birth color", C.DIM); c.addView(colorRow { col -> pushUndo(); l.color = col; render() })
                    text(c, "Death color", C.DIM); c.addView(colorRow { col -> pushUndo(); l.color2 = col; render() })
                }
                for (nm in d.inputs) {
                    val rid = l.inputs[id + ":" + nm]
                    val ref = Editor.scene.layers.firstOrNull { it.id == rid }
                    put(c, pill(nm + " layer: " + (ref?.name ?: "None"), "layers") { showInputDialog(l, d, nm) }, 42)
                }
                if (id == "tile") {
                    val b = hRow()
                    for (axis in arrayOf("tileX", "tileY")) b.addView(pill("Scroll " + axis.last()) { tileScroll(l, axis) }, LinearLayout.LayoutParams(0, dp(40), 1f))
                    c.addView(b)
                }
            }
            put(p, c, 0, 3, 6)
        }
        put(p, pill("Add Effect", "plus", C.GREEN, 0xFF04210F.toInt()) { fxTab = 1; refreshPanel() }, 48, 10, 10)
    }

    private fun tileScroll(l: Layer, key: String) {
        pushUndo()
        val tr = l.track(key)
        val mirror = l.p("tileMirror", Editor.time) >= 0.5f
        tr.keys.clear()
        tr.keys.add(Key(l.start, 0f, Ease.LINEAR)); tr.keys.add(Key(l.end, if (mirror) 2f else 1f, Ease.LINEAR))
        refreshPanel(); render()
    }

    private fun showInputDialog(l: Layer, d: EffectDef, nm: String) {
        val cands = Editor.scene.layers.filter { it.id != l.id && it.isRenderable() && it.type != LayerType.VIDEO && it.type != LayerType.MODEL && it.type != LayerType.PARTICLES }
        val names = arrayOf("None") + cands.map { it.name }
        Dlg(this).setTitle(nm + " layer").setItems(names) { _, w ->
            pushUndo()
            if (w == 0) l.inputs.remove(d.id + ":" + nm) else l.inputs[d.id + ":" + nm] = cands[w - 1].id
            refreshPanel(); render()
        }.show()
    }

    private fun buildBrowse(l: Layer) {
        val p = panelList
        val cats = listOf("All") + Registry.order.map { it.category }.distinct()
        p.addView(chipRow(this, cats, fxCat) { fxCat = it; refreshPanel() })
        val list = Registry.order.filter { fxCat == 0 || it.category == cats[fxCat] }
        if (list.any { !EffectThumbs.ready(it.id) }) EffectThumbs.generate(this) { if (panel == P_FX && fxTab == 1) refreshPanel() }
        var i = 0
        while (i < list.size) {
            val r = hRow()
            for (j in 0 until 2) {
                if (i + j >= list.size) { r.addView(View(this), LinearLayout.LayoutParams(0, dp(170), 1f)); continue }
                val d = list[i + j]
                val card = EffectCard(this, d.name, d.category)
                card.before = EffectThumbs.cache["__orig"]
                card.after = EffectThumbs.cache[d.id]
                card.badge = l.fx.contains(d.id)
                card.onClick = { showEffectInfo(d, l) }
                val lp = LinearLayout.LayoutParams(0, dp(170), 1f)
                lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                r.addView(card, lp)
            }
            p.addView(r)
            i += 2
        }
    }

    private fun showEffectInfo(d: EffectDef, l: Layer) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val card = EffectCard(this, d.name, d.category)
        card.before = EffectThumbs.cache["__orig"]; card.after = EffectThumbs.cache[d.id]
        box.addView(card, LinearLayout.LayoutParams(MATCH, dp(280)))
        val info = TextView(this)
        val sb = StringBuilder(d.desc).append("\n\nParameters: ")
        sb.append(if (d.props.isEmpty()) "none" else d.props.joinToString(", ") { it.label })
        if (d.inputs.isNotEmpty()) sb.append("\nLayer inputs: ").append(d.inputs.joinToString(", "))
        if (!d.builtin) sb.append("\nCustom effect")
        Registry.errors[d.id]?.let { sb.append("\n\nShader error:\n").append(it) }
        info.text = sb.toString()
        info.setPadding(0, dp(10), 0, 0)
        box.addView(info)
        val b = Dlg(this).setTitle(d.name).setView(ScrollView(this).also { it.addView(box) })
            .setPositiveButton("Add to layer") { _, _ ->
                pushUndo()
                if (!l.fx.contains(d.id)) l.fx.add(d.id)
                l.fxOff.remove(d.id)
                expanded.add(l.id.toString() + ":" + d.id)
                fxTab = 0; refreshPanel(); render()
            }.setNegativeButton("Close", null)
        if (!d.builtin) b.setNeutralButton("Export") { _, _ -> exportText(d.id + ".saikieffect.json", Registry.toJson(d).toString(2)) }
        b.show()
    }

    private fun buildPresets(l: Layer) {
        val p = panelList
        put(p, pill("Save current effects as preset", "plus", C.GREEN, 0xFF04210F.toInt()) {
            if (l.fx.isEmpty()) { toast("Add an effect first"); return@pill }
            val et = EditText(this)
            et.setText("My preset")
            Dlg(this).setTitle("Preset name").setView(et).setPositiveButton("Save") { _, _ ->
                Registry.savePreset(this, Registry.capturePreset(l, et.text.toString().ifBlank { "My preset" }, Editor.time))
                refreshPanel()
            }.show()
        }, 44)
        put(p, pill("Import preset file", "import") { pickFile(R_PRESET, "*/*") }, 44)
        for (pr in Registry.presets(this)) {
            text(p, pr.name + if (pr.builtin) "  (built in)" else "", C.TEXT, 15f, true)
            val r = hRow()
            r.addView(pill("Apply") { pushUndo(); Registry.applyPreset(l, pr.json); fxTab = 0; refreshPanel(); render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill("Export") { exportText(pr.name + ".saikipreset.json", pr.json.toString(2)) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            if (!pr.builtin) r.addView(pill("Delete", null, C.CARD2, C.RED) { Registry.deletePreset(this, pr.name); refreshPanel() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            put(p, r)
        }
    }

    private fun buildCustom(l: Layer) {
        val p = panelList
        put(p, pill("Import effect file", "import") { pickFile(R_FX, "*/*") }, 44)
        put(p, pill("Create your own effect", "plus", C.GREEN, 0xFF04210F.toInt()) { showCreateEffect() }, 44)
        text(p, "An effect is a JSON file with: name, description, params (name, label, min, max, def) and code. The code defines vec4 effect(vec2 uv) and may call src(uv), in0(uv), in1(uv), luma(), hash21(), fbm(), rot(), hsv2rgb() and use uTime and uRes. Every effect gets an auto-rendered animated icon.", C.DIM, 12f)
        val custom = Registry.order.filter { !it.builtin }
        if (custom.isEmpty()) text(p, "No custom effects yet.")
        for (d in custom) {
            text(p, d.name, C.TEXT, 15f, true)
            text(p, d.desc, C.DIM, 12f)
            val r = hRow()
            r.addView(pill("Info") { showEffectInfo(d, l) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill("Export") { exportText(d.id + ".saikieffect.json", Registry.toJson(d).toString(2)) }, LinearLayout.LayoutParams(0, dp(40), 1f))
            r.addView(pill("Delete", null, C.CARD2, C.RED) { Registry.deleteCustom(this, d.id); EffectThumbs.cache.remove(d.id); refreshPanel() }, LinearLayout.LayoutParams(0, dp(40), 1f))
            put(p, r)
        }
    }

    private fun showCreateEffect() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        fun field(hint: String, init: String, lines: Int): EditText {
            val e = EditText(this)
            e.hint = hint; e.setText(init); e.textSize = 13f
            if (lines > 1) { e.minLines = lines; e.gravity = Gravity.TOP }
            box.addView(e)
            return e
        }
        val name = field("Name", "My Effect", 1)
        val desc = field("Description", "Mixes the image with grayscale.", 1)
        val params = field("Parameters, one per line: name,label,min,max,default", "amount,Amount,0,1,1", 3)
        val code = field("GLSL code", "vec4 effect(vec2 uv) {\n  vec4 c = src(uv);\n  return vec4(mix(c.rgb, vec3(luma(c.rgb)) * c.a, amount), c.a);\n}", 8)
        Dlg(this).setTitle("Create effect").setView(ScrollView(this).also { it.addView(box) })
            .setPositiveButton("Create") { _, _ ->
                try {
                    val pa = JSONArray()
                    for (line in params.text.toString().lines()) {
                        val f = line.split(",").map { it.trim() }
                        if (f.size >= 5) pa.put(JSONObject().put("name", f[0]).put("label", f[1]).put("min", f[2].toDouble()).put("max", f[3].toDouble()).put("def", f[4].toDouble()))
                    }
                    val o = JSONObject().put("name", name.text.toString()).put("description", desc.text.toString()).put("params", pa).put("code", code.text.toString())
                    val err = Registry.addCustom(this, o.toString())
                    if (err != null) toast(err) else { toast("Effect created"); EffectThumbs.generate(this) { refreshPanel() }; refreshPanel() }
                } catch (e: Exception) { toast("Check the parameter lines") }
            }.setNegativeButton("Cancel", null).show()
    }

    // ---------------------------------------------------------------- graph

    private fun buildGraph(l: Layer) {
        val p = panelList
        text(p, "Bezier graph", C.TEXT, 16f, true)
        val animated = l.props.filter { it.value.keys.size >= 2 }.keys.toList()
        if (animated.isEmpty()) { text(p, "Add two keyframes to a property (tap its label or use the diamond), then edit the curve here."); return }
        if (graphProp !in animated) { graphProp = animated[0]; graphKey = 0 }
        p.addView(chipRow(this, animated.map { Registry.propDef(it)?.label ?: it }, animated.indexOf(graphProp)) { graphProp = animated[it]; graphKey = 0; refreshPanel() })
        val tr = l.track(graphProp)
        graphKey = graphKey.coerceIn(0, tr.keys.size - 2)
        p.addView(chipRow(this, (0 until tr.keys.size - 1).map { "Segment " + (it + 1) }, graphKey) { graphKey = it; refreshPanel() })
        val g = GraphView(this)
        g.key = tr.keys[graphKey]
        g.onBegin = { pushUndo() }
        g.onChange = { render() }
        put(p, g, 220)
        p.addView(chipRow(this, listOf("Linear", "Ease In", "Ease Out", "Ease In-Out", "Bounce"), -1) { i ->
            pushUndo()
            tr.keys[graphKey].preset(listOf(Ease.LINEAR, Ease.EASE_IN, Ease.EASE_OUT, Ease.EASE_IN_OUT, Ease.BOUNCE)[i])
            refreshPanel(); render()
        })
        put(p, pill("Copy this curve to all segments") {
            pushUndo()
            val s = tr.keys[graphKey]
            for (k in tr.keys) { k.ease = s.ease; k.x1 = s.x1; k.y1 = s.y1; k.x2 = s.x2; k.y2 = s.y2 }
            render()
        }, 42)
        text(p, "Drag the two white handles. Pull a handle above 1 for overshoot.", C.DIM, 12f)
    }

    private fun showPanelMenu() {
        val l = selected() ?: return
        Dlg(this).setTitle("Layer").setItems(arrayOf("Clear all keyframes", "Reset transform", "Snap keyframes to beat markers")) { _, which ->
            pushUndo()
            if (which == 2) snapKeys(l)
            else for ((k, tr) in l.props) {
                if (which == 0) { tr.keys.clear(); tr.setExpr("") }
                else if (Defs.transform.any { it.key == k } || Defs.rot3d.any { it.key == k } || k == "z") { tr.keys.clear(); tr.base = Registry.propDef(k)?.def ?: 0f }
            }
            refreshPanel(); render()
        }.show()
    }

    // ================================================================ scenes + export

    private fun showSceneDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val dlg = Dlg(this).setTitle("Scene setup").setView(ScrollView(this).also { it.addView(box) }).setPositiveButton("Done", null).create()
        fun build() {
            box.removeAllViews()
            val pr = Editor.project
            val s = Editor.scene
            text(box, Projects.resLabel(pr.w, pr.h) + "  ·  " + pr.w + " x " + pr.h + "  ·  " + pr.fps + " fps", C.DIM)
            text(box, "Guides", C.GREEN, 13f, true)
            box.addView(chipRow(this, listOf("Off", "On"), if (overlay.guides) 1 else 0) { overlay.guides = it == 1; overlay.invalidate(); build() })
            text(box, "Scenes", C.GREEN, 13f, true)
            box.addView(chipRow(this, pr.scenes.map { it.name } + listOf("New scene"), Editor.sceneIndex) { i ->
                pushUndo()
                if (i == pr.scenes.size) { pr.scenes.add(Scene("Scene " + (pr.scenes.size + 1))); Editor.sceneIndex = pr.scenes.size - 1 } else Editor.sceneIndex = i
                Editor.time = 0f; selectedId = -1; panel = P_NONE; refreshAll(); build()
            })
            if (pr.scenes.size > 1) put(box, pill("Delete this scene", null, C.CARD2, C.RED) {
                pushUndo(); pr.scenes.remove(s); Editor.sceneIndex = 0; Editor.time = 0f; selectedId = -1; panel = P_NONE; refreshAll(); build()
            }, 40)
            val d = RulerSlider(this)
            d.label = "Duration (s)"; d.lo = 1f; d.hi = 120f; d.value = s.duration; d.dec = 1; d.canKey = false
            d.onChange = { v ->
                val old = s.duration
                s.duration = maxOf(1f, Math.round(v * 2f) / 2f)
                for (l in s.layers) if (l.end >= old - 0.001f) l.end = s.duration
                Editor.time = Editor.time.coerceIn(0f, s.duration); onTimeChanged()
            }
            put(box, d, 60, 8, 4)
            val f = RulerSlider(this)
            f.label = "Scene FOV"; f.lo = 15f; f.hi = 90f; f.value = s.fov; f.dec = 0; f.canKey = false
            f.onChange = { v -> s.fov = v; render() }
            put(box, f, 60)
            text(box, "Background", C.GREEN, 13f, true)
            box.addView(colorRow { c -> s.bg = c; render() })
        }
        build()
        dlg.show()
    }

    private fun showRenderDialog() {
        if (playing) togglePlay()
        val p = Editor.project
        val scales = floatArrayOf(1f, 0.75f, 0.5f)
        var q = 0
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(4), dp(4), dp(4))
        fun build() {
            box.removeAllViews()
            val sc = scales[q]
            val w = (p.w * sc / 2f).toInt() * 2
            val h = (p.h * sc / 2f).toInt() * 2
            var dur = 0f
            for (s in p.scenes) dur += s.duration
            val mb = w.toLong() * h * p.fps / 9L * dur / 8f / 1048576f
            text(box, "Output", C.GREEN, 13f, true)
            text(box, w.toString() + " x " + h + "  ·  " + p.fps + " fps  ·  " + String.format("%.1f", dur) + " s", C.TEXT, 16f)
            text(box, "About " + String.format("%.0f", mb) + " MB. Saved to Movies/SaikiMotion", C.DIM, 13f)
            text(box, "Size", C.GREEN, 13f, true)
            box.addView(chipRow(this, listOf("Full size", "3/4 size", "1/2 size"), q) { q = it; build() })
        }
        build()
        Dlg(this).setTitle("Render video").setView(box).setPositiveButton("Render") { _, _ -> startRender(scales[q]) }.setNegativeButton("Cancel", null).show()
    }

    private fun startRender(scale: Float) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(4), dp(4), dp(4), dp(8))
        val st = text(box, "Starting...", C.TEXT, 15f)
        val pb = ProgressBarView(this)
        put(box, pb, 12, 10, 6)
        var ref: Exporter? = null
        val dlg = Dlg(this).setTitle("Rendering").setView(box).setCancelable(false).setNegativeButton("Cancel") { _, _ -> ref?.cancel() }.show()
        val ex = Exporter(applicationContext, Editor.project,
            { pct -> runOnUiThread { pb.progress = pct / 100f; st.text = "Rendering " + pct + "%" } },
            { loc, err -> runOnUiThread { dlg.dismiss(); if (err != null) toast(if (err == "Cancelled") "Render cancelled" else "Render failed: " + err) else toast("Saved to " + loc) } }, scale)
        ref = ex
        ex.start()
    }
}
