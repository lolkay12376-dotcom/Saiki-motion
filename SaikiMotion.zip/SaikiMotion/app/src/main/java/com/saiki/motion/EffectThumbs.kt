package com.saiki.motion

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.GLES20
import android.os.Handler
import android.os.Looper
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap

/**
 * Renders every effect once on the bundled anime portrait using the real shaders,
 * so the swipe icons always show the true before/after result (and custom effects too).
 */
object EffectThumbs {
    val cache = ConcurrentHashMap<String, Bitmap>()
    @Volatile private var running = false
    @Volatile var lastError = ""
    private const val W = 192
    private const val H = 256

    fun ready(id: String) = cache.containsKey(id) && cache.containsKey("__orig")

    fun portraitFile(ctx: Context): File {
        val f = File(ctx.cacheDir, "anime_portrait.jpg")
        if (!f.exists()) ctx.resources.openRawResource(R.drawable.anime_portrait).use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f
    }

    /** Generates missing thumbnails on a worker thread, then calls [done] on the main thread. */
    fun generate(ctx: Context, done: () -> Unit) {
        if (running) return
        val todo = (if (cache.containsKey("__orig")) emptyList() else listOf("__orig")) + Registry.order.map { it.id }.filter { !cache.containsKey(it) }
        if (todo.isEmpty()) { done(); return }
        running = true
        val app = ctx.applicationContext
        Thread {
            try { render(app, todo) } catch (e: Throwable) { lastError = (e.message ?: e.toString()).take(160) }
            running = false
            Handler(Looper.getMainLooper()).post { done() }
        }.start()
    }

    private fun render(ctx: Context, ids: List<String>) {
        val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        EGL14.eglInitialize(dpy, ver, 0, ver, 1)
        val attribs = intArrayOf(EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_DEPTH_SIZE, 16, EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE)
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attribs, 0, cfgs, 0, 1, n, 0)
        if (n[0] == 0) EGL14.eglChooseConfig(dpy, intArrayOf(EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE), 0, cfgs, 0, 1, n, 0)
        val eglCtx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        val surf = EGL14.eglCreatePbufferSurface(dpy, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, W, EGL14.EGL_HEIGHT, H, EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, surf, surf, eglCtx)
        val sr = SceneRenderer()
        try {
            sr.init()
            val proj = Project()
            proj.w = W; proj.h = H
            val sc = proj.scenes[0]
            sc.duration = 5f
            val l = Layer(1, "portrait", LayerType.IMAGE)
            l.imagePath = portraitFile(ctx).absolutePath
            l.end = 5f
            sc.layers.add(l)
            val buf = ByteBuffer.allocateDirect(W * H * 4).order(ByteOrder.nativeOrder())
            for (id in ids) try {
                l.fx.clear()
                if (id != "__orig") l.fx.add(id)
                val t = if (id == "swing") 0.45f else 0.7f
                sr.draw(proj, sc, t, W, H)
                if (id != "__orig") sr.draw(proj, sc, t, W, H)
                GLES20.glReadPixels(0, 0, W, H, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
                val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
                buf.position(0)
                bmp.copyPixelsFromBuffer(buf)
                val m = Matrix()
                m.preScale(1f, -1f)
                cache[id] = Bitmap.createBitmap(bmp, 0, 0, W, H, m, false)
                bmp.recycle()
            } catch (e: Throwable) {
                lastError = (id + ": " + (e.message ?: e.toString())).take(160)
                cache[id] = cache["__orig"] ?: continue
            }
        } finally {
            sr.release()
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(dpy, surf)
            EGL14.eglDestroyContext(dpy, eglCtx)
            EGL14.eglTerminate(dpy)
        }
    }
}
