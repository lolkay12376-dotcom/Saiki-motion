package com.saiki.motion

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLExt
import android.os.Environment
import android.provider.MediaStore
import android.media.MediaExtractor
import java.io.File
import java.nio.ByteBuffer
import java.io.FileInputStream
import java.io.IOException

/** Renders every scene offscreen into an H.264 MP4 and saves it to Movies/SaikiMotion. */
class Exporter(
    private val ctx: Context,
    private val project: Project,
    private val onProgress: (Int) -> Unit,
    private val onDone: (String?, String?) -> Unit,
    private val scale: Float = 1f
) {
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var muxStarted = false
    @Volatile private var cancelled = false
    private var audioEx: MediaExtractor? = null
    private var audioFmt: MediaFormat? = null
    private var audioTrackOut = -1
    fun cancel() { cancelled = true }

    fun start() { Thread { run() }.start() }

    private fun run() {
        val out = File(ctx.cacheDir, "export_" + System.currentTimeMillis() + ".mp4")
        try {
            encode(out)
            val where = saveToGallery(out)
            onDone(where, null)
        } catch (e: Throwable) {
            onDone(null, e.message ?: e.toString())
        } finally {
            out.delete()
        }
    }

    private fun encode(out: File) {
        val w = (project.w * scale / 2f).toInt() * 2
        val h = (project.h * scale / 2f).toInt() * 2
        val fps = project.fps
        fun makeFormat(mime: String): MediaFormat {
            val f = MediaFormat.createVideoFormat(mime, w, h)
            f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            f.setInteger(MediaFormat.KEY_BIT_RATE, (w.toLong() * h * fps / 9).toInt().coerceIn(2_000_000, 100_000_000))
            f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            return f
        }
        val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)
        var mime = MediaFormat.MIMETYPE_VIDEO_AVC
        var fmt = makeFormat(mime)
        if (list.findEncoderForFormat(fmt) == null) {
            mime = MediaFormat.MIMETYPE_VIDEO_HEVC
            fmt = makeFormat(mime)
            if (list.findEncoderForFormat(fmt) == null)
                throw IOException("This device cannot encode " + w + "x" + h + " at " + fps + " fps. Pick a lower resolution or frame rate.")
        }
        val enc = MediaCodec.createEncoderByType(mime)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = enc.createInputSurface()
        enc.start()
        var audioPath: String? = null
        var audioOffsetUs = 0L
        var audioEndUs = 0L
        var audioSrcUs = 0L
        var accT = 0f
        for (s in project.scenes) {
            if (audioPath == null) for (l in s.layers) if (l.type == LayerType.AUDIO && l.visible && l.imagePath != null) {
                audioPath = l.imagePath
                audioSrcUs = (l.srcOffset * 1_000_000f).toLong()
                audioOffsetUs = ((accT + l.start) * 1_000_000f).toLong()
                audioEndUs = ((accT + l.end) * 1_000_000f).toLong()
                break
            }
            accT += s.duration
        }
        if (audioPath != null) prepareAudio(audioPath)
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        EGL14.eglInitialize(dpy, ver, 0, ver, 1)
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_DEPTH_SIZE, 16, EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            0x3142, 1, // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attribs, 0, cfgs, 0, 1, n, 0)
        val eglCtx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        val surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], inputSurface, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, surf, surf, eglCtx)

        try {
            val sr = SceneRenderer()
            sr.init()
            var total = 0
            for (s in project.scenes) total += (s.duration * fps).toInt()
            if (total < 1) total = 1
            var frame = 0
            for (s in project.scenes) {
                val count = (s.duration * fps).toInt()
                for (f in 0 until count) {
                    if (cancelled) throw IOException("Cancelled")
                    sr.draw(project, s, f.toFloat() / fps, w, h)
                    EGLExt.eglPresentationTimeANDROID(dpy, surf, frame * 1_000_000_000L / fps)
                    EGL14.eglSwapBuffers(dpy, surf)
                    drain(enc, muxer, false)
                    frame++
                    onProgress(frame * 100 / total)
                }
            }
            enc.signalEndOfInputStream()
            drain(enc, muxer, true)
            writeAudio(muxer, audioOffsetUs, audioEndUs, total.toLong() * 1_000_000L / fps, audioSrcUs)
            sr.release()
        } finally {
            try { enc.stop() } catch (e: Exception) { }
            enc.release()
            try { if (muxStarted) muxer.stop() } catch (e: Exception) { }
            muxer.release()
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(dpy, surf)
            EGL14.eglDestroyContext(dpy, eglCtx)
            EGL14.eglTerminate(dpy)
            inputSurface.release()
            try { audioEx?.release() } catch (e: Exception) { }
        }
    }

    private fun prepareAudio(path: String) {
        try {
            val ex = MediaExtractor()
            ex.setDataSource(path)
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { ex.selectTrack(i); audioEx = ex; audioFmt = f; return }
            }
            ex.release()
        } catch (e: Exception) { audioEx = null; audioFmt = null }
    }

    private fun writeAudio(muxer: MediaMuxer, offsetUs: Long, endUs: Long, totalUs: Long, srcUs: Long) {
        val ex = audioEx ?: return
        if (audioTrackOut < 0) return
        val buf = ByteBuffer.allocate(1 shl 18)
        val bi = MediaCodec.BufferInfo()
        val limit = minOf(endUs, totalUs)
        while (true) {
            val n = ex.readSampleData(buf, 0)
            if (n < 0) break
            val st = ex.sampleTime
            if (st < srcUs) { ex.advance(); continue }
            val pts = st - srcUs + offsetUs
            if (pts > limit) break
            if (pts >= 0) { bi.set(0, n, pts, ex.sampleFlags); muxer.writeSampleData(audioTrackOut, buf, bi) }
            ex.advance()
        }
    }

    private fun drain(enc: MediaCodec, muxer: MediaMuxer, end: Boolean) {
        while (true) {
            val idx = enc.dequeueOutputBuffer(info, 10_000)
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!end) return
            } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = muxer.addTrack(enc.outputFormat)
                val af = audioFmt
                if (af != null) { try { audioTrackOut = muxer.addTrack(af) } catch (e: Exception) { audioTrackOut = -1 } }
                muxer.start()
                muxStarted = true
            } else if (idx >= 0) {
                val buf = enc.getOutputBuffer(idx)
                if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                if (buf != null && info.size > 0 && muxStarted) {
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    muxer.writeSampleData(track, buf, info)
                }
                enc.releaseOutputBuffer(idx, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }
    }

    private fun saveToGallery(f: File): String {
        val values = ContentValues()
        values.put(MediaStore.Video.Media.DISPLAY_NAME, "SaikiMotion_" + System.currentTimeMillis() + ".mp4")
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SaikiMotion")
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Could not create output file")
        val os = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("Could not open output")
        os.use { o -> FileInputStream(f).use { it.copyTo(o) } }
        return "Movies/SaikiMotion"
    }
}
