package com.saiki.motion

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** One part of a lens flare: a glow, ring, streak, rays, polygon, hoop or orb placed along the flare axis. */
class FlareEl(var type: Int = 0) {
    var name = ""
    var enabled = true
    var pos = 1f          // 0 = at the light, 1 = screen center, 2 = opposite side of the light
    var size = 0.3f       // radius, in screen half-heights
    var stretch = 1f      // width / height of the element
    var rot = 0f
    var bright = 1f
    var color = 0xFFFFFFFF.toInt()
    var soft = 0.5f
    var thick = 0.15f
    var sides = 6
    var rays = 8
    var chroma = 0f
    var follow = false    // turns with the flare axis

    fun label(): String = if (name.isNotBlank()) name else TYPES.getOrElse(type) { "Element" }

    fun copy(): FlareEl {
        val c = FlareEl(type)
        c.name = name; c.enabled = enabled; c.pos = pos; c.size = size; c.stretch = stretch; c.rot = rot; c.bright = bright
        c.color = color; c.soft = soft; c.thick = thick; c.sides = sides; c.rays = rays; c.chroma = chroma; c.follow = follow
        return c
    }

    fun toJson(): JSONObject = JSONObject().put("type", type).put("name", name).put("on", enabled).put("pos", pos.toDouble())
        .put("size", size.toDouble()).put("stretch", stretch.toDouble()).put("rot", rot.toDouble()).put("bright", bright.toDouble())
        .put("color", color).put("soft", soft.toDouble()).put("thick", thick.toDouble()).put("sides", sides).put("rays", rays)
        .put("chroma", chroma.toDouble()).put("follow", follow)

    companion object {
        val TYPES = listOf("Glow", "Ring", "Streak", "Rays", "Polygon", "Hoop", "Orb")
        fun fromJson(o: JSONObject): FlareEl {
            val e = FlareEl(o.optInt("type", 0).coerceIn(0, TYPES.size - 1))
            e.name = o.optString("name", ""); e.enabled = o.optBoolean("on", true)
            e.pos = o.optDouble("pos", 1.0).toFloat(); e.size = o.optDouble("size", 0.3).toFloat()
            e.stretch = o.optDouble("stretch", 1.0).toFloat(); e.rot = o.optDouble("rot", 0.0).toFloat()
            e.bright = o.optDouble("bright", 1.0).toFloat(); e.color = o.optInt("color", 0xFFFFFFFF.toInt())
            e.soft = o.optDouble("soft", 0.5).toFloat(); e.thick = o.optDouble("thick", 0.15).toFloat()
            e.sides = o.optInt("sides", 6); e.rays = o.optInt("rays", 8); e.chroma = o.optDouble("chroma", 0.0).toFloat()
            e.follow = o.optBoolean("follow", false)
            return e
        }
    }
}

/** A complete optical flare: its elements plus the settings shared by all of them. */
class Flare {
    var name = "Custom"
    val els = ArrayList<FlareEl>()
    var tint = 0xFFFFFFFF.toInt()
    var depthScale = 1f   // how much the flare shrinks and grows with distance from the camera (3D layers)
    var edgeFade = 0.3f   // how far past the screen edge the light can go before the flare fades out

    fun copy(): Flare {
        val f = Flare()
        f.name = name; f.tint = tint; f.depthScale = depthScale; f.edgeFade = edgeFade
        for (e in els) f.els.add(e.copy())
        return f
    }

    fun toJson(): JSONObject {
        val a = JSONArray()
        for (e in els) a.put(e.toJson())
        return JSONObject().put("name", name).put("tint", tint).put("depthScale", depthScale.toDouble()).put("edgeFade", edgeFade.toDouble()).put("els", a)
    }

    fun sig(): String = name + "|" + toJson().toString().hashCode()

    companion object {
        fun fromJson(o: JSONObject): Flare {
            val f = Flare()
            f.name = o.optString("name", "Custom"); f.tint = o.optInt("tint", 0xFFFFFFFF.toInt())
            f.depthScale = o.optDouble("depthScale", 1.0).toFloat(); f.edgeFade = o.optDouble("edgeFade", 0.3).toFloat()
            val a = o.optJSONArray("els")
            if (a != null) for (i in 0 until a.length()) f.els.add(FlareEl.fromJson(a.getJSONObject(i)))
            return f
        }

        private fun el(type: Int, pos: Float, size: Float, color: Int, bright: Float = 1f, cfg: FlareEl.() -> Unit = {}): FlareEl {
            val e = FlareEl(type)
            e.pos = pos; e.size = size; e.color = color; e.bright = bright
            e.cfg()
            return e
        }

        private fun make(name: String, vararg els: FlareEl): Flare {
            val f = Flare()
            f.name = name
            f.els.addAll(els)
            return f
        }

        fun default(): Flare = builtin()[0].copy().also { it.name = "Custom" }

        fun builtin(): List<Flare> = listOf(
            make("Sun",
                el(0, 0f, 0.7f, 0xFFFFE2A8.toInt(), 0.9f) { soft = 0.6f },
                el(0, 0f, 0.16f, 0xFFFFFFFF.toInt(), 1.4f),
                el(3, 0f, 0.95f, 0xFFFFD79A.toInt(), 0.45f) { rays = 14; soft = 0.55f },
                el(2, 0f, 1.1f, 0xFFFFC98A.toInt(), 0.5f) { stretch = 9f; thick = 0.05f },
                el(1, 1f, 0.42f, 0xFFFFFFFF.toInt(), 0.3f) { thick = 0.05f; chroma = 0.7f },
                el(4, 0.55f, 0.1f, 0xFFFFB347.toInt(), 0.5f) { sides = 6; thick = 1f },
                el(4, 1.35f, 0.16f, 0xFF7DF9FF.toInt(), 0.4f) { sides = 6; thick = 1f },
                el(4, 1.9f, 0.3f, 0xFFB388FF.toInt(), 0.3f) { sides = 6; thick = 0.12f },
                el(0, 1.2f, 0.25f, 0xFF9CFF9C.toInt(), 0.2f)),
            make("Anamorphic Blue",
                el(2, 0f, 1.7f, 0xFF66B3FF.toInt(), 1.2f) { stretch = 14f; thick = 0.03f; soft = 0.7f },
                el(2, 0f, 0.8f, 0xFFFFFFFF.toInt(), 0.45f) { stretch = 8f; thick = 0.02f },
                el(0, 0f, 0.32f, 0xFF4D94FF.toInt(), 1f),
                el(0, 0f, 0.1f, 0xFFFFFFFF.toInt(), 1.5f),
                el(6, 0.7f, 0.04f, 0xFF66B3FF.toInt(), 0.7f),
                el(6, 1.3f, 0.07f, 0xFF99CCFF.toInt(), 0.6f),
                el(6, 1.7f, 0.03f, 0xFFFFFFFF.toInt(), 0.6f)),
            make("Cinematic Gold",
                el(0, 0f, 0.5f, 0xFFFFC857.toInt(), 1f) { soft = 0.7f },
                el(2, 0f, 1.4f, 0xFFFFB300.toInt(), 0.9f) { stretch = 12f; thick = 0.04f },
                el(3, 0f, 0.7f, 0xFFFFE08A.toInt(), 0.4f) { rays = 6; soft = 0.5f },
                el(5, 1f, 0.5f, 0xFFFFD27F.toInt(), 0.35f) { thick = 0.08f; chroma = 0.4f },
                el(4, 0.8f, 0.09f, 0xFFFFA726.toInt(), 0.5f) { sides = 8; thick = 1f },
                el(4, 1.5f, 0.13f, 0xFFFFCC80.toInt(), 0.4f) { sides = 8; thick = 1f }),
            make("Lens Chain",
                el(0, 0f, 0.3f, 0xFFFFFFFF.toInt(), 1f),
                el(4, 0.35f, 0.06f, 0xFFFF8A80.toInt(), 0.6f) { sides = 6; thick = 1f },
                el(4, 0.6f, 0.11f, 0xFFFFF59D.toInt(), 0.5f) { sides = 6; thick = 1f },
                el(4, 0.95f, 0.07f, 0xFF80D8FF.toInt(), 0.6f) { sides = 6; thick = 1f },
                el(4, 1.3f, 0.16f, 0xFFB388FF.toInt(), 0.45f) { sides = 6; thick = 0.2f },
                el(4, 1.6f, 0.08f, 0xFF69F0AE.toInt(), 0.55f) { sides = 6; thick = 1f },
                el(4, 1.95f, 0.2f, 0xFFFFAB40.toInt(), 0.4f) { sides = 6; thick = 0.15f }),
            make("Neon Hoops",
                el(0, 0f, 0.35f, 0xFFFF4DFF.toInt(), 1f),
                el(5, 0.5f, 0.3f, 0xFF00E5FF.toInt(), 1f) { thick = 0.12f; chroma = 0.5f },
                el(5, 1f, 0.55f, 0xFFFF4081.toInt(), 0.9f) { thick = 0.08f; chroma = 0.6f },
                el(5, 1.6f, 0.22f, 0xFF76FF03.toInt(), 0.9f) { thick = 0.15f },
                el(6, 0.2f, 0.05f, 0xFFFFFFFF.toInt(), 0.8f)),
            make("Star Burst",
                el(3, 0f, 1.1f, 0xFFFFFFFF.toInt(), 0.9f) { rays = 24; soft = 0.7f },
                el(0, 0f, 0.35f, 0xFFFFFFFF.toInt(), 1.1f),
                el(2, 0f, 1.3f, 0xFFFFFFFF.toInt(), 0.8f) { stretch = 10f; thick = 0.03f },
                el(2, 0f, 1.3f, 0xFFBBDDFF.toInt(), 0.6f) { stretch = 10f; thick = 0.03f; rot = 90f },
                el(0, 0f, 0.1f, 0xFFFFFFFF.toInt(), 1.6f)),
            make("Soft Bokeh",
                el(0, 0f, 0.6f, 0xFFFFE9C7.toInt(), 0.7f) { soft = 0.9f },
                el(4, 0.5f, 0.2f, 0xFFFFD1A0.toInt(), 0.25f) { sides = 12; thick = 1f; soft = 0.6f },
                el(4, 0.9f, 0.32f, 0xFFFFB7B7.toInt(), 0.2f) { sides = 12; thick = 1f; soft = 0.6f },
                el(4, 1.4f, 0.18f, 0xFFBDE0FF.toInt(), 0.25f) { sides = 12; thick = 1f; soft = 0.6f },
                el(4, 1.8f, 0.4f, 0xFFD7BDFF.toInt(), 0.18f) { sides = 12; thick = 1f; soft = 0.6f }),
            make("Cold Moon",
                el(0, 0f, 0.45f, 0xFFB9D7FF.toInt(), 0.9f) { soft = 0.8f },
                el(0, 0f, 0.12f, 0xFFFFFFFF.toInt(), 1.2f),
                el(1, 0f, 0.6f, 0xFF9CC4FF.toInt(), 0.35f) { thick = 0.03f; soft = 0.8f },
                el(1, 1.1f, 0.35f, 0xFFB9D7FF.toInt(), 0.25f) { thick = 0.03f },
                el(6, 0.7f, 0.04f, 0xFFD6E6FF.toInt(), 0.5f),
                el(6, 1.5f, 0.06f, 0xFFD6E6FF.toInt(), 0.45f)),
            make("Sci-Fi Scan",
                el(2, 0f, 1.6f, 0xFF00E5FF.toInt(), 1f) { stretch = 16f; thick = 0.02f },
                el(2, 0f, 1f, 0xFFFFFFFF.toInt(), 0.5f) { stretch = 12f; thick = 0.015f },
                el(0, 0f, 0.22f, 0xFF00E5FF.toInt(), 1f),
                el(1, 0.6f, 0.18f, 0xFF00E5FF.toInt(), 0.7f) { thick = 0.06f },
                el(6, 1f, 0.05f, 0xFFFFFFFF.toInt(), 0.8f),
                el(6, 1.2f, 0.05f, 0xFF00E5FF.toInt(), 0.8f),
                el(6, 1.4f, 0.05f, 0xFFFFFFFF.toInt(), 0.8f)),
            make("Minimal",
                el(0, 0f, 0.35f, 0xFFFFFFFF.toInt(), 1f) { soft = 0.7f },
                el(0, 0f, 0.09f, 0xFFFFFFFF.toInt(), 1.3f),
                el(1, 1f, 0.3f, 0xFFFFFFFF.toInt(), 0.25f) { thick = 0.03f })
        )

        // ---------------------------------------------------------------- the user's own presets
        val user = ArrayList<Flare>()
        private var loaded = false

        private fun file(ctx: Context) = File(ctx.filesDir, "flare_presets.json")

        fun loadUser(ctx: Context) {
            if (loaded) return
            loaded = true
            try {
                val a = JSONArray(file(ctx).readText())
                for (i in 0 until a.length()) user.add(fromJson(a.getJSONObject(i)))
            } catch (e: Exception) { }
        }

        fun saveUser(ctx: Context) {
            try {
                val a = JSONArray()
                for (f in user) a.put(f.toJson())
                file(ctx).writeText(a.toString())
            } catch (e: Exception) { }
        }
    }
}

/** Preview pictures of flares, drawn once in the GL thread and read back by the cards that show them. */
object FlareThumbs {
    val cache = ConcurrentHashMap<String, Bitmap>()
    @Volatile var running = false

    fun generate(view: PreviewView, flares: List<Flare>, done: () -> Unit) {
        val todo = flares.filter { !cache.containsKey(it.sig()) }
        if (todo.isEmpty() || running) { done(); return }
        running = true
        view.renderFlareThumbs(todo.map { Pair(it.sig(), it.copy()) }) { running = false; done() }
    }
}
