package com.saiki.motion

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Minimal binary glTF (.glb) importer for static meshes.
 * Optimisations: all node transforms are baked on load, geometry is uploaded once into interleaved VBOs,
 * 16-bit indices are used whenever possible, textures are downsampled to 1024 px and the model is
 * auto-centred and normalised. Skins, animations and Draco compression are not supported.
 */
class GlbModel(private val path: String) {
    class Prim(val vbo: Int, val ibo: Int, val count: Int, val indexType: Int, val color: FloatArray, val tex: Int)

    var ok = false
    var info = ""
    val prims = ArrayList<Prim>()

    private class Raw(val v: FloatArray, val idx: IntArray, val color: FloatArray, val image: Bitmap?)

    fun load(): Boolean {
        try {
            val data = File(path).readBytes()
            val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
            if (bb.getInt(0) != 0x46546C67) return false
            var off = 12
            var json: JSONObject? = null
            var binStart = 0
            while (off + 8 <= data.size) {
                val len = bb.getInt(off)
                val type = bb.getInt(off + 4)
                val s = off + 8
                if (type == 0x4E4F534A) json = JSONObject(String(data, s, len, Charsets.UTF_8))
                else if (type == 0x004E4942) binStart = s
                off = s + ((len + 3) and 3.inv())
            }
            val g = json ?: return false
            val accessors = g.optJSONArray("accessors") ?: JSONArray()
            val views = g.optJSONArray("bufferViews") ?: JSONArray()
            val meshes = g.optJSONArray("meshes") ?: return false
            val nodes = g.optJSONArray("nodes") ?: JSONArray()
            val materials = g.optJSONArray("materials") ?: JSONArray()
            val textures = g.optJSONArray("textures") ?: JSONArray()
            val images = g.optJSONArray("images") ?: JSONArray()

            fun compSize(ct: Int) = when (ct) { 5126, 5125 -> 4; 5123, 5122 -> 2; else -> 1 }
            fun readAcc(idx: Int): FloatArray {
                val a = accessors.getJSONObject(idx)
                val count = a.getInt("count")
                val comps = when (a.getString("type")) { "SCALAR" -> 1; "VEC2" -> 2; "VEC3" -> 3; "VEC4" -> 4; "MAT4" -> 16; else -> 1 }
                val ct = a.getInt("componentType")
                val norm = a.optBoolean("normalized", false)
                val out = FloatArray(count * comps)
                if (!a.has("bufferView")) return out
                val bv = views.getJSONObject(a.getInt("bufferView"))
                val base = binStart + bv.optInt("byteOffset", 0) + a.optInt("byteOffset", 0)
                val cs = compSize(ct)
                var stride = bv.optInt("byteStride", 0)
                if (stride == 0) stride = cs * comps
                for (i in 0 until count) for (j in 0 until comps) {
                    val p = base + i * stride + j * cs
                    out[i * comps + j] = when (ct) {
                        5126 -> bb.getFloat(p)
                        5123 -> (bb.getShort(p).toInt() and 0xFFFF) / (if (norm) 65535f else 1f)
                        5125 -> (bb.getInt(p).toLong() and 0xFFFFFFFFL).toFloat()
                        5121 -> (bb.get(p).toInt() and 0xFF) / (if (norm) 255f else 1f)
                        5122 -> bb.getShort(p) / (if (norm) 32767f else 1f)
                        else -> bb.get(p) / (if (norm) 127f else 1f)
                    }
                }
                return out
            }

            fun image(matIdx: Int): Bitmap? {
                if (matIdx < 0) return null
                val m = materials.getJSONObject(matIdx).optJSONObject("pbrMetallicRoughness") ?: return null
                val ti = m.optJSONObject("baseColorTexture")?.optInt("index", -1) ?: -1
                if (ti < 0) return null
                val src = textures.getJSONObject(ti).optInt("source", -1)
                if (src < 0) return null
                val bvi = images.getJSONObject(src).optInt("bufferView", -1)
                if (bvi < 0) return null
                val bv = views.getJSONObject(bvi)
                val start = binStart + bv.optInt("byteOffset", 0)
                val len = bv.getInt("byteLength")
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeByteArray(data, start, len, o)
                var ss = 1
                while (o.outWidth / ss > 1024 || o.outHeight / ss > 1024) ss *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = ss
                return BitmapFactory.decodeByteArray(data, start, len, o2)
            }

            val raws = ArrayList<Raw>()
            var minX = 1e30f; var minY = 1e30f; var minZ = 1e30f
            var maxX = -1e30f; var maxY = -1e30f; var maxZ = -1e30f
            val imgCache = HashMap<Int, Bitmap?>()

            fun addMesh(mi: Int, w: FloatArray) {
                val prs = meshes.getJSONObject(mi).optJSONArray("primitives") ?: return
                val nm = FloatArray(16)
                val inv = FloatArray(16)
                Matrix.invertM(inv, 0, w, 0)
                Matrix.transposeM(nm, 0, inv, 0)
                for (pi in 0 until prs.length()) {
                    val pr = prs.getJSONObject(pi)
                    if (pr.optInt("mode", 4) != 4) continue
                    val at = pr.getJSONObject("attributes")
                    if (!at.has("POSITION")) continue
                    val pos = readAcc(at.getInt("POSITION"))
                    val n = pos.size / 3
                    val nrm = if (at.has("NORMAL")) readAcc(at.getInt("NORMAL")) else null
                    val uv = if (at.has("TEXCOORD_0")) readAcc(at.getInt("TEXCOORD_0")) else null
                    val idx: IntArray = if (pr.has("indices")) readAcc(pr.getInt("indices")).let { f -> IntArray(f.size) { f[it].toInt() } } else IntArray(n) { it }
                    val v = FloatArray(n * 8)
                    for (i in 0 until n) {
                        val x = pos[i * 3]; val y = pos[i * 3 + 1]; val z = pos[i * 3 + 2]
                        val px = w[0] * x + w[4] * y + w[8] * z + w[12]
                        val py = w[1] * x + w[5] * y + w[9] * z + w[13]
                        val pz = w[2] * x + w[6] * y + w[10] * z + w[14]
                        v[i * 8] = px; v[i * 8 + 1] = py; v[i * 8 + 2] = pz
                        if (px < minX) minX = px; if (py < minY) minY = py; if (pz < minZ) minZ = pz
                        if (px > maxX) maxX = px; if (py > maxY) maxY = py; if (pz > maxZ) maxZ = pz
                        if (nrm != null) {
                            val nx = nm[0] * nrm[i * 3] + nm[4] * nrm[i * 3 + 1] + nm[8] * nrm[i * 3 + 2]
                            val ny = nm[1] * nrm[i * 3] + nm[5] * nrm[i * 3 + 1] + nm[9] * nrm[i * 3 + 2]
                            val nz = nm[2] * nrm[i * 3] + nm[6] * nrm[i * 3 + 1] + nm[10] * nrm[i * 3 + 2]
                            val l = max(sqrt(nx * nx + ny * ny + nz * nz), 1e-6f)
                            v[i * 8 + 3] = nx / l; v[i * 8 + 4] = ny / l; v[i * 8 + 5] = nz / l
                        }
                        if (uv != null) { v[i * 8 + 6] = uv[i * 2]; v[i * 8 + 7] = uv[i * 2 + 1] }
                    }
                    if (nrm == null) { // smooth normals from faces
                        var t = 0
                        while (t + 2 < idx.size) {
                            val a = idx[t]; val b = idx[t + 1]; val c = idx[t + 2]
                            val ux = v[b * 8] - v[a * 8]; val uy = v[b * 8 + 1] - v[a * 8 + 1]; val uz = v[b * 8 + 2] - v[a * 8 + 2]
                            val vx = v[c * 8] - v[a * 8]; val vy = v[c * 8 + 1] - v[a * 8 + 1]; val vz = v[c * 8 + 2] - v[a * 8 + 2]
                            val nx = uy * vz - uz * vy; val ny = uz * vx - ux * vz; val nz = ux * vy - uy * vx
                            for (q in intArrayOf(a, b, c)) { v[q * 8 + 3] += nx; v[q * 8 + 4] += ny; v[q * 8 + 5] += nz }
                            t += 3
                        }
                        for (i in 0 until n) {
                            val l = max(sqrt(v[i * 8 + 3] * v[i * 8 + 3] + v[i * 8 + 4] * v[i * 8 + 4] + v[i * 8 + 5] * v[i * 8 + 5]), 1e-6f)
                            v[i * 8 + 3] /= l; v[i * 8 + 4] /= l; v[i * 8 + 5] /= l
                        }
                    }
                    val mat = pr.optInt("material", -1)
                    var col = floatArrayOf(1f, 1f, 1f, 1f)
                    if (mat >= 0) {
                        val bc = materials.getJSONObject(mat).optJSONObject("pbrMetallicRoughness")?.optJSONArray("baseColorFactor")
                        if (bc != null && bc.length() == 4) col = floatArrayOf(bc.getDouble(0).toFloat(), bc.getDouble(1).toFloat(), bc.getDouble(2).toFloat(), bc.getDouble(3).toFloat())
                    }
                    val bmp = if (mat >= 0) imgCache.getOrPut(mat) { image(mat) } else null
                    raws.add(Raw(v, idx, col, bmp))
                }
            }

            fun local(n: JSONObject, out: FloatArray) {
                if (n.has("matrix")) { val m = n.getJSONArray("matrix"); for (i in 0 until 16) out[i] = m.getDouble(i).toFloat(); return }
                Matrix.setIdentityM(out, 0)
                n.optJSONArray("translation")?.let { Matrix.translateM(out, 0, it.getDouble(0).toFloat(), it.getDouble(1).toFloat(), it.getDouble(2).toFloat()) }
                n.optJSONArray("rotation")?.let {
                    val x = it.getDouble(0).toFloat(); val y = it.getDouble(1).toFloat(); val z = it.getDouble(2).toFloat(); val w = it.getDouble(3).toFloat()
                    val r = floatArrayOf(
                        1 - 2 * (y * y + z * z), 2 * (x * y + z * w), 2 * (x * z - y * w), 0f,
                        2 * (x * y - z * w), 1 - 2 * (x * x + z * z), 2 * (y * z + x * w), 0f,
                        2 * (x * z + y * w), 2 * (y * z - x * w), 1 - 2 * (x * x + y * y), 0f,
                        0f, 0f, 0f, 1f)
                    val t = FloatArray(16)
                    Matrix.multiplyMM(t, 0, out, 0, r, 0)
                    System.arraycopy(t, 0, out, 0, 16)
                }
                n.optJSONArray("scale")?.let { Matrix.scaleM(out, 0, it.getDouble(0).toFloat(), it.getDouble(1).toFloat(), it.getDouble(2).toFloat()) }
            }

            fun walk(ni: Int, parent: FloatArray, depth: Int) {
                if (depth > 32) return
                val n = nodes.getJSONObject(ni)
                val l = FloatArray(16)
                local(n, l)
                val w = FloatArray(16)
                Matrix.multiplyMM(w, 0, parent, 0, l, 0)
                if (n.has("mesh")) addMesh(n.getInt("mesh"), w)
                n.optJSONArray("children")?.let { for (i in 0 until it.length()) walk(it.getInt(i), w, depth + 1) }
            }

            val ident = FloatArray(16)
            Matrix.setIdentityM(ident, 0)
            val scenes = g.optJSONArray("scenes")
            val roots = scenes?.getJSONObject(g.optInt("scene", 0))?.optJSONArray("nodes")
            if (roots != null) for (i in 0 until roots.length()) walk(roots.getInt(i), ident, 0)
            else for (i in 0 until nodes.length()) walk(i, ident, 0)
            if (raws.isEmpty()) return false

            val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f; val cz = (minZ + maxZ) / 2f
            val ext = max(maxX - minX, max(maxY - minY, maxZ - minZ))
            val sc = 1.2f / max(ext, 1e-6f)
            val uint = (GLES20.glGetString(GLES20.GL_EXTENSIONS) ?: "").contains("GL_OES_element_index_uint")
            var tris = 0
            for (r in raws) {
                val n = r.v.size / 8
                for (i in 0 until n) {
                    r.v[i * 8] = (r.v[i * 8] - cx) * sc; r.v[i * 8 + 1] = (r.v[i * 8 + 1] - cy) * sc; r.v[i * 8 + 2] = (r.v[i * 8 + 2] - cz) * sc
                }
                var verts = r.v
                var idx = r.idx
                var itype = GLES20.GL_UNSIGNED_SHORT
                if (n > 65535 && !uint) { // de-index so 16-bit indices are never needed
                    val nv = FloatArray(idx.size * 8)
                    for (i in idx.indices) System.arraycopy(r.v, idx[i] * 8, nv, i * 8, 8)
                    verts = nv
                    idx = IntArray(0)
                } else if (n > 65535) itype = GLES20.GL_UNSIGNED_INT
                val ids = IntArray(2)
                GLES20.glGenBuffers(2, ids, 0)
                val vb = ByteBuffer.allocateDirect(verts.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
                vb.put(verts).position(0)
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
                GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, verts.size * 4, vb, GLES20.GL_STATIC_DRAW)
                var count = verts.size / 8
                if (idx.isNotEmpty()) {
                    count = idx.size
                    GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ids[1])
                    if (itype == GLES20.GL_UNSIGNED_SHORT) {
                        val ib = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
                        for (v in idx) ib.put(v.toShort())
                        ib.position(0)
                        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, idx.size * 2, ib, GLES20.GL_STATIC_DRAW)
                    } else {
                        val ib = ByteBuffer.allocateDirect(idx.size * 4).order(ByteOrder.nativeOrder()).asIntBuffer()
                        ib.put(idx).position(0)
                        GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, idx.size * 4, ib, GLES20.GL_STATIC_DRAW)
                    }
                } else itype = 0
                var tex = 0
                if (r.image != null) {
                    val t = IntArray(1)
                    GLES20.glGenTextures(1, t, 0)
                    GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
                    GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
                    GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, r.image, 0)
                    tex = t[0]
                }
                tris += count / 3
                prims.add(Prim(ids[0], ids[1], count, itype, r.color, tex))
            }
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
            info = "$tris triangles, ${prims.size} parts"
            ok = true
            return true
        } catch (e: Exception) {
            info = e.message ?: "load failed"
            return false
        }
    }

    fun release() {
        for (p in prims) {
            GLES20.glDeleteBuffers(2, intArrayOf(p.vbo, p.ibo), 0)
            if (p.tex != 0) GLES20.glDeleteTextures(1, intArrayOf(p.tex), 0)
        }
        prims.clear()
    }
}
