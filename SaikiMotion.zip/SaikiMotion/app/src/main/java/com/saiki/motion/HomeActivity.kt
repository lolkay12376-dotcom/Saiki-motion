package com.saiki.motion

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.roundToInt

/** Project menu: "My Playground". */
class HomeActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var count: TextView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Registry.init(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF000000.toInt())
        root.fitsSystemWindows = true

        val top = LinearLayout(this)
        top.orientation = LinearLayout.VERTICAL
        top.setPadding(dp(28), dp(28), dp(28), dp(20))
        val brand = TextView(this)
        brand.text = "SAIKI MOTION"
        brand.setTextColor(C.GREEN)
        brand.textSize = 15f
        brand.typeface = Typeface.DEFAULT_BOLD
        brand.letterSpacing = 0.25f
        top.addView(brand)
        val title = TextView(this)
        title.text = "My\nPlayground"
        title.setTextColor(0xFFF2F2F2.toInt())
        title.textSize = 44f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setPadding(0, dp(16), 0, 0)
        top.addView(title)
        root.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(28), 0, dp(28), dp(20))
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        count = TextView(this)
        count.setTextColor(C.DIM)
        count.textSize = 14f
        count.setPadding(0, dp(24), 0, 0)
        col.addView(count)
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val nb = PillButton(this, "NEW PROJECT", "plus", C.GREEN, 0xFF04210F.toInt())
        nb.onClick = { showNewDialog() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60))
        lp.setMargins(dp(28), dp(8), dp(28), dp(24))
        root.addView(nb, lp)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        list.removeAllViews()
        val ps = Projects.list(this)
        for ((i, p) in ps.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dp(18), 0, dp(18))
            val idx = TextView(this)
            idx.text = String.format("%02d", i + 1)
            idx.setTextColor(C.DIM)
            idx.textSize = 16f
            row.addView(idx, LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.WRAP_CONTENT))
            val txt = LinearLayout(this)
            txt.orientation = LinearLayout.VERTICAL
            val nm = TextView(this)
            nm.text = p.name
            nm.setTextColor(0xFFFFFFFF.toInt())
            nm.textSize = 24f
            nm.typeface = Typeface.DEFAULT_BOLD
            val info = TextView(this)
            info.text = Projects.resLabel(p.w, p.h) + "  ·  " + p.fps + " FPS  ·  " + Projects.aspectLabel(p.w, p.h)
            info.setTextColor(C.DIM)
            info.textSize = 15f
            txt.addView(nm); txt.addView(info)
            row.addView(txt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val thumb = View(this)
            thumb.setBackgroundColor(0xFF1C1C21.toInt())
            val ar = p.w.toFloat() / p.h
            val tw = if (ar >= 1f) dp(52) else (dp(52) * ar).toInt()
            val th = if (ar >= 1f) (dp(52) / ar).toInt() else dp(52)
            row.addView(thumb, LinearLayout.LayoutParams(tw, th))
            row.setOnClickListener {
                val i2 = Intent(this, EditorActivity::class.java)
                i2.putExtra("id", p.id)
                startActivity(i2)
            }
            row.setOnLongClickListener { showMenu(p); true }
            list.addView(row)
            val line = View(this)
            line.setBackgroundColor(C.LINE)
            list.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 2))
        }
        if (ps.isEmpty()) {
            val e = TextView(this)
            e.text = "No projects yet. Tap NEW PROJECT to start."
            e.setTextColor(C.DIM)
            e.textSize = 16f
            list.addView(e)
        }
        count.text = ps.size.toString() + (if (ps.size == 1) " project" else " projects") + "  ·  " +
            String.format("%.1f", Projects.sizeBytes(this) / 1048576f) + " MB on device"
    }

    private fun showMenu(p: Projects.Info) {
        Dlg(this).setTitle(p.name).setItems(arrayOf("Rename", "Duplicate", "Delete")) { _, which ->
            when (which) {
                0 -> {
                    val et = EditText(this)
                    et.setText(p.name)
                    Dlg(this).setTitle("Rename").setView(et)
                        .setPositiveButton("Save") { _, _ -> Projects.rename(this, p.id, et.text.toString().ifBlank { p.name }); refresh() }.show()
                }
                1 -> { Projects.duplicate(this, p.id); refresh() }
                else -> Dlg(this).setTitle("Delete project?").setMessage(p.name)
                    .setPositiveButton("Delete") { _, _ -> Projects.delete(this, p.id); refresh() }
                    .setNegativeButton("Cancel", null).show()
            }
        }.show()
    }

    private fun showNewDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val name = EditText(this)
        name.setText("Project " + (Projects.list(this).size + 1))
        box.addView(name)
        var res = 1
        var asp = 0
        var fpsI = 1
        val resL = listOf("720p", "1080p", "1440p", "4K")
        val resS = intArrayOf(720, 1080, 1440, 2160)
        val aspL = listOf("16:9", "9:16", "1:1", "4:5", "21:9")
        val aspV = arrayOf(intArrayOf(16, 9), intArrayOf(9, 16), intArrayOf(1, 1), intArrayOf(4, 5), intArrayOf(21, 9))
        val fpsL = listOf(24, 30, 60, 90, 120)
        val sum = TextView(this)
        sum.setTextColor(C.GREEN)
        sum.setPadding(0, dp(10), 0, 0)
        fun size(): IntArray {
            val s = resS[res]
            val a = aspV[asp]
            return if (a[0] >= a[1]) intArrayOf((s * a[0].toFloat() / a[1] / 2f).roundToInt() * 2, s)
            else intArrayOf(s, (s * a[1].toFloat() / a[0] / 2f).roundToInt() * 2)
        }
        fun build() {
            box.removeAllViews()
            box.addView(name)
            fun label(t: String) { val tv = TextView(this); tv.text = t; tv.setTextColor(C.DIM); tv.setPadding(0, dp(10), 0, 0); box.addView(tv) }
            label("Resolution")
            box.addView(chipRow(this, resL, res) { res = it; build() })
            label("Aspect ratio")
            box.addView(chipRow(this, aspL, asp) { asp = it; build() })
            label("Frame rate")
            box.addView(chipRow(this, fpsL.map { "$it fps" }, fpsI) { fpsI = it; build() })
            val z = size()
            sum.text = z[0].toString() + " x " + z[1] + "  ·  " + fpsL[fpsI] + " fps" +
                (if (res == 3 || fpsL[fpsI] >= 90) "\nHigh settings need a capable device to export. You can lower preview quality in the editor." else "")
            box.addView(sum)
        }
        build()
        Dlg(this).setTitle("New project").setView(ScrollView(this).also { it.addView(box) })
            .setPositiveButton("Create") { _, _ ->
                val z = size()
                val id = Projects.create(this, name.text.toString().ifBlank { "Project" }, z[0], z[1], fpsL[fpsI])
                val i2 = Intent(this, EditorActivity::class.java)
                i2.putExtra("id", id)
                startActivity(i2)
            }.setNegativeButton("Cancel", null).show()
    }
}
