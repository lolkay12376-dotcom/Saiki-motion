package com.saiki.motion

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CopyOnWriteArraySet
import kotlin.math.abs

enum class Ease { LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, BOUNCE, CUSTOM }

fun bezier(u: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
    if (u <= 0f) return 0f
    if (u >= 1f) return 1f
    var s = u
    val cx = 3f * x1
    val bx = 3f * (x2 - x1) - cx
    val ax = 1f - cx - bx
    for (i in 0 until 8) {
        val x = ((ax * s + bx) * s + cx) * s
        val dx = (3f * ax * s + 2f * bx) * s + cx
        if (abs(dx) < 1e-5f) break
        s = (s - (x - u) / dx).coerceIn(0f, 1f)
    }
    val cy = 3f * y1
    val by = 3f * (y2 - y1) - cy
    val ay = 1f - cy - by
    return ((ay * s + by) * s + cy) * s
}

fun bounceOut(u: Float): Float {
    val n = 7.5625f
    val d = 2.75f
    return when {
        u < 1f / d -> n * u * u
        u < 2f / d -> { val x = u - 1.5f / d; n * x * x + 0.75f }
        u < 2.5f / d -> { val x = u - 2.25f / d; n * x * x + 0.9375f }
        else -> { val x = u - 2.625f / d; n * x * x + 0.984375f }
    }
}

class Key(var t: Float, var v: Float, var ease: Ease = Ease.EASE_IN_OUT) {
    var x1 = 0.42f
    var y1 = 0f
    var x2 = 0.58f
    var y2 = 1f

    fun preset(e: Ease) {
        ease = e
        when (e) {
            Ease.LINEAR -> { x1 = 0f; y1 = 0f; x2 = 1f; y2 = 1f }
            Ease.EASE_IN -> { x1 = 0.42f; y1 = 0f; x2 = 1f; y2 = 1f }
            Ease.EASE_OUT -> { x1 = 0f; y1 = 0f; x2 = 0.58f; y2 = 1f }
            Ease.EASE_IN_OUT -> { x1 = 0.42f; y1 = 0f; x2 = 0.58f; y2 = 1f }
            else -> {}
        }
    }

    fun curve(u: Float): Float = if (ease == Ease.BOUNCE) bounceOut(u) else bezier(u, x1, y1, x2, y2)

    init { preset(ease) }
}

/** An animatable value: constant `base` or interpolated keyframes with cubic bezier easing. */
class Track(var base: Float) {
    val keys = CopyOnWriteArrayList<Key>()

    fun eval(t: Float): Float {
        val ks = keys
        val n = ks.size
        if (n == 0) return base
        if (t <= ks[0].t) return ks[0].v
        if (t >= ks[n - 1].t) return ks[n - 1].v
        for (i in 0 until n - 1) {
            val a = ks[i]
            val b = ks[i + 1]
            if (t >= a.t && t <= b.t) {
                val u = (t - a.t) / (b.t - a.t)
                return a.v + (b.v - a.v) * a.curve(u)
            }
        }
        return base
    }

    fun keyAt(t: Float): Key? = keys.firstOrNull { abs(it.t - t) < 0.03f }

    fun set(t: Float, v: Float, autoKey: Boolean) {
        if (!autoKey && keys.isEmpty()) { base = v; return }
        val k = keyAt(t)
        if (k != null) k.v = v else { keys.add(Key(t, v)); keys.sortBy { it.t } }
    }

    fun toggleKey(t: Float) {
        val k = keyAt(t)
        if (k != null) {
            keys.remove(k)
            if (keys.isEmpty()) base = k.v
        } else {
            val v = eval(t)
            keys.add(Key(t, v))
            keys.sortBy { it.t }
        }
    }

    fun toJson(): JSONObject {
        val arr = JSONArray()
        for (k in keys) arr.put(JSONObject().put("t", k.t.toDouble()).put("v", k.v.toDouble()).put("e", k.ease.name)
            .put("x1", k.x1.toDouble()).put("y1", k.y1.toDouble()).put("x2", k.x2.toDouble()).put("y2", k.y2.toDouble()))
        return JSONObject().put("b", base.toDouble()).put("k", arr)
    }

    fun load(o: JSONObject) {
        base = o.optDouble("b", base.toDouble()).toFloat()
        keys.clear()
        val a = o.optJSONArray("k") ?: return
        for (i in 0 until a.length()) {
            val j = a.getJSONObject(i)
            val k = Key(j.getDouble("t").toFloat(), j.getDouble("v").toFloat(),
                try { Ease.valueOf(j.optString("e", "EASE_IN_OUT")) } catch (e: Exception) { Ease.EASE_IN_OUT })
            k.x1 = j.optDouble("x1", k.x1.toDouble()).toFloat(); k.y1 = j.optDouble("y1", k.y1.toDouble()).toFloat()
            k.x2 = j.optDouble("x2", k.x2.toDouble()).toFloat(); k.y2 = j.optDouble("y2", k.y2.toDouble()).toFloat()
            keys.add(k)
        }
    }
}

class PropDef(
    val key: String, val label: String, val min: Float, val max: Float, val def: Float,
    val dec: Int = 2, val name: String = key, val options: List<String>? = null
)

enum class LayerType { SHAPE, TEXT, IMAGE, VIDEO, CAMERA, NULL, MODEL, PARTICLES }
enum class ShapeKind { RECT, ROUND, CIRCLE, TRIANGLE, STAR }

class Layer(val id: Int, var name: String, var type: LayerType) {
    var text = "Saiki Motion"
    var color = 0xFF7C4DFF.toInt()
    var color2 = 0xFFFF4081.toInt()
    var shape = ShapeKind.ROUND
    var bold = true
    var italic = false
    var imagePath: String? = null
    var start = 0f
    var end = 5f
    var visible = true
    var is3d = false
    var parentId = -1
    var blend = 0
    var srcDur = 0f
    @Volatile var texAspect = 1f
    val props = LinkedHashMap<String, Track>().also { m -> Registry.allProps().forEach { m[it.key] = Track(it.def) } }
    val fx = CopyOnWriteArrayList<String>()
    val fxOff = CopyOnWriteArraySet<String>()
    val inputs = ConcurrentHashMap<String, Int>()

    /** UI-side accessor: creates the track if it did not exist yet (e.g. effect imported later). */
    fun track(key: String): Track = props[key] ?: synchronized(props) {
        props.getOrPut(key) { Track(Registry.propDef(key)?.def ?: 0f) }
    }

    fun p(key: String, t: Float): Float = props[key]?.eval(t) ?: (Registry.propDef(key)?.def ?: 0f)
    fun texKey(): String = "$type|$text|$color|$shape|$bold|$italic|$imagePath"
    fun fxOn(id: String): Boolean = fx.contains(id) && !fxOff.contains(id)
    fun isRenderable(): Boolean = type != LayerType.CAMERA && type != LayerType.NULL

    /** Time used to evaluate this layer's animation (Time Remap). */
    fun localTime(t: Float): Float {
        if (!fxOn("remap")) return t
        val sp = props["remapSpeed"] ?: return t
        var lt: Float
        if (sp.keys.isEmpty()) {
            lt = start + (t - start) * sp.base
        } else {
            var acc = 0f
            var u = start
            while (u < t) {
                val d = minOf(0.05f, t - u)
                acc += sp.eval(u + d * 0.5f) * d
                u += d
            }
            lt = start + acc
        }
        val loop = p("remapLoop", t)
        if (loop > 0.05f) {
            val rel = lt - start
            val ping = p("remapPing", t) >= 0.5f
            if (ping) {
                var m = rel % (2f * loop)
                if (m < 0f) m += 2f * loop
                lt = start + (if (m <= loop) m else 2f * loop - m)
            } else {
                var m = rel % loop
                if (m < 0f) m += loop
                lt = start + m
            }
        }
        return lt
    }

    fun editTime(key: String, t: Float): Float = if (key.startsWith("remap")) t else localTime(t)
}

class Scene(var name: String) {
    var duration = 5f
    var bg = 0xFF101018.toInt()
    var fov = 45f
    val layers = CopyOnWriteArrayList<Layer>()
    val markers = CopyOnWriteArrayList<Float>()
}

class Project {
    var name = "Project 1"
    var w = 1920
    var h = 1080
    var fps = 30
    var nextId = 1
    val scenes = CopyOnWriteArrayList<Scene>()
    init { scenes.add(Scene("Scene 1")) }
}

object Editor {
    @Volatile var project = Project()
    @Volatile var sceneIndex = 0
    @Volatile var time = 0f
    val scene: Scene
        get() = project.scenes[sceneIndex.coerceIn(0, project.scenes.size - 1)]
}

object Store {
    fun toJson(p: Project): JSONObject {
        val o = JSONObject().put("name", p.name).put("w", p.w).put("h", p.h).put("fps", p.fps).put("next", p.nextId)
        val sa = JSONArray()
        for (s in p.scenes) {
            val so = JSONObject().put("name", s.name).put("dur", s.duration.toDouble())
                .put("bg", s.bg).put("fov", s.fov.toDouble())
            val la = JSONArray()
            for (l in s.layers) {
                val lo = JSONObject().put("id", l.id).put("name", l.name).put("type", l.type.name)
                    .put("text", l.text).put("color", l.color).put("color2", l.color2).put("shape", l.shape.name)
                    .put("bold", l.bold).put("italic", l.italic)
                    .put("img", l.imagePath ?: "").put("start", l.start.toDouble()).put("end", l.end.toDouble())
                    .put("is3d", l.is3d).put("parent", l.parentId).put("blend", l.blend).put("srcDur", l.srcDur.toDouble())
                lo.put("fx", JSONArray(l.fx.toList()))
                lo.put("fxoff", JSONArray(l.fxOff.toList()))
                lo.put("vis", l.visible)
                val io = JSONObject()
                for ((k, v) in l.inputs) io.put(k, v)
                lo.put("inputs", io)
                val po = JSONObject()
                for ((k, tr) in l.props) po.put(k, tr.toJson())
                lo.put("props", po)
                la.put(lo)
            }
            so.put("layers", la)
            val ma = JSONArray()
            for (m in s.markers) ma.put(m.toDouble())
            so.put("markers", ma)
            sa.put(so)
        }
        o.put("scenes", sa)
        return o
    }

    fun fromJson(o: JSONObject): Project {
        val p = Project()
        p.scenes.clear()
        p.name = o.optString("name", "Project")
        p.w = o.optInt("w", 1920); p.h = o.optInt("h", 1080); p.fps = o.optInt("fps", 30)
        p.nextId = o.optInt("next", 1)
        val sa = o.getJSONArray("scenes")
        for (i in 0 until sa.length()) {
            val so = sa.getJSONObject(i)
            val s = Scene(so.optString("name", "Scene"))
            s.duration = so.optDouble("dur", 5.0).toFloat()
            s.bg = so.optInt("bg", s.bg)
            s.fov = so.optDouble("fov", 45.0).toFloat()
            val mk = so.optJSONArray("markers")
            if (mk != null) for (k in 0 until mk.length()) s.markers.add(mk.getDouble(k).toFloat())
            val la = so.optJSONArray("layers")
            if (la != null) for (j in 0 until la.length()) {
                val lo = la.getJSONObject(j)
                val type = try { LayerType.valueOf(lo.getString("type")) } catch (e: Exception) { LayerType.SHAPE }
                val l = Layer(lo.getInt("id"), lo.optString("name", "Layer"), type)
                l.text = lo.optString("text", ""); l.color = lo.optInt("color", l.color); l.color2 = lo.optInt("color2", l.color2)
                l.shape = try { ShapeKind.valueOf(lo.optString("shape", "ROUND")) } catch (e: Exception) { ShapeKind.ROUND }
                l.bold = lo.optBoolean("bold", true); l.italic = lo.optBoolean("italic", false)
                val img = lo.optString("img", "")
                l.imagePath = if (img.isEmpty()) null else img
                l.start = lo.optDouble("start", 0.0).toFloat(); l.end = lo.optDouble("end", 5.0).toFloat()
                l.is3d = lo.optBoolean("is3d", false); l.parentId = lo.optInt("parent", -1)
                l.blend = lo.optInt("blend", 0); l.srcDur = lo.optDouble("srcDur", 0.0).toFloat()
                val fa = lo.optJSONArray("fx")
                if (fa != null) for (k in 0 until fa.length()) l.fx.add(fa.getString(k))
                val fo = lo.optJSONArray("fxoff")
                if (fo != null) for (k in 0 until fo.length()) l.fxOff.add(fo.getString(k))
                l.visible = lo.optBoolean("vis", true)
                val io = lo.optJSONObject("inputs")
                if (io != null) for (k in io.keys()) l.inputs[k] = io.getInt(k)
                val po = lo.optJSONObject("props")
                if (po != null) for (k in po.keys()) po.optJSONObject(k)?.let { l.track(k).load(it) }
                s.layers.add(l)
            }
            p.scenes.add(s)
        }
        if (p.scenes.isEmpty()) p.scenes.add(Scene("Scene 1"))
        return p
    }
}
