package com.saiki.motion

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.opengl.Matrix
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.atan2
import kotlin.math.hypot

interface EditHost {
    fun selectedLayer(): Layer?
    fun autoKey(): Boolean
    fun beginEdit()
    fun onEdited()
}

/** Selection box, handles, guides and direct manipulation (move, scale, rotate) above the GL preview. */
class OverlayView(ctx: Context, private val host: EditHost) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    var guides = false
    var pick: ((Float, Float) -> Unit)? = null

    private val outline = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillWhite = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val guide = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    private val hx = FloatArray(9)
    private val hy = FloatArray(9)
    private var rotX = 0f
    private var rotY = 0f
    private val m = FloatArray(16)
    private val vp = FloatArray(16)
    private val mvp = FloatArray(16)
    private val inV = FloatArray(4)
    private val gin = FloatArray(4)
    private val gout = FloatArray(4)
    private val outV = FloatArray(4)

    private var mode = 0 // 0 none, 1 move, 2 scale, 3 rotate
    private var lastX = 0f
    private var lastY = 0f
    private var startDist = 1f
    private var startScale = 1f
    private var startRot = 0f
    private var startAng = 0f
    private var skip = false

    private val pinch = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(det: ScaleGestureDetector): Boolean { host.beginEdit(); return true }
        override fun onScale(det: ScaleGestureDetector): Boolean {
            val l = host.selectedLayer() ?: return true
            val lt = l.localTime(Editor.time)
            val tr = l.props["scale"]!!
            tr.set(lt, (tr.eval(lt) * det.scaleFactor).coerceIn(0.05f, 8f), host.autoKey())
            host.onEdited()
            return true
        }
    })

    init {
        outline.style = Paint.Style.STROKE
        outline.strokeWidth = 1.6f * d
        outline.color = C.GREEN
        outline.pathEffect = DashPathEffect(floatArrayOf(8f * d, 5f * d), 0f)
        fillWhite.color = 0xFFFFFFFF.toInt()
        line.style = Paint.Style.STROKE
        line.strokeWidth = 1.6f * d
        line.color = C.GREEN
        guide.style = Paint.Style.STROKE
        guide.strokeWidth = 1f * d
        guide.color = 0x55FFFFFF
    }

    private fun project(): Boolean {
        val l = host.selectedLayer() ?: return false
        if (width == 0 || height == 0 || l.type == LayerType.AUDIO) return false
        val sc = Editor.scene
        val qh = LayerBitmaps.baseHeight(l)
        val qw = qh * (if (l.type == LayerType.CAMERA || l.type == LayerType.NULL || l.type == LayerType.GROUP || l.type == LayerType.ADJUST || l.type == LayerType.PARTICLES || l.type == LayerType.MODEL) 1f else l.texAspect)
        Xf.world(sc, l, Editor.time, qw, qh, m)
        Xf.viewProj(sc, Editor.time, width.toFloat() / height, if ((l.is3d || l.type == LayerType.MODEL) && l.type != LayerType.CAMERA) Xf.cameraAbove(sc, l, Editor.time) else null, vp)
        Matrix.multiplyMM(mvp, 0, vp, 0, m, 0)
        val gm = Xf.groupMatrix(sc, l, Editor.time, width.toFloat() / height)
        val lx = floatArrayOf(-0.5f, 0.5f, 0.5f, -0.5f, 0f, 0.5f, 0f, -0.5f, 0f)
        val ly = floatArrayOf(0.5f, 0.5f, -0.5f, -0.5f, 0.5f, 0f, -0.5f, 0f, 0f)
        for (i in 0 until 9) {
            inV[0] = lx[i] * qw; inV[1] = ly[i] * qh; inV[2] = 0f; inV[3] = 1f
            Matrix.multiplyMV(outV, 0, mvp, 0, inV, 0)
            val w = if (outV[3] == 0f) 1f else outV[3]
            var nx = outV[0] / w
            var ny = outV[1] / w
            if (gm != null) { gin[0] = nx; gin[1] = ny; gin[2] = 0f; gin[3] = 1f; Matrix.multiplyMV(gout, 0, gm, 0, gin, 0); nx = gout[0]; ny = gout[1] }
            hx[i] = (nx * 0.5f + 0.5f) * width
            hy[i] = (1f - (ny * 0.5f + 0.5f)) * height
        }
        val dx = hx[4] - hx[8]
        val dy = hy[4] - hy[8]
        val len = hypot(dx, dy).coerceAtLeast(1f)
        rotX = hx[4] + dx / len * 36f * d
        rotY = hy[4] + dy / len * 36f * d
        return true
    }

    override fun onDraw(c: Canvas) { try { draw0(c) } catch (e: Exception) { } }

    private fun draw0(c: Canvas) {
        if (guides) {
            val w = width.toFloat()
            val h = height.toFloat()
            c.drawLine(w / 3f, 0f, w / 3f, h, guide); c.drawLine(2f * w / 3f, 0f, 2f * w / 3f, h, guide)
            c.drawLine(0f, h / 3f, w, h / 3f, guide); c.drawLine(0f, 2f * h / 3f, w, 2f * h / 3f, guide)
            c.drawLine(w / 2f, 0f, w / 2f, h, guide); c.drawLine(0f, h / 2f, w, h / 2f, guide)
        }
        if (!project()) return
        path.reset()
        path.moveTo(hx[0], hy[0]); path.lineTo(hx[1], hy[1]); path.lineTo(hx[2], hy[2]); path.lineTo(hx[3], hy[3]); path.close()
        c.drawPath(path, outline)
        c.drawLine(hx[4], hy[4], rotX, rotY, line)
        val hs = 4.5f * d
        for (i in 0 until 8) c.drawRect(hx[i] - hs, hy[i] - hs, hx[i] + hs, hy[i] + hs, fillWhite)
        c.drawCircle(rotX, rotY, 7f * d, fillWhite)
        c.drawCircle(rotX, rotY, 3.5f * d, line)
        c.drawCircle(hx[8], hy[8], 7f * d, line)
        c.drawCircle(hx[8], hy[8], 1.8f * d, fillWhite)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val pk = pick
        if (pk != null) {
            if (e.actionMasked == MotionEvent.ACTION_UP) { pick = null; pk(e.x, e.y) }
            return true
        }
        val l = host.selectedLayer() ?: return false
        pinch.onTouchEvent(e)
        if (pinch.isInProgress || e.pointerCount > 1) { mode = 0; skip = true; return true }
        val lt = l.localTime(Editor.time)
        val ak = host.autoKey()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                skip = false
                if (!project()) return false
                host.beginEdit()
                val slop = 26f * d
                mode = 1
                if (hypot(e.x - rotX, e.y - rotY) < slop) {
                    mode = 3
                    startAng = Math.toDegrees(atan2((e.y - hy[8]).toDouble(), (e.x - hx[8]).toDouble())).toFloat()
                    startRot = l.props["rotZ"]!!.eval(lt)
                } else {
                    for (i in 0 until 8) {
                        if (hypot(e.x - hx[i], e.y - hy[i]) < slop) {
                            mode = 2
                            startDist = hypot(e.x - hx[8], e.y - hy[8]).coerceAtLeast(1f)
                            startScale = l.props["scale"]!!.eval(lt)
                            break
                        }
                    }
                }
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                if (skip) { lastX = e.x; lastY = e.y; skip = false; return true }
                when (mode) {
                    1 -> {
                        val k = 2f / height
                        val tx = l.props["x"]!!
                        val ty = l.props["y"]!!
                        tx.set(lt, tx.eval(lt) + (e.x - lastX) * k, ak)
                        ty.set(lt, ty.eval(lt) - (e.y - lastY) * k, ak)
                    }
                    2 -> {
                        val dist = hypot(e.x - hx[8], e.y - hy[8])
                        l.props["scale"]!!.set(lt, (startScale * dist / startDist).coerceIn(0.05f, 8f), ak)
                    }
                    3 -> {
                        val ang = Math.toDegrees(atan2((e.y - hy[8]).toDouble(), (e.x - hx[8]).toDouble())).toFloat()
                        var v = startRot - (ang - startAng)
                        while (v > 360f) v -= 720f
                        while (v < -360f) v += 720f
                        l.props["rotZ"]!!.set(lt, v.coerceIn(-360f, 360f), ak)
                    }
                }
                lastX = e.x; lastY = e.y
                host.onEdited()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }
}
