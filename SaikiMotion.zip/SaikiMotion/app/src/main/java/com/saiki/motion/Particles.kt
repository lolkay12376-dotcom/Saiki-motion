package com.saiki.motion

import android.graphics.Color
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Stateless particle simulation modelled on CC Particle World style controls.
 * Every particle is a closed-form function of its index and age, so scrubbing and export are exact.
 * Vertex layout (11 floats): centre xyz, corner xy (already scaled), uv, premultiplied rgba.
 */
object Particles {
    const val MAX = 3000
    const val FLOATS = 11
    private val CS = floatArrayOf(-1f, -1f, 1f, -1f, 1f, 1f, -1f, -1f, 1f, 1f, -1f, 1f)
    private val US = floatArrayOf(0f, 1f, 1f, 1f, 1f, 0f, 0f, 1f, 1f, 0f, 0f, 0f)

    private fun rnd(i: Int, k: Int, seed: Float): Float {
        var h = i * 374761393 + k * 668265263 + (seed * 1000f).toInt() * 2147483
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFFFF) / 16777216f
    }

    fun build(l: Layer, lt: Float, out: FloatArray): Int {
        val t = lt - l.start
        if (t < 0f) return 0
        val rate = l.p("pBirthRate", lt) * 60f
        val lon = max(0.05f, l.p("pLongevity", lt))
        if (rate <= 0f) return 0
        val iMax = floor(t * rate).toInt()
        var iMin = max(0, ceil((t - lon) * rate).toInt())
        if (iMax - iMin >= MAX) iMin = iMax - MAX + 1
        val px = l.p("pProdX", lt); val py = l.p("pProdY", lt); val pz = l.p("pProdZ", lt)
        val rx = l.p("pRadX", lt); val ry = l.p("pRadY", lt); val rz = l.p("pRadZ", lt)
        val anim = l.p("pAnim", lt).toInt()
        val vel = l.p("pVelocity", lt)
        val dirA = Math.toRadians(l.p("pDirection", lt).toDouble())
        val spread = l.p("pSpread", lt)
        val grav = l.p("pGravity", lt)
        var res = l.p("pResist", lt)
        val extra = l.p("pExtra", lt)
        val bs = l.p("pBirthSize", lt); val ds = l.p("pDeathSize", lt); val sv = l.p("pSizeVar", lt)
        val maxOp = l.p("pOpacity", lt)
        val fade = l.p("pFade", lt).toInt()
        val seed = l.p("pSeed", lt)
        if (anim == 3) res *= 3f
        val c1 = l.color
        val c2 = l.color2
        var n = 0
        for (i in iMin..iMax) {
            val age = t - i / rate
            if (age < 0f || age >= lon) continue
            val u = age / lon
            val x0 = px + (rnd(i, 1, seed) * 2f - 1f) * rx
            val y0 = py + (rnd(i, 2, seed) * 2f - 1f) * ry
            val z0 = pz + (rnd(i, 3, seed) * 2f - 1f) * rz
            // direction
            val phi = (rnd(i, 4, seed) * 2f * PI).toFloat()
            val cz = rnd(i, 5, seed) * 2f - 1f
            val sr = sqrt(max(0f, 1f - cz * cz))
            var dx = sr * cos(phi); var dy = sr * sin(phi); var dz = cz
            val ax = cos(dirA).toFloat(); val ay = sin(dirA).toFloat()
            when (anim) {
                1 -> { val k = spread / 90f; dx = ax + dx * k; dy = ay + dy * k; dz *= k }
                2 -> {
                    val ca = 1f - rnd(i, 6, seed) * (1f - cos(Math.toRadians(spread.toDouble())).toFloat())
                    val sa = sqrt(max(0f, 1f - ca * ca))
                    // basis: axis (ax,ay,0), side (-ay,ax,0), up (0,0,1)
                    dx = ax * ca + (-ay * cos(phi)) * sa; dy = ay * ca + (ax * cos(phi)) * sa; dz = sin(phi) * sa
                }
                4 -> { dx = -sin(phi); dy = cos(phi); dz = 0.3f }
            }
            val len = max(sqrt(dx * dx + dy * dy + dz * dz), 1e-5f)
            dx /= len; dy /= len; dz /= len
            val speed = vel * (if (anim == 3) 0.4f else 1f) * (1f + (rnd(i, 7, seed) - 0.5f) * extra)
            val travel = if (res < 0.001f) age else (1f - exp(-res * age)) / res
            var x = x0 + dx * speed * travel
            var y = y0 + dy * speed * travel - 0.5f * grav * age * age
            val z = z0 + dz * speed * travel
            if (anim == 4) {
                val a = age * 2.5f
                val rx2 = x - px
                val ry2 = y - py
                x = px + rx2 * cos(a) - ry2 * sin(a)
                y = py + rx2 * sin(a) + ry2 * cos(a)
            }
            val sz = (bs + (ds - bs) * u) * (1f + (rnd(i, 8, seed) - 0.5f) * 2f * sv) * 0.08f
            val op = maxOp * when (fade) { 0 -> 1f - u; 1 -> sin(PI.toFloat() * u); else -> 1f }
            val r = lerp(Color.red(c1), Color.red(c2), u) / 255f
            val g = lerp(Color.green(c1), Color.green(c2), u) / 255f
            val b = lerp(Color.blue(c1), Color.blue(c2), u) / 255f
            val o = n * 6 * FLOATS
            if (o + 6 * FLOATS > out.size) break
            for (v in 0 until 6) {
                val q = o + v * FLOATS
                out[q] = x; out[q + 1] = y; out[q + 2] = z
                out[q + 3] = CS[v * 2] * sz; out[q + 4] = CS[v * 2 + 1] * sz
                out[q + 5] = US[v * 2]; out[q + 6] = US[v * 2 + 1]
                out[q + 7] = r * op; out[q + 8] = g * op; out[q + 9] = b * op; out[q + 10] = op
            }
            n++
        }
        return n
    }

    private fun lerp(a: Int, b: Int, u: Float): Float = a + (b - a) * min(1f, max(0f, u))
}
