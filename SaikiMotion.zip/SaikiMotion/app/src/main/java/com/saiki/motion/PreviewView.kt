package com.saiki.motion

import android.content.Context
import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Renders only when something changed (dirty mode) to save battery. */
class PreviewView(ctx: Context) : GLSurfaceView(ctx) {
    private val sr = SceneRenderer()
    @Volatile private var vw = 1
    @Volatile private var vh = 1
    @Volatile private var glReady = false

    /** 1 = full, 2 = half, 4 = quarter resolution. Lower is faster on heavy scenes. */
    var quality = 1
        set(v) { field = v; applyQuality() }

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        setRenderer(object : GLSurfaceView.Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
                try { sr.init() } catch (e: Throwable) { Registry.errors["__gl"] = (e.message ?: "gl init").take(200) }
                glReady = true
            }
            override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) { vw = w; vh = h }
            override fun onDrawFrame(gl: GL10?) {
                try {
                    sr.draw(Editor.project, Editor.scene, Editor.time, vw, vh)
                } catch (e: Throwable) {
                    // skip a frame if the project was mutated mid-draw
                }
            }
        })
        renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
    }

    override fun onPause() {
        queueEvent { sr.releaseVideos() }
        super.onPause()
    }

    /** Renders the effect icons on the portrait using the same GL context that already draws the preview. */
    fun renderThumbs(ids: List<String>, portrait: String, done: () -> Unit) {
        queueEvent {
            if (!glReady) { postDelayed({ renderThumbs(ids, portrait, done) }, 400); return@queueEvent }
            val W = 192
            val H = 256
            val tex = IntArray(1)
            val fb = IntArray(1)
            val saved = sr.outFbo
            try {
                GLES20.glGenTextures(1, tex, 0)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0])
                GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, W, H, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
                GLES20.glGenFramebuffers(1, fb, 0)
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fb[0])
                GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, tex[0], 0)
                sr.outFbo = fb[0]
                val proj = Project()
                proj.w = W; proj.h = H
                val sc = proj.scenes[0]
                sc.duration = 5f
                val l = Layer(999999, "portrait", LayerType.IMAGE)
                l.imagePath = portrait
                l.end = 5f
                sc.layers.add(l)
                val buf = ByteBuffer.allocateDirect(W * H * 4).order(ByteOrder.nativeOrder())
                for (id in ids) {
                    try {
                        l.fx.clear(); l.fxOff.clear()
                        if (id != "__orig") l.fx.add(id)
                        val t = if (id == "swing") 0.45f else 0.7f
                        sr.draw(proj, sc, t, W, H)
                        GLES20.glReadPixels(0, 0, W, H, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
                        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
                        buf.position(0)
                        bmp.copyPixelsFromBuffer(buf)
                        val m = android.graphics.Matrix()
                        m.preScale(1f, -1f)
                        EffectThumbs.cache[id] = Bitmap.createBitmap(bmp, 0, 0, W, H, m, false)
                        bmp.recycle()
                        Registry.errors[id]?.let { EffectThumbs.lastError = id + ": " + it.take(120) }
                    } catch (e: Throwable) {
                        EffectThumbs.lastError = (id + ": " + (e.message ?: e.toString())).take(160)
                        EffectThumbs.cache[id] = EffectThumbs.cache["__orig"] ?: continue
                    }
                }
            } catch (e: Throwable) {
                EffectThumbs.lastError = (e.message ?: e.toString()).take(160)
            } finally {
                sr.outFbo = saved
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, saved)
                GLES20.glDeleteFramebuffers(1, fb, 0)
                GLES20.glDeleteTextures(1, tex, 0)
            }
            post { done() }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        applyQuality()
    }

    private fun applyQuality() {
        if (width <= 0 || height <= 0) return
        if (quality <= 1) holder.setSizeFromLayout()
        else holder.setFixedSize(width / quality, height / quality)
    }
}
