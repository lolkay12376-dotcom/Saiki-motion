package com.saiki.motion

import android.content.Context
import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Renders only when something changed (dirty mode) to save battery. */
class PreviewView(ctx: Context) : GLSurfaceView(ctx) {
    private val sr = SceneRenderer()
    @Volatile private var vw = 1
    @Volatile private var vh = 1
    @Volatile private var glReady = false

    /** 1 = full, 2 = half, 4 = quarter resolution. Lower is faster on heavy scenes. */
    var quality = 1
        set(v) { field = v; applyQuality() }

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        setRenderer(object : GLSurfaceView.Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
                try { sr.init() } catch (e: Throwable) { Registry.errors["__gl"] = (e.message ?: "gl init").take(200) }
                glReady = true
            }
            override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) { vw = w; vh = h }
            override fun onDrawFrame(gl: GL10?) {
                try {
                    sr.draw(Editor.project, Editor.scene, Editor.time, vw, vh)
                } catch (e: Throwable) {
                    // skip a frame if the project was mutated mid-draw
                }
            }
        })
        renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
    }

    override fun onPause() {
        queueEvent { sr.releaseVideos() }
        super.onPause()
    }

    /** Renders the effect icons on the portrait using the same GL context that already draws the preview. */
    /** Draws each flare on black into a small bitmap, one GL event for all of them (there are only a few). */
    fun renderFlareThumbs(items: List<Pair<String, Flare>>, done: () -> Unit) {
        queueEvent { flareThumbStep(items, done) }
    }

    private fun flareThumbStep(items: List<Pair<String, Flare>>, done: () -> Unit) {
        if (!glReady) { postDelayed({ queueEvent { flareThumbStep(items, done) } }, 400); return }
        val W = 220
        val H = 150
        val saved = sr.outFbo
        val tex = IntArray(1)
        val fb = IntArray(1)
        try {
            GLES20.glGenTextures(1, tex, 0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0])
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, W, H, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glGenFramebuffers(1, fb, 0)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fb[0])
            GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, tex[0], 0)
            val proj = Project()
            proj.w = W; proj.h = H
            val sc = proj.scenes[0]
            sc.duration = 5f
            val l = Layer(999998, "flare", LayerType.FLARE)
            l.end = 5f
            l.track("x").base = -0.42f * (W.toFloat() / H)
            l.track("y").base = 0.3f
            sc.layers.add(l)
            val buf = ByteBuffer.allocateDirect(W * H * 4).order(ByteOrder.nativeOrder())
            sr.outFbo = fb[0]
            for ((key, f) in items) {
                try {
                    l.flare = f
                    sr.draw(proj, sc, 0.5f, W, H)
                    GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fb[0])
                    buf.clear()
                    GLES20.glReadPixels(0, 0, W, H, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
                    buf.rewind()
                    val raw = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
                    raw.copyPixelsFromBuffer(buf)
                    val m = android.graphics.Matrix()
                    m.preScale(1f, -1f)
                    val flipped = Bitmap.createBitmap(raw, 0, 0, W, H, m, false)
                    raw.recycle()
                    val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
                    val cv = android.graphics.Canvas(out)
                    cv.drawColor(0xFF0B0B10.toInt())
                    cv.drawBitmap(flipped, 0f, 0f, null)
                    flipped.recycle()
                    FlareThumbs.cache[key] = out
                } catch (e: Throwable) { }
            }
        } catch (e: Throwable) {
        } finally {
            sr.outFbo = saved
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, saved)
            try { GLES20.glDeleteFramebuffers(1, fb, 0); GLES20.glDeleteTextures(1, tex, 0) } catch (e: Throwable) { }
        }
        post { done() }
    }

    private class ThumbJob(val ids: List<String>, val done: () -> Unit) {
        var next = 0
        var ready = false
        val tex = IntArray(1)
        val fb = IntArray(1)
        var proj: Project? = null
        var sc: Scene? = null
        var layer: Layer? = null
        var buf: ByteBuffer? = null
    }

    /** Renders effect thumbnails two at a time with short gaps, so the live preview never freezes. */
    fun renderThumbs(ids: List<String>, portrait: String, done: () -> Unit) {
        val job = ThumbJob(ids, done)
        queueEvent { thumbStep(job) }
    }

    private fun thumbStep(job: ThumbJob) {
        if (!glReady) { postDelayed({ queueEvent { thumbStep(job) } }, 400); return }
        val W = 192
        val H = 256
        val saved = sr.outFbo
        try {
            if (!job.ready) {
                GLES20.glGenTextures(1, job.tex, 0)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, job.tex[0])
                GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, W, H, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
                GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
                GLES20.glGenFramebuffers(1, job.fb, 0)
                GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, job.fb[0])
                GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, job.tex[0], 0)
                val proj = Project()
                proj.w = W; proj.h = H
                val sc = proj.scenes[0]
                sc.duration = 5f
                val l = Layer(999999, "sample", LayerType.IMAGE)
                l.end = 5f
                sc.layers.add(l)
                job.proj = proj; job.sc = sc; job.layer = l
                job.buf = ByteBuffer.allocateDirect(W * H * 4).order(ByteOrder.nativeOrder())
                job.ready = true
            }
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, job.fb[0])
            sr.outFbo = job.fb[0]
            val proj = job.proj!!
            val sc = job.sc!!
            val l = job.layer!!
            val buf = job.buf!!
            var made = 0
            while (job.next < job.ids.size && made < 2) {
                val id = job.ids[job.next++]
                if (EffectThumbs.cache.containsKey(id)) continue
                made++
                try {
                    l.fx.clear(); l.fxOff.clear()
                    l.imagePath = EffectThumbs.pathOf(id)
                    if (!EffectThumbs.isOrig(id)) l.fx.add(id)
                    val t = if (id == "swing") 0.45f else (Registry.byId[id]?.previewTime ?: 0.7f)
                    sr.draw(proj, sc, t, W, H)
                    GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, job.fb[0])
                    buf.clear()
                    GLES20.glReadPixels(0, 0, W, H, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
                    val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
                    buf.rewind()
                    bmp.copyPixelsFromBuffer(buf)
                    val m = android.graphics.Matrix()
                    m.preScale(1f, -1f)
                    EffectThumbs.cache[id] = Bitmap.createBitmap(bmp, 0, 0, W, H, m, false)
                    bmp.recycle()
                    Registry.errors[id]?.let { EffectThumbs.lastError = id + ": " + it.take(120) }
                } catch (e: Throwable) {
                    EffectThumbs.lastError = (id + ": " + (e.message ?: e.toString())).take(160)
                    val o = EffectThumbs.cache[EffectThumbs.origKey(id)]
                    if (o != null) EffectThumbs.cache[id] = o
                }
            }
        } catch (e: Throwable) {
            EffectThumbs.lastError = (e.message ?: e.toString()).take(160)
            job.next = job.ids.size
        } finally {
            sr.outFbo = saved
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, saved)
        }
        if (job.next < job.ids.size) {
            postDelayed({ queueEvent { thumbStep(job) } }, 24)
        } else {
            try {
                if (job.ready) { GLES20.glDeleteFramebuffers(1, job.fb, 0); GLES20.glDeleteTextures(1, job.tex, 0) }
            } catch (e: Throwable) { }
            post { job.done() }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        applyQuality()
    }

    private fun applyQuality() {
        if (width <= 0 || height <= 0) return
        if (quality <= 1) holder.setSizeFromLayout()
        else holder.setFixedSize(width / quality, height / quality)
    }
}
