package com.saiki.motion

import android.content.Context
import org.json.JSONObject
import java.io.File

object Projects {
    class Info(val id: String, val name: String, val w: Int, val h: Int, val fps: Int, val modified: Long)

    private fun dir(ctx: Context) = File(ctx.filesDir, "projects").also { it.mkdirs() }
    fun mediaDir(ctx: Context) = File(ctx.filesDir, "media").also { it.mkdirs() }

    fun list(ctx: Context): List<Info> {
        val out = ArrayList<Info>()
        for (f in dir(ctx).listFiles() ?: emptyArray()) {
            if (!f.name.endsWith(".json")) continue
            try {
                val o = JSONObject(f.readText())
                out.add(Info(f.name.removeSuffix(".json"), o.optString("name", "Project"), o.optInt("w", 1920), o.optInt("h", 1080), o.optInt("fps", 30), f.lastModified()))
            } catch (e: Exception) { }
        }
        return out.sortedByDescending { it.modified }
    }

    fun create(ctx: Context, name: String, w: Int, h: Int, fps: Int): String {
        val id = "p" + System.currentTimeMillis()
        val p = Project()
        p.name = name; p.w = w; p.h = h; p.fps = fps
        save(ctx, id, p)
        return id
    }

    fun load(ctx: Context, id: String): Project =
        try { Store.fromJson(JSONObject(File(dir(ctx), "$id.json").readText())) } catch (e: Exception) { Project() }

    fun save(ctx: Context, id: String, p: Project) {
        try { File(dir(ctx), "$id.json").writeText(Store.toJson(p).toString()) } catch (e: Exception) { }
    }

    fun delete(ctx: Context, id: String) { File(dir(ctx), "$id.json").delete() }

    fun rename(ctx: Context, id: String, name: String) {
        val p = load(ctx, id); p.name = name; save(ctx, id, p)
    }

    fun duplicate(ctx: Context, id: String) {
        val p = load(ctx, id); p.name = p.name + " copy"
        save(ctx, "p" + System.currentTimeMillis(), p)
    }

    fun sizeBytes(ctx: Context): Long {
        var n = 0L
        for (d in listOf(dir(ctx), mediaDir(ctx))) for (f in d.listFiles() ?: emptyArray()) n += f.length()
        return n
    }

    fun resLabel(w: Int, h: Int): String {
        val s = minOf(w, h)
        return if (s >= 2160) "4K" else if (s >= 1440) "1440p" else "${s}p"
    }

    fun aspectLabel(w: Int, h: Int): String {
        val r = w.toFloat() / h
        val m = listOf("16:9" to 16f / 9f, "9:16" to 9f / 16f, "1:1" to 1f, "4:5" to 0.8f, "21:9" to 21f / 9f, "4:3" to 4f / 3f)
        return m.minByOrNull { Math.abs(it.second - r) }?.first ?: "custom"
    }
}
