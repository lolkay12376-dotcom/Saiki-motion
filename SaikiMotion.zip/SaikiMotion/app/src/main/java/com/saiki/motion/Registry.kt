package com.saiki.motion

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class ColorParam(val name: String, val label: String, val key: String, val def: Int)

class EffectDef(
    val id: String,
    val name: String,
    val desc: String,
    val category: String,
    val props: List<PropDef>,
    val inputs: List<String>,
    val code: String,
    val kind: Int,            // 0 = pixel shader pass, 1 = built-in transform-level effect
    val builtin: Boolean,
    val colors: List<ColorParam> = emptyList(),
    val source: String = "",              // folder path, or "asset:<path>" for effects bundled in the APK
    val previewImage: String? = null,     // browser sample image key, or "custom:<id>" for a file in the effect folder
    val previewPath: String? = null,
    val previewTime: Float = 0.7f,
    val previewAnim: String = "swipe"     // swipe | fade | cut | wipe
) {
    val bundled: Boolean get() = source.startsWith("asset:")
}

object Defs {
    val transform = listOf(
        PropDef("x", "Position X", -1e9f, 1e9f, 0f, 2, "x", null, true, 3f),
        PropDef("y", "Position Y", -1e9f, 1e9f, 0f, 2, "y", null, true, 3f),
        PropDef("scale", "Scale", -1e9f, 1e9f, 1f, 2, "scale", null, true, 4f),
        PropDef("opacity", "Opacity", 0f, 1f, 1f),
        PropDef("rotZ", "Rotation Z", -1e9f, 1e9f, 0f, 1, "rotZ", null, true, 720f)
    )
    val anchor = listOf(
        PropDef("anchorX", "Anchor X", -1e9f, 1e9f, 50f, 1, "anchorX", null, true, 140f),
        PropDef("anchorY", "Anchor Y", -1e9f, 1e9f, 50f, 1, "anchorY", null, true, 140f)
    )
    val pos3d = listOf(PropDef("z", "Position Z", -1e9f, 1e9f, 0f, 2, "z", null, true, 6f))
    val rot3d = listOf(
        PropDef("rotX", "Rotation X", -1e9f, 1e9f, 0f, 1, "rotX", null, true, 720f),
        PropDef("rotY", "Rotation Y", -1e9f, 1e9f, 0f, 1, "rotY", null, true, 720f)
    )
    val camera = listOf(PropDef("camFov", "Field of View", 15f, 120f, 45f, 0))
    val audio = listOf(PropDef("volume", "Volume", 0f, 1f, 1f))
    val blur = listOf(PropDef("mbAmount", "Shutter", 0f, 4f, 1f), PropDef("mbSamples", "Samples", 3f, 16f, 8f, 0))
    val text = listOf(PropDef("strokeW", "Stroke width", 0f, 20f, 0f, 1), PropDef("borderW", "Border width", 0f, 20f, 0f, 1),
        PropDef("borderPad", "Border padding", 0f, 60f, 10f, 0), PropDef("spacing", "Letter spacing", -0.1f, 1f, 0f),
        PropDef("lineSpacing", "Line spacing", 0.5f, 3f, 1f), PropDef("shadowBlur", "Shadow blur", 0f, 40f, 6f, 0),
        PropDef("shadowX", "Shadow X", -1e9f, 1e9f, 4f, 0, "shadowX", null, true, 40f), PropDef("shadowY", "Shadow Y", -1e9f, 1e9f, 4f, 0, "shadowY", null, true, 40f),
        PropDef("stroke2W", "Second stroke width", 0f, 20f, 0f, 1), PropDef("borderRadius", "Corner radius", 0f, 100f, 12f, 0))
    val scaleXY = listOf(PropDef("scaleX", "Scale X", -1e9f, 1e9f, 1f, 2, "scaleX", null, true, 4f), PropDef("scaleY", "Scale Y", -1e9f, 1e9f, 1f, 2, "scaleY", null, true, 4f))
    val particles = listOf(
        PropDef("pBirthRate", "Birth Rate", 0f, 20f, 3f, 1),
        PropDef("pLongevity", "Longevity (sec)", 0.1f, 10f, 2f, 1),
        PropDef("pProdX", "Producer X", -1e9f, 1e9f, 0f, 2, "pProdX", null, true, 3f),
        PropDef("pProdY", "Producer Y", -1e9f, 1e9f, 0f, 2, "pProdY", null, true, 3f),
        PropDef("pProdZ", "Producer Z", -1e9f, 1e9f, 0f, 2, "pProdZ", null, true, 3f),
        PropDef("pRadX", "Radius X", -1e9f, 1e9f, 0.1f, 2, "pRadX", null, true, 3f),
        PropDef("pRadY", "Radius Y", -1e9f, 1e9f, 0.1f, 2, "pRadY", null, true, 3f),
        PropDef("pRadZ", "Radius Z", -1e9f, 1e9f, 0.1f, 2, "pRadZ", null, true, 3f),
        PropDef("pAnim", "Animation", 0f, 4f, 0f, 0, "pAnim", listOf("Explosive", "Direction Axis", "Cone Axis", "Viscous", "Twirl")),
        PropDef("pVelocity", "Velocity", -1e9f, 1e9f, 1f, 2, "pVelocity", null, true, 8f),
        PropDef("pDirection", "Direction Angle", -180f, 180f, 90f, 0),
        PropDef("pSpread", "Cone Angle", 0f, 180f, 45f, 0),
        PropDef("pGravity", "Gravity", -1e9f, 1e9f, 0.4f, 2, "pGravity", null, true, 6f),
        PropDef("pResist", "Resistance", -1e9f, 1e9f, 0.2f, 2, "pResist", null, true, 8f),
        PropDef("pExtra", "Extra", -1e9f, 1e9f, 0.5f, 2, "pExtra", null, true, 5f),
        PropDef("pType", "Particle Type", 0f, 3f, 0f, 0, "pType", listOf("Faded Sphere", "Star", "Line", "Disc")),
        PropDef("pBirthSize", "Birth Size", -1e9f, 1e9f, 0.5f, 2, "pBirthSize", null, true, 6f),
        PropDef("pDeathSize", "Death Size", -1e9f, 1e9f, 0.15f, 2, "pDeathSize", null, true, 6f),
        PropDef("pSizeVar", "Size Variation", 0f, 1f, 0.3f),
        PropDef("pOpacity", "Max Opacity", 0f, 1f, 1f),
        PropDef("pFade", "Opacity Map", 0f, 2f, 0f, 0, "pFade", listOf("Fade Out", "Fade In-Out", "Constant")),
        PropDef("pAdd", "Transfer Mode", 0f, 1f, 0f, 0, "pAdd", listOf("Add", "Normal")),
        PropDef("pSeed", "Random Seed", 0f, 100f, 1f, 0)
    )
    val all: List<PropDef> get() = transform + scaleXY + anchor + pos3d + rot3d + camera + audio + text + blur
}

fun fxCategoryOf(d: EffectDef): String = when (d.id) {
    "deepglow", "lightsweep", "contour", "lightleak" -> "Light and glow"
    "tritone", "duotone", "hueshift", "grayscale", "invert", "rgbsplit", "vignette", "fill" -> "Color"
    "etching", "halftone", "zebrafy", "posterize", "filmgrain", "edgelines", "scanlines", "pixelate", "sharpen" -> "Stylize"
    "distortrgb", "kaleido", "bulge", "twirl", "barrel", "wavewarp", "ripple" -> "Distort"
    "blur", "radialblur", "blurmo" -> "Blur"
    "psykoblobs", "texturefolded", "texturemoire" -> "Generate"
    "sshake", "twitch", "glitchslices", "oscillate", "autoshake", "randisp", "streaks", "timeslice" -> "Glitch and motion"
    "chromakey" -> "Keying"
    else -> if (d.id.startsWith("shake_")) "Glitch and motion" else if (d.builtin) "Transform and time" else if (d.category in Registry.CATEGORIES) d.category else "Custom"
}

object Registry {
    val order = CopyOnWriteArrayList<EffectDef>()
    val byId = ConcurrentHashMap<String, EffectDef>()
    private val props = ConcurrentHashMap<String, PropDef>()
    val errors = ConcurrentHashMap<String, String>()

    fun get(id: String): EffectDef? = byId[id.substringBefore('~')]
    fun propDef(key: String): PropDef? {
        val i = key.indexOf('~')
        if (i > 0) { val j = key.indexOf("__", i); if (j > 0) return propDef(key.substring(0, i) + key.substring(j)) }
        return props[key] ?: Defs.all.firstOrNull { it.key == key } ?: colorDefault(key)
    }
    private fun colorDefault(key: String): PropDef? {
        if (key.length < 3) return null
        val sf = key.takeLast(2)
        val shift = when (sf) { "_r" -> 16; "_g" -> 8; "_b" -> 0; "_a" -> 24; else -> return null }
        val base = key.dropLast(2)
        for (d in order) for (c in d.colors) if (c.key == base) return PropDef(key, "", 0f, 1f, ((c.def ushr shift) and 255) / 255f)
        return null
    }
    fun baseId(entry: String) = entry.substringBefore('~')
    fun uniqueEntry(l: Layer, id: String): String {
        if (!l.fx.contains(id)) return id
        var n = 2
        while (l.fx.contains("$id~$n")) n++
        return "$id~$n"
    }
    /** Copies of the definition props/colors with keys rewritten for a specific instance. */
    fun instProp(l: Layer, entry: String, pd: PropDef): PropDef =
        if (!entry.contains('~')) pd else PropDef(l.pkey(entry, pd), pd.label, pd.min, pd.max, pd.def, pd.dec, pd.name, pd.options, pd.inf, pd.span)
    fun instColor(l: Layer, entry: String, cp: ColorParam): ColorParam =
        if (!entry.contains('~')) cp else ColorParam(cp.name, cp.label, l.ckey(entry, cp), cp.def)
    fun colorProps(c: ColorParam): List<PropDef> =
        listOf("_r" to ((c.def shr 16) and 255), "_g" to ((c.def shr 8) and 255), "_b" to (c.def and 255), "_a" to ((c.def ushr 24) and 255))
            .map { PropDef(c.key + it.first, c.label + it.first, 0f, 1f, it.second / 255f) }

    fun allProps(): List<PropDef> = Defs.all + order.flatMap { it.props + it.colors.flatMap { c -> colorProps(c) } }

    private fun add(d: EffectDef) {
        if (byId.containsKey(d.id)) order.remove(byId[d.id])
        byId[d.id] = d
        order.add(d)
        for (p in d.props) props[p.key] = p
        for (c in d.colors) for (pd in colorProps(c)) props[pd.key] = pd
    }

    class CP(val n: String, val label: String, val def: Int)

    class P(val n: String, val label: String, val min: Float, val max: Float, val def: Float, val dec: Int = 2, val opts: List<String>? = null, val inf: Boolean = false, val span: Float = 0f)

    private fun fx(id: String, name: String, cat: String, desc: String, ps: List<P>, inputs: List<String>, code: String, cols: List<CP> = emptyList()) {
        val defs = ps.map { PropDef(id + "__" + it.n, it.label, it.min, it.max, it.def, it.dec, it.n, it.opts, it.inf, it.span) }
        add(EffectDef(id, name, desc, cat, defs, inputs, code, 0, true, cols.map { ColorParam(it.n, it.label, id + "__" + it.n, it.def) }))
    }

    private fun shakeVariant(id: String, name: String, desc: String, mot: String, freq: Float, amt: Float, rot: Float, chroma: Boolean) {
        val sample = if (chroma) "vec2 o = s.xy * amount * 0.03; vec4 a = srcW(q + o, 2.0); vec4 b = srcW(q, 2.0); vec4 c = srcW(q - o, 2.0); acc += vec4(a.r, b.g, c.b, max(a.a, max(b.a, c.a)));"
            else "acc += srcW(q, 2.0);"
        val code = """
vec3 rn(float i){ return vec3(hash11(i + seed * 1.7), hash11(i + seed * 3.1 + 11.0), hash11(i + seed * 5.3 + 23.0)) - 0.5; }
vec3 sm(float f){ float i = floor(f); float u = fract(f); u = u * u * (3.0 - 2.0 * u); return mix(rn(i), rn(i + 1.0), u) * 2.0; }
""" + mot + """

vec4 effect(vec2 uv){
  vec4 acc = vec4(0.0);
  float asp = uRes.x / uRes.y;
  for (int k = 0; k < 8; k++) {
    float tt = uTime - float(k) / 7.0 * 0.03 * blur;
    vec3 s = mot(tt);
    float zm = 1.0 + zoom * (0.5 + 0.5 * abs(s.x));
    vec2 p = uv - 0.5;
    p.x *= asp;
    p = rot(p, radians(s.z * rotation)) / zm;
    p.x /= asp;
    vec2 q = p + 0.5 + s.xy * amount * 0.08;
    """ + sample + """
  }
  return acc / 8.0;
}"""
        fx(id, name, "Glitch and motion", desc,
            listOf(P("amount", "Amount", 0f, 1f, amt), P("frequency", "Frequency", 0f, 60f, freq, 1), P("rotation", "Rotation", 0f, 45f, rot, 1),
                P("zoom", "Zoom", 0f, 0.5f, 0.1f), P("blur", "Motion Blur", 0f, 1f, 0.5f), P("seed", "Seed", 0f, 100f, 1f, 0)),
            emptyList(), code)
    }

    private fun tfx(id: String, name: String, desc: String, ps: List<PropDef>, cat: String = "Transform") {
        add(EffectDef(id, name, desc, cat, ps, emptyList(), "", 1, true))
    }

    fun init(ctx: Context) {
        if (order.isNotEmpty()) { if (!sdkLoaded) loadAllCustom(ctx); return }
        tfx("tile", "Motion Tile", "Repeats the layer in a grid with scrolling, gaps and mirrored tiles.", listOf(
            PropDef("tileX", "Phase X", -4f, 4f, 0f), PropDef("tileY", "Phase Y", -4f, 4f, 0f),
            PropDef("tileGap", "Gap", -0.5f, 2f, 0f), PropDef("tileNX", "Tiles X", 0f, 6f, 2f, 0),
            PropDef("tileNY", "Tiles Y", 0f, 6f, 2f, 0), PropDef("tileMirror", "Mirror", 0f, 1f, 0f, 0, "tileMirror", listOf("Off", "On"))))
        tfx("remap", "Time Remap", "Changes the speed of the layer's animation and lets you keyframe which moment of the source plays.", listOf(
            PropDef("remapSpeed", "Speed", -4f, 4f, 1f),
            PropDef("remapT", "Time Remap", -1e9f, 1e9f, 0f, 2, "remapT", null, true, 4f),
            PropDef("remapInterp", "Frame Interpolation", 0f, 2f, 0f, 0, "remapInterp", listOf("Off", "Frame Blend", "Optical Flow"))))
        tfx("swing", "Swing", "Swings the layer back and forth around a pivot point like a pendulum.", listOf(
            PropDef("swingSpeed", "Speed", 0f, 30f, 7f, 0), PropDef("swingAngle", "Swing Angle", 0f, 90f, 17f, 0),
            PropDef("swingPX", "Pivot X", -100f, 100f, 0f, 0), PropDef("swingPY", "Pivot Y", -100f, 100f, 100f, 0)))
        tfx("shake", "Layer Shake", "Quick positional shake applied to the whole layer.", listOf(PropDef("shake", "Amount", 0f, 1f, 0.4f)))

        tfx("particles", "Particle World", "Emits particles from the layer with birth, physics, size and color controls, like CC Particle World. Turn Show Layer off to see only the particles. 3D layers use the camera above them.",
            Defs.particles + PropDef("pShowSrc", "Show Layer", 0f, 1f, 1f, 0, "pShowSrc", listOf("Off", "On")), "Generate")
        fx("distortrgb", "DistortRGB", "Sapphire-style", "Warps the red, green and blue channels by different amounts using the gradient of a Lens layer. Without a lens it uses a built-in bold pattern.",
            listOf(P("amount", "Amount", -3f, 3f, 1f), P("blurLens", "Blur Lens", 0f, 5f, 0.4f), P("rotate", "Rotate Warp Dir", -180f, 180f, 0f, 0),
                P("warpR", "Warp Red", -2f, 2f, 0.5f), P("warpG", "Warp Green", -2f, 2f, 0.75f), P("warpB", "Warp Blue", -2f, 2f, 1f),
                P("relX", "Amount Rel X", 0f, 2f, 1f), P("relY", "Amount Rel Y", 0f, 2f, 1f), P("wrap", "Wrap", 0f, 2f, 2f, 0, listOf("No", "Tile", "Reflect"))),
            listOf("Lens", "Matte"), """
float lensV(vec2 uv){
  if (uHas0 > 0.5) return luma(in0(uv).rgb);
  vec2 p = (uv - 0.5) * vec2(uRes.x / uRes.y, 1.0);
  return 0.5 + 0.25 * sin(p.x * 7.0) * cos(p.y * 7.0) + 0.25 * sin(length(p) * 9.0);
}
vec4 effect(vec2 uv){
  float e = (1.0 + blurLens * 2.0) / uRes.y;
  vec2 g = vec2(lensV(uv + vec2(e, 0.0)) - lensV(uv - vec2(e, 0.0)),
                lensV(uv + vec2(0.0, e)) - lensV(uv - vec2(0.0, e))) / (2.0 * e);
  g = rot(g, radians(rotate)) * vec2(relX, relY);
  float k = amount * 0.02;
  if (uHas1 > 0.5) k *= luma(in1(uv).rgb);
  vec4 r = srcW(uv + g * k * warpR, wrap);
  vec4 gg = srcW(uv + g * k * warpG, wrap);
  vec4 b = srcW(uv + g * k * warpB, wrap);
  return vec4(r.r, gg.g, b.b, max(r.a, max(gg.a, b.a)));
}""")

        fx("etching", "Etching", "Sapphire-style", "Turns the image into engraved ink lines whose thickness follows the brightness, with optional cross-hatching.",
            listOf(P("spacing", "Line Spacing", 2f, 40f, 9f, 0), P("angle", "Angle", -180f, 180f, 45f, 0), P("contrast", "Contrast", 0f, 3f, 1.3f),
                P("thickness", "Thickness", 0f, 1f, 0.55f), P("crossHatch", "Cross Hatch", 0f, 1f, 0.35f), P("colorMix", "Keep Color", 0f, 1f, 0f), P("amount", "Amount", 0f, 1f, 1f)),
            emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  float L = clamp((luma(c.rgb) - 0.5) * contrast + 0.5, 0.0, 1.0);
  float D = 1.0 - L;
  vec2 p = uv * uRes;
  float a = radians(angle);
  float d1 = abs(fract(dot(p, vec2(cos(a), sin(a))) / spacing) - 0.5) * 2.0;
  float w1 = D * thickness * 1.3;
  float ink = 1.0 - smoothstep(w1 - 0.1, w1 + 0.1, d1);
  float d2 = abs(fract(dot(p, vec2(-sin(a), cos(a))) / spacing) - 0.5) * 2.0;
  float w2 = max(D - 0.5, 0.0) * crossHatch * 2.2;
  ink = max(ink, 1.0 - smoothstep(w2 - 0.1, w2 + 0.1, d2));
  vec3 paper = vec3(0.96, 0.94, 0.88);
  vec3 inkc = mix(vec3(0.07, 0.06, 0.09), c.rgb * 0.55, colorMix);
  vec3 res = mix(paper, inkc, ink);
  vec3 o = mix(c.rgb, res, amount);
  return vec4(o * c.a, c.a);
}""")

        fx("halftone", "HalfTone", "Sapphire-style", "Rebuilds the image from a rotated grid of dots; dot size follows brightness. Black, colored or on-black modes.",
            listOf(P("cell", "Dot Spacing", 3f, 80f, 14f, 0), P("angle", "Angle", 0f, 90f, 45f, 0), P("softness", "Softness", 0f, 1f, 0.25f),
                P("dotScale", "Dot Scale", 0.3f, 1.6f, 1f), P("colorMode", "Mode", 0f, 2f, 1f, 0, listOf("Black on white", "Color on white", "Color on black"))),
            emptyList(), """
vec4 effect(vec2 uv){
  vec4 c0 = unpremul(src(uv));
  vec2 p = uv * uRes;
  float a = radians(angle);
  vec2 q = rot(p, a);
  vec2 cc = (floor(q / cell) + 0.5) * cell;
  vec4 cs = unpremul(src(rot(cc, -a) / uRes));
  float L = luma(cs.rgb);
  float D = colorMode > 1.5 ? L : 1.0 - L;
  float rad = sqrt(D) * cell * 0.72 * dotScale;
  float m = 1.0 - smoothstep(rad - softness * cell * 0.4 - 0.5, rad + 0.5, length(q - cc));
  vec3 col;
  if (colorMode < 0.5) col = mix(vec3(1.0), vec3(0.05), m);
  else if (colorMode < 1.5) col = mix(vec3(1.0), cs.rgb, m);
  else col = mix(vec3(0.0), cs.rgb, m);
  return vec4(col * c0.a, c0.a);
}""")

        fx("psykoblobs", "S_PsykoBlobs", "Sapphire-style", "Combines the source with a field of blob shapes and passes them through a colorization process. Phase Speed rotates the colors over time. Mask: white areas use the result, black areas use the source.",
            listOf(P("noiseFreq", "Noise Freq", 0.01f, 40f, 4f), P("noiseRelx", "Noise Freq Relx", 0.01f, 8f, 1f), P("noiseOctaves", "Noise Octaves", 1f, 10f, 1f, 0),
                P("noiseSeed", "Noise Seed", 0f, 100f, 0.23f), P("shiftX", "Noise Shift X", -10f, 10f, 0f), P("shiftY", "Noise Shift Y", -10f, 10f, 0f),
                P("sourceBlur", "Source Blur", 0f, 1f, 0.088f), P("sourceScale", "Source Scale", 0f, 4f, 1f), P("freqColors", "Freq Colors", 0f, 20f, 4f),
                P("freqRed", "Freq Red", 0f, 5f, 1f), P("freqGreen", "Freq Green", 0f, 5f, 1.1f), P("freqBlue", "Freq Blue", 0f, 5f, 1.2f),
                P("phaseStart", "Phase Start", -5f, 5f, 0.5f), P("phaseSpeed", "Phase Speed", -5f, 5f, 1f),
                P("phaseRed", "Phase Red", -2f, 2f, 0f), P("phaseGreen", "Phase Green", -2f, 2f, 0f), P("phaseBlue", "Phase Blue", -2f, 2f, 0f),
                P("brightness", "Brightness", 0f, 4f, 1f), P("offset", "Offset", -2f, 2f, 0f), P("saturation", "Saturation", 0f, 4f, 1f),
                P("scaleBySource", "Scale By Source", 0f, 1f, 0f), P("scaleAmp", "Scale By Src Amp", 0f, 8f, 1f), P("mixSrc", "Mix With Source", 0f, 1f, 0f),
                P("fill", "Fill Transparent", 0f, 1f, 0f)),
            listOf("Mask"), """
float nz(vec2 p){
  float s = 0.0;
  float a = 1.0;
  float tot = 0.0;
  for (int i = 0; i < 10; i++) {
    if (float(i) >= noiseOctaves) break;
    s += a * vnoise(p);
    tot += a;
    p *= 2.0;
    a *= 0.5;
  }
  return s / tot;
}
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  float asp = uRes.x / uRes.y;
  float rb = sourceBlur * 0.06;
  vec4 sb = c;
  for (int i = 0; i < 8; i++) {
    float a = float(i) * 0.7854;
    sb += src(uv + vec2(cos(a), sin(a) * asp) * rb);
  }
  sb /= 9.0;
  vec4 cu = unpremul(c);
  float L = luma(unpremul(sb).rgb);
  vec2 p = (uv - 0.5) * vec2(asp, 1.0) * vec2(noiseFreq * noiseRelx, noiseFreq) + vec2(shiftX, shiftY) + noiseSeed * 37.0;
  float v = nz(p) + sourceScale * L;
  float ph = phaseStart + phaseSpeed * uTime * 0.5;
  vec3 f = vec3(freqRed, freqGreen, freqBlue) * freqColors;
  vec3 col = 0.5 + 0.5 * cos(6.2832 * (f * v + vec3(phaseRed, phaseGreen, phaseBlue) + ph));
  col = mix(vec3(luma(col)), col, saturation);
  col = col * brightness * tint.rgb * tint.a + offset;
  float k = mix(1.0, clamp(luma(cu.rgb) * scaleAmp, 0.0, 1.0), scaleBySource);
  col = clamp(col * k, 0.0, 1.0);
  vec3 res = mix(col, cu.rgb, mixSrc);
  float m = uHas0 > 0.5 ? luma(in0(uv).rgb) : 1.0;
  vec3 o = mix(cu.rgb, res, m);
  float a2 = mix(c.a, 1.0, fill * m);
  return vec4(o * a2, a2);
}""", listOf(CP("tint", "Color", 0xFFFFFFFF.toInt())))
        fx("sshake", "Shake", "Sapphire-style", "Random camera shake of the image with rotation, zoom and shutter motion blur.",
            listOf(P("amount", "Amount", 0f, 1f, 0.3f), P("frequency", "Frequency", 0f, 30f, 8f, 1), P("rotation", "Rotation", 0f, 30f, 2f, 1),
                P("zoom", "Zoom", 0f, 0.5f, 0.1f), P("blur", "Motion Blur", 0f, 1f, 0.5f), P("seed", "Seed", 0f, 100f, 1f, 0)),
            emptyList(), """
vec3 shk(float t){
  float f = t * frequency;
  float i = floor(f);
  float u = fract(f);
  u = u * u * (3.0 - 2.0 * u);
  vec3 a = vec3(hash11(i + seed * 1.7), hash11(i + seed * 3.1 + 11.0), hash11(i + seed * 5.3 + 23.0)) - 0.5;
  vec3 b = vec3(hash11(i + 1.0 + seed * 1.7), hash11(i + 1.0 + seed * 3.1 + 11.0), hash11(i + 1.0 + seed * 5.3 + 23.0)) - 0.5;
  return mix(a, b, u) * 2.0;
}
vec4 effect(vec2 uv){
  vec4 acc = vec4(0.0);
  float asp = uRes.x / uRes.y;
  for (int k = 0; k < 8; k++) {
    float tt = uTime - float(k) / 7.0 * 0.03 * blur;
    vec3 s = shk(tt);
    float zm = 1.0 + zoom * (0.5 + 0.5 * abs(s.x));
    vec2 p = uv - 0.5;
    p.x *= asp;
    p = rot(p, radians(s.z * rotation)) / zm;
    p.x /= asp;
    acc += srcW(p + 0.5 + s.xy * amount * 0.08, 2.0);
  }
  return acc / 8.0;
}""")


        fx("fill", "Fill", "Color", "Covers the layer's shape with a solid color. Choose how it blends with the original pixels.",
            listOf(P("amount", "Amount", 0f, 1f, 1f), P("mode", "Blend", 0f, 4f, 0f, 0, listOf("Normal", "Add", "Multiply", "Screen", "Overlay"))),
            emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  vec3 u = c.a > 0.0001 ? c.rgb / c.a : vec3(0.0);
  vec3 f = fillColor.rgb;
  vec3 r = f;
  if (mode > 0.5 && mode < 1.5) r = u + f;
  else if (mode > 1.5 && mode < 2.5) r = u * f;
  else if (mode > 2.5 && mode < 3.5) r = 1.0 - (1.0 - u) * (1.0 - f);
  else if (mode > 3.5) r = mix(2.0 * u * f, 1.0 - 2.0 * (1.0 - u) * (1.0 - f), step(0.5, u));
  r = mix(u, clamp(r, 0.0, 1.0), clamp(amount, 0.0, 1.0) * fillColor.a);
  return vec4(r * c.a, c.a);
}""", listOf(CP("fillColor", "Color", 0xFFFF4D6D.toInt())))

        fx("blurmo", "S_BlurMoCurves", "Blur", "Sapphire-style motion blur that moves through a 3D-like transform during the shutter: push in or out, rotate and shift.",
            listOf(P("zdist", "Z Dist", -2f, 2f, 0.5f), P("rotate", "Rotate", -180f, 180f, 10f, 1), P("shiftX", "Shift X", -1f, 1f, 0f),
                P("shiftY", "Shift Y", -1f, 1f, 0f), P("shutter", "Shutter", 0f, 3f, 1f)),
            emptyList(), """
vec4 effect(vec2 uv){
  float asp = uRes.x / uRes.y;
  vec4 acc = vec4(0.0);
  for (int i = 0; i < 16; i++) {
    float k = (float(i) / 15.0 - 0.5) * shutter;
    vec2 p = uv - 0.5;
    p.x *= asp;
    p = rot(p, radians(rotate * k)) / max(1.0 + zdist * k, 0.05);
    p.x /= asp;
    p += 0.5 - vec2(shiftX, shiftY) * k;
    acc += srcW(p, 0.0);
  }
  return acc / 16.0;
}""")

        fx("oscillate", "Oscillate", "Glitch and motion", "Moves the layer back and forth along a line (Sine) or around a circle (Orbit), forever.",
            listOf(P("mode", "Type", 0f, 1f, 0f, 0, listOf("Sine", "Orbit")), P("amp", "Amplitude", 0f, 2f, 0.2f), P("freq", "Frequency", 0f, 10f, 1.5f),
                P("angle", "Angle", -180f, 180f, 0f, 1), P("phase", "Phase", -1e9f, 1e9f, 0f, 2, null, true, 6.3f)),
            emptyList(), """
vec4 effect(vec2 uv){
  float asp = uRes.x / uRes.y;
  float ph = uTime * freq * 6.2831853 + phase;
  float a = radians(angle);
  vec2 d = mode < 0.5 ? vec2(cos(a), sin(a)) * sin(ph) : vec2(cos(a + ph), sin(a + ph));
  d *= amp;
  d.x /= asp;
  return srcW(uv - d, 0.0);
}""")

        fx("autoshake", "Auto Shake", "Glitch and motion", "Shakes in bursts that kick in on their own and settle down, like repeated impacts.",
            listOf(P("amount", "Amount", 0f, 1f, 0.5f), P("rate", "Bursts per second", 0.1f, 6f, 1.5f), P("decay", "Decay", 0.5f, 12f, 5f, 1),
                P("rotation", "Rotation", 0f, 30f, 3f, 1), P("shkFreq", "Shake speed", 5f, 60f, 28f, 0), P("blur", "Motion Blur", 0f, 1f, 0.5f), P("seed", "Seed", 0f, 100f, 1f, 0)),
            emptyList(), """
vec3 rn(float i){ return vec3(hash11(i + seed * 1.7), hash11(i + seed * 3.1 + 11.0), hash11(i + seed * 5.3 + 23.0)) - 0.5; }
vec3 mot(float t){
  float b = floor(t * rate);
  float ph = fract(t * rate);
  float env = exp(-ph * decay) * (0.6 + 0.8 * hash11(b + seed));
  float f = t * shkFreq;
  float i = floor(f);
  float u = fract(f);
  u = u * u * (3.0 - 2.0 * u);
  return mix(rn(i), rn(i + 1.0), u) * 2.0 * env;
}
vec4 effect(vec2 uv){
  vec4 acc = vec4(0.0);
  float asp = uRes.x / uRes.y;
  for (int k = 0; k < 8; k++) {
    float tt = uTime - float(k) / 7.0 * 0.03 * blur;
    vec3 s = mot(tt);
    vec2 p = uv - 0.5;
    p.x *= asp;
    p = rot(p, radians(s.z * rotation)) / (1.0 + 0.08 * abs(s.x));
    p.x /= asp;
    acc += srcW(p + 0.5 + s.xy * amount * 0.08, 2.0);
  }
  return acc / 8.0;
}""")

        fx("randisp", "Random Displacement", "Glitch and motion", "Cuts the picture into blocks and nudges each block by a random amount that changes over time.",
            listOf(P("blocksX", "Columns", 1f, 64f, 12f, 0), P("blocksY", "Rows", 1f, 64f, 8f, 0), P("amount", "Amount", 0f, 1f, 0.3f),
                P("speed", "Change rate", 0f, 30f, 8f, 1), P("seed", "Seed", 0f, 100f, 1f, 0), P("axis", "Direction", 0f, 2f, 0f, 0, listOf("Both", "Horizontal", "Vertical"))),
            emptyList(), """
vec4 effect(vec2 uv){
  vec2 cell = floor(uv * vec2(blocksX, blocksY));
  float tick = floor(uTime * speed);
  float h1 = hash21(cell + tick * 7.13 + seed);
  float h2 = hash21(cell + tick * 3.77 + seed + 41.0);
  vec2 o = (vec2(h1, h2) - 0.5) * amount * 0.4;
  float on = step(0.5, hash21(cell + tick + seed * 2.0 + 90.0));
  if (axis > 0.5 && axis < 1.5) o.y = 0.0;
  if (axis > 1.5) o.x = 0.0;
  return srcW(uv + o * on, 2.0);
}""")

        fx("streaks", "Motion Streaks", "Glitch and motion", "Pulls bright areas into long directional streaks.",
            listOf(P("streakLen", "Length", 0f, 2f, 0.6f), P("angle", "Angle", 0f, 360f, 0f, 0), P("thresh", "Threshold", 0f, 1f, 0.55f),
                P("intensity", "Intensity", 0f, 4f, 1.5f), P("falloff", "Falloff", 0.2f, 6f, 1.8f)),
            emptyList(), """
vec4 effect(vec2 uv){
  vec4 base = src(uv);
  float asp = uRes.x / uRes.y;
  vec2 dir = vec2(cos(radians(angle)), sin(radians(angle))) * streakLen * 0.3;
  dir.x /= asp;
  vec3 acc = vec3(0.0);
  float aacc = 0.0;
  float ws = 0.0;
  for (int i = 0; i < 32; i++) {
    float k = float(i) / 31.0;
    float w = pow(max(1.0 - k, 0.0001), falloff);
    vec4 s = srcW(uv - dir * k, 0.0);
    vec3 u = s.a > 0.0001 ? s.rgb / s.a : vec3(0.0);
    float lum = dot(u, vec3(0.299, 0.587, 0.114));
    float m = smoothstep(thresh, thresh + 0.15, lum) * s.a;
    acc += u * m * w;
    aacc += m * w;
    ws += w;
  }
  acc /= ws;
  aacc /= ws;
  vec3 st = acc * intensity * streakTint.rgb;
  float sa = clamp(aacc * intensity, 0.0, 1.0);
  return vec4(base.rgb + st, clamp(max(base.a, sa), 0.0, 1.0));
}""", listOf(CP("streakTint", "Tint", 0xFFFFFFFF.toInt())))

        shakeVariant("shake_handheld", "Shake: Handheld", "Slow, drifting camera shake like a hand-held shot.",
            "vec3 mot(float t){ return sm(t * frequency * 0.35) * 0.7 + sm(t * frequency * 1.3 + 17.0) * 0.3; }", 6f, 0.25f, 1.5f, false)
        shakeVariant("shake_earthquake", "Shake: Earthquake", "Fast, heavy rumbling shake.",
            "vec3 mot(float t){ return sm(t * frequency * 2.0) * 0.8 + sm(t * frequency * 5.0 + 3.0) * 0.5; }", 12f, 0.6f, 3f, false)
        shakeVariant("shake_impact", "Shake: Impact", "Hard hits that die away, repeating at the chosen rate.",
            "vec3 mot(float t){ float r = frequency * 0.25; float b = floor(t * r); float ph = fract(t * r); float env = exp(-ph * 7.0) * (0.7 + 0.6 * hash11(b + seed)); return sm(t * frequency * 4.0) * env; }", 8f, 0.8f, 4f, false)
        shakeVariant("shake_wobble", "Shake: Wobble", "Smooth rocking motion with a lot of rotation.",
            "vec3 mot(float t){ return vec3(sin(t * frequency * 1.7) * 0.35, sin(t * frequency * 1.1 + 1.3) * 0.35, sin(t * frequency * 1.3 + 0.5)); }", 4f, 0.3f, 8f, false)
        shakeVariant("shake_glitch", "Shake: Glitch", "Jumpy, stepped shake with a red-blue color split.",
            "vec3 mot(float t){ float f = floor(t * frequency); float hold = step(0.45, hash11(f + seed * 9.1)); return rn(f) * 2.0 * hold; }", 10f, 0.7f, 2f, true)

        tfx("timeslice", "TimeSlice", "Cuts the layer into slices and shows each slice at a slightly different moment in time.", listOf(
            PropDef("tsCount", "Slices", 2f, 48f, 8f, 0), PropDef("tsOffset", "Offset (frames)", -30f, 30f, 3f, 1),
            PropDef("tsDir", "Direction", 0f, 3f, 0f, 0, "tsDir", listOf("Left to right", "Right to left", "Top to bottom", "Bottom to top"))), "Glitch and motion")

        fx("texturefolded", "TextureFolded", "Sapphire-style", "Procedural folded-paper relief lit from an angle and blended over the image.",
            listOf(P("scale", "Scale", 1f, 20f, 4f), P("folds", "Folds", 1f, 8f, 4f, 0), P("sharp", "Sharpness", 0f, 1f, 0.6f),
                P("lightAngle", "Light Angle", 0f, 360f, 45f, 0), P("relief", "Relief", 0f, 2f, 1f), P("animate", "Drift", 0f, 2f, 0.3f), P("amount", "Amount", 0f, 1f, 0.8f)),
            emptyList(), """
float heightF(vec2 p){
  float h = 0.0;
  float k = 1.0;
  for (int i = 0; i < 8; i++) {
    if (float(i) >= folds) break;
    p = abs(p) - vec2(0.55 + 0.07 * float(i), 0.35);
    p = rot(p, 0.9 + 0.4 * float(i) + uTime * animate * 0.05);
    h += abs(p.x) * k;
    k *= 0.65;
  }
  return h;
}
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  vec2 p = (uv - 0.5) * vec2(uRes.x / uRes.y, 1.0) * scale * 0.5;
  float e = 0.01;
  float h0 = heightF(p);
  vec2 n = vec2(heightF(p + vec2(e, 0.0)) - h0, heightF(p + vec2(0.0, e)) - h0) / e * sharp;
  vec2 L = vec2(cos(radians(lightAngle)), sin(radians(lightAngle)));
  float shade = 0.55 + clamp(dot(n, L) * 0.25 * relief, -0.45, 0.45);
  vec3 o = mix(c.rgb, c.rgb * shade * 1.8, amount);
  return vec4(o * c.a, c.a);
}""")

        fx("texturemoire", "TextureMoire", "Sapphire-style", "Interfering ring patterns create a moire texture that can be overlaid, multiplied or replace the image.",
            listOf(P("frequency", "Frequency", 2f, 120f, 40f, 0), P("offset", "Ring Offset", 0f, 1f, 0.12f), P("spin", "Spin", 0f, 2f, 0.2f),
                P("contrast", "Contrast", 0f, 3f, 1.4f), P("tintHue", "Tint Hue", 0f, 1f, 0.6f), P("tintAmt", "Tint Amount", 0f, 1f, 0f),
                P("amount", "Amount", 0f, 1f, 0.7f), P("mode", "Blend", 0f, 2f, 0f, 0, listOf("Overlay", "Multiply", "Replace"))),
            emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  vec2 p = (uv - 0.5) * vec2(uRes.x / uRes.y, 1.0);
  float a = uTime * spin;
  vec2 c1 = vec2(cos(a), sin(a)) * offset;
  float f1 = sin(length(p - c1) * frequency * 6.2832);
  float f2 = sin(length(p + c1) * frequency * 6.2832);
  float m = clamp((0.5 + 0.5 * f1 * f2 - 0.5) * contrast + 0.5, 0.0, 1.0);
  vec3 tex = mix(vec3(m), hsv2rgb(vec3(tintHue, 0.6, m)), tintAmt);
  vec3 bl;
  if (mode < 0.5) bl = mix(2.0 * c.rgb * tex, 1.0 - 2.0 * (1.0 - c.rgb) * (1.0 - tex), step(0.5, c.rgb));
  else if (mode < 1.5) bl = c.rgb * tex * 1.5;
  else bl = tex;
  vec3 o = mix(c.rgb, bl, amount);
  return vec4(o * c.a, c.a);
}""")

        fx("zebrafy", "Zebrafy", "Sapphire-style", "Converts brightness into zebra stripes: brighter areas get wider stripes.",
            listOf(P("stripes", "Stripes", 2f, 120f, 28f, 0), P("angle", "Angle", -90f, 90f, 35f, 0), P("softness", "Softness", 0f, 1f, 0.12f),
                P("bias", "Brightness Bias", -0.5f, 0.5f, 0f), P("invert", "Invert", 0f, 1f, 0f, 0, listOf("Off", "On")),
                P("colorize", "Keep Color", 0f, 1f, 0f), P("amount", "Amount", 0f, 1f, 1f)),
            emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  float L = clamp(luma(c.rgb) + bias, 0.0, 1.0);
  vec2 p = (uv - 0.5) * vec2(uRes.x / uRes.y, 1.0);
  float a = radians(angle);
  float f = fract(dot(p, vec2(cos(a), sin(a))) * stripes);
  float m = 1.0 - smoothstep(L - softness * 0.5 - 0.001, L + softness * 0.5 + 0.001, f);
  if (invert > 0.5) m = 1.0 - m;
  vec3 zc = mix(vec3(m), c.rgb * m, colorize);
  vec3 o = mix(c.rgb, zc, amount);
  return vec4(o * c.a, c.a);
}""")

        fx("twitch", "Twitch", "Video Copilot-style", "Random flicker hits: shake, zoom punch, RGB split, glitch bands and flashes that decay after each beat.",
            listOf(P("intensity", "Intensity", 0f, 2f, 1f), P("frequency", "Twitches / sec", 0.5f, 30f, 7f, 1), P("shake", "Shake", 0f, 1f, 0.5f),
                P("split", "RGB Split", 0f, 1f, 0.5f), P("zoom", "Zoom Punch", 0f, 1f, 0.3f), P("flash", "Flash", 0f, 1f, 0.35f),
                P("glitch", "Glitch Bands", 0f, 1f, 0.4f), P("seed", "Seed", 0f, 100f, 3f, 0)),
            emptyList(), """
vec4 effect(vec2 uv){
  float f = uTime * frequency;
  float i = floor(f);
  float ph = fract(f);
  float on = step(0.45, hash11(i * 1.37 + seed));
  float k = on * pow(1.0 - ph, 2.5) * intensity;
  vec2 dir = vec2(hash11(i + seed * 2.0) - 0.5, hash11(i + seed * 5.0) - 0.5) * 2.0;
  float zm = 1.0 + zoom * 0.25 * k * (hash11(i + 9.0) > 0.5 ? 1.0 : -0.5);
  vec2 p = (uv - 0.5) / zm + 0.5 + dir * shake * 0.07 * k;
  float bh = hash21(vec2(floor(uv.y * 24.0), i + seed));
  p.x += (bh - 0.5) * 0.25 * step(0.78, bh) * k * glitch;
  float sp = split * 0.03 * k;
  vec4 a = srcW(p + vec2(sp, 0.0), 0.0);
  vec4 b = srcW(p, 0.0);
  vec4 d = srcW(p - vec2(sp, 0.0), 0.0);
  vec4 c = vec4(a.r, b.g, d.b, max(a.a, max(b.a, d.a)));
  c.rgb += c.a * flash * 0.6 * k * step(0.5, hash11(i + 3.3));
  return c;
}""")

        fx("deepglow", "Deep Glow", "Glow", "Physically based glow with an inverse-square falloff: bright areas bleed outward over eight octaves, smooth and clean, and beyond the edge of the layer. Falloff 1 is physically accurate (lower = longer tail), Radius widens the glow, Exposure sets strength, Tint colors it.",
            listOf(P("radius", "Radius", 0f, 1f, 0.55f), P("exposure", "Exposure", 0f, 5f, 1.6f), P("threshold", "Threshold", 0f, 1f, 0.5f), P("softness", "Softness", 0f, 1f, 0.5f),
                P("falloff", "Falloff", 0.2f, 3f, 1f), P("tintAmt", "Tint Amount", 0f, 1f, 0f)), emptyList(), """
vec4 effect(vec2 uv){ return src(uv); }""", listOf(CP("tint", "Tint Color", 0xFFFF9A3C.toInt())))
        fx("rgbsplit", "RGB Split", "Color", "Separates the red and blue channels along an angle for a chromatic aberration look.",
            listOf(P("amount", "Amount", 0f, 1f, 0.4f), P("angle", "Angle", 0f, 360f, 0f, 0)), emptyList(), """
vec4 effect(vec2 uv){
  vec2 o = vec2(cos(radians(angle)), sin(radians(angle))) * amount * 0.04;
  vec4 a = srcW(uv + o, 0.0);
  vec4 b = src(uv);
  vec4 d = srcW(uv - o, 0.0);
  return vec4(a.r, b.g, d.b, max(a.a, max(b.a, d.a)));
}""")
        fx("blur", "Blur", "Blur", "Smooth gaussian-style blur.", listOf(P("radius", "Radius", 0f, 1f, 0.4f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 acc = vec4(0.0);
  float ws = 0.0;
  for (int i = -2; i <= 2; i++) {
    for (int j = -2; j <= 2; j++) {
      float w = exp(-float(i * i + j * j) * 0.4);
      acc += srcW(uv + vec2(float(i), float(j)) * radius * 0.02, 0.0) * w;
      ws += w;
    }
  }
  return acc / ws;
}""")
        fx("wavewarp", "Wave Warp", "Distort", "Ripples the picture with an animated sine wave.",
            listOf(P("amount", "Amount", 0f, 1f, 0.5f), P("freq", "Frequency", 1f, 60f, 18f, 0), P("speed", "Speed", 0f, 20f, 6f, 1),
                P("dir", "Direction", 0f, 1f, 0f, 0, listOf("Horizontal", "Vertical"))), emptyList(), """
vec4 effect(vec2 uv){
  float w = sin((dir < 0.5 ? uv.y : uv.x) * freq + uTime * speed) * amount * 0.06;
  vec2 p = dir < 0.5 ? vec2(uv.x + w, uv.y) : vec2(uv.x, uv.y + w);
  return srcW(p, 0.0);
}""")
        fx("pixelate", "Pixelate", "Stylize", "Blocky mosaic pixels.", listOf(P("size", "Pixel Size", 2f, 120f, 24f, 0)), emptyList(), """
vec4 effect(vec2 uv){
  vec2 cell = vec2(size) / uRes;
  return src((floor(uv / cell) + 0.5) * cell);
}""")
        fx("grayscale", "Grayscale", "Color", "Removes color.", listOf(P("amount", "Amount", 0f, 1f, 1f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  return vec4(mix(c.rgb, vec3(luma(c.rgb)), amount), c.a);
}""")
        fx("invert", "Invert", "Color", "Inverts the colors.", listOf(P("amount", "Amount", 0f, 1f, 1f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  return vec4(mix(c.rgb, vec3(c.a) - c.rgb, amount), c.a);
}""")
        fx("vignette", "Vignette", "Color", "Darkens the edges of the picture.",
            listOf(P("amount", "Amount", 0f, 1f, 0.6f), P("radius", "Radius", 0.2f, 1.5f, 0.8f), P("softness", "Softness", 0.05f, 1f, 0.5f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  float d = length((uv - 0.5) * vec2(uRes.x / uRes.y, 1.0));
  float v = 1.0 - smoothstep(radius - softness * radius, radius, d);
  return c * mix(1.0, v, amount);
}""")
        fx("scanlines", "Scanlines", "Stylize", "Retro CRT scanlines with optional flicker.",
            listOf(P("lines", "Line Count", 50f, 800f, 240f, 0), P("strength", "Strength", 0f, 1f, 0.4f), P("flicker", "Flicker", 0f, 1f, 0.2f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  float s = 0.5 + 0.5 * sin(uv.y * lines * 6.2832 + uTime * flicker * 20.0);
  float m = 1.0 - strength * s;
  float k = 1.0 + 0.1 * sin(uv.x * uRes.x * 1.5);
  return vec4(c.rgb * m * k, c.a);
}""")
        fx("duotone", "Duotone", "Color", "Maps shadows and highlights to two colors you choose.",
            listOf(P("contrast", "Contrast", 0f, 2f, 1f), P("amount", "Amount", 0f, 1f, 1f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  float L = clamp((luma(c.rgb) - 0.5) * contrast + 0.5, 0.0, 1.0);
  vec3 o = mix(c.rgb, mix(shadows.rgb, highlights.rgb, L), amount * mix(shadows.a, highlights.a, L));
  return vec4(o * c.a, c.a);
}""", listOf(CP("shadows", "Shadows", 0xFF2A1B6B.toInt()), CP("highlights", "Highlights", 0xFFFF9ED2.toInt())))
        fx("kaleido", "Kaleidoscope", "Distort", "Mirrors the picture into rotating segments.",
            listOf(P("segments", "Segments", 2f, 16f, 6f, 0), P("angle", "Angle", 0f, 360f, 0f, 0), P("zoom", "Zoom", 0.3f, 3f, 1f), P("amount", "Amount", 0f, 1f, 1f)), emptyList(), """
vec4 effect(vec2 uv){
  float asp = uRes.x / uRes.y;
  vec2 p = (uv - 0.5) * vec2(asp, 1.0);
  float a = atan(p.y, p.x) + radians(angle);
  float r = length(p) / zoom;
  float seg = 6.2831853 / segments;
  a = abs(mod(a, seg) - seg * 0.5);
  vec2 q = vec2(cos(a), sin(a)) * r;
  q.x /= asp;
  return mix(src(uv), srcW(q + 0.5, 2.0), amount);
}""")
        fx("posterize", "Posterize", "Color", "Reduces the number of colors for a poster look.",
            listOf(P("levels", "Levels", 2f, 16f, 5f, 0), P("amount", "Amount", 0f, 1f, 1f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  vec3 q = floor(c.rgb * levels + 0.5) / levels;
  return vec4(mix(c.rgb, q, amount) * c.a, c.a);
}""")
        fx("filmgrain", "Film Grain", "Stylize", "Animated film grain noise.",
            listOf(P("amount", "Amount", 0f, 1f, 0.35f), P("size", "Grain Size", 1f, 6f, 1.5f), P("speed", "Speed", 0f, 30f, 24f, 0)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  float n = hash21(floor(uv * uRes / size) + floor(uTime * speed) * 17.0) - 0.5;
  return vec4(c.rgb + n * amount * c.a, c.a);
}""")
        fx("edgelines", "Edge Lines", "Stylize", "Sobel edge detection that draws bright outlines.",
            listOf(P("strength", "Strength", 0f, 4f, 1.5f), P("thickness", "Thickness", 0.5f, 4f, 1f), P("amount", "Amount", 0f, 1f, 1f)), emptyList(), """
float lm(vec2 p){ return luma(src(p).rgb); }
vec4 effect(vec2 uv){
  vec2 e = vec2(thickness) / uRes;
  float a = lm(uv + vec2(-e.x, -e.y)); float b = lm(uv + vec2(0.0, -e.y)); float c = lm(uv + vec2(e.x, -e.y));
  float d = lm(uv + vec2(-e.x, 0.0)); float f = lm(uv + vec2(e.x, 0.0));
  float g = lm(uv + vec2(-e.x, e.y)); float h = lm(uv + vec2(0.0, e.y)); float i = lm(uv + vec2(e.x, e.y));
  float gx = -a - 2.0 * d - g + c + 2.0 * f + i;
  float gy = -a - 2.0 * b - c + g + 2.0 * h + i;
  float m = clamp(length(vec2(gx, gy)) * strength, 0.0, 1.0);
  vec4 s = src(uv);
  return vec4(mix(s.rgb, vec3(m) * s.a, amount), s.a);
}""")
        fx("bulge", "Bulge / Pinch", "Distort", "Pushes the picture outward or pinches it inward around a point.",
            listOf(P("amount", "Amount", -1f, 1f, 0.5f), P("radius", "Radius", 0.1f, 1f, 0.5f), P("centerX", "Center X", 0f, 1f, 0.5f), P("centerY", "Center Y", 0f, 1f, 0.5f)), emptyList(), """
vec4 effect(vec2 uv){
  float asp = uRes.x / uRes.y;
  vec2 c = vec2(centerX, centerY);
  vec2 p = (uv - c) * vec2(asp, 1.0);
  float d = length(p) / radius;
  float k = d < 1.0 ? pow(d, 1.0 - amount * 0.8) : d;
  vec2 q = (d > 0.0001 ? p / d * k : p) * radius;
  q.x /= asp;
  return srcW(c + q, 0.0);
}""")
        fx("hueshift", "Hue Shift", "Color", "Rotates all colors around the color wheel and adjusts saturation.",
            listOf(P("shift", "Hue Shift", -180f, 180f, 60f, 0), P("sat", "Saturation", 0f, 2f, 1.2f), P("amount", "Amount", 0f, 1f, 1f)), emptyList(), """
vec3 rgb2hsv(vec3 c){
  vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
  vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
  vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
  float d = q.x - min(q.w, q.y);
  float e = 1.0e-10;
  return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  vec3 h = rgb2hsv(c.rgb);
  h.x = fract(h.x + shift / 360.0);
  h.y = clamp(h.y * sat, 0.0, 1.0);
  return vec4(mix(c.rgb, hsv2rgb(h), amount) * c.a, c.a);
}""")
        fx("twirl", "Twirl", "Distort", "Swirls the picture around a point; strongest at the center.",
            listOf(P("amount", "Amount", -4f, 4f, 1.5f), P("radius", "Radius", 0.1f, 1.2f, 0.6f), P("centerX", "Center X", 0f, 1f, 0.5f), P("centerY", "Center Y", 0f, 1f, 0.5f)), emptyList(), """
vec4 effect(vec2 uv){
  float asp = uRes.x / uRes.y;
  vec2 c = vec2(centerX, centerY);
  vec2 p = (uv - c) * vec2(asp, 1.0);
  float k = max(0.0, 1.0 - length(p) / radius);
  float a = amount * k * k * 3.14159;
  vec2 q = vec2(cos(a) * p.x - sin(a) * p.y, sin(a) * p.x + cos(a) * p.y);
  q.x /= asp;
  return srcW(c + q, 0.0);
}""")
        fx("lightsweep", "CC Light Sweep", "Light", "A band of light sweeps across the layer. Parameters follow After Effects: Center, Direction, Shape, Width, Sweep Intensity, Edge Intensity, Edge Thickness, Light Color and Light Reception. Contour Glow adds a bright rim around the subject that flares as the sweep passes.",
            listOf(P("centerX", "Center X", 0f, 1f, 0.5f), P("centerY", "Center Y", 0f, 1f, 0.5f), P("direction", "Direction", -360f, 360f, 45f, 0),
                P("shape", "Shape", 0f, 2f, 0f, 0, listOf("Linear", "Smooth", "Sharp")), P("width", "Width", 0f, 200f, 30f, 0),
                P("sweepInt", "Sweep Intensity", 0f, 100f, 30f, 0), P("edgeInt", "Edge Intensity", 0f, 200f, 100f, 0), P("edgeThick", "Edge Thickness", 0f, 10f, 1f),
                P("reception", "Light Reception", 0f, 2f, 0f, 0, listOf("Add", "Composite", "Cut Away")),
                P("contour", "Contour Glow", 0f, 200f, 70f, 0), P("contourWidth", "Contour Width", 0f, 10f, 3f), P("contourFollow", "Contour Follows Sweep", 0f, 1f, 0.5f), P("autoSpeed", "Auto Sweep Speed", 0f, 4f, 0f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  float asp = uRes.x / uRes.y;
  vec2 p = (uv - vec2(centerX, centerY)) * vec2(asp, 1.0);
  float a = radians(direction);
  float d = dot(p, vec2(cos(a), sin(a))) - (autoSpeed > 0.0 ? (fract(uTime * autoSpeed * 0.4) * 2.8 - 1.4) : 0.0);
  float hw = max(width, 0.5) * 0.005;
  float x = abs(d) / hw;
  float m = 0.0;
  if (shape < 0.5) m = clamp(1.0 - x, 0.0, 1.0);
  else if (shape < 1.5) m = smoothstep(0.0, 1.0, 1.0 - x);
  else m = 1.0 - smoothstep(0.9, 1.0, x);
  vec3 lc = lightColor.rgb * lightColor.a;
  float g = (x - 1.0) / (0.05 * edgeThick + 0.01);
  float ed = exp(-g * g) * edgeInt * 0.01;
  float rr = contourWidth * 0.004;
  float ba = 0.0;
  for (int i = 0; i < 12; i++) {
    float a2 = float(i) * 0.5236;
    ba += src(uv + vec2(cos(a2), sin(a2) * asp) * rr).a;
  }
  ba /= 12.0;
  float rim = clamp(ba - c.a * 0.9, 0.0, 1.0) + clamp(c.a - ba, 0.0, 1.0) * 0.8;
  float cm = mix(1.0, clamp(m * 1.4 + 0.15, 0.0, 1.0), contourFollow);
  float ct = rim * cm * contour * 0.02;
  float k = m * sweepInt * 0.016 + ed;
  vec3 L = lc * (k * c.a + ct);
  float oa = max(c.a, clamp(ct, 0.0, 1.0));
  if (reception < 0.5) return vec4(c.rgb + L, oa);
  if (reception < 1.5) return vec4(mix(c.rgb, lc * c.a, clamp(k, 0.0, 1.0)) + lc * ct, oa);
  vec4 r = c * clamp(m * 1.5 + ed, 0.0, 1.0);
  r.rgb += L;
  r.a = oa;
  return r;
}""", listOf(CP("lightColor", "Light Color", 0xFFFFFFFF.toInt())))
        fx("tritone", "Tritone", "Color", "Maps shadows, midtones and highlights to three colors you choose, each with its own opacity. Blend With Original mixes the result back into the picture.",
            listOf(P("blend", "Blend With Original", 0f, 1f, 0f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  float L = luma(c.rgb);
  vec3 t = L < 0.5 ? mix(shadows.rgb, midtones.rgb, L * 2.0) : mix(midtones.rgb, highlights.rgb, (L - 0.5) * 2.0);
  float k = (L < 0.5 ? mix(shadows.a, midtones.a, L * 2.0) : mix(midtones.a, highlights.a, (L - 0.5) * 2.0)) * (1.0 - blend);
  return vec4(mix(c.rgb, t, k) * c.a, c.a);
}""", listOf(CP("highlights", "Highlights", 0xFFFFE2B8.toInt()), CP("midtones", "Midtones", 0xFFB5527F.toInt()), CP("shadows", "Shadows", 0xFF1B2C66.toInt())))
        fx("radialblur", "Radial Blur", "Blur", "Zoom blur that streaks the picture away from a center point.",
            listOf(P("amount", "Amount", 0f, 1f, 0.4f), P("centerX", "Center X", 0f, 1f, 0.5f), P("centerY", "Center Y", 0f, 1f, 0.5f)), emptyList(), """
vec4 effect(vec2 uv){
  vec2 d = (uv - vec2(centerX, centerY)) * amount * 0.25;
  vec4 acc = vec4(0.0);
  for (int i = 0; i < 16; i++) acc += srcW(uv - d * (float(i) / 15.0), 0.0);
  return acc / 16.0;
}""")
        fx("glitchslices", "Glitch Slices", "Stylize", "Horizontal slices jump sideways with an RGB split, like a broken signal.",
            listOf(P("slices", "Slices", 4f, 60f, 18f, 0), P("amount", "Amount", 0f, 1f, 0.5f), P("speed", "Speed", 0f, 30f, 10f, 1), P("split", "RGB Split", 0f, 1f, 0.4f), P("seed", "Seed", 0f, 100f, 3f, 0)), emptyList(), """
vec4 effect(vec2 uv){
  float row = floor(uv.y * slices);
  float tt = floor(uTime * speed);
  float r = hash21(vec2(row, tt + seed));
  float on = step(0.72, hash21(vec2(row * 1.7, tt + seed * 3.0)));
  float off = (r - 0.5) * amount * 0.4 * on;
  float sp = split * 0.03 * on;
  vec4 a = srcW(vec2(uv.x + off + sp, uv.y), 0.0);
  vec4 b = srcW(vec2(uv.x + off, uv.y), 0.0);
  vec4 d = srcW(vec2(uv.x + off - sp, uv.y), 0.0);
  return vec4(a.r, b.g, d.b, max(a.a, max(b.a, d.a)));
}""")
        fx("barrel", "Barrel Lens", "Distort", "Bulges the picture like a wide lens, with optional chromatic fringing.",
            listOf(P("amount", "Amount", -1f, 1f, 0.4f), P("zoom", "Zoom", 0.5f, 1.5f, 1f), P("split", "Chromatic Split", 0f, 1f, 0.2f)), emptyList(), """
vec2 barrelUV(vec2 uv, float k){
  float asp = uRes.x / uRes.y;
  vec2 p = (uv * 2.0 - 1.0) * vec2(asp, 1.0);
  p *= (1.0 + k * dot(p, p)) / zoom;
  p.x /= asp;
  return p * 0.5 + 0.5;
}
vec4 effect(vec2 uv){
  vec4 a = srcW(barrelUV(uv, amount * (1.0 + split)), 0.0);
  vec4 b = srcW(barrelUV(uv, amount), 0.0);
  vec4 d = srcW(barrelUV(uv, amount * (1.0 - split)), 0.0);
  return vec4(a.r, b.g, d.b, max(a.a, max(b.a, d.a)));
}""")
        fx("sharpen", "Sharpen", "Stylize", "Unsharp mask that brings out fine detail.",
            listOf(P("amount", "Amount", 0f, 4f, 1.2f), P("radius", "Radius", 0.5f, 3f, 1f)), emptyList(), """
vec4 effect(vec2 uv){
  vec2 e = vec2(radius) / uRes;
  vec4 c = src(uv);
  vec4 bl = (src(uv + vec2(e.x, 0.0)) + src(uv - vec2(e.x, 0.0)) + src(uv + vec2(0.0, e.y)) + src(uv - vec2(0.0, e.y))) * 0.25;
  vec4 o = c + (c - bl) * amount;
  o.a = c.a;
  o.rgb = clamp(o.rgb, 0.0, c.a);
  return o;
}""")
        fx("contour", "Contour Glow", "Light", "A glowing rim around the subject's outline. It works on its own, so the contour stays even without a light sweep.",
            listOf(P("intensity", "Intensity", 0f, 200f, 90f, 0), P("width", "Width", 0f, 10f, 3f), P("softness", "Softness", 0f, 1f, 0.5f),
                P("innerEdge", "Inner Edge", 0f, 1f, 0.5f), P("outside", "Outside Glow", 0f, 1f, 1f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  float asp = uRes.x / uRes.y;
  float rr = width * 0.004;
  float ba = 0.0;
  float ba2 = 0.0;
  for (int i = 0; i < 12; i++) {
    float a = float(i) * 0.5236;
    vec2 o = vec2(cos(a), sin(a) * asp);
    ba += src(uv + o * rr).a;
    ba2 += src(uv + o * rr * 2.2).a;
  }
  ba /= 12.0;
  ba2 /= 12.0;
  float outer = clamp(ba - c.a * 0.9, 0.0, 1.0) * outside + clamp(ba2 - c.a, 0.0, 1.0) * 0.5 * softness * outside;
  float inner = clamp(c.a - ba, 0.0, 1.0) * innerEdge;
  float k = (outer + inner) * intensity * 0.02;
  vec3 L = glow.rgb * glow.a * k;
  return vec4(c.rgb + L, clamp(max(c.a, k * glow.a), 0.0, 1.0));
}""", listOf(CP("glow", "Glow Color", 0xFFFFFFFF.toInt())))
        fx("chromakey", "Chroma Key", "Keying", "Removes a background color such as a green screen. Pick the key color with the pen in the color tool, then tune Similarity and Smoothness. Spill pulls the key color out of the edges.",
            listOf(P("similarity", "Similarity", 0f, 1f, 0.2f), P("smoothness", "Smoothness", 0f, 1f, 0.1f), P("spill", "Spill Suppression", 0f, 1f, 0.5f),
                P("invert", "Invert", 0f, 1f, 0f, 0, listOf("Off", "On")), P("matte", "Show Matte", 0f, 1f, 0f, 0, listOf("Off", "On"))), emptyList(), """
vec2 cbcr(vec3 c){ return vec2(-0.169 * c.r - 0.331 * c.g + 0.5 * c.b, 0.5 * c.r - 0.419 * c.g - 0.081 * c.b); }
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  float d = distance(cbcr(c.rgb), cbcr(keyColor.rgb));
  float m = smoothstep(similarity, similarity + smoothness + 0.001, d);
  if (invert > 0.5) m = 1.0 - m;
  float near = 1.0 - smoothstep(similarity, similarity * 2.0 + 0.05, d);
  vec3 rgb = mix(c.rgb, vec3(luma(c.rgb)), spill * near);
  float a = c.a * m;
  if (matte > 0.5) return vec4(vec3(a), 1.0);
  return vec4(rgb * a, a);
}""", listOf(CP("keyColor", "Key Color", 0xFF00B140.toInt())))
        fx("ripple", "Ripple", "Distort", "Water ripples that spread out from a point and fade with distance.",
            listOf(P("amount", "Amount", 0f, 2f, 0.8f), P("freq", "Frequency", 1f, 80f, 28f, 0), P("speed", "Speed", 0f, 20f, 6f, 1),
                P("decay", "Decay", 0f, 8f, 1.5f), P("centerX", "Center X", 0f, 1f, 0.5f), P("centerY", "Center Y", 0f, 1f, 0.5f)), emptyList(), """
vec4 effect(vec2 uv){
  float asp = uRes.x / uRes.y;
  vec2 p = (uv - vec2(centerX, centerY)) * vec2(asp, 1.0);
  float d = length(p);
  float w = sin(d * freq - uTime * speed) * amount * 0.03 * exp(-d * decay);
  vec2 dir = d > 0.0001 ? p / d : vec2(0.0);
  return srcW(uv + vec2(dir.x / asp, dir.y) * w, 0.0);
}""")
        fx("lightleak", "Light Leak", "Light", "Warm film light leaks that drift in from the edges of the frame.",
            listOf(P("intensity", "Intensity", 0f, 3f, 1f), P("scale", "Scale", 0.3f, 6f, 1.6f), P("speed", "Speed", 0f, 4f, 0.6f), P("edge", "Edge Bias", 0f, 2f, 1f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  float asp = uRes.x / uRes.y;
  vec2 p = (uv - 0.5) * vec2(asp, 1.0);
  float t = uTime * speed;
  float v = fbm(p * scale + vec2(t * 0.3, -t * 0.2));
  float e = smoothstep(0.3, 1.0, length(p) * 1.2 * edge + (v - 0.5) * 0.9);
  vec3 lc = leak.rgb * (0.7 + 0.6 * v) + vec3(0.15, 0.04, 0.0) * v;
  float flick = 0.7 + 0.3 * sin(t * 2.0 + v * 6.0);
  return vec4(c.rgb + lc * e * intensity * flick * leak.a * max(c.a, 0.0), c.a);
}""", listOf(CP("leak", "Leak Color", 0xFFFF7A1A.toInt())))
        loadAllCustom(ctx)
    }

    // ------------------------------------------------------------------ GLSL assembly

    private const val HEAD = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vUV;
uniform sampler2D uSrc;
uniform sampler2D uIn0;
uniform sampler2D uIn1;
uniform float uHas0;
uniform float uHas1;
uniform float uTime;
uniform vec2 uRes;
"""

    private const val HELPERS = """
float hash11(float p){ p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash21(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float vnoise(vec2 p){ vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x), mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y); }
float fbm(vec2 p){ float a = 0.5; float s = 0.0; for (int i = 0; i < 5; i++) { s += a * vnoise(p); p *= 2.0; a *= 0.5; } return s; }
float luma(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }
vec3 hsv2rgb(vec3 c){ vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0); vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www); return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y); }
vec2 rot(vec2 p, float a){ float c = cos(a); float s = sin(a); return vec2(c * p.x - s * p.y, s * p.x + c * p.y); }
vec4 src(vec2 uv){ return texture2D(uSrc, uv); }
vec4 in0(vec2 uv){ return texture2D(uIn0, uv); }
vec4 in1(vec2 uv){ return texture2D(uIn1, uv); }
vec4 unpremul(vec4 c){ return c.a > 0.0001 ? vec4(c.rgb / c.a, c.a) : vec4(0.0); }
vec4 srcW(vec2 uv, float m){
  if (m < 0.5) { if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return vec4(0.0); return texture2D(uSrc, uv); }
  if (m < 1.5) return texture2D(uSrc, fract(uv));
  return texture2D(uSrc, 1.0 - abs(1.0 - mod(uv, 2.0)));
}
"""

    fun fragmentFor(d: EffectDef): String {
        val sb = StringBuilder(HEAD)
        for (p in d.props) sb.append("uniform float ").append(p.name).append(";\n")
        for (c in d.colors) sb.append("uniform vec4 ").append(c.name).append(";\n")
        sb.append(HELPERS).append(d.code).append("\nvoid main(){ gl_FragColor = effect(vUV); }\n")
        return sb.toString()
    }

    // ------------------------------------------------------------------ custom effects + SDK

    val CATEGORIES = listOf("Light and glow", "Color", "Stylize", "Distort", "Blur", "Generate", "Glitch and motion", "Keying", "Transform and time", "Custom")
    private val PREVIEW_KEYS = setOf("portrait", "mountain", "woman", "greenscreen", "ramen", "apple")
    val sdkErrors = ConcurrentHashMap<String, String>()
    @Volatile private var sdkLoaded = false

    private fun dir(ctx: Context, name: String) = File(ctx.filesDir, name).also { it.mkdirs() }

    fun sdkRoot(ctx: Context): File = dir(ctx, "sdk")

    fun safeName(s: String): String = s.lowercase().replace(Regex("[^a-z0-9_]+"), "_").trim('_').ifEmpty { "effect" }

    /** Line in the final GLSL where the user's code starts, so compiler messages can be shown against the file. */
    fun codeLineOffset(d: EffectDef): Int {
        val full = fragmentFor(d)
        val at = full.indexOf(d.code)
        return if (at < 0) 0 else full.substring(0, at).count { it == '\n' }
    }

    fun parseEffect(o: JSONObject, source: String = "", resolve: (String) -> String? = { null }): EffectDef {
        val name = o.getString("name").trim()
        require(name.isNotEmpty()) { "Effect needs a name" }
        val desc = o.optString("description", "").trim()
        require(desc.isNotEmpty()) { "Effect needs a description" }
        val code = o.getString("code")
        require(code.contains("effect(")) { "Code must define: vec4 effect(vec2 uv)" }
        val id = o.optString("id", "").ifBlank { "custom_" + name.lowercase().replace(Regex("[^a-z0-9]"), "") }
        require(id.matches(Regex("[A-Za-z][A-Za-z0-9_]*"))) { "Bad effect id: $id (letters, digits and _ only)" }
        val ps = ArrayList<PropDef>()
        val pa = o.optJSONArray("params") ?: JSONArray()
        for (i in 0 until pa.length()) {
            val j = pa.getJSONObject(i)
            val n = j.getString("name")
            require(n.matches(Regex("[A-Za-z][A-Za-z0-9_]*"))) { "Bad parameter name: $n" }
            var opts: List<String>? = null
            val oa = j.optJSONArray("options")
            if (oa != null && oa.length() > 0) opts = (0 until oa.length()).map { oa.getString(it) }
            val inf = j.optBoolean("infinite", false)
            val lo = if (inf) -1e9f else j.optDouble("min", 0.0).toFloat()
            val hi = if (inf) 1e9f else (if (opts != null) (opts.size - 1).toFloat() else j.optDouble("max", 1.0).toFloat())
            ps.add(PropDef(id + "__" + n, j.optString("label", n), lo, hi, j.optDouble("def", 0.0).toFloat(),
                if (opts != null) 0 else j.optInt("dec", 2), n, opts, inf, j.optDouble("span", 1.0).toFloat()))
        }
        val ins = ArrayList<String>()
        val ia = o.optJSONArray("inputs")
        if (ia != null) for (i in 0 until minOf(2, ia.length())) ins.add(ia.getString(i))
        val cols = ArrayList<ColorParam>()
        val ca = o.optJSONArray("colors")
        if (ca != null) for (i in 0 until ca.length()) {
            val j = ca.getJSONObject(i)
            val n = j.getString("name")
            require(n.matches(Regex("[A-Za-z][A-Za-z0-9_]*"))) { "Bad color name: $n" }
            val hex = j.optString("def", "#FFFFFFFF").removePrefix("#")
            val col = (if (hex.length == 6) 0xFF000000L or hex.toLong(16) else hex.toLong(16)).toInt()
            cols.add(ColorParam(n, j.optString("label", n), id + "__" + n, col))
        }
        val pv = o.optJSONObject("preview")
        var pimg: String? = pv?.optString("image", "")?.ifBlank { null }
        var ppath: String? = null
        if (pimg != null) {
            if (pimg.contains('.')) { ppath = resolve(pimg); pimg = if (ppath != null) "custom:$id" else null }
            else if (pimg !in PREVIEW_KEYS) pimg = null
        }
        val ptime = (pv?.optDouble("time", 0.7) ?: 0.7).toFloat().coerceIn(0f, 8f)
        val panim = pv?.optString("animation", "swipe") ?: "swipe"
        return EffectDef(id, name, desc, o.optString("category", "Custom"), ps, ins, code, 0, false, cols, source, pimg, ppath, ptime,
            if (panim in setOf("swipe", "fade", "cut", "wipe")) panim else "swipe")
    }

    /** The effect.json manifest: everything except the code, which lives in effect.glsl. */
    fun manifestJson(d: EffectDef): JSONObject {
        val pa = JSONArray()
        for (p in d.props) {
            val po = JSONObject().put("name", p.name).put("label", p.label)
            if (p.options != null) po.put("options", JSONArray(p.options)).put("def", p.def.toDouble())
            else if (p.inf) po.put("infinite", true).put("span", p.span.toDouble()).put("def", p.def.toDouble()).put("dec", p.dec)
            else po.put("min", p.min.toDouble()).put("max", p.max.toDouble()).put("def", p.def.toDouble()).put("dec", p.dec)
            pa.put(po)
        }
        val ca = JSONArray()
        for (c in d.colors) ca.put(JSONObject().put("name", c.name).put("label", c.label).put("def", String.format("#%08X", c.def)))
        val o = JSONObject().put("id", d.id).put("name", d.name).put("description", d.desc).put("category", d.category)
            .put("params", pa).put("colors", ca).put("inputs", JSONArray(d.inputs)).put("shader", "effect.glsl")
        val img = if (d.previewImage != null && d.previewImage.startsWith("custom:")) (d.previewPath?.let { File(it).name } ?: "preview.jpg") else (d.previewImage ?: "portrait")
        o.put("preview", JSONObject().put("image", img).put("time", d.previewTime.toDouble()).put("animation", d.previewAnim))
        return o
    }

    fun toJson(d: EffectDef): JSONObject = manifestJson(d).put("code", d.code).also { it.remove("shader") }

    fun writeSdk(ctx: Context, d: EffectDef): File {
        val f = File(sdkRoot(ctx), safeName(d.id)).also { it.mkdirs() }
        File(f, "effect.json").writeText(manifestJson(d).toString(2))
        File(f, "effect.glsl").writeText(d.code)
        return f
    }

    fun loadUserFolder(folder: File): EffectDef {
        val m = File(folder, "effect.json").readText()
        val o = JSONObject(m)
        val sf = File(folder, o.optString("shader", "effect.glsl"))
        if (sf.exists()) o.put("code", sf.readText()) else if (!o.has("code")) throw IllegalArgumentException("Missing shader file " + sf.name)
        return parseEffect(o, folder.absolutePath) { n -> File(folder, n).takeIf { it.exists() }?.absolutePath }
    }

    private fun loadAssetFolder(ctx: Context, path: String): EffectDef {
        val am = ctx.assets
        val o = JSONObject(am.open("$path/effect.json").bufferedReader().use { it.readText() })
        val shader = o.optString("shader", "effect.glsl")
        try { o.put("code", am.open("$path/$shader").bufferedReader().use { it.readText() }) } catch (e: Exception) { if (!o.has("code")) throw IllegalArgumentException("Missing shader file $shader") }
        return parseEffect(o, "asset:$path") { n ->
            try {
                val out = File(ctx.cacheDir, "sdk_" + path.replace('/', '_') + "_" + n)
                if (!out.exists()) am.open("$path/$n").use { i -> out.outputStream().use { x -> i.copyTo(x) } }
                out.absolutePath
            } catch (e: Exception) { null }
        }
    }

    private fun walkUser(root: File, out: MutableList<File>) {
        val fs = root.listFiles() ?: return
        for (f in fs.sortedBy { it.name }) if (f.isDirectory && !f.name.startsWith("_")) {
            if (File(f, "effect.json").exists()) out.add(f) else walkUser(f, out)
        }
    }

    private fun walkAssets(ctx: Context, path: String, out: MutableList<String>) {
        val names = try { ctx.assets.list(path) } catch (e: Exception) { null } ?: return
        if (names.contains("effect.json")) { out.add(path); return }
        for (n in names.sorted()) if (!n.startsWith("_") && !n.contains('.')) walkAssets(ctx, "$path/$n", out)
    }

    /** Effects from the user's SDK folder first, then the ones bundled in the APK (a user effect with the same id wins). */
    fun loadSdk(ctx: Context) {
        sdkErrors.clear()
        val users = ArrayList<File>()
        walkUser(sdkRoot(ctx), users)
        for (f in users) try {
            val d = loadUserFolder(f)
            if (byId[d.id]?.builtin == true) throw IllegalArgumentException("The id '" + d.id + "' belongs to a built-in effect")
            add(d)
        } catch (e: Exception) { sdkErrors[f.name] = e.message ?: "Invalid effect" }
        val bundled = ArrayList<String>()
        walkAssets(ctx, "sdk", bundled)
        for (p in bundled) try {
            val d = loadAssetFolder(ctx, p)
            if (!byId.containsKey(d.id)) add(d)
        } catch (e: Exception) { sdkErrors[p] = e.message ?: "Invalid effect" }
        sdkLoaded = true
    }

    private fun migrateLegacy(ctx: Context) {
        val fs = dir(ctx, "effects").listFiles() ?: return
        for (f in fs) {
            if (!f.name.endsWith(".json")) continue
            try {
                val d = parseEffect(JSONObject(f.readText()))
                if (!File(sdkRoot(ctx), safeName(d.id)).exists()) writeSdk(ctx, d)
                f.renameTo(File(f.parentFile, f.name + ".migrated"))
            } catch (e: Exception) { }
        }
    }

    private fun loadAllCustom(ctx: Context) { migrateLegacy(ctx); loadSdk(ctx) }

    /** Drops every non-built-in effect and reads the SDK folders again. Call after editing files. */
    fun reloadSdk(ctx: Context) {
        for (d in order.toList()) if (!d.builtin) { byId.remove(d.id); order.remove(d); errors.remove(d.id) }
        loadAllCustom(ctx)
    }

    /** Returns an error message or null on success. */
    fun addCustom(ctx: Context, json: String): String? {
        return try {
            val d = parseEffect(JSONObject(json))
            val f = writeSdk(ctx, d)
            add(loadUserFolder(f))
            null
        } catch (e: Exception) { e.message ?: "Invalid effect file" }
    }

    fun deleteCustom(ctx: Context, id: String) {
        val d = byId[id] ?: return
        if (d.builtin || d.bundled) return
        byId.remove(id); order.remove(d)
        if (d.source.isNotEmpty()) File(d.source).deleteRecursively()
    }

    private const val TEMPLATE_GLSL = """// vec4 effect(vec2 uv) runs once for every pixel. uv goes 0..1 across the layer.
// Every param in effect.json is a float with the same name. Every color is a vec4.
// src(uv) is the layer's pixel (premultiplied alpha). uTime is seconds, uRes is the size in pixels.
vec4 effect(vec2 uv) {
  vec4 c = src(uv);
  vec3 gray = vec3(luma(c.rgb)) * c.a;
  return vec4(mix(c.rgb, gray, amount), c.a);
}
"""

    /** Creates a new effect folder with a working starting point and returns it. */
    fun newEffectFolder(ctx: Context, title: String, parent: File = sdkRoot(ctx)): File {
        val base = safeName(title)
        var id = "my_$base"
        var n = 2
        while (byId.containsKey(id) || File(parent, id).exists()) id = "my_" + base + "_" + n++
        val f = File(parent, id).also { it.mkdirs() }
        val m = JSONObject().put("id", id).put("name", title.ifBlank { "My Effect" }).put("description", "Describe what this effect does.")
            .put("category", "Custom")
            .put("params", JSONArray().put(JSONObject().put("name", "amount").put("label", "Amount").put("min", 0).put("max", 1).put("def", 1).put("dec", 2)))
            .put("colors", JSONArray()).put("inputs", JSONArray()).put("shader", "effect.glsl")
            .put("preview", JSONObject().put("image", "portrait").put("time", 0.7).put("animation", "swipe"))
        File(f, "effect.json").writeText(m.toString(2))
        File(f, "effect.glsl").writeText(TEMPLATE_GLSL)
        return f
    }

    // ------------------------------------------------------------------ presets

    class Preset(val name: String, val json: JSONObject, val builtin: Boolean)

    private val builtinPresets = listOf(
        """{"name":"Neon Glow","effects":[{"id":"deepglow","params":{"radius":0.7,"exposure":2.2,"threshold":0.25,"tintAmt":0.7,"hue":0.85}}]}""",
        """{"name":"Glitch Cut","effects":[{"id":"twitch","params":{"intensity":1.4,"frequency":9,"glitch":0.8}},{"id":"rgbsplit","params":{"amount":0.5}}]}""",
        """{"name":"Retro Print","effects":[{"id":"halftone","params":{"cell":10,"colorMode":1}},{"id":"texturemoire","params":{"amount":0.25}}]}""",
        """{"name":"Dream Warp","effects":[{"id":"psykoblobs","params":{"amount":0.5,"distort":0.7}},{"id":"deepglow","params":{"radius":0.5,"exposure":1.2}}]}""",
        """{"name":"Handheld Cam","effects":[{"id":"sshake","params":{"amount":0.35,"frequency":6,"blur":0.7}}]}""",
        """{"name":"Zebra Skin","effects":[{"id":"zebrafy","params":{"stripes":40,"angle":20}}]}"""
    )

    fun presets(ctx: Context): List<Preset> {
        val out = ArrayList<Preset>()
        for (s in builtinPresets) { val o = JSONObject(s); out.add(Preset(o.getString("name"), o, true)) }
        val fs = dir(ctx, "presets").listFiles()
        if (fs != null) for (f in fs.sortedBy { it.name }) try { val o = JSONObject(f.readText()); out.add(Preset(o.getString("name"), o, false)) } catch (e: Exception) { }
        return out
    }

    fun capturePreset(l: Layer, name: String, t: Float): JSONObject {
        val ea = JSONArray()
        for (id in l.fx) {
            val d = get(id) ?: continue
            val po = JSONObject()
            for (p in d.props) { val k = l.pkey(id, p); po.put(p.name, l.p(k, l.editTime(k, t)).toDouble()) }
            ea.put(JSONObject().put("id", d.id).put("params", po))
        }
        return JSONObject().put("name", name).put("effects", ea)
    }

    fun savePreset(ctx: Context, o: JSONObject) {
        val safe = o.getString("name").replace(Regex("[^A-Za-z0-9_ -]"), "_")
        File(dir(ctx, "presets"), "$safe.json").writeText(o.toString())
    }

    fun deletePreset(ctx: Context, name: String) {
        val safe = name.replace(Regex("[^A-Za-z0-9_ -]"), "_")
        File(dir(ctx, "presets"), "$safe.json").delete()
    }

    fun applyPreset(l: Layer, o: JSONObject) {
        val ea = o.optJSONArray("effects") ?: return
        for (i in 0 until ea.length()) {
            val e = ea.getJSONObject(i)
            val id = e.getString("id")
            val d = byId[id] ?: continue
            if (!l.fx.contains(id)) l.fx.add(id)
            l.fxOff.remove(id)
            val po = e.optJSONObject("params") ?: continue
            for (p in d.props) if (po.has(p.name)) { val tr = l.track(p.key); tr.keys.clear(); tr.base = po.getDouble(p.name).toFloat() }
        }
    }
}
