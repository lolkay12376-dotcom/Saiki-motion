package com.saiki.motion

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class EffectDef(
    val id: String,
    val name: String,
    val desc: String,
    val category: String,
    val props: List<PropDef>,
    val inputs: List<String>,
    val code: String,
    val kind: Int,            // 0 = pixel shader pass, 1 = built-in transform-level effect
    val builtin: Boolean
)

object Defs {
    val transform = listOf(
        PropDef("x", "Position X", -2.5f, 2.5f, 0f),
        PropDef("y", "Position Y", -2.5f, 2.5f, 0f),
        PropDef("scale", "Scale", 0.05f, 4f, 1f),
        PropDef("opacity", "Opacity", 0f, 1f, 1f),
        PropDef("rotZ", "Rotation Z", -360f, 360f, 0f, 1)
    )
    val pos3d = listOf(PropDef("z", "Position Z", -5f, 5f, 0f))
    val rot3d = listOf(
        PropDef("rotX", "Rotation X", -360f, 360f, 0f, 1),
        PropDef("rotY", "Rotation Y", -360f, 360f, 0f, 1)
    )
    val camera = listOf(PropDef("camFov", "Field of View", 15f, 120f, 45f, 0))
    val particles = listOf(
        PropDef("pBirthRate", "Birth Rate", 0f, 20f, 3f, 1),
        PropDef("pLongevity", "Longevity (sec)", 0.1f, 10f, 2f, 1),
        PropDef("pProdX", "Producer X", -1.5f, 1.5f, 0f),
        PropDef("pProdY", "Producer Y", -1.5f, 1.5f, 0f),
        PropDef("pProdZ", "Producer Z", -1.5f, 1.5f, 0f),
        PropDef("pRadX", "Radius X", 0f, 1.5f, 0.1f),
        PropDef("pRadY", "Radius Y", 0f, 1.5f, 0.1f),
        PropDef("pRadZ", "Radius Z", 0f, 1.5f, 0.1f),
        PropDef("pAnim", "Animation", 0f, 4f, 0f, 0, "pAnim", listOf("Explosive", "Direction Axis", "Cone Axis", "Viscous", "Twirl")),
        PropDef("pVelocity", "Velocity", 0f, 5f, 1f),
        PropDef("pDirection", "Direction Angle", -180f, 180f, 90f, 0),
        PropDef("pSpread", "Cone Angle", 0f, 180f, 45f, 0),
        PropDef("pGravity", "Gravity", -3f, 3f, 0.4f),
        PropDef("pResist", "Resistance", 0f, 5f, 0.2f),
        PropDef("pExtra", "Extra", 0f, 3f, 0.5f),
        PropDef("pType", "Particle Type", 0f, 3f, 0f, 0, "pType", listOf("Faded Sphere", "Star", "Line", "Disc")),
        PropDef("pBirthSize", "Birth Size", 0f, 4f, 0.5f),
        PropDef("pDeathSize", "Death Size", 0f, 4f, 0.15f),
        PropDef("pSizeVar", "Size Variation", 0f, 1f, 0.3f),
        PropDef("pOpacity", "Max Opacity", 0f, 1f, 1f),
        PropDef("pFade", "Opacity Map", 0f, 2f, 0f, 0, "pFade", listOf("Fade Out", "Fade In-Out", "Constant")),
        PropDef("pAdd", "Transfer Mode", 0f, 1f, 0f, 0, "pAdd", listOf("Add", "Normal")),
        PropDef("pSeed", "Random Seed", 0f, 100f, 1f, 0)
    )
    val all: List<PropDef> get() = transform + pos3d + rot3d + camera + particles
}

object Registry {
    val order = CopyOnWriteArrayList<EffectDef>()
    val byId = ConcurrentHashMap<String, EffectDef>()
    private val props = ConcurrentHashMap<String, PropDef>()
    val errors = ConcurrentHashMap<String, String>()

    fun get(id: String): EffectDef? = byId[id]
    fun propDef(key: String): PropDef? = props[key] ?: Defs.all.firstOrNull { it.key == key }
    fun allProps(): List<PropDef> = Defs.all + order.flatMap { it.props }

    private fun add(d: EffectDef) {
        if (byId.containsKey(d.id)) order.remove(byId[d.id])
        byId[d.id] = d
        order.add(d)
        for (p in d.props) props[p.key] = p
    }

    class P(val n: String, val label: String, val min: Float, val max: Float, val def: Float, val dec: Int = 2, val opts: List<String>? = null)

    private fun fx(id: String, name: String, cat: String, desc: String, ps: List<P>, inputs: List<String>, code: String) {
        val defs = ps.map { PropDef(id + "__" + it.n, it.label, it.min, it.max, it.def, it.dec, it.n, it.opts) }
        add(EffectDef(id, name, desc, cat, defs, inputs, code, 0, true))
    }

    private fun tfx(id: String, name: String, desc: String, ps: List<PropDef>) {
        add(EffectDef(id, name, desc, "Transform", ps, emptyList(), "", 1, true))
    }

    fun init(ctx: Context) {
        if (order.isNotEmpty()) { loadCustom(ctx); return }
        tfx("tile", "Motion Tile", "Repeats the layer in a grid with scrolling, gaps and mirrored tiles.", listOf(
            PropDef("tileX", "Phase X", -4f, 4f, 0f), PropDef("tileY", "Phase Y", -4f, 4f, 0f),
            PropDef("tileGap", "Gap", -0.5f, 2f, 0f), PropDef("tileNX", "Tiles X", 0f, 6f, 2f, 0),
            PropDef("tileNY", "Tiles Y", 0f, 6f, 2f, 0), PropDef("tileMirror", "Mirror", 0f, 1f, 0f, 0, "tileMirror", listOf("Off", "On"))))
        tfx("remap", "Time Remap", "Changes the speed of the layer's animation: slow motion, reverse, loop and ping-pong.", listOf(
            PropDef("remapSpeed", "Speed", -4f, 4f, 1f), PropDef("remapLoop", "Loop Length", 0f, 10f, 0f),
            PropDef("remapPing", "Ping-Pong", 0f, 1f, 0f, 0, "remapPing", listOf("Off", "On"))))
        tfx("swing", "Swing", "Swings the layer back and forth around a pivot point like a pendulum.", listOf(
            PropDef("swingSpeed", "Speed", 0f, 30f, 7f, 0), PropDef("swingAngle", "Swing Angle", 0f, 90f, 17f, 0),
            PropDef("swingPX", "Pivot X", -100f, 100f, 0f, 0), PropDef("swingPY", "Pivot Y", -100f, 100f, 100f, 0)))
        tfx("shake", "Layer Shake", "Quick positional shake applied to the whole layer.", listOf(PropDef("shake", "Amount", 0f, 1f, 0.4f)))

        fx("distortrgb", "DistortRGB", "Sapphire-style", "Warps the red, green and blue channels by different amounts using the gradient of a Lens layer. Without a lens it uses a built-in bold pattern.",
            listOf(P("amount", "Amount", -3f, 3f, 1f), P("blurLens", "Blur Lens", 0f, 5f, 0.4f), P("rotate", "Rotate Warp Dir", -180f, 180f, 0f, 0),
                P("warpR", "Warp Red", -2f, 2f, 0.5f), P("warpG", "Warp Green", -2f, 2f, 0.75f), P("warpB", "Warp Blue", -2f, 2f, 1f),
                P("relX", "Amount Rel X", 0f, 2f, 1f), P("relY", "Amount Rel Y", 0f, 2f, 1f), P("wrap", "Wrap", 0f, 2f, 2f, 0, listOf("No", "Tile", "Reflect"))),
            listOf("Lens", "Matte"), """
float lensV(vec2 uv){
  if (uHas0 > 0.5) return luma(in0(uv).rgb);
  vec2 p = (uv - 0.5) * vec2(uRes.x / uRes.y, 1.0);
  return 0.5 + 0.25 * sin(p.x * 7.0) * cos(p.y * 7.0) + 0.25 * sin(length(p) * 9.0);
}
vec4 effect(vec2 uv){
  float e = (1.0 + blurLens * 2.0) / uRes.y;
  vec2 g = vec2(lensV(uv + vec2(e, 0.0)) - lensV(uv - vec2(e, 0.0)),
                lensV(uv + vec2(0.0, e)) - lensV(uv - vec2(0.0, e))) / (2.0 * e);
  g = rot(g, radians(rotate)) * vec2(relX, relY);
  float k = amount * 0.02;
  if (uHas1 > 0.5) k *= luma(in1(uv).rgb);
  vec4 r = srcW(uv + g * k * warpR, wrap);
  vec4 gg = srcW(uv + g * k * warpG, wrap);
  vec4 b = srcW(uv + g * k * warpB, wrap);
  return vec4(r.r, gg.g, b.b, max(r.a, max(gg.a, b.a)));
}""")

        fx("etching", "Etching", "Sapphire-style", "Turns the image into engraved ink lines whose thickness follows the brightness, with optional cross-hatching.",
            listOf(P("spacing", "Line Spacing", 2f, 40f, 9f, 0), P("angle", "Angle", -180f, 180f, 45f, 0), P("contrast", "Contrast", 0f, 3f, 1.3f),
                P("thickness", "Thickness", 0f, 1f, 0.55f), P("crossHatch", "Cross Hatch", 0f, 1f, 0.35f), P("colorMix", "Keep Color", 0f, 1f, 0f), P("amount", "Amount", 0f, 1f, 1f)),
            emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  float L = clamp((luma(c.rgb) - 0.5) * contrast + 0.5, 0.0, 1.0);
  float D = 1.0 - L;
  vec2 p = uv * uRes;
  float a = radians(angle);
  float d1 = abs(fract(dot(p, vec2(cos(a), sin(a))) / spacing) - 0.5) * 2.0;
  float w1 = D * thickness * 1.3;
  float ink = 1.0 - smoothstep(w1 - 0.1, w1 + 0.1, d1);
  float d2 = abs(fract(dot(p, vec2(-sin(a), cos(a))) / spacing) - 0.5) * 2.0;
  float w2 = max(D - 0.5, 0.0) * crossHatch * 2.2;
  ink = max(ink, 1.0 - smoothstep(w2 - 0.1, w2 + 0.1, d2));
  vec3 paper = vec3(0.96, 0.94, 0.88);
  vec3 inkc = mix(vec3(0.07, 0.06, 0.09), c.rgb * 0.55, colorMix);
  vec3 res = mix(paper, inkc, ink);
  vec3 o = mix(c.rgb, res, amount);
  return vec4(o * c.a, c.a);
}""")

        fx("halftone", "HalfTone", "Sapphire-style", "Rebuilds the image from a rotated grid of dots; dot size follows brightness. Black, colored or on-black modes.",
            listOf(P("cell", "Dot Spacing", 3f, 80f, 14f, 0), P("angle", "Angle", 0f, 90f, 45f, 0), P("softness", "Softness", 0f, 1f, 0.25f),
                P("dotScale", "Dot Scale", 0.3f, 1.6f, 1f), P("colorMode", "Mode", 0f, 2f, 1f, 0, listOf("Black on white", "Color on white", "Color on black"))),
            emptyList(), """
vec4 effect(vec2 uv){
  vec4 c0 = unpremul(src(uv));
  vec2 p = uv * uRes;
  float a = radians(angle);
  vec2 q = rot(p, a);
  vec2 cc = (floor(q / cell) + 0.5) * cell;
  vec4 cs = unpremul(src(rot(cc, -a) / uRes));
  float L = luma(cs.rgb);
  float D = colorMode > 1.5 ? L : 1.0 - L;
  float rad = sqrt(D) * cell * 0.72 * dotScale;
  float m = 1.0 - smoothstep(rad - softness * cell * 0.4 - 0.5, rad + 0.5, length(q - cc));
  vec3 col;
  if (colorMode < 0.5) col = mix(vec3(1.0), vec3(0.05), m);
  else if (colorMode < 1.5) col = mix(vec3(1.0), cs.rgb, m);
  else col = mix(vec3(0.0), cs.rgb, m);
  return vec4(col * c0.a, c0.a);
}""")

        fx("psykoblobs", "PsykoBlobs", "Sapphire-style", "Floods the image with flowing, psychedelic rainbow blobs that also warp the picture underneath.",
            listOf(P("scale", "Blob Scale", 1f, 20f, 6f), P("speed", "Speed", 0f, 3f, 0.6f), P("bands", "Color Bands", 1f, 12f, 5f, 1),
                P("colorShift", "Color Shift", 0f, 1f, 0f), P("distort", "Distort", 0f, 1f, 0.35f), P("sat", "Saturation", 0f, 1f, 0.9f), P("amount", "Amount", 0f, 1f, 0.85f)),
            emptyList(), """
float field(vec2 p, float t){
  float v = 0.0;
  for (int i = 0; i < 4; i++) {
    float fi = float(i);
    vec2 c = vec2(sin(t * (0.7 + fi * 0.31) + fi * 2.1), cos(t * (0.5 + fi * 0.27) + fi * 1.7)) * 0.6;
    v += 0.35 / (0.15 + dot(p - c, p - c));
  }
  return v;
}
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  vec2 p = (uv - 0.5) * vec2(uRes.x / uRes.y, 1.0) * scale * 0.35;
  float t = uTime * speed;
  vec2 w = vec2(fbm(p * 1.3 + t * 0.4), fbm(p * 1.3 - t * 0.4 + 5.2));
  float f = field(p + (w - 0.5) * 1.2, t);
  float h = fract(f * bands * 0.15 + colorShift + uTime * 0.03 * speed);
  vec3 col = hsv2rgb(vec3(h, sat, 0.55 + 0.45 * sin(f * bands * 0.5)));
  vec4 d = unpremul(src(uv + (w - 0.5) * distort * 0.12));
  vec3 base = mix(c.rgb, d.rgb, distort);
  float a = mix(c.a, d.a, distort);
  vec3 o = mix(base, mix(base, col, 0.75), amount);
  return vec4(o * a, a);
}""")

        fx("sshake", "Shake", "Sapphire-style", "Random camera shake of the image with rotation, zoom and shutter motion blur.",
            listOf(P("amount", "Amount", 0f, 1f, 0.3f), P("frequency", "Frequency", 0f, 30f, 8f, 1), P("rotation", "Rotation", 0f, 30f, 2f, 1),
                P("zoom", "Zoom", 0f, 0.5f, 0.1f), P("blur", "Motion Blur", 0f, 1f, 0.5f), P("seed", "Seed", 0f, 100f, 1f, 0)),
            emptyList(), """
vec3 shk(float t){
  float f = t * frequency;
  float i = floor(f);
  float u = fract(f);
  u = u * u * (3.0 - 2.0 * u);
  vec3 a = vec3(hash11(i + seed * 1.7), hash11(i + seed * 3.1 + 11.0), hash11(i + seed * 5.3 + 23.0)) - 0.5;
  vec3 b = vec3(hash11(i + 1.0 + seed * 1.7), hash11(i + 1.0 + seed * 3.1 + 11.0), hash11(i + 1.0 + seed * 5.3 + 23.0)) - 0.5;
  return mix(a, b, u) * 2.0;
}
vec4 effect(vec2 uv){
  vec4 acc = vec4(0.0);
  float asp = uRes.x / uRes.y;
  for (int k = 0; k < 8; k++) {
    float tt = uTime - float(k) / 7.0 * 0.03 * blur;
    vec3 s = shk(tt);
    float zm = 1.0 + zoom * (0.5 + 0.5 * abs(s.x));
    vec2 p = uv - 0.5;
    p.x *= asp;
    p = rot(p, radians(s.z * rotation)) / zm;
    p.x /= asp;
    acc += srcW(p + 0.5 + s.xy * amount * 0.08, 2.0);
  }
  return acc / 8.0;
}""")

        fx("texturefolded", "TextureFolded", "Sapphire-style", "Procedural folded-paper relief lit from an angle and blended over the image.",
            listOf(P("scale", "Scale", 1f, 20f, 4f), P("folds", "Folds", 1f, 8f, 4f, 0), P("sharp", "Sharpness", 0f, 1f, 0.6f),
                P("lightAngle", "Light Angle", 0f, 360f, 45f, 0), P("relief", "Relief", 0f, 2f, 1f), P("animate", "Drift", 0f, 2f, 0.3f), P("amount", "Amount", 0f, 1f, 0.8f)),
            emptyList(), """
float heightF(vec2 p){
  float h = 0.0;
  float k = 1.0;
  for (int i = 0; i < 8; i++) {
    if (float(i) >= folds) break;
    p = abs(p) - vec2(0.55 + 0.07 * float(i), 0.35);
    p = rot(p, 0.9 + 0.4 * float(i) + uTime * animate * 0.05);
    h += abs(p.x) * k;
    k *= 0.65;
  }
  return h;
}
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  vec2 p = (uv - 0.5) * vec2(uRes.x / uRes.y, 1.0) * scale * 0.5;
  float e = 0.01;
  float h0 = heightF(p);
  vec2 n = vec2(heightF(p + vec2(e, 0.0)) - h0, heightF(p + vec2(0.0, e)) - h0) / e * sharp;
  vec2 L = vec2(cos(radians(lightAngle)), sin(radians(lightAngle)));
  float shade = 0.55 + clamp(dot(n, L) * 0.25 * relief, -0.45, 0.45);
  vec3 o = mix(c.rgb, c.rgb * shade * 1.8, amount);
  return vec4(o * c.a, c.a);
}""")

        fx("texturemoire", "TextureMoire", "Sapphire-style", "Interfering ring patterns create a moire texture that can be overlaid, multiplied or replace the image.",
            listOf(P("frequency", "Frequency", 2f, 120f, 40f, 0), P("offset", "Ring Offset", 0f, 1f, 0.12f), P("spin", "Spin", 0f, 2f, 0.2f),
                P("contrast", "Contrast", 0f, 3f, 1.4f), P("tintHue", "Tint Hue", 0f, 1f, 0.6f), P("tintAmt", "Tint Amount", 0f, 1f, 0f),
                P("amount", "Amount", 0f, 1f, 0.7f), P("mode", "Blend", 0f, 2f, 0f, 0, listOf("Overlay", "Multiply", "Replace"))),
            emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  vec2 p = (uv - 0.5) * vec2(uRes.x / uRes.y, 1.0);
  float a = uTime * spin;
  vec2 c1 = vec2(cos(a), sin(a)) * offset;
  float f1 = sin(length(p - c1) * frequency * 6.2832);
  float f2 = sin(length(p + c1) * frequency * 6.2832);
  float m = clamp((0.5 + 0.5 * f1 * f2 - 0.5) * contrast + 0.5, 0.0, 1.0);
  vec3 tex = mix(vec3(m), hsv2rgb(vec3(tintHue, 0.6, m)), tintAmt);
  vec3 bl;
  if (mode < 0.5) bl = mix(2.0 * c.rgb * tex, 1.0 - 2.0 * (1.0 - c.rgb) * (1.0 - tex), step(0.5, c.rgb));
  else if (mode < 1.5) bl = c.rgb * tex * 1.5;
  else bl = tex;
  vec3 o = mix(c.rgb, bl, amount);
  return vec4(o * c.a, c.a);
}""")

        fx("zebrafy", "Zebrafy", "Sapphire-style", "Converts brightness into zebra stripes: brighter areas get wider stripes.",
            listOf(P("stripes", "Stripes", 2f, 120f, 28f, 0), P("angle", "Angle", -90f, 90f, 35f, 0), P("softness", "Softness", 0f, 1f, 0.12f),
                P("bias", "Brightness Bias", -0.5f, 0.5f, 0f), P("invert", "Invert", 0f, 1f, 0f, 0, listOf("Off", "On")),
                P("colorize", "Keep Color", 0f, 1f, 0f), P("amount", "Amount", 0f, 1f, 1f)),
            emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = unpremul(src(uv));
  float L = clamp(luma(c.rgb) + bias, 0.0, 1.0);
  vec2 p = (uv - 0.5) * vec2(uRes.x / uRes.y, 1.0);
  float a = radians(angle);
  float f = fract(dot(p, vec2(cos(a), sin(a))) * stripes);
  float m = 1.0 - smoothstep(L - softness * 0.5 - 0.001, L + softness * 0.5 + 0.001, f);
  if (invert > 0.5) m = 1.0 - m;
  vec3 zc = mix(vec3(m), c.rgb * m, colorize);
  vec3 o = mix(c.rgb, zc, amount);
  return vec4(o * c.a, c.a);
}""")

        fx("twitch", "Twitch", "Video Copilot-style", "Random flicker hits: shake, zoom punch, RGB split, glitch bands and flashes that decay after each beat.",
            listOf(P("intensity", "Intensity", 0f, 2f, 1f), P("frequency", "Twitches / sec", 0.5f, 30f, 7f, 1), P("shake", "Shake", 0f, 1f, 0.5f),
                P("split", "RGB Split", 0f, 1f, 0.5f), P("zoom", "Zoom Punch", 0f, 1f, 0.3f), P("flash", "Flash", 0f, 1f, 0.35f),
                P("glitch", "Glitch Bands", 0f, 1f, 0.4f), P("seed", "Seed", 0f, 100f, 3f, 0)),
            emptyList(), """
vec4 effect(vec2 uv){
  float f = uTime * frequency;
  float i = floor(f);
  float ph = fract(f);
  float on = step(0.45, hash11(i * 1.37 + seed));
  float k = on * pow(1.0 - ph, 2.5) * intensity;
  vec2 dir = vec2(hash11(i + seed * 2.0) - 0.5, hash11(i + seed * 5.0) - 0.5) * 2.0;
  float zm = 1.0 + zoom * 0.25 * k * (hash11(i + 9.0) > 0.5 ? 1.0 : -0.5);
  vec2 p = (uv - 0.5) / zm + 0.5 + dir * shake * 0.07 * k;
  float bh = hash21(vec2(floor(uv.y * 24.0), i + seed));
  p.x += (bh - 0.5) * 0.25 * step(0.78, bh) * k * glitch;
  float sp = split * 0.03 * k;
  vec4 a = srcW(p + vec2(sp, 0.0), 0.0);
  vec4 b = srcW(p, 0.0);
  vec4 d = srcW(p - vec2(sp, 0.0), 0.0);
  vec4 c = vec4(a.r, b.g, d.b, max(a.a, max(b.a, d.a)));
  c.rgb += c.a * flash * 0.6 * k * step(0.5, hash11(i + 3.3));
  return c;
}""")

        fx("deepglow", "Deep Glow", "Glow", "Soft exponential glow: bright areas bleed outward with adjustable radius, exposure, threshold and tint. Approximated in one pass.",
            listOf(P("radius", "Radius", 0f, 1f, 0.45f), P("exposure", "Exposure", 0f, 5f, 1.4f), P("threshold", "Threshold", 0f, 1f, 0.35f),
                P("falloff", "Falloff", 0.3f, 4f, 1.6f), P("tintAmt", "Tint Amount", 0f, 1f, 0f), P("hue", "Tint Hue", 0f, 1f, 0.08f)),
            emptyList(), """
vec3 gtap(vec2 uv, float th){
  vec3 rgb = src(uv).rgb;
  float l = max(max(rgb.r, rgb.g), rgb.b);
  float m = max(l - th, 0.0) / max(1.0 - th, 0.001);
  return rgb * (m / max(l, 0.0001));
}
vec4 effect(vec2 uv){
  vec4 base = src(uv);
  float R = radius * 0.18;
  float asp = uRes.x / uRes.y;
  vec3 sum = gtap(uv, threshold);
  float wsum = 1.0;
  for (int r = 1; r <= 5; r++) {
    float fr = float(r) / 5.0;
    float w = exp(-falloff * fr * 2.2);
    float rr = R * fr * (0.35 + 0.65 * fr);
    for (int k = 0; k < 12; k++) {
      float ang = float(k) * 0.5236 + float(r) * 0.7;
      vec2 o = vec2(cos(ang), sin(ang) * asp) * rr;
      sum += gtap(uv + o, threshold) * w;
      wsum += w;
    }
  }
  vec3 glow = sum / wsum * exposure * 2.0;
  vec3 tcol = hsv2rgb(vec3(hue, 0.85, 1.0));
  glow = mix(glow, tcol * dot(glow, vec3(0.333)) * 1.6, tintAmt);
  float a = clamp(max(base.a, dot(glow, vec3(0.333))), 0.0, 1.0);
  return vec4(base.rgb + glow, a);
}""")

        fx("rgbsplit", "RGB Split", "Color", "Separates the red and blue channels along an angle for a chromatic aberration look.",
            listOf(P("amount", "Amount", 0f, 1f, 0.4f), P("angle", "Angle", 0f, 360f, 0f, 0)), emptyList(), """
vec4 effect(vec2 uv){
  vec2 o = vec2(cos(radians(angle)), sin(radians(angle))) * amount * 0.04;
  vec4 a = srcW(uv + o, 0.0);
  vec4 b = src(uv);
  vec4 d = srcW(uv - o, 0.0);
  return vec4(a.r, b.g, d.b, max(a.a, max(b.a, d.a)));
}""")
        fx("blur", "Blur", "Blur", "Smooth gaussian-style blur.", listOf(P("radius", "Radius", 0f, 1f, 0.4f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 acc = vec4(0.0);
  float ws = 0.0;
  for (int i = -2; i <= 2; i++) {
    for (int j = -2; j <= 2; j++) {
      float w = exp(-float(i * i + j * j) * 0.4);
      acc += srcW(uv + vec2(float(i), float(j)) * radius * 0.02, 0.0) * w;
      ws += w;
    }
  }
  return acc / ws;
}""")
        fx("wavewarp", "Wave Warp", "Distort", "Ripples the picture with an animated sine wave.",
            listOf(P("amount", "Amount", 0f, 1f, 0.5f), P("freq", "Frequency", 1f, 60f, 18f, 0), P("speed", "Speed", 0f, 20f, 6f, 1),
                P("dir", "Direction", 0f, 1f, 0f, 0, listOf("Horizontal", "Vertical"))), emptyList(), """
vec4 effect(vec2 uv){
  float w = sin((dir < 0.5 ? uv.y : uv.x) * freq + uTime * speed) * amount * 0.06;
  vec2 p = dir < 0.5 ? vec2(uv.x + w, uv.y) : vec2(uv.x, uv.y + w);
  return srcW(p, 0.0);
}""")
        fx("pixelate", "Pixelate", "Stylize", "Blocky mosaic pixels.", listOf(P("size", "Pixel Size", 2f, 120f, 24f, 0)), emptyList(), """
vec4 effect(vec2 uv){
  vec2 cell = vec2(size) / uRes;
  return src((floor(uv / cell) + 0.5) * cell);
}""")
        fx("grayscale", "Grayscale", "Color", "Removes color.", listOf(P("amount", "Amount", 0f, 1f, 1f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  return vec4(mix(c.rgb, vec3(luma(c.rgb)), amount), c.a);
}""")
        fx("invert", "Invert", "Color", "Inverts the colors.", listOf(P("amount", "Amount", 0f, 1f, 1f)), emptyList(), """
vec4 effect(vec2 uv){
  vec4 c = src(uv);
  return vec4(mix(c.rgb, vec3(c.a) - c.rgb, amount), c.a);
}""")
        loadCustom(ctx)
    }

    // ------------------------------------------------------------------ GLSL assembly

    private const val HEAD = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vUV;
uniform sampler2D uSrc;
uniform sampler2D uIn0;
uniform sampler2D uIn1;
uniform float uHas0;
uniform float uHas1;
uniform float uTime;
uniform vec2 uRes;
"""

    private const val HELPERS = """
float hash11(float p){ p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash21(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
float vnoise(vec2 p){ vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x), mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y); }
float fbm(vec2 p){ float a = 0.5; float s = 0.0; for (int i = 0; i < 5; i++) { s += a * vnoise(p); p *= 2.0; a *= 0.5; } return s; }
float luma(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }
vec3 hsv2rgb(vec3 c){ vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0); vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www); return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y); }
vec2 rot(vec2 p, float a){ float c = cos(a); float s = sin(a); return vec2(c * p.x - s * p.y, s * p.x + c * p.y); }
vec4 src(vec2 uv){ return texture2D(uSrc, uv); }
vec4 in0(vec2 uv){ return texture2D(uIn0, uv); }
vec4 in1(vec2 uv){ return texture2D(uIn1, uv); }
vec4 unpremul(vec4 c){ return c.a > 0.0001 ? vec4(c.rgb / c.a, c.a) : vec4(0.0); }
vec4 srcW(vec2 uv, float m){
  if (m < 0.5) { if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) return vec4(0.0); return texture2D(uSrc, uv); }
  if (m < 1.5) return texture2D(uSrc, fract(uv));
  return texture2D(uSrc, 1.0 - abs(1.0 - mod(uv, 2.0)));
}
"""

    fun fragmentFor(d: EffectDef): String {
        val sb = StringBuilder(HEAD)
        for (p in d.props) sb.append("uniform float ").append(p.name).append(";\n")
        sb.append(HELPERS).append(d.code).append("\nvoid main(){ gl_FragColor = effect(vUV); }\n")
        return sb.toString()
    }

    // ------------------------------------------------------------------ custom effects

    private fun dir(ctx: Context, name: String) = File(ctx.filesDir, name).also { it.mkdirs() }

    fun parseEffect(o: JSONObject): EffectDef {
        val name = o.getString("name").trim()
        require(name.isNotEmpty()) { "Effect needs a name" }
        val desc = o.optString("description", "").trim()
        require(desc.isNotEmpty()) { "Effect needs a description" }
        val code = o.getString("code")
        require(code.contains("effect(")) { "Code must define: vec4 effect(vec2 uv)" }
        val id = o.optString("id", "").ifBlank { "custom_" + name.lowercase().replace(Regex("[^a-z0-9]"), "") }
        val ps = ArrayList<PropDef>()
        val pa = o.optJSONArray("params") ?: JSONArray()
        for (i in 0 until pa.length()) {
            val j = pa.getJSONObject(i)
            val n = j.getString("name")
            require(n.matches(Regex("[A-Za-z][A-Za-z0-9_]*"))) { "Bad parameter name: $n" }
            ps.add(PropDef(id + "__" + n, j.optString("label", n), j.optDouble("min", 0.0).toFloat(), j.optDouble("max", 1.0).toFloat(),
                j.optDouble("def", 0.0).toFloat(), j.optInt("dec", 2), n))
        }
        val ins = ArrayList<String>()
        val ia = o.optJSONArray("inputs")
        if (ia != null) for (i in 0 until minOf(2, ia.length())) ins.add(ia.getString(i))
        return EffectDef(id, name, desc, o.optString("category", "Custom"), ps, ins, code, 0, false)
    }

    fun toJson(d: EffectDef): JSONObject {
        val pa = JSONArray()
        for (p in d.props) pa.put(JSONObject().put("name", p.name).put("label", p.label).put("min", p.min.toDouble())
            .put("max", p.max.toDouble()).put("def", p.def.toDouble()).put("dec", p.dec))
        return JSONObject().put("id", d.id).put("name", d.name).put("description", d.desc).put("category", d.category)
            .put("params", pa).put("inputs", JSONArray(d.inputs)).put("code", d.code)
    }

    /** Returns an error message or null on success. */
    fun addCustom(ctx: Context, json: String): String? {
        return try {
            val d = parseEffect(JSONObject(json))
            add(d)
            File(dir(ctx, "effects"), d.id + ".json").writeText(toJson(d).toString())
            null
        } catch (e: Exception) { e.message ?: "Invalid effect file" }
    }

    fun deleteCustom(ctx: Context, id: String) {
        val d = byId[id] ?: return
        if (d.builtin) return
        byId.remove(id); order.remove(d)
        File(dir(ctx, "effects"), "$id.json").delete()
    }

    private fun loadCustom(ctx: Context) {
        val fs = dir(ctx, "effects").listFiles() ?: return
        for (f in fs) try { val d = parseEffect(JSONObject(f.readText())); if (!byId.containsKey(d.id)) add(d) } catch (e: Exception) { }
    }

    // ------------------------------------------------------------------ presets

    class Preset(val name: String, val json: JSONObject, val builtin: Boolean)

    private val builtinPresets = listOf(
        """{"name":"Neon Glow","effects":[{"id":"deepglow","params":{"radius":0.7,"exposure":2.2,"threshold":0.25,"tintAmt":0.7,"hue":0.85}}]}""",
        """{"name":"Glitch Cut","effects":[{"id":"twitch","params":{"intensity":1.4,"frequency":9,"glitch":0.8}},{"id":"rgbsplit","params":{"amount":0.5}}]}""",
        """{"name":"Retro Print","effects":[{"id":"halftone","params":{"cell":10,"colorMode":1}},{"id":"texturemoire","params":{"amount":0.25}}]}""",
        """{"name":"Dream Warp","effects":[{"id":"psykoblobs","params":{"amount":0.5,"distort":0.7}},{"id":"deepglow","params":{"radius":0.5,"exposure":1.2}}]}""",
        """{"name":"Handheld Cam","effects":[{"id":"sshake","params":{"amount":0.35,"frequency":6,"blur":0.7}}]}""",
        """{"name":"Zebra Skin","effects":[{"id":"zebrafy","params":{"stripes":40,"angle":20}}]}"""
    )

    fun presets(ctx: Context): List<Preset> {
        val out = ArrayList<Preset>()
        for (s in builtinPresets) { val o = JSONObject(s); out.add(Preset(o.getString("name"), o, true)) }
        val fs = dir(ctx, "presets").listFiles()
        if (fs != null) for (f in fs.sortedBy { it.name }) try { val o = JSONObject(f.readText()); out.add(Preset(o.getString("name"), o, false)) } catch (e: Exception) { }
        return out
    }

    fun capturePreset(l: Layer, name: String, t: Float): JSONObject {
        val ea = JSONArray()
        for (id in l.fx) {
            val d = byId[id] ?: continue
            val po = JSONObject()
            for (p in d.props) po.put(p.name, l.p(p.key, l.editTime(p.key, t)).toDouble())
            ea.put(JSONObject().put("id", id).put("params", po))
        }
        return JSONObject().put("name", name).put("effects", ea)
    }

    fun savePreset(ctx: Context, o: JSONObject) {
        val safe = o.getString("name").replace(Regex("[^A-Za-z0-9_ -]"), "_")
        File(dir(ctx, "presets"), "$safe.json").writeText(o.toString())
    }

    fun deletePreset(ctx: Context, name: String) {
        val safe = name.replace(Regex("[^A-Za-z0-9_ -]"), "_")
        File(dir(ctx, "presets"), "$safe.json").delete()
    }

    fun applyPreset(l: Layer, o: JSONObject) {
        val ea = o.optJSONArray("effects") ?: return
        for (i in 0 until ea.length()) {
            val e = ea.getJSONObject(i)
            val id = e.getString("id")
            val d = byId[id] ?: continue
            if (!l.fx.contains(id)) l.fx.add(id)
            l.fxOff.remove(id)
            val po = e.optJSONObject("params") ?: continue
            for (p in d.props) if (po.has(p.name)) { val tr = l.track(p.key); tr.keys.clear(); tr.base = po.getDouble(p.name).toFloat() }
        }
    }
}
