package com.saiki.motion

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

/** Transform math shared by the renderer and the selection overlay. */
object Xf {
    private fun is3d(l: Layer) = l.is3d || l.type == LayerType.CAMERA || l.type == LayerType.MODEL

    fun localModel(l: Layer, lt: Float, qw: Float, qh: Float, out: FloatArray) {
        val d3 = is3d(l)
        var x = l.p("x", lt)
        var y = l.p("y", lt)
        val z = if (d3) l.p("z", lt) else 0f
        if (l.fxOn("shake")) {
            val a = l.p("shake", lt) * 0.08f
            x += sin(lt * 53.1f) * a
            y += cos(lt * 47.3f) * a
        }
        val sc = l.p("scale", lt)
        Matrix.setIdentityM(out, 0)
        Matrix.translateM(out, 0, x, y, z)
        if (d3) {
            Matrix.rotateM(out, 0, l.p("rotX", lt), 1f, 0f, 0f)
            Matrix.rotateM(out, 0, l.p("rotY", lt), 0f, 1f, 0f)
        }
        Matrix.rotateM(out, 0, l.p("rotZ", lt), 0f, 0f, 1f)
        if (l.type != LayerType.CAMERA) Matrix.scaleM(out, 0, sc, sc, sc)
        if (l.fxOn("swing")) {
            val ang = sin(lt * l.p("swingSpeed", lt)) * l.p("swingAngle", lt)
            val px = l.p("swingPX", lt) / 100f * qw * 0.5f
            val py = l.p("swingPY", lt) / 100f * qh * 0.5f
            Matrix.translateM(out, 0, px, py, 0f)
            Matrix.rotateM(out, 0, ang, 0f, 0f, 1f)
            Matrix.translateM(out, 0, -px, -py, 0f)
        }
    }

    /** World matrix including the parent chain. A Null only drives children when its 3D switch is on. */
    fun world(sc: Scene, l: Layer, t: Float, qw: Float, qh: Float, out: FloatArray, depth: Int = 0) {
        localModel(l, l.localTime(t), qw, qh, out)
        if (l.parentId < 0 || depth > 6) return
        val p = sc.layers.firstOrNull { it.id == l.parentId } ?: return
        if (p.id == l.id || (p.type == LayerType.NULL && !p.is3d)) return
        val pm = FloatArray(16)
        world(sc, p, t, 1f, 1f, pm, depth + 1)
        val r = FloatArray(16)
        Matrix.multiplyMM(r, 0, pm, 0, out, 0)
        System.arraycopy(r, 0, out, 0, 16)
    }

    /** A camera only affects layers below it in the stack (earlier in the list). Returns the nearest one above [l]. */
    fun cameraAbove(sc: Scene, l: Layer, t: Float): Layer? {
        val ls = sc.layers
        val i = ls.indexOf(l)
        for (j in i + 1 until ls.size) {
            val c = ls[j]
            if (c.type == LayerType.CAMERA && c.visible && t >= c.start && t <= c.end) return c
        }
        return null
    }

    fun fov(sc: Scene, t: Float, cam: Layer?): Float = if (cam != null) cam.p("camFov", cam.localTime(t)) else sc.fov

    fun viewProj(sc: Scene, t: Float, aspect: Float, cam: Layer?, out: FloatArray) {
        val f = fov(sc, t, cam)
        val proj = FloatArray(16)
        val view = FloatArray(16)
        Matrix.perspectiveM(proj, 0, f, aspect, 0.05f, 100f)
        val d = (1.0 / tan(Math.toRadians(f / 2.0))).toFloat()
        if (cam == null) {
            Matrix.setLookAtM(view, 0, 0f, 0f, d, 0f, 0f, 0f, 0f, 1f, 0f)
        } else {
            val m = FloatArray(16)
            world(sc, cam, t, 1f, 1f, m)
            Matrix.translateM(m, 0, 0f, 0f, d)
            if (!Matrix.invertM(view, 0, m, 0)) Matrix.setLookAtM(view, 0, 0f, 0f, d, 0f, 0f, 0f, 0f, 1f, 0f)
        }
        Matrix.multiplyMM(out, 0, proj, 0, view, 0)
    }
}

class SceneRenderer {
    private class Src(val tex: Int, val w: Int, val h: Int, val oes: Boolean)
    private class TexEntry(val id: Int, val key: String, val w: Int, val h: Int)
    private class Fbo(val id: Int, val tex: Int)
    private class Prog(val p: Int, val a0: Int, val a1: Int, val a2: Int, val a3: Int)
    private class Pass(val p: Int, val aPos: Int, val aUV: Int, val uSrc: Int, val uIn0: Int, val uIn1: Int,
                       val uHas0: Int, val uHas1: Int, val uTime: Int, val uRes: Int, val params: IntArray)

    var outFbo = 0
    private var viewW = 1
    private var viewH = 1

    private val texs = HashMap<Int, TexEntry>()
    private val videos = HashMap<Int, VideoSource>()
    private val models = HashMap<Int, GlbModel>()
    private val fbos = HashMap<String, Fbo>()
    private val passes = HashMap<String, Pass?>()
    private val sprites = IntArray(4)

    private var f2d = 0
    private var fOes = 0
    private var blit = 0
    private var partProg = 0
    private var copyProg = 0
    private var adjTex = 0
    private var adjW = 0
    private var adjH = 0
    private var modelProg = 0

    private val vp2 = FloatArray(16)
    private var vpCur = FloatArray(16)
    private var fovCur = 45f
    private val base = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private val ident = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val pArr = FloatArray(Particles.MAX * 6 * Particles.FLOATS)
    private val pBuf: FloatBuffer = ByteBuffer.allocateDirect(pArr.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    private val quad: FloatBuffer = fb(floatArrayOf(-0.5f, 0.5f, 0f, 0f, -0.5f, -0.5f, 0f, 1f, 0.5f, 0.5f, 1f, 0f, 0.5f, -0.5f, 1f, 1f))
    private val passQuad: FloatBuffer = fb(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))

    private fun fb(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also { it.put(a); it.position(0) }

    fun init() {
        releaseVideos()
        for (m in models.values) try { m.release() } catch (e: Exception) { }
        texs.clear(); models.clear(); fbos.clear(); passes.clear()
        f2d = build(VS, FS2D)
        fOes = build(VS, FSOES)
        blit = build(PASS_VS, BLIT_FS)
        partProg = build(PART_VS, PART_FS)
        copyProg = build(PASS_VS, COPY_FS)
        adjTex = 0; adjW = 0; adjH = 0
        modelProg = build(MODEL_VS, MODEL_FS)
        makeSprites()
    }

    fun releaseVideos() {
        for (v in videos.values) try { v.release() } catch (e: Exception) { }
        videos.clear()
    }

    fun release() {
        releaseVideos()
        for (m in models.values) try { m.release() } catch (e: Exception) { }
        models.clear()
    }

    // ------------------------------------------------------------------ frame

    fun draw(p: Project, s: Scene, t: Float, w: Int, h: Int) {
        viewW = w; viewH = h
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, outFbo)
        GLES20.glViewport(0, 0, w, h)
        val bg = s.bg
        GLES20.glClearColor(Color.red(bg) / 255f, Color.green(bg) / 255f, Color.blue(bg) / 255f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        val aspect = w.toFloat() / h
        Xf.viewProj(s, t, aspect, null, vp2)
        val camVp = HashMap<Int, FloatArray>()
        for (l in s.layers) {
            if (!l.visible || !l.isRenderable() || t < l.start || t > l.end) continue
            val par = s.layers.firstOrNull { it.id == l.parentId }
            if (par != null && par.type == LayerType.GROUP && !par.visible) continue
            if (l.is3d || l.type == LayerType.MODEL) {
                val cam = Xf.cameraAbove(s, l, t)
                vpCur = camVp.getOrPut(cam?.id ?: -1) { FloatArray(16).also { Xf.viewProj(s, t, aspect, cam, it) } }
                fovCur = Xf.fov(s, t, cam)
            } else { vpCur = vp2; fovCur = s.fov }
            GLES20.glEnable(GLES20.GL_BLEND)
            setBlend(l.blend)
            try {
                when (l.type) {
                    LayerType.ADJUST -> drawAdjust(l, s, t, w, h)
                    LayerType.PARTICLES -> drawParticles(l, s, t, aspect)
                    LayerType.MODEL -> drawModel(l, s, t, aspect)
                    else -> drawQuadLayer(l, s, t)
                }
            } catch (e: Exception) { }
        }
    }

    private fun setBlend(b: Int) {
        when (b) {
            1 -> GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE)
            2 -> GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_COLOR)
            3 -> GLES20.glBlendFunc(GLES20.GL_DST_COLOR, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            else -> GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        }
    }

    // ------------------------------------------------------------------ 2D quad layers

    private fun drawQuadLayer(l: Layer, s: Scene, t: Float) {
        val lt = l.localTime(t)
        if (l.fxOn("particles") && l.p("pShowSrc", lt) < 0.5f) { drawParticles(l, s, t, viewW.toFloat() / viewH); return }
        val src = sourceFor(l, lt) ?: return
        val qh = LayerBitmaps.baseHeight(l)
        val qw = qh * l.texAspect
        Xf.world(s, l, t, qw, qh, base)
        val vs = videos[l.id]
        val effs = ArrayList<EffectDef>()
        for (id in l.fx) { val d = Registry.get(id); if (d != null && d.kind == 0 && l.fxOn(id)) effs.add(d) }
        var tex = src.tex
        var oes = src.oes
        if (effs.isNotEmpty()) {
            tex = runEffects(l, s, lt, src, effs, vs?.texMat)
            oes = false
            GLES20.glEnable(GLES20.GL_BLEND)
            setBlend(l.blend)
        }
        val prog = if (oes) fOes else f2d
        GLES20.glUseProgram(prog)
        val aPos = GLES20.glGetAttribLocation(prog, "aPos")
        val aUV = GLES20.glGetAttribLocation(prog, "aUV")
        quad.position(0)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(aPos)
        quad.position(2)
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(aUV)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(if (oes) GLES11Ext.GL_TEXTURE_EXTERNAL_OES else GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uOpacity"), l.p("opacity", lt).coerceIn(0f, 1f))
        if (oes) GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uTexMat"), 1, false, vs?.texMat ?: ident, 0)
        val uMVP = GLES20.glGetUniformLocation(prog, "uMVP")
        val vp = vpCur

        if (l.fxOn("tile")) {
            val nx = l.p("tileNX", lt).roundToInt().coerceIn(0, 6)
            val ny = l.p("tileNY", lt).roundToInt().coerceIn(0, 6)
            val gap = l.p("tileGap", lt)
            val sx = qw * (1f + gap)
            val sy = qh * (1f + gap)
            val px = l.p("tileX", lt)
            val py = l.p("tileY", lt)
            val fx0 = floor(px)
            val fy0 = floor(py)
            val mirror = l.p("tileMirror", lt) >= 0.5f
            for (j in -ny - 1..ny) for (i in -nx - 1..nx) {
                val ci = i + fx0.toInt()
                val cj = j + fy0.toInt()
                val flipX = mirror && (ci and 1) == 1
                val flipY = mirror && (cj and 1) == 1
                drawQuad(uMVP, vp, (i + px - fx0) * sx, (j + py - fy0) * sy, if (flipX) -qw else qw, if (flipY) -qh else qh)
            }
        } else drawQuad(uMVP, vp, 0f, 0f, qw, qh)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aUV)
        if (l.fxOn("particles")) drawParticles(l, s, t, viewW.toFloat() / viewH)
    }

    private fun drawQuad(uMVP: Int, vp: FloatArray, ox: Float, oy: Float, sx: Float, sy: Float) {
        System.arraycopy(base, 0, model, 0, 16)
        Matrix.translateM(model, 0, ox, oy, 0f)
        Matrix.scaleM(model, 0, sx, sy, 1f)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    // ------------------------------------------------------------------ adjustment layers

    /** Runs the layer's effects on everything drawn so far (the layers below it). */
    private fun drawAdjust(l: Layer, s: Scene, t: Float, w: Int, h: Int) {
        val lt = l.localTime(t)
        val effs = ArrayList<EffectDef>()
        for (id in l.fx) { val d = Registry.get(id); if (d != null && d.kind == 0 && l.fxOn(id)) effs.add(d) }
        if (effs.isEmpty()) return
        if (adjTex == 0 || adjW != w || adjH != h) {
            if (adjTex != 0) GLES20.glDeleteTextures(1, intArrayOf(adjTex), 0)
            val ids = IntArray(1)
            GLES20.glGenTextures(1, ids, 0)
            adjTex = ids[0]
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, adjTex)
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
            texParams()
            adjW = w; adjH = h
        }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, outFbo)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, adjTex)
        GLES20.glCopyTexSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, 0, 0, w, h)
        val res = runEffects(l, s, lt, Src(adjTex, w, h, false), effs, null)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUseProgram(copyProg)
        val aPos = GLES20.glGetAttribLocation(copyProg, "aPos")
        val aUV = GLES20.glGetAttribLocation(copyProg, "aUV")
        bindPass(aPos, aUV)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, res)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(copyProg, "uTex"), 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(copyProg, "uOpacity"), l.p("opacity", lt).coerceIn(0f, 1f))
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aUV)
    }

    // ------------------------------------------------------------------ effect passes

    private fun runEffects(l: Layer, s: Scene, lt: Float, src: Src, effs: List<EffectDef>, texMat: FloatArray?): Int {
        var fw = src.w
        var fh = src.h
        val big = max(fw, fh)
        if (big > 2048) { fw = fw * 2048 / big; fh = fh * 2048 / big }
        fw = max(fw, 2); fh = max(fh, 2)
        val fa = fbo(fw, fh, 0)
        val fbb = fbo(fw, fh, 1)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glViewport(0, 0, fw, fh)
        var curTex = src.tex
        var cur: Fbo? = null
        if (src.oes) {
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fa.id)
            GLES20.glClearColor(0f, 0f, 0f, 0f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUseProgram(blit)
            val aPos = GLES20.glGetAttribLocation(blit, "aPos")
            val aUV = GLES20.glGetAttribLocation(blit, "aUV")
            bindPass(aPos, aUV)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, src.tex)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(blit, "uTex"), 0)
            GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(blit, "uTexMat"), 1, false, texMat ?: ident, 0)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aUV)
            cur = fa
            curTex = fa.tex
        }
        for (d in effs) {
            val ps = passFor(d) ?: continue
            val out = if (cur === fa) fbb else fa
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, out.id)
            GLES20.glViewport(0, 0, fw, fh)
            GLES20.glClearColor(0f, 0f, 0f, 0f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUseProgram(ps.p)
            bindPass(ps.aPos, ps.aUV)
            var has0 = 0f
            var has1 = 0f
            for ((i, nm) in d.inputs.withIndex()) {
                val rid = l.inputs[d.id + ":" + nm]
                val ref = if (rid != null) s.layers.firstOrNull { it.id == rid && it.id != l.id } else null
                val ok = ref != null && ref.isRenderable() && ref.type != LayerType.VIDEO && ref.type != LayerType.PARTICLES && ref.type != LayerType.MODEL
                val rs = if (ok) sourceFor(ref!!, lt) else null
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + 1 + i)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, rs?.tex ?: curTex)
                GLES20.glUniform1i(if (i == 0) ps.uIn0 else ps.uIn1, 1 + i)
                if (rs != null) { if (i == 0) has0 = 1f else has1 = 1f }
            }
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, curTex)
            GLES20.glUniform1i(ps.uSrc, 0)
            GLES20.glUniform1f(ps.uHas0, has0)
            GLES20.glUniform1f(ps.uHas1, has1)
            GLES20.glUniform1f(ps.uTime, lt)
            GLES20.glUniform2f(ps.uRes, fw.toFloat(), fh.toFloat())
            for ((i, pd) in d.props.withIndex()) GLES20.glUniform1f(ps.params[i], l.p(pd.key, lt))
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(ps.aPos); GLES20.glDisableVertexAttribArray(ps.aUV)
            cur = out
            curTex = out.tex
        }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, outFbo)
        GLES20.glViewport(0, 0, viewW, viewH)
        return curTex
    }

    private fun bindPass(aPos: Int, aUV: Int) {
        passQuad.position(0)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, passQuad)
        GLES20.glEnableVertexAttribArray(aPos)
        passQuad.position(2)
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 16, passQuad)
        GLES20.glEnableVertexAttribArray(aUV)
    }

    private fun passFor(d: EffectDef): Pass? {
        val key = d.id + "#" + d.code.hashCode() + "#" + d.props.size
        if (passes.containsKey(key)) return passes[key]
        var pass: Pass? = null
        try {
            val p = build(PASS_VS, Registry.fragmentFor(d))
            pass = Pass(p, GLES20.glGetAttribLocation(p, "aPos"), GLES20.glGetAttribLocation(p, "aUV"),
                GLES20.glGetUniformLocation(p, "uSrc"), GLES20.glGetUniformLocation(p, "uIn0"), GLES20.glGetUniformLocation(p, "uIn1"),
                GLES20.glGetUniformLocation(p, "uHas0"), GLES20.glGetUniformLocation(p, "uHas1"),
                GLES20.glGetUniformLocation(p, "uTime"), GLES20.glGetUniformLocation(p, "uRes"),
                IntArray(d.props.size) { GLES20.glGetUniformLocation(p, d.props[it].name) })
            Registry.errors.remove(d.id)
        } catch (e: RuntimeException) {
            Registry.errors[d.id] = e.message ?: "shader error"
        }
        passes[key] = pass
        return pass
    }

    private fun fbo(w: Int, h: Int, slot: Int): Fbo {
        val key = "$w x $h #$slot"
        fbos[key]?.let { return it }
        if (fbos.size > 8) {
            for (f in fbos.values) { GLES20.glDeleteFramebuffers(1, intArrayOf(f.id), 0); GLES20.glDeleteTextures(1, intArrayOf(f.tex), 0) }
            fbos.clear()
        }
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
        texParams()
        val f = IntArray(1)
        GLES20.glGenFramebuffers(1, f, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, f[0])
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, t[0], 0)
        val fo = Fbo(f[0], t[0])
        fbos[key] = fo
        return fo
    }

    private fun texParams() {
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    // ------------------------------------------------------------------ sources

    private fun sourceFor(l: Layer, lt: Float): Src? {
        if (l.type == LayerType.VIDEO) {
            val path = l.imagePath ?: return null
            val vs = videos.getOrPut(l.id) { VideoSource(path).also { it.init() } }
            if (vs.failed) return null
            vs.seek(((lt - l.start).coerceAtLeast(0f) * 1_000_000f).toLong())
            l.texAspect = vs.w.toFloat() / vs.h.toFloat()
            return Src(vs.texId, vs.w, vs.h, true)
        }
        val e = texFor(l)
        return Src(e.id, e.w, e.h, false)
    }

    private fun texFor(l: Layer): TexEntry {
        val key = l.texKey()
        val old = texs[l.id]
        if (old != null && old.key == key) return old
        if (old != null) GLES20.glDeleteTextures(1, intArrayOf(old.id), 0)
        val bmp = LayerBitmaps.make(l)
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        texParams()
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        l.texAspect = bmp.width.toFloat() / bmp.height.toFloat()
        val e = TexEntry(ids[0], key, bmp.width, bmp.height)
        bmp.recycle()
        texs[l.id] = e
        return e
    }

    // ------------------------------------------------------------------ particles

    private fun drawParticles(l: Layer, s: Scene, t: Float, aspect: Float) {
        val lt = l.localTime(t)
        val n = Particles.build(l, lt, pArr)
        if (n == 0) return
        pBuf.clear()
        pBuf.put(pArr, 0, n * 6 * Particles.FLOATS)
        Xf.world(s, l, t, 1f, 1f, base)
        Matrix.multiplyMM(mvp, 0, vpCur, 0, base, 0)
        val fov = fovCur
        val f = (1.0 / tan(Math.toRadians(fov / 2.0))).toFloat()
        GLES20.glUseProgram(partProg)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(partProg, "uMVP"), 1, false, mvp, 0)
        GLES20.glUniform2f(GLES20.glGetUniformLocation(partProg, "uPS"), f / aspect, f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(partProg, "uSizeScale"), l.p("scale", lt))
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, sprites[l.p("pType", lt).toInt().coerceIn(0, 3)])
        GLES20.glUniform1i(GLES20.glGetUniformLocation(partProg, "uTex"), 0)
        if (l.p("pAdd", lt) < 0.5f) GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE)
        else GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        val stride = Particles.FLOATS * 4
        val names = arrayOf("aCenter", "aCorner", "aUV", "aColor")
        val sizes = intArrayOf(3, 2, 2, 4)
        val offs = intArrayOf(0, 3, 5, 7)
        val locs = IntArray(4)
        for (i in 0 until 4) {
            locs[i] = GLES20.glGetAttribLocation(partProg, names[i])
            pBuf.position(offs[i])
            GLES20.glVertexAttribPointer(locs[i], sizes[i], GLES20.GL_FLOAT, false, stride, pBuf)
            GLES20.glEnableVertexAttribArray(locs[i])
        }
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, n * 6)
        for (i in 0 until 4) GLES20.glDisableVertexAttribArray(locs[i])
        pBuf.position(0)
    }

    private fun makeSprites() {
        val sz = 64
        for (k in 0 until 4) {
            val bmp = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = Color.WHITE
            val h = sz / 2f
            when (k) {
                0 -> { p.shader = RadialGradient(h, h, h, intArrayOf(0xFFFFFFFF.toInt(), 0x88FFFFFF.toInt(), 0x00FFFFFF), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP); c.drawCircle(h, h, h, p) }
                1 -> {
                    val path = Path()
                    for (i in 0 until 10) {
                        val a = -Math.PI / 2 + i * Math.PI / 5
                        val r = if (i % 2 == 0) h * 0.9f else h * 0.38f
                        val x = (h + r * cos(a)).toFloat(); val y = (h + r * sin(a)).toFloat()
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    path.close()
                    p.maskFilter = BlurMaskFilter(2f, BlurMaskFilter.Blur.NORMAL)
                    c.drawPath(path, p)
                }
                2 -> { p.shader = RadialGradient(h, h, h, intArrayOf(0xFFFFFFFF.toInt(), 0x00FFFFFF), floatArrayOf(0.2f, 1f), Shader.TileMode.CLAMP); c.save(); c.scale(0.12f, 1f, h, h); c.drawCircle(h, h, h, p); c.restore() }
                else -> c.drawCircle(h, h, h * 0.9f, p)
            }
            val ids = IntArray(1)
            GLES20.glGenTextures(1, ids, 0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
            texParams()
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
            bmp.recycle()
            sprites[k] = ids[0]
        }
    }

    // ------------------------------------------------------------------ 3D models

    private fun drawModel(l: Layer, s: Scene, t: Float, aspect: Float) {
        val path = l.imagePath ?: return
        val m = models.getOrPut(l.id) { GlbModel(path).also { it.load() } }
        if (!m.ok) return
        val lt = l.localTime(t)
        Xf.world(s, l, t, 1f, 1f, base)
        Matrix.multiplyMM(mvp, 0, vpCur, 0, base, 0)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(true)
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(modelProg)
        val uMVP = GLES20.glGetUniformLocation(modelProg, "uMVP")
        val uNM = GLES20.glGetUniformLocation(modelProg, "uNM")
        val uColor = GLES20.glGetUniformLocation(modelProg, "uColor")
        val uHasTex = GLES20.glGetUniformLocation(modelProg, "uHasTex")
        val aPos = GLES20.glGetAttribLocation(modelProg, "aPos")
        val aNrm = GLES20.glGetAttribLocation(modelProg, "aNrm")
        val aUV = GLES20.glGetAttribLocation(modelProg, "aUV")
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uNM, 1, false, base, 0)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(modelProg, "uTex"), 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        val op = l.p("opacity", lt)
        for (pr in m.prims) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, pr.vbo)
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 32, 0)
            GLES20.glEnableVertexAttribArray(aPos)
            GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, 32, 12)
            GLES20.glEnableVertexAttribArray(aNrm)
            GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 32, 24)
            GLES20.glEnableVertexAttribArray(aUV)
            GLES20.glUniform4f(uColor, pr.color[0] * op, pr.color[1] * op, pr.color[2] * op, 1f)
            if (pr.tex != 0) { GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, pr.tex); GLES20.glUniform1f(uHasTex, 1f) } else GLES20.glUniform1f(uHasTex, 0f)
            if (pr.indexType != 0) {
                GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, pr.ibo)
                GLES20.glDrawElements(GLES20.GL_TRIANGLES, pr.count, pr.indexType, 0)
            } else GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, pr.count)
        }
        GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aNrm); GLES20.glDisableVertexAttribArray(aUV)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
    }

    // ------------------------------------------------------------------ shaders

    private fun build(vs: String, fs: String): Int {
        fun sh(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) {
                val log = GLES20.glGetShaderInfoLog(s)
                GLES20.glDeleteShader(s)
                throw RuntimeException(log)
            }
            return s
        }
        val v = sh(GLES20.GL_VERTEX_SHADER, vs)
        val f = sh(GLES20.GL_FRAGMENT_SHADER, fs)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Link error: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    companion object {
        private const val VS = """
            uniform mat4 uMVP;
            attribute vec2 aPos;
            attribute vec2 aUV;
            varying vec2 vUV;
            void main() { vUV = aUV; gl_Position = uMVP * vec4(aPos, 0.0, 1.0); }
        """
        private const val FS2D = """
            precision mediump float;
            varying vec2 vUV;
            uniform sampler2D uTex;
            uniform float uOpacity;
            void main() { gl_FragColor = texture2D(uTex, vUV) * uOpacity; }
        """
        private const val FSOES = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vUV;
            uniform samplerExternalOES uTex;
            uniform mat4 uTexMat;
            uniform float uOpacity;
            void main() {
                vec2 uv = (uTexMat * vec4(vUV.x, 1.0 - vUV.y, 0.0, 1.0)).xy;
                gl_FragColor = texture2D(uTex, uv) * uOpacity;
            }
        """
        private const val PASS_VS = """
            attribute vec2 aPos;
            attribute vec2 aUV;
            varying vec2 vUV;
            void main() { vUV = aUV; gl_Position = vec4(aPos, 0.0, 1.0); }
        """
        private const val COPY_FS = """
            precision mediump float;
            varying vec2 vUV;
            uniform sampler2D uTex;
            uniform float uOpacity;
            void main() { gl_FragColor = texture2D(uTex, vUV) * uOpacity; }
        """
        private const val BLIT_FS = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vUV;
            uniform samplerExternalOES uTex;
            uniform mat4 uTexMat;
            void main() {
                vec2 uv = (uTexMat * vec4(vUV.x, 1.0 - vUV.y, 0.0, 1.0)).xy;
                gl_FragColor = texture2D(uTex, uv);
            }
        """
        private const val PART_VS = """
            uniform mat4 uMVP;
            uniform vec2 uPS;
            uniform float uSizeScale;
            attribute vec3 aCenter;
            attribute vec2 aCorner;
            attribute vec2 aUV;
            attribute vec4 aColor;
            varying vec2 vUV;
            varying vec4 vColor;
            void main() {
                vUV = aUV;
                vColor = aColor;
                vec4 c = uMVP * vec4(aCenter, 1.0);
                c.xy += aCorner * uSizeScale * uPS;
                gl_Position = c;
            }
        """
        private const val PART_FS = """
            precision mediump float;
            varying vec2 vUV;
            varying vec4 vColor;
            uniform sampler2D uTex;
            void main() { gl_FragColor = texture2D(uTex, vUV) * vColor; }
        """
        private const val MODEL_VS = """
            uniform mat4 uMVP;
            uniform mat4 uNM;
            attribute vec3 aPos;
            attribute vec3 aNrm;
            attribute vec2 aUV;
            varying vec3 vN;
            varying vec2 vUV;
            void main() {
                vN = (uNM * vec4(aNrm, 0.0)).xyz;
                vUV = aUV;
                gl_Position = uMVP * vec4(aPos, 1.0);
            }
        """
        private const val MODEL_FS = """
            precision mediump float;
            varying vec3 vN;
            varying vec2 vUV;
            uniform vec4 uColor;
            uniform float uHasTex;
            uniform sampler2D uTex;
            void main() {
                vec4 b = uColor;
                if (uHasTex > 0.5) b *= texture2D(uTex, vUV);
                vec3 n = normalize(vN);
                float d = max(dot(n, normalize(vec3(0.4, 0.7, 0.6))), 0.0);
                float r = max(dot(n, normalize(vec3(-0.5, -0.2, 0.3))), 0.0) * 0.25;
                gl_FragColor = vec4(b.rgb * (0.32 + 0.78 * d + r), 1.0);
            }
        """
    }
}
