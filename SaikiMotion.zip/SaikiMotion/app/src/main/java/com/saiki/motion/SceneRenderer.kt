package com.saiki.motion

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

/** Transform math shared by the renderer and the selection overlay. */
object Xf {
    /** Unscaled quad size (world units) of a layer, matching what the renderer draws. */
    fun quadSize(l: Layer): Pair<Float, Float> {
        val qh = LayerBitmaps.baseHeight(l)
        val flat = l.type == LayerType.CAMERA || l.type == LayerType.NULL || l.type == LayerType.GROUP || l.type == LayerType.ADJUST || l.type == LayerType.PARTICLES || l.type == LayerType.MODEL
        return Pair(qh * (if (flat) 1f else l.texAspect), qh)
    }
    private fun is3d(l: Layer) = l.is3d || l.type == LayerType.CAMERA || l.type == LayerType.MODEL

    fun localModel(l: Layer, lt: Float, qw: Float, qh: Float, out: FloatArray) {
        val d3 = is3d(l)
        var x = l.p("x", lt)
        var y = l.p("y", lt)
        val z = if (d3) l.p("z", lt) else 0f
        if (l.fxOn("shake")) {
            val a = l.p("shake", lt) * 0.08f
            x += sin(lt * 53.1f) * a
            y += cos(lt * 47.3f) * a
        }
        val sc = l.p("scale", lt)
        Matrix.setIdentityM(out, 0)
        Matrix.translateM(out, 0, x, y, z)
        if (d3) {
            Matrix.rotateM(out, 0, l.p("rotX", lt), 1f, 0f, 0f)
            Matrix.rotateM(out, 0, l.p("rotY", lt), 0f, 1f, 0f)
        }
        Matrix.rotateM(out, 0, l.p("rotZ", lt), 0f, 0f, 1f)
        if (l.type != LayerType.CAMERA) Matrix.scaleM(out, 0, sc, sc, sc)
        val ax = l.p("anchorX", lt)
        val ay = l.p("anchorY", lt)
        if (ax != 50f || ay != 50f) Matrix.translateM(out, 0, -(ax - 50f) / 100f * qw, (ay - 50f) / 100f * qh, 0f)
        if (l.fxOn("swing")) {
            val ang = sin(lt * l.p("swingSpeed", lt)) * l.p("swingAngle", lt)
            val px = l.p("swingPX", lt) / 100f * qw * 0.5f
            val py = l.p("swingPY", lt) / 100f * qh * 0.5f
            Matrix.translateM(out, 0, px, py, 0f)
            Matrix.rotateM(out, 0, ang, 0f, 0f, 1f)
            Matrix.translateM(out, 0, -px, -py, 0f)
        }
    }

    /** A layer's own 2D transform expressed in screen (NDC) space. Groups are flat planes composited with this. */
    fun ndcLocal(l: Layer, lt: Float, aspect: Float, out: FloatArray) {
        val base = FloatArray(16)
        localModel(l, lt, 2f, 2f, base)
        val m1 = FloatArray(16)
        Matrix.setIdentityM(m1, 0)
        Matrix.scaleM(m1, 0, 1f / aspect, 1f, 1f)
        Matrix.multiplyMM(out, 0, m1, 0, base, 0)
        Matrix.scaleM(out, 0, aspect, 1f, 1f)
    }

    fun groupMatrix(sc: Scene, l: Layer, t: Float, aspect: Float): FloatArray? {
        val par = sc.layers.firstOrNull { it.id == l.parentId } ?: return null
        if (par.type != LayerType.GROUP) return null
        val m = FloatArray(16)
        ndcLocal(par, par.localTime(t), aspect, m)
        return m
    }

    /** World matrix including the parent chain. A Null only drives children when its 3D switch is on. */
    fun world(sc: Scene, l: Layer, t: Float, qw: Float, qh: Float, out: FloatArray, depth: Int = 0) {
        localModel(l, l.localTime(t), qw, qh, out)
        if (l.parentId < 0 || depth > 6) return
        val p = sc.layers.firstOrNull { it.id == l.parentId } ?: return
        if (p.id == l.id || (p.type == LayerType.NULL && !p.is3d) || p.type == LayerType.GROUP) return
        val pm = FloatArray(16)
        world(sc, p, t, 1f, 1f, pm, depth + 1)
        val r = FloatArray(16)
        Matrix.multiplyMM(r, 0, pm, 0, out, 0)
        System.arraycopy(r, 0, out, 0, 16)
    }

    private fun scopeOf(sc: Scene, x: Layer): Int {
        val p = sc.layers.firstOrNull { it.id == x.parentId } ?: return -1
        return if (p.type == LayerType.GROUP) p.id else -1
    }

    /** A camera only affects layers below it. A camera inside a group drives that group first; otherwise a top-level camera above works. */
    fun cameraAbove(sc: Scene, l: Layer, t: Float): Layer? {
        val ls = sc.layers
        val i = ls.indexOf(l)
        val mine = scopeOf(sc, l)
        var fallback: Layer? = null
        for (j in i + 1 until ls.size) {
            val c = ls[j]
            if (c.type != LayerType.CAMERA || !c.visible || t < c.start || t > c.end) continue
            val sc2 = scopeOf(sc, c)
            if (sc2 == mine) return c
            if (fallback == null && sc2 == -1) fallback = c
        }
        return fallback
    }

    fun fov(sc: Scene, t: Float, cam: Layer?): Float = if (cam != null) cam.p("camFov", cam.localTime(t)) else sc.fov

    fun viewProj(sc: Scene, t: Float, aspect: Float, cam: Layer?, out: FloatArray) {
        val f = fov(sc, t, cam)
        val proj = FloatArray(16)
        val view = FloatArray(16)
        Matrix.perspectiveM(proj, 0, f, aspect, 0.2f, 50f)
        val d = (1.0 / tan(Math.toRadians(f / 2.0))).toFloat()
        if (cam == null) {
            Matrix.setLookAtM(view, 0, 0f, 0f, d, 0f, 0f, 0f, 0f, 1f, 0f)
        } else {
            val m = FloatArray(16)
            world(sc, cam, t, 1f, 1f, m)
            Matrix.translateM(m, 0, 0f, 0f, d)
            if (!Matrix.invertM(view, 0, m, 0)) Matrix.setLookAtM(view, 0, 0f, 0f, d, 0f, 0f, 0f, 0f, 1f, 0f)
        }
        Matrix.multiplyMM(out, 0, proj, 0, view, 0)
    }
}

/** One applied effect instance on a layer: entry id (may carry ~n) plus its definition. */
class Fx(val entry: String, val def: EffectDef)

class SceneRenderer {
    private class Src(val tex: Int, val w: Int, val h: Int, val oes: Boolean)
    private class TexEntry(val id: Int, val key: String, val w: Int, val h: Int)
    private class Fbo(val id: Int, val tex: Int, val rb: Int = 0)
    private class Prog(val p: Int, val a0: Int, val a1: Int, val a2: Int, val a3: Int)
    private class Pass(val p: Int, val aPos: Int, val aUV: Int, val uSrc: Int, val uIn0: Int, val uIn1: Int,
                       val uHas0: Int, val uHas1: Int, val uTime: Int, val uRes: Int, val params: IntArray, val colorLocs: IntArray)

    var outFbo = 0
    private var viewW = 1
    private var viewH = 1

    private val texs = HashMap<Int, TexEntry>()
    private val videos = HashMap<Int, VideoSource>()
    private val videosB = HashMap<Int, VideoSource>()
    private val models = HashMap<Int, GlbModel>()
    private val fbos = HashMap<String, Fbo>()
    private val passes = HashMap<String, Pass?>()
    private val sprites = IntArray(4)

    private var f2d = 0
    private var fOes = 0
    private var blit = 0
    private var partProg = 0
    private var copyProg = 0
    private var padProg = 0
    private var lastPad = 1f
    private var brightProg = 0
    private var blurProg = 0
    private var bloomProg = 0
    private var downProg = 0
    private var upProg = 0
    private var halfOk = false
    private var maskProg = 0
    private val camVp = HashMap<Int, FloatArray>()
    private var adjTex = 0
    private var adjW = 0
    private var adjH = 0
    private var modelProg = 0

    private val vp2 = FloatArray(16)
    private var vpCur = FloatArray(16)
    private var fovCur = 45f
    private val base = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)
    private val ident = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val pArr = FloatArray(Particles.MAX * 6 * Particles.FLOATS)
    private val pBuf: FloatBuffer = ByteBuffer.allocateDirect(pArr.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

    private val quad: FloatBuffer = fb(floatArrayOf(-0.5f, 0.5f, 0f, 0f, -0.5f, -0.5f, 0f, 1f, 0.5f, 0.5f, 1f, 0f, 0.5f, -0.5f, 1f, 1f))
    private val passQuad: FloatBuffer = fb(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))

    private fun fb(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also { it.put(a); it.position(0) }

    fun init() {
        releaseVideos()
        for (m in models.values) try { m.release() } catch (e: Exception) { }
        texs.clear(); models.clear(); fbos.clear(); passes.clear()
        f2d = buildSafe(VS, FS2D)
        fOes = buildSafe(VS, FSOES)
        blit = buildSafe(PASS_VS, BLIT_FS)
        partProg = buildSafe(PART_VS, PART_FS)
        copyProg = buildSafe(COPY_VS, COPY_FS)
        padProg = buildSafe(PASS_VS, PAD_FS)
        brightProg = buildSafe(PASS_VS, BRIGHT_FS)
        blurProg = buildSafe(PASS_VS, BLUR_FS)
        bloomProg = buildSafe(PASS_VS, BLOOM_FS)
        downProg = buildSafe(PASS_VS, DOWN_FS)
        upProg = buildSafe(PASS_VS, UP_FS)
        maskProg = buildSafe(PASS_VS, MASK_FS)
        adjTex = 0; adjW = 0; adjH = 0
        modelProg = buildSafe(MODEL_VS, MODEL_FS)
        val ext = GLES20.glGetString(GLES20.GL_EXTENSIONS) ?: ""
        halfOk = ext.contains("GL_OES_texture_half_float_linear") && ext.contains("GL_EXT_color_buffer_half_float")
        makeSprites()
    }

    fun releaseVideos() {
        for (v in videos.values) try { v.release() } catch (e: Exception) { }
        for (v in videosB.values) try { v.release() } catch (e: Exception) { }
        videosB.clear()
        videos.clear()
    }

    fun release() {
        releaseVideos()
        for (m in models.values) try { m.release() } catch (e: Exception) { }
        models.clear()
    }

    // ------------------------------------------------------------------ frame

    fun draw(p: Project, s: Scene, t: Float, w: Int, h: Int) {
        viewW = w; viewH = h
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, outFbo)
        GLES20.glViewport(0, 0, w, h)
        val bg = s.bg
        GLES20.glClearColor(Color.red(bg) / 255f, Color.green(bg) / 255f, Color.blue(bg) / 255f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        val aspect = w.toFloat() / h
        Xf.viewProj(s, t, aspect, null, vp2)
        camVp.clear()
        for (l in s.layers) {
            val par = s.layers.firstOrNull { it.id == l.parentId }
            if (par != null && par.type == LayerType.GROUP && (!par.visible || groupActive(par, s))) continue
            if (l.type == LayerType.GROUP) { if (l.visible && groupActive(l, s)) drawGroup(l, s, t, w, h, aspect); continue }
            drawOne(l, s, t, aspect)
        }
    }

    private fun drawOne(l: Layer, s: Scene, t: Float, aspect: Float, sub: Boolean = false) {
        if (!l.visible || !l.isRenderable() || t < l.start || t > l.end) return
        val camBlur = !sub && l.type != LayerType.CAMERA && (l.is3d || l.type == LayerType.MODEL) && (cameraAbove(s, l, t)?.mblur == true)
        if ((l.mblur || camBlur) && !sub && l.type != LayerType.ADJUST && l.type != LayerType.VIDEO && l.type != LayerType.CAMERA) { drawBlurred(l, s, t, aspect); return }
        if (l.is3d || l.type == LayerType.MODEL) {
            val cam = Xf.cameraAbove(s, l, t)
            vpCur = if (sub) FloatArray(16).also { Xf.viewProj(s, t, aspect, cam, it) }
                    else camVp.getOrPut(cam?.id ?: -1) { FloatArray(16).also { Xf.viewProj(s, t, aspect, cam, it) } }
            fovCur = Xf.fov(s, t, cam)
        } else { vpCur = vp2; fovCur = s.fov }
        GLES20.glEnable(GLES20.GL_BLEND)
        setBlend(l.blend)
        try {
            when (l.type) {
                LayerType.ADJUST -> drawAdjust(l, s, t, viewW, viewH)
                LayerType.PARTICLES -> drawParticles(l, s, t, aspect)
                LayerType.MODEL -> drawModel(l, s, t, aspect)
                else -> drawQuadLayer(l, s, t)
            }
        } catch (e: Exception) { }
    }

    // ------------------------------------------------------------------ groups: effects and masks

    /** Motion blur: draws the layer at several moments inside the shutter window and averages them. Works with particles. */
    private fun drawBlurred(l: Layer, s: Scene, t: Float, aspect: Float) {
        val lt = l.localTime(t)
        val n = l.p("mbSamples", lt).toInt().coerceIn(3, 16)
        val window = 0.5f / max(Editor.project.fps, 1) * l.p("mbAmount", lt).coerceIn(0f, 4f)
        var fw = viewW
        var fh = viewH
        val big = max(fw, fh)
        if (big > 2048) { fw = fw * 2048 / big; fh = fh * 2048 / big }
        fw = max(fw, 2); fh = max(fh, 2)
        val acc = fbo(fw, fh, 50)
        val smp = fbo(fw, fh, 9)
        val saved = outFbo
        val sw = viewW
        val sh = viewH
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, acc.id)
        GLES20.glViewport(0, 0, fw, fh)
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        for (i in 0 until n) {
            var tt = t + window * (i / (n - 1f) - 0.5f)
            if (l.mbStutter) { val fp = max(Editor.project.fps, 1).toFloat(); tt = Math.round(tt * fp) / fp }
            renderInto(smp, fw, fh, s, tt, aspect, listOf(l), true)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, acc.id)
            GLES20.glViewport(0, 0, fw, fh)
            if (l.mbRgb) {
                val u = i / (n - 1f)
                val wr = 2f * (1f - u); val wb = 2f * u
                GLES20.glColorMask(true, false, false, false); drawCopy(smp.tex, wr / n, ident, true)
                GLES20.glColorMask(false, true, false, false); drawCopy(smp.tex, 1f / n, ident, true)
                GLES20.glColorMask(false, false, true, false); drawCopy(smp.tex, wb / n, ident, true)
                GLES20.glColorMask(false, false, false, true); drawCopy(smp.tex, 1f / n, ident, true)
                GLES20.glColorMask(true, true, true, true)
            } else drawCopy(smp.tex, 1f / n, ident, true)
        }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, saved)
        GLES20.glViewport(0, 0, sw, sh)
        drawCopy(acc.tex, 1f, ident, false)
    }

    private fun groupFx(g: Layer): List<Fx> {
        val out = ArrayList<Fx>()
        for (id in g.fx) { val d = Registry.get(id); if (d != null && d.kind == 0 && g.fxOn(id)) out.add(Fx(id, d)) }
        return out
    }

    private fun groupActive(g: Layer, s: Scene): Boolean = s.layers.any { it.parentId == g.id }

    private fun renderInto(f: Fbo, fw: Int, fh: Int, s: Scene, t: Float, aspect: Float, layers: List<Layer>, sub: Boolean = false) {
        val saved = outFbo
        val sw = viewW
        val sh = viewH
        outFbo = f.id; viewW = fw; viewH = fh
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, f.id)
        GLES20.glViewport(0, 0, fw, fh)
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        GLES20.glDepthMask(true)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        for (c in layers) drawOne(c, s, t, aspect, sub)
        outFbo = saved; viewW = sw; viewH = sh
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, saved)
        GLES20.glViewport(0, 0, sw, sh)
    }

    /** Renders a group's children into a buffer, applies the mask (top layer masks the ones beneath) and the group's effects. */
    private fun drawGroup(g: Layer, s: Scene, t: Float, w: Int, h: Int, aspect: Float) {
        val kids = s.layers.filter { it.parentId == g.id }
        if (kids.isEmpty()) return
        val lt = g.localTime(t)
        var fw = w
        var fh = h
        val big = max(fw, fh)
        if (big > 2048) { fw = fw * 2048 / big; fh = fh * 2048 / big }
        fw = max(fw, 2); fh = max(fh, 2)
        val maskLayer = if (g.mask != 0 && kids.size >= 2) kids.last() else null
        val pc = fbo(fw, fh, 2)
        renderInto(pc, fw, fh, s, t, aspect, kids.filter { it !== maskLayer })
        var tex = pc.tex
        if (maskLayer != null) {
            val pm = fbo(fw, fh, 6)
            renderInto(pm, fw, fh, s, t, aspect, listOf(maskLayer))
            val po = fbo(fw, fh, 7)
            GLES20.glDisable(GLES20.GL_BLEND)
            passTo(maskProg, po, fw, fh) {
                bindTex(0, pc.tex, maskProg, "uTex")
                bindTex(1, pm.tex, maskProg, "uMask")
                GLES20.glUniform1f(GLES20.glGetUniformLocation(maskProg, "uMode"), g.mask.toFloat())
            }
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, outFbo)
            GLES20.glViewport(0, 0, viewW, viewH)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            tex = po.tex
        }
        val effs = groupFx(g)
        val res = if (effs.isNotEmpty()) runEffects(g, s, lt, Src(tex, fw, fh, false), effs, null) else tex
        val gm = FloatArray(16)
        Xf.ndcLocal(g, lt, aspect, gm)
        drawCopy(res, g.p("opacity", lt).coerceIn(0f, 1f), gm)
    }

    private fun bindTex(unit: Int, tex: Int, prog: Int, name: String) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unit)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, name), unit)
    }

    private fun passTo(prog: Int, target: Fbo, tw: Int, th: Int, setup: () -> Unit) {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, target.id)
        GLES20.glViewport(0, 0, tw, th)
        GLES20.glUseProgram(prog)
        val aPos = GLES20.glGetAttribLocation(prog, "aPos")
        val aUV = GLES20.glGetAttribLocation(prog, "aUV")
        bindPass(aPos, aUV)
        setup()
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aUV)
    }

    private fun loc(prog: Int, name: String): Int = GLES20.glGetUniformLocation(prog, name)

    /**
     * Deep Glow. Bright pass, a 13-tap downsample chain (8 octaves) and a tent upsample chain.
     * Every octave carries equal energy, which gives the inverse-square falloff of real light;
     * Falloff = 1 is physically accurate, lower is a longer tail, higher is tighter.
     * Intermediate buffers are half float when the GPU allows, and the result is dithered, so there is no banding.
     */
    private fun bloom(l: Layer, lt: Float, srcTex: Int, fw: Int, fh: Int, out: Fbo, entry: String = "deepglow") {
        fun pv(n: String) = l.p(entry + "__" + n, lt)
        val th = pv("threshold")
        val knee = pv("softness") * 0.5f + 0.001f
        val radius = pv("radius")
        val falloff = pv("falloff")
        val n = 8
        val lw = IntArray(n) { max(fw shr (it + 1), 2) }
        val lh = IntArray(n) { max(fh shr (it + 1), 2) }
        val spread = 0.7f + radius * 1.1f
        val down = ArrayList<Fbo>()
        val d0 = fbo(lw[0], lh[0], 30)
        passTo(brightProg, d0, lw[0], lh[0]) {
            bindTex(0, srcTex, brightProg, "uTex")
            GLES20.glUniform1f(loc(brightProg, "uTh"), th)
            GLES20.glUniform1f(loc(brightProg, "uKnee"), knee)
        }
        down.add(d0)
        for (i in 1 until n) {
            val di = fbo(lw[i], lh[i], 30 + i)
            val from = down[i - 1]
            val sw = lw[i - 1]
            val sh = lh[i - 1]
            passTo(downProg, di, lw[i], lh[i]) {
                bindTex(0, from.tex, downProg, "uTex")
                GLES20.glUniform2f(loc(downProg, "uTexel"), spread / sw, spread / sh)
            }
            down.add(di)
        }
        val scatter = Math.pow(2.0, 2.0 - 2.0 * falloff).toFloat().coerceIn(0.2f, 1.5f)
        var up = down[n - 1]
        for (i in n - 2 downTo 0) {
            val ui = fbo(lw[i], lh[i], 40 + i)
            val coarse = up
            val fine = down[i]
            val cw = lw[i + 1]
            val ch = lh[i + 1]
            passTo(upProg, ui, lw[i], lh[i]) {
                bindTex(0, fine.tex, upProg, "uFine")
                bindTex(1, coarse.tex, upProg, "uCoarse")
                GLES20.glUniform2f(loc(upProg, "uTexel"), spread / cw, spread / ch)
                GLES20.glUniform1f(loc(upProg, "uScatter"), scatter)
            }
            up = ui
        }
        val glow = up
        passTo(bloomProg, out, fw, fh) {
            bindTex(0, srcTex, bloomProg, "uSrc")
            bindTex(1, glow.tex, bloomProg, "uGlow")
            GLES20.glUniform2f(loc(bloomProg, "uTexel"), spread / lw[0], spread / lh[0])
            GLES20.glUniform1f(loc(bloomProg, "uExp"), pv("exposure") * 0.2f)
            GLES20.glUniform3f(loc(bloomProg, "uTint"), pv("tint_r"), pv("tint_g"), pv("tint_b"))
            GLES20.glUniform1f(loc(bloomProg, "uTintAmt"), pv("tintAmt"))
        }
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
    }

    private fun setBlend(b: Int) {
        when (b) {
            1 -> GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE)
            2 -> GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_COLOR)
            3 -> GLES20.glBlendFunc(GLES20.GL_DST_COLOR, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            else -> GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        }
    }

    // ------------------------------------------------------------------ 2D quad layers

    private fun drawQuadLayer(l: Layer, s: Scene, t: Float, skipFx: Boolean = false) {
        val lt = l.localTime(t)
        if (!skipFx && l.fxOn("particles") && l.fx.any { id -> val ed = Registry.get(id); ed != null && ed.kind == 0 && l.fxOn(id) }) { drawParticleComposite(l, s, t, lt); return }
        if (l.fxOn("particles") && l.p("pShowSrc", lt) < 0.5f) { drawParticles(l, s, t, viewW.toFloat() / viewH); return }
        var src = sourceFor(l, lt) ?: return
        if (!skipFx && l.fxOn("timeslice")) src = timeSliceSrc(l, lt, src)
        val qh = LayerBitmaps.baseHeight(l)
        val qw = qh * l.texAspect
        Xf.world(s, l, t, qw, qh, base)
        val vs = videos[l.id]
        val effs = ArrayList<Fx>()
        if (!skipFx) for (id in l.fx) { val d = Registry.get(id); if (d != null && d.kind == 0 && l.fxOn(id)) effs.add(Fx(id, d)) }
        var tex = src.tex
        var oes = src.oes
        var padS = 1f
        if (effs.isNotEmpty()) {
            tex = runEffects(l, s, lt, src, effs, vs?.texMat, if (effs.any { it.def.id == "deepglow" }) 0.25f else if (effs.any { it.def.id in PAD_IDS }) 0.18f else 0f)
            padS = lastPad
            oes = false
            GLES20.glEnable(GLES20.GL_BLEND)
            setBlend(l.blend)
        }
        val prog = if (oes) fOes else f2d
        GLES20.glUseProgram(prog)
        val aPos = GLES20.glGetAttribLocation(prog, "aPos")
        val aUV = GLES20.glGetAttribLocation(prog, "aUV")
        quad.position(0)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(aPos)
        quad.position(2)
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(aUV)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(if (oes) GLES11Ext.GL_TEXTURE_EXTERNAL_OES else GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uOpacity"), l.p("opacity", lt).coerceIn(0f, 1f))
        if (oes) GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uTexMat"), 1, false, vs?.texMat ?: ident, 0)
        val uMVP = GLES20.glGetUniformLocation(prog, "uMVP")
        val vp = vpCur
        // 3D layers use the depth buffer so nearer layers hide farther ones instead of showing through
        val depth3d = l.is3d
        if (depth3d) {
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            GLES20.glDepthFunc(GLES20.GL_LEQUAL)
            GLES20.glDepthMask(l.p("opacity", lt) >= 0.98f)
            Matrix.translateM(base, 0, 0f, 0f, s.layers.indexOf(l) * 0.0006f)
        }

        if (l.fxOn("tile")) {
            val nx = l.p("tileNX", lt).roundToInt().coerceIn(0, 6)
            val ny = l.p("tileNY", lt).roundToInt().coerceIn(0, 6)
            val gap = l.p("tileGap", lt)
            val sx = qw * (1f + gap)
            val sy = qh * (1f + gap)
            val px = l.p("tileX", lt)
            val py = l.p("tileY", lt)
            val fx0 = floor(px)
            val fy0 = floor(py)
            val mirror = l.p("tileMirror", lt) >= 0.5f
            for (j in -ny - 1..ny) for (i in -nx - 1..nx) {
                val ci = i + fx0.toInt()
                val cj = j + fy0.toInt()
                val flipX = mirror && (ci and 1) == 1
                val flipY = mirror && (cj and 1) == 1
                drawQuad(uMVP, vp, (i + px - fx0) * sx, (j + py - fy0) * sy, (if (flipX) -qw else qw) * padS, (if (flipY) -qh else qh) * padS)
            }
        } else drawQuad(uMVP, vp, 0f, 0f, qw * padS, qh * padS)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aUV)
        if (depth3d) { GLES20.glDisable(GLES20.GL_DEPTH_TEST); GLES20.glDepthMask(true) }
        if (l.fxOn("particles")) drawParticles(l, s, t, viewW.toFloat() / viewH)
    }

    private fun drawQuad(uMVP: Int, vp: FloatArray, ox: Float, oy: Float, sx: Float, sy: Float) {
        System.arraycopy(base, 0, model, 0, 16)
        Matrix.translateM(model, 0, ox, oy, 0f)
        Matrix.scaleM(model, 0, sx, sy, 1f)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    // ------------------------------------------------------------------ adjustment layers

    /** Runs the layer's effects on everything drawn so far (the layers below it). */
    private fun drawAdjust(l: Layer, s: Scene, t: Float, w: Int, h: Int) {
        val lt = l.localTime(t)
        val effs = ArrayList<Fx>()
        for (id in l.fx) { val d = Registry.get(id); if (d != null && d.kind == 0 && l.fxOn(id)) effs.add(Fx(id, d)) }
        if (effs.isEmpty()) return
        if (adjTex == 0 || adjW != w || adjH != h) {
            if (adjTex != 0) GLES20.glDeleteTextures(1, intArrayOf(adjTex), 0)
            val ids = IntArray(1)
            GLES20.glGenTextures(1, ids, 0)
            adjTex = ids[0]
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, adjTex)
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
            texParams()
            adjW = w; adjH = h
        }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, outFbo)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, adjTex)
        GLES20.glCopyTexSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, 0, 0, w, h)
        val res = runEffects(l, s, lt, Src(adjTex, w, h, false), effs, null)
        val op = l.p("opacity", lt).coerceIn(0f, 1f)
        if (op >= 0.99f) {
            val bg = s.bg
            GLES20.glClearColor(Color.red(bg) / 255f, Color.green(bg) / 255f, Color.blue(bg) / 255f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        }
        // the adjustment layer's own transform (position, scale, rotation, Layer Shake, Swing) moves the processed image
        Xf.localModel(l, lt, 2f, 2f, base)
        val aspect = w.toFloat() / h
        val m1 = FloatArray(16)
        Matrix.setIdentityM(m1, 0)
        Matrix.scaleM(m1, 0, 1f / aspect, 1f, 1f)
        val m2 = FloatArray(16)
        Matrix.multiplyMM(m2, 0, m1, 0, base, 0)
        Matrix.scaleM(m2, 0, aspect, 1f, 1f)
        drawCopy(res, op, m2)
    }

    private fun drawCopy(tex: Int, opacity: Float, m: FloatArray, additive: Boolean = false) {
        GLES20.glEnable(GLES20.GL_BLEND)
        if (additive) GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE) else GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUseProgram(copyProg)
        val aPos = GLES20.glGetAttribLocation(copyProg, "aPos")
        val aUV = GLES20.glGetAttribLocation(copyProg, "aUV")
        bindPass(aPos, aUV)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(copyProg, "uTex"), 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(copyProg, "uOpacity"), opacity)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(copyProg, "uM"), 1, false, m, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aUV)
    }

    /** Layers with Particle World plus other effects: render everything into a buffer, run the effects, then composite. */
    private fun drawParticleComposite(l: Layer, s: Scene, t: Float, lt: Float) {
        var fw = viewW
        var fh = viewH
        val big = max(fw, fh)
        if (big > 2048) { fw = fw * 2048 / big; fh = fh * 2048 / big }
        fw = max(fw, 2); fh = max(fh, 2)
        val pf = fbo(fw, fh, 8)
        val saved = outFbo
        val sw = viewW
        val sh = viewH
        outFbo = pf.id
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, pf.id)
        GLES20.glViewport(0, 0, fw, fh)
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glEnable(GLES20.GL_BLEND)
        setBlend(0)
        viewW = fw; viewH = fh
        drawQuadLayer(l, s, t, true)
        viewW = sw; viewH = sh
        outFbo = saved
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, saved)
        GLES20.glViewport(0, 0, sw, sh)
        val effs = ArrayList<Fx>()
        for (id in l.fx) { val d = Registry.get(id); if (d != null && d.kind == 0 && l.fxOn(id)) effs.add(Fx(id, d)) }
        val res = runEffects(l, s, lt, Src(pf.tex, fw, fh, false), effs, null)
        drawCopy(res, l.p("opacity", lt).coerceIn(0f, 1f), ident)
    }

    // ------------------------------------------------------------------ effect passes

    private fun runEffects(l: Layer, s: Scene, lt: Float, src: Src, effs: List<Fx>, texMat: FloatArray?, padQ: Float = 0f): Int {
        val padS = if (padQ > 0f) 1f / (1f - 2f * padQ) else 1f
        lastPad = padS
        var fw = (src.w * padS).toInt()
        var fh = (src.h * padS).toInt()
        val big = max(fw, fh)
        val capPx = if (padQ > 0f) 3072 else 2048
        if (big > capPx) { fw = fw * capPx / big; fh = fh * capPx / big }
        fw = max(fw, 2); fh = max(fh, 2)
        val fa = fbo(fw, fh, 0)
        val fbb = fbo(fw, fh, 1)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glViewport(0, 0, fw, fh)
        var curTex = src.tex
        var cur: Fbo? = null
        if (src.oes || padQ > 0f) {
            val prog = if (src.oes) blit else padProg
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fa.id)
            GLES20.glClearColor(0f, 0f, 0f, 0f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUseProgram(prog)
            val aPos = GLES20.glGetAttribLocation(prog, "aPos")
            val aUV = GLES20.glGetAttribLocation(prog, "aUV")
            bindPass(aPos, aUV)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(if (src.oes) GLES11Ext.GL_TEXTURE_EXTERNAL_OES else GLES20.GL_TEXTURE_2D, src.tex)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0)
            if (src.oes) GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uTexMat"), 1, false, texMat ?: ident, 0)
            GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uQ"), padQ)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aUV)
            cur = fa
            curTex = fa.tex
        }
        for (fx in effs) {
            val d = fx.def
            val entry = fx.entry
            if (d.id == "deepglow") {
                val bo = if (cur === fa) fbb else fa
                bloom(l, lt, curTex, fw, fh, bo, entry)
                cur = bo
                curTex = bo.tex
                continue
            }
            val ps = passFor(d) ?: continue
            val out = if (cur === fa) fbb else fa
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, out.id)
            GLES20.glViewport(0, 0, fw, fh)
            GLES20.glClearColor(0f, 0f, 0f, 0f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUseProgram(ps.p)
            bindPass(ps.aPos, ps.aUV)
            var has0 = 0f
            var has1 = 0f
            for ((i, nm) in d.inputs.withIndex()) {
                val rid = l.inputs[entry + ":" + nm]
                val ref = if (rid != null) s.layers.firstOrNull { it.id == rid && it.id != l.id } else null
                val ok = ref != null && ref.isRenderable() && ref.type != LayerType.VIDEO && ref.type != LayerType.PARTICLES && ref.type != LayerType.MODEL
                val rs = if (ok) sourceFor(ref!!, lt) else null
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + 1 + i)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, rs?.tex ?: curTex)
                GLES20.glUniform1i(if (i == 0) ps.uIn0 else ps.uIn1, 1 + i)
                if (rs != null) { if (i == 0) has0 = 1f else has1 = 1f }
            }
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, curTex)
            GLES20.glUniform1i(ps.uSrc, 0)
            GLES20.glUniform1f(ps.uHas0, has0)
            GLES20.glUniform1f(ps.uHas1, has1)
            GLES20.glUniform1f(ps.uTime, lt)
            GLES20.glUniform2f(ps.uRes, fw.toFloat(), fh.toFloat())
            for ((i, pd) in d.props.withIndex()) GLES20.glUniform1f(ps.params[i], l.p(l.pkey(entry, pd), lt))
            for ((i, cp) in d.colors.withIndex()) {
                val ck = l.ckey(entry, cp)
                GLES20.glUniform4f(ps.colorLocs[i], l.p(ck + "_r", lt), l.p(ck + "_g", lt), l.p(ck + "_b", lt), l.p(ck + "_a", lt))
            }
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(ps.aPos); GLES20.glDisableVertexAttribArray(ps.aUV)
            cur = out
            curTex = out.tex
        }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, outFbo)
        GLES20.glViewport(0, 0, viewW, viewH)
        return curTex
    }

    private fun bindPass(aPos: Int, aUV: Int) {
        passQuad.position(0)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, passQuad)
        GLES20.glEnableVertexAttribArray(aPos)
        passQuad.position(2)
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 16, passQuad)
        GLES20.glEnableVertexAttribArray(aUV)
    }

    private fun passFor(d: EffectDef): Pass? {
        val key = d.id + "#" + d.code.hashCode() + "#" + d.props.size
        if (passes.containsKey(key)) return passes[key]
        var pass: Pass? = null
        try {
            val p = build(PASS_VS, Registry.fragmentFor(d))
            pass = Pass(p, GLES20.glGetAttribLocation(p, "aPos"), GLES20.glGetAttribLocation(p, "aUV"),
                GLES20.glGetUniformLocation(p, "uSrc"), GLES20.glGetUniformLocation(p, "uIn0"), GLES20.glGetUniformLocation(p, "uIn1"),
                GLES20.glGetUniformLocation(p, "uHas0"), GLES20.glGetUniformLocation(p, "uHas1"),
                GLES20.glGetUniformLocation(p, "uTime"), GLES20.glGetUniformLocation(p, "uRes"),
                IntArray(d.props.size) { GLES20.glGetUniformLocation(p, d.props[it].name) },
                IntArray(d.colors.size) { GLES20.glGetUniformLocation(p, d.colors[it].name) })
            Registry.errors.remove(d.id)
        } catch (e: RuntimeException) {
            Registry.errors[d.id] = e.message ?: "shader error"
        }
        passes[key] = pass
        return pass
    }

    private fun fbo(w: Int, h: Int, slot: Int): Fbo {
        val key = "$w x $h #$slot"
        fbos[key]?.let { return it }
        if (fbos.size > 120) {
            for (f in fbos.values) {
                GLES20.glDeleteFramebuffers(1, intArrayOf(f.id), 0); GLES20.glDeleteTextures(1, intArrayOf(f.tex), 0)
                if (f.rb != 0) GLES20.glDeleteRenderbuffers(1, intArrayOf(f.rb), 0)
            }
            fbos.clear()
        }
        var hdr = slot >= 30 && halfOk
        var made: Fbo? = null
        for (attempt in 0 until 2) {
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, if (hdr) 0x8D61 else GLES20.GL_UNSIGNED_BYTE, null)
            texParams()
            val f = IntArray(1)
            GLES20.glGenFramebuffers(1, f, 0)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, f[0])
            GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, t[0], 0)
            var rbId = 0
            if (slot == 2 || slot == 6 || slot == 9) {
                val r = IntArray(1)
                GLES20.glGenRenderbuffers(1, r, 0)
                GLES20.glBindRenderbuffer(GLES20.GL_RENDERBUFFER, r[0])
                GLES20.glRenderbufferStorage(GLES20.GL_RENDERBUFFER, GLES20.GL_DEPTH_COMPONENT16, w, h)
                GLES20.glFramebufferRenderbuffer(GLES20.GL_FRAMEBUFFER, GLES20.GL_DEPTH_ATTACHMENT, GLES20.GL_RENDERBUFFER, r[0])
                rbId = r[0]
            }
            if (!hdr || GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER) == GLES20.GL_FRAMEBUFFER_COMPLETE) { made = Fbo(f[0], t[0], rbId); break }
            GLES20.glDeleteFramebuffers(1, f, 0)
            GLES20.glDeleteTextures(1, t, 0)
            hdr = false
            halfOk = false
        }
        val fo = made!!
        fbos[key] = fo
        return fo
    }

    private fun texParams() {
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    // ------------------------------------------------------------------ sources

    private fun sourceFor(l: Layer, lt: Float): Src? {
        if (l.type == LayerType.VIDEO) {
            val path = l.imagePath ?: return null
            val vs = videos.getOrPut(l.id) { VideoSource(path).also { it.init() } }
            if (vs.failed) return null
            val srcT = (lt - l.start + l.srcOffset).coerceAtLeast(0f)
            if (l.fxOn("remap") && l.p("remapInterp", lt) >= 0.5f) {
                val blended = blendedVideo(l, vs, path, srcT)
                if (blended != null) { l.texAspect = vs.w.toFloat() / vs.h.toFloat(); return blended }
            }
            vs.seek((srcT * 1_000_000f).toLong())
            l.texAspect = vs.w.toFloat() / vs.h.toFloat()
            return Src(vs.texId, vs.w, vs.h, true)
        }
        val e = texFor(l, lt)
        return Src(e.id, e.w, e.h, false)
    }

    private fun blitOes(v: VideoSource) {
        val prog = blit
        GLES20.glUseProgram(prog)
        val aPos = GLES20.glGetAttribLocation(prog, "aPos")
        val aUV = GLES20.glGetAttribLocation(prog, "aUV")
        bindPass(aPos, aUV)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, v.texId)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uTexMat"), 1, false, v.texMat, 0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uQ"), 0f)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aUV)
    }

    /** TimeSlice: each slice of the picture is taken from the layer at a different moment. */
    private fun timeSliceSrc(l: Layer, lt: Float, first: Src): Src {
        val n = l.p("tsCount", lt).toInt().coerceIn(2, 48)
        val dir = l.p("tsDir", lt).toInt().coerceIn(0, 3)
        val offs = l.p("tsOffset", lt) / max(Editor.project.fps, 1)
        var fw = first.w
        var fh = first.h
        val big = max(fw, fh)
        if (big > 2048) { fw = fw * 2048 / big; fh = fh * 2048 / big }
        fw = max(fw, 2); fh = max(fh, 2)
        val comp = fbo(fw, fh, 61)
        val saved = outFbo
        val sw = viewW
        val sh = viewH
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, comp.id)
        GLES20.glViewport(0, 0, fw, fh)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glEnable(GLES20.GL_SCISSOR_TEST)
        for (i in 0 until n) {
            val sr = if (i == 0) first else (sourceFor(l, lt - offs * i) ?: continue)
            val a = i
            val x0: Int; val y0: Int; val w: Int; val h: Int
            when (dir) {
                0 -> { x0 = a * fw / n; w = (a + 1) * fw / n - x0; y0 = 0; h = fh }
                1 -> { val b = n - 1 - a; x0 = b * fw / n; w = (b + 1) * fw / n - x0; y0 = 0; h = fh }
                2 -> { y0 = fh - (a + 1) * fh / n; h = fh - a * fh / n - y0; x0 = 0; w = fw }
                else -> { y0 = a * fh / n; h = (a + 1) * fh / n - y0; x0 = 0; w = fw }
            }
            GLES20.glScissor(x0, y0, max(w, 1), max(h, 1))
            GLES20.glDisable(GLES20.GL_BLEND)
            if (sr.oes) { val v = videos[l.id]; if (v != null) blitOes(v) }
            else drawCopy(sr.tex, 1f, ident, false)
        }
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, saved)
        GLES20.glViewport(0, 0, sw, sh)
        sourceFor(l, lt)
        return Src(comp.tex, fw, fh, false)
    }

    /** Frame blend: mixes the two source frames around the requested time into an RGBA buffer. */
    private fun blendedVideo(l: Layer, va: VideoSource, path: String, srcT: Float): Src? {
        val vb = videosB.getOrPut(l.id) { VideoSource(path).also { it.init() } }
        if (vb.failed) return null
        val fd = max(va.frameSec(), 0.001f)
        val idx = Math.floor((srcT / fd).toDouble()).toFloat()
        val f = srcT / fd - idx
        va.seek((idx * fd * 1_000_000f).toLong())
        vb.seek(((idx + 1f) * fd * 1_000_000f).toLong())
        var fw = va.w
        var fh = va.h
        val big = max(fw, fh)
        if (big > 2048) { fw = fw * 2048 / big; fh = fh * 2048 / big }
        fw = max(fw, 2); fh = max(fh, 2)
        val out = fbo(fw, fh, 60)
        val saved = outFbo
        val sw = viewW
        val sh = viewH
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, out.id)
        GLES20.glViewport(0, 0, fw, fh)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        for (pass in 0..1) {
            val v = if (pass == 0) va else vb
            if (pass == 0) GLES20.glDisable(GLES20.GL_BLEND)
            else { GLES20.glEnable(GLES20.GL_BLEND); GLES20.glBlendColor(0f, 0f, 0f, f); GLES20.glBlendFunc(GLES20.GL_CONSTANT_ALPHA, GLES20.GL_ONE_MINUS_CONSTANT_ALPHA) }
            val prog = blit
            GLES20.glUseProgram(prog)
            val aPos = GLES20.glGetAttribLocation(prog, "aPos")
            val aUV = GLES20.glGetAttribLocation(prog, "aUV")
            bindPass(aPos, aUV)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, v.texId)
            GLES20.glUniform1i(GLES20.glGetUniformLocation(prog, "uTex"), 0)
            GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(prog, "uTexMat"), 1, false, v.texMat, 0)
            GLES20.glUniform1f(GLES20.glGetUniformLocation(prog, "uQ"), 0f)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aUV)
        }
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, saved)
        GLES20.glViewport(0, 0, sw, sh)
        return Src(out.tex, fw, fh, false)
    }

    private fun texFor(l: Layer, lt: Float): TexEntry {
        val key = l.texKey(lt)
        val old = texs[l.id]
        if (old != null && old.key == key) return old
        if (old != null) GLES20.glDeleteTextures(1, intArrayOf(old.id), 0)
        val bmp = LayerBitmaps.make(l, lt)
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        texParams()
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        l.texAspect = bmp.width.toFloat() / bmp.height.toFloat()
        val e = TexEntry(ids[0], key, bmp.width, bmp.height)
        bmp.recycle()
        texs[l.id] = e
        return e
    }

    // ------------------------------------------------------------------ particles

    private fun drawParticles(l: Layer, s: Scene, t: Float, aspect: Float) {
        val lt = l.localTime(t)
        val n = Particles.build(l, lt, pArr)
        if (n == 0) return
        pBuf.clear()
        pBuf.put(pArr, 0, n * 6 * Particles.FLOATS)
        Xf.world(s, l, t, 1f, 1f, base)
        Matrix.multiplyMM(mvp, 0, vpCur, 0, base, 0)
        val fov = fovCur
        val f = (1.0 / tan(Math.toRadians(fov / 2.0))).toFloat()
        GLES20.glUseProgram(partProg)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(partProg, "uMVP"), 1, false, mvp, 0)
        GLES20.glUniform2f(GLES20.glGetUniformLocation(partProg, "uPS"), f / aspect, f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(partProg, "uSizeScale"), l.p("scale", lt))
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, sprites[l.p("pType", lt).toInt().coerceIn(0, 3)])
        GLES20.glUniform1i(GLES20.glGetUniformLocation(partProg, "uTex"), 0)
        if (l.p("pAdd", lt) < 0.5f) GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE)
        else GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        val stride = Particles.FLOATS * 4
        val names = arrayOf("aCenter", "aCorner", "aUV", "aColor")
        val sizes = intArrayOf(3, 2, 2, 4)
        val offs = intArrayOf(0, 3, 5, 7)
        val locs = IntArray(4)
        for (i in 0 until 4) {
            locs[i] = GLES20.glGetAttribLocation(partProg, names[i])
            pBuf.position(offs[i])
            GLES20.glVertexAttribPointer(locs[i], sizes[i], GLES20.GL_FLOAT, false, stride, pBuf)
            GLES20.glEnableVertexAttribArray(locs[i])
        }
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, n * 6)
        for (i in 0 until 4) GLES20.glDisableVertexAttribArray(locs[i])
        pBuf.position(0)
    }

    private fun makeSprites() {
        val sz = 64
        for (k in 0 until 4) {
            val bmp = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = Color.WHITE
            val h = sz / 2f
            when (k) {
                0 -> { p.shader = RadialGradient(h, h, h, intArrayOf(0xFFFFFFFF.toInt(), 0x88FFFFFF.toInt(), 0x00FFFFFF), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP); c.drawCircle(h, h, h, p) }
                1 -> {
                    val path = Path()
                    for (i in 0 until 10) {
                        val a = -Math.PI / 2 + i * Math.PI / 5
                        val r = if (i % 2 == 0) h * 0.9f else h * 0.38f
                        val x = (h + r * cos(a)).toFloat(); val y = (h + r * sin(a)).toFloat()
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    path.close()
                    p.maskFilter = BlurMaskFilter(2f, BlurMaskFilter.Blur.NORMAL)
                    c.drawPath(path, p)
                }
                2 -> { p.shader = RadialGradient(h, h, h, intArrayOf(0xFFFFFFFF.toInt(), 0x00FFFFFF), floatArrayOf(0.2f, 1f), Shader.TileMode.CLAMP); c.save(); c.scale(0.12f, 1f, h, h); c.drawCircle(h, h, h, p); c.restore() }
                else -> c.drawCircle(h, h, h * 0.9f, p)
            }
            val ids = IntArray(1)
            GLES20.glGenTextures(1, ids, 0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
            texParams()
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
            bmp.recycle()
            sprites[k] = ids[0]
        }
    }

    // ------------------------------------------------------------------ 3D models

    private fun drawModel(l: Layer, s: Scene, t: Float, aspect: Float) {
        val path = l.imagePath ?: return
        val m = models.getOrPut(l.id) { GlbModel(path).also { it.load() } }
        if (!m.ok) return
        val lt = l.localTime(t)
        Xf.world(s, l, t, 1f, 1f, base)
        Matrix.multiplyMM(mvp, 0, vpCur, 0, base, 0)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(true)
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(modelProg)
        val uMVP = GLES20.glGetUniformLocation(modelProg, "uMVP")
        val uNM = GLES20.glGetUniformLocation(modelProg, "uNM")
        val uColor = GLES20.glGetUniformLocation(modelProg, "uColor")
        val uHasTex = GLES20.glGetUniformLocation(modelProg, "uHasTex")
        val aPos = GLES20.glGetAttribLocation(modelProg, "aPos")
        val aNrm = GLES20.glGetAttribLocation(modelProg, "aNrm")
        val aUV = GLES20.glGetAttribLocation(modelProg, "aUV")
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(uNM, 1, false, base, 0)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(modelProg, "uTex"), 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        val op = l.p("opacity", lt)
        for (pr in m.prims) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, pr.vbo)
            GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 32, 0)
            GLES20.glEnableVertexAttribArray(aPos)
            GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, 32, 12)
            GLES20.glEnableVertexAttribArray(aNrm)
            GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 32, 24)
            GLES20.glEnableVertexAttribArray(aUV)
            GLES20.glUniform4f(uColor, pr.color[0] * op, pr.color[1] * op, pr.color[2] * op, 1f)
            if (pr.tex != 0) { GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, pr.tex); GLES20.glUniform1f(uHasTex, 1f) } else GLES20.glUniform1f(uHasTex, 0f)
            if (pr.indexType != 0) {
                GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, pr.ibo)
                GLES20.glDrawElements(GLES20.GL_TRIANGLES, pr.count, pr.indexType, 0)
            } else GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, pr.count)
        }
        GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aNrm); GLES20.glDisableVertexAttribArray(aUV)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
    }

    // ------------------------------------------------------------------ shaders

    private fun buildSafe(vs: String, fs: String): Int =
        try { build(vs, fs) } catch (e: RuntimeException) { Registry.errors["__gl"] = (e.message ?: "shader error").take(200); 0 }

    private fun build(vs: String, fs: String): Int {
        fun sh(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) {
                val log = GLES20.glGetShaderInfoLog(s)
                GLES20.glDeleteShader(s)
                throw RuntimeException(log)
            }
            return s
        }
        val v = sh(GLES20.GL_VERTEX_SHADER, vs)
        val f = sh(GLES20.GL_FRAGMENT_SHADER, fs)
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, v)
        GLES20.glAttachShader(p, f)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Link error: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    companion object {
        private val PAD_IDS = setOf("deepglow", "lightsweep", "contour", "blur", "radialblur", "blurmo", "streaks")

        private const val VS = """
            uniform mat4 uMVP;
            attribute vec2 aPos;
            attribute vec2 aUV;
            varying vec2 vUV;
            void main() { vUV = aUV; gl_Position = uMVP * vec4(aPos, 0.0, 1.0); }
        """
        private const val FS2D = """
            precision mediump float;
            varying vec2 vUV;
            uniform sampler2D uTex;
            uniform float uOpacity;
            void main() {
                vec4 c = texture2D(uTex, vUV);
                if (c.a < 0.03) discard;
                gl_FragColor = c * uOpacity;
            }
        """
        private const val FSOES = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vUV;
            uniform samplerExternalOES uTex;
            uniform mat4 uTexMat;
            uniform float uOpacity;
            void main() {
                vec2 uv = (uTexMat * vec4(vUV.x, 1.0 - vUV.y, 0.0, 1.0)).xy;
                vec4 c = texture2D(uTex, uv);
                if (c.a < 0.03) discard;
                gl_FragColor = c * uOpacity;
            }
        """
        private const val PASS_VS = """
            attribute vec2 aPos;
            attribute vec2 aUV;
            varying vec2 vUV;
            void main() { vUV = aUV; gl_Position = vec4(aPos, 0.0, 1.0); }
        """
        private const val BRIGHT_FS = """
            precision mediump float;
            varying vec2 vUV;
            uniform sampler2D uTex;
            uniform float uTh;
            uniform float uKnee;
            void main() {
                vec4 c = texture2D(uTex, vUV);
                float l = max(max(c.r, c.g), c.b);
                float rq = clamp(l - uTh + uKnee, 0.0, 2.0 * uKnee);
                rq = rq * rq / (4.0 * uKnee + 0.00001);
                float w = max(rq, l - uTh) / max(l, 0.0001);
                gl_FragColor = c * w;
            }
        """
        private const val BLUR_FS = """
            precision mediump float;
            varying vec2 vUV;
            uniform sampler2D uTex;
            uniform vec2 uDir;
            void main() {
                vec4 s = texture2D(uTex, vUV) * 0.2270270270;
                s += texture2D(uTex, vUV + uDir * 1.3846153846) * 0.3162162162;
                s += texture2D(uTex, vUV - uDir * 1.3846153846) * 0.3162162162;
                s += texture2D(uTex, vUV + uDir * 3.2307692308) * 0.0702702703;
                s += texture2D(uTex, vUV - uDir * 3.2307692308) * 0.0702702703;
                gl_FragColor = s;
            }
        """
        private const val BLOOM_FS = """
            #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
            #else
            precision mediump float;
            #endif
            varying vec2 vUV;
            uniform sampler2D uSrc;
            uniform sampler2D uGlow;
            uniform vec2 uTexel;
            uniform float uExp;
            uniform vec3 uTint;
            uniform float uTintAmt;
            void main() {
                vec4 base = texture2D(uSrc, vUV);
                vec2 t = uTexel;
                vec3 c = texture2D(uGlow, vUV + vec2(-t.x, t.y)).rgb + 2.0 * texture2D(uGlow, vUV + vec2(0.0, t.y)).rgb + texture2D(uGlow, vUV + vec2(t.x, t.y)).rgb
                       + 2.0 * texture2D(uGlow, vUV + vec2(-t.x, 0.0)).rgb + 4.0 * texture2D(uGlow, vUV).rgb + 2.0 * texture2D(uGlow, vUV + vec2(t.x, 0.0)).rgb
                       + texture2D(uGlow, vUV + vec2(-t.x, -t.y)).rgb + 2.0 * texture2D(uGlow, vUV + vec2(0.0, -t.y)).rgb + texture2D(uGlow, vUV + vec2(t.x, -t.y)).rgb;
                vec3 g = c / 16.0 * uExp;
                float gv = dot(g, vec3(0.3333));
                g = mix(g, uTint * gv * 1.8, uTintAmt);
                float n = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453);
                g += (n - 0.5) * (1.5 / 255.0) * step(0.0004, gv);
                gl_FragColor = vec4(base.rgb + g, clamp(max(base.a, gv), 0.0, 1.0));
            }
        """
        private const val DOWN_FS = """
            #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
            #else
            precision mediump float;
            #endif
            varying vec2 vUV;
            uniform sampler2D uTex;
            uniform vec2 uTexel;
            void main() {
                vec2 t = uTexel;
                vec3 a = texture2D(uTex, vUV + t * vec2(-2.0, -2.0)).rgb;
                vec3 b = texture2D(uTex, vUV + t * vec2(0.0, -2.0)).rgb;
                vec3 c = texture2D(uTex, vUV + t * vec2(2.0, -2.0)).rgb;
                vec3 d = texture2D(uTex, vUV + t * vec2(-2.0, 0.0)).rgb;
                vec3 e = texture2D(uTex, vUV).rgb;
                vec3 f = texture2D(uTex, vUV + t * vec2(2.0, 0.0)).rgb;
                vec3 g = texture2D(uTex, vUV + t * vec2(-2.0, 2.0)).rgb;
                vec3 h = texture2D(uTex, vUV + t * vec2(0.0, 2.0)).rgb;
                vec3 i = texture2D(uTex, vUV + t * vec2(2.0, 2.0)).rgb;
                vec3 j = texture2D(uTex, vUV + t * vec2(-1.0, -1.0)).rgb;
                vec3 k = texture2D(uTex, vUV + t * vec2(1.0, -1.0)).rgb;
                vec3 l = texture2D(uTex, vUV + t * vec2(-1.0, 1.0)).rgb;
                vec3 m = texture2D(uTex, vUV + t * vec2(1.0, 1.0)).rgb;
                vec3 o = e * 0.125 + (a + c + g + i) * 0.03125 + (b + d + f + h) * 0.0625 + (j + k + l + m) * 0.125;
                gl_FragColor = vec4(o, 1.0);
            }
        """
        private const val UP_FS = """
            #ifdef GL_FRAGMENT_PRECISION_HIGH
            precision highp float;
            #else
            precision mediump float;
            #endif
            varying vec2 vUV;
            uniform sampler2D uFine;
            uniform sampler2D uCoarse;
            uniform vec2 uTexel;
            uniform float uScatter;
            void main() {
                vec2 t = uTexel;
                vec3 c = texture2D(uCoarse, vUV + vec2(-t.x, t.y)).rgb + 2.0 * texture2D(uCoarse, vUV + vec2(0.0, t.y)).rgb + texture2D(uCoarse, vUV + vec2(t.x, t.y)).rgb
                       + 2.0 * texture2D(uCoarse, vUV + vec2(-t.x, 0.0)).rgb + 4.0 * texture2D(uCoarse, vUV).rgb + 2.0 * texture2D(uCoarse, vUV + vec2(t.x, 0.0)).rgb
                       + texture2D(uCoarse, vUV + vec2(-t.x, -t.y)).rgb + 2.0 * texture2D(uCoarse, vUV + vec2(0.0, -t.y)).rgb + texture2D(uCoarse, vUV + vec2(t.x, -t.y)).rgb;
                vec3 f = texture2D(uFine, vUV).rgb;
                gl_FragColor = vec4(f + c / 16.0 * uScatter, 1.0);
            }
        """
        private const val MASK_FS = """
            precision mediump float;
            varying vec2 vUV;
            uniform sampler2D uTex;
            uniform sampler2D uMask;
            uniform float uMode;
            void main() {
                vec4 c = texture2D(uTex, vUV);
                vec4 m = texture2D(uMask, vUV);
                float v = uMode < 2.5 ? m.a : dot(m.rgb, vec3(0.299, 0.587, 0.114));
                bool inv = (uMode > 1.5 && uMode < 2.5) || uMode > 3.5;
                if (inv) v = 1.0 - v;
                gl_FragColor = c * clamp(v, 0.0, 1.0);
            }
        """
        private const val COPY_VS = """
            uniform mat4 uM;
            attribute vec2 aPos;
            attribute vec2 aUV;
            varying vec2 vUV;
            void main() { vUV = aUV; gl_Position = uM * vec4(aPos, 0.0, 1.0); }
        """
        private const val COPY_FS = """
            precision mediump float;
            varying vec2 vUV;
            uniform sampler2D uTex;
            uniform float uOpacity;
            void main() { gl_FragColor = texture2D(uTex, vUV) * uOpacity; }
        """
        private const val BLIT_FS = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            varying vec2 vUV;
            uniform samplerExternalOES uTex;
            uniform mat4 uTexMat;
            uniform float uQ;
            void main() {
                vec2 s = (vUV - vec2(uQ)) / (1.0 - 2.0 * uQ);
                if (s.x < 0.0 || s.x > 1.0 || s.y < 0.0 || s.y > 1.0) { gl_FragColor = vec4(0.0); return; }
                vec2 uv = (uTexMat * vec4(s.x, 1.0 - s.y, 0.0, 1.0)).xy;
                gl_FragColor = texture2D(uTex, uv);
            }
        """
        private const val PAD_FS = """
            precision mediump float;
            varying vec2 vUV;
            uniform sampler2D uTex;
            uniform float uQ;
            void main() {
                vec2 s = (vUV - vec2(uQ)) / (1.0 - 2.0 * uQ);
                if (s.x < 0.0 || s.x > 1.0 || s.y < 0.0 || s.y > 1.0) gl_FragColor = vec4(0.0);
                else gl_FragColor = texture2D(uTex, s);
            }
        """
        private const val PART_VS = """
            uniform mat4 uMVP;
            uniform vec2 uPS;
            uniform float uSizeScale;
            attribute vec3 aCenter;
            attribute vec2 aCorner;
            attribute vec2 aUV;
            attribute vec4 aColor;
            varying vec2 vUV;
            varying vec4 vColor;
            void main() {
                vUV = aUV;
                vColor = aColor;
                vec4 c = uMVP * vec4(aCenter, 1.0);
                c.xy += aCorner * uSizeScale * uPS;
                gl_Position = c;
            }
        """
        private const val PART_FS = """
            precision mediump float;
            varying vec2 vUV;
            varying vec4 vColor;
            uniform sampler2D uTex;
            void main() { gl_FragColor = texture2D(uTex, vUV) * vColor; }
        """
        private const val MODEL_VS = """
            uniform mat4 uMVP;
            uniform mat4 uNM;
            attribute vec3 aPos;
            attribute vec3 aNrm;
            attribute vec2 aUV;
            varying vec3 vN;
            varying vec2 vUV;
            void main() {
                vN = (uNM * vec4(aNrm, 0.0)).xyz;
                vUV = aUV;
                gl_Position = uMVP * vec4(aPos, 1.0);
            }
        """
        private const val MODEL_FS = """
            precision mediump float;
            varying vec3 vN;
            varying vec2 vUV;
            uniform vec4 uColor;
            uniform float uHasTex;
            uniform sampler2D uTex;
            void main() {
                vec4 b = uColor;
                if (uHasTex > 0.5) b *= texture2D(uTex, vUV);
                vec3 n = normalize(vN);
                float d = max(dot(n, normalize(vec3(0.4, 0.7, 0.6))), 0.0);
                float r = max(dot(n, normalize(vec3(-0.5, -0.2, 0.3))), 0.0) * 0.25;
                gl_FragColor = vec4(b.rgb * (0.32 + 0.78 * d + r), 1.0);
            }
        """
    }
}
