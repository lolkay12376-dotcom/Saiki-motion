package com.saiki.motion

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow

object C {
    const val BG = 0xFF0E0E10.toInt()
    const val PANEL = 0xFF111114.toInt()
    const val CARD = 0xFF1C1C21.toInt()
    const val CARD2 = 0xFF26262C.toInt()
    const val GREEN = 0xFF22C55E.toInt()
    const val AMBER = 0xFFF5B301.toInt()
    const val RED = 0xFFEF4444.toInt()
    const val BLUE = 0xFF38BDF8.toInt()
    const val TEXT = 0xFFFFFFFF.toInt()
    const val DIM = 0xFF8C8C96.toInt()
    const val LINE = 0xFF2A2A30.toInt()
}

/** Vector icons drawn with Paths on a 24x24 grid. No emoji or font glyphs are used anywhere in the UI. */
object Icons {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    private fun stroke(color: Int) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = color
    }

    private fun fill(color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
    }

    fun draw(c: Canvas, name: String, cx: Float, cy: Float, size: Float, color: Int) {
        c.save()
        c.translate(cx - size / 2f, cy - size / 2f)
        c.scale(size / 24f, size / 24f)
        path.reset()
        when (name) {
            "back" -> { stroke(color); path.moveTo(15f, 5f); path.lineTo(8f, 12f); path.lineTo(15f, 19f); c.drawPath(path, p) }
            "cube" -> {
                stroke(color)
                path.moveTo(12f, 3f); path.lineTo(20f, 7.5f); path.lineTo(20f, 16.5f); path.lineTo(12f, 21f)
                path.lineTo(4f, 16.5f); path.lineTo(4f, 7.5f); path.close()
                path.moveTo(4f, 7.5f); path.lineTo(12f, 12f); path.lineTo(20f, 7.5f)
                path.moveTo(12f, 12f); path.lineTo(12f, 21f)
                c.drawPath(path, p)
            }
            "dots" -> {
                fill(color)
                for (i in 0 until 3) for (j in 0 until 3) c.drawCircle(6f + i * 6f, 6f + j * 6f, 1.5f, p)
            }
            "dup" -> {
                stroke(color)
                rect.set(3f, 3f, 14f, 14f); c.drawRoundRect(rect, 2f, 2f, p)
                rect.set(10f, 10f, 21f, 21f); c.drawRoundRect(rect, 2f, 2f, p)
            }
            "more" -> { fill(color); c.drawCircle(12f, 5f, 1.8f, p); c.drawCircle(12f, 12f, 1.8f, p); c.drawCircle(12f, 19f, 1.8f, p) }
            "grid" -> {
                stroke(color)
                rect.set(3f, 3f, 21f, 21f); c.drawRoundRect(rect, 2f, 2f, p)
                path.moveTo(9f, 3f); path.lineTo(9f, 21f); path.moveTo(15f, 3f); path.lineTo(15f, 21f)
                path.moveTo(3f, 9f); path.lineTo(21f, 9f); path.moveTo(3f, 15f); path.lineTo(21f, 15f)
                c.drawPath(path, p)
            }
            "bookmark", "bookmark_f" -> {
                if (name == "bookmark_f") fill(color) else stroke(color)
                path.moveTo(6f, 3f); path.lineTo(18f, 3f); path.lineTo(18f, 21f); path.lineTo(12f, 16.5f); path.lineTo(6f, 21f); path.close()
                c.drawPath(path, p)
            }
            "prev" -> {
                stroke(color)
                path.moveTo(18f, 5f); path.lineTo(8f, 12f); path.lineTo(18f, 19f); path.close()
                path.moveTo(5f, 5f); path.lineTo(5f, 19f)
                c.drawPath(path, p)
            }
            "next" -> {
                stroke(color)
                path.moveTo(6f, 5f); path.lineTo(16f, 12f); path.lineTo(6f, 19f); path.close()
                path.moveTo(19f, 5f); path.lineTo(19f, 19f)
                c.drawPath(path, p)
            }
            "play" -> { fill(color); path.moveTo(7f, 4f); path.lineTo(20f, 12f); path.lineTo(7f, 20f); path.close(); c.drawPath(path, p) }
            "pause" -> { fill(color); rect.set(6f, 4f, 10f, 20f); c.drawRect(rect, p); rect.set(14f, 4f, 18f, 20f); c.drawRect(rect, p) }
            "layers" -> {
                fill(color)
                path.moveTo(12f, 3f); path.lineTo(22f, 9f); path.lineTo(12f, 15f); path.lineTo(2f, 9f); path.close()
                c.drawPath(path, p)
                stroke(color)
                path.reset(); path.moveTo(2f, 13f); path.lineTo(12f, 19f); path.lineTo(22f, 13f)
                c.drawPath(path, p)
            }
            "undo", "redo" -> {
                stroke(color)
                if (name == "redo") { c.translate(24f, 0f); c.scale(-1f, 1f) }
                path.moveTo(9f, 5f); path.lineTo(4f, 10f); path.lineTo(9f, 15f)
                path.moveTo(4f, 10f); path.lineTo(14f, 10f); path.cubicTo(18.5f, 10f, 21f, 12.5f, 21f, 17f)
                c.drawPath(path, p)
            }
            "eye", "eye_off" -> {
                stroke(color)
                path.moveTo(2f, 12f); path.quadTo(12f, 3f, 22f, 12f); path.quadTo(12f, 21f, 2f, 12f); path.close()
                c.drawPath(path, p)
                fill(color); c.drawCircle(12f, 12f, 3f, p)
                if (name == "eye_off") { stroke(color); path.reset(); path.moveTo(4f, 4f); path.lineTo(20f, 20f); c.drawPath(path, p) }
            }
            "chev_down" -> { stroke(color); path.moveTo(6f, 9f); path.lineTo(12f, 15f); path.lineTo(18f, 9f); c.drawPath(path, p) }
            "chev_up" -> { stroke(color); path.moveTo(6f, 15f); path.lineTo(12f, 9f); path.lineTo(18f, 15f); c.drawPath(path, p) }
            "trash" -> {
                fill(color)
                path.moveTo(6f, 8f); path.lineTo(18f, 8f); path.lineTo(17f, 21f); path.lineTo(7f, 21f); path.close()
                c.drawPath(path, p)
                stroke(color); path.reset()
                path.moveTo(4f, 6f); path.lineTo(20f, 6f)
                path.moveTo(9f, 6f); path.lineTo(9f, 3f); path.lineTo(15f, 3f); path.lineTo(15f, 6f)
                c.drawPath(path, p)
            }
            "close" -> { stroke(color); path.moveTo(5f, 5f); path.lineTo(19f, 19f); path.moveTo(19f, 5f); path.lineTo(5f, 19f); c.drawPath(path, p) }
            "plus" -> { stroke(color); path.moveTo(12f, 4f); path.lineTo(12f, 20f); path.moveTo(4f, 12f); path.lineTo(20f, 12f); c.drawPath(path, p) }
            "diamond", "diamond_f" -> {
                if (name == "diamond_f") fill(color) else stroke(color)
                path.moveTo(12f, 3f); path.lineTo(21f, 12f); path.lineTo(12f, 21f); path.lineTo(3f, 12f); path.close()
                c.drawPath(path, p)
            }
            "graph" -> { stroke(color); path.moveTo(3f, 18f); path.lineTo(9f, 11f); path.lineTo(13f, 15f); path.lineTo(21f, 6f); c.drawPath(path, p) }
            "box" -> {
                stroke(color)
                rect.set(3f, 3f, 21f, 21f); c.drawRoundRect(rect, 3f, 3f, p)
                path.moveTo(7f, 9f); path.lineTo(11f, 12f); path.lineTo(7f, 15f)
                path.moveTo(13f, 16f); path.lineTo(17f, 16f)
                c.drawPath(path, p)
            }
            "handle" -> { stroke(color); path.moveTo(4f, 9f); path.lineTo(20f, 9f); path.moveTo(4f, 15f); path.lineTo(20f, 15f); c.drawPath(path, p) }
            "media" -> {
                stroke(color); rect.set(3f, 5f, 21f, 19f); c.drawRoundRect(rect, 2f, 2f, p)
                path.moveTo(5f, 17f); path.lineTo(10f, 11f); path.lineTo(14f, 15f); path.lineTo(16f, 13f); path.lineTo(19f, 17f); c.drawPath(path, p)
                fill(color); c.drawCircle(16.5f, 9.5f, 1.6f, p)
            }
            "text" -> { stroke(color); path.moveTo(5f, 6f); path.lineTo(19f, 6f); path.moveTo(12f, 6f); path.lineTo(12f, 19f); path.moveTo(9f, 19f); path.lineTo(15f, 19f); c.drawPath(path, p) }
            "shape" -> { stroke(color); c.drawCircle(9f, 9f, 5.5f, p); rect.set(11f, 11f, 20f, 20f); c.drawRoundRect(rect, 1.5f, 1.5f, p) }
            "camera" -> {
                stroke(color); rect.set(3f, 7f, 16f, 17f); c.drawRoundRect(rect, 2f, 2f, p)
                path.moveTo(16f, 10f); path.lineTo(21f, 7f); path.lineTo(21f, 17f); path.lineTo(16f, 14f); c.drawPath(path, p)
            }
            "nullobj" -> {
                stroke(color); c.drawCircle(12f, 12f, 5f, p)
                path.moveTo(12f, 2f); path.lineTo(12f, 7f); path.moveTo(12f, 17f); path.lineTo(12f, 22f)
                path.moveTo(2f, 12f); path.lineTo(7f, 12f); path.moveTo(17f, 12f); path.lineTo(22f, 12f); c.drawPath(path, p)
            }
            "particles" -> {
                fill(color)
                c.drawCircle(7f, 7f, 1.8f, p); c.drawCircle(15f, 6f, 1.2f, p); c.drawCircle(11f, 12f, 2.2f, p)
                c.drawCircle(18f, 14f, 1.6f, p); c.drawCircle(6f, 17f, 1.4f, p); c.drawCircle(14f, 19f, 1.8f, p)
            }
            "edit" -> {
                stroke(color); path.moveTo(4f, 20f); path.lineTo(5f, 15f); path.lineTo(16f, 4f); path.lineTo(20f, 8f); path.lineTo(9f, 19f); path.close()
                path.moveTo(14f, 6f); path.lineTo(18f, 10f); c.drawPath(path, p)
            }
            "move" -> {
                stroke(color)
                path.moveTo(12f, 3f); path.lineTo(12f, 21f); path.moveTo(3f, 12f); path.lineTo(21f, 12f)
                path.moveTo(9f, 6f); path.lineTo(12f, 3f); path.lineTo(15f, 6f); path.moveTo(9f, 18f); path.lineTo(12f, 21f); path.lineTo(15f, 18f)
                path.moveTo(6f, 9f); path.lineTo(3f, 12f); path.lineTo(6f, 15f); path.moveTo(18f, 9f); path.lineTo(21f, 12f); path.lineTo(18f, 15f)
                c.drawPath(path, p)
            }
            "sparkle" -> {
                fill(color)
                path.moveTo(12f, 3f); path.lineTo(14f, 10f); path.lineTo(21f, 12f); path.lineTo(14f, 14f); path.lineTo(12f, 21f)
                path.lineTo(10f, 14f); path.lineTo(3f, 12f); path.lineTo(10f, 10f); path.close(); c.drawPath(path, p)
            }
            "drop" -> {
                stroke(color); path.moveTo(12f, 3f); path.cubicTo(12f, 3f, 5f, 10f, 5f, 15f); path.cubicTo(5f, 19f, 8f, 21f, 12f, 21f)
                path.cubicTo(16f, 21f, 19f, 19f, 19f, 15f); path.cubicTo(19f, 10f, 12f, 3f, 12f, 3f); path.close(); c.drawPath(path, p)
            }
            "speed" -> { stroke(color); path.moveTo(5f, 5f); path.lineTo(12f, 12f); path.lineTo(5f, 19f); path.moveTo(13f, 5f); path.lineTo(20f, 12f); path.lineTo(13f, 19f); c.drawPath(path, p) }
            "import" -> { stroke(color); path.moveTo(12f, 3f); path.lineTo(12f, 15f); path.moveTo(7f, 10f); path.lineTo(12f, 15f); path.lineTo(17f, 10f); path.moveTo(4f, 19f); path.lineTo(20f, 19f); c.drawPath(path, p) }
            "export" -> { stroke(color); path.moveTo(12f, 15f); path.lineTo(12f, 3f); path.moveTo(7f, 8f); path.lineTo(12f, 3f); path.lineTo(17f, 8f); path.moveTo(4f, 19f); path.lineTo(20f, 19f); c.drawPath(path, p) }
            "fit" -> {
                stroke(color)
                path.moveTo(4f, 9f); path.lineTo(4f, 4f); path.lineTo(9f, 4f)
                path.moveTo(15f, 4f); path.lineTo(20f, 4f); path.lineTo(20f, 9f)
                path.moveTo(20f, 15f); path.lineTo(20f, 20f); path.lineTo(15f, 20f)
                path.moveTo(9f, 20f); path.lineTo(4f, 20f); path.lineTo(4f, 15f)
                c.drawPath(path, p)
            }
        }
        c.restore()
    }
}

/** Plain icon button. */
class IconView(ctx: Context, var icon: String, var tint: Int = C.TEXT, private val sizeDp: Float = 22f) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    var onClick: (() -> Unit)? = null
    var onLong: (() -> Unit)? = null

    init {
        isClickable = true
        setOnClickListener { onClick?.invoke() }
        setOnLongClickListener { if (onLong != null) { onLong?.invoke(); true } else false }
    }

    fun set(name: String, color: Int) { icon = name; tint = color; invalidate() }

    override fun setPressed(pressed: Boolean) { super.setPressed(pressed); invalidate() }

    override fun onDraw(c: Canvas) {
        val col = if (isPressed) ((tint and 0x00FFFFFF) or 0x80000000.toInt()) else tint
        Icons.draw(c, icon, width / 2f, height / 2f, sizeDp * d, col)
    }
}

/** Small outlined text chip, e.g. the preview quality switch. */
class ChipView(ctx: Context, var text: String) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    var onClick: (() -> Unit)? = null

    init {
        isClickable = true
        setOnClickListener { onClick?.invoke() }
        bg.style = Paint.Style.STROKE
        bg.strokeWidth = 1.5f * d
        bg.color = 0xFF4A4A52.toInt()
        tp.color = C.TEXT
        tp.textSize = 13f * d
        tp.typeface = Typeface.DEFAULT_BOLD
        tp.textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        r.set(2f * d, 6f * d, width - 2f * d, height - 6f * d)
        c.drawRoundRect(r, 8f * d, 8f * d, bg)
        c.drawText(text, width / 2f, height / 2f + 4.5f * d, tp)
    }
}

/** Rounded text button, optionally with a leading icon. Used for "Add Effect" etc. */
class PillButton(ctx: Context, var text: String, var icon: String?, private val fillColor: Int, private val textColor: Int) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    var onClick: (() -> Unit)? = null

    init {
        isClickable = true
        setOnClickListener { onClick?.invoke() }
        bg.color = fillColor
        tp.color = textColor
        tp.textSize = 15f * d
        tp.typeface = Typeface.DEFAULT_BOLD
    }

    override fun setPressed(pressed: Boolean) { super.setPressed(pressed); invalidate() }

    override fun onDraw(c: Canvas) {
        bg.alpha = if (isPressed) 170 else 255
        r.set(0f, 0f, width.toFloat(), height.toFloat())
        c.drawRoundRect(r, 12f * d, 12f * d, bg)
        val tw = tp.measureText(text)
        val iw = if (icon != null) 22f * d + 8f * d else 0f
        var x = (width - tw - iw) / 2f
        if (icon != null) { Icons.draw(c, icon!!, x + 11f * d, height / 2f, 20f * d, textColor); x += iw }
        c.drawText(text, x, height / 2f + 5f * d, tp)
    }
}

/**
 * The scrolling-ruler value control used for every parameter.
 * Drag horizontally to change the value, tap the label to toggle a keyframe.
 */
class RulerSlider(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    var label = ""
    var lo = 0f
    var hi = 1f
    var value = 0f
    var dec = 2
    var hasKey = false
    var hasAnim = false
    var canKey = true
    var onChange: ((Float) -> Unit)? = null
    var onBegin: (() -> Unit)? = null
    var onLabelTap: (() -> Unit)? = null

    private val card = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val small = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bub = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bubTxt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private var downX = 0f
    private var lastX = 0f
    private var dragging = false
    private var onLabel = false

    init {
        card.color = C.CARD
        tick.strokeWidth = 1.2f * d
        tick.color = 0xFF6B6B75.toInt()
        txt.color = C.TEXT
        txt.textSize = 15f * d
        txt.typeface = Typeface.DEFAULT_BOLD
        small.color = 0xFF8C8C96.toInt()
        small.textSize = 11f * d
        small.textAlign = Paint.Align.CENTER
        bub.color = C.GREEN
        bubTxt.color = 0xFF04210F.toInt()
        bubTxt.textSize = 15f * d
        bubTxt.typeface = Typeface.DEFAULT_BOLD
        bubTxt.textAlign = Paint.Align.CENTER
    }

    private fun fmt(v: Float): String {
        val q = if (abs(v) < 0.5f * 10f.pow(-dec)) 0f else v
        return String.format("%." + dec + "f", q)
    }

    private fun labelW() = width * 0.36f
    private fun ppu(): Float = (width - labelW()) / ((hi - lo) * 0.6f)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        r.set(0f, 0f, w, h)
        c.drawRoundRect(r, 10f * d, 10f * d, card)

        val lw = labelW()
        c.drawText(label, 14f * d, h / 2f + 5f * d, txt)
        if (canKey && (hasKey || hasAnim)) {
            Icons.draw(c, if (hasKey) "diamond_f" else "diamond", lw - 14f * d, 16f * d, 12f * d, if (hasKey) C.GREEN else 0xFF7A7A84.toInt())
        }

        // ruler
        val cxv = lw + (w - lw) / 2f
        val ppu = ppu()
        c.save()
        c.clipRect(lw, 0f, w, h)
        val range = hi - lo
        val raw = range * 0.1f
        val mag = 10f.pow(floor(log10(raw.toDouble())).toFloat())
        val f = raw / mag
        val nice = if (f < 1.5f) 1f else if (f < 3.5f) 2f else if (f < 7.5f) 5f else 10f
        val major = nice * mag
        val minor = major / 5f
        val k0 = ceil((value - (cxv - lw) / ppu) / minor).toInt()
        val k1 = floor((value + (w - cxv) / ppu) / minor).toInt()
        for (k in k0..k1) {
            val v = k * minor
            if (v < lo - 0.0001f || v > hi + 0.0001f) continue
            val x = cxv + (v - value) * ppu
            val isMajor = k % 5 == 0
            val top = if (isMajor) h - 18f * d else h - 11f * d
            c.drawLine(x, top, x, h - 4f * d, tick)
            if (isMajor) {
                val s = String.format(if (major >= 1f) "%.0f" else "%.1f", v)
                c.drawText(s, x, h - 22f * d, small)
            }
        }
        // boundary markers at min and max
        val xl = cxv + (lo - value) * ppu
        val xh = cxv + (hi - value) * ppu
        tick.color = 0xFFFFFFFF.toInt()
        tick.strokeWidth = 2f * d
        if (xl in lw..w) c.drawLine(xl, 8f * d, xl, h - 4f * d, tick)
        if (xh in lw..w) c.drawLine(xh, 8f * d, xh, h - 4f * d, tick)
        tick.color = 0xFF6B6B75.toInt()
        tick.strokeWidth = 1.2f * d
        // centre line
        tick.color = C.GREEN
        tick.strokeWidth = 2f * d
        c.drawLine(cxv, 30f * d, cxv, h, tick)
        tick.color = 0xFF6B6B75.toInt()
        tick.strokeWidth = 1.2f * d
        c.restore()

        // value bubble
        val s = fmt(value)
        val bw = maxOf(44f * d, bubTxt.measureText(s) + 20f * d)
        r.set(cxv - bw / 2f, 6f * d, cxv + bw / 2f, 34f * d)
        c.drawRoundRect(r, 8f * d, 8f * d, bub)
        c.drawText(s, cxv, 26f * d, bubTxt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; lastX = e.x; dragging = false
                onLabel = e.x < labelW()
                if (!onLabel) { onBegin?.invoke(); parent?.requestDisallowInterceptTouchEvent(true) }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (onLabel) return true
                if (abs(e.x - downX) > 4f * d) dragging = true
                val dx = e.x - lastX
                lastX = e.x
                var v = value - dx / ppu()
                v = v.coerceIn(lo, hi)
                if (dec == 0) v = Math.round(v).toFloat()
                if (v != value) { value = v; onChange?.invoke(v); invalidate() }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (onLabel && abs(e.x - downX) < 8f * d) onLabelTap?.invoke()
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
            MotionEvent.ACTION_CANCEL -> { parent?.requestDisallowInterceptTouchEvent(false); return true }
        }
        return super.onTouchEvent(e)
    }
}


/** Icon above a label; used for the bottom tool bar. */
class ToolButton(ctx: Context, var icon: String, var label: String) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    var tint = C.TEXT
    var onClick: (() -> Unit)? = null

    init {
        isClickable = true
        setOnClickListener { onClick?.invoke() }
        tp.textSize = 11f * d
        tp.textAlign = Paint.Align.CENTER
    }

    override fun setPressed(pressed: Boolean) { super.setPressed(pressed); invalidate() }

    override fun onDraw(c: Canvas) {
        val col = if (isPressed) ((tint and 0x00FFFFFF) or 0x80000000.toInt()) else tint
        Icons.draw(c, icon, width / 2f, height / 2f - 7f * d, 24f * d, col)
        tp.color = col
        c.drawText(label, width / 2f, height - 10f * d, tp)
    }
}

/** Horizontal row of selectable pills. */
fun chipRow(ctx: Context, labels: List<String>, sel: Int, onPick: (Int) -> Unit): View {
    val d = ctx.resources.displayMetrics.density
    val sv = android.widget.HorizontalScrollView(ctx)
    sv.isHorizontalScrollBarEnabled = false
    val row = android.widget.LinearLayout(ctx)
    for ((i, nm) in labels.withIndex()) {
        val on = i == sel
        val b = PillButton(ctx, nm, null, if (on) C.GREEN else C.CARD2, if (on) 0xFF04210F.toInt() else C.TEXT)
        b.onClick = { onPick(i) }
        val lp = android.widget.LinearLayout.LayoutParams((92 * d).toInt(), (38 * d).toInt())
        lp.setMargins((3 * d).toInt(), (4 * d).toInt(), (3 * d).toInt(), (4 * d).toInt())
        row.addView(b, lp)
    }
    sv.addView(row)
    return sv
}

/** Effect tile whose icon automatically swipes between the processed and the original anime portrait. */
class EffectCard(ctx: Context, var name: String, var category: String) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    var before: Bitmap? = null
    var after: Bitmap? = null
    var badge = false
    var thumbHeight = 0.8f
    var onClick: (() -> Unit)? = null
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val r = RectF()
    private val src = android.graphics.Rect()
    private val dst = RectF()

    init {
        isClickable = true
        setOnClickListener { onClick?.invoke() }
        bg.color = C.CARD
        line.color = 0xFFFFFFFF.toInt()
        line.strokeWidth = 2f * d
        tp.typeface = Typeface.DEFAULT_BOLD
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val th = minOf(w * thumbHeight, height - 44f * d)
        r.set(0f, 0f, w, height.toFloat())
        c.drawRoundRect(r, 12f * d, 12f * d, bg)
        r.set(0f, 0f, w, th)
        clip.reset()
        clip.addRoundRect(r, floatArrayOf(12f * d, 12f * d, 12f * d, 12f * d, 0f, 0f, 0f, 0f), Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        val a = after
        val b = before
        if (a != null && b != null) {
            val ph = ((System.currentTimeMillis() % 3600L) / 3600f)
            val u = if (ph < 0.5f) ph * 2f else 2f - ph * 2f
            val ex = w * (0.08f + 0.84f * u)
            drawFit(c, b, 0f, w, th)
            c.save()
            c.clipRect(0f, 0f, ex, th)
            drawFit(c, a, 0f, w, th)
            c.restore()
            c.drawLine(ex, 0f, ex, th, line)
            bg.color = 0xFFFFFFFF.toInt()
            c.drawCircle(ex, th / 2f, 9f * d, bg)
            bg.color = 0xFF111114.toInt()
            c.drawCircle(ex, th / 2f, 3.5f * d, bg)
            bg.color = C.CARD
            postInvalidateOnAnimation()
        } else {
            bg.color = C.CARD2
            c.drawRect(0f, 0f, w, th, bg)
            bg.color = C.CARD
            tp.color = C.DIM; tp.textSize = 12f * d; tp.textAlign = Paint.Align.CENTER
            c.drawText("rendering", w / 2f, th / 2f, tp)
            postInvalidateDelayed(400)
        }
        c.restore()
        tp.textAlign = Paint.Align.LEFT
        tp.color = C.TEXT; tp.textSize = 14f * d
        c.drawText(name, 10f * d, th + 22f * d, tp)
        tp.color = C.DIM; tp.textSize = 11f * d; tp.typeface = Typeface.DEFAULT
        c.drawText(category, 10f * d, th + 38f * d, tp)
        tp.typeface = Typeface.DEFAULT_BOLD
        if (badge) { bg.color = C.GREEN; c.drawCircle(w - 14f * d, th + 20f * d, 5f * d, bg); bg.color = C.CARD }
    }

    private fun drawFit(c: Canvas, bmp: Bitmap, x: Float, w: Float, h: Float) {
        val s = maxOf(w / bmp.width, h / bmp.height)
        val sw = w / s
        val sh = h / s
        src.set(((bmp.width - sw) / 2f).toInt(), ((bmp.height - sh) / 2f).toInt(), ((bmp.width + sw) / 2f).toInt(), ((bmp.height + sh) / 2f).toInt())
        dst.set(x, 0f, x + w, h)
        c.drawBitmap(bmp, src, dst, null)
    }
}

/** Cubic bezier easing editor: drag the two handles. */
class GraphView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    var key: Key? = null
    var onBegin: (() -> Unit)? = null
    var onChange: (() -> Unit)? = null
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG)
    private val curve = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var drag = 0
    private val pad = 24f * d

    init {
        grid.color = 0xFF2A2A30.toInt(); grid.strokeWidth = 1f * d
        curve.color = C.GREEN; curve.strokeWidth = 3f * d; curve.style = Paint.Style.STROKE
        hp.color = 0xFFFFFFFF.toInt(); hp.strokeWidth = 1.5f * d
        tp.color = C.DIM; tp.textSize = 12f * d; tp.textAlign = Paint.Align.CENTER
    }

    private fun px(x: Float) = pad + x * (width - 2 * pad)
    private fun py(y: Float) = height - pad - (y + 0.5f) / 2f * (height - 2 * pad)
    private fun ux(x: Float) = ((x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
    private fun uy(y: Float) = ((height - pad - y) / (height - 2 * pad) * 2f - 0.5f).coerceIn(-0.5f, 1.5f)

    override fun onDraw(c: Canvas) {
        for (i in 0..4) {
            val gx = px(i / 4f)
            c.drawLine(gx, py(-0.5f), gx, py(1.5f), grid)
        }
        for (i in 0..4) {
            val gy = py(-0.5f + i * 0.5f)
            c.drawLine(px(0f), gy, px(1f), gy, grid)
        }
        val k = key
        if (k == null) { c.drawText("Select a property with 2+ keyframes", width / 2f, height / 2f, tp); return }
        path.reset()
        for (i in 0..60) {
            val u = i / 60f
            val x = px(u)
            val y = py(k.curve(u))
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, curve)
        c.drawLine(px(0f), py(0f), px(k.x1), py(k.y1), hp)
        c.drawLine(px(1f), py(1f), px(k.x2), py(k.y2), hp)
        hp.style = Paint.Style.FILL
        c.drawCircle(px(k.x1), py(k.y1), 8f * d, hp)
        c.drawCircle(px(k.x2), py(k.y2), 8f * d, hp)
        c.drawCircle(px(0f), py(0f), 4f * d, hp)
        c.drawCircle(px(1f), py(1f), 4f * d, hp)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val k = key ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val d1 = Math.hypot((e.x - px(k.x1)).toDouble(), (e.y - py(k.y1)).toDouble())
                val d2 = Math.hypot((e.x - px(k.x2)).toDouble(), (e.y - py(k.y2)).toDouble())
                drag = if (minOf(d1, d2) > 40f * d) 0 else if (d1 <= d2) 1 else 2
                if (drag != 0) { onBegin?.invoke(); parent?.requestDisallowInterceptTouchEvent(true) }
            }
            MotionEvent.ACTION_MOVE -> if (drag != 0) {
                if (k.ease != Ease.CUSTOM) k.ease = Ease.CUSTOM
                if (drag == 1) { k.x1 = ux(e.x); k.y1 = uy(e.y) } else { k.x2 = ux(e.x); k.y2 = uy(e.y) }
                onChange?.invoke(); invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { drag = 0; parent?.requestDisallowInterceptTouchEvent(false) }
        }
        return true
    }
}
