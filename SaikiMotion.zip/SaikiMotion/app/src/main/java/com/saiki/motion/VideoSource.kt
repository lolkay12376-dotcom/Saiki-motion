package com.saiki.motion

import android.graphics.SurfaceTexture
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.Looper
import android.view.Surface
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/**
 * Frame-accurate video decoding with the platform MediaCodec (no FFmpeg, adds 0 bytes to the APK).
 * Frames go straight into an external OES texture. Must be created and used on a GL thread.
 */
class VideoSource(private val path: String) {
    var texId = 0
    var w = 1
    var h = 1
    var durationUs = 0L
    var failed = false
    val texMat = FloatArray(16)

    private var extractor: MediaExtractor? = null
    private var codec: MediaCodec? = null
    private var st: SurfaceTexture? = null
    private var surface: Surface? = null
    private val sem = Semaphore(0)
    private val info = MediaCodec.BufferInfo()
    private var curPts = -1L
    private var frameDurUs = 33_000L
    private var inputDone = false
    private var outDone = false

    fun init(): Boolean {
        try {
            val ex = MediaExtractor()
            ex.setDataSource(path)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("video/")) { track = i; fmt = f; break }
            }
            if (track < 0 || fmt == null) { failed = true; return false }
            ex.selectTrack(track)
            w = fmt.getInteger(MediaFormat.KEY_WIDTH)
            h = fmt.getInteger(MediaFormat.KEY_HEIGHT)
            val rot = if (fmt.containsKey(MediaFormat.KEY_ROTATION)) fmt.getInteger(MediaFormat.KEY_ROTATION) else 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            durationUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            if (fmt.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                val fr = try { fmt.getInteger(MediaFormat.KEY_FRAME_RATE) } catch (e: Exception) { 30 }
                if (fr > 0) frameDurUs = 1_000_000L / fr
            }
            val ids = IntArray(1)
            GLES20.glGenTextures(1, ids, 0)
            texId = ids[0]
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            val s = SurfaceTexture(texId)
            s.setOnFrameAvailableListener({ sem.release() }, Handler(Looper.getMainLooper()))
            st = s
            surface = Surface(s)
            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            c.configure(fmt, surface, null, 0)
            c.start()
            codec = c
            extractor = ex
            android.opengl.Matrix.setIdentityM(texMat, 0)
            return true
        } catch (e: Exception) {
            failed = true
            return false
        }
    }

    /** Make the texture show the frame at [targetUs]. */
    fun seek(targetUs0: Long) {
        if (failed) return
        val c = codec ?: return
        val ex = extractor ?: return
        val target = targetUs0.coerceIn(0L, maxOf(0L, durationUs - 1))
        if (curPts >= 0 && target >= curPts && target < curPts + frameDurUs) return
        val forward = curPts >= 0 && target >= curPts && target - curPts < 800_000
        if (!forward) {
            ex.seekTo(target, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            c.flush()
            inputDone = false
            outDone = false
            curPts = -1
        }
        var guard = 0
        while (guard++ < 900 && !outDone) {
            if (!inputDone) {
                val ii = c.dequeueInputBuffer(0)
                if (ii >= 0) {
                    val buf = c.getInputBuffer(ii)!!
                    val size = ex.readSampleData(buf, 0)
                    if (size < 0) {
                        c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inputDone = true
                    } else {
                        c.queueInputBuffer(ii, 0, size, ex.sampleTime, 0)
                        ex.advance()
                    }
                }
            }
            val oi = c.dequeueOutputBuffer(info, 8000)
            if (oi >= 0) {
                val pts = info.presentationTimeUs
                val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                val show = pts >= target - frameDurUs / 2 && !eos
                c.releaseOutputBuffer(oi, show)
                if (eos) { outDone = true; break }
                if (show) {
                    if (sem.tryAcquire(300, TimeUnit.MILLISECONDS)) {
                        st?.updateTexImage()
                        st?.getTransformMatrix(texMat)
                    }
                    if (curPts >= 0 && pts > curPts) frameDurUs = (pts - curPts).coerceIn(4_000L, 100_000L)
                    curPts = pts
                    break
                }
            }
        }
    }

    fun release() {
        try { codec?.stop() } catch (e: Exception) { }
        try { codec?.release() } catch (e: Exception) { }
        try { extractor?.release() } catch (e: Exception) { }
        try { surface?.release() } catch (e: Exception) { }
        try { st?.release() } catch (e: Exception) { }
        if (texId != 0) GLES20.glDeleteTextures(1, intArrayOf(texId), 0)
        codec = null; extractor = null
    }
}
