# Saiki Motion

Native Android motion-graphics editor (Kotlin + OpenGL ES 2.0). No WebView, no browser.

## Features
- Scenes: multiple scenes, canvas presets (16:9, 9:16, 1:1, 4:5, 21:9), fps, duration, background, 3D camera FOV
- Layers: shapes, text, images from the gallery
- 3D: rotate X / Y / Z with real perspective, one-tap spin presets
- Keyframes with easing (linear, in, out, in-out, bounce), auto-keyframe mode
- Effects: Motion Tile (scroll, mirror, gap), Time Remap (speed, reverse, loop, ping-pong),
  Swing, RGB Split, Blur, Wave Warp, Pixelate, Grayscale, Invert, Shake
- Timeline with fixed playhead, pinch zoom, trim and move bars, markers, visibility toggles
- On-canvas handles: drag to move, corner handles to scale, top handle to rotate, pinch to scale
- Undo / redo, autosave, preview quality (Full, 1/2, 1/4) for smooth editing
- Export to MP4 (H.264) in Movies/SaikiMotion

## Build the APK on GitHub (no PC needed beyond a browser)
1. Create a new empty repository on github.com.
2. Upload every file and folder from this project (including the hidden `.github` folder).
   On a phone browser use "Add file > Upload files"; on desktop just drag the folder contents in.
3. Open the **Actions** tab. The "Build APK" workflow runs on every push (or press "Run workflow").
4. When it turns green, open the run and download the artifact **SaikiMotion-debug-apk**.
5. Unzip it and install `app-debug.apk` (allow "Install unknown apps" for your browser/file manager).

## Build locally
Open the folder in Android Studio (Ladybug or newer, JDK 17) and press Run,
or with Gradle 8.7 installed: `gradle assembleDebug`.
The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- minSdk 29 (Android 10+).
- Debug-signed APK, fine for personal use. For Play Store builds add a release signing config.
