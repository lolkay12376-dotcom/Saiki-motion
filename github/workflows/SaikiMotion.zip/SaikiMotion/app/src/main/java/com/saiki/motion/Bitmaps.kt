package com.saiki.motion

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Turns a layer into a bitmap that is uploaded as a GL texture. */
object LayerBitmaps {
    fun baseHeight(l: Layer): Float = when (l.type) {
        LayerType.SHAPE -> 0.8f
        LayerType.TEXT -> 0.3f
        LayerType.IMAGE -> 1.2f
    }

    fun make(l: Layer): Bitmap = when (l.type) {
        LayerType.SHAPE -> shape(l)
        LayerType.TEXT -> text(l)
        LayerType.IMAGE -> image(l)
    }

    private fun shape(l: Layer): Bitmap {
        val s = 512
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = l.color
        p.style = Paint.Style.FILL
        val m = 40f
        val r = RectF(m, m, s - m, s - m)
        when (l.shape) {
            ShapeKind.RECT -> c.drawRect(r, p)
            ShapeKind.ROUND -> c.drawRoundRect(r, 90f, 90f, p)
            ShapeKind.CIRCLE -> c.drawOval(r, p)
            ShapeKind.TRIANGLE -> {
                val path = Path()
                path.moveTo(s / 2f, m); path.lineTo(s - m, s - m); path.lineTo(m, s - m); path.close()
                c.drawPath(path, p)
            }
            ShapeKind.STAR -> {
                val path = Path()
                val cx = s / 2f
                val cy = s / 2f
                val ro = s / 2f - m
                val ri = ro * 0.45f
                for (i in 0 until 10) {
                    val ang = -Math.PI / 2 + i * Math.PI / 5
                    val rr = if (i % 2 == 0) ro else ri
                    val px = (cx + rr * cos(ang)).toFloat()
                    val py = (cy + rr * sin(ang)).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                c.drawPath(path, p)
            }
        }
        return bmp
    }

    private fun text(l: Layer): Bitmap {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = l.color
        p.textSize = 160f
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val tw = max(p.measureText(l.text), 40f)
        val fm = p.fontMetrics
        val pad = 40
        val w = (tw + pad * 2).toInt().coerceIn(64, 4096)
        val h = (fm.descent - fm.ascent + pad * 2).toInt()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawText(l.text, pad.toFloat(), pad - fm.ascent, p)
        return bmp
    }

    private fun image(l: Layer): Bitmap {
        val path = l.imagePath
        if (path != null) {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, o)
            var ss = 1
            while (o.outWidth / ss > 1500 || o.outHeight / ss > 1500) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            val b = BitmapFactory.decodeFile(path, o2)
            if (b != null) return b
        }
        val bmp = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(0xFF888888.toInt())
        return bmp
    }
}
