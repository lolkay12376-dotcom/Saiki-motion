package com.saiki.motion

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLExt
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileInputStream
import java.io.IOException

/** Renders every scene offscreen into an H.264 MP4 and saves it to Movies/SaikiMotion. */
class Exporter(
    private val ctx: Context,
    private val project: Project,
    private val onProgress: (Int) -> Unit,
    private val onDone: (String?, String?) -> Unit
) {
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var muxStarted = false

    fun start() { Thread { run() }.start() }

    private fun run() {
        val out = File(ctx.cacheDir, "export_" + System.currentTimeMillis() + ".mp4")
        try {
            encode(out)
            val where = saveToGallery(out)
            onDone(where, null)
        } catch (e: Throwable) {
            onDone(null, e.message ?: e.toString())
        } finally {
            out.delete()
        }
    }

    private fun encode(out: File) {
        val w = project.w / 2 * 2
        val h = project.h / 2 * 2
        val fps = project.fps
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, (w.toLong() * h * fps / 8).toInt().coerceIn(2_000_000, 24_000_000))
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)

        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inputSurface = enc.createInputSurface()
        enc.start()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        EGL14.eglInitialize(dpy, ver, 0, ver, 1)
        val attribs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            0x3142, 1, // EGL_RECORDABLE_ANDROID
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attribs, 0, cfgs, 0, 1, n, 0)
        val eglCtx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        val surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], inputSurface, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, surf, surf, eglCtx)

        try {
            val sr = SceneRenderer()
            sr.init()
            var total = 0
            for (s in project.scenes) total += (s.duration * fps).toInt()
            if (total < 1) total = 1
            var frame = 0
            for (s in project.scenes) {
                val count = (s.duration * fps).toInt()
                for (f in 0 until count) {
                    sr.draw(project, s, f.toFloat() / fps, w, h)
                    EGLExt.eglPresentationTimeANDROID(dpy, surf, frame * 1_000_000_000L / fps)
                    EGL14.eglSwapBuffers(dpy, surf)
                    drain(enc, muxer, false)
                    frame++
                    onProgress(frame * 100 / total)
                }
            }
            enc.signalEndOfInputStream()
            drain(enc, muxer, true)
        } finally {
            try { enc.stop() } catch (e: Exception) { }
            enc.release()
            try { if (muxStarted) muxer.stop() } catch (e: Exception) { }
            muxer.release()
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(dpy, surf)
            EGL14.eglDestroyContext(dpy, eglCtx)
            EGL14.eglTerminate(dpy)
            inputSurface.release()
        }
    }

    private fun drain(enc: MediaCodec, muxer: MediaMuxer, end: Boolean) {
        while (true) {
            val idx = enc.dequeueOutputBuffer(info, 10_000)
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!end) return
            } else if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = muxer.addTrack(enc.outputFormat)
                muxer.start()
                muxStarted = true
            } else if (idx >= 0) {
                val buf = enc.getOutputBuffer(idx)
                if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                if (buf != null && info.size > 0 && muxStarted) {
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    muxer.writeSampleData(track, buf, info)
                }
                enc.releaseOutputBuffer(idx, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }
    }

    private fun saveToGallery(f: File): String {
        val values = ContentValues()
        values.put(MediaStore.Video.Media.DISPLAY_NAME, "SaikiMotion_" + System.currentTimeMillis() + ".mp4")
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SaikiMotion")
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Could not create output file")
        val os = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("Could not open output")
        os.use { o -> FileInputStream(f).use { it.copyTo(o) } }
        return "Movies/SaikiMotion"
    }
}
