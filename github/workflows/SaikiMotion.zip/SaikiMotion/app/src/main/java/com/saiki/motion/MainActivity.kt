package com.saiki.motion

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File

class MainActivity : Activity(), EditHost, TimelineHost {
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val REQ_IMG = 41

    private lateinit var preview: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var aspect: AspectLayout
    private lateinit var timeline: TimelineView
    private lateinit var titleView: TextView
    private lateinit var playIcon: IconView
    private lateinit var markIcon: IconView
    private lateinit var qualityChip: ChipView
    private lateinit var panelBox: LinearLayout
    private lateinit var panelList: LinearLayout
    private lateinit var diamondSide: IconView

    private var selectedId = -1
    private var panelOpen = false
    private var playing = false
    private var lastNs = 0L
    private var autoKey = false
    private var quality = 1

    private val expanded = HashSet<String>()
    private val rows = ArrayList<Row>()

    private class Row(val slider: RulerSlider, val d: PropDef, val layer: Layer)

    private val undo = ArrayList<String>()
    private val redo = ArrayList<String>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Editor.project = loadProject()
        Editor.sceneIndex = 0
        Editor.time = 0f
        buildUi()
        refreshAll()
    }

    override fun onResume() { super.onResume(); preview.onResume() }

    override fun onPause() {
        super.onPause()
        playing = false
        playIcon.set("play", C.TEXT)
        preview.onPause()
        saveProject()
    }

    private fun projectFile() = File(filesDir, "project.json")

    private fun saveProject() {
        try { projectFile().writeText(Store.toJson(Editor.project).toString()) } catch (e: Exception) { }
    }

    private fun loadProject(): Project {
        return try {
            val f = projectFile()
            if (f.exists()) Store.fromJson(JSONObject(f.readText())) else starter()
        } catch (e: Exception) { starter() }
    }

    private fun starter(): Project {
        val p = Project()
        val s = p.scenes[0]
        val a = Layer(p.nextId++, "Shape", LayerType.SHAPE)
        a.end = s.duration
        a.props["rotY"]!!.keys.add(Key(0f, 0f, Ease.LINEAR))
        a.props["rotY"]!!.keys.add(Key(s.duration, 360f, Ease.LINEAR))
        val b = Layer(p.nextId++, "Title", LayerType.TEXT)
        b.end = s.duration
        b.color = 0xFFFFFFFF.toInt()
        b.props["y"]!!.base = -0.8f
        s.layers.add(a)
        s.layers.add(b)
        return p
    }

    // ---------------------------------------------------------------- UI construction

    private fun hRow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun icon(name: String, tint: Int = C.TEXT, click: () -> Unit = {}): IconView {
        val v = IconView(this, name, tint)
        v.onClick = click
        return v
    }

    private fun addIcon(parent: LinearLayout, v: IconView, wdp: Int = 44, hdp: Int = 48) {
        parent.addView(v, LinearLayout.LayoutParams(dp(wdp), dp(hdp)))
    }

    private fun spacer(): View = View(this)

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(C.BG)
        root.fitsSystemWindows = true

        // top bar
        val top = hRow()
        top.setPadding(dp(4), 0, dp(4), 0)
        addIcon(top, icon("back", C.AMBER) { onBack() })
        titleView = TextView(this)
        titleView.setTextColor(C.TEXT)
        titleView.textSize = 18f
        titleView.typeface = Typeface.DEFAULT_BOLD
        titleView.maxLines = 1
        top.addView(titleView, LinearLayout.LayoutParams(0, WRAP, 1f))
        addIcon(top, icon("cube") { showSceneDialog() })
        val guidesIcon = icon("dots")
        guidesIcon.onClick = {
            overlay.guides = !overlay.guides
            guidesIcon.tint = if (overlay.guides) C.GREEN else C.TEXT
            guidesIcon.invalidate()
            overlay.invalidate()
        }
        addIcon(top, guidesIcon)
        addIcon(top, icon("dup") { duplicateLayer() })
        addIcon(top, icon("more") { showMenu() })
        root.addView(top, LinearLayout.LayoutParams(MATCH, dp(52)))

        // preview
        val previewBox = FrameLayout(this)
        previewBox.setBackgroundColor(0xFF161618.toInt())
        aspect = AspectLayout(this)
        preview = PreviewView(this)
        overlay = OverlayView(this, this)
        aspect.addView(preview, MATCH, MATCH)
        aspect.addView(overlay, MATCH, MATCH)
        previewBox.addView(aspect, MATCH, MATCH)
        root.addView(previewBox, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // transport
        val tr = hRow()
        tr.setBackgroundColor(C.BG)
        tr.setPadding(dp(6), 0, dp(6), 0)
        addIcon(tr, icon("fit") { timeline.fitToScene() })
        qualityChip = ChipView(this, "Full")
        qualityChip.onClick = { cycleQuality() }
        tr.addView(qualityChip, LinearLayout.LayoutParams(dp(56), dp(48)))
        markIcon = icon("bookmark") { toggleMarker() }
        addIcon(tr, markIcon)
        tr.addView(spacer(), LinearLayout.LayoutParams(0, 1, 1f))
        val prev = icon("prev") { stepFrame(-1) }
        prev.onLong = { jump(-1) }
        addIcon(tr, prev, 48)
        playIcon = icon("play") { togglePlay() }
        addIcon(tr, playIcon, 52)
        val next = icon("next") { stepFrame(1) }
        next.onLong = { jump(1) }
        addIcon(tr, next, 48)
        tr.addView(spacer(), LinearLayout.LayoutParams(0, 1, 1f))
        addIcon(tr, icon("layers") { showAddLayer() })
        addIcon(tr, icon("undo") { doUndo() })
        addIcon(tr, icon("redo") { doRedo() })
        root.addView(tr, LinearLayout.LayoutParams(MATCH, dp(48)))

        // timeline
        timeline = TimelineView(this, this)
        root.addView(timeline, LinearLayout.LayoutParams(MATCH, dp(176)))

        // effects panel
        panelBox = LinearLayout(this)
        panelBox.orientation = LinearLayout.HORIZONTAL
        panelBox.setBackgroundColor(C.PANEL)
        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER_HORIZONTAL
        side.addView(icon("close") { closePanel() }, LinearLayout.LayoutParams(dp(48), dp(52)))
        side.addView(icon("plus", C.GREEN) { showAddEffect() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        diamondSide = icon("diamond_f", C.DIM) { keyAllRows() }
        side.addView(diamondSide, LinearLayout.LayoutParams(dp(48), dp(48)))
        side.addView(icon("graph", C.DIM) { cycleEase() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        side.addView(icon("box", C.DIM) { showPresets() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        side.addView(icon("more", C.DIM) { showPanelMenu() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        panelBox.addView(side, LinearLayout.LayoutParams(dp(52), MATCH))
        val sv = ScrollView(this)
        panelList = LinearLayout(this)
        panelList.orientation = LinearLayout.VERTICAL
        panelList.setPadding(dp(4), dp(6), dp(8), dp(12))
        sv.addView(panelList, MATCH, WRAP)
        panelBox.addView(sv, LinearLayout.LayoutParams(0, MATCH, 1f))
        panelBox.visibility = View.GONE
        root.addView(panelBox, LinearLayout.LayoutParams(MATCH, dp(280)))

        setContentView(root)
    }

    // ---------------------------------------------------------------- helpers

    private fun selected(): Layer? = Editor.scene.layers.firstOrNull { it.id == selectedId }

    private fun render() {
        preview.requestRender()
        overlay.invalidate()
        timeline.invalidate()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun refreshAll() {
        aspect.ratio = Editor.project.w.toFloat() / Editor.project.h.toFloat()
        if (selected() == null) {
            selectedId = -1
            panelOpen = false
            panelBox.visibility = View.GONE
        }
        refreshTitle()
        refreshPanel()
        onTimeChanged()
    }

    private fun refreshTitle() {
        val l = selected()
        titleView.text = l?.name ?: Editor.scene.name
    }

    private fun onTimeChanged() {
        syncRows()
        val has = Editor.scene.markers.any { Math.abs(it - Editor.time) < 0.02f }
        markIcon.set(if (has) "bookmark_f" else "bookmark", if (has) C.BLUE else C.TEXT)
        render()
    }

    private fun onBack() {
        if (panelOpen) closePanel() else finish()
    }

    // ---------------------------------------------------------------- playback

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            if (!playing) return
            if (lastNs != 0L) {
                var t = Editor.time + (ns - lastNs) / 1e9f
                if (t > Editor.scene.duration) t = 0f
                Editor.time = t
                onTimeChanged()
            }
            lastNs = ns
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun togglePlay() {
        playing = !playing
        playIcon.set(if (playing) "pause" else "play", C.TEXT)
        if (playing) { lastNs = 0L; Choreographer.getInstance().postFrameCallback(frameCb) }
    }

    private fun stepFrame(dir: Int) {
        val fps = Editor.project.fps
        val t = Editor.time + dir / fps.toFloat()
        Editor.time = t.coerceIn(0f, Editor.scene.duration)
        onTimeChanged()
    }

    private fun jump(dir: Int) {
        val times = ArrayList<Float>()
        times.addAll(Editor.scene.markers)
        selected()?.let { l -> for ((_, tr) in l.props) for (k in tr.keys) times.add(k.t) }
        times.sort()
        val now = Editor.time
        val target = if (dir > 0) times.firstOrNull { it > now + 0.02f } else times.lastOrNull { it < now - 0.02f }
        if (target != null) { Editor.time = target; onTimeChanged() }
    }

    private fun toggleMarker() {
        val ms = Editor.scene.markers
        val ex = ms.firstOrNull { Math.abs(it - Editor.time) < 0.02f }
        pushUndo()
        if (ex != null) ms.remove(ex) else ms.add(Editor.time)
        onTimeChanged()
    }

    private fun cycleQuality() {
        quality = when (quality) { 1 -> 2; 2 -> 4; else -> 1 }
        preview.quality = quality
        qualityChip.text = when (quality) { 1 -> "Full"; 2 -> "1/2"; else -> "1/4" }
        qualityChip.invalidate()
        render()
    }

    // ---------------------------------------------------------------- undo / redo

    private fun snapshot(): String = Store.toJson(Editor.project).toString()

    private fun pushUndo() {
        val s = snapshot()
        if (undo.lastOrNull() == s) return
        undo.add(s)
        if (undo.size > 60) undo.removeAt(0)
        redo.clear()
    }

    private fun restore(js: String) {
        val p = Store.fromJson(JSONObject(js))
        Editor.project = p
        if (Editor.sceneIndex >= p.scenes.size) Editor.sceneIndex = p.scenes.size - 1
        Editor.time = Editor.time.coerceIn(0f, Editor.scene.duration)
        refreshAll()
    }

    private fun doUndo() {
        if (undo.isEmpty()) { toast("Nothing to undo"); return }
        redo.add(snapshot())
        restore(undo.removeAt(undo.size - 1))
    }

    private fun doRedo() {
        if (redo.isEmpty()) { toast("Nothing to redo"); return }
        undo.add(snapshot())
        restore(redo.removeAt(redo.size - 1))
    }

    // ---------------------------------------------------------------- EditHost / TimelineHost

    override fun selectedLayer(): Layer? = selected()
    override fun autoKey(): Boolean = autoKey
    override fun beginEdit() { pushUndo() }
    override fun onEdited() { syncRows(); render() }

    override fun selectedId(): Int = selectedId
    override fun onSeek(t: Float) { Editor.time = t; onTimeChanged() }
    override fun onSelect(id: Int) {
        selectedId = id
        refreshTitle()
        if (id >= 0) openPanel() else closePanel()
        render()
    }
    override fun onToggleVisible(l: Layer) { pushUndo(); l.visible = !l.visible; render() }
    override fun onTimingChanged() { render() }

    // ---------------------------------------------------------------- layers

    private fun addLayer(type: LayerType, imagePath: String? = null) {
        pushUndo()
        val p = Editor.project
        val s = Editor.scene
        val id = p.nextId++
        val nm = when (type) { LayerType.SHAPE -> "Shape"; LayerType.TEXT -> "Text"; LayerType.IMAGE -> "Image" }
        val l = Layer(id, nm + " " + id, type)
        l.end = s.duration
        l.imagePath = imagePath
        if (type == LayerType.TEXT) l.color = 0xFFFFFFFF.toInt()
        s.layers.add(l)
        selectedId = id
        refreshTitle()
        openPanel()
        render()
    }

    private fun duplicateLayer() {
        val l = selected() ?: run { toast("Select a layer first"); return }
        pushUndo()
        val p = Editor.project
        val id = p.nextId++
        val c = Layer(id, l.name + " copy", l.type)
        c.text = l.text; c.color = l.color; c.shape = l.shape; c.imagePath = l.imagePath
        c.start = l.start; c.end = l.end; c.visible = l.visible
        c.fx.addAll(l.fx); c.fxOff.addAll(l.fxOff)
        for ((k, tr) in l.props) {
            val n = c.props[k]!!
            n.base = tr.base
            for (key in tr.keys) n.keys.add(Key(key.t, key.v, key.ease))
        }
        c.props["x"]!!.base = c.props["x"]!!.base + 0.1f
        Editor.scene.layers.add(c)
        selectedId = id
        refreshTitle(); refreshPanel(); render()
    }

    private fun deleteLayer() {
        val l = selected() ?: return
        pushUndo()
        Editor.scene.layers.remove(l)
        selectedId = -1
        closePanel()
        refreshTitle(); render()
    }

    private fun moveLayer(dir: Int) {
        val l = selected() ?: return
        pushUndo()
        val ls = Editor.scene.layers
        val i = ls.indexOf(l)
        val j = i + dir
        if (j < 0 || j >= ls.size) return
        ls.removeAt(i)
        ls.add(j, l)
        render()
    }

    private fun showAddLayer() {
        val items = arrayOf("Shape", "Text", "Image from gallery")
        AlertDialog.Builder(this).setTitle("Add layer").setItems(items) { _, which ->
            when (which) {
                0 -> addLayer(LayerType.SHAPE)
                1 -> addLayer(LayerType.TEXT)
                else -> {
                    val i = Intent(Intent.ACTION_GET_CONTENT)
                    i.type = "image/*"
                    startActivityForResult(i, REQ_IMG)
                }
            }
        }.show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req == REQ_IMG && res == RESULT_OK && uri != null) {
            try {
                val f = File(filesDir, "img_" + System.currentTimeMillis() + ".bin")
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                addLayer(LayerType.IMAGE, f.absolutePath)
            } catch (e: Exception) {
                toast("Could not load image")
            }
        }
    }

    private fun showMenu() {
        val items = arrayOf("Export video", "Scene setup", "Move layer up", "Move layer down", "Delete layer")
        AlertDialog.Builder(this).setItems(items) { _, which ->
            when (which) {
                0 -> doExport()
                1 -> showSceneDialog()
                2 -> moveLayer(1)
                3 -> moveLayer(-1)
                else -> deleteLayer()
            }
        }.show()
    }

    // ---------------------------------------------------------------- panel

    private fun openPanel() {
        if (selected() == null) return
        panelOpen = true
        panelBox.visibility = View.VISIBLE
        refreshPanel()
    }

    private fun closePanel() {
        panelOpen = false
        panelBox.visibility = View.GONE
        if (selectedId != -1) { selectedId = -1; refreshTitle(); render() }
    }

    private fun header(title: String, key: String, l: Layer, effectId: String?): View {
        val isOpen = expanded.contains(l.id.toString() + ":" + key)
        val bar = hRow()
        bar.setBackgroundColor(C.CARD)
        bar.setPadding(dp(4), 0, dp(2), 0)
        val h = IconView(this, "handle", C.DIM, 20f)
        bar.addView(h, LinearLayout.LayoutParams(dp(36), dp(48)))
        val t = TextView(this)
        t.text = title
        t.setTextColor(C.TEXT)
        t.textSize = 16f
        t.typeface = Typeface.DEFAULT_BOLD
        bar.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (effectId != null) {
            val off = l.fxOff.contains(effectId)
            val eye = IconView(this, if (off) "eye_off" else "eye", if (off) C.DIM else C.GREEN, 20f)
            eye.onClick = {
                pushUndo()
                if (off) l.fxOff.remove(effectId) else l.fxOff.add(effectId)
                refreshPanel(); render()
            }
            bar.addView(eye, LinearLayout.LayoutParams(dp(40), dp(48)))
        }
        val chev = IconView(this, if (isOpen) "chev_up" else "chev_down", C.DIM, 20f)
        chev.onClick = {
            val k = l.id.toString() + ":" + key
            if (!expanded.remove(k)) expanded.add(k)
            refreshPanel()
        }
        bar.addView(chev, LinearLayout.LayoutParams(dp(40), dp(48)))
        if (effectId != null) {
            val del = IconView(this, "trash", C.RED, 20f)
            del.onClick = {
                pushUndo()
                l.fx.remove(effectId); l.fxOff.remove(effectId)
                refreshPanel(); render()
            }
            bar.addView(del, LinearLayout.LayoutParams(dp(40), dp(48)))
        }
        return bar
    }

    private fun cardWrap(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, 0, 0, dp(6))
        c.layoutParams = lp
        return c
    }

    private fun refreshPanel() {
        panelList.removeAllViews()
        rows.clear()
        val l = selected()
        if (l == null) return
        val idp = l.id.toString() + ":"

        // Transform
        var c = cardWrap()
        c.addView(header("Transform", "transform", l, null))
        if (expanded.contains(idp + "transform")) for (d in Defs.transform) addRow(c, l, d)
        panelList.addView(c)

        // 3D
        c = cardWrap()
        c.addView(header("3D Rotation", "rot3d", l, null))
        if (expanded.contains(idp + "rot3d")) {
            for (d in Defs.rot3d) addRow(c, l, d)
            val b = hRow()
            for (axis in arrayOf("rotX", "rotY", "rotZ")) {
                val pb = PillButton(this, "Spin " + axis.last(), null, C.CARD2, C.TEXT)
                pb.onClick = { spin(l, axis) }
                val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
                lp.setMargins(dp(3), dp(4), dp(3), dp(4))
                b.addView(pb, lp)
            }
            c.addView(b)
        }
        panelList.addView(c)

        // Layer
        c = cardWrap()
        c.addView(header("Layer", "layer", l, null))
        if (expanded.contains(idp + "layer")) {
            val dur = Editor.scene.duration
            addPlain(c, "Start", 0f, dur, l.start, 1) { l.start = minOf(it, l.end - 0.1f); render() }
            addPlain(c, "End", 0f, dur, l.end, 1) { l.end = maxOf(it, l.start + 0.1f); render() }
            val eb = PillButton(this, "Edit content", null, C.CARD2, C.TEXT)
            eb.onClick = { showEdit() }
            val lp = LinearLayout.LayoutParams(MATCH, dp(40))
            lp.setMargins(dp(3), dp(4), dp(3), dp(4))
            c.addView(eb, lp)
            val ak = PillButton(this, if (autoKey) "Auto keyframe: on" else "Auto keyframe: off", null, C.CARD2, if (autoKey) C.GREEN else C.TEXT)
            ak.onClick = { autoKey = !autoKey; refreshPanel() }
            val lp2 = LinearLayout.LayoutParams(MATCH, dp(40))
            lp2.setMargins(dp(3), dp(4), dp(3), dp(4))
            c.addView(ak, lp2)
        }
        panelList.addView(c)

        // Effects
        for (id in l.fx) {
            val def = Defs.effects.firstOrNull { it.id == id } ?: continue
            c = cardWrap()
            c.addView(header(def.label, id, l, id))
            if (expanded.contains(idp + id)) {
                for (d in def.props) addRow(c, l, d)
                if (id == "tile") {
                    val b = hRow()
                    for (axis in arrayOf("tileX", "tileY")) {
                        val pb = PillButton(this, "Scroll " + axis.last(), null, C.CARD2, C.TEXT)
                        pb.onClick = { tileScroll(l, axis) }
                        val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
                        lp.setMargins(dp(3), dp(4), dp(3), dp(4))
                        b.addView(pb, lp)
                    }
                    c.addView(b)
                }
            }
            panelList.addView(c)
        }

        val add = PillButton(this, "Add Effect", "plus", C.GREEN, 0xFF04210F.toInt())
        add.onClick = { showAddEffect() }
        val alp = LinearLayout.LayoutParams(MATCH, dp(48))
        alp.setMargins(dp(24), dp(8), dp(24), dp(8))
        panelList.addView(add, alp)
        syncRows()
    }

    private fun addPlain(parent: LinearLayout, label: String, lo: Float, hi: Float, v: Float, dec: Int, onChange: (Float) -> Unit) {
        val s = RulerSlider(this)
        s.label = label; s.lo = lo; s.hi = hi; s.value = v; s.dec = dec; s.canKey = false
        s.onBegin = { pushUndo() }
        s.onChange = onChange
        val lp = LinearLayout.LayoutParams(MATCH, dp(60))
        lp.setMargins(0, dp(3), 0, dp(3))
        parent.addView(s, lp)
    }

    private fun addRow(parent: LinearLayout, l: Layer, d: PropDef) {
        val tr = l.props[d.key]!!
        val s = RulerSlider(this)
        s.label = d.label; s.lo = d.min; s.hi = d.max; s.dec = d.dec
        s.value = tr.eval(l.editTime(d.key, Editor.time))
        s.onBegin = { pushUndo() }
        s.onChange = { v ->
            tr.set(l.editTime(d.key, Editor.time), v, autoKey)
            syncRows(s)
            render()
        }
        s.onLabelTap = {
            pushUndo()
            tr.toggleKey(l.editTime(d.key, Editor.time))
            syncRows(); render()
        }
        val lp = LinearLayout.LayoutParams(MATCH, dp(60))
        lp.setMargins(0, dp(3), 0, dp(3))
        parent.addView(s, lp)
        rows.add(Row(s, d, l))
    }

    private fun syncRows(except: RulerSlider? = null) {
        for (r in rows) {
            val tr = r.layer.props[r.d.key] ?: continue
            val t = r.layer.editTime(r.d.key, Editor.time)
            if (r.slider !== except) r.slider.value = tr.eval(t)
            r.slider.hasKey = tr.keyAt(t) != null
            r.slider.hasAnim = tr.keys.isNotEmpty()
            r.slider.invalidate()
        }
        val any = rows.any { it.slider.hasKey }
        diamondSide.set("diamond_f", if (any) C.GREEN else C.DIM)
    }

    private fun keyAllRows() {
        if (rows.isEmpty()) { toast("Expand a section first"); return }
        pushUndo()
        val allKeyed = rows.all { it.slider.hasKey }
        for (r in rows) {
            val tr = r.layer.props[r.d.key] ?: continue
            val t = r.layer.editTime(r.d.key, Editor.time)
            val has = tr.keyAt(t) != null
            if (allKeyed && has) tr.toggleKey(t) else if (!allKeyed && !has) tr.toggleKey(t)
        }
        syncRows(); render()
    }

    private fun cycleEase() {
        if (selected() == null) return
        pushUndo()
        var chosen: Ease? = null
        for (r in rows) {
            val tr = r.layer.props[r.d.key] ?: continue
            val k = tr.keyAt(r.layer.editTime(r.d.key, Editor.time)) ?: continue
            val n = chosen ?: Ease.values()[(k.ease.ordinal + 1) % Ease.values().size]
            chosen = n
            k.ease = n
        }
        val shown = chosen
        if (shown == null) toast("Add a keyframe at the playhead first")
        else toast("Easing: " + shown.name.replace('_', ' ').lowercase())
        render()
    }

    private fun spin(l: Layer, key: String) {
        pushUndo()
        val tr = l.props[key]!!
        tr.keys.clear()
        tr.keys.add(Key(l.start, 0f, Ease.LINEAR))
        tr.keys.add(Key(l.end, 360f, Ease.LINEAR))
        syncRows(); render()
    }

    private fun tileScroll(l: Layer, key: String) {
        pushUndo()
        val tr = l.props[key]!!
        val mirror = l.props["tileMirror"]!!.eval(Editor.time) >= 0.5f
        tr.keys.clear()
        tr.keys.add(Key(l.start, 0f, Ease.LINEAR))
        tr.keys.add(Key(l.end, if (mirror) 2f else 1f, Ease.LINEAR))
        syncRows(); render()
    }

    private fun addEffect(l: Layer, id: String) {
        if (!l.fx.contains(id)) l.fx.add(id)
        l.fxOff.remove(id)
        expanded.add(l.id.toString() + ":" + id)
    }

    private fun showAddEffect() {
        val l = selected() ?: run { toast("Select a layer first"); return }
        val names = Defs.effects.map { it.label }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Add effect").setItems(names) { _, which ->
            pushUndo()
            addEffect(l, Defs.effects[which].id)
            refreshPanel(); render()
        }.show()
    }

    private fun showPresets() {
        val l = selected() ?: run { toast("Select a layer first"); return }
        val items = arrayOf("3D spin (Y axis loop)", "Motion tile scroll", "Pendulum swing", "Slow motion then reverse", "Glitch (RGB split + shake)")
        AlertDialog.Builder(this).setTitle("Presets").setItems(items) { _, which ->
            pushUndo()
            when (which) {
                0 -> spin(l, "rotY")
                1 -> {
                    addEffect(l, "tile")
                    l.props["tileMirror"]!!.base = 0f
                    tileScroll(l, "tileX")
                    l.props["scale"]!!.base = 0.4f
                }
                2 -> addEffect(l, "swing")
                3 -> {
                    addEffect(l, "remap")
                    val sp = l.props["remapSpeed"]!!
                    sp.keys.clear()
                    val mid = (l.start + l.end) / 2f
                    sp.keys.add(Key(l.start, 0.4f, Ease.EASE_IN_OUT))
                    sp.keys.add(Key(mid, 1f, Ease.EASE_IN_OUT))
                    sp.keys.add(Key(l.end, -1f, Ease.EASE_IN_OUT))
                }
                else -> { addEffect(l, "rgb"); addEffect(l, "shake") }
            }
            refreshPanel(); render()
        }.show()
    }

    private fun showPanelMenu() {
        val l = selected() ?: return
        val items = arrayOf("Clear all keyframes", "Reset transform")
        AlertDialog.Builder(this).setItems(items) { _, which ->
            pushUndo()
            for ((k, tr) in l.props) {
                if (which == 0) tr.keys.clear()
                else if (Defs.transform.any { it.key == k } || Defs.rot3d.any { it.key == k }) {
                    tr.keys.clear()
                    tr.base = Defs.all.first { it.key == k }.def
                }
            }
            refreshPanel(); render()
        }.show()
    }

    // ---------------------------------------------------------------- dialogs

    private fun colorRow(onPick: (Int) -> Unit): View {
        val colors = intArrayOf(0xFF7C4DFF.toInt(), 0xFFFF4081.toInt(), 0xFFF44336.toInt(), 0xFFFF9800.toInt(),
            0xFFFFEB3B.toInt(), 0xFF22C55E.toInt(), 0xFF00E5FF.toInt(), 0xFF2979FF.toInt(), 0xFFFFFFFF.toInt(), 0xFF000000.toInt())
        val row = hRow()
        for (col in colors) {
            val v = View(this)
            v.setBackgroundColor(col)
            v.setOnClickListener { onPick(col) }
            val lp = LinearLayout.LayoutParams(dp(34), dp(34))
            lp.setMargins(dp(3), dp(6), dp(3), dp(6))
            row.addView(v, lp)
        }
        val sv = HorizontalScrollView(this)
        sv.addView(row)
        return sv
    }

    private fun showEdit() {
        val l = selected() ?: return
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(8), dp(20), dp(8))
        if (l.type == LayerType.TEXT) {
            val et = EditText(this)
            et.setText(l.text)
            et.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { l.text = s?.toString() ?: ""; render() }
            })
            box.addView(et)
        }
        if (l.type == LayerType.SHAPE) {
            val names = ShapeKind.values().map { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }.toTypedArray()
            val sv = HorizontalScrollView(this)
            val row = hRow()
            for ((i, nm) in names.withIndex()) {
                val b = PillButton(this, nm, null, C.CARD2, C.TEXT)
                b.onClick = { l.shape = ShapeKind.values()[i]; render() }
                val lp = LinearLayout.LayoutParams(dp(92), dp(40))
                lp.setMargins(dp(3), dp(4), dp(3), dp(4))
                row.addView(b, lp)
            }
            sv.addView(row)
            box.addView(sv)
        }
        if (l.type != LayerType.IMAGE) box.addView(colorRow { col -> l.color = col; render() })
        AlertDialog.Builder(this).setTitle("Edit " + l.name).setView(box)
            .setPositiveButton("Done") { _, _ -> pushUndo() }.show()
    }

    private fun ruler(parent: LinearLayout, label: String, lo: Float, hi: Float, v: Float, dec: Int, onChange: (Float) -> Unit) {
        val s = RulerSlider(this)
        s.label = label; s.lo = lo; s.hi = hi; s.value = v; s.dec = dec; s.canKey = false
        s.onChange = onChange
        val lp = LinearLayout.LayoutParams(MATCH, dp(60))
        lp.setMargins(0, dp(4), 0, dp(4))
        parent.addView(s, lp)
    }

    private fun showSceneDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(8), dp(16), dp(8))
        val sv = ScrollView(this)
        sv.addView(box)
        val dlg = AlertDialog.Builder(this).setTitle("Scene setup").setView(sv)
            .setPositiveButton("Done", null).create()

        fun section(text: String) {
            val tv = TextView(this)
            tv.text = text
            tv.setTextColor(C.GREEN)
            tv.textSize = 13f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setPadding(0, dp(12), 0, dp(4))
            box.addView(tv)
        }

        fun chips(labels: List<String>, selectedIdx: Int, onPick: (Int) -> Unit) {
            val hs = HorizontalScrollView(this)
            val row = hRow()
            for ((i, nm) in labels.withIndex()) {
                val on = i == selectedIdx
                val b = PillButton(this, nm, null, if (on) C.GREEN else C.CARD2, if (on) 0xFF04210F.toInt() else C.TEXT)
                b.onClick = { onPick(i) }
                val lp = LinearLayout.LayoutParams(dp(86), dp(40))
                lp.setMargins(dp(3), dp(4), dp(3), dp(4))
                row.addView(b, lp)
            }
            hs.addView(row)
            box.addView(hs)
        }

        fun build() {
            box.removeAllViews()
            val p = Editor.project
            val s = Editor.scene
            section("Scenes")
            val names = p.scenes.map { it.name } + listOf("New scene")
            chips(names, Editor.sceneIndex) { i ->
                pushUndo()
                if (i == p.scenes.size) {
                    val ns = Scene("Scene " + (p.scenes.size + 1))
                    p.scenes.add(ns)
                    Editor.sceneIndex = p.scenes.size - 1
                } else Editor.sceneIndex = i
                Editor.time = 0f
                selectedId = -1
                closePanel()
                refreshAll()
                build()
            }
            if (p.scenes.size > 1) {
                val del = PillButton(this, "Delete this scene", null, C.CARD2, C.RED)
                del.onClick = {
                    pushUndo()
                    p.scenes.remove(s)
                    Editor.sceneIndex = 0
                    Editor.time = 0f
                    selectedId = -1
                    closePanel()
                    refreshAll()
                    build()
                }
                val lp = LinearLayout.LayoutParams(MATCH, dp(40))
                lp.setMargins(dp(3), dp(6), dp(3), dp(4))
                box.addView(del, lp)
            }

            section("Canvas")
            val sizes = listOf("16:9" to intArrayOf(1280, 720), "9:16" to intArrayOf(720, 1280), "1:1" to intArrayOf(1024, 1024),
                "4:5" to intArrayOf(864, 1080), "21:9" to intArrayOf(1280, 544))
            val cur = sizes.indexOfFirst { it.second[0] == p.w && it.second[1] == p.h }
            chips(sizes.map { it.first }, cur) { i ->
                pushUndo()
                p.w = sizes[i].second[0]; p.h = sizes[i].second[1]
                refreshAll()
                build()
            }

            section("Frame rate")
            val fpsList = listOf(24, 30, 60)
            chips(fpsList.map { it.toString() + " fps" }, fpsList.indexOf(p.fps)) { i ->
                pushUndo(); p.fps = fpsList[i]; build()
            }

            section("Timing and camera")
            ruler(box, "Duration (s)", 1f, 30f, s.duration, 1) { v ->
                val old = s.duration
                val nv = Math.round(v * 2f) / 2f
                s.duration = maxOf(1f, nv)
                for (l in s.layers) if (l.end >= old - 0.001f) l.end = s.duration
                Editor.time = Editor.time.coerceIn(0f, s.duration)
                onTimeChanged()
            }
            ruler(box, "3D camera FOV", 15f, 90f, s.fov, 0) { v -> s.fov = v; render() }

            section("Background")
            box.addView(colorRow { col -> s.bg = col; render() })
        }
        build()
        dlg.show()
    }

    private fun doExport() {
        if (playing) togglePlay()
        val tv = TextView(this)
        tv.text = "Rendering 0%"
        tv.textSize = 16f
        tv.setPadding(dp(24), dp(24), dp(24), dp(24))
        val dlg = AlertDialog.Builder(this).setTitle("Exporting video").setView(tv).setCancelable(false).show()
        Exporter(applicationContext, Editor.project, { pct ->
            runOnUiThread { tv.text = "Rendering " + pct + "%" }
        }, { loc, err ->
            runOnUiThread {
                dlg.dismiss()
                if (err != null) toast("Export failed: " + err) else toast("Saved to " + loc)
            }
        }).start()
    }
}
