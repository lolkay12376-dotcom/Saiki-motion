package com.saiki.motion

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CopyOnWriteArraySet
import kotlin.math.abs

enum class Ease { LINEAR, EASE_IN, EASE_OUT, EASE_IN_OUT, BOUNCE }

fun applyEase(e: Ease, u: Float): Float = when (e) {
    Ease.LINEAR -> u
    Ease.EASE_IN -> u * u
    Ease.EASE_OUT -> 1f - (1f - u) * (1f - u)
    Ease.EASE_IN_OUT -> if (u < 0.5f) 2f * u * u else 1f - 2f * (1f - u) * (1f - u)
    Ease.BOUNCE -> {
        val n = 7.5625f
        val d = 2.75f
        when {
            u < 1f / d -> n * u * u
            u < 2f / d -> { val x = u - 1.5f / d; n * x * x + 0.75f }
            u < 2.5f / d -> { val x = u - 2.25f / d; n * x * x + 0.9375f }
            else -> { val x = u - 2.625f / d; n * x * x + 0.984375f }
        }
    }
}

class Key(var t: Float, var v: Float, var ease: Ease = Ease.EASE_IN_OUT)

/** An animatable value: constant `base` or interpolated keyframes. */
class Track(var base: Float) {
    val keys = CopyOnWriteArrayList<Key>()

    fun eval(t: Float): Float {
        val ks = keys
        val n = ks.size
        if (n == 0) return base
        if (t <= ks[0].t) return ks[0].v
        if (t >= ks[n - 1].t) return ks[n - 1].v
        for (i in 0 until n - 1) {
            val a = ks[i]
            val b = ks[i + 1]
            if (t >= a.t && t <= b.t) {
                val u = (t - a.t) / (b.t - a.t)
                return a.v + (b.v - a.v) * applyEase(a.ease, u)
            }
        }
        return base
    }

    fun keyAt(t: Float): Key? = keys.firstOrNull { abs(it.t - t) < 0.03f }

    fun set(t: Float, v: Float, autoKey: Boolean) {
        if (!autoKey && keys.isEmpty()) { base = v; return }
        val k = keyAt(t)
        if (k != null) k.v = v else { keys.add(Key(t, v)); keys.sortBy { it.t } }
    }

    fun toggleKey(t: Float) {
        val k = keyAt(t)
        if (k != null) {
            keys.remove(k)
            if (keys.isEmpty()) base = k.v
        } else {
            val v = eval(t)
            keys.add(Key(t, v))
            keys.sortBy { it.t }
        }
    }

    fun toJson(): JSONObject {
        val arr = JSONArray()
        for (k in keys) arr.put(JSONObject().put("t", k.t.toDouble()).put("v", k.v.toDouble()).put("e", k.ease.name))
        return JSONObject().put("b", base.toDouble()).put("k", arr)
    }

    fun load(o: JSONObject) {
        base = o.optDouble("b", base.toDouble()).toFloat()
        keys.clear()
        val a = o.optJSONArray("k") ?: return
        for (i in 0 until a.length()) {
            val j = a.getJSONObject(i)
            keys.add(Key(j.getDouble("t").toFloat(), j.getDouble("v").toFloat(),
                Ease.valueOf(j.optString("e", "EASE_IN_OUT"))))
        }
    }
}

class PropDef(val key: String, val label: String, val min: Float, val max: Float, val def: Float, val dec: Int = 2)
class EffectDef(val id: String, val label: String, val props: List<PropDef>)

object Defs {
    val transform = listOf(
        PropDef("x", "Position X", -2.5f, 2.5f, 0f),
        PropDef("y", "Position Y", -2.5f, 2.5f, 0f),
        PropDef("scale", "Scale", 0.05f, 4f, 1f),
        PropDef("opacity", "Opacity", 0f, 1f, 1f),
        PropDef("rotZ", "Rotate Z (roll)", -360f, 360f, 0f)
    )
    val rot3d = listOf(
        PropDef("rotX", "Rotate X (tilt)", -360f, 360f, 0f),
        PropDef("rotY", "Rotate Y (turn)", -360f, 360f, 0f)
    )
    val effects = listOf(
        EffectDef("tile", "Motion Tile", listOf(
            PropDef("tileX", "Phase X", -4f, 4f, 0f),
            PropDef("tileY", "Phase Y", -4f, 4f, 0f),
            PropDef("tileGap", "Gap", -0.5f, 2f, 0f),
            PropDef("tileNX", "Tiles X", 0f, 6f, 2f, 0),
            PropDef("tileNY", "Tiles Y", 0f, 6f, 2f, 0),
            PropDef("tileMirror", "Mirror", 0f, 1f, 0f, 0)
        )),
        EffectDef("remap", "Time Remap", listOf(
            PropDef("remapSpeed", "Speed", -4f, 4f, 1f),
            PropDef("remapLoop", "Loop Length", 0f, 10f, 0f),
            PropDef("remapPing", "Ping-Pong", 0f, 1f, 0f, 0)
        )),
        EffectDef("swing", "Swing", listOf(
            PropDef("swingSpeed", "Speed", 0f, 30f, 7f, 0),
            PropDef("swingAngle", "Swing Angle", 0f, 90f, 17f, 0),
            PropDef("swingPX", "Pivot X", -100f, 100f, 0f, 0),
            PropDef("swingPY", "Pivot Y", -100f, 100f, 100f, 0)
        )),
        EffectDef("rgb", "RGB Split", listOf(PropDef("rgb", "Amount", 0f, 1f, 0.5f))),
        EffectDef("blur", "Blur", listOf(PropDef("blur", "Amount", 0f, 1f, 0.5f))),
        EffectDef("wave", "Wave Warp", listOf(PropDef("wave", "Amount", 0f, 1f, 0.5f))),
        EffectDef("pix", "Pixelate", listOf(PropDef("pix", "Amount", 0f, 1f, 0.5f))),
        EffectDef("gray", "Grayscale", listOf(PropDef("gray", "Amount", 0f, 1f, 1f))),
        EffectDef("inv", "Invert", listOf(PropDef("inv", "Amount", 0f, 1f, 1f))),
        EffectDef("shake", "Shake", listOf(PropDef("shake", "Amount", 0f, 1f, 0.4f)))
    )
    val all: List<PropDef> = transform + rot3d + effects.flatMap { it.props }
}

enum class LayerType { SHAPE, TEXT, IMAGE }
enum class ShapeKind { RECT, ROUND, CIRCLE, TRIANGLE, STAR }

class Layer(val id: Int, var name: String, var type: LayerType) {
    var text = "Saiki Motion"
    var color = 0xFF7C4DFF.toInt()
    var shape = ShapeKind.ROUND
    var imagePath: String? = null
    var start = 0f
    var end = 5f
    var visible = true
    @Volatile var texAspect = 1f
    val props = LinkedHashMap<String, Track>().also { m -> Defs.all.forEach { m[it.key] = Track(it.def) } }
    val fx = CopyOnWriteArrayList<String>()        // effects added to this layer, in order
    val fxOff = CopyOnWriteArraySet<String>()      // effects switched off

    fun p(key: String, t: Float): Float = props[key]!!.eval(t)
    fun texKey(): String = "$type|$text|$color|$shape|$imagePath"
    fun fxOn(id: String): Boolean = fx.contains(id) && !fxOff.contains(id)

    /** Time used to evaluate this layer's animation (Time Remap effect). */
    fun localTime(t: Float): Float {
        if (!fxOn("remap")) return t
        val sp = props["remapSpeed"]!!
        var lt: Float
        if (sp.keys.isEmpty()) {
            lt = start + (t - start) * sp.base
        } else {
            var acc = 0f
            var u = start
            while (u < t) {
                val d = minOf(0.05f, t - u)
                acc += sp.eval(u + d * 0.5f) * d
                u += d
            }
            lt = start + acc
        }
        val loop = props["remapLoop"]!!.eval(t)
        if (loop > 0.05f) {
            val rel = lt - start
            val ping = props["remapPing"]!!.eval(t) >= 0.5f
            if (ping) {
                var m = rel % (2f * loop)
                if (m < 0f) m += 2f * loop
                lt = start + (if (m <= loop) m else 2f * loop - m)
            } else {
                var m = rel % loop
                if (m < 0f) m += loop
                lt = start + m
            }
        }
        return lt
    }

    /** Time at which edits to [key] are keyed. Remap controls live on the composition clock. */
    fun editTime(key: String, t: Float): Float = if (key.startsWith("remap")) t else localTime(t)
}

class Scene(var name: String) {
    var duration = 5f
    var bg = 0xFF101018.toInt()
    var fov = 45f
    val layers = CopyOnWriteArrayList<Layer>()
    val markers = CopyOnWriteArrayList<Float>()
}

class Project {
    var w = 1280
    var h = 720
    var fps = 30
    var nextId = 1
    val scenes = CopyOnWriteArrayList<Scene>()
    init { scenes.add(Scene("Scene 1")) }
}

/** Global editor state shared between UI thread and GL thread. */
object Editor {
    @Volatile var project = Project()
    @Volatile var sceneIndex = 0
    @Volatile var time = 0f
    val scene: Scene
        get() = project.scenes[sceneIndex.coerceIn(0, project.scenes.size - 1)]
}

object Store {
    fun toJson(p: Project): JSONObject {
        val o = JSONObject().put("w", p.w).put("h", p.h).put("fps", p.fps).put("next", p.nextId)
        val sa = JSONArray()
        for (s in p.scenes) {
            val so = JSONObject().put("name", s.name).put("dur", s.duration.toDouble())
                .put("bg", s.bg).put("fov", s.fov.toDouble())
            val la = JSONArray()
            for (l in s.layers) {
                val lo = JSONObject().put("id", l.id).put("name", l.name).put("type", l.type.name)
                    .put("text", l.text).put("color", l.color).put("shape", l.shape.name)
                    .put("img", l.imagePath ?: "").put("start", l.start.toDouble()).put("end", l.end.toDouble())
                lo.put("fx", JSONArray(l.fx.toList()))
                lo.put("fxoff", JSONArray(l.fxOff.toList()))
                lo.put("vis", l.visible)
                val po = JSONObject()
                for ((k, tr) in l.props) po.put(k, tr.toJson())
                lo.put("props", po)
                la.put(lo)
            }
            so.put("layers", la)
            val ma = JSONArray()
            for (m in s.markers) ma.put(m.toDouble())
            so.put("markers", ma)
            sa.put(so)
        }
        o.put("scenes", sa)
        return o
    }

    fun fromJson(o: JSONObject): Project {
        val p = Project()
        p.scenes.clear()
        p.w = o.optInt("w", 1280); p.h = o.optInt("h", 720); p.fps = o.optInt("fps", 30)
        p.nextId = o.optInt("next", 1)
        val sa = o.getJSONArray("scenes")
        for (i in 0 until sa.length()) {
            val so = sa.getJSONObject(i)
            val s = Scene(so.optString("name", "Scene"))
            s.duration = so.optDouble("dur", 5.0).toFloat()
            s.bg = so.optInt("bg", s.bg)
            s.fov = so.optDouble("fov", 45.0).toFloat()
            val mk = so.optJSONArray("markers")
            if (mk != null) for (k in 0 until mk.length()) s.markers.add(mk.getDouble(k).toFloat())
            val la = so.optJSONArray("layers")
            if (la != null) for (j in 0 until la.length()) {
                val lo = la.getJSONObject(j)
                val l = Layer(lo.getInt("id"), lo.optString("name", "Layer"), LayerType.valueOf(lo.getString("type")))
                l.text = lo.optString("text", ""); l.color = lo.optInt("color", l.color)
                l.shape = ShapeKind.valueOf(lo.optString("shape", "ROUND"))
                val img = lo.optString("img", "")
                l.imagePath = if (img.isEmpty()) null else img
                l.start = lo.optDouble("start", 0.0).toFloat(); l.end = lo.optDouble("end", 5.0).toFloat()
                val fa = lo.optJSONArray("fx")
                if (fa != null) for (k in 0 until fa.length()) l.fx.add(fa.getString(k))
                val fo = lo.optJSONArray("fxoff")
                if (fo != null) for (k in 0 until fo.length()) l.fxOff.add(fo.getString(k))
                l.visible = lo.optBoolean("vis", true)
                val po = lo.optJSONObject("props")
                if (po != null) for ((k, tr) in l.props) po.optJSONObject(k)?.let { tr.load(it) }
                s.layers.add(l)
            }
            p.scenes.add(s)
        }
        if (p.scenes.isEmpty()) p.scenes.add(Scene("Scene 1"))
        return p
    }
}
