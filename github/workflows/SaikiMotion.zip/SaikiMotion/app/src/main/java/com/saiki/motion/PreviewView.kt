package com.saiki.motion

import android.content.Context
import android.opengl.GLSurfaceView
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Renders only when something changed (dirty mode) to save battery. */
class PreviewView(ctx: Context) : GLSurfaceView(ctx) {
    private val sr = SceneRenderer()
    @Volatile private var vw = 1
    @Volatile private var vh = 1

    /** 1 = full, 2 = half, 4 = quarter resolution. Lower is faster on heavy scenes. */
    var quality = 1
        set(v) { field = v; applyQuality() }

    init {
        setEGLContextClientVersion(2)
        setRenderer(object : GLSurfaceView.Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) { sr.init() }
            override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) { vw = w; vh = h }
            override fun onDrawFrame(gl: GL10?) {
                try {
                    sr.draw(Editor.project, Editor.scene, Editor.time, vw, vh)
                } catch (e: Exception) {
                    // skip a frame if the project was mutated mid-draw
                }
            }
        })
        renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        applyQuality()
    }

    private fun applyQuality() {
        if (width <= 0 || height <= 0) return
        if (quality <= 1) holder.setSizeFromLayout()
        else holder.setFixedSize(width / quality, height / quality)
    }
}
