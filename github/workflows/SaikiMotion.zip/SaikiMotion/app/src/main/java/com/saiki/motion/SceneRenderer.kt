package com.saiki.motion

import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

/** Shared transform math so the GL renderer and the selection overlay always agree. */
object Xf {
    fun model(l: Layer, lt: Float, qw: Float, qh: Float, out: FloatArray) {
        var x = l.p("x", lt)
        var y = l.p("y", lt)
        if (l.fxOn("shake")) {
            val a = l.p("shake", lt) * 0.08f
            x += sin(lt * 53.1f) * a
            y += cos(lt * 47.3f) * a
        }
        val sc = l.p("scale", lt)
        Matrix.setIdentityM(out, 0)
        Matrix.translateM(out, 0, x, y, 0f)
        Matrix.rotateM(out, 0, l.p("rotX", lt), 1f, 0f, 0f)
        Matrix.rotateM(out, 0, l.p("rotY", lt), 0f, 1f, 0f)
        Matrix.rotateM(out, 0, l.p("rotZ", lt), 0f, 0f, 1f)
        Matrix.scaleM(out, 0, sc, sc, 1f)
        if (l.fxOn("swing")) {
            val ang = sin(lt * l.p("swingSpeed", lt)) * l.p("swingAngle", lt)
            val px = l.p("swingPX", lt) / 100f * qw * 0.5f
            val py = l.p("swingPY", lt) / 100f * qh * 0.5f
            Matrix.translateM(out, 0, px, py, 0f)
            Matrix.rotateM(out, 0, ang, 0f, 0f, 1f)
            Matrix.translateM(out, 0, -px, -py, 0f)
        }
    }

    /** Perspective camera placed so that z=0 plane maps y in [-1,1] to the full height. */
    fun viewProj(fov: Float, aspect: Float, out: FloatArray) {
        val proj = FloatArray(16)
        val view = FloatArray(16)
        Matrix.perspectiveM(proj, 0, fov, aspect, 0.1f, 100f)
        val d = (1.0 / tan(Math.toRadians(fov / 2.0))).toFloat()
        Matrix.setLookAtM(view, 0, 0f, 0f, d, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(out, 0, proj, 0, view, 0)
    }
}

class SceneRenderer {
    private class Tex(val id: Int, val key: String)

    private val texs = HashMap<Int, Tex>()
    private var prog = 0
    private var aPos = 0
    private var aUV = 0
    private var uMVP = 0
    private var uTex = 0
    private var uOpacity = 0
    private var uPix = 0
    private var uRgb = 0
    private var uWave = 0
    private var uGray = 0
    private var uInv = 0
    private var uBlur = 0
    private var uTime = 0

    private val vp = FloatArray(16)
    private val base = FloatArray(16)
    private val model = FloatArray(16)
    private val mvp = FloatArray(16)

    private val quad: FloatBuffer = ByteBuffer.allocateDirect(64).order(ByteOrder.nativeOrder()).asFloatBuffer().also {
        it.put(floatArrayOf(
            -0.5f, 0.5f, 0f, 0f,
            -0.5f, -0.5f, 0f, 1f,
            0.5f, 0.5f, 1f, 0f,
            0.5f, -0.5f, 1f, 1f
        ))
        it.position(0)
    }

    fun init() {
        texs.clear()
        prog = build(VS, FS)
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aUV = GLES20.glGetAttribLocation(prog, "aUV")
        uMVP = GLES20.glGetUniformLocation(prog, "uMVP")
        uTex = GLES20.glGetUniformLocation(prog, "uTex")
        uOpacity = GLES20.glGetUniformLocation(prog, "uOpacity")
        uPix = GLES20.glGetUniformLocation(prog, "uPix")
        uRgb = GLES20.glGetUniformLocation(prog, "uRgb")
        uWave = GLES20.glGetUniformLocation(prog, "uWave")
        uGray = GLES20.glGetUniformLocation(prog, "uGray")
        uInv = GLES20.glGetUniformLocation(prog, "uInv")
        uBlur = GLES20.glGetUniformLocation(prog, "uBlur")
        uTime = GLES20.glGetUniformLocation(prog, "uTime")
    }

    fun draw(p: Project, s: Scene, t: Float, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        val bg = s.bg
        GLES20.glClearColor(Color.red(bg) / 255f, Color.green(bg) / 255f, Color.blue(bg) / 255f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUseProgram(prog)

        Xf.viewProj(s.fov, w.toFloat() / h, vp)

        quad.position(0)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(aPos)
        quad.position(2)
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(aUV)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glUniform1i(uTex, 0)

        for (l in s.layers) {
            if (!l.visible || t < l.start || t > l.end) continue
            drawLayer(l, t)
        }
    }

    private fun drawLayer(l: Layer, t: Float) {
        val tex = texFor(l)
        val qh = LayerBitmaps.baseHeight(l)
        val qw = qh * l.texAspect
        val lt = l.localTime(t)
        Xf.model(l, lt, qw, qh, base)

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex.id)
        GLES20.glUniform1f(uOpacity, l.p("opacity", lt).coerceIn(0f, 1f))
        fun amt(id: String): Float = if (l.fxOn(id)) l.p(id, lt) else 0f
        GLES20.glUniform1f(uPix, amt("pix"))
        GLES20.glUniform1f(uRgb, amt("rgb"))
        GLES20.glUniform1f(uWave, amt("wave"))
        GLES20.glUniform1f(uGray, amt("gray"))
        GLES20.glUniform1f(uInv, amt("inv"))
        GLES20.glUniform1f(uBlur, amt("blur"))
        GLES20.glUniform1f(uTime, lt)

        if (l.fxOn("tile")) {
            val nx = l.p("tileNX", lt).roundToInt().coerceIn(0, 6)
            val ny = l.p("tileNY", lt).roundToInt().coerceIn(0, 6)
            val gap = l.p("tileGap", lt)
            val sx = qw * (1f + gap)
            val sy = qh * (1f + gap)
            val px = l.p("tileX", lt)
            val py = l.p("tileY", lt)
            val fx0 = floor(px)
            val fy0 = floor(py)
            val fracX = px - fx0
            val fracY = py - fy0
            val mirror = l.p("tileMirror", lt) >= 0.5f
            for (j in -ny - 1..ny) {
                for (i in -nx - 1..nx) {
                    val ci = i + fx0.toInt()
                    val cj = j + fy0.toInt()
                    val flipX = mirror && (ci and 1) == 1
                    val flipY = mirror && (cj and 1) == 1
                    drawQuad((i + fracX) * sx, (j + fracY) * sy,
                        if (flipX) -qw else qw, if (flipY) -qh else qh)
                }
            }
        } else {
            drawQuad(0f, 0f, qw, qh)
        }
    }

    private fun drawQuad(ox: Float, oy: Float, sx: Float, sy: Float) {
        System.arraycopy(base, 0, model, 0, 16)
        Matrix.translateM(model, 0, ox, oy, 0f)
        Matrix.scaleM(model, 0, sx, sy, 1f)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(uMVP, 1, false, mvp, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun texFor(l: Layer): Tex {
        val key = l.texKey()
        val old = texs[l.id]
        if (old != null && old.key == key) return old
        if (old != null) GLES20.glDeleteTextures(1, intArrayOf(old.id), 0)
        val bmp = LayerBitmaps.make(l)
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        l.texAspect = bmp.width.toFloat() / bmp.height.toFloat()
        bmp.recycle()
        val t = Tex(ids[0], key)
        texs[l.id] = t
        return t
    }

    private fun build(vs: String, fs: String): Int {
        fun sh(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw RuntimeException("Shader error: " + GLES20.glGetShaderInfoLog(s))
            return s
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, sh(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, sh(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        return p
    }

    companion object {
        private const val VS = """
            uniform mat4 uMVP;
            attribute vec2 aPos;
            attribute vec2 aUV;
            varying vec2 vUV;
            void main() {
                vUV = aUV;
                gl_Position = uMVP * vec4(aPos, 0.0, 1.0);
            }
        """

        private const val FS = """
            precision mediump float;
            varying vec2 vUV;
            uniform sampler2D uTex;
            uniform float uOpacity;
            uniform float uPix;
            uniform float uRgb;
            uniform float uWave;
            uniform float uGray;
            uniform float uInv;
            uniform float uBlur;
            uniform float uTime;
            void main() {
                vec2 uv = vUV;
                uv.x += sin(uv.y * 18.0 + uTime * 6.0) * uWave * 0.06;
                if (uPix > 0.0) {
                    float p = mix(256.0, 6.0, uPix);
                    uv = (floor(uv * p) + 0.5) / p;
                }
                vec4 c;
                if (uBlur > 0.0) {
                    float r = uBlur * 0.05;
                    vec4 acc = vec4(0.0);
                    for (int i = -1; i <= 1; i++) {
                        for (int j = -1; j <= 1; j++) {
                            acc += texture2D(uTex, uv + vec2(float(i), float(j)) * r);
                        }
                    }
                    c = acc / 9.0;
                } else if (uRgb > 0.0) {
                    float o = uRgb * 0.04;
                    vec4 a = texture2D(uTex, uv + vec2(o, 0.0));
                    vec4 b = texture2D(uTex, uv);
                    vec4 d = texture2D(uTex, uv - vec2(o, 0.0));
                    c = vec4(a.r, b.g, d.b, max(a.a, max(b.a, d.a)));
                } else {
                    c = texture2D(uTex, uv);
                }
                float lum = dot(c.rgb, vec3(0.299, 0.587, 0.114));
                c.rgb = mix(c.rgb, vec3(lum) * c.a, uGray);
                c.rgb = mix(c.rgb, vec3(c.a) - c.rgb, uInv);
                gl_FragColor = c * uOpacity;
            }
        """
    }
}
