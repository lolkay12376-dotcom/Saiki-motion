package com.saiki.motion

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.roundToInt

interface TimelineHost {
    fun selectedId(): Int
    fun onSeek(t: Float)
    fun onSelect(id: Int)
    fun onToggleVisible(l: Layer)
    fun beginEdit()
    fun onTimingChanged()
}

/**
 * Timeline with the playhead fixed at the centre. Drag on the ruler or empty space to scrub,
 * pinch to zoom, drag handles of the selected bar to trim, drag its body to move it.
 */
class TimelineView(ctx: Context, private val host: TimelineHost) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    var pxPerSec = 80f * d
    private var scrollY = 0f

    private val rulerH = 36f * d
    private val rowH = 46f * d
    private val leftCol = 46f * d

    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG)
    private val num = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)
    private val barLine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val name = Paint(Paint.ANTI_ALIAS_FLAG)
    private val head = Paint(Paint.ANTI_ALIAS_FLAG)
    private val headTxt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val white = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tri = Path()
    private val r = RectF()

    private var mode = 0 // 0 none, 1 scrub, 2 pending tap, 3 trim start, 4 trim end, 5 move bar, 6 vertical scroll
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var tapLayer: Layer? = null
    private var tapEye: Layer? = null
    private var moved = false

    private val pinch = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(det: ScaleGestureDetector): Boolean {
            pxPerSec = (pxPerSec * det.scaleFactor).coerceIn(10f * d, 900f * d)
            invalidate()
            return true
        }
    })

    init {
        bgP.color = C.BG
        tick.strokeWidth = 1f * d
        tick.color = 0xFF55555E.toInt()
        num.color = C.DIM
        num.textSize = 11f * d
        num.textAlign = Paint.Align.CENTER
        barLine.style = Paint.Style.STROKE
        barLine.strokeWidth = 2f * d
        barLine.color = 0xFFFFFFFF.toInt()
        name.color = 0xFFFFFFFF.toInt()
        name.textSize = 12f * d
        name.typeface = Typeface.DEFAULT_BOLD
        head.color = C.GREEN
        headTxt.color = 0xFF04210F.toInt()
        headTxt.textSize = 12f * d
        headTxt.typeface = Typeface.DEFAULT_BOLD
        headTxt.textAlign = Paint.Align.CENTER
        white.color = 0xFFFFFFFF.toInt()
    }

    fun fitToScene() {
        val usable = width - leftCol - 24f * d
        if (usable > 0) pxPerSec = (usable / Editor.scene.duration).coerceIn(10f * d, 900f * d)
        invalidate()
    }

    private fun cx() = width / 2f
    private fun tx(t: Float) = cx() + (t - Editor.time) * pxPerSec
    private fun xt(x: Float) = Editor.time + (x - cx()) / pxPerSec

    fun timecode(t: Float): String {
        val fps = Editor.project.fps
        val total = (t * fps).roundToInt()
        val f = total % fps
        val s = (total / fps) % 60
        val m = total / fps / 60
        return String.format("%02d:%02d:%02d", m, s, f)
    }

    private fun rowAt(y: Float): Int {
        if (y < rulerH) return -1
        return floor((y - rulerH + scrollY) / rowH).toInt()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val scene = Editor.scene
        val layers = scene.layers
        c.drawRect(0f, 0f, w, h, bgP)

        // ruler
        val minPx = 56f * d
        val steps = floatArrayOf(0.1f, 0.2f, 0.5f, 1f, 2f, 5f, 10f, 30f, 60f)
        var step = 60f
        for (s in steps) if (s * pxPerSec >= minPx) { step = s; break }
        val t0 = xt(0f)
        val t1 = xt(w)
        var t = floor(t0 / step) * step
        while (t <= t1) {
            if (t >= -0.0001f) {
                val x = tx(t)
                c.drawLine(x, rulerH - 14f * d, x, rulerH, tick)
                val label = if (step >= 1f) String.format("%d", t.roundToInt()) else String.format("%.1f", t)
                c.drawText(label, x, rulerH - 18f * d, num)
            }
            for (k in 1 until 5) {
                val mt = t + step * k / 5f
                if (mt >= 0f && step * pxPerSec / 5f > 7f * d) {
                    val x = tx(mt)
                    c.drawLine(x, rulerH - 6f * d, x, rulerH, tick)
                }
            }
            t += step
        }
        // composition extent
        head.strokeWidth = 3f * d
        c.drawLine(maxOf(tx(0f), 0f), 1.5f * d, minOf(tx(scene.duration), w), 1.5f * d, head)
        // markers
        for (m in scene.markers) {
            val x = tx(m)
            tri.reset()
            tri.moveTo(x - 6f * d, rulerH - 12f * d); tri.lineTo(x + 6f * d, rulerH - 12f * d); tri.lineTo(x, rulerH)
            tri.close()
            bar.color = C.BLUE
            c.drawPath(tri, bar)
            c.drawLine(x, rulerH, x, h, tick)
        }

        // layer rows
        c.save()
        c.clipRect(0f, rulerH, w, h)
        val sel = host.selectedId()
        for (i in layers.indices) {
            val l = layers[i]
            val top = rulerH + i * rowH - scrollY + 4f * d
            if (top > h || top + rowH < rulerH) continue
            val x0 = tx(l.start)
            val x1 = tx(l.end)
            r.set(x0, top, x1, top + rowH - 8f * d)
            bar.color = when (l.type) {
                LayerType.SHAPE -> 0xFF2F6BFF.toInt()
                LayerType.TEXT -> 0xFFD9822B.toInt()
                LayerType.IMAGE -> 0xFF1FA67A.toInt()
            }
            bar.alpha = if (l.visible) 255 else 90
            c.drawRoundRect(r, 7f * d, 7f * d, bar)
            // effect stripes
            if (l.fx.isNotEmpty()) {
                bar.color = 0x33FFFFFF
                c.drawRect(r.left + 6f * d, r.bottom - 6f * d, r.right - 6f * d, r.bottom - 3f * d, bar)
            }
            // keyframes
            val seen = HashSet<Int>()
            for ((_, tr) in l.props) for (k in tr.keys) {
                val kx = tx(k.t)
                if (kx < x0 || kx > x1) continue
                if (seen.add((k.t * 100f).roundToInt())) {
                    tri.reset()
                    val cy = top + (rowH - 8f * d) / 2f
                    tri.moveTo(kx, cy - 5f * d); tri.lineTo(kx + 5f * d, cy); tri.lineTo(kx, cy + 5f * d); tri.lineTo(kx - 5f * d, cy); tri.close()
                    c.drawPath(tri, white)
                }
            }
            c.save()
            c.clipRect(maxOf(r.left + 8f * d, leftCol), r.top, r.right - 8f * d, r.bottom)
            c.drawText(l.name, maxOf(r.left, leftCol) + 10f * d, top + 17f * d, name)
            c.restore()
            if (l.id == sel) {
                c.drawRoundRect(r, 7f * d, 7f * d, barLine)
                for (side in 0..1) {
                    val hx = if (side == 0) r.left else r.right
                    val hw = 9f * d
                    val hr = RectF(hx - hw, r.top - 1f * d, hx + hw, r.bottom + 1f * d)
                    c.drawRoundRect(hr, 6f * d, 6f * d, white)
                    tri.reset()
                    val cy = (r.top + r.bottom) / 2f
                    val dir = if (side == 0) -1f else 1f
                    tri.moveTo(hx + dir * 3f * d, cy - 4f * d); tri.lineTo(hx + dir * 3f * d, cy + 4f * d); tri.lineTo(hx - dir * 2f * d, cy); tri.close()
                    bar.color = 0xFF222222.toInt()
                    bar.alpha = 255
                    c.drawPath(tri, bar)
                }
            }
        }
        c.restore()

        // left column with visibility toggles
        c.drawRect(0f, rulerH, leftCol, h, bgP)
        c.save()
        c.clipRect(0f, rulerH, leftCol, h)
        for (i in layers.indices) {
            val l = layers[i]
            val cy = rulerH + i * rowH - scrollY + 4f * d + (rowH - 8f * d) / 2f
            Icons.draw(c, if (l.visible) "eye" else "eye_off", leftCol / 2f, cy, 20f * d, if (l.visible) C.TEXT else 0xFF666670.toInt())
        }
        c.restore()

        // playhead and time bubble
        val px = cx()
        head.strokeWidth = 2f * d
        c.drawLine(px, 0f, px, h, head)
        val tc = timecode(Editor.time)
        val bw = headTxt.measureText(tc) + 18f * d
        r.set(px - bw / 2f, 4f * d, px + bw / 2f, 24f * d)
        c.drawRoundRect(r, 10f * d, 10f * d, head)
        c.drawText(tc, px, 19f * d, headTxt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        pinch.onTouchEvent(e)
        if (pinch.isInProgress || e.pointerCount > 1) { mode = 0; return true }
        val layers = Editor.scene.layers
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y; moved = false
                tapLayer = null; tapEye = null
                parent?.requestDisallowInterceptTouchEvent(true)
                val row = rowAt(e.y)
                mode = 1
                if (row in layers.indices) {
                    val l = layers[row]
                    if (e.x < leftCol) { tapEye = l; mode = 0 }
                    else {
                        val x0 = tx(l.start)
                        val x1 = tx(l.end)
                        val hit = 22f * d
                        if (l.id == host.selectedId() && abs(e.x - x0) < hit) { host.beginEdit(); mode = 3 }
                        else if (l.id == host.selectedId() && abs(e.x - x1) < hit) { host.beginEdit(); mode = 4 }
                        else if (l.id == host.selectedId() && e.x in x0..x1) { host.beginEdit(); mode = 5 }
                        else { mode = 2; tapLayer = l }
                    }
                } else if (e.y > rulerH) {
                    mode = 2
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX
                val dy = e.y - lastY
                if (abs(e.x - downX) > 6f * d || abs(e.y - downY) > 6f * d) moved = true
                when (mode) {
                    1, 2 -> {
                        if (mode == 2 && moved && abs(e.y - downY) > abs(e.x - downX) * 1.5f && layers.size > 1) {
                            mode = 6
                        } else if (moved) {
                            if (mode == 2) mode = 1
                            val t = (Editor.time - dx / pxPerSec).coerceIn(0f, Editor.scene.duration)
                            host.onSeek(t)
                        }
                    }
                    6 -> {
                        val maxScroll = maxOf(0f, layers.size * rowH + 8f * d - (height - rulerH))
                        scrollY = (scrollY - dy).coerceIn(0f, maxScroll)
                        invalidate()
                    }
                    3, 4, 5 -> {
                        val l = layers.firstOrNull { it.id == host.selectedId() }
                        if (l != null) {
                            val fps = Editor.project.fps.toFloat()
                            val dur = Editor.scene.duration
                            when (mode) {
                                3 -> l.start = (Math.round(xt(e.x) * fps) / fps).coerceIn(0f, maxOf(0f, l.end - 0.1f))
                                4 -> l.end = (Math.round(xt(e.x) * fps) / fps).coerceIn(l.start + 0.1f, maxOf(dur, l.start + 0.1f))
                                else -> {
                                    val dt = dx / pxPerSec
                                    val len = l.end - l.start
                                    var ns = l.start + dt
                                    ns = ns.coerceIn(0f, maxOf(0f, dur - len))
                                    l.start = ns
                                    l.end = ns + len
                                }
                            }
                            host.onTimingChanged()
                            invalidate()
                        }
                    }
                }
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (!moved) {
                    val eye = tapEye
                    val tl = tapLayer
                    if (eye != null) host.onToggleVisible(eye)
                    else if (tl != null) host.onSelect(tl.id)
                    else if (mode == 2) host.onSelect(-1)
                }
                mode = 0
            }
            MotionEvent.ACTION_CANCEL -> { parent?.requestDisallowInterceptTouchEvent(false); mode = 0 }
        }
        return true
    }
}
